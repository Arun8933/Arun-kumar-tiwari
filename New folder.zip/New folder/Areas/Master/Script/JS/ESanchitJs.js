﻿
//SHOW DATE PRICKER
$(".datepickerAll").datepicker({
    toolbarPlacement: "bottom",
    showButtonPanel: true,
    changeMonth: true,
    changeYear: true,
    dateFormat: 'dd/mm/yy',
});

//SHOW DATE AND TIME PICKER
$(".dateTimepickerAll").datetimepicker({
    format: "d/m/Y H:i", step: 5
});

//FOR TODAY DATE
jQuery.datepicker._gotoToday = function (id) {
    let today = new Date();
    let dateRef = jQuery("<td><a>" + today.getDate() + "</a></td>");
    this._selectDay(id, today.getMonth(), today.getFullYear(), dateRef);
};

//DOCUMENT READY
$(document).ready(function () {
    Firstcolumn = 'E_Sanchit_Document_Uid';
    FillIceGateId('IcegateIdSearch', '----All----');
    FillIceGateId('ICEGATEUserId', '----Select----');
    FillPageSizeList('ddlPageSize', FormList);
    $('#IcegateIdSearch').focus();
});

//PAGE SIZE CHANGE
$("#ddlPageSize").change(function () {
    FormList(1);
});

// PAGINATION BUTTON CLICKED
$(document).on("click", ".pagination .page", function () {
    FormList(($(this).attr('page')));
});

//FORMSEARCH BUTTON CLICK 
$("#FormSearch").click(function () {
    FormList(1);
});


//CUSTOM PORT  LIST PAGE INDEX
function FormList(pageindex) {
    try {
        const dataString = {};
        dataString.PageSize = $("#ddlPageSize").val();
        dataString.PageIndex = pageindex;
        dataString.IcegateUserId = $("#IcegateIdSearch").val();       
        dataString.ImageReferenceNumber = $("#ImageRefNoSearch").val();
        dataString.DocumentReferenceNumber = $("#DocumentRefNoSearch").val();
        dataString.IssuingParty = $("#HiddenIssuingPartySearch").val();
        dataString.BeneficiaryParty = $("#HiddenBeneficiaryPartySearch").val();
        dataString.DocumentTypeCode = $("#HiddenDocumentTypeCodeSearch").val();
        dataString.FileName = $("#FileNameSearch").val();
        dataString.OrderBy = $("#sort-column").val().trim() + " " + $("#sort-type").val().trim();        
        ShowLoader();       
        AjaxSubmission(JSON.stringify(dataString), "/Master/ESanchit/FormList", $('input[name=__RequestVerificationToken]').val()).done(function (result) {
            let obj = result;
            if (obj.status == true) {
                if (obj.responsecode == '100') {
                    let ser = ((parseInt(obj.data.Table1[0].PageIndex) - 1) * parseInt(obj.data.Table1[0].PageSize)) + 1;
                    BindFormTable(obj.data.Table, ser);
                    if (obj.data.Table1 != undefined && obj.data.Table1.length > 0) {
                        $(".pagination").BindPaging({
                            ActiveCssClass: "current",
                            PagerCssClass: "pager",
                            PageIndex: parseInt(obj.data.Table1[0].PageIndex),
                            PageSize: parseInt(obj.data.Table1[0].PageSize),
                            RecordCount: parseInt(obj.data.Table1[0].count)
                        });
                    }
                }
                else 
                    Toast(RetrieveMessage(obj.responsecode), "Message", "error");
            }
            else
                window.location.href = '/ClientLogin/ClientLogin';           
            HideLoader();
        }).fail(function (result) {
            console.log(result.Message);
            HideLoader();
        });
    }
    catch (e) {
        console.log(e.message);
        HideLoader();
    }
}

//ALL INPUT TYPE SEARCH TEXT BOX WHEN ENTER KEY PRESS
$('#ImageRefNoSearch,#DocumentRefNoSearch,#IssuingPartySearch,#BeneficiaryPartySearch,#DocumentTypeCodeSearch').bind('keypress', function (e) {
    if (e.keyCode == 13) {
        $("#FormSearch").trigger('click');
    }
});

var Ercount = 0;
var Firstcolumn = "";

//FUNCTION FOR VALIDATE ESANCHIT 
function ValidateESanchitRequiredField() {
    Ercount = 0;   
    if ($('#ICEGATEUserId').val().trim().length <= 1) {
        Toast('Please Enter ICEGATE User Id.', 'Message', 'error');
        Ercount = 1;
        $('#ICEGATEUserId').focus();
        return;
    }
    if ($('#ImageReferenceNo').val().trim().length <= 0) {
        Toast('Please Enter Image Reference Number', 'Message', 'error');
        Ercount = 1;
        $('#ImageReferenceNo').focus();
        return;
    }
    if ($('#DocumentRefNo').val().trim().length <= 0) {
        Toast('Please Enter Document Reference Number', 'Message', 'error');
        Ercount = 1;
        $('#DocumentRefNo').focus();
        return;
    }
    if ($('#HiddenDocumentTypeCode').val().trim().length <= 0 || $('#DocumentTypeCode').val().trim().length <= 0) {
        Toast('Please Enter Document Type', 'Message', 'error');
        Ercount = 1;
        $('#DocumentTypeCode').focus();
        return;
    }
    if ($('#FileName').val().trim().length <= 0) {
        Toast('Please Enter File Name.', 'Message', 'error');
        Ercount = 1;
        $('#FileName').focus();
        return;
    }
}

// FORM ADD BUTTON CLICK EVENT
$('#FormAdd').click(function () {
    ValidateESanchitRequiredField();
    if (Ercount == 0) {
        if ($('#ICEGATEUserId').val() != "0")
            FormAdd();
        else {
            Toast('Please Select IceGate UserId', 'Message', 'error');
            $('#ICEGATEUserId').focus();
        }
    }
});

//FUNCTION FOR FORM ADD
function FormAdd() {
    try {
        const dataString = {};
        dataString.ICEGATEUserId = $('#ICEGATEUserId').val();
        dataString.ImageReferenceNo = $('#ImageReferenceNo').val().trim();
        dataString.DocumentRefNo = $('#DocumentRefNo').val().trim();
        dataString.DocumentTypeCode = $('#HiddenDocumentTypeCode').val().trim();
        dataString.FileType = $('#FileType').val();
        dataString.UploadDateTime = $('#UploadDateTime').val();
        dataString.PlaceOfIssue = $('#PlaceOfIssue').val();
        dataString.DocumentIssueDate = $('#DocumentIssueDate').val().trim();
        dataString.DocumentExpiryDate = $('#DocumentExpiryDate').val().trim();
        dataString.DocumentIssuingParty = $('#HiddenDocumentIssuingParty').val();
        dataString.DocumentIssuingPartyCode = $('#DocumentIssuingPartyCode').val();
        dataString.DocumentBeneficiaryParty = $('#HiddenDocumentBeneficiaryParty').val();
        dataString.DocumentBeneficiaryPartyCode = $('#DocumentBeneficiaryPartyCode').val();
        dataString.DocumentTypeCodeDescriptions = $('#DocumentTypeCode').val().trim();
        dataString.FileName = $('#FileName').val().trim();

        AjaxSubmission(JSON.stringify(dataString), "/Master/ESanchit/FormAdd", $('input[name=__RequestVerificationToken]').val()).done(function (result) {
            let obj = result;
            if (obj.status == true) {
                if (obj.responsecode == '101') {
                    Toast(RetrieveMessage(obj.responsecode), "Message", "success");
                    $('#FormAdd').hide();
                    $('#FormUpdate,#FormReset').show();                  
                    $("#ESanchit-tab").html("Edit ESanchit Document");
                    setTimeout(FormList(1), 500);
                    $('#TimeStamp').val(obj.data.Table[0].TimeStamp);
                    $('#ESanchitUid').val(obj.data.Table[0].ESanchitDocumentUid);
                }
                else
                    Toast(RetrieveMessage(obj.responsecode), "Message", "error");
            }
            else 
                window.location.href = '/ClientLogin/ClientLogin';
        }).fail(function (result) {
            console.log(result.Message);
        });
    }
    catch (e) {
        console.log(e.message);
    }
}

//FUNCTION FOR EDIT 
function FormEdit(e) {
    try {
        const dataString = {};
        dataString.ESanchitDocumentUid = e;

        AjaxSubmission(JSON.stringify(dataString), '/Master/ESanchit/FormEdit', $('input[name=__RequestVerificationToken]').val()).done(function (result) {
            let obj = result;
            if (obj.status == true) {
                if (obj.responsecode == '100') {
                    TabShow();
                    $('#ESanchitUid').val(obj.data.Table[0].ESanchitDocumentUid);
                    $('#TimeStamp').val(obj.data.Table[0].TimeStamp);

                    let optionExists = ($("#ICEGATEUserId option[value='" + obj.data.Table[0].ICEGATEUserId + "']").length > 0);
                    $('#ICEGATEUserId').val(optionExists == true ? obj.data.Table[0].ICEGATEUserId : 0);
                    $('#ImageReferenceNo').val(obj.data.Table[0].ImageReferenceNo);
                    $('#DocumentRefNo').val(obj.data.Table[0].DocumentReferenceNo);
                    $('#HiddenDocumentTypeCode').val(obj.data.Table[0].DocumentTypeCode)
                    $('#DocumentTypeCode').val(obj.data.Table[0].DocumentTypeCodeDescriptions);
                    $('#FileType').val(obj.data.Table[0].FileType);
                    $('#UploadDateTime').val(obj.data.Table[0].UploadDateTime);
                    $('#HiddenPlaceOfIssue').val(obj.data.Table[0].PlaceOfIssue);
                    $('#PlaceOfIssue').val(obj.data.Table[0].PlaceOfIssue);
                    $('#DocumentIssueDate').val(obj.data.Table[0].DocumentIssueDate);
                    $('#DocumentExpiryDate').val(obj.data.Table[0].DocumentExpiryDate);
                    $('#FileName').val(obj.data.Table[0].FileName);

                    $('#HiddenDocumentIssuingParty').val(obj.data.Table[0].DocumentIssuingParty);
                    $('#DocumentIssuingPartyName').val(obj.data.Table[0].DocumentIssuingPartyName);
                    $('#DocumentIssuingPartyCode').val(obj.data.Table[0].DocumentIssuingPartyCode);

                    $('#HiddenDocumentBeneficiaryParty').val(obj.data.Table[0].DocumentBeneficiaryParty);
                    $('#DocumentBeneficiaryPartyName').val(obj.data.Table[0].DocumentBeneficiaryPartyName);
                    $('#DocumentBeneficiaryPartyCode').val(obj.data.Table[0].DocumentBeneficiaryPartyCode);

                }
                else
                    Toast(RetrieveMessage(obj.responsecode), 'Message', 'error');
            }
            else
                window.location.href = '/ClientLogin/ClientLogin';
        }).fail(function (result) {
            console.log(result.message);
        });
    }
    catch (e) {
        console.log(e.message);
    }

}

// FORM UPDATE BUTTON CLICK EVENT
$('#FormUpdate').click(function () {
    ValidateESanchitRequiredField();
    if (Ercount == 0) {
        if ($('#ESanchitUid').val() == null || $('#ESanchitUid').val() == undefined)
            Toast('ESanchitDocumentUid Not found.', 'Message', 'error');
        else {
            if ($('#ICEGATEUserId').val() != "0")
                FormUpdate();
            else {
                Toast('Please Select IceGate UserId', 'Message', 'error');
                $('#ICEGATEUserId').focus();
            }
        }
    }
});

//FUNCTION FOR FORM UPDATE
function FormUpdate() {
    try {
        const dataString = {};
        dataString.ESanchitDocumentUid = $('#ESanchitUid').val().trim();
        dataString.ICEGATEUserId = $('#ICEGATEUserId').val();
        dataString.ImageReferenceNo = $('#ImageReferenceNo').val().trim();
        dataString.DocumentRefNo = $('#DocumentRefNo').val().trim();
        dataString.DocumentTypeCode = $('#HiddenDocumentTypeCode').val().trim();
        dataString.FileType = $('#FileType').val();
        dataString.UploadDateTime = $('#UploadDateTime').val();
        dataString.PlaceOfIssue = $('#PlaceOfIssue').val();
        dataString.DocumentIssueDate = $('#DocumentIssueDate').val().trim();
        dataString.DocumentExpiryDate = $('#DocumentExpiryDate').val().trim();
        dataString.DocumentIssuingParty = $('#HiddenDocumentIssuingParty').val();
        dataString.DocumentIssuingPartyCode = $('#DocumentIssuingPartyCode').val();
        dataString.DocumentBeneficiaryParty = $('#HiddenDocumentBeneficiaryParty').val();
        dataString.DocumentBeneficiaryPartyCode = $('#DocumentBeneficiaryPartyCode').val();
        dataString.TimeStamp = $('#TimeStamp').val().trim();
        dataString.DocumentTypeCodeDescriptions = $('#DocumentTypeCode').val().trim();
        dataString.FileName = $('#FileName').val().trim();

        AjaxSubmission(JSON.stringify(dataString), "/Master/ESanchit/FormUpdate", $('input[name=__RequestVerificationToken]').val()).done(function (result) {
            let obj = result;
            if (obj.status == true) {
                if (obj.responsecode == '107') {
                    Toast(RetrieveMessage(obj.responsecode), "Message", "success");
                    setTimeout(FormList(1), 500);
                    $('#TimeStamp').val(obj.data.Table[0].TimeStamp);
                    $('#ESanchitUid').val(obj.data.Table[0].ESanchitDocumentUid);
                }
                else 
                    Toast(RetrieveMessage(obj.responsecode), "Message", "error");
            }
            else 
                window.location.href = '/ClientLogin/ClientLogin';
        }).fail(function (result) {
            console.log(result.Message);
        });
    }
    catch (e) {
        console.log(e.message);
    }
}


//FUNCTION FOR FORM DELETE
function FormDelete(e) {
    try {
        $.confirm({
            title: '',
            content: 'Are You Sure Want To Delete ?',
            type: 'red',
            boxWidth: '300px',
            useBootstrap: false,
            columnClass: 'small',
            containerFluid: true,
            typeAnimated: true,
            buttons: {
                tryAgain: {
                    text: 'Confirm',
                    btnClass: 'btn-red',
                    action: function () {

                        const datastring = {};
                        datastring.ESanchitDocumentUid = parseInt(e);
                        ShowLoader();
                        AjaxSubmission(JSON.stringify(datastring), "/ESanchit/FormDelete", $('[name="__RequestVerificationToken"]').val()).done(function (data) {
                            let obj = data;
                            if (obj.status == true) {
                                if (obj.responsecode == '102') {
                                    Toast(RetrieveMessage(obj.responsecode), "Message", "success");
                                    setTimeout(FormList(1), 500);
                                }
                                else if (obj.responsecode == '602') {
                                    window.location.href = '/ClientLogin/ClientLogin';
                                }
                                else {
                                    Toast(RetrieveMessage(obj.responsecode), "Message", "error");
                                }
                            }
                            else {
                                window.location.href = 'ClientLogin/ClientLogin';
                            }
                            HideLoader();
                        }).fail(function (data) {
                            console.log(data.Message);
                            HideLoader();
                        });
                    }
                },
                close: function () {

                }
            }
        });
    }
    catch (e) {
        console.log(e.message);
        HideLoader();
    }
}

//FUNCTION  FOR BIND FORM TABLE
function BindFormTable(Result, SerialNo) {
    let tr = "";
    $("#TblESanchit tbody tr").remove();

    if (Result.length == 0) {
        tr = "<tr>";
        tr += "<td class='text-center' colspan='8'>NO RECORDS FOUND</td></tr>";
        $("#TblESanchit tbody").html(tr);
    } else {
        for (i = 0; i < Result.length; i++) {
            tr += "<tr>";

            tr += "<td class='text-left'><button type='button' title='Edit IRN ' onclick='FormEdit(\"" + Result[i].ESanchitDocumentUid + "\");' class= 'Edit common-btn common-btn-sm ms-1' ><i class='fa-solid fa-pen-to-square'></i></button> <button type='button' title='Delete IRN' onclick='FormDelete(\"" + Result[i].ESanchitDocumentUid + "\");' class= 'Delete common-btn common-btn-sm ' > <i class='fa-regular fa-trash-can'></i></button> </td>";

            tr += "<td class='text-left'>" + SerialNo + "</td>";

            tr += "<td><a href='javascript:void(0)' class='text-decoration-none' style='color: black !important;' onclick='FormEdit(\"" + HandleNullTextValue(Result[i].ESanchitDocumentUid) + "\");'>" + HandleNullTextValue(Result[i].ESanchitDocumentUid) + "</a></td>";

            tr += "<td class='text-center'>" + HandleNullTextValue(Result[i].DocumentTypeCode) + "</td>";

            tr += "<td class='text-center'><a href='javascript:void(0)' class='text-decoration-none' style='color: black !important;' onclick='FormEdit(\"" + HandleNullTextValue(Result[i].ESanchitDocumentUid) + "\");'>" + HandleNullTextValue(Result[i].ImageReferenceNo) + "</a></td>";

            tr += "<td class='text-center'><a href='javascript:void(0)' class='text-decoration-none' style='color: black !important;' onclick='FormEdit(\"" + HandleNullTextValue(Result[i].ESanchitDocumentUid) + "\");'>" + HandleNullTextValue(Result[i].DocumentReferenceNo) + "</a></td>";

            tr += "<td class='text-center'>" + HandleNullTextValue(Result[i].UploadDateTime) + "</td>";

            tr += "<td class='text-center'>" + HandleNullTextValue(Result[i].FileName) + "</td>";

            SerialNo++;
        }
        $("#TblESanchit tbody").html(tr);
    }
}

//FUNCTION FOR FORM SORTING
function FormSorting(obj) {
    if (Firstcolumn != "") {
        document.getElementById(Firstcolumn).innerHTML = document.getElementById(Firstcolumn).getAttribute("data-column") + " <i style='margin-left:10px;' class='fa-solid fa-sort'></i>";
    }
    let cn = obj.id;
    Firstcolumn = cn;
    let colname = $(obj).data("column");
    $("#sort-column").val(cn.replaceAll("_", ""));
    let sorttype = $("#sort-type").val();
    if (sorttype == "ASC") {
        $("#sort-type").val("DESC");
        $(obj).html(colname + " <i style='margin-left:10px;' class='fa-solid fa-sort-down'></i>");
    } else if (sorttype == "DESC") {
        $("#sort-type").val("ASC");
        $(obj).html(colname + " <i style='margin-left:10px;' class='fa-solid fa-sort-up'></i>");
    }
    FormList(1);
}

//ESanchit LIST TAB CLICKED
$("#ESanchit_list-tab").click(function () {
    TabHide();
});

//FUCNTION FOR TAB SHOW
function TabShow() {
    $('#ESanchit_list-tab').removeClass('active');
    $('#ESanchit-tab').addClass('active');
    $('#ESanchit_list').removeClass('active show');
    $('#ESanchit').addClass('active show');
    $("#FormAdd").hide();
    $("#FormUpdate").show();
    $("#FormReset").show();
    $("#ESanchit-tab").html("Edit ESanchit Document");

}

//FUNCTION FOR TAB HIDE
function TabHide() {
    $('#ESanchit-tab').removeClass('active');
    $('#ESanchit_list-tab').addClass('active ');
    $('#ESanchit_list').addClass('active show');
    $('#ESanchit').removeClass('active show');
    $("#FormAdd").show();
    $("#FormUpdate").hide();
    $("#FormReset").hide();
    $("#ESanchit-tab").html("Add ESanchit Document");

}

//FUNCTION FOR EXPORT DATA IN EXCEL
function FormExcel() {
    ShowLoader();
    let date = new Date();
    let NewDate = ("00" + date.getDate()).slice(-2) + "_" + ("00" + (date.getMonth() + 1)).slice(-2) + "_" + date.getFullYear() + "_" + ("00" + date.getHours()).slice(-2) + "_" + ("00" + date.getMinutes()).slice(-2) + "_" + ("00" + date.getSeconds()).slice(-2);
    let fileName = "ESanchit_" + NewDate + ".xlsx";

    $('#FormSearch').trigger('click');
    AjaxSubmission(null, '/Master/ESanchit/FormExcel', $('input[name=__RequestVerificationToken]').val()).done(function (result) {
        let obj = result;
        if (obj.status == true) {
            if (obj.responsecode == '100') {

                let bytes = Base64ToBytes(obj.data.FileData[0].Base64Data);
                let blob = new Blob([bytes], { type: "application/octetstream" });
                let isIE = false || !!document.documentMode;
                if (isIE) {
                    window.navigator.msSaveBlob(blob, fileName);
                } else {
                    let url = window.URL || window.webkitURL;
                    link = url.createObjectURL(blob);
                    let a = $("<a />");
                    a.attr("download", fileName);
                    a.attr("href", link);
                    $("body").append(a);
                    a[0].click();
                    $("body").remove(a);
                }
            }
            else if (obj.responsecode == '302')
                Toast("No Records found.", 'Message', 'success');
            else
                Toast(RetrieveMessage(obj.responsecode), 'Message', 'error');

        } else
            window.location.href = '/ClientLogin/ClientLogin';
        HideLoader();

    }).fail(function (result) {
        console.log(result.Message);
        HideLoader();
    });
}

$('#FormReset').click(function () {
    ResetForm();
})
//GROUP HEADS LIST TAB ON CLICK 
$('#ESanchit_list-tab').click(function () {
    ResetForm();
    RemoveAllError('ESanchitForm');
});
//FUNCTION FOR RESET DATA
function ResetForm() {   
    $('#ESanchitUid').val('');
    $('#TimeStamp').val('');
    $('#ICEGATEUserId').val('0');    
    $('#ImageReferenceNo').val('');
    $('#DocumentRefNo').val('');
    $('#HiddenDocumentTypeCode').val('')
    $('#DocumentTypeCode').val('');
    $('#FileType').val('PDF');
    $('#UploadDateTime').val('');
    $('#HiddenPlaceOfIssue').val('');
    $('#PlaceOfIssue').val('');
    $('#DocumentIssueDate').val('');
    $('#DocumentExpiryDate').val('');
    $('#FileName').val('');

    $('#HiddenDocumentIssuingParty').val('');
    $('#DocumentIssuingPartyName').val('');
    $('#DocumentIssuingPartyCode').val('');
    $('#IssuingPartyCity').val('');
    $('#IssuingPartyPinCode').val('');
    $('#IssuingPartyAddressFirst').val('');
    $('#IssuingPartyAddressSecond').val('');


    $('#HiddenDocumentBeneficiaryParty').val('');
    $('#DocumentBeneficiaryPartyName').val('');
    $('#DocumentBeneficiaryPartyCode').val('');
    $('#DocumentBeneficiaryPartyCity').val('');
    $('#DocumentBeneficiaryPartyPinCode').val('');
    $('#DocumentBeneficiaryPartyAddressFirst').val('');
    $('#DocumentBeneficiaryPartyAddressSecond').val('');

    $("#FormAdd").show();
    $("#FormUpdate").hide();
    $("#FormReset").hide();
    $("#ESanchit-tab").html("Add ESanchit Document");
    $('#ICEGATEUserId').focus();
}

document.addEventListener("keydown", function (zEvent) {
    if (zEvent.ctrlKey && zEvent.altKey && (zEvent.key == "j" || zEvent.key == "J")) {
        $('#ESanchit_list-tab').removeClass('active ');
        $('#ESanchit_list').removeClass('active show');
        $('#ESanchit-tab').addClass('active');
        $('#ESanchit').addClass('active show');
        $("#FormAdd").show();
        $("#FormUpdate").hide();
        $("#FormReset").hide();
        $("#ESanchit-tab").html("Add ESanchit Document");
        ResetForm();
        $('#ICEGATEUserId').focus();


    }
});

//DOCUMENTISSUINGPARTYNAME ON INPUT EVENT
$('#DocumentIssuingPartyName').on('input', function () {
    $('#HiddenDocumentIssuingParty').val('');
});
//DOCUMENTISSUINGPARTYNAME BLUR EVENT
$("#DocumentIssuingPartyName").blur(function () {
    try {
        $('#IssuingPartyCity,#IssuingPartyPinCode,#IssuingPartyAddressFirst,#IssuingPartyAddressSecond').val('');
        const dataString = {};
        let LidI = parseInt($("#HiddenDocumentIssuingParty").val().trim());
        dataString.LedgerUid = LidI;
        if (!isNaN(dataString.LedgerUid)) {
            AjaxSubmission(JSON.stringify(dataString), '/Master/_Layout/GetLedgerAccData', $('input[name=__RequestVerificationToken]').val()).done(function (result) {
                let obj = result.data.Table[0];
                if (result.status == true) {
                    if (result.responsecode == 100) {
                        $("#IssuingPartyCity").val(obj.City);
                        $("#IssuingPartyPinCode").val(obj.PinCode);
                        $("#IssuingPartyAddressFirst").val(obj.Address1);
                        $("#IssuingPartyAddressSecond").val(obj.Address2);

                    }
                }
            }
            ).fail(function (result) {
                console.log(result.Message);
            });
        }
    }
    catch (e) {
        console.log(e.message);
    }
});

//DOCUMENTBENEFICIARYPARTYNAME ON INPUT EVENT
$('#DocumentBeneficiaryPartyName').on('input', function () {
    $('#HiddenDocumentBeneficiaryParty').val('');
});
//DOCUMENTBENEFICIARYPARTYNAME BLUR EVENT
$("#DocumentBeneficiaryPartyName").blur(function () {
    try {
        $('#DocumentBeneficiaryPartyCity,#DocumentBeneficiaryPartyPinCode,#DocumentBeneficiaryPartyAddressFirst,#DocumentBeneficiaryPartyAddressSecond').val('');

        const dataString = {};
        let LidB = parseInt($("#HiddenDocumentBeneficiaryParty").val().trim());
        dataString.LedgerUid = LidB;
        if (!isNaN(dataString.LedgerUid)) {
            AjaxSubmission(JSON.stringify(dataString), '/Master/_Layout/GetLedgerAccData', $('input[name=__RequestVerificationToken]').val()).done(function (result) {
                let obj = result.data.Table[0];
                if (result.status == true) {
                    if (result.responsecode == 100) {
                        $("#DocumentBeneficiaryPartyCity").val(obj.City);
                        $("#DocumentBeneficiaryPartyPinCode").val(obj.PinCode);
                        $("#DocumentBeneficiaryPartyAddressFirst").val(obj.Address1);
                        $("#DocumentBeneficiaryPartyAddressSecond").val(obj.Address2);
                    }
                }
            }
            ).fail(function (result) {
                console.log(result.Message);
            });
        }
    }
    catch (e) {
        console.log(e.message);
    }
})
