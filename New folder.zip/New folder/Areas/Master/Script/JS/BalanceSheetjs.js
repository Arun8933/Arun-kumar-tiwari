﻿
var DateFrom = "";
var DateTo = "";
var Count;
// DOCUMENT ON READY FUNCTION
$(document).ready(function () {
    GetFinancialYearDate();
    $(".datepickerAll").datepicker({
        changeMonth: true,
        changeYear: true,
        dateFormat: 'dd/mm/yy'
    });
    FillBranchList('BranchBalSheet', false);
    $("#BranchBalSheet").select2({
        width: '100%'
    });
    //DATEPICKER FOR SEARCHJOBDATEFROM AND SEARCHJOBDATETO
    $('#SearchDateFromBalSheet,#SearchDateToBalSheet').datepicker({
        toolbarPlacement: "bottom",
        showButtonPanel: true,
        changeMonth: true,
        changeYear: true,
        dateFormat: 'dd/mm/yy',
        onClose: function () {
            if ($('#SearchDateFromBalSheet').val().length == 10 || $('#SearchDateToBalSheet').val().length == 10)
                CompareSearchDate($('#SearchDateFromBalSheet').val(), $('#SearchDateToBalSheet').val(), 'SearchDate');
        }
    });

})
//FUNCTION FOR GET FINANCIAL YEAR DATE
function GetFinancialYearDate() {
    try {
        AjaxSubmission(null, '/_Layout/GetFinancialYearDate', $('[name="__RequestVerificationToken"]').val()).done(function (result) {
            let obj = result;
            console.log(obj)
            if (obj.status == true) {
                if (obj.responsecode == '100') {
                    $("#SearchDateFromBalSheet").val(obj.data.Table[0].finyr_start_date);
                    $("#SearchDateToBalSheet").val(obj.data.Table[0].finyr_end_date);
                }
            }
            else
                window.location.href = '/ClientLogin/ClientLogin';
            HideLoader();
        }).fail(function (result) {
            HideLoader();
            console.log(result.message);
        });
        HideLoader();
    }
    catch (e) {
        HideLoader();
        console.log(e.message);
    }
}

//SEARCH ARROW UP/DOWN
$("#Arrow").click(function () {
    if (srbtn == 'up') {
        $("#icn").html("<i class='fa-solid fa-angle-down'></i>");
        srbtn = 'down';
    } else {
        $("#icn").html("<i class='fa-solid fa-angle-up'></i>");
        srbtn = 'up';
    }
});



$("#FormSearch").click(function () {
    $("#ShowPdf").show();
    var flag = 0;
    var FromDate = $("#SearchDateFromBalSheet").val();
    var ToDate = $("#SearchDateToBalSheet").val();
    if (FromDate == "") {
        Toast("Please Enter Date From", "Message", "error");
        flag = 1;
        return false;
    }
    if (ToDate == "") {
        Toast("Please Enter Date To", "Message", "error");
        flag = 1;
        return false;
    }
    if (FromDate > ToDate) {
        Toast("To Date Must Be Greater Than From Date!", "Message", "error");
        flag = 1;
        return false;
    }
    if (ToDate < FromDate) {
        Toast("To Date Must Be Greater Than From Date!", "Message", "error");
        flag = 1;
        return false;
    }
    if (flag == 0) {
        $(".ReportDNone").show();
        FormList();
    }
});
//FUNCTION FOR FILL PROFIT LOSS STATEMENT
function FormList() {
    try {
        const dataString = {};
        dataString.FromDate = $("#SearchDateFromBalSheet").val();
        dataString.ToDate = $("#SearchDateToBalSheet").val();
        dataString.BranchUid = $("#BranchBalSheet").val();
        ShowLoader();
        AjaxSubmission(JSON.stringify(dataString), "/Master/BalanceSheet/FormList", $('input[name=__RequestVerificationToken]').val()).done(function (result) {
            let obj = result;
            console.log(obj);
            if (obj.status == true) {
                if (obj.responsecode == '100') {
                    //BindFormTable(obj.data.CurrLiabilities, obj.data.CapitalLiabilities, obj.data.Assests, obj.data.Balance);
                    BindFormTable(obj.data.Table);
                }
                else
                    Toast(RetrieveMessage(obj.responsecode), "Message", "error");
            }
            else
                window.location.href = '/ClientLogin/ClientLogin';
            HideLoader();
        }).fail(function (result) {
            console.log(result.Message);
            HideLoader();
        });
    }
    catch (e) {
        console.log(e.message);
        HideLoader();
    }
}


//ON CLICK FUNCTION FOR PDF
$("#BalanceSheetPDF").click(function () {
    try {
        const dataString = {};
        dataString.FromDate = $("#SearchDateFromBalSheet").val();
        dataString.ToDate = $("#SearchDateToBalSheet").val();
        dataString.BranchUid = $("#BranchBalSheet").val();
        ShowLoader();
        AjaxSubmission(JSON.stringify(dataString), "/Master/BalanceSheet/BalanceSheetReport", $('input[name=__RequestVerificationToken]').val()).done(function (result) {
            let obj = result;
            console.log(obj);
            if (obj.status == true) {
                if (obj.responsecode == '100') {
                    window.open($("#MyReport").attr('href'), '_blank');
                }
                else
                    Toast(RetrieveMessage(obj.responsecode), "Message", "error");
            }
            else
                window.location.href = '/ClientLogin/ClientLogin';
            HideLoader();
        }).fail(function (result) {
            console.log(result.Message);
            HideLoader();
        });
    }
    catch (e) {
        console.log(e.message);
        HideLoader();
    }
});

// FUNCTION FOR GO TO REDIRECT VIEW
function GoToRedirectView(E1, E2, E3) {
    window.open('/Master/GroupSummary/GroupSummary', '_blank');
    SetCookie('GroupId', E1, 's', 50);
    SetCookie('Date1', E2, 's', 50);
    SetCookie('Date2', E3, 's', 50);
}


function BindFormTable(Result) {
    DateFrom = $("#SearchDateFromBalSheet").val();
    DateTo = $("#SearchDateToBalSheet").val();
    $("#tbl_BalSheet tbody tr").remove();
    if (Result.length == 0) {
        tr = $('<tr/>');
        tr.append("<td class='text-center' colspan='11'>NO RESULTS FOUND</td>");
        $("#tbl_BalSheet tbody").append(tr);
    }
    else {
        for (i = 0; i < Result.length; i++) {
            tr = $('<tr/>');
            if (Result[i].Type == 'G')
                tr.append("<td class='text-left px-1'><b>" + HandleNullTextValue(Result[i].Liability) + "</b></td>");
            else if (Result[i].Type == 'SG')
                tr.append("<td  class='text-left px-2 ' style='color:#355089 !important'>" + HandleNullTextValue(Result[i].Liability) + "</td>");
            else if (Result[i].Type == 'LG')
                tr.append("<td class='text-left px-3 '>" + HandleNullTextValue(Result[i].Liability) + "</td>");
            else if (Result[i].Type == 'NA')
                tr.append("<td class='text-end  ' style='font-weight: bold;'><b>" + HandleNullTextValue(Result[i].Liability) + "</b></td>");
            else
                tr.append("<td class='text-end  style='font-weight: bold;''  ><b>" + HandleNullTextValue(Result[i].Liability) + "</b></td>");

            if (Result[i].SGroupAmount != null)
                tr.append("<td class='text-end'>" + Result[i].SGroupAmount.toFixed(2) + "</td>");
            else
                tr.append("<td class='text-end'></td>");

            if (Result[i].GroupAmount != null)
                tr.append("<td class='text-end'><b>" + Result[i].GroupAmount.toFixed(2) + "</b></td>");
            else
                tr.append("<td class='text-end'></td>");

            if (Result[i].AS_Type == 'G')
                tr.append("<td class='text-left px-1'><b>" + HandleNullTextValue(Result[i].Assets) + "</b></td>");
            else if (Result[i].AS_Type == 'SG')
                tr.append("<td  class='text-left px-2 ' style='color:#355089 !important'>" + HandleNullTextValue(Result[i].Assets) + "</td>");
            else if (Result[i].AS_Type == 'LG')
                tr.append("<td class='text-left px-3 ' >" + HandleNullTextValue(Result[i].Assets) + "</td>");
            else if (Result[i].AS_Type == 'NA')
                tr.append("<td class='text-end  '  style='font-weight: bold;'><b>" + HandleNullTextValue(Result[i].Assets) + "</b></td>");
            else
                tr.append("<td class='text-end '  style='font-weight: bold;'><b>" + HandleNullTextValue(Result[i].Assets) + "</b></td>");


            if (Result[i].AS_SGroupAmount != null) {
                tr.append("<td class='text-end'>" + Result[i].AS_SGroupAmount.toFixed(2) + "</td>");
            }
            else {
                tr.append("<td class='text-end'></td>");
            }
            if (Result[i].AS_GroupAmount != null) {
                tr.append("<td class='text-end'><b>" + Result[i].AS_GroupAmount.toFixed(2) + "</b></td>");
            }
            else {
                tr.append("<td class='text-end'></td>");
            }
            $("#tbl_BalSheet tbody").append(tr);
        }
    }
}


//FUNCTION FOR EXPORT DATA IN EXCEL
function FormExcel() {
    debugger;
    ShowLoader();
    let date = new Date();
    let NewDate = ("00" + date.getDate()).slice(-2) + "_" + ("00" + (date.getMonth() + 1)).slice(-2) + "_" + date.getFullYear() + "_" + ("00" + date.getHours()).slice(-2) + "_" + ("00" + date.getMinutes()).slice(-2) + "_" + ("00" + date.getSeconds()).slice(-2);
    let fileName = "BalanceSheet_" + NewDate + ".xlsx";

    $('#FormSearch').trigger('click');
    AjaxSubmission(null, '/Master/BalanceSheet/FormExcel', $('input[name=__RequestVerificationToken]').val()).done(function (result) {
        let obj = result;
        if (obj.status == true) {
            if (obj.responsecode == '100') {

                let bytes = Base64ToBytes(obj.data.FileData[0].Base64Data);
                let blob = new Blob([bytes], { type: "application/octetstream" });
                let isIE = false || !!document.documentMode;
                if (isIE) {
                    window.navigator.msSaveBlob(blob, fileName);
                } else {
                    let url = window.URL || window.webkitURL;
                    link = url.createObjectURL(blob);
                    let a = $("<a />");
                    a.attr("download", fileName);
                    a.attr("href", link);
                    $("body").append(a);
                    a[0].click();
                    $("body").remove(a);
                }
            }
            else if (obj.responsecode == '302')
                Toast('No Records found.', 'Message', 'success');
            else
                Toast(RetrieveMessage(obj.responsecode), 'Message', 'error');

        } else
            window.location.href = '/ClientLogin/ClientLogin';
        HideLoader();

    }).fail(function (result) {
        console.log(result.Message);
        HideLoader();
    });
}

