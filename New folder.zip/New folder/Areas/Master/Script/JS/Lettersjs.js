﻿var SelectField = [];
var SelectFieldValue = [];


$("#LetterNameSearch").select2({ width: '100%' });
$("#LetterName").select2({ width: '100%' });

if (Get_Cookie("LettersId") != null) {
    var a = setInterval(() => {
        if (Get_Cookie("LettersId") != '' && Get_Cookie("LettersId") != 0) {
            FormEdit(Get_Cookie("LettersId"));
        }
        EraseCookie('LettersId');
        clearInterval(a);
    }, 1000);
}
//DOCUMENT READY
$(document).ready(function () {
    $("#LetterNotes").css('height', $(".scrol").height() / 1.7);
    if (Get_Cookie("LettersId") == null)
        FillPageSizeList('ddlPageSize', FormList);
    else
        FillPageSizeList('ddlPageSize');

    $(".datepickerAll").datepicker({
        toolbarPlacement: "bottom",
        showButtonPanel: true,
        changeMonth: true,
        changeYear: true,
        dateFormat: 'dd/mm/yy',

    });
    jQuery.datepicker._gotoToday = function (id) {
        var today = new Date();
        var dateRef = jQuery("<td><a>" + today.getDate() + "</a></td>");
        this._selectDay(id, today.getMonth(), today.getFullYear(), dateRef);
    };
    LoadTinyMCE();
    $('#CurrDate').datepicker('setDate', 'today');
    FillLetterList('LetterName');
    FillLetterList('LetterNameSearch');
    $('#SearchJobNo').focus();
})

//FUNCTION FOR TINYMCE EDITIOR
function LoadTinyMCE() {
    tinymce.init({
        selector: ".tinymce",
        branding: false,
        theme: "modern",
        skin: "lightgray",
        width: "100%",
        height: 250,
        statubar: true,
        plugins: [
            "advlist autolink link image lists charmap print preview hr anchor pagebreak",
            "searchreplace wordcount visualblocks visualchars code fullscreen insertdatetime media nonbreaking",
            "save table contextmenu directionality emoticons template paste textcolor"
        ],
        toolbar: "insertfile undo redo | styleselect | bold italic | alignleft aligncenter alignright alignjustify | bullist numlist outdent indent | link | fontsizeselect | fontselect | image | print preview media fullpage | forecolor backcolor emoticons ",
        style_formats: [
            {
                title: "Headers", items: [
                    { title: "Header 1", format: "h1" },
                    { title: "Header 2", format: "h2" },
                    { title: "Header 3", format: "h3" },
                    { title: "Header 4", format: "h4" },
                    { title: "Header 5", format: "h5" },
                    { title: "Header 6", format: "h6" }
                ]
            },
            {
                title: "Inline", items: [
                    { title: "Bold", icon: "bold", format: "bold" },
                    { title: "Italic", icon: "italic", format: "italic" },
                    { title: "Underline", icon: "underline", format: "underline" },
                    { title: "Strikethrough", icon: "strikethrough", format: "strikethrough" },
                    { title: "Superscript", icon: "superscript", format: "superscript" },
                    { title: "Subscript", icon: "subscript", format: "subscript" },
                    { title: "Code", icon: "code", format: "code" }
                ]
            },
            {
                title: "Blocks", items: [
                    { title: "Paragraph", format: "p" },
                    { title: "Blockquote", format: "blockquote" },
                    { title: "Div", format: "div" },
                    { title: "Pre", format: "pre" }
                ]
            },
            {
                title: "Alignment", items: [
                    { title: "Left", icon: "alignleft", format: "alignleft" },
                    { title: "Center", icon: "aligncenter", format: "aligncenter" },
                    { title: "Right", icon: "alignright", format: "alignright" },
                    { title: "Justify", icon: "alignjustify", format: "alignjustify" }
                ]
            }
        ],
    });
}

/*----------------------------------------------FORM ADD UPDATE DELETE EDIT LIST CODE START-------------------------------------*/
//LETTER ASSIGN LIST FUNCTION
function FormList(pageindex) {
    try {
        const dataString = {};
        dataString.PageSize = $("#ddlPageSize").val();
        dataString.PageIndex = pageindex;
        dataString.LetterAssignId = $("#LetterIdSearch").val();
        dataString.LetterId = $("#LetterNameSearch").val();
        /*dataString.SubJobNo = $("#SubJobNoSearch").val();*/
        dataString.JobNo = $("#JobNoSearch").val();
        dataString.Date = $("#DateSearch").val();
        dataString.OrderBy = $("#sort-column").val().trim() + " " + $("#sort-type").val().trim();
        //Showloader();
        AjaxSubmission(JSON.stringify(dataString), "/Master/Letters/FormList", $('input[name=__RequestVerificationToken]').val()).done(function (result) {
            let obj = result;
            if (obj.status == true) {
                if (obj.responsecode == '100') {
                    var ser = ((parseInt(obj.data.Table1[0].PageIndex) - 1) * parseInt(obj.data.Table1[0].PageSize)) + 1;
                    BindFormTable(obj.data.Table, ser);
                    if (obj.data.Table1 != undefined && obj.data.Table1.length > 0) {
                        $(".pagination").BindPaging({
                            ActiveCssClass: "current",
                            PagerCssClass: "pager",
                            PageIndex: parseInt(obj.data.Table1[0].PageIndex),
                            PageSize: parseInt(obj.data.Table1[0].PageSize),
                            RecordCount: parseInt(obj.data.Table1[0].count)
                        });
                    }
                }
                else {
                    Toast(RetrieveMessage(obj.responsecode), "Message", "error");
                }
            }
            else {
                window.location.href = '/ClientLogin/ClientLogin';
            }
            //Hideloader();
        }).fail(function (result) {
            console.log(result.Message);
            //Hideloader();
        });
    }
    catch (e) {
        console.log(e.message);
        //Hideloader();
    }
}

//FUNCTION FOR BIND LETTER ASSIGN TABLE
function BindFormTable(Result, SerialNo) {
    $("#TblLetter tbody tr").remove();
    if (Result.length == 0) {
        tr = $('<tr/>');
        tr.append("<td class='text-center' colspan='8'>NO RESULTS FOUND</td>");
        $("#TblLetter tbody").append(tr);
    }
    else {
        for (i = 0; i < Result.length; i++) {
            if (Result[i].is_active == "Inactive") {
                tr = $(' <tr style="background-color:#fdd2d2;"/>');
            }
            else {
                tr = $('<tr/>');
                tr.append("<td class='text-center'><button type='button' onclick='FormEdit(\"" + Result[i].LetterAssignUid + "\");' class='common-btn common-btn-sm'><i class='fa-solid fa-pen-to-square'></i></button ><button type='button' onclick='FormDelete(\"" + Result[i].LetterAssignUid + "\");' class='common-btn common-btn-sm ms-1'> <i class='fa-regular fa-trash-can'></i></button ></td > ");
                tr.append("<td class='text-left'>" + SerialNo + "</td>");
                tr.append("<td class='text-left'>" + Result[i].LetterAssignUid + "</td>");
                /*tr.append("<td class='text-left'><a href='javascript:void(0)' class='text-decoration-none ' style='color: black !important;' onclick='FormEdit(\"" + Result[i].LetterAssignUid + "\");'>" + HandleNullTextValue(Result[i].SubJobNo) + "</a></td>");*/
                tr.append("<td class='text-center'><a href='javascript:void(0)' class='text-decoration-none ' style='color: black !important;' onclick='FormEdit(\"" + Result[i].LetterAssignUid + "\");'>" + Result[i].JobNo + "</a></td>");
                tr.append("<td class='text-center'>" + Result[i].AccHead + "</td>");

                tr.append("<td class='text-center'>" + Result[i].LetterName + "</td>");
                tr.append("<td class='text-center'>" + Result[i].Date + "</td>");


            }
            SerialNo++;
            $("#TblLetter tbody").append(tr);
        }
    }
}

//FUNCTION FOR SORTING 
function FormSorting(obj) {
    if (Firstcolumn != "") {
        document.getElementById(Firstcolumn).innerHTML = document.getElementById(Firstcolumn).getAttribute("data-column") + " <i class='fa-solid fa-sort'></i>";
    }
    let cn = obj.id;
    Firstcolumn = cn;
    var colname = $(obj).data("column");
    $("#sort-column").val(cn.replaceAll("_", ""));
    var sorttype = $("#sort-type").val();
    if (sorttype == "ASC") {
        $("#sort-type").val("DESC");
        $(obj).html(colname + " <i style='margin-left:10px;' class='fa-solid fa-sort-up'></i>");
    } else if (sorttype == "DESC") {
        $("#sort-type").val("ASC");
        $(obj).html(colname + " <i style='margin-left:10px;' class='fa-solid fa-sort-down'></i>");
    }
    FormList(1);
}

//FUNCTION FOR PEGINATION PREVIOUS NEXT CLICK
$(document).on("click", ".pagination .page", function () {
    FormList(($(this).attr('page')));
});

//PAGE SIZE DROPDOWN ON CHANGE
$("#ddlPageSize").change(function () {
    FormList(1);
});

//SEARCH BUTTON CLICK
$("#FormSearch").click(function () {
    FormList(1);
});

//FORM ADD CLICK LETTER ASSIGN
$("#FormAdd").click(function () {
    try {
        RemoveAllError('Letters');
        ValidateAllFieldNewTest('Letters');

        if (Ercount == 0) {
            if ($("#HiddenSearchJobNo").val().length == 0) {
                Toast("Please Fill Job No !", "message", "error");
                return;
            }
            if ($("#LetterName").val() == "0") {
                Toast("Please Select Letter !", "message", "error");
                return;
            }
            if ($("#CurrDate").val().length == 0) {
                Toast("Please Fill Date !", "message", "error");
                return;
            }
            FormAdd();
        }
    }
    catch (ex) {
        console.log(ex.message);
    }
});

//FUNCTION FOR FORM ADD LETTER ASSIGN
function FormAdd() {
    try {
        const dataString = {};
        dataString.JobNo = $("#HiddenSearchJobNo").val();
        dataString.LetterUid = $("#LetterName").val();
        dataString.Date = $("#CurrDate").val();
        dataString.LetterNotes = $("#LetterNotes").val();
        dataString.CCEmail = $("#CCEmail").val();

        //Showloader();
        AjaxSubmission(JSON.stringify(dataString), "/Master/Letters/FormAdd", $('input[name=__RequestVerificationToken]').val()).done(function (result) {
            let obj = result;
            if (obj.status == true) {
                if (obj.responsecode == '101') {
                    Toast(RetrieveMessage(obj.responsecode), "Message", "success");
                    setTimeout(FormList(1), 1000);
                    $("#LetterAssignId").val(obj.data.Table[0].LetterAssignId);
                    $("#Timestamp").val(obj.data.Table[0].Timestamp);

                    $("#Letters-tab").html("Edit Letter");
                    $("#FormAdd").hide();
                    $("#FormPrint").show();
                    $("#FormPrintLH").show();
                    $("#FormPrintPlain").show();
                    $("#OpenEmailModal").show();
                    $("#AddNew").show();
                    $("#FormUpdate").show();
                }
                else {
                    Toast(RetrieveMessage(obj.responsecode), "Message", "error");
                }
            }
            else {
                window.location.href = '/ClientLogin/ClientLogin';
            }
            //Hideloader();
        }).fail(function (result) {
            console.log(result.Message);
            //Hideloader();
        });
    }
    catch (e) {
        console.log(e.message);
    }
}

//FUNCTION FOR FORM EDIT LETTER ASSIGN
function FormEdit(e) {
    try {
        const datastring = {};
        datastring.LetterAssignId = e;
        AjaxSubmission(JSON.stringify(datastring), "/Master/Letters/FormEdit", $('[name="__RequestVerificationToken"]').val()).done(function (data) {
            let obj = data;
            if (obj.status == true) {
                if (obj.responsecode == '100') {
                    TabShow();
                    $("#LetterAssignId").val(obj.data.Table[0].LetterAssignId);
                    $("#HiddenSearchJobNo").val(obj.data.Table[0].JobNo);
                    $("#SearchJobNo").val(obj.data.Table[0].JobNo).trigger('change');
                    $("#PrintDate").val(obj.data.Table[0].PrintDate);
                    $("#LetterName").val(obj.data.Table[0].LetterUid).trigger('change');
                    $("#CurrDate").val(obj.data.Table[0].Date);
                    $("#LetterNotes").val(obj.data.Table[0].LetterNotes);
                    $("#CCEmail").val(obj.data.Table[0].CCEmail);
                    $("#Timestamp").val(obj.data.Table[0].Timestamp);

                } else {
                    Toast(RetrieveMessage(obj.responsecode), "Message", "error");
                }
            }
            else {
                window.location.href = '/ClientLogin/ClientLogin';
            }
        }).fail(function (data) {
            console.log(data.Message);
        });

    }
    catch (e) {
        console.log(e.message);
    }
}

//FORM UPDATE BUTTON CLICK LETTER ASSIGN
$("#FormUpdate").click(function () {
    if ($("#HiddenSearchJobNo").val().length == 0) {
        Toast("Please Fill Job No !", "message", "error");
        return;
    }

    if ($("#LetterName").val() == "0") {
        Toast("Please Select Letter !", "message", "error");
        return;
    }
    if ($("#CurrDate").val().length == 0) {
        Toast("Please Fill Date !", "message", "error");
        return;
    }
    FormUpdate();
});

//FUNCTION FOR FORM UPDATE LETTER ASSIGN
function FormUpdate() {
    try {

        const dataString = {};
        dataString.JobNo = $("#HiddenSearchJobNo").val();
        dataString.LetterUid = $("#LetterName").val();
        dataString.Date = $("#CurrDate").val();
        dataString.LetterNotes = $("#LetterNotes").val();
        dataString.CCEmail = $("#CCEmail").val();
        dataString.PrintDate = $("#PrintDate").val();
        dataString.LetterAssignUid = $("#LetterAssignId").val();
        dataString.Timestamp = $("#Timestamp").val();

        //Showloader();
        AjaxSubmission(JSON.stringify(dataString), "/Master/Letters/FormUpdate", $('input[name=__RequestVerificationToken]').val()).done(function (result) {
            let obj = result;
            if (obj.status == true) {
                if (obj.responsecode == '107') {
                    Toast(RetrieveMessage(obj.responsecode), "Message", "success");
                    setTimeout(FormList(1), 1000);
                    $("#Timestamp").val(obj.data.Table[0].Timestamp);
                    $("#LetterAssignId").val(obj.data.Table[0].LetterAssignId);
                }
                else {
                    Toast(RetrieveMessage(obj.responsecode), "Message", "error");
                }
            }
            else {
                window.location.href = '/ClientLogin/ClientLogin';
            }
            //Hideloader();
        }).fail(function (result) {
            console.log(result.Message);
            //Hideloader();

        });
    }
    catch (e) {
        //Hideloader();
        console.log(e.Message);
    }
}

//FUNCTION FOR FORM DELETE
function FormDelete(e) {
    try {
        $.confirm({
            title: '',
            content: 'Are You Sure Want To Delete ?',
            type: 'red',
            boxWidth: '300px',
            useBootstrap: false,
            columnClass: 'small',
            containerFluid: true,
            typeAnimated: true,
            buttons: {
                tryAgain: {
                    text: 'Confirm',
                    btnClass: 'btn-red',
                    action: function () {
                        const datastring = {};
                        datastring.LetterAssignId = parseInt(e);
                        //Showloader();
                        AjaxSubmission(JSON.stringify(datastring), "/Master/Letters/FormDelete", $('[name="__RequestVerificationToken"]').val()).done(function (data) {
                            let obj = data;
                            if (obj.status == true) {
                                if (obj.responsecode == '102') {
                                    Toast(RetrieveMessage(obj.responsecode), "Message", "success");
                                    FormList(1);
                                }
                                else {
                                    Toast(RetrieveMessage(obj.responsecode), "Message", "error");
                                }
                            }
                            else {
                                window.location.href = 'ClientLogin/ClientLogin';
                            }
                            //Hideloader();
                        }).fail(function (data) {
                            console.log(data.Message);
                            //Hideloader();
                        });
                    }
                },
                close: function () {
                    //Hideloader();
                }
            }
        });
    }
    catch (e) {
        console.log(e.message);
        //Hideloader();
    }
}
/*----------------------------------------------FORM ADD UPDATE DELETE EDIT LIST CODE END-------------------------------------*/


/*----------------------------------------------OTHER FUNCTIONS DROPDOWN KEY PRESS ,ON INPUT , ON CHANGE  START-------------------------------------*/
//SEARCHJOBNO KEYPRESS EVENT
$("#SearchJobNo").bind('keypress', function (e) {
    if (e.keyCode == 13) {
        $("#SearchJobNo").trigger('change');
    }
});
//FUNCTION FOR FILL DATA OF JOB NUMBER
function SearchJobNo() {
    ResetForm();   
    if ($("#HiddenSearchJobNo").val().trim().length == 0) {
        Toast('Job Number Required', 'Message', 'error');
        $("#SearchJobNo").focus();
        $("#LetterNotes").val('');
    }
    else {
        FillJobData($("#HiddenSearchJobNo").val().trim());
    }
}

//SEARCH JOB NO ON INPUT 
$("#SearchJobNo").on('input', function () {
    $("#HiddenSearchJobNo").val('');
});

//SEARCHJOBNO KEYPRESS EVENT
$("#JobNoSearch").bind('keypress', function (e) {
    if (e.keyCode == 13) {
        $("#JobNoSearch").trigger('change');
    }
});

//FUNCTION FOR GET DATA OF JOB NUMBER
function FillJobData(e) {
    try {
        const dataString = {};
        dataString.JobNo = e;
        AjaxSubmission(JSON.stringify(dataString), '/Master/Letters/FillJobData', $('input[name=__RequestVerificationToken]').val()).done(function (result) {

            let obj = result;

            if (obj.status == true) {
                if (obj.responsecode == '100') {

                    $("#ClientName").val(obj.data.Table[0].ClientName);
                    $("#CFS").val(obj.data.Table[0].CFS);
                    $("#ShippingLine").val(obj.data.Table[0].ShippingLine);
                    $("#Indentor").val(obj.data.Table[0].Indentor);

                }
                else
                    Toast(RetrieveMessage(obj.responsecode), 'Message', 'error');

            } else
                window.location.href = '/ClientLogin/ClientLogin';
            //Hideloader();

        }).fail(function (result) {
            console.log(result.Message);
            //Hideloader();
        });
    }
    catch (e) {
        console.log(e.message);
    }
}

//FUNCTION FOR BIND LETTER NAMES FROM LETTER MASTER 
function FillLetterList(DrpId) {
    try {
        //Showloader();
        AjaxSubmission(null, "/Master/Letters/GetLetterList", $('input[name=__RequestVerificationToken]').val()).done(function (result) {
            let obj = result;
            if (obj.status == true) {
                if (obj.responsecode == '100') {
                    BindDropdown(obj.data.Table, DrpId, 'LetterUid', 'LetterName', '-----Select-----');
                }
                else if (obj.responsecode == '604') {
                    BindDropdown(null, DrpId, 'LetterUid', 'LetterName', '-----Select-----');
                }
                else {
                    Toast(RetrieveMessage(obj.responsecode), "Message", "error");
                }
                //setTimeout(FormList(1), 1000);
            }
            else {
                window.location.href = '/ClientLogin/ClientLogin';
            }
            //Hideloader();
        }).fail(function (result) {
            console.log(result.Message);
            //Hideloader();
        });
    }
    catch (e) {
        console.log(e.message);
        //Hideloader();
    }
}

//LETTER NAME DROPDOWN ON CHANGE 
$("#LetterName").change(function () {
    if ($("#LetterName").val() == "0") {
        $("#LetterNotes").val('');
    }
    if ($("#LetterName").val() != "0" && $("#HiddenSearchJobNo").val().length != 0) {
        FillLetterNotes($("#LetterName").val(), $("#HiddenSearchJobNo").val());
    }
    if ($("#LetterName").val() != "0" && $("#HiddenSearchJobNo").val().length == 0) {
        Toast("Please Select Job No !", "message", "error");
    }

});

//FUNCTION TO GET LETTER NOTES ON CHANGE OF JOB NUMBER
function GetLetterNotes() {  
    if ($("#LetterName").val() != "0" && $("#HiddenSearchJobNo").val().length != 0) {      
        FillLetterNotes($("#LetterName").val(), $("#HiddenSearchJobNo").val());
    }
}

//FUNCTION TO GET LETTER NOTES FROM LETTER MASTER 
function FillLetterNotes(e, JobNo) {
    try {
        const dataString = {};
        dataString.LetterId = e;
        dataString.JobNo = JobNo;
        AjaxSubmission(JSON.stringify(dataString), "/Master/Letters/GetLetterNotes", $('input[name=__RequestVerificationToken]').val()).done(function (result) {
            let obj = result;
            SelectField.push(obj.data.AllColumn[0].SelectFields.split(','));
            SelectFieldValue.push(obj.data.AllColumn[0].SelectFieldValue.split('},'));
            if (obj.status == true) {
                if (obj.responsecode == '100') {
                    var LetterNotes = obj.data.Table[0].LetterNotes;

                    for (var i = 0; i <= SelectField[0].length; i++) {
                        LetterNotes = LetterNotes.replaceAll(SelectField[0][i], SelectFieldValue[0][i]);
                    }


                    $("#LetterNotes").val(LetterNotes);
                    SelectField = [];
                    SelectFieldValue = [];
                }
                else {
                    Toast(RetrieveMessage(obj.responsecode), "Message", "error");
                }
                //setTimeout(FormList(1), 1000);
            }
            else {
                window.location.href = '/ClientLogin/ClientLogin';
            }
            //Hideloader();
        }).fail(function (result) {
            console.log(result.Message);
            //Hideloader();
        });
    }
    catch (e) {

    }
}

//FUNCTION FOR JOB NUMBER AUTOCOMPLETE AJAX WITH ID
function JobNoAutoCompleteAjax(id, Url, HiddenId) {

    $("#" + id).autocomplete({
        source: function (request, response) {
            AjaxSubmissionAutocomplete(JSON.stringify({ SearchField: request.term }), Url, $('input[name=__RequestVerificationToken]').val()).done(function (result) {
                let obj = result;
                if (obj.status == true) {
                    if (obj.responsecode == '100') {
                        response($.map(result.data.Table, function (item, id) {
                            return {
                                label: item.name,
                                value: item.name,
                                id: item.id
                            };
                        }));
                    }
                }
                else
                    window.location.href = '/ClientLogin/ClientLogin';
                //Hideloader();
            }).fail(function (result) {
                //Hideloader();
                console.log(result.Message);
            });
        },

        minLength: 1,

        selectOnly: true,
        select: function (e, i) {
            $("#" + HiddenId).val(i.item.id);
            SearchJobNo();
        },
        change: function (e, i) {
            if (i.item == null || i.item == undefined) {
                $("#" + id).val('');
                $("#" + HiddenId).val('');
            }

        }
    });
}

//FUNCTION FOR TAB HIDE
function TabShow() {
    $('#Letters_list-tab').removeClass('active');
    $('#Letters-tab').addClass('active');
    $('#Letters_list').removeClass('active show');
    $('#Letters').addClass('active show');
    $("#FormAdd").hide();
    $("#FormPrint").show();
    $("#FormPrintLH").show();
    $("#FormPrintPlain").show();
    $("#OpenEmailModal").show();

    $("#AddNew").show();
    $("#FormUpdate").show();
    $("#Letters-tab").html("Edit Letter");
}

//FUNCTION FOR TAB HIDE
function TabHide() {
    $('#Letters-tab').removeClass('active');
    $('#Letters_list-tab').addClass('active ');
    $('#Letters_list').addClass('active show');
    $('#Letters').removeClass('active show');
    $("#FormAdd").show();
    $("#FormUpdate").hide();
    $("#FormPrint").hide();
    $("#FormPrintLH").hide();
    $("#FormPrintPlain").hide();
    $("#OpenEmailModal").hide();
    $("#AddNew").hide();
    $("#Letters-tab").html("Add Letter");
}

//LETTERS LIST TAB ON CLICK 
$('#Letters_list-tab').click(function () {
    ResetData();
    TabHide();
    RemoveAllError('Letters');
});

//FUNCTION FOR RESET CLIENT NAME AND IMPORTER DATA ON JOB NO CHANGE 
function ResetForm() {
    $("#ClientName").val('');
    $("#CFS").val('');
    $("#ShippingLine").val('');
    $("#Indentor").val('');
}

//FUNCTION FOR RESET DATA
function ResetData() {
    $("#LetterAssignId").val('');
    $("#Timestamp").val('');
    $("#ClientName").val('');
    $("#CFS").val('');
    $("#ShippingLine").val('');
    $("#Indentor").val('');
    $("#SearchJobNo").val('');
    $("#LetterName").val('0').trigger('change');
    $('#CurrDate').datepicker('setDate', 'today');
    $("#LetterNotes").val('');
    $("#CCEmail").val('');
    $("#PrintDate").val('');
}

// ADD NEW BUTTON CLICK 
$("#AddNew").click(function () {
    $("#Letters-tab").html("Add Letter");
    $("#FormAdd").show();
    $("#FormUpdate").hide();
    $("#FormPrint").hide();
    $("#FormPrintLH").hide();
    $("#FormPrintPlain").hide();
    $("#OpenEmailModal").hide();
    $("#AddNew").hide();
    $("#PrintDate").val('');
    ResetData();
});

function GoToLetter(e) {
    SetCookie('LetterId', $("#" + e).val(), 's', 50);
}

/*----------------------------------------------OTHER FUNCTIONS DROPDOWN KEY PRESS ,ON INPUT , ON CHANGE  END-------------------------------------*/


/*----------------------------------------------CREATE PDF CODE START -------------------------------------*/

$("#FormPrint").click(function () {
    PrintLetterReport('LetterPrint');
})
$("#FormPrintLH").click(function () {
    PrintLetterReport('LetterPrintLetterHead');
})
$("#FormPrintPlain").click(function () {
    PrintLetterReport('LetterPrintPlain');

})
//FUNCTION FOR PRINT LETTER REPORTS GET DATA OF A REPORT 
function PrintLetterReport(ReportType) {
    try {
        const datastring = {};

        datastring.ReportType = ReportType;
        datastring.LetterAssignId = $("#LetterAssignId").val();
        AjaxSubmission(JSON.stringify(datastring), "/Master/Letters/PrintLetterReport", $('input[name=__RequestVerificationToken]').val()).done(function (result) {
            let obj = result;

            if (obj.status == true) {
                if (obj.responsecode == '100') {
                    $("#Timestamp").val(obj.data[0].Timestamp);
                    $("#LetterAssignId").val(obj.data[0].LetterAssignId);
                    window.open($("#MyReport").attr('href'), '_blank');


                }
                else {
                    Toast(RetrieveMessage(obj.responsecode), "Message", "error");
                }
            }
            else {
                window.location.href = '/ClientLogin/ClientLogin';
            }
            //Hideloader();
        }).fail(function (result) {
            console.log(result.Message);
            //Hideloader();
        });
    }
    catch (e) {
        console.log(e.message);
    }
}
/*----------------------------------------------CREATE PDF CODE END -------------------------------------*/


/*----------------------------------------------SEND EMAIL CODE START -------------------------------------*/


//MODAL SEND EMAIL CLICK TO GET EMAIL DATA AND OPEN MODEL
$("#OpenEmailModal").click(function () {
    GetEmailData();
});
//FUNCTION TO FILL EMAIL RELATED DETAILS 
function GetEmailData() {
    try {
        ShowLoader();
        const datastring = {};
        datastring.LetterAssignId = $("#LetterAssignId").val();
        AjaxSubmission(JSON.stringify(datastring), "/Master/Letters/GetEmailData", $('input[name=__RequestVerificationToken]').val()).done(function (result) {
            let obj = result;
            if (obj.status == true) {
                if (obj.responsecode == '100') {
                    EmailModal.style.display = "block";
                    $("#EmailTo").val(obj.data.Table1[0].ClientEmail);
                    $("#EmailCC").val(obj.data.Table1[0].CCEmail);
                    $("#EmailLetterName").val(obj.data.Table1[0].LetterName);
                    $("#AttachFileName").text(obj.data.Table2[0].FileName);
                    $("#AttachFileName").attr("href", obj.data.Table2[0].FilePath);
                    $("#AttachedFilePath").val(obj.data.Table2[0].AttachmentFilePath);

                    $("#RefId").val($("#LetterAssignId").val());
                    $("#SendToName").val($("#ClientName").val());
                    $("#RefName").val('Letters');
                    BindTemplateName('AllTemplate', 'Email');
                    FillTemplateDataInTincyMce($('#SearchJobNo').val(), 'Letters', null, 'Email');

                }
                else if (obj.responsecode == "1046")
                    Toast(RetrieveMessage(obj.responsecode), "Message", "error");
                else
                    Toast(RetrieveMessage(obj.responsecode), "Message", "error");

            }
            else
                window.location.href = '/ClientLogin/ClientLogin';

            HideLoader();
        }).fail(function (result) {
            console.log(result.Message);
            HideLoader();
        });
    }
    catch (e) {
        console.log(e.message);
        HideLoader();
    }
}

//FUNCTION FOR CHANGE TEMPLATE DETAILS
function TemplateChange() {
    tinymce.get("EmailBody").setContent('');
    $('#Subject').val('');
    if ($('#AllTemplate').val() != null && $('#AllTemplate') != undefined) {
        if ($('#AllTemplate').val() != 0)
            FillTemplateDataInTincyMce($('#SearchJobNo').val(), 'Letters', $('#AllTemplate').val(), 'Email');
    }
}

/*----------------------------------------------SEND EMAIL CODE END -------------------------------------*/


