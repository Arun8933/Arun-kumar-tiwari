﻿var DateFrom = "";
var DateTo = "";
var Count;
// DOCUMENT ON READY FUNCTION
$(document).ready(function () {
    GetFinancialYearDate();
    $(".datepickerAll").datepicker({
        changeMonth: true,
        changeYear: true,
        dateFormat: 'dd/mm/yy'
    });
    $(".datepickerAll1").datepicker({
        changeMonth: true,
        changeYear: true,
        dateFormat: 'dd/mm/yy'
    });
    $(".datepickerAll1").datepicker('setDate', 'today');
    FillBranchList('SelectBranch', false);
    $("#SelectBranch").select2({
        width: '100%'
    });
    $("#BillStatusSearch").select2({
        width: '100%'
    });
    $("#GroupSearch").select2({
        width: '100%'
    });
    //DATEPICKER FOR SEARCHJOBDATEFROM AND SEARCHJOBDATETO
    $('#SearchDateFrom,#SearchDateTo').datepicker({
        toolbarPlacement: "bottom",
        showButtonPanel: true,
        changeMonth: true,
        changeYear: true,
        dateFormat: 'dd/mm/yy',
        onClose: function () {
            if ($('#SearchDateFrom').val().length == 10 || $('#SearchDateTo').val().length == 10)
                CompareSearchDate($('#SearchDateFrom').val(), $('#SearchDateTo').val(), 'SearchDate');
        }
    });
    FillGroup('GroupSearch');
    LoadTinyMCE();
})


//FUNCTION FOR GET FINANCIAL YEAR DATE
function GetFinancialYearDate() {
    try {
        AjaxSubmission(null, '/_Layout/GetFinancialYearDate', $('[name="__RequestVerificationToken"]').val()).done(function (result) {
            let obj = result;
            console.log(obj)
            if (obj.status == true) {
                if (obj.responsecode == '100') {
                    $("#SearchDateFrom").val(obj.data.Table[0].finyr_start_date);
                    $("#SearchDateTo").val(obj.data.Table[0].finyr_end_date);
                }
            }
            else
                window.location.href = '/ClientLogin/ClientLogin';
            HideLoader();
        }).fail(function (result) {
            HideLoader();
            console.log(result.message);
        });
        HideLoader();
    }
    catch (e) {
        HideLoader();
        console.log(e.message);
    }
}

//SEARCH ARROW UP/DOWN
$("#Arrow").click(function () {
    if (srbtn == 'up') {
        $("#icn").html("<i class='fa-solid fa-angle-down'></i>");
        srbtn = 'down';
    } else {
        $("#icn").html("<i class='fa-solid fa-angle-up'></i>");
        srbtn = 'up';
    }
});

$("#AccHeadSearch").autocomplete({
    source: function (request, response) {
        $.ajax({
            type: 'POST',
            url: "/Master/PaymentReminder/SearchAccHeadNameList",
            dataType: "json",
            async: false,
            data: {
                AccDescription: request.term, GroupUid: $("#GroupSearch").val()
            },
            success: function (result) {
                response($.map(result.data.Table, function (LedgerName) {
                    return {
                        label: LedgerName.AccHead,
                        value: LedgerName.AccHead,
                        id: LedgerName.ledgeruid,
                        LedgerGroup: LedgerName.LedgerGroup,
                    }
                }));
            },
            error: function (response) {
                console.log(response.responseText);
            }
        });
    },
    autoFocus: true,
    minLength: 1,
    selectFirst: true,
    selectOnly: true,
    select: function (e, i) {
        $("#HiddenLedgerId").val(i.item.id);
        $("#GroupSearch").val(i.item.LedgerGroup);
    },

});

//FUNCTION FOR FILL GROUP
function FillGroup(DrpID) {
    try {
        //Showloader();
        AjaxSubmission(null, "/PaymentReminder/FillGroup", $('input[name=__RequestVerificationToken]').val()).done(function (data) {
            let obj = data;
            if (obj.status == true) {
                if (obj.responsecode == '100')
                    BindDropdown(obj.data.Table, DrpID, 'SubgroupHeadUid', 'SubgroupHeadName', '---Select---');
                else if (obj.responsecode == '100')
                    BindDropdown(obj.data.Table, DrpID, 'SubgroupHeadUid', 'SubgroupHeadName', '---Select---');
                else
                    Toast(RetrieveMessage(obj.responsecode), "Message", "error");
            }
            else
                window.location.href = '/ClientLogin/ClientLogin';
            //Hideloader();
        }).fail(function (result) {
            console.log(result.Message);
            //Hideloader();
        });
    }
    catch (e) {
        console.log(e.message);
        //Hideloader();
    }
}


$("#FormSearch").click(function () {
    var flag = 0;
    var FromDate = $("#SearchDateFrom").val();
    var ToDate = $("#SearchDateTo").val();
    var HiddenLedgerId = $('#HiddenLedgerId').val();
    if ($("#GroupSearch").val() == "0") {
        Toast("Please Select Account Group !", 'Message', 'error');
        flag = 1;
        return false;
    }
    if ($('#SearchDateFrom').val().length == 10 || $('#SearchDateTo').val().length == 10)
        CompareSearchDate($('#SearchDateFrom').val(), $('#SearchDateTo').val(), '');
    var flag = 0;

    if (HiddenLedgerId == "") {
        Toast("Please Select Account Head !", 'Message', 'error');
        return false;
    }
    if (FromDate >= ToDate) {
        Toast("To Date Must Be Greater Than From Date*", "Message", "error");
        flag = 1;
        return false;
    }
    else {
        var type = $("#ReportBySearch").val();
        $(".ReportDNone").show();
        FormList();
    }
});

$('#AccHeadSearch').on('input', function () {
    var flag = 0;
    if ($("#GroupSearch").val() == "0") {
        Toast("Please Select Account Group !", 'Message', 'error');
        return false;
    }
});

//FUNCTION FOR FILL PROFIT LOSS STATEMENT
function FormList() {
    try {
        const dataString = {};
        dataString.FromDate = $("#SearchDateFrom").val();
        dataString.ToDate = $("#SearchDateTo").val();
        dataString.SearchOnDate = $("#SearchOnDate").val();
        dataString.BillStatusSearch = $("#BillStatusSearch").val();
        dataString.LedgerUid = $("#HiddenLedgerId").val();
        ShowLoader();
        AjaxSubmission(JSON.stringify(dataString), "/Master/PaymentReminder/FormList", $('input[name=__RequestVerificationToken]').val()).done(function (result) {
            let obj = result;
            console.log(obj);
            if (obj.status == true) {
                if (obj.responsecode == '100') {
                    BindFormTable(obj.data.Table);
                }
                else
                    Toast(RetrieveMessage(obj.responsecode), "Message", "error");
            }
            else
                window.location.href = '/ClientLogin/ClientLogin';
            HideLoader();
        }).fail(function (result) {
            console.log(result.Message);
            HideLoader();
        });
    }
    catch (e) {
        console.log(e.message);
        HideLoader();
    }
}

//FUNCTION FOR BIND LETTER LIST TABLE
function BindFormTable(Result) {
    debugger
    $("#tbl_PaymentReminder tbody tr").remove();
    if (Result.length == 0) {
        $(".ShowPDF").hide();
        tr = $('<tr/>');
        tr.append("<td class='text-center' colspan='8'>NO RESULTS FOUND</td>");
        $("#tbl_PaymentReminder tbody").append(tr);
    }
    else {
        $(".ShowPDF").show();
        for (i = 0; i < Result.length; i++) {
            tr = $('<tr/>');
            /* tr.append("<td class='text-center ' >" + (i + 1) + "</td>")*/
            if (Result[i].type == 0) {
                tr.append("<td class='text-end ' colspan='7'><b>" + Result[i].BillNo + "</b></td>")
                if (Result[i].BalanceAmount > 0) {
                    tr.append("<td class='text-end ' >" + Result[i].BalanceAmount.toFixed(2) + " Dr</td>")
                }
                else {
                    tr.append("<td class='text-end ' >" + Result[i].BalanceAmount.toFixed(2) + " Cr</td>")
                }

            }
            else if (Result[i].type == 1) {
                tr.append("<td class='text-center ' >" + Result[i].BillNo + "</td>")
                tr.append("<td class='text-center ' >" + Result[i].BillDate + "</td>")
                tr.append("<td class='text-center ' >" + Result[i].Particular + "</td>")
                tr.append("<td class='text-end ' >" + Result[i].BillAmount.toFixed(2) + "</td>")
                tr.append("<td class='text-center ' >" + Result[i].PayMentDetails + "</td>")
                tr.append("<td class='text-center ' >" + HandleNullTextValue(Result[i].ChequeNo) + "</td>")

                if (Result[i].Amount != null) {
                    tr.append("<td class='text-end ' >" + Result[i].Amount + "</td>")
                }
                else {
                    tr.append("<td class='text-end ' ></td>")
                }
                if ((Result[i].BalanceAmount != null) && (Result[i].BalanceAmount != 0)) {
                    tr.append("<td class='text-end ' >" + Result[i].BalanceAmount.toFixed(2) + "</td>")
                }
                else {
                    tr.append("<td class='text-end ' ></td>")
                }
            }
            else if (Result[i].type == 2) {
                tr.append("<td class='text-left '  colspan='7'><b>" + Result[i].BillNo + "</b></td>")
                //tr.append("<td class='text-center ' >" + Result[i].BillDate + "</td>")
                //tr.append("<td class='text-center ' >" + Result[i].Particular + "</td>")
                //tr.append("<td class='text-end ' >" + HandleNullTextValue(Result[i].BillAmount) + "</td>")
                //tr.append("<td class='text-center ' >" + Result[i].PayMentDetails + "</td>")
                //tr.append("<td class='text-center ' >" + HandleNullTextValue(Result[i].ChequeNo) + "</td>")

                //if (Result[i].Amount != null) {
                //    tr.append("<td class='text-end ' >" + Result[i].Amount.toFixed(2) + "</td>")
                //}
                //else {
                //    tr.append("<td class='text-end ' ></td>")
                //}
                //if ((Result[i].BalanceAmount != null) && (Result[i].BalanceAmount != 0)) {
                //    tr.append("<td class='text-end ' >" + Result[i].BalanceAmount.toFixed(2) + "</td>")
                //}
                //else {
                //    tr.append("<td class='text-end ' ></td>")
                //}
            }
            else if (Result[i].type == 3) {
                tr.append("<td class='text-center ' >" + Result[i].BillNo + "</td>")
                tr.append("<td class='text-center ' >" + Result[i].BillDate + "</td>")
                tr.append("<td class='text-center ' >" + Result[i].Particular + "</td>")
                tr.append("<td class='text-end ' >" + Result[i].BillAmount.toFixed(2) + "</td>")
                tr.append("<td class='text-center ' >" + Result[i].PayMentDetails + "</td>")
                tr.append("<td class='text-center ' >" + HandleNullTextValue(Result[i].ChequeNo) + "</td>")

                if (Result[i].Amount != null) {
                    tr.append("<td class='text-end ' >" + Result[i].Amount.toFixed(2) + "</td>")
                }
                else {
                    tr.append("<td class='text-end ' ></td>")
                }
                if ((Result[i].BalanceAmount != null) && (Result[i].BalanceAmount != 0)) {
                    tr.append("<td class='text-end ' >" + Result[i].BalanceAmount.toFixed(2) + "</td>")
                }
                else {
                    tr.append("<td class='text-end ' ></td>")
                }
            }
            else if (Result[i].type == 4) {
                tr.append("<td class='text-end ' colspan='7'><b>" + Result[i].BillNo + "</b></td>")
                if (Result[i].BalanceAmount != null) {
                    tr.append("<td class='text-end ' ><b>" + Result[i].BalanceAmount.toFixed(2) + "</b></td>")
                }
                else {
                    tr.append("<td class='text-end ' ></td>")
                }
            }
            $("#tbl_PaymentReminder tbody").append(tr);
        }
    }
}


//FUNCTION FOR TINYMCE EDITIOR
function LoadTinyMCE() {
    tinymce.init({
        selector: ".tinymce",
        branding: false,
        theme: "modern",
        skin: "lightgray",
        width: "100%",
        height: 200,
        statubar: true,
        plugins: [
            "advlist autolink link image lists charmap print preview hr anchor pagebreak",
            "searchreplace wordcount visualblocks visualchars code fullscreen insertdatetime media nonbreaking",
            "save table contextmenu directionality emoticons template paste textcolor"
        ],
        toolbar: "insertfile undo redo | styleselect | bold italic | alignleft aligncenter alignright alignjustify | bullist numlist outdent indent | link | fontsizeselect | fontselect | image | print preview media fullpage | forecolor backcolor emoticons ",
        style_formats: [
            {
                title: "Headers", items: [
                    { title: "Header 1", format: "h1" },
                    { title: "Header 2", format: "h2" },
                    { title: "Header 3", format: "h3" },
                    { title: "Header 4", format: "h4" },
                    { title: "Header 5", format: "h5" },
                    { title: "Header 6", format: "h6" }
                ]
            },
            {
                title: "Inline", items: [
                    { title: "Bold", icon: "bold", format: "bold" },
                    { title: "Italic", icon: "italic", format: "italic" },
                    { title: "Underline", icon: "underline", format: "underline" },
                    { title: "Strikethrough", icon: "strikethrough", format: "strikethrough" },
                    { title: "Superscript", icon: "superscript", format: "superscript" },
                    { title: "Subscript", icon: "subscript", format: "subscript" },
                    { title: "Code", icon: "code", format: "code" }
                ]
            },
            {
                title: "Blocks", items: [
                    { title: "Paragraph", format: "p" },
                    { title: "Blockquote", format: "blockquote" },
                    { title: "Div", format: "div" },
                    { title: "Pre", format: "pre" }
                ]
            },
            {
                title: "Alignment", items: [
                    { title: "Left", icon: "alignleft", format: "alignleft" },
                    { title: "Center", icon: "aligncenter", format: "aligncenter" },
                    { title: "Right", icon: "alignright", format: "alignright" },
                    { title: "Justify", icon: "alignjustify", format: "alignjustify" }
                ]
            }
        ],
    });
}



$("#PaymentReminderPDF").click(function () {
    try {
        const dataString = {};
        dataString.FromDate = $("#SearchDateFrom").val();
        dataString.ToDate = $("#SearchDateTo").val();
        dataString.SearchOnDate = $("#SearchOnDate").val();
        dataString.BillStatusSearch = $("#BillStatusSearch").val();
        dataString.LedgerUid = $("#HiddenLedgerId").val();
        ShowLoader();
        AjaxSubmission(JSON.stringify(dataString), '/Master/PaymentReminder/GetReportPdf', $('input[name=__RequestVerificationToken]').val()).done(function (result) {
            let obj = result;
            if (obj.status == true) {
                if (obj.responsecode == '100') {
                    window.open($("#MyReport").attr('href'), '_blank');
                }
                else if (obj.responsecode == '703') {
                    Toast(obj.error, "Message", "error");
                }
                else {
                    Toast(RetrieveMessage(obj.responsecode), "Message", "error");
                }

            } else
                window.location.href = '/ClientLogin/ClientLogin';
            HideLoader();
        }).fail(function (result) {
            console.log(result.Message);
            HideLoader();
        });
    }
    catch (e) {
        console.log(e.message);
    }
});



function PaymentReportEmailClick() {
    try {
        const dataString = {};
        dataString.FromDate = $("#SearchDateFrom").val();
        dataString.ToDate = $("#SearchDateTo").val();
        dataString.SearchOnDate = $("#SearchOnDate").val();
        dataString.BillStatusSearch = $("#BillStatusSearch").val();
        dataString.LedgerUid = $("#HiddenLedgerId").val();
        ShowLoader();
        AjaxSubmission(JSON.stringify(dataString), '/Master/PaymentReminder/GetMailWithReport', $('input[name=__RequestVerificationToken]').val()).done(function (result) {
            let obj = result;
            console.log(obj);
            if (obj.status == true) {
                if (obj.responsecode == '100') {
                   
                    EmailModal.style.display = "block";
                    $("#EmailTo").val(obj.data.Table1[0].Email);
                    $("#EmailCC").val(obj.data.Table1[0].CCEmail);
                    $("#EmailLetterName").val(obj.data.Table1[0].LetterName);
                    $("#AttachFileName").text(obj.data.Table2[0].FileName);
                    $("#AttachFileName").attr("href", obj.data.Table2[0].FilePath);
                    $("#AttachedFilePath").val(obj.data.Table2[0].AttachmentFilePath);
                    $("#RefId").val(obj.data.Table1[0].LedgerId);
                    $("#SendToName").val(obj.data.Table1[0].SendTo);
                    $("#RefName").val('PmntReminderReport');

                    BindTemplateName('AllTemplate', 'Email');
                    FillTemplateDataInTincyMce(parseInt($("#HiddenLedgerId").val()), 'PaymentReminder', null, 'Email', 'PaymentReminder');

                }
                else if (obj.responsecode == '703') {
                    Toast(obj.error, "Message", "error");
                }
                else {
                    Toast(RetrieveMessage(obj.responsecode), "Message", "error");
                }

            } else
                window.location.href = '/ClientLogin/ClientLogin';
            HideLoader();
        }).fail(function (result) {
            console.log(result.Message);
            HideLoader();
        });
    }
    catch (e) {
        HideLoader();
        console.log(e.message);
    }
}



//FUNCTION FOR CHANGE TEMPLATE DETAILS
function TemplateChange() {
    tinymce.get("EmailBody").setContent('');
    $('#Subject').val('');
    if ($('#AllTemplate').val() != null && $('#AllTemplate') != undefined) {
        if ($('#AllTemplate').val() != 0)
            FillTemplateDataInTincyMce(parseInt($("#HiddenLedgerId").val()), 'PaymentReminder', $('#AllTemplate').val(), 'Email', 'PaymentReminder');
    }
}