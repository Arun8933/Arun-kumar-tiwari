﻿$("#Search").click(function () {
    var flag = 0;
    let JobNo = $("#JobNo").val();
    if (JobNo == "") {
        Toast("Please Enter JobNo", "Message", "error");
        flag = 1;
        return false;
    }
    GetDeclaration();
});

$(document).ready(function () {
    $("#SubJobNo").focus();
});

$("#ReportTypeSearch").select2({
    width: '100%'
});

function GetDeclaration() {
    try {
        const dataString = {};
        //dataString.SubJobNo = $("#SubJobNo").val();
        dataString.JobNo = $("#JobNo").val();
        dataString.ReportTypeSearch = $("#ReportTypeSearch").val();
        ShowLoader();

        AjaxSubmission(JSON.stringify(dataString), '/Master/Declaration/GetDeclaration', $('input[name=__RequestVerificationToken]').val())
            .done(function (result) {

                let obj = result;
                console.log(obj);
                if (obj.status == true) {
                    if (obj.responsecode == '100') {
                        if (obj.data.Table.length == 1) {
                            window.open($("#MyReport").attr('href'), '_blank');
                        }
                        else {
                            Toast("No Records Found", "Message", "error");
                        }
                    }
                    else {
                        Toast(obj.responsecode, "Message", "error");
                    }
                    HideLoader();
                }
                else {
                    window.location.href = '/ClientLogin/ClientLogin';
                    HideLoader();
                }

            })
            .fail(function (result) {
                console.log(result.Message);
                HideLoader();
            });
    } catch (e) {
        console.log(e.message);
        HideLoader();
    }
}

