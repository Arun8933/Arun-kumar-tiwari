﻿
var State_code_selected = "";
var Firstcolumn = "";
var Ercount = 0;
var Action = "";

$(document).ready(function () {
    Firstcolumn = "Branch_Name";
    ShowLoader();
    localStorage.setItem('PageName', 'Branch Master');
    FillPageSizeList('ddlPageSize', FormList);
    GetCompanyName();
    FillCountryList('Country', 'Company');
    LoadTinyMCE();
    FillIceGateId('ICEGATEUserId', '----Select----');

    FillInvApiId('EInvApiId', '----Select----');

    if ($('#SearchStatus').val() == 2) {
        $("#SearchBranchId").focus();
    }

    $("#SearchStatus").select2({
        width: '100%'
    });
    $("#Country").select2({
        width: '100%'
    });
    $("#State").select2({
        width: '100%'
    });
    $('#SearchBranchId').focus();
    HideLoader();
});
//Image preview code 
function ImagePreviewStampModel(e) {
    $("#stamp-model").modal('show');
    var SourceFile = $(e).prop('src');
    $("#PreviewImage").attr("src", SourceFile);
}

$("#chktmp").click(function () {
    CheckCompanySelect();
});

$(document).on("click", ".pagination .page", function () {
    FormList(($(this).attr('page')));
});

//SET COMPANY ON CHANGE FILL COMPANY LIST IN BRANCH
$("#SetCompany").change(function () {
    $("#CompanyId").val($("#SetCompany").val());
});

//CHOOSE COMPANY ON CHANGE FILL COMPANY LIST IN BRANCH
$("#ChooseCompany").change(function () {
    var company_id = localStorage.getItem("company_id");
    $("#CompanyId").val(company_id);
});
$("#ddlPageSize").change(function () {
    FormList(1);
});

//SERACH CLICK
$("#FormSearch").click(function () {
    FormList(1);
});

//ADD BRANCH BUTTON
$("#FormAdd").click(function () {

    try {

        RemoveAllError('Branch');
        ValidateAllFieldNewTest('Branch');

        if (Ercount == 0) {
            if ($("#Country").val() == "0") {
                Toast(RetrieveMessage(707), 'Message', 'error');
                return;
            }

            if ($("#State").val() == "0") {
                Toast(RetrieveMessage(708), 'Message', 'error');
                return;
            }
            FormAdd();
        }
    }
    catch (ex) {
        console.log(ex.message);
    }

})

//COUNTRY ON CHANGE 
$("#Country").change(function () {
    FillStateList($("#Country").val(), 'State');
});

//UPDATE BRANCH BUTTON CLICK
$("#FormUpdate").click(function () {
    try {

        RemoveAllError('Branch');
        ValidateAllFieldNewTest('Branch');

        if (Ercount == 0) {
            if ($("#Country").val() == "0") {
                Toast(RetrieveMessage(707), 'Message', 'error');
                return;
            }

            if ($("#State").val() == "0") {
                Toast(RetrieveMessage(708), 'Message', 'error');
                return;
            }
            FormUpdate();
        }
    }
    catch (ex) {
        console.log(ex.message);
    }

})


//FUNCTION FOR GET COMPANY NAME
function GetCompanyName() {
    try {
       
        //ShowLoader();
        AjaxSubmission(null, "/Master/Branch/GetCompanyList", $('input[name=__RequestVerificationToken]').val()).done(function (data) {
            let obj = data;           
            if (obj.status == true) {
                if (obj.responsecode == '100')
                    BindDropdown(obj.data.Table, 'CompanyId', 'company_id', 'company_name', '--select--')

            }
            else {
                window.location.href = '/ClientLogin/ClientLogin';
            }
            /* FormList(1);*/
            //HideLoader();
        }).fail(function (result) {
            console.log(result.Message);
            //HideLoader();
        });
    }
    catch (e) {
        console.log(e.message);
        //HideLoader();
    }
}

//FUNCTION FOR TINYMCE EDITIOR
function LoadTinyMCE() {
    tinymce.init({
        /* replace textarea having class .tinymce with tinymce editor */
        selector: ".tinymce",
        branding: false,
        /* theme of the editor */
        theme: "modern",
        skin: "lightgray",

        /* width and height of the editor */
        width: "100%",
        height: 200,

        /* display statusbar */
        statubar: true,

        /* plugin */
        plugins: [
            "advlist autolink link image lists charmap print preview hr anchor pagebreak",
            "searchreplace wordcount visualblocks visualchars code fullscreen insertdatetime media nonbreaking",
            "save table contextmenu directionality emoticons template paste textcolor"
        ],

        /* toolbar */
        toolbar: "insertfile undo redo | styleselect | bold italic | alignleft aligncenter alignright alignjustify | bullist numlist outdent indent | link | fontsizeselect | fontselect | image | print preview media fullpage | forecolor backcolor emoticons ",

        /* style */
        style_formats: [
            {
                title: "Headers", items: [
                    { title: "Header 1", format: "h1" },
                    { title: "Header 2", format: "h2" },
                    { title: "Header 3", format: "h3" },
                    { title: "Header 4", format: "h4" },
                    { title: "Header 5", format: "h5" },
                    { title: "Header 6", format: "h6" }
                ]
            },
            {
                title: "Inline", items: [
                    { title: "Bold", icon: "bold", format: "bold" },
                    { title: "Italic", icon: "italic", format: "italic" },
                    { title: "Underline", icon: "underline", format: "underline" },
                    { title: "Strikethrough", icon: "strikethrough", format: "strikethrough" },
                    { title: "Superscript", icon: "superscript", format: "superscript" },
                    { title: "Subscript", icon: "subscript", format: "subscript" },
                    { title: "Code", icon: "code", format: "code" }
                ]
            },
            {
                title: "Blocks", items: [
                    { title: "Paragraph", format: "p" },
                    { title: "Blockquote", format: "blockquote" },
                    { title: "Div", format: "div" },
                    { title: "Pre", format: "pre" }
                ]
            },
            {
                title: "Alignment", items: [
                    { title: "Left", icon: "alignleft", format: "alignleft" },
                    { title: "Center", icon: "aligncenter", format: "aligncenter" },
                    { title: "Right", icon: "alignright", format: "alignright" },
                    { title: "Justify", icon: "alignjustify", format: "alignjustify" }
                ]
            }
        ],
    });
}

//FUNCTION FOR BIND BRANCH TABLE
function BindFormTable(Result, SerialNo) {
    $("#TblBranch tbody tr").remove();

    if (Result.length == 0) {
        tr = $('<tr/>');
        tr.append("<td class='text-center' colspan='8'>NO RESULTS FOUND</td>");
        $("#TblBranch tbody").append(tr);
    }
    else {
        for (i = 0; i < Result.length; i++) {
            if (Result[i].IsActive == "Inactive")
                tr = $(' <tr style="background-color:#fdd2d2;"/>');
            else
                tr = $('<tr/>');

            tr.append("<td class='text-center'><button type='button' onclick='FormEdit(\"" + Result[i].BranchUid + "\");' class='common-btn common-btn-sm'><i class='fa-solid fa-pen-to-square'></i></button ><button type='button' onclick='FormDelete(\"" + Result[i].BranchUid + "\");' class='common-btn common-btn-sm ms-1'> <i class='fa-regular fa-trash-can'></i></button ></td > ");
            tr.append("<td class='text-left'>" + SerialNo + "</td>");
            tr.append("<td class='text-left'>" + Result[i].BranchUid + "</td>");
            tr.append("<td class='text-center'><a href='javascript:void(0)' class='text-decoration-none ' style='color: black !important;' onclick='FormEdit(\"" + Result[i].BranchUid + "\");'>" + Result[i].BranchName + "</a></td>");

            tr.append("<td class='text-center'>" + Result[i].BranchCode + "</td>");
            tr.append("<td class='text-center'>" + HandleNullTextValue(Result[i].EmailId) + "</td>");
            tr.append("<td class='text-center'>" + HandleNullTextValue(Result[i].PrimaryPhone) + "</td>");
            tr.append("<td class='text-center'>" + Result[i].IsActive + "</td>");


            SerialNo++;

            $("#TblBranch tbody").append(tr);

        }

    }
}

//FUNCTION FILL BRANCH LIST
function FormList(pageindex) {
    try {
        const dataString = {};
        dataString.PageSize = $("#ddlPageSize").val();
        dataString.PageIndex = pageindex;
        dataString.BranchId = $("#SearchBranchId").val().trim();
        dataString.BranchName = $("#SearchBranchName").val().trim();
        dataString.Status = $("#SearchStatus").val();
        dataString.OrderBy = $("#sort-column").val().trim() + " " + $("#sort-type").val().trim();
        //ShowLoader();
        AjaxSubmission(JSON.stringify(dataString), "/Branch/FormList", $('input[name=__RequestVerificationToken]').val()).done(function (result) {

            let obj = result;

            if (obj.status == true) {
                if (obj.responsecode == '100') {

                    var ser = ((parseInt(obj.data.Table1[0].PageIndex) - 1) * parseInt(obj.data.Table1[0].PageSize)) + 1;
                    BindFormTable(obj.data.Table, ser);
                    if (obj.data.Table1 != undefined && obj.data.Table1.length > 0) {
                        $(".pagination").BindPaging({
                            ActiveCssClass: "current",
                            PagerCssClass: "pager",
                            PageIndex: parseInt(obj.data.Table1[0].PageIndex),
                            PageSize: parseInt(obj.data.Table1[0].PageSize),
                            RecordCount: parseInt(obj.data.Table1[0].count)
                        });
                    }

                }
                else {
                    Toast(RetrieveMessage(obj.responsecode), "Message", "error");
                }
            }
            else {
                window.location.href = '/ClientLogin/ClientLogin';
            }
            //HideLoader();
        }).fail(function (result) {
            console.log(result.Message);
            //HideLoader();
        });
    }
    catch (e) {
        console.log(e.message);
        //HideLoader();
    }
}

//FUNCTION ADD BRANCH DETAILS
function FormAdd() {
    try {

        var editorContent_invoiceadd = tinyMCE.get('InvoiceAddress').getContent();
        var msgcontent = window.btoa(editorContent_invoiceadd);
        $('[name="InvoiceAddress"]').val(msgcontent);

        var editorContent_invoiceadd1 = tinyMCE.get('InvoiceRemarks').getContent();
        var msgcontent1 = window.btoa(editorContent_invoiceadd1);
        $('[name="InvoiceRemarks"]').val(msgcontent1);

        //var editorContent_invoiceadd2 = tinyMCE.get('SaleOrderRemarks').getContent();
        //var msgcontent2 = window.btoa(editorContent_invoiceadd2);
        //$('[name="SaleOrderRemarks"]').val(msgcontent2);

        var form = $('#myform')[0];
        var mydata = new FormData(form);

        ShowLoader();
        AjaxSubmissionformdata(mydata, "/Master/Branch/FormAdd", $('[name="__RequestVerificationToken"]').val()).done(function (result) {
            let obj = result;
            if (obj.status == true) {
                if (obj.responsecode == '101') {
                    Toast(RetrieveMessage(obj.responsecode), "Message", "success");
                    setTimeout(FormList(1), 500);
                    $("#FormAdd").hide();
                    $("#FormUpdate").show();
                    $("#FormReset").show();
                    $("#Branch-tab").html("Edit Branch");
                    $("#Timestamp").val(obj.data.Table[0].Timestamp);
                    $("#BranchId").val(obj.data.Table[0].BranchUid);
                }
                else if (obj.responsecode == '1004') {
                    Toast(RetrieveMessage(obj.responsecode), "Message", "success");
                    setTimeout(FormList(1), 500);
                    TabHide();
                    ResetForm();
                }
                else {
                    Toast(RetrieveMessage(obj.responsecode), "Message", "error");
                }
            }
            else {
                window.location.href = '/ClientLogin/ClientLogin';
            }
            HideLoader();
        }).fail(function (result) {
            console.log(result.Message);
            HideLoader();
        });
    }
    catch (ex) {
        HideLoader();
        console.log(ex.message);
    }
}
//FUNCTION TO EDIT BRANCH
function FormEdit(e) {
    try {
        const datastring = {};
        datastring.BranchId = e;
        ShowLoader();
        AjaxSubmission(JSON.stringify(datastring), "/Master/Branch/FormEdit", $('[name="__RequestVerificationToken"]').val()).done(function (data) {
            let obj = data;

            if (obj.status == true) {
                if (obj.responsecode == '100') {
                    TabShow();
                   
                    if (obj.data.Table[0].SignImgPath != null) {
                        $("#SignatureTmpImageFile").val(obj.data.Table[0].SignImgPath);
                        $("#SignatureImagePreview").css("display", "block");
                        $("#SignatureImagePreview").attr('src', obj.data.Table[0].SignImgPath);
                    }
                   
                    $("#BranchId").val(obj.data.Table[0].BranchUid);
                    $("#Timestamp").val(obj.data.Table[0].Timestamp);

                    $("#CompanyId").val(obj.data.Table[0].CompanyUid);
                    $("#CompanyDescription").val(obj.data.Table[0].CompanyDescription);

                    if ($("#ICEGATEUserId option[value='" + obj.data.Table[0].ICEGATEUserId + "']").length > 0)
                        $('#ICEGATEUserId').val(obj.data.Table[0].ICEGATEUserId);

                    if ($("#EInvApiId option[value='" + obj.data.Table[0].EInvoiceApiId + "']").length > 0)
                        $('#EInvApiId').val(obj.data.Table[0].EInvoiceApiId);

                    $("#BranchName").val(obj.data.Table[0].BranchName);
                    $("#BranchCode").val(obj.data.Table[0].BranchCode);

                    $("#DefaultBranch").prop("checked", obj.data.Table[0].IsDefault);

                    $("#Email").val(obj.data.Table[0].EmailId);
                    $("#PrimaryPhone").val(obj.data.Table[0].PrimaryPhone);
                    $("#AltPhone").val(obj.data.Table[0].AltPhone);
                    $("#Gstin").val(obj.data.Table[0].Gstin);
                    $("#PanNo").val(obj.data.Table[0].PanNo);
                    $("#ChaNo").val(obj.data.Table[0].ChaNo);
                    $("#SenderId").val(obj.data.Table[0].SenderId);
                    $("#ReceiverId").val(obj.data.Table[0].ReciverId);
                    $("#BankName").val(obj.data.Table[0].BankName);
                    $("#BankAccNo").val(obj.data.Table[0].BankAccNo);
                    $("#BankBranch").val(obj.data.Table[0].BankBranch);
                    $("#BankIfscCode").val(obj.data.Table[0].BankIfscCode);

                    $("#Address").val(obj.data.Table[0].BranchAddress);

                    StateCodeSelected = obj.data.Table[0].StateCode;
                    $("#Country").val(obj.data.Table[0].CountryCode).trigger("change");


                    $("#City").val(obj.data.Table[0].City);
                    $("#PinCode").val(obj.data.Table[0].PinCode);
                    $("#EInvUserName").val(obj.data.Table[0].EInvUserName);
                    $("#EInvEmailId").val(obj.data.Table[0].EInvEmailId);
                    $("#EInvClientId").val(obj.data.Table[0].EInvClientId);
                    $("#EInvClientSecret").val(obj.data.Table[0].EInvClientSecret);



                    tinymce.get("InvoiceAddress").setContent(obj.data.Table[0].InvoiceAddress);

                    $("#Signatory").val(obj.data.Table[0].Signatory);
                    if (obj.data.Table[0].IsActive == "1")
                        $("#Status").val("1");
                    else
                        $("#Status").val("0");


                    tinymce.get("InvoiceRemarks").setContent(obj.data.Table[0].InvoiceRemarks);
                    //tinymce.get("SaleOrderRemarks").setContent(obj.data.Table[0].saleorder_remarks);

                } else {
                    Toast(RetrieveMessage(obj.responsecode), "Message", "error");
                }
            }
            else {
                window.location.href = '/ClientLogin/ClientLogin';
            }
            HideLoader();
        }).fail(function (data) {
            console.log(data.Message);
            HideLoader();
        });

    }
    catch (e) {
        console.log(e.message);
        HideLoader();
    }
}
//FUNCTION TO UPDATE BRANCH
function FormUpdate() {
    try {
        var editorContent_invoiceadd = tinyMCE.get('InvoiceAddress').getContent();
        var msgcontent = window.btoa(editorContent_invoiceadd);
        $('[name="InvoiceAddress"]').val(msgcontent);

        var editorContent_invoiceadd1 = tinyMCE.get('InvoiceRemarks').getContent();
        var msgcontent1 = window.btoa(editorContent_invoiceadd1);
        $('[name="InvoiceRemarks"]').val(msgcontent1);

        var form = $('#myform')[0];
        var mydata = new FormData(form);

        ShowLoader();
        AjaxSubmissionformdata(mydata, "/Master/Branch/FormUpdate", $('[name="__RequestVerificationToken"]').val()).done(function (result) {
            let obj = result;
            if (obj.status == true) {
                if (obj.responsecode == '107') {
                    Toast(RetrieveMessage(obj.responsecode), "Message", "success");
                    setTimeout(FormList(1), 500);
                    $("#BranchId").val(obj.data.Table[0].BranchUid);
                    $("#Timestamp").val(obj.data.Table[0].Timestamp);
                    //ResetForm();
                    //TabHide();
                }
                else if (obj.responsecode == '1004') {
                    Toast(RetrieveMessage(obj.responsecode), "Message", "success");
                    setTimeout(FormList(1), 500);
                    $("#BranchId").val(obj.data.Table[0].BranchUid);
                    $("#Timestamp").val(obj.data.Table[0].Timestamp);
                    //ResetForm();
                    //TabHide();
                }
                else {
                    Toast(RetrieveMessage(obj.responsecode), "Message", "error");
                }
            }
            else {
                window.location.href = '/ClientLogin/ClientLogin';
            }
            HideLoader();
        }).fail(function (result) {
            console.log(result.Message);
            HideLoader();

        });
    }
    catch (ex) {
        console.log(ex.message);
        HideLoader();
    }
}

//FUNCTION TO DELETE BRANCH
function FormDelete(e) {
    try {
        $.confirm({
            title: '',
            content: 'Are You Sure Want To Delete ?',
            type: 'red',
            boxWidth: '300px',
            useBootstrap: false,
            columnClass: 'small',
            containerFluid: true,
            typeAnimated: true,
            buttons: {
                tryAgain: {
                    text: 'Confirm',
                    btnClass: 'btn-red',
                    action: function () {

                        const datastring = {};
                        datastring.BranchId = parseInt(e);
                        ShowLoader();
                        AjaxSubmission(JSON.stringify(datastring), "/Branch/FormDelete", $('[name="__RequestVerificationToken"]').val()).done(function (data) {
                            let obj = data;
                            if (obj.status == true) {
                                if (obj.responsecode == '102') {
                                    Toast(RetrieveMessage(obj.responsecode), "Message", "success");
                                    setTimeout(FormList(1), 500);
                                }
                                else if (obj.responsecode == '602') {
                                    window.location.href = '/ClientLogin/ClientLogin';
                                }
                                else {
                                    Toast(RetrieveMessage(obj.responsecode), "Message", "error");
                                }
                            }
                            else {
                                window.location.href = 'ClientLogin/ClientLogin';
                            }
                            HideLoader();
                        }).fail(function (data) {
                            console.log(data.Message);
                            HideLoader();
                        });
                    }
                },
                close: function () {

                }
            }
        });
    }
    catch (e) {
        console.log(e.message);
        HideLoader();
    }
}

//FUNCTION FOR EXPORT DATA IN EXCEL
function FormExcel() {
    ShowLoader();
    let date = new Date();
    let NewDate = ("00" + date.getDate()).slice(-2) + "_" + ("00" + (date.getMonth() + 1)).slice(-2) + "_" + date.getFullYear() + "_" + ("00" + date.getHours()).slice(-2) + "_" + ("00" + date.getMinutes()).slice(-2) + "_" + ("00" + date.getSeconds()).slice(-2);
    let fileName = "Branch_" + NewDate + ".xlsx";

    $('#FormSearch').trigger('click');
    AjaxSubmission(null, '/Master/Branch/FormExcel', $('input[name=__RequestVerificationToken]').val()).done(function (result) {
        let obj = result;
        if (obj.status == true) {
            if (obj.responsecode == '100') {

                let bytes = Base64ToBytes(obj.data.FileData[0].Base64Data);
                let blob = new Blob([bytes], { type: "application/octetstream" });
                let isIE = false || !!document.documentMode;
                if (isIE) {
                    window.navigator.msSaveBlob(blob, fileName);
                } else {
                    let url = window.URL || window.webkitURL;
                    link = url.createObjectURL(blob);
                    let a = $("<a />");
                    a.attr("download", fileName);
                    a.attr("href", link);
                    $("body").append(a);
                    a[0].click();
                    $("body").remove(a);
                }
            }
            else if (obj.responsecode == '302')
                Toast("No Records found.", 'Message', 'success');
            else
                Toast(RetrieveMessage(obj.responsecode), 'Message', 'error');

        } else
            window.location.href = '/ClientLogin/ClientLogin';
        HideLoader();

    }).fail(function (result) {
        console.log(result.Message);
        HideLoader();
    });
}

// FUNCTION FOR TAB SHOW
function TabShow() {
    $('#Branch_list-tab').removeClass('active');
    $('#Branch-tab').addClass('active');
    $('#Branch_list').removeClass('active show');
    $('#Branch').addClass('active show');
    $("#FormAdd").hide();
    $("#FormUpdate").show();
    $("#FormReset").show();
    $("#Branch-tab").html("Edit Branch");
}

//FUNCTION FOR TAB HIDE
function TabHide() {
    $('#Branch-tab').removeClass('active');
    $('#Branch_list-tab').addClass('active ');
    $('#Branch_list').addClass('active show');
    $('#Branch').removeClass('active show');
    $("#FormAdd").show();
    $("#FormUpdate").hide();
    $("#FormReset").hide();
    $("#Branch-tab").html("Add Branch");
}
//Branch LIST TAB CLICKED
$("#Branch_list-tab").click(function () {
    ResetForm();
    RemoveAllError('Branch');
    //TabHide();
});
$(".Branch_list").click(function () {
    $("#SearchBranchId").focus();
});

//ON CLICK OF ADD BRANCH TAB
$("#Branch-tab").click(function () {
    $("#CompanyId").val($("#SetCompany").val());
})

//FUNCTION TO RESET DATA 
function ResetForm() {
    $("#FormAdd").show();
    $("#FormUpdate").hide();
    $("#FormReset").hide();
    $("#Branch-tab").html("Add Branch");


    $("#SignatureImagePreview").attr('src', '');
    $("#SignatureImagePreview").css('display', 'none');
    $("#BranchId").val("");
    $("#Timestamp").val("");

    $("#CompanyDescription").val("");
    $('#ICEGATEUserId').val(0);
    $('#EInvApiId').val(0);
    $("#BranchName").val("");
    $("#BranchCode").val("");
    $("#DefaultBranch").prop("checked", false);
    $("#Email").val("");
    $("#PhoneNo").val("");
    $("#AlternatePhoneNo").val("");
    $("#Gstin").val("");
    $("#PanNo").val("");
    $("#ChaNo").val("");
    $("#SenderId").val("");
    $("#ReceiverId").val("");
    $("#BankName").val("");
    $("#BankAccNo").val("");
    $("#BankBranch").val("");
    $("#IfscCode").val("");
    $("#Address").val("");
    FillCountryList('Country', 'Company');
    $("#State").val("0").trigger('change');
    $("#City").val("");
    $("#PinCode").val("");
    tinymce.get("InvoiceAddress").setContent("");
    $("#Signatory").val("");
    $("#Signature").val("");
    $("#Stamp").val("");
    $("#Status").val("1");
    tinymce.get("InvoiceRemarks").setContent("");
    $("#EInvUserName").val("");
    $("#EInvEmailId").val("");
    $("#EInvClientId").val("");
    $("#EInvClientSecret").val("");
    $("#EInvPassword").val("");
}
//ALLOW NUMBER WITH POINT
$(".allownumericwithdecimal").on("keypress keyup blur", function (event) {
    $(this).val($(this).val().replace(/[^0-9\|\,]/g, ''));
    if (event.which == 44) {
        return true;
    }
    if ((event.which != 46 || $(this).val().indexOf('.') != -1) && (event.which < 48 || event.which > 57)) {

        event.preventDefault();
    }
});


//FUNCTION FOR SORTING
function Sorting(obj) {

    if (Firstcolumn != "") {
        document.getElementById(Firstcolumn).innerHTML = document.getElementById(Firstcolumn).getAttribute("data-column") + " <i class='fa-solid fa-sort'></i>";
    }
    Firstcolumn = obj.id;
    var colname = $(obj).data("column");
    $("#sort-column").val(Firstcolumn);
    var sorttype = $("#sort-type").val();
    if (sorttype == "ASC") {
        $("#sort-type").val("DESC");
        $(obj).html(colname + " <i style='margin-left:10px;' class='fa-solid fa-sort-up'></i>");
    } else if (sorttype == "DESC") {
        $("#sort-type").val("ASC");
        $(obj).html(colname + " <i style='margin-left:10px;' class='fa-solid fa-sort-down'></i>");
    }
    FormList(1);
}

function FormSorting(obj) {
    if (Firstcolumn != "") {
        document.getElementById(Firstcolumn).innerHTML = document.getElementById(Firstcolumn).getAttribute("data-column") + " <i class='fa-solid fa-sort'></i>";
    }
    let cn = obj.id;
    Firstcolumn = cn;
    var colname = $(obj).data("column");
    $("#sort-column").val(cn.replaceAll("_", ""));
    var sorttype = $("#sort-type").val();

    if (sorttype == "ASC") {
        $("#sort-type").val("DESC");
        $(obj).html(colname + " <i style='margin-left:10px;' class='fa-solid fa-sort-down'></i>");
    } else if (sorttype == "DESC") {
        $("#sort-type").val("ASC");
        $(obj).html(colname + " <i style='margin-left:10px;' class='fa-solid fa-sort-up'></i>");
    }
    FormList(1);
}
//function for image preview
function ImageShowInImageTag(e, imgpre) {

    const file = e.files[0];
    if (file) {

        if (imgpre.style.display == "none")
            imgpre.style.display = "block";

        let reader = new FileReader();
        reader.onload = function (event) {
            $(imgpre).attr('src', event.target.result);
        };
        reader.readAsDataURL(file);
    }
}
$("#FormReset").click(function () {
    ResetForm();
})

document.addEventListener("keydown", function (zEvent) {
    if (zEvent.ctrlKey && zEvent.altKey && (zEvent.key == "j" || zEvent.key == "J")) {
        $('#Branch_list-tab').removeClass('active ');
        $('#Branch_list').removeClass('active show');
        $('#Branch-tab').addClass('active');
        $('#Branch').addClass('active show');
        $("#FormAdd").show();
        $("#FormUpdate").hide();
        $("#FormReset").hide();
        $("#Branch-tab").html("Add Branch");
        $('#BranchName').focus();
        ResetForm();
    }
});
