﻿var srbtn = 'up';
var DateFrom = "";
var DateTo = "";
var LedgerId = "";
var LedgerGroup = "";
var sel = "";
var Assignledtbltype = "";
var templedtimestamp = "";
var Assignledtbllength = "";

// PAGINATION BUTTON CLICKED
$(document).on("click", ".pagination .page", function () {
    FormList(($(this).attr('page')));
});
//PAGE SIZE CLICKED
$("#ddlPageSize").change(function () {
    FormList(1);
});

//DOCUMNET READY
$(document).ready(function () {
    FillBranchList('SelectBranch', false);
    FillUserList('AgentSearch');
    FillPageSizeList('ddlPageSize');
    FillGroup('GroupSearch');
    GetFinancialYearDate();

    //DATEPICKER FOR SEARCHJOBDATEFROM AND SEARCHJOBDATETO
    $('#SearchDateFrom,#SearchDateTo').datepicker({
        toolbarPlacement: "bottom",
        showButtonPanel: true,
        changeMonth: true,
        changeYear: true,
        dateFormat: 'dd/mm/yy',
        onClose: function () {
            if ($('#SearchDateFrom').val().length == 10 || $('#SearchDateTo').val().length == 10)
                CompareSearchDate($('#SearchDateFrom').val(), $('#SearchDateTo').val(), '');
        }
    });


    //FOR TODAY DATE
    jQuery.datepicker._gotoToday = function (id) {
        var today = new Date();
        var dateRef = jQuery("<td><a>" + today.getDate() + "</a></td>");
        this._selectDay(id, today.getMonth(), today.getFullYear(), dateRef);
    };
    LoadTinyMCE();
});

//SEARCH ARROW UP/DOWN
$("#Arrow").click(function () {
    if (srbtn == 'up') {
        $("#icn").html("<i class='fa-solid fa-angle-down'></i>");
        srbtn = 'down';
    } else {
        $("#icn").html("<i class='fa-solid fa-angle-up'></i>");
        srbtn = 'up';
    }
});


//FUNCTION FOR GET FINANCIAL YEAR DATE
function GetFinancialYearDate() {
    try {
        AjaxSubmission(null, '/_Layout/GetFinancialYearDate', $('[name="__RequestVerificationToken"]').val()).done(function (result) {
            let obj = result;
            if (obj.status == true) {
                if (obj.responsecode == '100') {
                    $("#SearchDateFrom").val(obj.data.Table[0].finyr_start_date);
                    $("#SearchDateTo").val(obj.data.Table[0].finyr_end_date);
                }
            }
            else
                window.location.href = '/ClientLogin/ClientLogin';
            HideLoader();
        }).fail(function (result) {
            HideLoader();
            console.log(result.message);
        });
        HideLoader();
    }
    catch (e) {
        HideLoader();
        console.log(e.message);
    }
}

$("#BalanceTypeSearch").select2({
    width: '100%'
});
$("#SelectBranch").select2({
    width: '100%'
});
$("#AgentSearch").select2({
    width: '100%'
});
$("#ReportTypeSearch").select2({
    width: '100%'
});
$("#GroupSearch").select2({
    width: '100%'
});

$("#GroupSearch").change(function () {
    var type = $("#ReportTypeSearch").val();
    if (type == "0") {
        $(".ReportDNone").show();
        $("#tbl_GroupSummary").show();
        $("#tbl_GroupSummaryMonthWise").hide();
    }
    else if (type == "1") {
        $(".ReportDNone").show();
        $("#tbl_GroupSummary").hide();
        $("#tbl_GroupSummaryMonthWise").show();
    }
    $("#FormSearch").trigger('click');
});

$("#AccHeadSearch").autocomplete({
    source: function (request, response) {
        $.ajax({
            type: 'POST',
            url: "/Master/GroupSummary/SearchAccHeadNameList",
            dataType: "json",
            async: false,
            data: {
                AccDescription: request.term, GroupUid: $("#GroupSearch").val()
            },
            success: function (result) {
                response($.map(result.data.Table, function (LedgerName) {
                    return {
                        label: LedgerName.AccHead,
                        value: LedgerName.AccHead,
                        id: LedgerName.ledgeruid,
                        LedgerGroup: LedgerName.LedgerGroup,
                    }
                }));
            },
            error: function (response) {
                console.log(response.responseText);
            }
        });
    },
    autoFocus: true,
    minLength: 1,
    selectFirst: true,
    selectOnly: true,
    select: function (e, i) {
        $("#HiddenLedgerId").val(i.item.id);
    },

});

$("#FormSearch").click(function () {
    var FromDate = $("#SearchDateFrom").val();
    var ToDate = $("#SearchDateTo").val();
    if ($('#SearchDateFrom').val().length == 10 || $('#SearchDateTo').val().length == 10)
        CompareSearchDate($('#SearchDateFrom').val(), $('#SearchDateTo').val(), '');
    var flag = 0;
    if ($("#GroupSearch").val() == "0") {
        Toast("Please Select Account Group !", 'Message', 'error');
        return false;
    }
    if (FromDate >= ToDate) {
        Toast("To Date Must Be Greater Than From Date*", "Message", "error");
        flag = 1;
        return false;
    }
    else {
        var type = $("#ReportTypeSearch").val();
        if (type == "0") {
            $(".ReportDNone").show();
            $("#tbl_GroupSummary").show();
            $("#tbl_GroupSummaryMonthWise").hide();
            $("#tbl_GroupSummaryDetailedMonthWise").hide();
        }
        else if (type == "1") {
            $(".ReportDNone").show();
            $("#tbl_GroupSummary").hide();
            $("#tbl_GroupSummaryMonthWise").show();
        }
        FormList();
    }
});
//LETTER MASTER LIST FUNCTION
function FormList(pageindex) {
    try {
        LedgerId = parseInt($("#HiddenLedgerId").val());
        LedgerGroup = parseInt($("#GroupSearch").val());
        DateFrom = $("#SearchDateFrom").val();
        DateTo = $("#SearchDateTo").val();
        const dataString = {};
        dataString.PageSize = $("#ddlPageSize").val();
        dataString.PageIndex = pageindex;
        dataString.DateFrom = DateFrom;
        dataString.DateTo = DateTo;
        dataString.GroupUid = parseInt($("#GroupSearch").val());
        dataString.ReportType = $("#ReportTypeSearch").val();
        dataString.LedgerUid = LedgerId;
        dataString.BranchUid = parseInt($("#SelectBranch").val());
        dataString.BalanceType = $("#BalanceTypeSearch").val();
        dataString.AgentUid = $("#AgentSearch").val();
        dataString.WithBalance = $("#WithBalance").is(':checked') == true ? 1 : 0;
        dataString.ShowImportant = $("#ShowImp").is(':checked') == true ? 1 : 0;
        dataString.SendEmail = false;
        dataString.OrderBy = $("#sort-column").val().trim() + " " + $("#sort-type").val().trim();
        ShowLoader();
        AjaxSubmission(JSON.stringify(dataString), "/Master/GroupSummary/FormList", $('input[name=__RequestVerificationToken]').val()).done(function (result) {
            let obj = result;
            if (obj.status == true) {

                if (obj.responsecode == '100') {
                    if (obj.data.Table2[0].ReportType == "0") {
                        var ser = ((parseInt(obj.data.Table1[0].PageIndex) - 1) * parseInt(obj.data.Table1[0].PageSize)) + 1;
                        BindFormTable(obj.data.Table, ser, obj.data.Table2[0].ReportType);
                    }
                    else {
                        var ser = ((parseInt(obj.data.Table[0].PageIndex) - 1) * parseInt(obj.data.Table[0].PageSize)) + 1;
                        BindFormTable(obj.data.Table1, ser, obj.data.Table2[0].ReportType);
                    }
                    if (obj.data.Table1 != undefined && obj.data.Table1.length > 0) {
                        if (obj.data.Table2[0].ReportType == "0") {
                            $(".pagination").BindPaging({
                                ActiveCssClass: "current",
                                PagerCssClass: "pager",
                                PageIndex: parseInt(obj.data.Table1[0].PageIndex),
                                PageSize: parseInt(obj.data.Table1[0].PageSize),
                                RecordCount: parseInt(obj.data.Table1[0].count)
                            });
                        }
                        else {
                            $(".pagination").BindPaging({
                                ActiveCssClass: "current",
                                PagerCssClass: "pager",
                                PageIndex: parseInt(obj.data.Table[0].PageIndex),
                                PageSize: parseInt(obj.data.Table[0].PageSize),
                                RecordCount: parseInt(obj.data.Table[0].count)
                            });
                        }
                        if (obj.data.Table2[0].ReportType == 0) {
                            $(".DebitCreditChart").show();
                            $(".DebitCreditMonth").hide();
                            ShowCurrentBalanceByChart();
                            ShowCreditBalanceByChart();
                        }
                        if (obj.data.Table2[0].ReportType == 1) {
                            DebitCreditBalanceByChartMonthWise();
                            $(".DebitCreditChart").hide();
                            $(".DebitCreditMonth").show();
                        }
                    }
                }
                else {
                    Toast(RetrieveMessage(obj.responsecode), "Message", "error");
                }
            }
            else {

                window.location.href = '/ClientLogin/ClientLogin';
            }
            HideLoader();
        }).fail(function (result) {
            console.log(result.Message);
            HideLoader();
        });
    }
    catch (e) {
        console.log(e.message);
        HideLoader();
    }
}

//FUNCTION FOR BIND LETTER LIST TABLE
function BindFormTable(Result, SerialNo, ReportType) {
    console.log("dsdsd" + Result)
    if (ReportType == '0') {
        $("#tbl_GroupSummary tbody tr").remove();
        if (Result.length == 0) {
            tr = $('<tr/>');
            tr.append("<td class='text-center' colspan='11'>NO RESULTS FOUND</td>");
            $("#tbl_GroupSummary tbody").append(tr);
        }
        else {
            var debit = 0.00;
            var credit = 0.00;
            var TotalDr = 0.00;
            var TotalCr = 0.00;
            for (i = 0; i < Result.length; i++) {
                if (Result[i].MarksImportant === "Active")
                    tr = $(' <tr style="background-color:#ccebff;"/>');
                else
                    tr = $('<tr/>');
                tr.append("<td class='text-left'>" + (i + 1) + "</td>");
                tr.append("<td class='text-center'><a href='javascript:void(0)' class='text-decoration-none' style='color: black !important;' onclick='GoToLedgerReport(\"" + Result[i].AccHead + "\",\"" + Result[i].LedgerUid + "\",\"" + DateFrom + "\",\"" + DateTo + "\");'>" + Result[i].AccHead + "</a></td>");
                if (Result[i].MarksImportant === 'Active') {
                    tr.append("<td class='text-center'><button type='button' onclick='OpenLedgerInformation(\"" + Result[i].LedgerUid + "\");' class= 'mt-1 bg-primary   btn btn-sm btn-primary' style=' border-radius:9px;'><i class='fa-solid fa-info'></i></button> <input type='checkbox' data-ledger_id='" + Result[i].LedgerUid + "' class=' mt-2 form-check-input' checked/></td>");
                }
                else if (Result[i].MarksImportant === 'InActive') {
                    tr.append("<td class='text-center'><button type='button' onclick='OpenLedgerInformation(\"" + Result[i].LedgerUid + "\");' class= 'mt-1 bg-primary   btn btn-sm btn-primary' style=' border-radius:9px;'><i class='fa-solid fa-info'></i></button> <input type='checkbox' data-ledger_id='" + Result[i].LedgerUid + "' class=' mt-2 form-check-input'/></td>");
                }
                tr.append("<td class='text-left'><button type='button'  class= 'bg-info  Ledgercommon-btn Ledgercommon-btn-sm' id='GroupSummaryMail' onclick='LedgerReportEmailClick(\"" + Result[i].LedgerUid + "\");'><i class='fa-regular fa-envelope me-1'></i></button > <button type='button' class= 'bg-warning  Ledgercommon-btn Ledgercommon-btn-sm ms-1' ><i class='fa-solid fa-message'></i></button> <button type='button' class= ' bg-success Ledgercommon-btn Ledgercommon-btn-sm ms-1'> <i class='fa-solid fa-list-check'></i></button> <button type='button' class= ' bg-facebook Ledgercommon-btn Ledgercommon-btn-sm ms-1'><i class='fa-solid fa-indian-rupee-sign'></i></button> </td>");

                if (Result[i].OpeningBalance > 0)
                    tr.append("<td class='text-end'>" + Result[i].OpeningBalance + "</td>");
                else
                    tr.append("<td class='text-center'></td>");
                if (Result[i].OpeningBalance < 0)
                    tr.append("<td class='text-end'>" + Math.abs(Result[i].OpeningBalance) + "</td>");
                else
                    tr.append("<td class='text-center'></td>");

                //if (Result[i].OverDueDays != null)
                //    tr.append("<td class='text-center'><button class='btn btn-Primary' style ='padding-top:1px;padding-bottom: 1px;'>" + Result[i].OverDueDays + "</button></td>");
                //else
                tr.append("<td class='text-center'></td>");

                if (Result[i].Debit > 0)
                    tr.append("<td class='text-end'>" + Result[i].Debit + "</td>");
                else
                    tr.append("<td class='text-center'></td>");
                if (Result[i].Credit != 0)
                    tr.append("<td class='text-end'>" + Result[i].Credit + "</td>");
                else
                    tr.append("<td class='text-center'></td>");


                if (Result[i].CurrentBalance > 0) {
                    tr.append("<td class='text-end'>" + Result[i].CurrentBalance + "</td>");
                    TotalDr = TotalDr + parseFloat(Result[i].CurrentBalance);
                }
                else {
                    tr.append("<td class='text-center'></td>");
                }
                if (Result[i].CurrentBalance < 0) {
                    tr.append("<td class='text-end'>" + Math.abs(Result[i].CurrentBalance) + "</td>");
                    TotalCr = TotalCr + parseFloat(Result[i].CurrentBalance);
                }
                else {
                    tr.append("<td class='text-center'></td>");
                }
                if (Result[i].Debit != null) {
                    debit = debit + parseFloat(HandleNullNumericValue((Result[i].Debit))); //Adding All Debit Amount
                }
                if (Result[i].Credit != null) {
                    credit = credit + parseFloat(HandleNullNumericValue((Result[i].Credit)));   // Adding All Credit Amount*/
                }
                //if (Result[i].CurrentBalance != null) {
                //    CurrentBalance = CurrentBalance + parseFloat(Result[i].CurrentBalance);   // Adding All RunningBalance Amount*/
                //}
                SerialNo++;
                $("#tbl_GroupSummary tbody").append(tr);
            }


            if (Result.length > 0) {
                tr = $('<tr/>');
                tr.append("<td align='Right' colspan='7'> <span style='font-weight:bold;'>Total :</span></td>");
                tr.append("<td class='text-end ' ><b>" + parseFloat(debit).toFixed(2) + "</b></td>")
                tr.append("<td class='text-end'><b>" + parseFloat(credit).toFixed(2) + "</b></td>")
                if (TotalDr > 0)
                    tr.append("<td class='text-end'><b>" + parseFloat(TotalDr).toFixed(2) + "</b></td>")
                else
                    tr.append("<td class='text-end'><b></b></td>")
                if (TotalCr < 0)
                    tr.append("<td class='text-end'><b>" + parseFloat(Math.abs(TotalCr)).toFixed(2) + "</b></td>")
                else
                    tr.append("<td class='text-end'><b></b></td>")
                $("#tbl_GroupSummary tbody").append(tr);
            }
        }
    }
    else if (ReportType == '1') {
        $("#tbl_GroupSummaryMonthWise tbody tr").remove();
        if (Result.length == 0) {
            tr = $('<tr/>');
            tr.append("<td class='text-center' colspan='8'>NO RESULTS FOUND</td>");
            $("#tbl_GroupSummaryMonthWise tbody").append(tr);
        }
        else {
            for (i = 0; i < Result.length; i++) {
                if (Result[i].Status == "Inactive") {
                    tr = $(' <tr style="background-color:#fdd2d2;"/>');
                }
                else {
                    tr = $('<tr/>');
                    tr.append("<td class='text-left'>" + (i + 1) + "</td>");
                    tr.append("<td class='text-left'>" + Result[i].VoucherMonth + "  </td>");
                    if ((Result[i].Debit != null) && (Result[i].Debit > 0)) {
                        tr.append("<td class='text-end'>" + HandleNullTextValue(Result[i].Debit) + "</td>");
                    }
                    else {
                        tr.append("<td class='text-end'></td>");
                    }
                    if ((Result[i].Credit != null) && (Result[i].Credit > 0)) {
                        tr.append("<td class='text-end'>" + HandleNullTextValue(Result[i].Credit) + "</td>");
                    }
                    else {
                        tr.append("<td class='text-end'></td>");
                    }
                    tr.append("<td class='text-end'>" + Result[i].RunningBalance + " </td>");

                }
                SerialNo++;
                $("#tbl_GroupSummaryMonthWise tbody").append(tr);
            }
        }
    }
}


$("#MarkAll").click(function () {
    let container = document.getElementById('tbl_GroupSummary');
    let ele = container.getElementsByTagName('input');
    if ($("#MarkAll")[0].checked == true) {
        for (i = 0; i < ele.length; i++) {
            if (ele[i].type == 'checkbox')
                $(ele[i]).prop('checked', true);
        }
    }
    else {
        for (i = 0; i < ele.length; i++) {
            if (ele[i].type == 'checkbox')
                $(ele[i]).prop('checked', false);
        }
    }

})

$("#MarksImportant").click(function () {
    try {
        const dataString = {};
        var Checked = "";
        var Unchecked = "";
        $("#tbl_GroupSummary tbody tr").find('.form-check-input').each(function (ind, ele) {
            if ($(ele).is(':checked') == true)
                Checked += $(ele).attr('data-ledger_id') + ",";
            else
                Unchecked += $(ele).attr('data-ledger_id') + ",";
        });
        Checked = Checked.substring(0, Checked.length - 1);
        Unchecked = Unchecked.substring(0, Unchecked.length - 1);
        dataString.CheckedLedger = Checked;
        dataString.UncheckedLedger = Unchecked;
        if (Checked.length > 0 || Unchecked.length > 0) {
            AjaxSubmission(JSON.stringify(dataString), "/Master/GroupSummary/UpdateMarksImp", $('input[name=__RequestVerificationToken]').val()).done(function (result) {
                let obj = result;
                console.log(obj);
                if (obj.status == true) {
                    if (obj.responsecode == '100') {
                        Toast(RetrieveMessage(obj.responsecode), "Message", "success");
                    }
                    else {
                        Toast(RetrieveMessage(obj.responsecode), "Message", "error");
                    }
                }
                else {
                    window.location.href = '/ClientLogin/ClientLogin';
                }
                $('#FormSearch').trigger('click');
            }).fail(function (result) {
                console.log(result.Message);
                //Hideloader();
            });
        }
    }
    catch (e) {
        console.log(e.message);
        //Hideloader();
    }
})

$(document).keydown(function (event) {
    if (event.keyCode == 27) {
        modal.style.display = "none";
    }
});
//WHEN THE USER CLICKS ANYWHERE OUTSIDE OF THE MODAL, CLOSE IT
window.onclick = function (event) {
    if (event.target == modal) {
        modal.style.display = "none";
    }
}
function ResetLedgerInformation() {
    $('#ModalLedgerInformation tbody').find('tr:eq(0) td:eq(2)').text('');
    $('#ModalLedgerInformation tbody').find('tr:eq(1) td:eq(2)').text('');
    $('#ModalLedgerInformation tbody').find('tr:eq(2) td:eq(2)').text('');
    $('#ModalLedgerInformation tbody').find('tr:eq(3) td:eq(2)').text('');
    $('#ModalLedgerInformation tbody').find('tr:eq(4) td:eq(2)').text('');
    $('#ModalLedgerInformation tbody').find('tr:eq(5) td:eq(2)').text('');
    modal.style.display = 'none';
}
var modal = document.getElementById('LedgerInformation');
function OpenLedgerInformation(e) {
    try {
        const dataString = {};
        dataString.LedgerUid = e;
        AjaxSubmission(JSON.stringify(dataString), '/Master/GroupSummary/GetIndividualLedgerInformation', $('input[name=__RequestVerificationToken]').val()).done(function (result) {
            let obj = result;
            if (obj.status == true) {
                if (obj.responsecode == '100') {
                    $('#ModalLedgerInformation tbody').find('tr:eq(0) td:eq(2)').text(HandleNullTextValue(obj.data.Table[0].AccHead));
                    $('#ModalLedgerInformation tbody').find('tr:eq(1) td:eq(2)').text(HandleNullTextValue(obj.data.Table[0].ContactPerson));
                    $('#ModalLedgerInformation tbody').find('tr:eq(2) td:eq(2)').text(HandleNullTextValue(obj.data.Table[0].Mobile));
                    $('#ModalLedgerInformation tbody').find('tr:eq(3) td:eq(2)').text(HandleNullTextValue(obj.data.Table[0].AltMobile));
                    $('#ModalLedgerInformation tbody').find('tr:eq(4) td:eq(2)').text(HandleNullTextValue(obj.data.Table[0].Email));
                    $('#ModalLedgerInformation tbody').find('tr:eq(5) td:eq(2)').text(HandleNullTextValue(obj.data.Table[0].CCEmail));
                    modal.style.display = 'block';
                }
            } else
                window.location.href = '/ClientLogin/ClientLogin';
        }).fail(function (result) {
            console.log(result.message);
        });
    }
    catch (e) {
        console.log(e.message);
    }
}



//FUNCTION FOR TINYMCE EDITIOR
function LoadTinyMCE() {
    tinymce.init({
        selector: ".tinymce",
        branding: false,
        theme: "modern",
        skin: "lightgray",
        width: "100%",
        height: 200,
        statubar: true,
        plugins: [
            "advlist autolink link image lists charmap print preview hr anchor pagebreak",
            "searchreplace wordcount visualblocks visualchars code fullscreen insertdatetime media nonbreaking",
            "save table contextmenu directionality emoticons template paste textcolor"
        ],
        toolbar: "insertfile undo redo | styleselect | bold italic | alignleft aligncenter alignright alignjustify | bullist numlist outdent indent | link | fontsizeselect | fontselect | image | print preview media fullpage | forecolor backcolor emoticons ",
        style_formats: [
            {
                title: "Headers", items: [
                    { title: "Header 1", format: "h1" },
                    { title: "Header 2", format: "h2" },
                    { title: "Header 3", format: "h3" },
                    { title: "Header 4", format: "h4" },
                    { title: "Header 5", format: "h5" },
                    { title: "Header 6", format: "h6" }
                ]
            },
            {
                title: "Inline", items: [
                    { title: "Bold", icon: "bold", format: "bold" },
                    { title: "Italic", icon: "italic", format: "italic" },
                    { title: "Underline", icon: "underline", format: "underline" },
                    { title: "Strikethrough", icon: "strikethrough", format: "strikethrough" },
                    { title: "Superscript", icon: "superscript", format: "superscript" },
                    { title: "Subscript", icon: "subscript", format: "subscript" },
                    { title: "Code", icon: "code", format: "code" }
                ]
            },
            {
                title: "Blocks", items: [
                    { title: "Paragraph", format: "p" },
                    { title: "Blockquote", format: "blockquote" },
                    { title: "Div", format: "div" },
                    { title: "Pre", format: "pre" }
                ]
            },
            {
                title: "Alignment", items: [
                    { title: "Left", icon: "alignleft", format: "alignleft" },
                    { title: "Center", icon: "aligncenter", format: "aligncenter" },
                    { title: "Right", icon: "alignright", format: "alignright" },
                    { title: "Justify", icon: "alignjustify", format: "alignjustify" }
                ]
            }
        ],
    });
}

$("#AccHeadSearch").on('input', function () {
    $("#HiddenLedgerId").val('');
});

function GoToLedgerReport(e, E1, E2, E3) {
    window.open('/Master/LedgerReport/LedgerReport', '_blank');
    SetCookie('LedgerGroupName', e, 's', 50);
    SetCookie('LedgerGroupId', E1, 's', 50);
    SetCookie('Date1', E2, 's', 50);
    SetCookie('Date2', E3, 's', 50);
}

var Id = "";
function LedgerReportEmailClick(e) {
    try {
        Id = e;
        LedgerId = parseInt($("#HiddenLedgerId").val());
        DateFrom = $("#SearchDateFrom").val();
        DateTo = $("#SearchDateTo").val();
        const dataString = {};
        dataString.PageSize = $("#ddlPageSize").val();
        dataString.PageIndex = 1;
        dataString.DateFrom = DateFrom;
        dataString.DateTo = DateTo;
        dataString.GroupUid = parseInt($("#GroupSearch").val());
        dataString.ReportType = $("#ReportTypeSearch").val();
        dataString.ledgeruid = e;
        dataString.BalanceType = $("#BalanceTypeSearch").val();
        dataString.AgentUid = $("#AgentSearch").val();
        dataString.WithBalance = $("#WithBalance").is(':checked') == true ? 1 : 0;
        dataString.ShowImportant = $("#ShowImp").is(':checked') == true ? 1 : 0;
        dataString.OrderBy = $("#sort-column").val().trim() + " " + $("#sort-type").val().trim();
        dataString.SendEmail = true;
        AjaxSubmission(JSON.stringify(dataString), '/Master/GroupSummary/FormList', $('input[name=__RequestVerificationToken]').val()).done(function (result) {
            let obj = result;
            if (obj.status == true) {
                if (obj.responsecode == '100') {
                    $("#EmailTo").val(obj.data.Table1[0].ClientEmail);

                    $("#EmailCC").val(obj.data.Table1[0].CCEmail);
                    $("#EmailLetterName").val(obj.data.Table1[0].LetterName);

                    $("#AttachFileName").text(obj.data.Table2[0].FileName);
                    $("#AttachFileName").attr("href", obj.data.Table2[0].FilePath);
                    $("#AttachedFilePath").val(obj.data.Table2[0].AttachmentFilePath);

                    $("#RefId").val(obj.data.Table1[0].LedgerId);
                    $("#SendToName").val(obj.data.Table1[0].SendTo);
                    $("#RefName").val('GroupSummaryReport');
                    EmailModal.style.display = "block";

                    BindTemplateName('AllTemplate', 'Email');
                    FillTemplateDataInTincyMce(e, 'LedgerReminder', null, 'Email', 'Group');
                }
                else if (obj.responsecode == '703') {
                    Toast(obj.error, "Message", "error");
                }
                else {
                    Toast(RetrieveMessage(obj.responsecode), "Message", "error");
                }

            } else
                window.location.href = '/ClientLogin/ClientLogin';
            HideLoader();
        }).fail(function (result) {
            console.log(result.Message);
            HideLoader();
        });
    }
    catch (e) {
        console.log(e.message);
    }
}


$("#GroupSummaryPDF").click(function () {
    try {
        LedgerId = parseInt($("#HiddenLedgerId").val());
        DateFrom = $("#SearchDateFrom").val();
        DateTo = $("#SearchDateTo").val();
        const dataString = {};
        dataString.PageSize = $("#ddlPageSize").val();
        dataString.PageIndex = 1;
        dataString.DateFrom = DateFrom;
        dataString.DateTo = DateTo;
        dataString.GroupUid = parseInt($("#GroupSearch").val());
        dataString.ReportType = $("#ReportTypeSearch").val();
        dataString.ledgeruid = LedgerId;
        dataString.BalanceType = $("#BalanceTypeSearch").val();
        dataString.AgentUid = $("#AgentSearch").val();
        dataString.WithBalance = $("#WithBalance").is(':checked') == true ? 1 : 0;
        dataString.ShowImportant = $("#ShowImp").is(':checked') == true ? 1 : 0;
        dataString.OrderBy = $("#sort-column").val().trim() + " " + $("#sort-type").val().trim();
        dataString.SendEmail = false;
        AjaxSubmission(JSON.stringify(dataString), '/Master/GroupSummary/FormList', $('input[name=__RequestVerificationToken]').val()).done(function (result) {
            let obj = result;
            if (obj.status == true) {
                if (obj.responsecode == '100') {
                    window.open($("#MyReport").attr('href'), '_blank');
                }
                else if (obj.responsecode == '703') {
                    Toast(obj.error, "Message", "error");
                }
                else {
                    Toast(RetrieveMessage(obj.responsecode), "Message", "error");
                }

            } else
                window.location.href = '/ClientLogin/ClientLogin';
            HideLoader();
        }).fail(function (result) {
            console.log(result.Message);
            HideLoader();
        });
    }
    catch (e) {
        console.log(e.message);
    }
});

//FUNCTION FOR CHANGE TEMPLATE DETAILS
function TemplateChange() {
    tinymce.get("EmailBody").setContent('');
    $('#Subject').val('');
    if ($('#AllTemplate').val() != null && $('#AllTemplate') != undefined) {
        if ($('#AllTemplate').val() != 0)
            FillTemplateDataInTincyMce(Id, 'LedgerReminder', $('#AllTemplate').val(), 'Email', 'Group');
    }
}



// FUNCTION FOR DEBIT CHART MONTH WISE
function ShowCurrentBalanceByChart() {
    try {
        AjaxSubmission(null, "/Master/GroupSummary/DebitGraphChart", $('[name="__RequestVerificationToken"]').val()).done(function (data) {
            let obj = data;
            if (obj.success == true) {
                if (obj.series.length > 0) {
                    var options = {
                        series: [{
                            name: "Amount",
                            data: data.series
                        }],
                        chart: {
                            type: 'bar',
                            height: 350
                        },
                        plotOptions: {
                            bar: {
                                borderRadius: 4,
                                horizontal: true,
                                barHeight: '40%',
                                hideZeroBarsWhenGrouped: false,
                            }
                        },
                        dataLabels: {
                            enabled: false
                        },
                        xaxis: {
                            name: "Amount",
                            categories: data.labels,
                        }, legend: {
                            position: 'top'
                        },
                        title: {
                            text: "Group Summary Debit Graph",
                            align: 'center',
                            margin: 10,
                            offsetX: 0,
                            offsetY: 0,
                            floating: false,
                            style:
                            {
                                fontSize: '14px',
                                fontWeight: 'bold',
                                fontFamily: 'Arial,Helvetica,sans-serif'
                                //color: '#263238'
                            }
                        }
                    };

                    var chart = new ApexCharts(document.querySelector("#DebitChart"), options);
                    chart.render();



                }
                else {
                    Toast(RetrieveMessage(obj.responsecode), "Message", "error");
                }

            }
            //else {
            //    window.location.href = '/ClientLogin/ClientLogin';
            //}
        }).fail(function (data) {
            console.log(data.Message);
        });
    }
    catch (e) {
        console.log(e.message);
    }
}
// FUNCTION FOR CREDIT CHART MONTH WISE
function ShowCreditBalanceByChart() {
    try {
        AjaxSubmission(null, "/Master/GroupSummary/CreditGraphChart", $('[name="__RequestVerificationToken"]').val()).done(function (data) {
            let obj = data;
            console.log(obj);
            if (obj.success == true) {
                if (obj.series.length > 0) {
                    var options = {
                        series: [{
                            name: "Amount Rs",
                            data: data.series
                        }],
                        chart: {
                            type: 'bar',
                            height: 350
                        },
                        plotOptions: {
                            bar: {
                                borderRadius: 4,
                                horizontal: true,
                                barHeight: '40%',
                                hideZeroBarsWhenGrouped: false,
                            }
                        },
                        dataLabels: {
                            enabled: false
                        },
                        xaxis: {

                            name: "Amount Rs",
                            categories: data.labels,
                        }, legend: {
                            position: 'top'
                        },
                        title: {
                            text: "Group Summary Credit Graph",
                            align: 'center',
                            margin: 10,
                            offsetX: 0,
                            offsetY: 0,
                            floating: false,
                            style:
                            {
                                fontSize: '14px',
                                fontWeight: 'bold',
                                fontFamily: 'Arial,Helvetica,sans-serif'
                                //color: '#263238'
                            }
                        },
                    };
                    var chart = new ApexCharts(document.querySelector("#CreditChart"), options);
                    chart.render();
                }
                else {
                    Toast(RetrieveMessage(obj.responsecode), "Message", "error");
                }

            }
            //else {
            //    window.location.href = '/ClientLogin/ClientLogin';
            //}
        }).fail(function (data) {
            console.log(data.Message);
        });
    }
    catch (e) {
        console.log(e.message);
    }
}


// FUNCTION FOR DEBIT CREDIT CHART MONTH WISE
function DebitCreditBalanceByChartMonthWise() {
    var dmy = $("#SearchDateFrom").val();
    var arrDate = dmy.split('/');
    var mdy = arrDate[2] + "-" + arrDate[1] + "-" + arrDate[0];

    var dmy = $("#SearchDateTo").val();
    var arrDate = dmy.split('/');
    var mdy1 = arrDate[2] + "-" + arrDate[1] + "-" + arrDate[0];
    const dataString = {};
    dataString.DateFrom = DateFrom;
    dataString.DateTo = DateTo;
    try {
        var dmy = $("#SearchDateFrom").val();
        var arrDate = dmy.split('/');
        var mdy = arrDate[2] + "-" + arrDate[1] + "-" + arrDate[0];
        var dmy = $("#SearchDateTo").val();
        var arrDate = dmy.split('/');
        var mdy1 = arrDate[2] + "-" + arrDate[1] + "-" + arrDate[0];
        const dataString = {};
        dataString.DateFrom = mdy;
        dataString.DateTo = mdy1;
        dataString.LedgerGroup = parseInt($("#GroupSearch").val()),
            dataString.BranchUid = parseInt($("#SelectBranch").val())
        AjaxSubmission(JSON.stringify(dataString), "/Master/GroupSummary/DebitCreditBalanceByChartMonthWise", $('[name="__RequestVerificationToken"]').val()).done(function (data) {
            let obj = data;
            console.log(obj);
            if (obj.success == true) {
                if (obj.series.length > 0) {
                    var options = {
                        series: [{
                            name: "Debit",
                            data: data.series
                        }, {
                            name: "Credit",
                            data: data.series1
                        }],
                        chart: {
                            type: 'bar',
                            height: 430
                        },
                        plotOptions: {
                            bar: {
                                horizontal: true,
                                borderRadius: 4,
                                barHeight: '100%',
                                columnWidth: '100%',
                                hideZeroBarsWhenGrouped: false,
                                dataLabels: {
                                    position: 'top',

                                },
                            }
                        },
                        dataLabels: {
                            enabled: true,
                            offsetX: -6,
                            style: {
                                fontSize: '12px',
                                colors: ['#fff']
                            }
                        },
                        stroke: {
                            show: true,
                            width: 1,
                            colors: ['#fff']
                        },
                        tooltip: {
                            shared: true,
                            intersect: false
                        },
                        xaxis: {
                            categories: data.labels,
                        }
                        , legend: {
                            position: 'top'
                        },
                        title: {
                            text: "Group Summary Month Wise Graph",
                            align: 'center',
                            margin: 10,
                            offsetX: 0,
                            offsetY: 0,
                            floating: false,
                            style:
                            {
                                fontSize: '14px',
                                fontWeight: 'bold',
                                fontFamily: 'Arial,Helvetica,sans-serif'
                                //color: '#263238'
                            }
                        },
                    };
                    var chart = new ApexCharts(document.querySelector("#DebitCreditMonthWise"), options);
                    chart.render();
                }
                else {
                    Toast(RetrieveMessage(obj.responsecode), "Message", "error");
                }

            }
            //else {
            //    window.location.href = '/ClientLogin/ClientLogin';
            //}
        }).fail(function (data) {
            console.log(data.Message);
        });
    }
    catch (e) {
        console.log(e.message);
    }
}


//FUNCTION FOR EXPORT DATA IN EXCEL
function FormExcel() {
    debugger;
    ShowLoader();
    let date = new Date();
    let NewDate = ("00" + date.getDate()).slice(-2) + "_" + ("00" + (date.getMonth() + 1)).slice(-2) + "_" + date.getFullYear() + "_" + ("00" + date.getHours()).slice(-2) + "_" + ("00" + date.getMinutes()).slice(-2) + "_" + ("00" + date.getSeconds()).slice(-2);
    let fileName = "GroupSummary_" + NewDate + ".xlsx";

    $('#FormSearch').trigger('click');
    AjaxSubmission(null, '/Master/GroupSummary/FormExcel', $('input[name=__RequestVerificationToken]').val()).done(function (result) {
        let obj = result;
        if (obj.status == true) {
            if (obj.responsecode == '100') {

                let bytes = Base64ToBytes(obj.data.FileData[0].Base64Data);
                let blob = new Blob([bytes], { type: "application/octetstream" });
                let isIE = false || !!document.documentMode;
                if (isIE) {
                    window.navigator.msSaveBlob(blob, fileName);
                } else {
                    let url = window.URL || window.webkitURL;
                    link = url.createObjectURL(blob);
                    let a = $("<a />");
                    a.attr("download", fileName);
                    a.attr("href", link);
                    $("body").append(a);
                    a[0].click();
                    $("body").remove(a);
                }
            }
            else if (obj.responsecode == '302')
                Toast('No Records found.', 'Message', 'success');
            else
                Toast(RetrieveMessage(obj.responsecode), 'Message', 'error');

        } else
            window.location.href = '/ClientLogin/ClientLogin';
        HideLoader();

    }).fail(function (result) {
        console.log(result.Message);
        HideLoader();
    });
}

