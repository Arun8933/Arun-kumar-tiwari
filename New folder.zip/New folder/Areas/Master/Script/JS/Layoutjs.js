﻿
const _InvalidExtension = [".exe", ".dll"];
var tmpcm = 0;
var compcount = 0;
var TableCount = 0;
var AmountCheck = "";
var ModalAcceptAddress=false;
$(document).on('select2:open', () => {
    document.querySelector('.select2-search__field').focus();
});

var EmailModal = document.getElementById('EmailModal');

window.onclick = function (event) {
    if (event.target == EmailModal) {
        EmailModal.style.display = "none";
        $("#EmailTo").val('');
        $("#EmailCC").val('');
        tinymce.get("EmailBody").setContent("");
        $("#Subject").val('');
        $("#RefId").val('');
        $("#AttachFileName").text('');
        $("#SendToName").val('');
        $("#RefName").val('');
        AttachmentUploadResetdata();
    }
};

var kecoun = 0;
var linkarr = [];
//FUNCTION FOR SEARCH MENU IN SIDE BAR // pass
function SearchMenu(e) {   
    var input, filter, ul, li, a, i;
    input = e.value.toUpperCase();
    filter = input.toUpperCase();
    ul = document.getElementById("sidebar-menu");
    li = ul.getElementsByTagName("li");
    var th = 0;
    var totala = 0;

    for (i = 0; i < li.length; i++) {
        totala = 0;
        a = li[i].getElementsByTagName("a");        
        th = 0;
        for (var j = 0; j < a.length; j++) {
            if (a[j].id.length > 0) {
                totala++;
                if ($(a[j]).find("span.menu_name").text().toUpperCase().indexOf(input) > -1) {
                    $(a[j]).find("span.menu_name").parent().css('display', '');  
                } else {
                    th++;
                    $(a[j]).find("span.menu_name").parent().css('display', 'none');
                }
            }
        }
     
        if (totala != th) {
            $(li[i]).css('display', '');
            $(li[i]).children().addClass('show');
        } else {
            $(li[i]).css('display', 'none');
            $(li[i]).children().removeClass('show');
        }
    }

    console.clear();
    linkarr = [];
    $('#sidebar-menu li:visible a[id]:visible').each(function (ind, ele) {
        linkarr.push(ele.href);
        console.log(ele.href);
    })
}

//FUNCTION FOR SET LAYOUT FOR STARTING
function SetSessionLayout() {
    try {
        if (Get_Cookie($('#userid').text()) == null)
            Set_Cookie($('#userid').text(), 'Horizontal-Layout', 2);

        const dataString = {};
        dataString.Layout = Get_Cookie($('#userid').text());

        AjaxSubmission(JSON.stringify(dataString), '/_Layout/ChangeSessionLayout', $('input[name=__RequestVerificationToken]').val()).done(function (result) {

        }).fail(function (result) {
            console.log(result.Message);
        });
    }
    catch (e) {
        console.log(e.message);
    }
}

//FUNCTION FOR CHANGE LAYOUT HORIZONTAL/VERTICAL   // pass
function ChangeSessionLayout() {

    try {

        if (Get_Cookie($('#userid').text()) == null)
            Set_Cookie($('#userid').text(), 'Horizontal-Layout', 2);
        else if (Get_Cookie($('#userid').text()) == 'Horizontal-Layout')
            Set_Cookie($('#userid').text(), 'Vertical-Layout', 2);
        else if (Get_Cookie($('#userid').text()) == 'Vertical-Layout')
            Set_Cookie($('#userid').text(), 'Horizontal-Layout', 2);
        else
            Set_Cookie($('#userid').text(), 'Horizontal-Layout', 2);

        //if (localStorage.getItem("Layout") == null)
        //    localStorage.setItem("Layout", "Horizontal-Layout");
        //else if (localStorage.getItem("Layout") == "Horizontal-Layout") 
        //    localStorage.setItem("Layout", "Vertical-Layout");         
        //else if (localStorage.getItem("Layout") == "Vertical-Layout") 
        //    localStorage.setItem("Layout", "Horizontal-Layout");
        //else 
        //    localStorage.setItem("Layout", "Horizontal-Layout");
        const dataString = {};

        /*dataString.Layout = localStorage.getItem("Layout");*/
        dataString.Layout = Get_Cookie($('#userid').text());
        AjaxSubmission(JSON.stringify(dataString), "/_Layout/ChangeSessionLayout", $('input[name=__RequestVerificationToken]').val()).done(function (result) {
            let obj = result;
            if (obj.status == true) {
                window.location.reload();
            }
            else {
                window.location.href = '/ClientLogin/ClientLogin';
            }
            
            //Hideloader();
        }).fail(function (result) {
            console.log(result.Message);
            //Hideloader();
        });
    }
    catch (e) {
        console.log(e.message);
        //Hideloader();
    }

}

//FUMCTION FOR FILL COMPANY LIST   // pass
function DynamicClientWiseCompanyList() {
    try {       
        AjaxSubmission(null, "/_Layout/FillClientWiseCompanyList", $('input[name=__RequestVerificationToken]').val()).done(function (result) {
            let obj = result;          
            if (obj.status == true) {
                if (obj.responsecode == '100') {

                    if (Get_Cookie($('#userid').text()) == "Horizontal-Layout") {
                        BindDropdown(obj.data.Table, 'SetCompany', 'company_id', 'company_name', '-----Select-----');
                        $('#SetCompany').val(obj.data.DefCompany[0].DefaultCompany);
                    }
                    else if (Get_Cookie($('#userid').text()) == "Vertical-Layout") {
                        BindDropdown(obj.data.Table, 'SetCompanySB', 'company_id', 'company_name', '-----Select-----');
                        $('#SetCompanySB').val(obj.data.DefCompany[0].DefaultCompany);
                    }

                    //if (localStorage.getItem("Layout") == "Horizontal-Layout") {
                    //    BindDropdown(obj.data.Table, 'SetCompany', 'company_id', 'company_name', '-----Select-----');
                    //    $('#SetCompany').val(obj.data.DefCompany[0].DefaultCompany);
                    //}
                    //else if (localStorage.getItem("Layout") == "Vertical-Layout") {
                    //    BindDropdown(obj.data.Table, 'SetCompanySB', 'company_id', 'company_name', '-----Select-----');
                    //    $('#SetCompanySB').val(obj.data.DefCompany[0].DefaultCompany);
                    //}
                    BindDropdown(obj.data.Table, 'ChooseCompany', 'company_id', 'company_name', '-----Select-----');

                    localStorage.setItem("company_id", obj.data.DefCompany[0].DefaultCompany);

                    if (obj.data.DefCompany[0].DefaultCompany == 0) {
                        Toast(RetrieveMessage("802"), "message", 'error');
                        $('#modal-Select-Company').modal('show');
                    } else {
                        //if (localStorage.getItem("Layout") == "Horizontal-Layout")
                        //    GetFinancialYearName('SetFinancialYear');
                        //else if (localStorage.getItem("Layout") == "Vertical-Layout")
                        //    GetFinancialYearName('SetFinancialYearSB');

                        if (Get_Cookie($('#userid').text()) == "Horizontal-Layout")
                            GetFinancialYearName('SetFinancialYear');
                        else if (Get_Cookie($('#userid').text()) == "Vertical-Layout")
                            GetFinancialYearName('SetFinancialYearSB');
                    }
                }
                         
            }                
            //Hideloader();
        }).fail(function (result) {
            console.log(result.Message);
            //Hideloader();
        });
    }
    catch (e) {
        console.log(e.message);
        //Hideloader();
    }
}

//$('.scrol').css({ 'overflow': 'scroll', 'height': parseInt(screen.height)/1.6});
//$('.scrol2').css({ 'overflow': 'scroll', 'height': parseInt(screen.height) / 2.1 });

$('.scrol').css({ 'overflow': 'scroll', 'height': parseInt($(window).height()) / 1.35 });
$('.scrol2').css({ 'overflow': 'scroll', 'height': parseInt($(window).height()) / 1.8 });

/*$('.modal-body').css({ 'overflow': 'scroll', 'height': parseInt(screen.height / 1.7) });*/


$(document).ready(function () {
    SetSessionLayout();
    DynamicClientWiseCompanyList();
    GetListDocumentTypeName();
    GetGroupListAcceptAddressWise('modalUnderGroup');
    jQuery('.timepicker').datetimepicker({
        datepicker: false,
        format: 'H:i',
        step: 15  // 15-minute intervals
    });
  
})

//TOP NAV BAR SET COMPANY ON CHANGE EVENT
$("#SetCompany").change(function () {
   
    if ($("#SetCompany").val() == 0) {
        $('#modal-Select-Company').modal('show');
        Toast(RetrieveMessage("802"), "message", 'error');
        $('#SetFinancialYear').html('');
        $('#SetFinancialYearSB').html('');
    } else {
        //Showloader();
        const dataString = {};
        dataString.CompanyId = $(".SetCompany").val();
        AjaxSubmission(JSON.stringify(dataString), "/_Layout/SelectCompany", $('input[name=__RequestVerificationToken]').val()).done(function (result) {
            AjaxSubmission(JSON.stringify(dataString), "/_Layout/CheckBranchCount", $('input[name=__RequestVerificationToken]').val()).done(function (result) {
                let obj = result;
                if (obj.status == true) {
                    if (obj.responsecode == '100')
                        if (obj.data.Table[0].count == 0)
                            window.location.href = '/Master/Branch/Branch';
                        else
                            location.reload();                       
                }
                else 
                    window.location.href = '/ClientLogin/ClientLogin';
                //Hideloader();
            }).fail(function (result) {
                console.log(result.Message);
                //Hideloader();
            });
            //Hideloader();
        }).fail(function (result) {
            console.log(result.Message);
            //Hideloader();
        });
    }
});

//SIDE NAV BAR SET COMPANY ON CHANGE EVENT
$("#SetCompanySB").change(function () {

    if ($("#SetCompanySB").val() == 0) {
        $('#modal-Select-Company').modal('show');
        Toast(RetrieveMessage("802"), "message", 'error');
    } else {
        //Showloader();
        const dataString = {};
        dataString.CompanyId = $("#SetCompanySB").val();
        AjaxSubmission(JSON.stringify(dataString), "/_Layout/SelectCompany", $('input[name=__RequestVerificationToken]').val()).done(function (result) {
            AjaxSubmission(JSON.stringify(dataString), "/_Layout/CheckBranchCount", $('input[name=__RequestVerificationToken]').val()).done(function (result) {
                let obj = result;
                if (obj.status == true) {
                    if (obj.responsecode == '100')
                        if (obj.data.Table[0].count == 0)
                            window.location.href = '/Master/Branch/Branch';
                        else
                            location.reload();
                }
                else
                    window.location.href = '/ClientLogin/ClientLogin';
                //Hideloader();
            }).fail(function (result) {
                console.log(result.Message);
                //Hideloader();
            });
            //Hideloader();
        }).fail(function (result) {
            console.log(result.Message);
            //Hideloader();
        });
    }
});
//ChooseCompanySave Button Click Event  // pass
$("#ChooseCompanySave").click(function () {   
    if ($("#ChooseCompany").val() == 0) {
        Toast(RetrieveMessage("802"), "message", 'error');
    } else {
        $("#SetCompany").val($("#ChooseCompany").val());        
        $("#SetCompanySB").val($("#ChooseCompany").val());
        $('#modal-Select-Company').modal('hide');
        //Showloader();
       
        const dataString = {};
        dataString.CompanyId = $("#ChooseCompany").val()

        AjaxSubmission(JSON.stringify(dataString), "/_Layout/SelectCompany", $('input[name=__RequestVerificationToken]').val()).done(function (result) {

            AjaxSubmission(JSON.stringify(dataString), "/_Layout/CheckBranchCount", $('input[name=__RequestVerificationToken]').val()).done(function (result) {
                let obj = result;

                if (obj.status == true) {
                    if (obj.responsecode == '100')
                        if (obj.data.Table[0].count == 0)
                            window.location.href = '/Master/Branch/Branch';
                        else 
                            location.reload();  
                }
                else 
                    window.location.href = '/ClientLogin/ClientLogin';                
                //Hideloader();
            }).fail(function (result) {
                console.log(result.Message);
                //Hideloader();
            });
            //Hideloader();
        }).fail(function (result) {
            console.log(result.Message);
            //Hideloader();
        });
    }
    
});




/*financial year function*/



// FUNCTION FOR FILL BRANCH LIST
function GetFinancialYearName(DrpID) {
    try {
        //Showloader();
        AjaxSubmission(null, "/_Layout/GetListFinancialYearName", $('input[name=__RequestVerificationToken]').val()).done(function (result) {
            let obj = result;           
            if (obj.status == true) {
                if (obj.responsecode == '100') {
                    BindDropdown(obj.data.Table, DrpID, 'finyr_id', 'finyr_name', '-----Select-----');
                    BindDropdown(obj.data.Table, 'ChooseFinancialYear', 'finyr_id', 'finyr_name', '-----Select-----');

                    $("#" + DrpID).val(obj.data.DefFinancialYear[0].DefaultFinancialYear);

                    if (obj.data.DefFinancialYear[0].DefaultFinancialYear == 0) {
                        Toast(RetrieveMessage("1018"), "message", 'error');
                        $("#modal-Select-FinancialYear").modal('show');
                    }
                }

                else if (obj.responsecode == '604') {
                    BindDropdown(null, DrpID, 'finyr_id', 'finyr_name', '-----Select-----');
                    BindDropdown(null, 'ChooseFinancialYear', 'finyr_id', 'finyr_name', '-----Select-----');
                }
                    
                else
                    Toast(RetrieveMessage(obj.responsecode), "Message", "error");

            }
            else
                window.location.href = '/ClientLogin/ClientLogin';
          
            //Hideloader();
        }).fail(function (result) {
            console.log(result.Message);
            //Hideloader();
        });
    }
    catch (e) {
        console.log(e.message);
        /* //Hideloader();*/
    }
}

//TOP NAV BAR SELECT FINANCIAL YEAR
$("#SetFinancialYear").change(function () {
    if ($("#SetFinancialYear").val() == 0) {
        Toast(RetrieveMessage("1018"), "message", 'error');
        $("#modal-Select-FinancialYear").modal('show');
    }
    else {
        const dataString = {};
        dataString.FinyrId = $("#SetFinancialYear").val();
        AjaxSubmission(JSON.stringify(dataString), "/_Layout/SelectFinancialYear", $('input[name=__RequestVerificationToken]').val()).done(function (result) {
            let obj = result;
            if (obj.status == true) {
                if (obj.responsecode == '100')
                    location.reload();
            }
            else
                window.location.href = '/ClientLogin/ClientLogin';


        }).fail(function (result) {
            console.log(result.Message);
        });
    }
    
});

//SIDE NAV BAR SELECT FINANCIAL YEAR
$("#SetFinancialYearSB").change(function () {
    if ($("#SetFinancialYearSB").val() == 0) {
        Toast(RetrieveMessage("1018"), "message", 'error');
        $("#modal-Select-FinancialYear").modal('show');
    }
    else {
        const dataString = {};
        dataString.FinyrId = $("#SetFinancialYearSB").val();
        AjaxSubmission(JSON.stringify(dataString), "/_Layout/SelectFinancialYear", $('input[name=__RequestVerificationToken]').val()).done(function (result) {
            let obj = result;
            if (obj.status == true) {
                if (obj.responsecode == '100')
                    location.reload();
            }
            else
                window.location.href = '/ClientLogin/ClientLogin';

        }).fail(function (result) {
            console.log(result.Message);
        });
    }

});

$("#ChooseFinancialYearSave").click(function () {
    if ($("#ChooseFinancialYear").val() == 0) {
        Toast(RetrieveMessage("1018"), "message", 'error');
        $("#modal-Select-FinancialYear").modal('show');
    }
    else {
        const dataString = {};
        dataString.FinyrId = $("#ChooseFinancialYear").val();
        AjaxSubmission(JSON.stringify(dataString), "/_Layout/SelectFinancialYear", $('input[name=__RequestVerificationToken]').val()).done(function (result) {
            let obj = result;
            if (obj.status == true) {
                if (obj.responsecode == '100')
                    location.reload();
            }
            else
                window.location.href = '/ClientLogin/ClientLogin';

        }).fail(function (result) {
            console.log(result.Message);
        });
    }
});




/*================================DOCUMENT UPLOAD MODAL FUNCTIONS==========================*/


function GetListDocumentTypeName() {
    try {
        //Showloader();
        AjaxSubmission(null, "/_Layout/GetListDocumentTypeName", $('input[name=__RequestVerificationToken]').val()).done(function (data) {
            let obj = data;

            if (obj.status == true) {
                if (obj.responsecode == '100')

                    BindDropdown(obj.data.Table, 'SetDocumentType', 'doc_type_uid', 'doc_type', 'Select');
                /* */

            }
            else {
                window.location.href = '/ClientLogin/ClientLogin';
            }
            //Hideloader();
        }).fail(function (result) {
            console.log(result.Message);
            //Hideloader();
        });
    }
    catch (e) {
        console.log(e.message);
        //Hideloader();
    }
}
// ADD MORE DOCUMENT UPLOAD DROPDOWN GRID 
$("#AddMoreDocumentUpload").click(function () {
    $("#RemoveDocumentUpload").removeAttr('disabled');
    var tbody = $("#DocumentUpload_Table").find("tbody");
    var FirstTr = $(tbody).find("tr:first");
    var NewRow = $(FirstTr).clone();
    /*  NewRow.find('.SetDocumentType').val('');*/
    NewRow.find('.DocumentName').val('');
    NewRow.find('.DocumentTypeFile').val('');
    $("#DocumentUpload_Table").find("tbody").append(NewRow);
    var LastTr = $(tbody).find("tr:last");
    LastTr.find('.SetDocumentType').focus();
});

// DELETE DOCUMENT UPLOAD DROPDOWN GRID ROW
function DeleteDocUploadRow(obj) {
    var rowCount = $("#DocumentUpload_Table tbody tr").length;
    if (rowCount > 1) {
        $(obj).parent().parent().remove();
    }
    else {
        $("#RemoveDocumentUpload").attr("disabled", "disabled");
    }
}

//FUNCTION FOR RESET INPUT TYPE FIELD
function DocUploadResetdata() {  
    var tbody = $("#DocumentUpload_Table").find("tbody");
    var Tr = $(tbody).find("tr");
    var rowCount = Tr.length;
    if (rowCount > 1) {
        $("#DocumentUpload_Table tbody tr").each(function (index, ele) {
            if (index > 0) {
                $(ele).remove();
            }
            else {
                $(ele).find('.SetDocumentType').val(0).trigger('change');
                $(ele).find('.DocumentTypeFile').val('');
                $(ele).find('.DocumentName').val('');
                $("#DocumentUpload_Table").find("tbody").append(ele);
            }
        });
    }
    else {
        Tr.find('.SetDocumentType').val(0).trigger('change');
        Tr.find('.DocumentTypeFile').val('');
        Tr.find('.DocumentName').val('');
        $("#DocumentUpload_Table").find("tbody").append(Tr);
    }
};


// DOCUMENT UPLOAD ON CLICK FUNCTION
$("#UploadDoc").click(function () {
    var flag = 0;
    alert('hii');
    $('#DocumentUpload_Table tbody tr').each(function (index, item) {
        if ($(this).find('.SetDocumentType').val() == 0) {
            Toast("Please Select Document Type !", 'Message', 'error');
            flag = 1;
            return false;
        }
        if ($(this).find('input:file').prop('files')[0] == null) {
            Toast("Please Choose File !", 'Message', 'error');
            flag = 1;
            return false;
        }

        if ($(this).find('input:file').prop('files')[0].size / 1024 >= 1000) {
            Toast("File too Big, please select a file less than 1mb !", 'Message', 'error');
            flag = 1;
            return false;
        }
        //if ($(this).find('input:file').prop('files')[0].size < 500) {
        //    Toast("File too small, please select a file greater than 500 kb!", 'Message', 'error');
        //    flag = 1;
        //    return false;
        //}
    });
    if (flag == 0)
        DocumentUpload();
});

// DOCUMENT UPLOAD COMMON FUNCTION FOR UPLOAD DOCUMNET
function DocumentUpload() {
    try {
        var mydata = new FormData();
        let allData = [];
        var FormName = formname;
        var FormUid = formid;

        $('#DocumentUpload_Table tbody tr').each(function (index, item) {
            var tr = $(this);
            var docType = $(this).find('select').val();
            var description = $(this).find('input:text').val();
            mydata.append(description, $(this).find('input:file').prop('files')[0]);
            var assoFiled = {
                DocTypeId: docType,
                Description: description,
                MasterName: FormName,
                MasterUid: FormUid,
                VoucherType: VoucherType
            };
            allData.push(assoFiled);
        });
        mydata.append('FilesData', JSON.stringify(allData));

        AjaxSubmissionformdata(mydata, "/_Layout/DocumentUploads", $('[name="__RequestVerificationToken"]').val()).done(function (result) {
            let obj = result;
            if (obj.status == true) {
                if (obj.responsecode == '101') {
                    DocUploadResetdata();
                    if (FormName == "Ledger") {
                        CommonFormList('LedgerDocUpload LDU INNER JOIN document_type_master DTM ON DTM.doc_type_uid =LDU.DocTypeUid ', 'ldu.DocUploadUId, DTM.doc_type, LDU.FilePath,ldu.LedgerUid', 'FilePath');
                        Toast("Record Saved Successfully", "Message", "success");
                    }
                    if (FormName == "Job") {
                        CommonFormList('JobDocUpload JDU INNER JOIN document_type_master DTM ON DTM.doc_type_uid =JDU.DocTypeUid', ' JDU.DocUploadUId, DTM.doc_type, JDU.FilePath,JDU.JobNo', 'FilePath');
                        Toast("Record Saved Successfully", "Message", "success");
                    }
                    if (FormName == "Voucher") {
                        CommonFormList('VoucherDocUpload VDU INNER JOIN document_type_master DTM ON DTM.doc_type_uid =VDU.DocTypeUid', ' VDU.DocUploadUId, DTM.doc_type, VDU.FilePath,VDU.VoucherID', 'FilePath');
                        Toast("Record Saved Successfully", "Message", "success");
                    }
                }
                else {
                    Toast(RetrieveMessage(obj.responsecode), "Message", "error");
                }
            }
            else {
                window.location.href = '/ClientLogin/ClientLogin';
            }
            //Hideloader();
        }).fail(function (result) {
            console.log(result.Message);
            //Hideloader();

        });


    }
    catch (ex) {
        console.log(ex.message);
    }
}

// BIND DOCUMENT UPLOAD  TABLE 
function BindCommonFormTable(result, serial_no) {
    $("#tbl_DocumentUploadList tbody tr").remove();
    if (result.length == 0) {
        tr = $('<tr/>');
        tr.append("<td class='text-center' colspan='9'>NO RESULTS FOUND</td>");
        $("#tbl_DocumentUploadList tbody").append(tr);
    }
    else {
        for (i = 0; i < result.length; i++) {
            if (result[i].is_active == "Inactive")
                tr = $(' <tr style="background-color:#fdd2d2;"/>');
            else
                tr = $('<tr/>');
            tr.append("<td class='text-center ' style='width:6%;'>" + serial_no + "</td>");
            tr.append("<td class='text-center'>" + result[i].DocUploadUId + "</td>");
            tr.append("<td class ='text-center'>" + result[i].doc_type + "</a></td>");
            PathName = result[i].FilePath;
            var path = PathName.trim().split('/');
            var file = path.length - 1;
            tr.append("<td class='text-center'><a href='" + result[i].FilePath + "' target = '_blank' class='text-decoration-none' style='color: black !important;' >" + path[file] + " </a> </td>");
            tr.append("<td class='text-center'><button type='button' onclick='CommonFormDelete(\"" + result[i].DocUploadUId + "\",\"" + result[i].FilePath + "\");' class= 'common-btn common-btn-sm'> <i class='fa-regular fa-trash-can'></i></button ></td > ");
            serial_no++;
            $("#tbl_DocumentUploadList tbody").append(tr);
        }
    }
}

//FUNCTION FOR FILL DOCUMENT UPLOAD LIST
function CommonFormList(TableName, ColumnName, OrderBy, pageindex) {
    try {
        const dataString = {};
        dataString.PageSize = $("#ddlPageSize").val();
        dataString.PageIndex = pageindex;
        dataString.TableName = TableName;
        dataString.ColumnName = ColumnName;
        dataString.TableId = formid;
        dataString.VoucherType = VoucherType;
        dataString.MasterName = formname;
        dataString.OrderBy = OrderBy;
        //Showloader();
        AjaxSubmission(JSON.stringify(dataString), "/Master/_Layout/GetUploadDocumentData", $('input[name=__RequestVerificationToken]').val()).done(function (result) {
            let obj = result;
            if (obj.status == true) {
                if (obj.responsecode == '100') {
                    var ser = ((parseInt(obj.data.Table1[0].PageIndex) - 1) * parseInt(obj.data.Table1[0].PageSize)) + 1;
                    BindCommonFormTable(obj.data.Table, ser);
                    $(".pagination").BindPaging({
                        ActiveCssClass: "current",
                        PagerCssClass: "pager",
                        PageIndex: parseInt(obj.data.Table1[0].PageIndex),
                        PageSize: parseInt(obj.data.Table1[0].PageSize),
                        RecordCount: parseInt(obj.data.Table1[0].count)
                    });
                }
                else
                    Toast(RetrieveMessage(obj.responsecode), "Message", "error");
            }
            else
                window.location.href = '/ClientLogin/ClientLogin';
            //Hideloader();
        }).fail(function (result) {
            console.log(result.Message);
            //Hideloader();
        });
    }
    catch (e) {
        console.log(e.message);
        //Hideloader();
    }
}

//FUNCTION FOR SORTING DOCUMENT UPLOAD FIELD
function Sorting(obj) {
    if (Firstcolumn != "") {
        document.getElementById(Firstcolumn).innerHTML = document.getElementById(Firstcolumn).getAttribute("data-column") + " <i class='fa-solid fa-sort'></i>";
    }
    Firstcolumn = obj.id;
    var colname = $(obj).data("column");
    $("#sort-column").val(Firstcolumn);
    var sorttype = $("#sort-type").val();
    if (sorttype == "ASC") {
        $("#sort-type").val("DESC");
        $(obj).html(colname + " <i  style='margin-left:10px;' class='fa-solid fa-sort-up'></i>");
    } else if (sorttype == "DESC") {
        $("#sort-type").val("ASC");
        $(obj).html(colname + " <i  style='margin-left:10px;' class='fa-solid fa-sort-down'></i>");
    }
    CommonFormList(1);
}


//FUNCTION FOR DELETE DOCUMENT UPLOAD LIST
function CommonFormDelete(e, FilePath) {
    try {
        var FormName = formname;
        var FilePath = FilePath;
        $.confirm({
            title: '',
            content: 'Are You Sure Want To Delete ?',
            type: 'red',
            boxWidth: '300px',
            useBootstrap: false,
            useBootstrap: false,
            columnClass: 'small',
            containerFluid: true,
            typeAnimated: true,
            buttons: {
                tryAgain: {
                    text: 'Confirm',
                    btnClass: 'btn-red',
                    action: function () {
                        const datastring = {};
                        datastring.DocUploadUId = parseInt(e);
                        datastring.fileName = FilePath;
                        datastring.MasterName = FormName;
                        //Showloader();
                        AjaxSubmission(JSON.stringify(datastring), "/Master/_Layout/CommonDocUploadFormDelete", $('[name="__RequestVerificationToken"]').val()).done(function (data) {
                            let obj = data;
                            if (obj.status == true) {
                                if (obj.responsecode == '102') {
                                    Toast(RetrieveMessage(obj.responsecode), "Message", "success");
                                    if (FormName == "Ledger") {
                                        CommonFormList('LedgerDocUpload LDU INNER JOIN document_type_master DTM ON DTM.doc_type_uid =LDU.DocTypeUid ', 'ldu.DocUploadUId, DTM.doc_type, LDU.FilePath,ldu.LedgerUid', 'FilePath');
                                    }

                                    if (FormName == "Job") {
                                        CommonFormList('JobDocUpload JDU INNER JOIN document_type_master DTM ON DTM.doc_type_uid =JDU.DocTypeUid', ' JDU.DocUploadUId, DTM.doc_type, JDU.FilePath,JDU.JobNo', 'FilePath');
                                    }
                                    if (FormName == "Voucher") {
                                        CommonFormList('VoucherDocUpload VDU INNER JOIN document_type_master DTM ON DTM.doc_type_uid =VDU.DocTypeUid', ' VDU.DocUploadUId, DTM.doc_type, VDU.FilePath,VDU.VoucherId', 'FilePath');
                                    }
                                }
                                else {
                                    Toast(RetrieveMessage(obj.responsecode), "Message", "error");
                                }
                            }
                            else {
                                window.location.href = 'ClientLogin/ClientLogin';
                            }
                            //Hideloader();
                        }).fail(function (data) {
                            console.log(data.Message);
                            //Hideloader();
                        });
                    }
                },
                close: function () {
                    //Hideloader();
                }
            }
        });
    }
    catch (e) {
        console.log(e.message);
        //Hideloader();
    }
}

//============================code end of document upload==================================================



//FUNCTION FOR FILL ICEGATEID
function FillIceGateId(DrpId,Default,IdClass) {
    try
    {
        AjaxSubmission(null, "/Master/_Layout/GetIceGateId", $('input[name=__RequestVerificationToken]').val()).done(function (result) {
            let obj = result;
            if (obj.status == true) {
                if (obj.responsecode == '100') {
                    BindDropdown(obj.data.Table, DrpId, 'IceGateIdMasterUid', 'IceGateId', Default, IdClass);
                }
                else if (obj.responsecode == '604') {                  
                    BindDropdown(null, DrpId, 'IceGateIdMasterUid', 'IceGateId', Default, IdClass);
                }
                //else {
                //    Toast(RetrieveMessage(obj.responsecode), "Message", "error");
                //}
            }
            HideLoader();
        }).fail(function (result) {
            console.log(result.Message);
            HideLoader();
        });
    }
    catch (e) {
        console.log(e.message);
        HideLoader();
    }
}

//FUNCTION FOR FILL FILLINVAPIID
function FillInvApiId(DrpId, Default, IdClass) {
    try {
        AjaxSubmission(null, "/Master/_Layout/GetInvApiId", $('input[name=__RequestVerificationToken]').val()).done(function (result) {
            let obj = result;
            if (obj.status == true) {
                if (obj.responsecode == '100') {
                    BindDropdown(obj.data.Table, DrpId, 'EInvoiceApiUid', 'EInvoiceApiName', Default, IdClass);
                }
                else if (obj.responsecode == '604') {
                    BindDropdown(null, DrpId, 'EInvoiceApiUid', 'EInvoiceApiName', Default, IdClass);
                }
                //else {
                //    Toast(RetrieveMessage(obj.responsecode), "Message", "error");
                //}
            }
            HideLoader();
        }).fail(function (result) {
            console.log(result.Message);
            HideLoader();
        });
    }
    catch (e) {
        console.log(e.message);
        HideLoader();
    }
}
//FUNCTION FOR BIND TEMPLATE NAME
function BindTemplateName(DrpID,TemplateType) {
    try {       
        const dataString = {};
        dataString.Condition = TemplateType;
        AjaxSubmission(JSON.stringify(dataString), "/Master/_Layout/BindTemplateName", $('input[name=__RequestVerificationToken]').val()).done(function (result) {
            let obj = result;
            if (obj.status == true) {
                if (obj.responsecode == '100') {
                    BindDropdown(obj.data.Table, DrpID, 'TemplateUid', 'TemplateName', '-----Select-----');
                }
                else if (obj.responsecode == '604') {
                    BindDropdown(null, DrpID, 'TemplateUid', 'TemplateName', '-----Select-----');
                }
                else {
                    Toast(RetrieveMessage(obj.responsecode), "Message", "error");
                }
            }
            HideLoader();
        }).fail(function (result) {
            console.log(result.Message);
            HideLoader();
        });
    }
    catch (e) {
        console.log(e.message);
        HideLoader();
    }
}
/*------------------------------------------------------------------Send Email Code Start ---------------------------------------------------------*/
//SEND EMAIL BUTTON CLICK 
$("#SendEmail").click(function () {
    var flag = 0
    var SendPDF = $("#SendPDF").is(":checked");   
    var FileName = "";
    var FileExtension = "";

    $('#TblEmailAttachment tbody tr').each(function (index, item) {

        if ($(this).find('.FileAttachment').prop('files')[0] != null) {

            FileName = $(this).find('.FileAttachment').prop('files')[0].name;
            FileExtension = FileName.substring(FileName.indexOf('.'), FileName.length);

            if ($(this).find('.FileAttachment').prop('files')[0].size / 1024 >= 3000) {
                Toast("File too Big, please select a file less than 1mb !", 'Message', 'error');
                flag = 1;
                return false;
            }
            for (var i = 0; i < _InvalidExtension.length; i++) {
                if (FileExtension == _InvalidExtension[i]) {
                    Toast("Invalid File selected !", 'Message', 'error');
                    //Toast("Invalid File selected .exe , .dll Files Not Allowed !", 'Message', 'error');
                    flag = 1;
                    return false;
                }
            }

        }
    });
    if (flag == 0) {
        if ($("#EmailTo").val().length == 0) {
            Toast("Please Enter To Email !", 'Message', 'error');
            return false;
        }
        SendEmail();
    }

});

//FUNCTION FOR SEND EMAIL 
function SendEmail() {
    try {
        let AllData = [];
        var editorContent_emailbody = tinyMCE.get('EmailBody').getContent();
        var msgcontent = window.btoa(editorContent_emailbody);

        $('[name="EmailBody"]').val(msgcontent);

        var RefId = $("#RefId").val();
        var EmailTo = $("#EmailTo").val();
        var EmailCC = $("#EmailCC").val();
        var EmailBody = $('[name = "EmailBody"]').val();
        var Subject = $("#Subject").val();
        var LetterName = $("#EmailLetterName").val();
        var AttachFileName = $("#AttachFileName").text();
        var SendPDF = $("#SendPDF").is(":checked");
        var SendToName = $("#SendToName").val();
        var RefName = $("#RefName").val();
        var mydata = new FormData();

        $('#TblEmailAttachment tbody tr').each(function (index, item) {
            var Attachment = "";
            if ($(this).find('.FileAttachment').prop('files')[0] == null) {

                Attachment = null;
            }
            else {
                Attachment = $(this).find('.FileAttachment').prop('files')[0].name;
            }
            mydata.append(Attachment, $(this).find('.FileAttachment').prop('files')[0]);
            var AllFields = {
                RefId: RefId,
                EmailTo: EmailTo,
                EmailCC: EmailCC,
                EmailBody: EmailBody,
                Subject: Subject,
                LetterName: LetterName,
                AttachFileName: AttachFileName,
                Attachment: Attachment,
                SendPDF: SendPDF,
                SendToName: SendToName,
                RefName: RefName
            };
            AllData.push(AllFields);
        });

        mydata.append('FilesData', JSON.stringify(AllData));

        console.log(mydata);
        ShowLoader();
        AjaxSubmissionformdata(mydata, "/Master/_Layout/SendEmail", $('input[name=__RequestVerificationToken]').val()).done(function (result) {
            let obj = result;            
            if (obj.status == true) {
                if (obj.responsecode == '100') {

                    Toast(RetrieveMessage(obj.responsecode), "Message", "success");
                }
                else {
                    Toast(RetrieveMessage(obj.responsecode), "Message", "error");
                }
            }
            else {
                window.location.href = '/ClientLogin/ClientLogin';
            }
            HideLoader();
        }).fail(function (result) {
            console.log(result.Message);
            HideLoader();
        });
    }
    catch (e) {
        console.log(e.message);
        HideLoader();
    }
}

//CLOSE MODEL BUTTON CLICK 
$("#EmailModelClose").click(function () {
    EmailModal.style.display = "none";
    $("#EmailTo").val('');
    $("#EmailCC").val('');
    tinymce.get("EmailBody").setContent("");
    $("#Subject").val('');
    $("#RefId").val('');
    $("#AttachFileName").text('');
    $("#SendToName").val('');
    $("#RefName").val('');
    AttachmentUploadResetdata();
});


$("#EmailClose").click(function () {
    EmailModal.style.display = "none";
    $("#EmailTo").val('');
    $("#EmailCC").val('');
    tinymce.get("EmailBody").setContent("");
    $("#Subject").val('');
    $("#RefId").val('');
    $("#AttachFileName").text('');
    $("#SendToName").val('');
    $("#RefName").val('');
    AttachmentUploadResetdata();
})




//ADD MORE ATTACHMENT CLICK
$("#AddAttachment").click(function () {
    $("#RemoveAttachment").removeAttr('disabled');

    var tbody = $("#TblEmailAttachment").find("tbody");
    var FirstTr = $(tbody).find("tr:first");
    var NewRow = $(FirstTr).clone();

    NewRow.find('.FileAttachment').val('');

    $("#TblEmailAttachment").find("tbody").append(NewRow);

    var LastTr = $(tbody).find("tr:last");
    LastTr.find('.FileAttachment').focus();
});

//FUNCTION FOR DELETE ROW FROM ADD MORE 
function DeleteAttachmentRow(obj) {
    var rowCount = $("#TblEmailAttachment tbody tr").length;
    if (rowCount > 1) {
        $(obj).parent().parent().remove();
    }
    else {
        //$("#RemoveAttachment").attr("disabled", "disabled");
        $('#FileAttachment').val('');
    }
}

//FUNCTION FOR RESET INPUT TYPE FIELD ATTACHMENT 
function AttachmentUploadResetdata() {
    var tbody = $("#TblEmailAttachment").find("tbody");
    var Tr = $(tbody).find("tr");
    var rowCount = Tr.length;
    if (rowCount > 1) {
        $("#TblEmailAttachment tbody tr").each(function (index, ele) {
            if (index > 0) {
                $(ele).remove();
            }
            else {
                $(ele).find('.FileAttachment').val('');
                $("#TblEmailAttachment").find("tbody").append(ele);
            }
        });
    }
    else {
        Tr.find('.FileAttachment').val('');
        $("#TblEmailAttachment").find("tbody").append(Tr);
    }
};
function CheckFile() {   
    var FileName = "";
    var FileExtension = "";

    $('#TblEmailAttachment tbody tr').each(function (index, item) {
        if ($(this).find('.FileAttachment').prop('files')[0] != null) {
            FileName = $(this).find('.FileAttachment').prop('files')[0].name;
            FileExtension = FileName.substring(FileName.lastIndexOf('.'), FileName.length);           
            for (var i = 0; i < _InvalidExtension.length; i++) {
                if (FileExtension.toLocaleLowerCase() == _InvalidExtension[i]) {
                    Toast("Invalid File selected !", 'Message', 'error');
                    $(item).find('#FileAttachment').val('');                  
                    return false;
                }
            }
        }
    });
}


/*------------------------------------------------------------------Send Email Code Start ---------------------------------------------------------*/

//var b = setInterval(() => {    
//    if ($('.page').width() < 1060) {
//        $("#olki").addClass('d-none');
//      /*  $("ftg").css('margin-left', 50);*/
//        /*document.getElementById("ftg").style.marginLeft = "50";*/
//    }
//    else {
//        //console.log('ds');
//        //document.getElementById("ftg").style.marginLeft = "219";
//        $("#olki").removeClass('d-none');
//    }
        
//},1000);

function NavItemsShow() {
    $("#SearchMenu").removeClass('d-none');
}

function OpenCloseSideNav(e) {
    if ($('#bar').hasClass('sv')) {
        $('#bar').removeClass('sv');
        $("#SearchMenu").removeClass('d-none');        
        openNav();
    } else {
        $('#bar').addClass('sv')        
        $("#SearchMenu").addClass('d-none');
        closeNav();
    }
}

var gt = $("#left-sidebar").width();
/*document.getElementById("ftg").style.marginLeft = (gt) + "px";*/
function openNav() {
    //$("#left-sidebar").removeClass('d-none');   
    $("#left-sidebar").removeClass('side-nav-animation-close');
    $("#left-sidebar").addClass('side-nav-animation-open');
    $("#ftg").removeClass('ftg-close');
    $("#ftg").addClass('ftg-open');
    //document.getElementById("ftg").style.marginLeft = ($("#left-sidebar").width()) + "px";
}
function closeNav() {
    //$("#left-sidebar").addClass('d-none');   
    $("#left-sidebar").addClass('side-nav-animation-close');
    $("#left-sidebar").removeClass('side-nav-animation-open');
    $("#ftg").addClass('ftg-close');
    $("#ftg").removeClass('ftg-open');
    //document.getElementById("ftg").style.marginLeft = "0";
}

/* LEDGER INFORMATION CODE START*/


var modal = document.getElementById('LedgerInformation');
var SearchLedgerModal = document.getElementById('SearchLedgerInformation');
var SearchJobModal = document.getElementById('SearchJobInformation');
var DocumentUploadModal = document.getElementById('modal-team');

$(document).keydown(function (event) {
    if (event.keyCode == 27) {
        modal.style.display = "none";
        DocumentUploadModal.style.display = "none";
    }
});

//FUNCTION FOR CLOSE DOCUMENT UPLOAD MODAL
function CloseDocumentUpload() {
    DocumentUploadModal.style.display = "none";
    $(".modal-backdrop").remove();
    $('body').removeClass('modal-open');
    $('body').removeAttr('style');
}

//WHEN THE USER CLICKS ANYWHERE OUTSIDE OF THE MODAL, CLOSE IT
window.onclick = function (event) {
    if (event.target == modal) {
        modal.style.display = "none";
        SearchLedgerModal.style.display = "none";
        SearchJobModal.style.display = "none";
      
    }
}

//FUNCTION FOR RESET LEDGER INFORMATION
function ResetLedgerInformation() {
    $('#ModalLedgerInformation tbody').find('tr:eq(0) td:eq(2)').text('');
    $('#ModalLedgerInformation tbody').find('tr:eq(1) td:eq(2)').text('');
    $('#ModalLedgerInformation tbody').find('tr:eq(2) td:eq(2)').text('');
    $('#ModalLedgerInformation tbody').find('tr:eq(3) td:eq(2)').text('');
    $('#ModalLedgerInformation tbody').find('tr:eq(4) td:eq(2)').text('');
    $('#ModalLedgerInformation tbody').find('tr:eq(5) td:eq(2)').text('');
    modal.style.display = 'none';
}

//FUNCTION FOR SEARCH RESET LEDGER INFORMATION
function SearchResetLedgerInformation() {
    $('#ModalSearchLedgerInformation tbody').find('tr:eq(0) td:eq(2)').text('');
    $('#ModalSearchLedgerInformation tbody').find('tr:eq(1) td:eq(2)').text('');
    $('#ModalSearchLedgerInformation tbody').find('tr:eq(2) td:eq(2)').text('');
    $('#ModalSearchLedgerInformation tbody').find('tr:eq(3) td:eq(2)').text('');
    $('#ModalSearchLedgerInformation tbody').find('tr:eq(4) td:eq(2)').text('');
    $('#ModalSearchLedgerInformation tbody').find('tr:eq(5) td:eq(2)').text('');
    SearchLedgerModal.style.display = 'none';
}

//FUNCTION FOR SEARCH RESET JOB INFORMATION
function ResetSearchJobInformation() {
    $('#TblSearchJob tbody').html('');
    $('#ModalTblBillDetails tbody').html('');
    $('#HiddenSearchModalJob').val('');
    SearchJobModal.style.display = 'none';
}
$(document).keydown(function (event) {
    if (event.keyCode == 27) {
        SearchLedgerModal.style.display = 'none';
        SearchJobModal.style.display = 'none';
        modal.style.display = 'none';
       
       
    }
})

//FUNCTION FOR OPEN LEDGER INFORMATION
function OpenLedgerInformation(e) {
    try {
      
        const dataString = {};
        dataString.LedgerUid = e;
        AjaxSubmission(JSON.stringify(dataString), '/Master/_Layout/GetLedgerInformation', $('input[name=__RequestVerificationToken]').val()).done(function (result) {
            let obj = result;
            if (obj.status == true) {
                if (obj.responsecode == '100') {                   
                    modal.style.display = 'block';

                    $('#ModalLedgerInformation tbody').find('tr:eq(0) td:eq(2)').text(HandleNullTextValue(obj.data.Table[0].AccHead));
                    $('#ModalLedgerInformation tbody').find('tr:eq(1) td:eq(2)').text(HandleNullTextValue(obj.data.Table[0].ContactPerson));
                    $('#ModalLedgerInformation tbody').find('tr:eq(2) td:eq(2)').text(HandleNullTextValue(obj.data.Table[0].Mobile));
                    $('#ModalLedgerInformation tbody').find('tr:eq(3) td:eq(2)').text(HandleNullTextValue(obj.data.Table[0].AltMobile));
                    $('#ModalLedgerInformation tbody').find('tr:eq(4) td:eq(2)').text(HandleNullTextValue(obj.data.Table[0].Email));
                    $('#ModalLedgerInformation tbody').find('tr:eq(5) td:eq(2)').text(HandleNullTextValue(obj.data.Table[0].CCEmail));

                    $("#LdContactDetails thead tr").html('');
                    $('#LBCDetails').css('display', 'none');
                    $("#LdContactDetails tbody").html('');
                    if (obj.data.Table1.length > 0) {
                        $('#LBCDetails').css('display', 'block');
                        $("#LdContactDetails thead tr").html('<th class=" text-capitalize bg-transparent text-center" style="width:80px;">Branch Name</th><th class=" text-capitalize bg-transparent text-center" style="width:80px;">Contact Person</th><th class=" text-capitalize bg-transparent text-center" style = "width:150px;" > Mobile</th><th class=" text-capitalize bg-transparent text-center" style="width:200px;">Emai Id</th>');
                        for (i = 0; i < obj.data.Table1.length; i++) {
                            tr = $('<tr/>');
                            tr.append("<td class='text-center'>" + HandleNullTextValue(obj.data.Table1[i].BranchName) + "</td>");
                            tr.append("<td class='text-center'>" + HandleNullTextValue(obj.data.Table1[i].ContactPerson) + "</td>");
                            tr.append("<td class='text-center'>" + HandleNullTextValue(obj.data.Table1[i].Mobile) + "</td>");
                            tr.append("<td class='text-center'>" + HandleNullTextValue(obj.data.Table1[i].Email) + "</td>");
                            $("#LdContactDetails tbody").append(tr);

                        }
                    }
                }
            } else
                window.location.href = '/ClientLogin/ClientLogin';
        }).fail(function (result) {
            console.log(result.message);
        });
    }
    catch (e) {
        console.log(e.message);
    }
}

function OpenDynamicModal() {    
    if ($('#HiddenTypeLedgJob').val() == 'Ledger')
        SearchOpenLedgerInformation($('#HiddenSrchLedgJob').val());
    if ($('#HiddenTypeLedgJob').val() == 'Job')
        SearchOpenJobInformation($('#HiddenSrchLedgJob').val());
    if ($('#HiddenTypeLedgJob').val() == 'Menu') {       
        window.open($('#HiddenSrchLedgJob').val(),'_blank');
    }
}
//$('#SrchLedgJob').on('blur', function () {
//    alert('dsdsds');
//    if ($('#HiddenTypeLedgJob').val() == 'Ledger') 
//        SearchOpenLedgerInformation($('#HiddenSrchLedgJob').val());
//    if ($('#HiddenTypeLedgJob').val() == 'Job') 
//        SearchOpenJobInformation($('#HiddenSrchLedgJob').val());
//});
       
$('#SrchLedgJob').on('keypress', function (e) {
    if (e.keyCode == 13) {
        if ($('#HiddenTypeLedgJob').val() == 'Ledger')
            SearchOpenLedgerInformation($('#HiddenSrchLedgJob').val());
        if ($('#HiddenTypeLedgJob').val() == 'Job')
            SearchOpenJobInformation($('#HiddenSrchLedgJob').val());
        if ($('#HiddenTypeLedgJob').val() == 'Menu') {
          
            window.location.href = $('#HiddenSrchLedgJob').val();
        }
            
    }
    
});

//FUNCTION FOR SEARCH OPEN JOB INFORMATION
function SearchOpenJobInformation(e) {
    try {       
        const dataString = {};
        dataString.JobUid = e;
        AjaxSubmission(JSON.stringify(dataString), '/Master/_Layout/GetIndividualSearchJobInformation', $('input[name=__RequestVerificationToken]').val()).done(function (result) {
            let obj = result;
            if (obj.status == true) {
                if (obj.responsecode == '100') {
                    ResetSearchJobInformation();
                    SearchJobModal.style.display = 'block';                  
                    $('#HiddenTypeLedgJob').val('');
                    $('#HiddenSrchLedgJob').val('');
                    $('#SrchLedgJob').val('');
                    $('#HiddenSearchModalJob').val(obj.data.Table[0].JobUid);


                    $('#ModalJobclientInformation tbody').find('tr:eq(0) td:eq(2)').html("<a href='javascript:void(0)' class='text-decoration-none' style='color: black !important;font-weight:bold;' onclick='GoToLedgerEdit(\"" + HandleNullTextValue(obj.data.Table[0].ClientId) + "\"); window.open(\"/Master/Ledger/Ledger\")'>" + HandleNullTextValue(obj.data.Table[0].ClientName) + "</a>");

                   /* $('#ModalJobclientInformation tbody').find('tr:eq(0) td:eq(2)').text(HandleNullTextValue(obj.data.Table[0].ClientName));*/
                    $('#ModalJobclientInformation tbody').find('tr:eq(1) td:eq(2)').text(HandleNullTextValue(obj.data.Table[0].BranchName));
                    $('#ModalJobclientInformation tbody').find('tr:eq(2) td:eq(2)').text(HandleNullTextValue(obj.data.Table[0].ContactPerson));
                    $('#ModalJobclientInformation tbody').find('tr:eq(3) td:eq(2)').text(HandleNullTextValue(obj.data.Table[0].Mobile));
                    $('#ModalJobclientInformation tbody').find('tr:eq(4) td:eq(2)').text(HandleNullTextValue(obj.data.Table[0].Email));
                   

                    //$('#ModalJobOthersInformation tbody').find('tr:eq(0) td:eq(2)').text(HandleNullTextValue(obj.data.Table[0].Shipper));06
                    $('#ModalJobOthersInformation tbody').find('tr:eq(0) td:eq(2)').html("<a href='javascript:void(0)' class='text-decoration-none' style='color: black !important;font-weight:bold;' onclick='GoToLedgerEdit(\"" + HandleNullTextValue(obj.data.Table[0].Shipper) + "\"); window.open(\"/Master/Ledger/Ledger\")'>" + HandleNullTextValue(obj.data.Table[0].ShipperName) + "</a>");

                    //$('#ModalJobOthersInformation tbody').find('tr:eq(1) td:eq(2)').text(HandleNullTextValue(obj.data.Table[0].Indentor));
                    $('#ModalJobOthersInformation tbody').find('tr:eq(1) td:eq(2)').html("<a href='javascript:void(0)' class='text-decoration-none' style='color: black !important;font-weight:bold;' onclick='GoToLedgerEdit(\"" + HandleNullTextValue(obj.data.Table[0].Indentor) + "\"); window.open(\"/Master/Ledger/Ledger\")'>" + HandleNullTextValue(obj.data.Table[0].IndentorName) + "</a>");

                    //$('#ModalJobOthersInformation tbody').find('tr:eq(2) td:eq(2)').text(HandleNullTextValue(obj.data.Table[0].ShippingLine));
                    $('#ModalJobOthersInformation tbody').find('tr:eq(2) td:eq(2)').html("<a href='javascript:void(0)' class='text-decoration-none' style='color: black !important;font-weight:bold;' onclick='GoToLedgerEdit(\"" + HandleNullTextValue(obj.data.Table[0].ShippingLine) + "\"); window.open(\"/Master/Ledger/Ledger\")'>" + HandleNullTextValue(obj.data.Table[0].ShippingLineName) + "</a>");

                    //$('#ModalJobOthersInformation tbody').find('tr:eq(3) td:eq(2)').text(HandleNullTextValue(obj.data.Table[0].CFS));
                    $('#ModalJobOthersInformation tbody').find('tr:eq(3) td:eq(2)').html("<a href='javascript:void(0)' class='text-decoration-none' style='color: black !important;font-weight:bold;' onclick='GoToLedgerEdit(\"" + HandleNullTextValue(obj.data.Table[0].CFSType) + "\"); window.open(\"/Master/Ledger/Ledger\")'>" + HandleNullTextValue(obj.data.Table[0].CFSName) + "</a>");

                    //$('#ModalJobOthersInformation tbody').find('tr:eq(4) td:eq(2)').text(HandleNullTextValue(obj.data.Table[0].HSSeller));
                    $('#ModalJobOthersInformation tbody').find('tr:eq(4) td:eq(2)').html("<a href='javascript:void(0)' class='text-decoration-none' style='color: black !important;font-weight:bold;' onclick='GoToLedgerEdit(\"" + HandleNullTextValue(obj.data.Table[0].HSSeller) + "\"); window.open(\"/Master/Ledger/Ledger\")'>" + HandleNullTextValue(obj.data.Table[0].HSSellerName) + "</a>");
                    

                    tr = $('<tr/>');
                    tr.append("<td class='text-center'><a href='javascript:void(0)' class='text-decoration-none' style='color: black !important; font-weight:bold;' onclick='GoToJob(\"HiddenSearchModalJob\");'>" + HandleNullTextValue(obj.data.Table[0].JobNo) + "</a></td>");
                    tr.append("<td class='text-center'>" + HandleNullTextValue(obj.data.Table[0].JobDate) + "</td>");
                    tr.append("<td class='text-center'>" + HandleNullTextValue(obj.data.Table[0].BENo) + "</td>");
                    tr.append("<td class='text-center'>" + HandleNullTextValue(obj.data.Table[0].BEDate) + "</td>");

                    tr.append("<td class='text-center'>" + HandleNullTextValue(obj.data.Table[0].Container) + "</td>");
                    tr.append("<td class='text-center'>" + HandleNullTextValue(obj.data.Table[0].Bales) + "</td>");
                    tr.append("<td class='text-end'>" + (obj.data.Table[0].TotalNetWeight == null ? 0.00 : obj.data.Table[0].TotalNetWeight.toFixed(3)) + "</td>");
                    tr.append("<td class='text-end'>" + (obj.data.Table[0].TotalGrossWeight == null ? 0.00 : obj.data.Table[0].TotalGrossWeight.toFixed(2)) + "</td>");
                    tr.append("<td class='text-end'>" + (obj.data.Table[0].TotalInvoiceValue == null ? 0.00 : obj.data.Table[0].TotalInvoiceValue.toFixed(2)) + "</td>");
                    tr.append("<td class='text-end'>" + (obj.data.Table[0].DutyAmount == null ? 0.00 : obj.data.Table[0].DutyAmount.toFixed(2)) + "</td>");

                    $("#TblSearchJob tbody").append(tr);
                    tr = $('<tr/>');
                    if (obj.data.Table1 != null) {
                        var TBillAmount = 0;
                        if (obj.data.Table1.length > 0) {
                            for (i = 0; i < obj.data.Table1.length; i++) {                               
                                tr = $('<tr/>');                               
                               
                                if (obj.data.Table1[i].Editable == 1) {
                                    tr.append("<td class='text-center'><a href='javascript:void(0)' class='text-decoration-none' style='color: black !important; font-weight:bold;' onclick='GoToModalBillDetails(\"" + obj.data.Table1[i].BillUid + "\");'>" + HandleNullTextValue(obj.data.Table1[i].BillNo) + "</a></td>");
                                } else {
                                    tr.append("<td class='text-center' style='color: black !important; font-weight:bold;'>" + HandleNullTextValue(obj.data.Table1[i].BillNo) + "</td>");
                                }
                               /* tr.append("<td class='text-center'><a href='javascript:void(0)' class='text-decoration-none' style='color: black !important; font-weight:bold;' onclick='GoToModalBillDetails(\"" + obj.data.Table1[i].BillUid + "\");'>" + HandleNullTextValue(obj.data.Table1[i].BillNo) + "</a></td>");*/
                                tr.append("<td class='text-center'>" + HandleNullTextValue(obj.data.Table1[i].BillDate) + "</td>");
                                tr.append("<td class='text-center'>" + HandleNullTextValue(obj.data.Table1[i].BillTypeName) + "</td>");                               
                                tr.append("<td class='text-center'>" + HandleNullTextValue(obj.data.Table1[i].AccHead) + "</td>");
                                tr.append("<td class='text-end'>" + HandleNullTextValueFixed(obj.data.Table1[i].BillTotalAmount, 2) + "</td>");
                                //tr.append("<td class='text-end'>" + HandleNullTextValueFixed(obj.data.Table1[i].TaxAmount, 2) + "</td>");
                                //tr.append("<td class='text-end'>" + HandleNullTextValueFixed(obj.data.Table1[i].NetAmount, 2) + "</td>");
                                TBillAmount += obj.data.Table1[i].BillTotalAmount;
                                $("#ModalTblBillDetails tbody").append(tr);

                                if (i == obj.data.Table1.length - 1) {
                                    tr = $('<tr/>');
                                    //tr.append("<td class='text-center'></td>");
                                    //tr.append("<td class='text-center'></td>");
                                    //tr.append("<td class='text-center'></td>");
                                    tr.append("<td class='text-end' colspan='4'></td>");
                                    tr.append("<td class='text-end' style='color: black !important; font-weight:bold;'>" + HandleNullTextValueFixed(TBillAmount, 2)+"</td>");

                                    $("#ModalTblBillDetails tbody").append(tr);
                                }
                               
                            }
                        } else {
                            tr = $('<tr/>');
                            tr.append("<td class='text-center' colspan='5'>NO RECORDS FOUND</td>");
                            $("#ModalTblBillDetails tbody").append(tr);                           
                        }
                    }

                  
                    $('#SearchEditJob').focus();
                }
            }
            else
                window.location.href = '/ClientLogin/ClientLogin';
        }).fail(function (result) {
            console.log(result.message);
        });
    }
    catch (e) {
        console.log(e.message);
    }
}

//FUNCTION FOR GOTOMODALBILLDETAILS
function GoToModalBillDetails(e) {
    localStorage.setItem('PageName', 'Bill Entry');
    localStorage.setItem('LinkSelected', 'sub/Master/BillEntry/BillEntry');
    SetCookie('BillEntryUid', e, 's', 50);
    window.open('/Master/BillEntry/BillEntry', '_blank');
}
//FUNCTION FOR SEARCH OPEN LEDGER INFORMATION
function SearchOpenLedgerInformation(e) {
    try {
      
        const dataString = {};
        dataString.LedgerUid = e;
        AjaxSubmission(JSON.stringify(dataString), '/Master/_Layout/GetIndividualSearchLedgerInformation', $('input[name=__RequestVerificationToken]').val()).done(function (result) {
            let obj = result;
            if (obj.status == true) {
                if (obj.responsecode == '100') {                  
                    //$('#HiddenTypeLedgJob').val('');
                    //$('#HiddenSrchLedgJob').val('');
                    //$('#SrchLedgJob').val('');
                    SearchLedgerModal.style.display = 'block';
                    $('#HiddenSrchLedgName').val(obj.data.Table[0].AccHead);                  
                    /* $('#ModalSearchLedgerInformation tbody').find('tr:eq(0) td:eq(2)').text(HandleNullTextValue(obj.data.Table[0].AccHead));*/
                    $('#ModalSearchLedgerInformation tbody').find('tr:eq(0) td:eq(2)').html("<a href='javascript:void(0)' id='LgName' class='text-decoration-none' style='color: black !important;font-weight:bold;' onclick='GoToLedgerEdit(\"" + HandleNullTextValue(obj.data.Table[0].LedgerUid) + "\"); window.open(\"/Master/Ledger/Ledger\")'>" + HandleNullTextValue(obj.data.Table[0].AccHead) + "</a>");
                    $('#ModalSearchLedgerInformation tbody').find('tr:eq(1) td:eq(2)').text(HandleNullTextValue(obj.data.Table[0].ContactPerson));
                    $('#ModalSearchLedgerInformation tbody').find('tr:eq(2) td:eq(2)').text(HandleNullTextValue(obj.data.Table[0].Mobile));
                    $('#ModalSearchLedgerInformation tbody').find('tr:eq(3) td:eq(2)').text(HandleNullTextValue(obj.data.Table[0].AltMobile));

                    $('#ModalSearchLedgerInformationOther tbody').find('tr:eq(0) td:eq(2)').text(HandleNullTextValue(obj.data.Table[0].Email));
                    $('#ModalSearchLedgerInformationOther tbody').find('tr:eq(1) td:eq(2)').text(HandleNullTextValue(obj.data.Table[0].CCEmail));
                    $('#ModalSearchLedgerInformationOther tbody').find('tr:eq(2) td:eq(2)').text(HandleNullTextValue(obj.data.Table[0].NotificationEmailId));
                    //$('#ModalSearchLedgerInformationOther tbody').find('tr:eq(3) td:eq(2)').text(HandleNullTextValue(' Rs.' + obj.data.Table4[0].CurrentBalance));
                    $('#ModalSearchLedgerInformationOther tbody').find('tr:eq(3) td:eq(2)').html("<a href='javascript:void(0)' class='text-decoration-none fw-bold text-facebook' onclick='GoToLedgerReport(\"" + HandleNullTextValue(obj.data.Table[0].AccHead) + "\",\"" + HandleNullTextValue(obj.data.Table[0].LedgerUid) + "\");'>" + HandleNullTextValue(' Rs.' + (obj.data.Table4[0].CurrentBalance == null ? '0.00' : obj.data.Table4[0].CurrentBalance)) + "</a>");

                    //$('#ModalSearchLedgerInformationOther tbody').find('tr:eq(3) td:eq(2)').html("<a href='javascript:void(0)' class='text-decoration-none' style='color: red !important;font-weight:bold;' onclick='GoToLedgerReport(\"" + HandleNullTextValue(obj.data.Table[0].AccHead)+"\",\"" + HandleNullTextValue(obj.data.Table[0].LedgerUid) + "\"); window.open(\"/Master/LedgerReport/LedgerReport\");'></a>";);

                    $("#SearchLdContactDetails thead tr").html('');
                    $('#SearchLBCDetails').css('display', 'none');
                    $("#SearchLdContactDetails tbody").html('');
                    if (obj.data.Table1.length > 0) {
                        $('#SearchLBCDetails').css('display', 'block');
                        $("#SearchLdContactDetails thead tr").html('<th class=" text-capitalize bg-transparent text-center" style="width:80px;">Branch Name</th><th class=" text-capitalize bg-transparent text-center" style="width:80px;">Contact Person</th><th class=" text-capitalize bg-transparent text-center" style = "width:150px;" > Mobile</th><th class=" text-capitalize bg-transparent text-center" style="width:200px;">Emai Id</th>');

                        for (i = 0; i < obj.data.Table1.length; i++) {
                            tr = $('<tr/>');
                            tr.append("<td class='text-left'>" + HandleNullTextValue(obj.data.Table1[i].BranchName) + "</td>");
                            tr.append("<td class='text-left'>" + HandleNullTextValue(obj.data.Table1[i].ContactPerson) + "</td>");
                            tr.append("<td class='text-left'>" + HandleNullTextValue(obj.data.Table1[i].Mobile) + "</td>");
                            tr.append("<td class='text-center'>" + HandleNullTextValue(obj.data.Table1[i].Email) + "</td>");
                            $("#SearchLdContactDetails tbody").append(tr);

                        }
                    }

                    $('#TotalImportJob').html(obj.data.Table3[0].TotalImportJob);
                    $('#TotalImportBilledJob').html(obj.data.Table3[0].TotalImportBilledJob);
                    $('#TotalImportPendingJob').html(obj.data.Table3[0].TotalImportPendingJob);
                    $('#TotalImportUnBilledJob').html(obj.data.Table3[0].TotalImportUnbilledJob);

                    $('#TotalExportJob').html(obj.data.Table3[0].TotalExportJob);
                    $('#TotalExportBilledJob').html(obj.data.Table3[0].TotalExportBilledJob);
                    $('#TotalExportPendingJob').html(obj.data.Table3[0].TotalExportPendingJob);
                    $('#TotalExportUnBilledJob').html(obj.data.Table3[0].TotalExportUnbilledJob);
                    $('#TotalPurchaseValue').html(obj.data.Table3[0].TotalPurchaseValue.toFixed(2));

                    var BlHtml = '';
                    if (obj.data.Table2.length > 0) {
                        for (i = 0; i < obj.data.Table2.length; i++) {                         
                            BlHtml += '<div class="col-sm-6 col-lg-3"><a href =javascript:void(0) onclick=GoToBillSearch("HiddenSrchLedgJob","HiddenSrchLedgName",'+obj.data.Table2[i].BillTypeUid+');> <div class="card card-sm card-shadow"><div class="card-body"><div class="row align-items-center"><div class="col-auto"><span class="bg-blue text-white avatar"><img src="/Images/total_bill.png" /></span></div><div class="col"><div class="font-weight-medium">Total ' + obj.data.Table2[i].BillTypeName + '</div> <div id="TotalBill" class="text-muted">' + (obj.data.Table2[i].TotalAmount == null ? 0.00 : obj.data.Table2[i].TotalAmount.toFixed(2)) + '</div></div></div></div></div> </a></div>';
                        }
                    }
                    $('#AllBl').html(BlHtml);

                    /*$('#CBal').text(' Rs.' + obj.data.Table4[0].CurrentBalance);*/
                    $('#SearchLedgerInformationClose').focus();
                }
            } else
                window.location.href = '/ClientLogin/ClientLogin';
        }).fail(function (result) {
            console.log(result.message);
        });
       
        
    }
    catch (e) {
        console.log(e.message);
    }
}

//FUNCTION FOR GOTOBILLSEARCH
function GoToBillSearch(id, Lname, Type) {   
    //console.log($("#" + id).val());
    //console.log($('#' + Lname).val());
    localStorage.setItem('PageName', 'Bill Entry');
    localStorage.setItem('LinkSelected', 'sub/Master/BillEntry/BillEntry');

    SetCookie('LId', $("#" + id).val(), 's', 50);
    SetCookie('LName', $('#' + Lname).val(), 's', 50);
    SetCookie('BillType', Type, 's', 50);
    window.open('/Master/BillEntry/BillEntry', '_blank');
}
//FUNCTION FOR GOTOLEDGEREDIT
function GoToLedgerEdit(id) {
    localStorage.setItem('PageName', 'Ledger Master');
    localStorage.setItem('LinkSelected', 'sub/Master/Ledger/Ledger');
    SetCookie('LedgerId', id, 's', 50);
}

//FUNCTION FOR GOTOPURCHASE
function GoToPurchase() {
    localStorage.setItem('PageName', 'Purchase Entry');
    localStorage.setItem('LinkSelected', 'sub/Master/PurchaseEntry/PurchaseEntry');
    /*SetCookie('LedgerPurchaseSearch', $('#ModalSearchLedgerInformation tbody tr').find('td:nth-child(3)').text());*/
    SetCookie('LedgerPurchaseSearch', $('#ModalSearchLedgerInformation tbody tr').find('#LgName').text());
    window.open('/Master/PurchaseEntry/PurchaseEntry', '_blank');
}
//FUNCTION FOR GOTOLEDGERREPORT
function GoToLedgerReport(e,E1) {
    SetCookie('LedgerGroupName', e, 's', 50);
    SetCookie('LedgerGroupId', E1, 's', 50);
    window.open('/Master/LedgerReport/LedgerReport', '_blank');
}
//FUNCTION FOR LEDGER INFORMATION POPUP
function LedgerInformationPopup(event,e) {
    if (event.altKey && event.key === "h") {
        OpenLedgerInformation($('#'+e).val());
    }
}
/* LEDGER INFORMATION CODE END*/

// FILL TEMPLATE DATA IN TINCY MCE
function FillTemplateDataInTincyMce(Uid, TemplateFor,TemplateUid,TemplateType,Type) {
    try {
        const dataString = {};       
        dataString.Uid = Uid;       
        dataString.TemplateFor = TemplateFor;
        dataString.TemplateUid = TemplateUid;
        dataString.Condition = TemplateType;      
        dataString.Type = Type;
        AjaxSubmission(JSON.stringify(dataString), '/_Layout/GetTemplateData', $('[name="__RequestVerificationToken"]').val()).done(function (result) {
            let obj = result;
            if (obj.status == true) {
                if (obj.responsecode == '100') {

                    if ($('#AllTemplate').val() != null && $('#AllTemplate') != undefined) {
                        $('#AllTemplate').val(obj.data.Table[0].TemplateUid);
                        $('#Subject').val(obj.data.Table[0].EmailSubject);
                        tinymce.get("EmailBody").setContent(obj.data.Table[0].EmailBody);
                    }
                    if ($('#ScheduleTempalte').val() != null && $('#ScheduleTempalte') != undefined) {
                        $('#ScheduleTempalte').val(obj.data.Table[0].TemplateUid);
                        $('#ScheduleSubject').val(obj.data.Table[0].EmailSubject);
                        tinymce.get("ScheduleBody").setContent(obj.data.Table[0].EmailBody);
                    }

                }
            }
            else
                window.location.href = '/ClientLogin/ClientLogin';           

        }).fail(function (result) {          
            console.log(result.message);
        });
    }
    catch (e) {       
        console.log(e.message);
    }
}


//FUNCTION FOR GO TO IMPORT JOB
function GoToSearchImportJob(e, Type, Status) {
    localStorage.setItem('PageName','Import Job');
    localStorage.setItem('LinkSelected','sub/Master/ImportJobEntry/ImportJobEntry');
    SetCookie('ClientId', $("#" + e).val(), 's', 50);
    SetCookie('HiddenSrchLedgName', $('#HiddenSrchLedgName').val(), 's', 50);
    SetCookie('SearchFrmDate', '', 's', 50);
    SetCookie('SearchToDate', '', 's', 50);
    if (Type != null && Type != undefined && Type != '') {
        SetCookie('Type', Type, 's', 50);
    }
    window.open('/Master/ImportJobEntry/ImportJobEntry');
}

//FUNCTION FOR GO TO EXPORT JOB
function GoToSearchExportJob(e, Type, Status) {
    localStorage.setItem('PageName', 'Export Job');
    localStorage.setItem('LinkSelected', 'sub/Master/ExportJobEntry/ExportJobEntry');
    SetCookie('ClientId', $("#" + e).val(), 's', 50);
    SetCookie('HiddenSrchLedgName', $('#HiddenSrchLedgName').val(), 's', 50);
    SetCookie('SearchFrmDate', '', 's', 50);
    SetCookie('SearchToDate', '', 's', 50);
    if (Type != null && Type != undefined && Type != '') {
        SetCookie('Type', Type, 's', 50);
    }
    window.open('/Master/ExportJobEntry/ExportJobEntry');
}

//FUNCTION FOR GO TO JOB EDIT
function GoToJob(e) {
    localStorage.setItem('PageName', 'Import Job');
    localStorage.setItem('LinkSelected', 'sub/Master/ImportJobEntry/ImportJobEntry');
    SetCookie('JobUid', $("#" + e).val(), 's', 50);
    window.open('/Master/ImportJobEntry/ImportJobEntry');
}

//FUNCTION FOR GO TO CHECKLIST
function OpenCheckList(e) {   
    try {
        const datastring = {};
        datastring.JobUid = $('#' + e).val();
        AjaxSubmission(JSON.stringify(datastring), "/Master/ImportJobEntry/DownloadCheckList", $('input[name=__RequestVerificationToken]').val()).done(function (result) {
            let obj = result;
            if (obj.status == true) {
                if (obj.responsecode == '100')
                    window.open($("#SearchCheckListPdf").attr('href'), '_blank');
                else
                    Toast(RetrieveMessage(obj.responsecode), "Message", "error");
            }
            else
                window.location.href = '/ClientLogin/ClientLogin';           
        }).fail(function (result) {
            console.log(result.Message);           
        });
    }
    catch (e) {      
        console.log(e.message);
    }
}


function checkkey(zEvent) {

   if (zEvent.keyCode == 40) {
        if (linkarr.length > 0) {
            if (kecoun < linkarr.length)
                kecoun++;
            else
                kecoun = 1;

            $('#sidebar-menu li:visible a[id]:visible').each(function (ind, ele) {
                if (ele.href == linkarr[kecoun-1]) 
                    $(ele).css('background-color', 'rgb(219, 228, 240)');
                else {
                    $(ele).css('background-color', 'transparent');
                }
                console.log(ele.href);
            })

        }
   }
   else if (zEvent.keyCode == 38) {
        if (linkarr.length > 0) {
            if (kecoun < linkarr.length)
                kecoun--;
            else
                kecoun = 1;

            //alert(kecoun);
            $('#sidebar-menu li:visible a[id]:visible').each(function (ind, ele) {
                if (ele.href == linkarr[kecoun+1])
                    $(ele).css('background-color', 'rgb(219, 228, 240)');
                else {
                    $(ele).css('background-color', 'transparent');
                }
                console.log(ele.href);
            })
        }
    }
    else if (zEvent.keyCode == 13) {
        console.log(kecoun);
        console.log(linkarr);
        
        //window.location.href = linkarr[kecoun-1];
    }

}

document.addEventListener("keydown", function (zEvent) {
   
    if (zEvent.ctrlKey && (zEvent.key == "f" || zEvent.key == "F"))         
        $('#SrchLedgJob').focus();
    if (zEvent.ctrlKey && (zEvent.key == "j" || zEvent.key == "J")) 
        $('#SearchMenu').focus();    
});

var thy = '<header class="navbar navbar-expand-md navbar-light d-print-none" style="min-height: 1.0rem !important;background - color: #043570!important; ">< div class="container-xl"><button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbar-menu"> span class="navbar-toggler-icon text-white"></span></button></div></header><div class="navbar-expand-md"> div class="collapse navbar-collapse" id="navbar-menu"><div class="navbar navbar-light"><div class="container-xl" style="justify-content: space-around;"><ul class="navbar-nav" id="navbar-top" style="margin-left: 7px;"><li class="nav-item"><a href="/Home/Dashboard"><img src="~/Images/SanCHA Logo.png" alt="SAN CHA" class="navbar-brand-image image_tag"></a></li></ul><div class="row" id="fgt"><div class="col-md-4 mt-1"><select id="SetCompany" name="SetCompany" class="form-select form-select-md SetCompany mybox" style="max-width: 140px;"> </select></div><div class="col-md-4 mt-1"><select id="SetFinancialYear" name="SetFinancialYear" class="form-select form-select-md SetFinancialYear mybox"></select></div><div class="col-md-4 mt-1"><div class="navbar-nav flex-row order-md-last"><div class="nav-item dropdown"><a href="#" class="nav-link d-flex lh-1 text-reset p-0" data-bs-toggle="dropdown" aria-label="Open user menu"><i class="fa-solid fa-user"></i><div class="d-none d-xl-block ps-2"><div>@{try{if (HttpContext.Current.Session["ClientSession"] != null){SAN_CHA.Models.ClientSessionModel userSession = (SAN_CHA.Models.ClientSessionModel)Session["ClientSession"];<input type="hidden" id="TmpClientTmp" value="@userSession.ClientID" /><label id="userid" style="display: none;">@userSession.UserID</label><span style="color: rgb(43, 59, 85); font-size:15px !important">@userSession.UserName</span><label id="dsdsds" style="display:none;">@Session["Selectcompany"]</label>}}catch (Exception){}}</div></div></a><div class="dropdown-menu dropdown-menu-end dropdown-menu-arrow"><a href="javascript:void(0);" onclick="ChangeSessionLayout();" class="dropdown-item"><span class="nav-link-icon d-md-none d-lg-inline-block"><i class="fa-solid fa-dice-d20" style="color: rgb(43, 59, 85); margin-left: 8px;"></i></span><span class="nav-link-title" style="color: rgb(43, 59, 85);margin-left: 4px;margin-top: 3px;"> Change Layout</span></a><a href="javascript:void(0);" onclick="logout();" class="dropdown-item"><span class="nav-link-icon d-md-none d-lg-inline-block"><i class="fa-solid fa-lock" style="color: rgb(43, 59, 85); margin-left: 8px;"></i></span><span class="nav-link-title" style="color: rgb(43, 59, 85);margin-left: 4px;margin-top: 3px;"> Logout</span></a></div></div</div></div></div></div></div></div></div><div class="page-wrapper" style="background-color:white;"><div class="container-xl"></div><div class="page-body px-4 bg-white"><div class="p-2 ">@{if (Session["qwer"].ToString() == "Horizontal-Layout"){<div class="p-2 ">@RenderBody()</div>}}</div></div></div>';

$('#PLO').html(thy);


//FUNCTION FOR CALCULATE RUNNING BALANCE 
function CalculateCurrentBalance(e) {
    try {
        const dataString = {};
        dataString.LedgerUid = $(e).parent().find('.HiddenLedgerId').val();
        AjaxSubmission(JSON.stringify(dataString), '/_Layout/CalculateCurrentBalance', $('[name="__RequestVerificationToken"]').val()).done(function (result) {
            let obj = result;
            if (obj.status == true) {
                $(e).parent().parent().find('.CurBalance').val('');
                $(e).parent().parent().find('.CurBalance').val(obj.data.Table[0].Current_Balance);
            }
            else
                window.location.href = '/ClientLogin/ClientLogin';

        }).fail(function (result) {
            console.log(result.message);
        });
    }
    catch (e) {
        console.log(e.message);
    }
}

/*================CODE FOR MODAL BILL ADJUSTMENT==========================================================*/
//let Firstcolumn = "";
var DefaultSelectedBranch = "";
var BillAdjustMentModal = document.getElementById('BillAdjustMentModal');

var UsedRef = [];
// ADD MORE BILL ADJUSTMENT ENTRY DROPDOWN GRID 
$("#modalAddMorePayment").click(function () {
    UsedRef = [];
    $("#modalBillAdjustment_Table tbody tr").each(function () {
        UsedRef.push($(this).find('.modalReferenceNo').val());
    });
    $("#modalRemovePayment").removeAttr('disabled');
    var tbody = $("#modalBillAdjustment_Table").find("tbody");
    var FirstTr = $(tbody).find("tr:first");
    FirstTr.find('.modalDate').datepicker("destroy");
    FirstTr.find('.modalDate').removeAttr("id");
    var NewRow = $(FirstTr).clone();
    $("#modalBillAdjustment_Table").find("tbody").append(NewRow);
    NewRow.find('.HiddenmodalReferenceNo').val('');
    NewRow.find('.modalReferenceNo').val('');
    NewRow.find('.modalCurBalance').val('');
    NewRow.find('.gridParticular').val('');
    NewRow.find('.modalDate').val('');
    NewRow.find('.modalAdjAmount').val('0.00');
    NewRow.find('.modalAmount').val('0.00');
    NewRow.find('.modalTotalBalAmount').val('0.00');
    NewRow.find('.modalRemovePayment').val('');
    var LastTr = $(tbody).find("tr:last");
    LastTr.find('.modalReferenceNo').focus();
    $(".datepickerAll2").datepicker('setDate', 'today');
    AutoSuggestionForBillAdjustMentBottomGridList();
});

// DELETE BILL ADJUSTMENT ENTRY DROPDOWN GRID ROW
function DeleteRowBill(obj) {
    var rowCount = $("#modalBillAdjustment_Table tbody tr").length;
    if (rowCount > 1) {
        $(obj).parent().parent().remove();
    }
    else if (rowCount == 1) {
        var tbody = $("#modalBillAdjustment_Table").find("tbody");
        var Tr = $(tbody).find("tr");
        var rowCount = Tr.length;
        if (rowCount > 1) {
            $("#modalBillAdjustment_Table tbody tr").each(function (index, ele) {
                if (index > 0) {
                    $(ele).remove();
                }
                else {
                    $(ele).find('.HiddenmodalReferenceNo').val('');
                    $(ele).find('.modalReferenceNo').val('');
                    $(ele).find('.gridParticular').val('');
                    $(ele).find('.modalDate').val('');
                    $(ele).find('.modalAmount').val('0.00');
                    $(ele).find('.modalAdjAmount').val('0.00');
                    $(ele).find('.modalTotalBalAmount').val('0.00');
                    $("#modalBillAdjustment_Table").find("tbody").append(ele);
                }
            });
        }
        else {
            Tr.find('.HiddenmodalReferenceNo').val('');
            Tr.find('.modalReferenceNo').val('');
            Tr.find('.gridParticular').val('');
            Tr.find('.modalDate').val('');
            Tr.find('.modalAmount').val('0.00');
            Tr.find('.modalAdjAmount').val('0.00');
            Tr.find('.modalTotalBalAmount').val('0.00');
            $("#modalBillAdjustment_Table").find("tbody").append(Tr);
        }
    }
    else {
        $("#modalRemovePayment").attr("disabled", "disabled");
    }
}

// PAYMENT MODE BUTTON ON CHANGE FUNCTION 
$(" input[name='type3']").click(function () {
    var checkval = $('input:radio[name=type3]:checked').val();
    if (checkval == "modalPaymentAdjustType") {
        $(".modalVoucherNo").show();
        $(".modalVoucherDate").show();
        $(".modalBillNo").hide();
        $(".modalBillDate").hide();
    }
    else if (checkval == "modalBilltAdjustType") {
        $(".modalVoucherNo").hide();
        $(".modalVoucherDate").hide();
        $(".modalBillNo").show();
        $(".modalBillDate").show();
    }

});

$(".modalReferenceNo").keypress(function () {
    AutoSuggestionForBillAdjustMentBottomGridList();
});
// RESET DATA FOR BILL ADJUSTMENT MODAL
function ResetDataBillAdjModal() {
    $("#modalUnderGroup").val("");
    $("#modalParty").val("");
    $("#ModalPartyUid").val("");
    $("#modalVoucherNo").val("");
    /* $("#modalVoucherDate").val("");*/
    $("#modalBillNo").val("");
    $("#modalBillDate").val("");
    $("#modalBillAmount").val("0.00");
    $("#modalBalAmount").val("0.00");
    $("#RefAccHead").val("");
    $("#MdlParticular").val("");
    var tbody = $("#modalBillAdjustment_Table").find("tbody");
    var Tr = $(tbody).find("tr");
    var rowCount = Tr.length;
    if (rowCount > 1) {
        $("#modalBillAdjustment_Table tbody tr").each(function (index, ele) {
            if (index > 0) {
                $(ele).remove();
            }
            else {
                $(ele).find('.HiddenmodalReferenceNo').val('');
                $(ele).find('.modalReferenceNo').val('');
                $(ele).find('.gridParticular').val('');
                $(ele).find('.modalDate').val('');
                $(ele).find('.modalAmount').val('0.00');
                $(ele).find('.modalAdjAmount').val('0.00');
                $(ele).find('.modalTotalBalAmount').val('0.00');
                $("#modalBillAdjustment_Table").find("tbody").append(ele);
            }
        });
    }
    else {
        Tr.find('.HiddenmodalReferenceNo').val('');
        Tr.find('.modalReferenceNo').val('');
        Tr.find('.gridParticular').val('');
        Tr.find('.modalDate').val('');
        Tr.find('.modalAmount').val('0.00');
        Tr.find('.modalAdjAmount').val('0.00');
        Tr.find('.modalTotalBalAmount').val('0.00');
        $("#modalBillAdjustment_Table").find("tbody").append(Tr);
    }
}

//ON CLICK FUNCTION FOR CLOSE BUTTON
$("#ModalBillAdjustmentClose1").click(function () {
    BillAdjustMentModal.style.display = "none";
    ResetDataBillAdjModal();
});

//ON CLICK FUNCTION FOR CLOSE BUTTON
$("#ModalBillAdjustmentClose").click(function () {
    BillAdjustMentModal.style.display = "none";
    ResetDataBillAdjModal();
});

// ON CLICK BUTTON FOR ADD OR UPDATE MODAL BILL ADJUSTMENT
$("#ModalBillAdjustmentSave").click(function () {
    var flag = 0;
    var AdjAmt = 0;
    var Amt = 0;
    var TotalBalAmt = 0.00;
    var BillAmount = $("#modalBillAmount").val();
    if ($("#modalVoucherNo").val() == "") {
        Toast("Please Enter Voucher No !", 'Message', 'error');
        return;
    }
    if ($("#modalVoucherDate").val() == "") {
        Toast("Please Select Voucher Date !", 'Message', 'error');
        return;
    }
    if (($("#modalBillAmount").val() == "0.00") || ($("#modalBillAmount").val() == "")) {
        Toast("The Bill Amount Field Must Contain a Number Greater Than 0 ", 'Message', 'error');
        return;
    }
    $("#modalBillAdjustment_Table tbody tr").each(function (index, ele) {
        var rowCount = $("#modalBillAdjustment_Table tbody tr").length;
        if (rowCount > 1)
        {
            if ($(ele).find('.HiddenmodalReferenceNo').val().length == 0) {
                Toast("Please Enter Ref No", 'Message', 'error');
                flag = 1;
                return false;
            }
            if ($(ele).find('.modalReferenceNo').val() == '') {
                Toast("Please Enter Ref No", 'Message', 'error');
                flag = 1;
                return false;
            }
        }
        if ($(ele).find('.Amount').val() == '0.00') {
            Toast("Please Enter Amount!", 'Message', 'error');
            flag = 1;
            return false;
        }
        if ($(ele).find('.modalAdjAmount').val() != null) {
            AdjAmt = AdjAmt + parseFloat($(ele).find('.modalAdjAmount').val());
        }
        if (AdjAmt > BillAmount) {
            Toast("Adjusted Amount Should Be Less Than Or Equal Bill Amount!", 'Message', 'error');
            flag = 1;
            return false;
        }
        if ($(ele).find('.modalAmount').val() != null) {
            Amt = Amt + parseFloat($(ele).find('.modalAmount').val());
        }
        if (AdjAmt > Amt) {
            Toast("Sorry you cannot not add more than the balance amount!!", 'Message', 'error');
            flag = 1;
            return false;
        }
        if ($(ele).find('.modalTotalBalAmount ').val() != null) {
            TotalBalAmt = TotalBalAmt + parseFloat($(ele).find('.modalTotalBalAmount ').val());
        }
        //if ((TotalBalAmt > '0.00') && (TableCount > 0)) {
        //        if (AdjAmt > TotalBalAmt) {
        //            Toast("Sorry you cannot not add more than the Total balance amount!!", 'Message', 'error');
        //            flag = 1;
        //            return false;
        //        }
        //}

    });
    if (flag == 0) {
        var rowCount = $("#modalBillAdjustment_Table tbody tr").length;
        var modalReferenceNo = $("#modalReferenceNo").val();
        if ((rowCount == 1) && (modalReferenceNo == '')) {
            DeleteBillAdjustMent();
        }
        else {
            if ((TableCount > 0)) {
                UpdateBillAdjustMent();
            }
            else if ((TableCount == 0)) {
                AddBillAdjustMent();
            }
        }

    }
});


// AUTO SUGGEST FUNCTION FOR BOTTOM GRID 
function AutoSuggestionForBillAdjustMentBottomGridList() {
    var BillNo = $("#modalVoucherNo").val();
    $.widget('custom.tableAutocomplete', $.ui.autocomplete, {
        options: {
            open: function (event, ui) {
                // Hack to prevent a 'menufocus' error when doing sequential searches using only the keyboard
                $('.ui-autocomplete .ui-menu-item:first').trigger('mouseover');
            }
        },
        _create: function () {
            this._super();
            // Using a table makes the autocomplete forget how to menu.
            // With this we can skip the header row and navigate again via keyboard.
            this.widget().menu("option", "items", ".ui-menu-item");
        },
        _renderMenu: function (ul, items) {
            var self = this;
            var $table = $('<table class="table-autocomplete table table-bordered  table-sm">'),
                $thead = $('<thead>'),
                $headerRow = $('<tr>'),
                $tbody = $('<tbody>');
            $.each(self.options.columns, function (index, columnMapping) {
                $('<th>').text(columnMapping.title).appendTo($headerRow);
            });
            $thead.append($headerRow);
            $table.append($thead);
            $table.append($tbody);
            ul.html($table);
            $.each(items, function (index, item) {
                self._renderItemData(ul, ul.find("table tbody"), item);
            });
        },
        _renderItemData: function (ul, table, item) {
            return this._renderItem(table, item).data("ui-autocomplete-item", item);
        },
        _renderItem: function (table, item) {
            var self = this;
            var $tr = $('<tr class="ui-menu-item a" role="presentation">');

            $.each(self.options.columns, function (index, columnMapping) {
                var cellContent = !item[columnMapping.field] ? '' : item[columnMapping.field];
                $('<td>').text(cellContent).appendTo($tr);
            });

            $tr.hover(function () {
                $(this).addClass('ui-state-hover');
            }, function () {
                $(this).removeClass('ui-state-hover');
            });


            return $tr.appendTo(table);
            console.log(table);
        }
    });
    $(function () {
        $('.modalReferenceNo').tableAutocomplete({
            source: function (request, response) {
                $.ajax({
                    type: 'POST',
                    url: "/_Layout/FillBillAdjustmentAutocomplete",
                    dataType: "json",
                    async: false,
                    data: { RefNo: request.term, BillLedgerUid: $("#ModalPartyUid").val(), BalanceBills: $(".BalanceBillCLS").is(':checked') == true ? true : false, AdjustType: $("#modalPaymentAdjustType").val(), BillNo: BillNo, UsedRef: UsedRef },
                    success: function (result) {
                        response($.map(result.data.Table, function (LedgerName) {
                            return {
                                label: LedgerName.AccDesc,
                                value: LedgerName.BillNo,
                                id: LedgerName.TrUid,
                                BillNo: LedgerName.BillNo,
                                Particular: LedgerName.Particular,
                                Amount: LedgerName.BillAmount,
                                AdjustedAmount: LedgerName.AdjustedAmount,
                                BillDate: LedgerName.BillDate,
                                ChequeDate: LedgerName.ChequeDate,
                                ChequeNo: LedgerName.ChequeNo,
                                RowNum: LedgerName.RowNum,
                                FinyrId: LedgerName.FinyrId,
                                LedgerUid2: LedgerName.LedgerUid2,
                                PendingAmount: LedgerName.PendingAmount,
                                TotalAmount: LedgerName.TotalAmount,
                            }
                        }));
                    }
                });
            },
            minlength: 1,
            autofocus: true,
            selectfirst: true,
            selectOnly: true,
            columns: [{
                field: 'BillNo',
                title: 'Ref. No.'
            }, {
                field: 'Particular',
                title: 'Particular'
            }, {
                field: 'Amount',
                title: 'Amount'
            }, {
                field: 'AdjustedAmount',
                title: 'Adjt Amount'
            }, {
                field: 'BillDate',
                title: 'Date'
            }, {
                field: 'ChequeNo',
                title: 'Cheque No'
            }, {
                field: 'ChequeDate',
                title: 'Cheque Date'
            }],
            delay: 500,
            select: function (event, ui) {
                if (ui.item != undefined) {
                    $(this).val(ui.item.value);
                    var parentTr = $(this).parents('tr');
                    parentTr.find(".HiddenmodalReferenceNo").val(HandleNullTextValue(ui.item.id));
                    parentTr.find(".HiddenmodalLedgerUid").val(HandleNullTextValue(ui.item.LedgerUid2));
                    parentTr.find(".HiddenmodalFinyrId").val(HandleNullTextValue(ui.item.FinyrId));
                    parentTr.find(".modalReferenceNo").val(HandleNullTextValue(ui.item.BillNo));
                    parentTr.find(".gridParticular").val(HandleNullTextValue(ui.item.Particular));
                    parentTr.find(".modalAmount").val(HandleNullTextValue(ui.item.Amount));
                 //   parentTr.find(".modalAdjAmount").val(HandleNullTextValue(ui.item.AdjustedAmount));
                    parentTr.find(".modalAdjAmount").val(HandleNullTextValue(ui.item.PendingAmount));
                    parentTr.find(".modalDate").val(HandleNullTextValue(ui.item.BillDate));
                    //parentTr.find(".modalTotalBalAmount").val(HandleNullTextValueFixed(ui.item.TotalAmount, 2));
                 //   parentTr.find(".modalTotalBalAmount").val(HandleNullTextValueFixed(ui.item.PendingAmount));
                    parentTr.find(".modalTotalBalAmount ").val(HandleNullTextValue(ui.item.TotalAmount));
                    CalculateTotalBalnceAmount();
                   
                }
                return false;
            }
        });
    });
};

// FUNCTION FOR ADD BILL ADJUSTMENT
function AddBillAdjustMent() {
    try {

        const dataString = {};
        dataString.FinyrId = $("#ModalFinancialYear").val();
        dataString.LedgerUId = $("#ModalPartyUid").val();
        dataString.LedgerId = $("#HiddenAccHeadId").val();
        dataString.RefNo1 = $("#modalVoucherNo").val();
        dataString.Date1 = $("#modalVoucherDate").val();
        dataString.TrxnId1 = $('#ModalTrUid').val();
        dataString.LedgerUid2 = $('#ModalRefUid').val();
        // alert(dataString.LedgerUid2 = $('#ModalRefUid').val());
        var BillAdj = new Array();
        $("#modalBillAdjustment_Table tbody tr").each(function () {
            var BillAdjDetail = {};
            BillAdjDetail.TrxnId2 = $(this).find(".HiddenmodalReferenceNo").val();
            BillAdjDetail.RefNo2 = $(this).find(".modalReferenceNo").val();
            BillAdjDetail.Date2 = $(this).find(".modalDate").val();
            BillAdjDetail.TrxnFinyrId = $(this).find(".HiddenmodalFinyrId").val();
            BillAdjDetail.Amount = $(this).find(".modalAdjAmount").val();
            BillAdjDetail.LedgerUid2 = $(this).find(".HiddenmodalLedgerUid").val();
            BillAdj.push(BillAdjDetail);
        });
        dataString.billAdjustMentGridModels = BillAdj;
        AjaxSubmission(JSON.stringify(dataString), '/_Layout/AddBillAdjustMent', $('input[name=__RequestVerificationToken]').val()).done(function (result) {
            let obj = result;
            if (obj.status == true) {
                if (obj.responsecode == '101') {
                    ResetDataBillAdjModal();
                    AdjustPayment();
                    /* EditBillAdjustMent();*/
                    Toast(RetrieveMessage(obj.responsecode), "Message", "success");
                }
                else {
                    Toast(RetrieveMessage(obj.responsecode), "Message", "error");
                }
            }
            else {
                window.location.href = '/ClientLogin/ClientLogin';
            }
            //Hideloader();
        }).fail(function (result) {
            console.log(result.Message);
            //Hideloader();
        });
    }
    catch (e) {
        console.log(e.message);
        //Hideloader();
    }
}

// FUNCTION FOR EDIT BILL ADJUSTMENT
function EditBillAdjustMent() {
    try {
        const dataString = {};
        dataString.RefNo1 = $("#modalVoucherNo").val();
        dataString.Date1 = $("#modalVoucherDate").val();
        AjaxSubmission(JSON.stringify(dataString), '/_Layout/EditBillAdjustMent', $('input[name=__RequestVerificationToken]').val()).done(function (result) {
            let obj = result;          
            if (obj.status == true) {
                if (obj.responsecode == '100') {
                    TableCount = obj.data.Table1[0].ROWCOUNT1;
                    AmountCheck = obj.data.Table[0].adjustamount;
                    var FirstChild = $("#modalBillAdjustment_Table").find("tbody tr:first-child");
                    var BillAdjTableData = obj.data.Table;
                    $.each(BillAdjTableData, function (index, ele) {
                        if (index == 0) {
                            FirstChild.find('.HiddenmodalFinyrId').val(ele.FinyrId);
                            FirstChild.find('.HiddenmodalReferenceNo').val(ele.TrxnId1);
                            FirstChild.find('.modalReferenceNo').val(ele.RefNo1);
                            FirstChild.find('.modalDate').val(ele.Date1);
                            FirstChild.find('.modalAdjAmount').val(ele.adjustamount.toFixed(2));
                            FirstChild.find('.modalAmount ').val(ele.TotalAmt.toFixed(2));
                            FirstChild.find('.modalTotalBalAmount ').val(ele.TotalBalAMT.toFixed(2));
                            FirstChild.find('.HiddenmodalLedgerUid ').val(ele.LedgerUid2);
                        }
                        else {
                            var CloneChild = FirstChild.clone();
                            //FirstChild.find('.HiddenmodalFinyrId').val('');
                            //FirstChild.find('.HiddenmodalReferenceNo').val('');
                            //FirstChild.find('.modalReferenceNo').val('');
                            //FirstChild.find('.modalDate').val('');
                            //FirstChild.find('.modalAdjAmount').val('');
                            //FirstChild.find('.modalAmount').val('');
                            CloneChild.find('.HiddenmodalFinyrId').val(ele.FinyrId);
                            CloneChild.find('.HiddenmodalReferenceNo').val(ele.TrxnId1);
                            CloneChild.find('.modalReferenceNo').val(ele.RefNo1);
                            CloneChild.find('.modalDate').val(ele.Date1);
                            CloneChild.find('.modalAdjAmount').val(ele.adjustamount.toFixed(2));
                            CloneChild.find('.modalAmount').val(ele.TotalAmt.toFixed(2));
                            CloneChild.find('.modalTotalBalAmount ').val(ele.TotalBalAMT.toFixed(2));
                            CloneChild.find('.HiddenmodalLedgerUid ').val(ele.LedgerUid2);
                            $("#modalBillAdjustment_Table tbody").append(CloneChild);
                        }
                    });
                }
                else {
                    Toast(RetrieveMessage(obj.responsecode), "Message", "error");
                }
            }
            else {
                window.location.href = '/ClientLogin/ClientLogin';
            }
            //Hideloader();
        }).fail(function (result) {
            console.log(result.Message);
            //Hideloader();
        });
    }
    catch (e) {
        console.log(e.message);
        //Hideloader();
    }
}

//FUNCTION FOR UPDATE BILL ADJUSTMENT
function UpdateBillAdjustMent() {
    try {
        const dataString = {};
        dataString.FinyrId = $("#ModalFinancialYear").val();
        dataString.LedgerUId = $("#ModalPartyUid").val();
        dataString.LedgerId = $("#HiddenAccHeadId").val();
        dataString.RefNo1 = $("#modalVoucherNo").val();
        dataString.Date1 = $("#modalVoucherDate").val();
        dataString.TrxnId1 = $('#ModalTrUid').val();
        dataString.LedgerUid2 = $('#ModalRefUid').val();
        var BillAdj = new Array();
        $("#modalBillAdjustment_Table tbody tr").each(function () {
            var BillAdjDetail = {};
            BillAdjDetail.TrxnId2 = $(this).find(".HiddenmodalReferenceNo").val();
            BillAdjDetail.RefNo2 = $(this).find(".modalReferenceNo").val();
            BillAdjDetail.Date2 = $(this).find(".modalDate").val();
            BillAdjDetail.TrxnFinyrId = $(this).find(".HiddenmodalFinyrId").val();
            BillAdjDetail.Amount = $(this).find(".modalAdjAmount").val();
            BillAdjDetail.LedgerUid2 = $(this).find(".HiddenmodalLedgerUid").val();
            BillAdj.push(BillAdjDetail);
        });
        dataString.billAdjustMentGridModels = BillAdj;
        AjaxSubmission(JSON.stringify(dataString), '/_Layout/UpdateBillAdjustMent', $('input[name=__RequestVerificationToken]').val()).done(function (result) {
            let obj = result;
            if (obj.status == true) {
                if (obj.responsecode == '107') {
                    ResetDataBillAdjModal();
                    AdjustPayment();
                    Toast(RetrieveMessage(obj.responsecode), "Message", "success");
                }
                else {
                    Toast(RetrieveMessage(obj.responsecode), "Message", "error");
                }
            }
            else {
                window.location.href = '/ClientLogin/ClientLogin';
            }
            //Hideloader();
        }).fail(function (result) {
            console.log(result.Message);
            //Hideloader();
        });
    }
    catch (e) {
        console.log(e.message);
        //Hideloader();
    }
}

//FUNCTION FOR UPDATE BILL ADJUSTMENT
function DeleteBillAdjustMent() {
    try {
        const dataString = {};
        dataString.RefNo1 = $("#modalVoucherNo").val();
        AjaxSubmission(JSON.stringify(dataString), '/_Layout/DeleteBillAdjustMent', $('input[name=__RequestVerificationToken]').val()).done(function (result) {
            let obj = result;
            if (obj.status == true) {
                if (obj.responsecode == '102') {
                    ResetDataBillAdjModal();
                    AdjustPayment();
                    Toast(RetrieveMessage(obj.responsecode), "Message", "success");
                }
                else {
                    Toast(RetrieveMessage(obj.responsecode), "Message", "error");
                }
            }
            else {
                window.location.href = '/ClientLogin/ClientLogin';
            }
            //Hideloader();
        }).fail(function (result) {
            console.log(result.Message);
            //Hideloader();
        });
    }
    catch (e) {
        console.log(e.message);
        //Hideloader();
    }
}
//FUNCTION FOR CALCULATE TOTAL BALANCE AMOUNT IN BILL ADJUSTMENT
function CalculateTotalBalnceAmount() {
    $("#modalBillAdjustment_Table tbody tr").each(function (index, ele) {
        var Amt = $(ele).find('.modalAmount').val();
        if ($(ele).find('.modalAmount').val() > 0) {
            var Amt1 = Amt - parseFloat($(ele).find('.modalAdjAmount ').val());
            $(ele).find('.modalTotalBalAmount').val(Amt1);
        }
    });
};

/*================END CODE FOR MODAL BILL ADJUSTMENT==========================================================*/

/*================NEW FUNCTION CREATED BY PRINCE START=========================================================*/

//FUNCTION FOR GO TO LEDGER
function GoToLedger(e) {
    SetCookie('LedgerId', $("#" + e).val(), 's', 50);
   
}

//FUNCTION FOR GO TO LEDGER FOR CLASS
function GoToLedgerForClass(e, ClsName) {
    SetCookie('LedgerId', $(e).parent().parent().find('.' + ClsName).val(), 's', 50);
}

/*================NEW FUNCTION CREATED BY PRINCE END===========================================================*/

//#region  SCHEDULE REPORT MODEL FUNCTION  START 

$(document).ready(function () {
    GetEmailIdByComapanySetup('ScheduleEmailAccountName');
  
    $(".datepickerAllScheduleModel").datepicker('setDate', 'today');
    $('#ScheduleFixed').click(function () {
        $('.MultipleView').addClass('d-none');
        $('.EmailView').removeClass('d-none');
        $('#ScheduleMultiple').prop('checked', false);
    });

    $('#ScheduleMultiple').click(function () {
        $('.MultipleView').removeClass('d-none');
        // $('.EmailView').addClass('d-none');
        $('#ScheduleFixed').prop('checked', false);
    });

});


//CLOSE MODEL BUTTON CLICK 
$("#ScheduleReportModelClose").click(function () {
    ScheduleReportModal.style.display = "none";
    tinymce.get("ScheduleBody").setContent("");
     ResetScheduleReportForm();
});
$("#ScheduleReportClose").click(function () {
    ScheduleReportModal.style.display = "none";
    tinymce.get("ScheduleBody").setContent("");
    ResetScheduleReportForm();
})

$("#ScheduleReport1").click(function () {
    if ($("#ScheduleReportName").val() == "") {
        Toast('Please Select Report Name !', 'Message', 'error');
        return;
    }
    if ($("#ScheduleReportRepeat").val() == "Select") {
        Toast('Please Select Repeat Frequency !', 'Message', 'error');
        return;
    }
    if ($("#ScheduleTempalte").val() == "0") {
        Toast('Please Select Template Name !', 'Message', 'error');
        return;
    }
    if ($("#ScheduleEmailAccountName").val() == "0") {
        Toast('Please Select Email Account Name !', 'Message', 'error');
        return;
    }

    if ($("#ScheduleSubject").val() == "") {
        Toast('Please enter Subject !', 'Message', 'error');
        return;
    }
    AddScheduleReport();
});

// FUNCTION FOR ADD SCHEDULE REPORT 
function AddScheduleReport() {
    try {
        var editorContent_scheduleBody = tinyMCE.get('ScheduleBody').getContent();
        var msgcontent = window.btoa(editorContent_scheduleBody);
        $('[name="ScheduleBody"]').val(msgcontent);
        const dataString = {};
        dataString.ScheduleReportName = $("#ScheduleReportName").val();
        dataString.ReportFrequency = $("#ScheduleReportRepeat").val();
        dataString.Condition_1 = $("#ScheduleReportCondition1").val();
        dataString.Condition_2 = $("#ScheduleReportConditionNumberDays").val();
        dataString.Condition_3 = $("#ScheduleReportCondition2").val();
        dataString.ReportFrom1 = $("#ScheduleStartDate").val();
        dataString.ReportTo1 = $("#ScheduleEndDate").val();
        dataString.EmailTimeFrom = $("#ScheduleFrom").val();
        dataString.EmailTimeTo = $("#ScheduleTo").val();
        dataString.TemplateId = $("#ScheduleTempalte").val();
        dataString.EmailSubject = $("#ScheduleSubject").val();
        dataString.EmailAccount = $("#ScheduleEmailAccountName").val();
        dataString.SendToOption = $("input[name='ScheduleFixed_Multiple']:checked").val();
     
        dataString.Fixed_EmailTo = $("#ScheduleEmailTo").val();
        dataString.Fixed_EmailCc = $("#ScheduleEmailCC").val();
        dataString.Fixed_EmailBcc = $("#ScheduleEmailBcc").val();

        dataString.MultipleSendTo = $("#ScheduleMultipleMessage").val();
        dataString.EmailBody = $('[name = "ScheduleBody"]').val();
        dataString.ProcedureParameter = $("#ScheduleQueryCondition").val();
        dataString.ScheduleFormName = $("#ScheduleFormName").val();
        dataString.OccursAt = $("#ScheduleOccursAt").val();
        dataString.WeekDay = $("input[name='ScheduleDays']:checked").val();
        dataString.FrequencyDD = $("#FrequencyDD").val();
        dataString.FrequencyMM = $("#FrequencyMM").val();

        dataString.ScheduleEmailToClient = $("#ScheduleEmailToClient").is(':checked') ? 1 : 0;
        dataString.ScheduleEmailToShipper = $("#ScheduleEmailToShipper").is(':checked') ? 1 : 0;
        dataString.ScheduleEmailToIndenter = $("#ScheduleEmailToIndenter").is(':checked') ? 1 : 0;
        dataString.ScheduleEmailToShippingLine = $("#ScheduleEmailToShippingLine").is(':checked') ? 1 : 0;
        dataString.ScheduleEmailToHSSeller = $("#ScheduleEmailToHSSeller").is(':checked') ? 1 : 0;
        dataString.ScheduleEmailToCFS = $("#ScheduleEmailToCFS").is(':checked') ? 1 : 0;
        console.log(JSON.stringify(dataString));
        AjaxSubmission(JSON.stringify(dataString), '/_Layout/AddScheduleReport', $('input[name="__RequestVerificationToken"]').val())
            .done(function (result) {
                let obj = result;
                if (obj.status) {
                    if (obj.responsecode === '101') {
                        ResetScheduleReportForm();
                        Toast(RetrieveMessage(obj.responsecode), "Message", "success");
                    } else {
                        Toast(RetrieveMessage(obj.responsecode), "Message", "error");
                    }
                } else {
                    window.location.href = '/ClientLogin/ClientLogin';
                }
            })
            .fail(function (result) {
                console.log(result.responseText);
                // Handle error
            });

    } catch (e) {
        console.log(e.message);
        // Handle exception
    }
}

function uncheckOtherRadios(clickedRadio,RadioName) {
    let radios = document.getElementsByName(RadioName);
    radios.forEach(function (radio) {
        if (radio !== clickedRadio) {
            radio.checked = false;
        }
    });
}
function ResetScheduleReportForm() {
    $("#ScheduleFormName").val('');
    $("#ScheduleReportName").val('');
    $("#ScheduleReportRepeat").val('Select');
    $("#ScheduleReportCondition1").val('Select');
    $("#ScheduleReportConditionNumberDays").val('1');
    $("#FrequencyDD").val('1');
    $("#FrequencyMM").val('1');
    $("#ScheduleReportCondition3").val('Select');
    $("#ScheduleStartDate").val('');
    $("#ScheduleEndDate").val('');
    $("#ScheduleFrom").val('');
    $("#ScheduleTo").val('');
    $("#ScheduleTempalte").val('0');
    $("#ScheduleSubject").val('');
    $("#ScheduleEmailAccountName").val('0');
    $("input[name='ScheduleFixed'][value='Fixed']").prop('checked', true);
    $("#ScheduleEmailTo").val('');
    $("#ScheduleEmailCC").val('');
    $("#ScheduleEmailBcc").val('');
    $("#ScheduleMultipleMessage").val('');
    $("#ScheduleBody").val('');
    $("#ScheduleOccursAt").val('');
    $("input[name='ScheduleDays']").prop('checked', false);

    var editor = tinymce.get('ScheduleBody');

    if (editor) {
        editor.setContent(''); // Set the content to empty string
    }
    $("input[name='ScheduleEmailToClient']").prop('checked', false);
    $("input[name='ScheduleEmailToShipper']").prop('checked', false);
    $("input[name='ScheduleEmailToIndenter']").prop('checked', false);
    $("input[name='ScheduleEmailToShippingLine']").prop('checked', false);
    $("input[name='ScheduleEmailToHSSeller']").prop('checked', false);
    $("input[name='ScheduleEmailToCFS']").prop('checked', false);

    //$("input[name='ScheduleEmailCcClient']").prop('checked', false);
    //$("input[name='ScheduleEmailCcShipper']").prop('checked', false);
    //$("input[name='ScheduleEmailCcIndenter']").prop('checked', false);
    //$("input[name='ScheduleEmailCcShippingLine']").prop('checked', false);
    //$("input[name='ScheduleEmailCcHSSeller']").prop('checked', false);
    //$("input[name='ScheduleEmailCcCFS']").prop('checked', false);
}

$('#ScheduleReportRepeat').change(function () {
    let selectedValue = $(this).val();
    $('#OccursAtSection').hide();
    $('#FrequencySection').hide();
    $('#DaysSection').hide();
    if (selectedValue === 'DoesNotRepeat' || selectedValue === 'Daily')
        $('#OccursAtSection').show();
    if (selectedValue === 'Weekly')
        $('#DaysSection').show();
        $('#OccursAtSection').show();
    if (selectedValue === 'Monthly') {
        $('#OccursAtSection').show();
        $('#FrequencySection').show();
    }
       
});

//#endregion 
