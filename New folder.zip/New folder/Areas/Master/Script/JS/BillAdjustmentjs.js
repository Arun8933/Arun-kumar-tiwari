﻿
var Firstcolumn = "";
var DefaultSelectedBranch = "";
// DOCUMENT READY
$(document).ready(function () {
    GetGroupListAcceptAddressWise('UnderGroup');
    $(".datepickerAll").datepicker({
        changeMonth: true,
        changeYear: true,
        dateFormat: 'dd/mm/yy'
    });
    $(".datepickerAll1").datepicker({
        changeMonth: true,
        changeYear: true,
        dateFormat: 'dd/mm/yy'
    });
})
var UsedRef = [];
// ADD MORE VOUCHER ENTRY DROPDOWN GRID 
$("#AddMorePayment").click(function () {
    UsedRef = [];
    $("#BillAdjustment_Table tbody tr").each(function () {
        UsedRef.push($(this).find('.ReferenceNo').val());
    });
    $("#RemovePayment").removeAttr('disabled');
    var tbody = $("#BillAdjustment_Table").find("tbody");
    var FirstTr = $(tbody).find("tr:first");
    FirstTr.find('.Date').datepicker("destroy");
    FirstTr.find('.Date').removeAttr("id");

    var NewRow = $(FirstTr).clone();
    NewRow.find('.ReferenceNo').val('');
    NewRow.find('.Particular').val('');
    NewRow.find('.CurBalance').val('');
    NewRow.find('.Particular').val('');
    NewRow.find('.Date').val('');
    NewRow.find('.Amount').val('0.00');
    NewRow.find('.AdjAmount').val('0.00');
    NewRow.find('.TotalBalAmount').val('0.00');
    NewRow.find('.RemovePayment').val('');
    $("#BillAdjustment_Table").find("tbody").append(NewRow);
    var LastTr = $(tbody).find("tr:last");

    LastTr.find('.ReferenceNo').focus();
    $(".datepickerAll2").datepicker('setDate', 'today');
    AutoSuggestionForBillAdjustMentBtmGridList();

});

// DELETE BILL ADJUSTMENT DROPDOWN GRID ROW
function DeleteBillAdjRow(obj) {
    var rowCount = $("#BillAdjustment_Table tbody tr").length;
    if (rowCount > 1) {
        $(obj).parent().parent().remove();
    }

    else if (rowCount == 1) {
        var tbody = $("#BillAdjustment_Table").find("tbody");
        var Tr = $(tbody).find("tr");
        var rowCount = Tr.length;
        if (rowCount > 1) {
            $("#BillAdjustment_Table tbody tr").each(function (index, ele) {
                if (index > 0) {
                    $(ele).remove();
                }
                else {
                    $(ele).find('.HiddenReferenceNo').val('');
                    $(ele).find('.ReferenceNo').val('');
                    $(ele).find('.GridParticular').val('');
                    $(ele).find('.Date').val('');
                    $(ele).find('.Amount').val('0.00');
                    $(ele).find('.AdjAmount').val('0.00');
                    $(ele).find('.TotalBalAmount').val('0.00');
                    $("#BillAdjustment_Table").find("tbody").append(ele);
                }
            });
        }
        else {
            Tr.find('.HiddenReferenceNo').val('');
            Tr.find('.ReferenceNo').val('');
            Tr.find('.GridParticular').val('');
            Tr.find('.Date').val('');
            Tr.find('.Amount').val('0.00');
            Tr.find('.AdjAmount').val('0.00');
            Tr.find('.TotalBalAmount').val('0.00');
            $("#BillAdjustment_Table").find("tbody").append(Tr);
        }
    }
    else {
        $("#RemovePayment").attr("disabled", "disabled");
    }
}
// PAYMENT MODE BUTTON ON CHANGE FUNCTION 
function PaymentModeButtonClickFunction() {
    if ($('input:radio[name="AdjType"]:checked').val() == "1") {
        $(".VoucherNo").show();
        $(".VoucherDate").show();
        $(".BillNo").hide();
        $(".BillDate").hide();
    }
    else if ($('input:radio[name="AdjType"]:checked').val() == "2") {
        $(".VoucherNo").hide();
        $(".VoucherDate").hide();
        $(".BillNo").show();
        $(".BillDate").show();
    }
}

///FUNCTION FOR GROUP ON CHANGE
$('#UnderGroup').on('change', function () {
    $("#Party").val('');
});

///FUNCTION FOR AUTOCOMPLETE LEDGER
function AutoCompleteBillAdjledger() {
    $("#Party").autocomplete({
        source: function (request, response) {
            $.ajax({
                type: 'POST',
                url: "/Master/BillAdjustment/SearchAccHeadNameList",
                dataType: "json",
                async: false,
                data: {
                    AccDescription: request.term, GroupUid: $("#UnderGroup").val()
                },
                success: function (result) {
                    response($.map(result.data.Table, function (LedgerName) {
                        return {
                            label: LedgerName.AccHead,
                            value: LedgerName.AccHead,
                            id: LedgerName.ledgeruid,
                            LedgerGroup: LedgerName.LedgerGroup,
                        }
                    }));
                },
                error: function (response) {
                    console.log(response.responseText);
                }
            });
        },
        autoFocus: true,
        minLength: 1,
        selectFirst: true,
        selectOnly: true,
        select: function (e, i) {
            $("#PartyUid").val(i.item.id);
            /*   $("#LedgerReportGroupSearch").val(i.item.LedgerGroup).trigger('change');*/
        },

    });
}

$("#Party").keypress(function () {
    var flag = 0;

    if ($("#UnderGroup").val() == "0") {
        Toast("Pleasr Select The Group First", 'Message', 'error');
        flag = 1;
        return false;
    }
    if (flag == 0) {
        AutoCompleteBillAdjledger();
    }
});

$(".TopGridSearch").keypress(function () {
    var flag = 0;
    if ($("#UnderGroup").val() == "0") {
        Toast("Pleasr Select The Group First", 'Message', 'error');
        flag = 1;
        return false;
    }
    if ($("#PartyUid").val() < "0") {
        Toast("Pleasr Select AccHead !", 'Message', 'error');
        flag = 1;
        return false;
    }
    if (flag == 0) {
        AutoSuggestionForBillAdjustMentTopGridList();
    }
});

// AUTO SUGGEST FUNCTION FOR BOTTOM GRID 
function AutoSuggestionForBillAdjustMentTopGridList() {
    if ($('input:radio[name="AdjType"]:checked').val() == "2")
        var BillNo = $("#VoucherNo").val();
    else
        var BillNo = $("#BillNo").val();
    $.widget('custom.tableAutocomplete', $.ui.autocomplete, {
        options: {
            open: function (event, ui) {
                // Hack to prevent a 'menufocus' error when doing sequential searches using only the keyboard
                $('.ui-autocomplete .ui-menu-item:first').trigger('mouseover');
            }
        },
        _create: function () {
            this._super();
            // Using a table makes the autocomplete forget how to menu.
            // With this we can skip the header row and navigate again via keyboard.
            this.widget().menu("option", "items", ".ui-menu-item");
        },
        _renderMenu: function (ul, items) {
            var self = this;
            var $table = $('<table class="table-autocomplete table table-bordered  table-sm">'),
                $thead = $('<thead>'),
                $headerRow = $('<tr>'),
                $tbody = $('<tbody>');
            $.each(self.options.columns, function (index, columnMapping) {
                $('<th>').text(columnMapping.title).appendTo($headerRow);
            });
            $thead.append($headerRow);
            $table.append($thead);
            $table.append($tbody);
            ul.html($table);
            $.each(items, function (index, item) {
                self._renderItemData(ul, ul.find("table tbody"), item);
            });
        },
        _renderItemData: function (ul, table, item) {
            return this._renderItem(table, item).data("ui-autocomplete-item", item);
        },
        _renderItem: function (table, item) {
            var self = this;
            var $tr = $('<tr class="ui-menu-item a" role="presentation">');

            $.each(self.options.columns, function (index, columnMapping) {
                var cellContent = !item[columnMapping.field] ? '' : item[columnMapping.field];
                $('<td>').text(cellContent).appendTo($tr);
            });

            $tr.hover(function () {
                $(this).addClass('ui-state-hover');
            }, function () {
                $(this).removeClass('ui-state-hover');
            });
            return $tr.appendTo(table);
            console.log(table);
        }
    });
    $(function () {
        $('.TopGridSearch').tableAutocomplete({
            source: function (request, response) {
                debugger
                $.ajax({
                    type: 'POST',
                    url: "/BillAdjustment/FillBillAdjustmentTopGridAutocomplete",
                    dataType: "json",
                    async: false,
                    data: { RefNo: request.term, BillLedgerUid: $("#PartyUid").val(), BalanceBills: $(".BalanceBillCLS").is(':checked') == true ? true : false, AdjustType: $('input:radio[name="AdjType"]:checked').val(), BillNo: BillNo, UsedRef: UsedRef },
                    success: function (result) {
                        response($.map(result.data.Table, function (LedgerName) {
                            return {
                                label: LedgerName.AccDesc,
                                value: LedgerName.BillNo,
                                id: LedgerName.TrUid,
                                BillNo: LedgerName.BillNo,
                                Particular: LedgerName.Particular,
                                Amount: LedgerName.BillAmount,
                                AdjustedAmount: LedgerName.AdjustedAmount,
                                BillDate: LedgerName.BillDate,
                                ChequeDate: LedgerName.ChequeDate,
                                ChequeNo: LedgerName.ChequeNo,
                                RowNum: LedgerName.RowNum,
                                FinyrId: LedgerName.FinyrId,
                                RefDesc: LedgerName.RefDesc,
                                LedgerUid2: LedgerName.LedgerUid2,
                                PendingAmount: LedgerName.PendingAmount,
                                TotalAmount: LedgerName.TotalAmount,
                            }
                        }));
                    }
                });
            },
            minlength: 1,
            autofocus: true,
            selectfirst: true,
            selectOnly: true,
            columns: [{
                field: 'BillNo',
                title: 'Ref. No.'
            }, {
                field: 'Particular',
                title: 'Particular'
            }, {
                field: 'Amount',
                title: 'Amount'
            }, {
                field: 'AdjustedAmount',
                title: 'Adjt Amount'
            }, {
                field: 'BillDate',
                title: 'Date'
            }, {
                field: 'ChequeNo',
                title: 'Cheque No'
            }, {
                field: 'ChequeDate',
                title: 'Cheque Date'
            }],
            delay: 500,
            select: function (event, ui) {
                if (ui.item != undefined) {
                    $("#TrUid").val(HandleNullTextValue(ui.item.id));
                    $("#RefDesc").val(HandleNullTextValue(ui.item.RefDesc));
                    $("#FinancialYear").val(HandleNullTextValue(ui.item.FinyrId));
                    $(".TopGridSearch").val(HandleNullTextValue(ui.item.BillNo));
                    //$("#VoucherNo").val(HandleNullTextValue(ui.item.BillNo));
                    $("#Particular").val(HandleNullTextValue(ui.item.Particular));
                    $("#BillAmount").val(HandleNullTextValue(ui.item.Amount));
                    $("#VoucherDate").val(HandleNullTextValue(ui.item.BillDate));
                    $("#BalAmount").val(HandleNullTextValueFixed(ui.item.PendingAmount));
                    FormEdit($("#VoucherDate").val(), $("#VoucherNo").val());
                }
                return false;
            }
        });
    });
};

// ON KEY PRESS FUNCTION FOR AUTO SUGGEST BOTTOM GRID 
$(".ReferenceNo").keypress(function () {
    var flag = 0;
    if ($("#UnderGroup").val() == "0") {
        Toast("Pleasr Select The Group First", 'Message', 'error');
        flag = 1;
        return false;
    }
    if ($("#PartyUid").val() < "0") {
        Toast("Pleasr Select AccHead !", 'Message', 'error');
        flag = 1;
        return false;
    }
    if ($("#VoucherNo").val() == "") {
        Toast("Pleasr Select Bill No Or Voucher No !", 'Message', 'error');
        flag = 1;
        return false;
    }
    if (flag == 0) {
        AutoSuggestionForBillAdjustMentBtmGridList();
    }
});

// AUTO SUGGEST FUNCTION FOR BOTTOM GRID 
function AutoSuggestionForBillAdjustMentBtmGridList() {
    var BillNo = $("#VoucherNo").val();
    $.widget('custom.tableAutocomplete', $.ui.autocomplete, {
        options: {
            open: function (event, ui) {
                // Hack to prevent a 'menufocus' error when doing sequential searches using only the keyboard
                $('.ui-autocomplete .ui-menu-item:first').trigger('mouseover');
            }
        },
        _create: function () {
            this._super();
            // Using a table makes the autocomplete forget how to menu.
            // With this we can skip the header row and navigate again via keyboard.
            this.widget().menu("option", "items", ".ui-menu-item");
        },
        _renderMenu: function (ul, items) {
            var self = this;
            var $table = $('<table class="table-autocomplete table table-bordered  table-sm">'),
                $thead = $('<thead>'),
                $headerRow = $('<tr>'),
                $tbody = $('<tbody>');
            $.each(self.options.columns, function (index, columnMapping) {
                $('<th>').text(columnMapping.title).appendTo($headerRow);
            });
            $thead.append($headerRow);
            $table.append($thead);
            $table.append($tbody);
            ul.html($table);
            $.each(items, function (index, item) {
                self._renderItemData(ul, ul.find("table tbody"), item);
            });
        },
        _renderItemData: function (ul, table, item) {
            return this._renderItem(table, item).data("ui-autocomplete-item", item);
        },
        _renderItem: function (table, item) {
            var self = this;
            var $tr = $('<tr class="ui-menu-item a" role="presentation">');

            $.each(self.options.columns, function (index, columnMapping) {
                var cellContent = !item[columnMapping.field] ? '' : item[columnMapping.field];
                $('<td>').text(cellContent).appendTo($tr);
            });

            $tr.hover(function () {
                $(this).addClass('ui-state-hover');
            }, function () {
                $(this).removeClass('ui-state-hover');
            });
            return $tr.appendTo(table);
            console.log(table);
        }
    });
    $(function () {
        $('.ReferenceNo').tableAutocomplete({
            source: function (request, response) {
                $.ajax({
                    type: 'POST',
                    url: "/BillAdjustment/AutoSuggestionForBillAdjustMentBottomGridList",
                    dataType: "json",
                    async: false,
                    data: { RefNo: request.term, BillLedgerUid: $("#PartyUid").val(), BalanceBills: $(".BalanceBillCLS").is(':checked') == true ? true : false, AdjustType: $('input:radio[name="AdjType"]:checked').val(), BillNo: BillNo, UsedRef: UsedRef },
                    success: function (result) {
                        response($.map(result.data.Table, function (LedgerName) {
                            return {
                                label: LedgerName.AccDesc,
                                value: LedgerName.BillNo,
                                id: LedgerName.TrUid,
                                BillNo: LedgerName.BillNo,
                                Particular: LedgerName.Particular,
                                Amount: LedgerName.BillAmount,
                                AdjustedAmount: LedgerName.AdjustedAmount,
                                BillDate: LedgerName.BillDate,
                                ChequeDate: LedgerName.ChequeDate,
                                ChequeNo: LedgerName.ChequeNo,
                                RowNum: LedgerName.RowNum,
                                FinyrId: LedgerName.FinyrId,
                                LedgerUid2: LedgerName.LedgerUid2,
                                PendingAmount: LedgerName.PendingAmount,
                                TotalAmount: LedgerName.TotalAmount,
                            }
                        }));
                    }
                });
            },
            minlength: 1,
            autofocus: true,
            selectfirst: true,
            selectOnly: true,
            columns: [{
                field: 'BillNo',
                title: 'Ref. No.'
            }, {
                field: 'Particular',
                title: 'Particular'
            }, {
                field: 'Amount',
                title: 'Amount'
            }, {
                field: 'AdjustedAmount',
                title: 'Adjt Amount'
            }, {
                field: 'BillDate',
                title: 'Date'
            }, {
                field: 'ChequeNo',
                title: 'Cheque No'
            }, {
                field: 'ChequeDate',
                title: 'Cheque Date'
            }],
            delay: 500,
            select: function (event, ui) {
                console.log(ui.item);


                if (ui.item != undefined) {
                    $(this).val(ui.item.value);
                    var parentTr = $(this).parents('tr');
                    parentTr.find(".HiddenReferenceNo").val(HandleNullTextValue(ui.item.id));
                    parentTr.find(".HiddenLedgerUid").val(HandleNullTextValue(ui.item.LedgerUid2));
                    parentTr.find(".HiddenFinyrId").val(HandleNullTextValue(ui.item.FinyrId));
                    parentTr.find(".ReferenceNo").val(HandleNullTextValue(ui.item.BillNo));
                    parentTr.find(".GridParticular").val(HandleNullTextValue(ui.item.Particular));
                    parentTr.find(".Amount").val(HandleNullTextValue(ui.item.Amount));
                    parentTr.find(".AdjAmount").val(HandleNullTextValue(ui.item.PendingAmount));
                    parentTr.find(".Date").val(HandleNullTextValue(ui.item.BillDate));
                    //parentTr.find(".TotalBalAmount").val(HandleNullTextValueFixed(ui.item.TotalAmount, 2));
                    //parentTr.find(".modalTotalBalAmount ").val(HandleNullTextValue(ui.item.TotalAmount));
                    CalculateTotalBalnceAmountBillAdj();
                }
                return false;
            }
        });
    });
};
// RESET DATA FOR BILL ADJUSTMENT MODAL
function ResetDataBillAdj() {
    $("#UnderGroup").val("0");
    $("#Party").val("");
    $("#PartyUid").val("");
    $("#VoucherNo").val("");
    $("#VoucherDate").val("");
    $("#BillNo").val("");
    $("#BillDate").val("");
    $("#BillAmount").val("0.00");
    $("#BalAmount").val("0.00");
    $("#RefAccHead").val("");
    $("#Particular").val("");
    $("#RefDesc").val("");
    var tbody = $("#BillAdjustment_Table").find("tbody");
    var Tr = $(tbody).find("tr");
    var rowCount = Tr.length;
    if (rowCount > 1) {
        $("#BillAdjustment_Table tbody tr").each(function (index, ele) {
            if (index > 0) {
                $(ele).remove();
            }
            else {
                $(ele).find('.HiddenReferenceNo').val('');
                $(ele).find('.ReferenceNo').val('');
                $(ele).find('.GridParticular').val('');
                $(ele).find('.Date').val('');
                $(ele).find('.Amount').val('0.00');
                $(ele).find('.AdjAmount').val('0.00');
                $(ele).find('.TotalBalAmount').val('0.00');
                $("#BillAdjustment_Table").find("tbody").append(ele);
            }
        });
    }
    else {
        Tr.find('.HiddenReferenceNo').val('');
        Tr.find('.ReferenceNo').val('');
        Tr.find('.GridParticular').val('');
        Tr.find('.Date').val('');
        Tr.find('.Amount').val('0.00');
        Tr.find('.AdjAmount').val('0.00');
        Tr.find('.TotalBalAmount').val('0.00');
        $("#BillAdjustment_Table").find("tbody").append(Tr);
    }
}
function CalculateTotalBalnceAmountBillAdj() {
    $("#BillAdjustment_Table tbody tr").each(function (index, ele) {
        var Amt = $(ele).find('.Amount').val();
        if ($(ele).find('.Amount').val() > 0) {
            var Amt1 = Amt - parseFloat($(ele).find('.AdjAmount ').val());
            $(ele).find('.TotalBalAmount').val(Amt1);
        }
    });
};


// ON CLICK BUTTON FOR ADD OR UPDAT BILL ADJUSTMENT
$("#BillAdjustmentSave").click(function () {
    var flag = 0;
    var AdjAmt = 0;
    var Amt = 0;
    var TotalBalAmt = 0.00;
    var BillAmount = $("#BillAmount").val();
    if ($("#VoucherNo").val() == "") {
        Toast("Please Enter Voucher No !", 'Message', 'error');
        return;
    }
    if ($("#VoucherDate").val() == "") {
        Toast("Please Select Voucher Date !", 'Message', 'error');
        return;
    }
    if (($("#BillAmount").val() == "0.00") || ($("#BillAmount").val() == "")) {
        Toast("The Bill Amount Field Must Contain a Number Greater Than 0 ", 'Message', 'error');
        return;
    }
    $("#BillAdjustment_Table tbody tr").each(function (index, ele) {

        var rowCount = $("#BillAdjustment_Table tbody tr").length;
        if (rowCount > 1) {
            if ($(ele).find('.HiddenReferenceNo').val().length == 0) {
                Toast("Please Enter Ref No", 'Message', 'error');
                flag = 1;
                return false;
            }
            if ($(ele).find('.ReferenceNo').val() == '') {
                Toast("Please Enter Ref No", 'Message', 'error');
                flag = 1;
                return false;
            }
        }

        if ($(ele).find('.Amount').val() == '0.00') {
            Toast("Please Enter Amount!", 'Message', 'error');
            flag = 1;
            return false;
        }
        if ($(ele).find('.AdjAmount').val() != null) {
            AdjAmt = AdjAmt + parseFloat($(ele).find('.AdjAmount').val());
        }
        if (AdjAmt > BillAmount) {
            Toast("Adjusted Amount Should Be Less Than Or Equal Bill Amount!", 'Message', 'error');
            flag = 1;
            return false;
        }
        if ($(ele).find('.Amount').val() != null) {
            Amt = Amt + parseFloat($(ele).find('.Amount').val());
        }
        if (AdjAmt > Amt) {
            Toast("Sorry you cannot not add more than the balance amount!!", 'Message', 'error');
            flag = 1;
            return false;
        }

        if ($(ele).find('.TotalBalAmount ').val() != null) {
            TotalBalAmt = TotalBalAmt + parseFloat($(ele).find('.TotalBalAmount ').val());
        }
        //if (TotalBalAmt > '0.00') {

        //    if (AdjAmt > TotalBalAmt) {
        //        Toast("Sorry you cannot not add more than the Total balance amount!!", 'Message', 'error');
        //        flag = 1;
        //        return false;
        //    }
        //}
    });
    if (flag == 0) {
        var rowCount = $("#BillAdjustment_Table tbody tr").length;
        var modalReferenceNo = $("#ReferenceNo").val();
        if ((rowCount == 1) && (modalReferenceNo == '')) {
            FormDelete();
        }
        else {
            if ((TableCount > 0) && (AmountCheck != null)) {
                FormUpdate();
            }
            else {
                FormAdd();
            }

        }

    }
});


// FUNCTION FOR ADD BILL ADJUSTMENT
function FormAdd() {
    try {
        debugger
        AdjustType = $('input:radio[name="AdjType"]:checked').val();
        const dataString = {};
        dataString.FinyrId = $("#FinancialYear").val();
        dataString.LedgerUId = $("#PartyUid").val();
        dataString.LedgerId = $("#HiddenAccHeadId").val();
        if (AdjustType == '2') {
            dataString.RefNo1 = $("#VoucherNo").val();
            dataString.Date1 = $("#VoucherDate").val();
        }
        else {
            dataString.RefNo1 = $("#BillNo").val();
            dataString.Date1 = $("#VoucherDate").val();
        }
        dataString.TrxnId1 = $('#TrUid').val();
        dataString.LedgerUid2 = $('#RefUid').val();
        var BillAdj = new Array();
        $("#BillAdjustment_Table tbody tr").each(function () {
            var BillAdjDetail = {};
            BillAdjDetail.TrxnId2 = $(this).find(".HiddenReferenceNo").val();
            BillAdjDetail.RefNo2 = $(this).find(".ReferenceNo").val();
            BillAdjDetail.Date2 = $(this).find(".Date").val();
            BillAdjDetail.TrxnFinyrId = $(this).find(".HiddenFinyrId").val();
            BillAdjDetail.Amount = $(this).find(".AdjAmount").val();
            BillAdjDetail.LedgerUid2 = $(this).find(".HiddenLedgerUid").val();
            BillAdj.push(BillAdjDetail);
        });
        dataString.billAdjustMentGridModels = BillAdj;
        AjaxSubmission(JSON.stringify(dataString), '/BillAdjustMent/FormAdd', $('input[name=__RequestVerificationToken]').val()).done(function (result) {
            let obj = result;
            if (obj.status == true) {
                if (obj.responsecode == '101') {
                    FormEdit($("#VoucherDate").val(), $("#VoucherNo").val());
                    Toast(RetrieveMessage(obj.responsecode), "Message", "success");
                }
                else {
                    Toast(RetrieveMessage(obj.responsecode), "Message", "error");
                }
            }
            else {
                window.location.href = '/ClientLogin/ClientLogin';
            }
        }).fail(function (result) {
            console.log(result.Message);
        });
    }
    catch (e) {
        console.log(e.message);
    }
}

// FUNCTION FOR EDIT BILL ADJUSTMENT
function FormEdit(Date, RefNo1) {
    try {
        debugger
        const dataString = {};
        dataString.RefNo1 = RefNo1;
        dataString.Date = Date;
        AjaxSubmission(JSON.stringify(dataString), '/BillAdjustMent/FormEdit', $('input[name=__RequestVerificationToken]').val()).done(function (result) {
            let obj = result;
            if (obj.status == true) {
                if (obj.responsecode == '100') {
                    TableCount = obj.data.Table1[0].ROWCOUNT1;
                    if (TableCount > '0') {
                        $("#DeleteAdjustment").removeClass('d-none');
                        $("#ReAdjustment").removeClass('d-none');
                        $("#NewAdjustment").removeClass('d-none');
                    }
                    AmountCheck = obj.data.Table[0].adjustamount;
                    ResetAdjustmentTableData();
                    var FirstChild = $("#BillAdjustment_Table").find("tbody tr:first-child");
                    var BillAdjTableData = obj.data.Table;
                    $.each(BillAdjTableData, function (index, ele) {
                        if (index == 0) {
                            FirstChild.find('.HiddenFinyrId').val(ele.FinyrId);
                            FirstChild.find('.HiddenReferenceNo').val(ele.TrxnId1);
                            FirstChild.find('.ReferenceNo').val(ele.RefNo1);
                            FirstChild.find('.Date').val(ele.Date1);
                            FirstChild.find('.AdjAmount').val(ele.adjustamount.toFixed(2));
                            FirstChild.find('.Amount').val(ele.TotalAmt.toFixed(2));
                            FirstChild.find('.TotalBalAmount').val(ele.TotalBalAMT.toFixed(2));
                            FirstChild.find('.HiddenLedgerUid').val(ele.LedgerUid2);
                        }
                        else {
                            var CloneChild = FirstChild.clone();
                            //FirstChild.find('.HiddenmodalFinyrId').val('');
                            //FirstChild.find('.HiddenmodalReferenceNo').val('');
                            //FirstChild.find('.modalReferenceNo').val('');
                            //FirstChild.find('.modalDate').val('');
                            //FirstChild.find('.modalAdjAmount').val('');
                            //FirstChild.find('.modalAmount').val('');
                            CloneChild.find('.HiddenFinyrId').val(ele.FinyrId);
                            CloneChild.find('.HiddenReferenceNo').val(ele.TrxnId1);
                            CloneChild.find('.ReferenceNo').val(ele.RefNo1);
                            CloneChild.find('.Date').val(ele.Date1);
                            CloneChild.find('.AdjAmount').val(ele.adjustamount.toFixed(2));
                            CloneChild.find('.Amount').val(ele.TotalAmt.toFixed(2));
                            CloneChild.find('.TotalBalAmount').val(ele.TotalBalAMT.toFixed(2));
                            CloneChild.find('.HiddenLedgerUid').val(ele.LedgerUid2);
                            $("#BillAdjustment_Table tbody").append(CloneChild);
                        }
                        var AdjAmt = 0;
                        $("#BillAdjustment_Table tbody tr").each(function (index, ele) {
                            if ($(ele).find('.AdjAmount').val() != null) {
                                AdjAmt = AdjAmt + parseFloat($(ele).find('.AdjAmount').val());
                            }
                        });
                        var BillAmt = ($('#BillAmount').val() - AdjAmt);
                        $('#BalAmount').val(BillAmt);
                      
                    });
                }
                else {
                    Toast(RetrieveMessage(obj.responsecode), "Message", "error");
                }
            }
            else {
                window.location.href = '/ClientLogin/ClientLogin';
            }
            //Hideloader();
        }).fail(function (result) {
            console.log(result.Message);
            //Hideloader();
        });
    }
    catch (e) {
        console.log(e.message);
        //Hideloader();
    }

}

//FUNCTION FOR UPDATE BILL ADJUSTMENT
function FormUpdate() {

    try {
        const dataString = {};
        dataString.FinyrId = $("#FinancialYear").val();
        dataString.LedgerUId = $("#PartyUid").val();
        dataString.LedgerId = $("#HiddenAccHeadId").val();
        dataString.RefNo1 = $("#VoucherNo").val();
        dataString.Date1 = $("#VoucherDate").val();
        dataString.TrxnId1 = $('#TrUid').val();
        dataString.LedgerUid2 = $('#RefUid').val();
        var BillAdj = new Array();
        $("#BillAdjustment_Table tbody tr").each(function () {
            var BillAdjDetail = {};
            BillAdjDetail.TrxnId2 = $(this).find(".HiddenReferenceNo").val();
            BillAdjDetail.RefNo2 = $(this).find(".ReferenceNo").val();
            BillAdjDetail.Date2 = $(this).find(".Date").val();
            BillAdjDetail.TrxnFinyrId = $(this).find(".HiddenFinyrId").val();
            BillAdjDetail.Amount = $(this).find(".AdjAmount").val();
            BillAdjDetail.LedgerUid2 = $(this).find(".HiddenLedgerUid").val();
            BillAdj.push(BillAdjDetail);
        });
        dataString.billAdjustMentGridModels = BillAdj;
        AjaxSubmission(JSON.stringify(dataString), '/BillAdjustMent/FormUpdate', $('input[name=__RequestVerificationToken]').val()).done(function (result) {
            let obj = result;
            if (obj.status == true) {
                if (obj.responsecode == '107') {
                    // ResetDataBillAdj();
                    //  AutoSuggestionForBillAdjustMentTopGridList();
                    //   AutoSuggestionForBillAdjustMentBtmGridList();
                    FormEdit($("#VoucherDate").val(), $("#VoucherNo").val());
                    Toast(RetrieveMessage(obj.responsecode), "Message", "success");
                }
                else {
                    Toast(RetrieveMessage(obj.responsecode), "Message", "error");
                }
            }
            else {
                window.location.href = '/ClientLogin/ClientLogin';
            }
            //Hideloader();
        }).fail(function (result) {
            console.log(result.Message);
            //Hideloader();
        });
    }
    catch (e) {
        console.log(e.message);
        //Hideloader();
    }
}

function ResetAdjustmentTableData() {
    var tbody = $("#BillAdjustment_Table").find("tbody");
    var Tr = $(tbody).find("tr");
    var rowCount = Tr.length;
    if (rowCount > 1) {
        $("#BillAdjustment_Table tbody tr").each(function (index, ele) {
            if (index > 0) {
                $(ele).remove();
            }
            else {
                $(ele).find('.HiddenReferenceNo').val('');
                $(ele).find('.ReferenceNo').val('');
                $(ele).find('.GridParticular').val('');
                $(ele).find('.Date').val('');
                $(ele).find('.Amount').val('0.00');
                $(ele).find('.AdjAmount').val('0.00');
                $(ele).find('.TotalBalAmount').val('0.00');
                $("#BillAdjustment_Table").find("tbody").append(ele);
            }
        });
    }
    else {
        Tr.find('.HiddenReferenceNo').val('');
        Tr.find('.ReferenceNo').val('');
        Tr.find('.GridParticular').val('');
        Tr.find('.Date').val('');
        Tr.find('.Amount').val('0.00');
        Tr.find('.AdjAmount').val('0.00');
        Tr.find('.TotalBalAmount').val('0.00');
        $("#BillAdjustment_Table").find("tbody").append(Tr);
    }
}


//FUNCTION FOR DELETE BILL ADJUSTMENT
function FormDelete(e) {
    try {
        var RefNo = $('#VoucherNo').val();
        $.confirm({
            title: '',
            content: 'Are You Sure Want To Delete ?',
            type: 'red',
            boxWidth: '300px',
            useBootstrap: false,
            columnClass: 'small',
            containerFluid: true,
            typeAnimated: true,
            buttons: {
                tryAgain: {
                    text: 'Confirm',
                    btnClass: 'btn-red',
                    action: function () {
                        const datastring = {};
                        datastring.RefNo = RefNo;
                        AjaxSubmission(JSON.stringify(datastring), '/BillAdjustMent/FormDelete', $('[name="__RequestVerificationToken"]').val()).done(function (data) {
                            let obj = data;
                            if (obj.status == true) {
                                if (obj.responsecode == '102') {
                                    Toast(RetrieveMessage(obj.responsecode), "Message", "success");
                                    ResetDataBillAdj();
                                }
                                else {
                                    Toast(RetrieveMessage(obj.responsecode), "Message", "error");
                                }
                            }
                            else {
                                window.location.href = 'ClientLogin/ClientLogin';
                            }
                        }).fail(function (data) {
                            console.log(data.Message);
                        });
                    }
                },
                close: function () {
                }
            }
        });
    }
    catch (e) {
        console.log(e.message);
    }
}
