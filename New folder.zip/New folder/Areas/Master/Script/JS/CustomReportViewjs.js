﻿
$(document).ready(function () {
    $(".datetime-local").datepicker({
        changeMonth: true,
        changeYear: true,
        dateFormat: 'dd/mm/yy',
    });
    FillAllReport();
    FillPageSizeList2('ddlPageSize');

});


function FillPageSizeList2(drpid) {
    try {
        //Showloader();
        AjaxSubmission(null, "/_Layout/FillPageSizeList", $('input[name=__RequestVerificationToken]').val()).done(function (data) {
            let obj = data;
            if (obj.status == true) {
                if (obj.responsecode == '100')
                    BindDropdown(obj.data.Table, drpid, 'size', 'text', 0);
                else if (obj.responsecode == '604')
                    BindDropdown(null, drpid, 'size', 'text', 1);
            }
            else
                window.location.href = '/ClientLogin/ClientLogin';
            //Hideloader();

        }).fail(function (result) {
            console.log(result.Message);
            //Hideloader();
        });
    }
    catch (e) {
        console.log(e.message);
        //Hideloader();
    }
}


$("#dropdown").select2({
    width: '100%'
});

$("#listbox").select2({
    width: '100%'
});
function FillAllReport() {
    try {
        AjaxSubmission(null, "/Master/CustomReportView/GetAllReport", $('input[name=__RequestVerificationToken]').val()).done(function (result) {
            let obj = result;
            if (obj.status == true) {
                if (obj.responsecode == '100') {
                    BindDropdown(obj.data.Table, 'SearchReport', 'Report_Id', 'Report_Name', '----------------Select----------------');
                }
                else if (obj.responsecode == '604') {
                    BindDropdown(null, 'SearchReport', 'Report_Id', 'Report_Name', '----------------Select----------------');
                }
                else {
                    Toast(RetrieveMessage(obj.responsecode), "Message", "error");
                }
            }
            else {
                window.location.href = '/ClientLogin/ClientLogin';
            }
            //Hideloader();
        }).fail(function (result) {
            console.log(result.Message);
            //Hideloader();
        });
    }
    catch (e) {
        console.log(e.message);
        //Hideloader();
    }
}

$("#SearchReport").change(function () {
    $("#NewReportQuery").val('');
    if ($("#SearchReport").val() != '0') {
        AllDisplayFields($("#SearchReport").val());
    }
});

function AllDisplayFields(e) {
    try {
        const datastring = {};
        datastring.ReportId = e;
        AjaxSubmission(JSON.stringify(datastring), "/Master/CustomReportView/AllDisplayFields", $('[name="__RequestVerificationToken"]').val()).done(function (data) {
            let obj = data;
            if (obj.status == true) {
                if (obj.responsecode == '100') {
                    $("#Searchfield").html(obj.error);
                    $("#ddlPageSize").val(obj.data.Table1[0].page_select)
                    $(".datetime-local").datepicker({
                        changeMonth: true,
                        changeYear: true,
                        dateFormat: 'dd/mm/yy',
                    });
                }
            }
        }).fail(function (data) {
            console.log(data.Message);
        });
    }
    catch (e) {
        console.log(e.message);
    }
}

function EditForm(e, ch) {
    try {
        const datastring = {};
        datastring.ReportId = e;
        AjaxSubmission(JSON.stringify(datastring), "/Master/CustomReportView/EditForm", $('[name="__RequestVerificationToken"]').val()).done(function (data) {
            let obj = data;
            if (obj.status == true) {
                if (obj.responsecode == '100') {
                    $("#SearchReport").val(obj.data.Table[0].Report_Id);
                    $("#ReportsName").val(obj.data.Table[0].Report_Name);
                    $("#RemoveSearchReportTables").removeAttr('disabled');
                    var firstChild = $("#SearchReportFields").find("tbody tr:first-child");
                    $.each(CustomreportSearchFieldList, function (index, ele) {
                        if (index == 0) {
                            firstChild.find('.rn').text('1');
                            firstChild.find('.SearchOnField').val(ele.Search_Field);
                            firstChild.find('.DisplayName').val(ele.Display_Field);
                            firstChild.find('.Parameter').val(ele.Parameter);
                            firstChild.find('.DefaultOperator').val(ele.Default_Operator);
                            firstChild.find('.DefaultValue').val(ele.Default_Value);
                            firstChild.find('.AllowNull').prop('checked', ele.Allow_Null);
                            firstChild.find('.OtherDB').prop('checked', ele.By_Other_Db);
                            firstChild.find('.ControlType').val(ele.Control_Type);
                            firstChild.find('.ComboValue').val(ele.Combo_Value);
                            firstChild.find('.HiddenReportFieldId').val(ele.Search_Field);
                        }
                        else {
                            var cloneChild = firstChild.clone();
                            cloneChild.find('.rn').text(index + 1);
                            cloneChild.find('.SearchOnField').val('');
                            cloneChild.find('.DisplayName').val('');
                            cloneChild.find('.Parameter').val('');
                            cloneChild.find('.DisplayName').val('');
                            cloneChild.find('.DefaultOperator').val('');
                            cloneChild.find('.DefaultValue').val('');
                            cloneChild.find('.AllowNull').prop('checked', false);
                            cloneChild.find('.OtherDB').prop('checked', false);
                            cloneChild.find('.ControlType').val('');
                            cloneChild.find('.ComboValue').val('');
                            cloneChild.find('.HiddenReportFieldId').val('');

                            cloneChild.find('.SearchOnField').val(ele.Search_Field);
                            cloneChild.find('.DisplayName').val(ele.Display_Field);
                            cloneChild.find('.Parameter').val(ele.Parameter);
                            cloneChild.find('.DefaultOperator').val(ele.Default_Operator);
                            cloneChild.find('.DefaultValue').val(ele.Default_Value);
                            cloneChild.find('.AllowNull').prop('checked', ele.Allow_Null);
                            cloneChild.find('.OtherDB').prop('checked', ele.By_Other_Db);
                            cloneChild.find('.ControlType').val(ele.Control_Type);
                            cloneChild.find('.ComboValue').val(ele.Combo_Value);
                            cloneChild.find('.HiddenReportFieldId').val(ele.Search_Field);
                            $("#SearchReportFields tbody").append(cloneChild)
                        }
                    });
                }
                else {
                    Toast(RetrieveMessage(obj.responsecode), "Message", "error");
                }
            }
            else {
                window.location.href = '/ClientLogin/ClientLogin';
            }
        }).fail(function (data) {
            console.log(data.Message);
        });
    }
    catch (e) {
        console.log(e.message);
    }
}

var Query = "";
var textvalue = "";
var NewQuery = "";

$("#SearchForm").click(function () {
    GetReportData();
});

function GetReportData() {
    try {
        Query = "";
        textvalue = "";
        NewQuery = "";
        let container = document.getElementById('Searchfield');
        let ele = container.getElementsByTagName('input');
        let elee = container.getElementsByTagName('select');
        for (i = 0; i < elee.length; i++) {
            var id = $(elee[i])[0].id;
            if ($(elee[i]).parent().find('label').find('span').html() == "*") {
                if ($(elee[i]).val().trim().length == 0 || $(elee[i]).val() == "--select--") {
                    Toast('Please Enter the value ', 'Message', 'error');
                    return;
                }
                else {
                    if (id.length > 0) {
                        if (Query.trim().length == 0) {
                            if ($(elee[i]).hasClass('datetime') || $(elee[i]).hasClass('date') || $(elee[i]).hasClass('varchar') || $(elee[i]).hasClass('nvarchar') || $(elee[i]).hasClass('text')) {
                                if ($(elee[i]).val() == "--select--") {
                                    Query += " ";
                                }
                                else {
                                    Query = " " + $(elee[i]).data("column") + " " + "=" + " " + "'" + $(elee[i]).val() + "'";
                                }
                            }
                            else
                                Query += "";
                        }
                        else {
                            if ($(elee[i]).hasClass('datetime') || $(elee[i]).hasClass('date') || $(elee[i]).hasClass('varchar') || $(elee[i]).hasClass('nvarchar') || $(elee[i]).hasClass('text')) {
                                if ($(elee[i]).val() == "--select--") {
                                    Query += " ";
                                }
                                else {
                                    Query += " " + "And" + " " + $(elee[i]).data("column") + " " + "=" + " " + "'" + $(elee[i]).val() + "'" + " ";
                                }

                            }
                            else
                                Query += " ";
                        }
                    }
                }
            }
            else {
                if ($(elee[i]).val().trim().length == 0 || $(elee[i]).val().trim() == '--select--') {
                    ;
                    Query += " ";
                }
                else {
                    if (id.length > 0) {
                        if (Query.trim().length == 0) {
                            if ($(elee[i]).hasClass('datetime') || $(elee[i]).hasClass('date') || $(elee[i]).hasClass('varchar') || $(elee[i]).hasClass('nvarchar') || $(elee[i]).hasClass('text')) {
                                if ($(elee[i]).val().trim() == '--select--') {
                                    Query += " ";
                                }
                                else {
                                    Query = " " + $(elee[i]).data("column") + " " + "=" + " " + "'" + $(elee[i]).val() + "'" + " ";
                                }

                            }
                            else {
                                if ($(elee[i]).val().trim() == '--select--') {
                                    Query += " ";
                                }
                                else {
                                    Query = $(elee[i]).data("column") + " " + "=" + " " + "" + $(elee[i]).val() + "";
                                }
                            }

                        }
                        else {
                            if ($(elee[i]).hasClass('datetime') || $(elee[i]).hasClass('date') || $(elee[i]).hasClass('varchar') || $(elee[i]).hasClass('nvarchar') || $(elee[i]).hasClass('text')) {
                                if ($(elee[i]).val().trim() == '--select--') {
                                    Query += "";
                                }
                                else {
                                    Query += " " + "And" + " " + $(elee[i]).data("column") + " " + "=" + " " + "'" + $(elee[i]).val() + "'" + " ";
                                }

                            }
                            else {
                                if ($(elee[i]).val().trim() == '--select--') {
                                    Query += " ";
                                }
                                else {
                                    Query += " " + "And" + " " + $(elee[i]).data("column") + " " + "=" + " " + "" + $(elee[i]).val() + "";
                                }
                            }
                        }
                    }
                }
            }
        }
        for (i = 0; i < ele.length; i++) {
            if (ele[i].type == 'text') {
                if ($(ele[i]).hasClass('mydt')) {
                    var olddate = $(ele[i]).val().split('/');
                    newdate = olddate[1] + "/" + olddate[0] + "/" + olddate[2];
                    if ($(ele[i]).parent().parent().find('label').find('span').html() == "*") {
                        if ($(ele[i]).val().trim().length < 10) {
                            Toast('Please Enter Date', 'Message', 'error');
                            return;
                        }
                        else {
                            if (Query.trim().length == 0) {
                                if ($(ele[i]).hasClass('datetime') || $(ele[i]).hasClass('date') || $(ele[i]).hasClass('varchar') || $(ele[i]).hasClass('nvarchar') || $(ele[i]).hasClass('text')) {
                                    Query = " " + $(ele[i]).data("column") + " " + $(ele[i]).siblings().val() + " " + "'" + newdate + "'" + " ";
                                }
                                else {
                                    Query = " " + $(ele[i]).data("column") + " " + $(ele[i]).siblings().val() + " " + "=" + " " + " " + newdate + " ";
                                }
                            }
                            else {
                                if ($(ele[i]).hasClass('datetime') || $(ele[i]).hasClass('date') || $(ele[i]).hasClass('varchar') || $(ele[i]).hasClass('nvarchar') || $(ele[i]).hasClass('text')) {
                                    Query += " " + "And" + " " + $(ele[i]).data("column") + " " + $(ele[i]).siblings().val() + " " + "'" + newdate + "'" + " ";
                                }
                                else {
                                    Query += " " + "And" + " " + $(ele[i]).data("column") + " " + $(ele[i]).siblings().val() + " " + "'" + newdate + " ";
                                }
                            }
                        }
                    }
                    else {
                        if ($(ele[i]).val().trim().length == 0) {
                            Query += " ";
                        }
                        else if ($(ele[i]).val().trim().length < 10) {
                            Toast('Please Enter Correct Date', 'Message', 'error');
                            return;
                        }
                        else {
                            if ($(ele[i]).val().trim().length == 10) {
                                if (Query.trim().length == 0) {
                                    if ($(ele[i]).hasClass('datetime') || $(ele[i]).hasClass('date') || $(ele[i]).hasClass('varchar') || $(ele[i]).hasClass('nvarchar') || $(ele[i]).hasClass('text')) {
                                        Query += " " + " " + $(ele[i]).data("column") + " " + $(ele[i]).siblings().val() + " " + "'" + newdate + "'";
                                    }
                                    else {
                                        Query += " " + " " + $(ele[i]).data("column") + " " + $(ele[i]).siblings().val() + " " + "'" + newdate + " ";
                                    }
                                }
                                else {
                                    if ($(ele[i]).hasClass('datetime') || $(ele[i]).hasClass('date') || $(ele[i]).hasClass('varchar') || $(ele[i]).hasClass('nvarchar') || $(ele[i]).hasClass('text')) {
                                        Query += " " + "And" + " " + $(ele[i]).data("column") + " " + $(ele[i]).siblings().val() + " " + "'" + newdate + "'";
                                    }
                                    else {
                                        Query += " " + "And" + " " + $(ele[i]).data("column") + " " + $(ele[i]).siblings().val() + " " + "'" + newdate + " ";
                                    }
                                }

                            }
                        }
                    }
                }
                else {
                    if ($(ele[i]).parent().parent().find('label').find('span').html() == "*") {
                        if ($(ele[i]).val().trim().length == 0) {
                            Toast('Please Enter the value', 'Message', 'error');
                            return;
                        }
                        else {
                            if (Query.trim().length <= 0) {
                                if ($(ele[i]).hasClass('datetime') || $(ele[i]).hasClass('date') || $(ele[i]).hasClass('varchar') || $(ele[i]).hasClass('nvarchar') || $(ele[i]).hasClass('text')) {
                                    Query = " " + $(ele[i])[0].id + " " + $(ele[i]).siblings().val() + " " + "'" + $(ele[i]).val() + "'" + " ";
                                }
                                else {
                                    Query = " " + $(ele[i])[0].id + " " + $(ele[i]).siblings().val() + " " + "" + $(ele[i]).val() + " ";
                                }
                            }
                            else {
                                if ($(ele[i]).hasClass('datetime') || $(ele[i]).hasClass('date') || $(ele[i]).hasClass('varchar') || $(ele[i]).hasClass('nvarchar') || $(ele[i]).hasClass('text')) {
                                    Query += " " + "And" + " " + $(ele[i])[0].id + " " + $(ele[i]).siblings().val() + " " + "=" + " " + "" + $(ele[i]).val() + "'" + " ";
                                }
                                else {
                                    Query += " " + "And" + " " + $(ele[i])[0].id + " " + $(ele[i]).siblings().val() + " " + " " + $(ele[i]).val() + " ";
                                }
                            }
                        }
                    }
                    else {
                        if ($(ele[i]).val().trim().length == 0) {
                            Query += "";
                        }
                        else {
                            if ($(ele[i]).hasClass('datetime') || $(ele[i]).hasClass('date') || $(ele[i]).hasClass('varchar') || $(ele[i]).hasClass('nvarchar') || $(ele[i]).hasClass('text')) {
                                Query += " " + "And" + " " + $(ele[i])[0].id + " " + $(ele[i]).siblings().val() + " " + "'" + $(ele[i]).val() + "'" + " ";
                            }
                            else {
                                Query += " " + "And" + " " + $(ele[i])[0].id + " " + $(ele[i]).siblings().val() + " " + "'" + $(ele[i]).val() + "'" + " ";
                            }
                        }
                    }
                }
            }
        }
        console.log(Query);
        if (Query.trim().length == 0) {
            NewQuery = Query + " ";
        }
        else {
            NewQuery = "And " + Query;
        }
        const datastring = {};
        datastring.ReportId = $("#SearchReport").val();
        datastring.NewQuery = NewQuery;
        datastring.pagesize = $("#ddlPageSize").val();
        localStorage.setItem('check', $("#ddlPageSize").val());
        AjaxSubmission(JSON.stringify(datastring), "/Master/CustomReportView/GetReportData", $('[name="__RequestVerificationToken"]').val()).done(function (data) {
            let obj = data;
            if (obj.status == true) {
                if (obj.responsecode == '100') {

                    if ($("#Preview").is(":checked") == true) {
                        $("#NewReportQuery").val(obj.error);
                        window.open('/Master/CustomReportView/ReportView');
                    }

                    else {
                        $("#NewReportQuery").val(obj.error);

                    }
                }
            }
        }).fail(function (data) {
            console.log(data.Message);
        });
    }
    catch (e) {
        console.log(e.message);
    }
}
