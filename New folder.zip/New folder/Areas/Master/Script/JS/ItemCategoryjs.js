﻿
var Firstcolumn = "";


if (Get_Cookie("ItemCategoryId") != null) {
    var a = setInterval(() => {
        if (Get_Cookie("ItemCategoryId") != '' && Get_Cookie("ItemCategoryId") != 0) {
            FormEdit(Get_Cookie("ItemCategoryId"));
        } else {
            $('#ItemCategory_list-tab').removeClass('active');
            $('#ItemCategory-tab').addClass('active');
            $('#ItemCategory_list').removeClass('active show');
            $('#ItemCategory').addClass('active show');
            $("#FormAdd").show();
            $("#FormUpdate").hide();
            $("#ItemCategory-tab").html("Add Item Category");
        }
        EraseCookie('ItemCategoryId');
        clearInterval(a);
    }, 100);
}

$(document).on("click", ".pagination .page", function () {
    FormList(($(this).attr('page')));
});
//PAGE SIZE CLICKED
$("#ddlPageSize").change(function () {
    FormList(1);
});

//SEARCH BUTTON CLICKED
$("#FormSearch").click(function () {
    FormList(1);
});

$(document).ready(function () {
    FillPageSizeList('ddlPageSize', FormList);

    // GetListDocumentTypeName();
    ItemCategoryDocumentTypeautocomplete();
})

// ADD MORE  DOCUMENT TYPE DROPDOWN GRID 
$(".AddMoreDocument").click(function () {
    $("#RemoveDocument").removeAttr('disabled');
    var tbody = $("#DocumentUpload_Table").find("tbody");
    var FirstTr = $(tbody).find("tr:first");

    var NewRow = $(FirstTr).clone();
    NewRow.find('.DocumentType').val('');
    $("#DocumentUpload_Table").find("tbody").append(NewRow);
    ItemCategoryDocumentTypeautocomplete();
});


// DELETE  DOCUMENT TYPE DROPDOWN GRID ROW
function DeleteRow(obj) {
    var rowCount = $("#DocumentUpload_Table tbody tr").length;
    //console.log(rowCount);
    if (rowCount > 1) {
        $(obj).parent().parent().remove();
    }
    else {
        $("#RemoveDocument").attr("disabled", "disabled");
    }
}
// BIND  ITEM CATEGORY TABLE
function BindFormTable(result, serial_no) {

    $("#tbl_ItemCategory tbody tr").remove();
    if (result.length == 0) {
        tr = $('<tr/>');
        tr.append("<td class='text-center' colspan='9'>NO RESULTS FOUND</td>");
        $("#tbl_ItemCategory tbody").append(tr);
    }
    else {
        for (i = 0; i < result.length; i++) {
            if (result[i].is_active == "Inactive")
                tr = $(' <tr style="background-color:#fdd2d2;"/>');
            else
                tr = $('<tr/>');

            tr.append("<td class='text-center'><button type='button' onclick='FormEdit(\"" + result[i].category_uid + "\");' class='common-btn common-btn-sm'><i class='fa-solid fa-pen-to-square'></i></button ><button type='button' onclick='FormDelete(\"" + result[i].category_uid + "\");' class='common-btn common-btn-sm ms-1'> <i class='fa-regular fa-trash-can'></i></button ></td > ");
            tr.append("<td class='text-left'>" + serial_no + "</td>");
            tr.append("<td class='text-left'>" + result[i].category_uid + "</td>");
            tr.append("<td class='text-left'><a href='javascript:void(0)' class='text-decoration-none' style='color: black !important;' onclick='FormEdit(\"" + result[i].category_uid + "\");'>" + result[i].category_code + "</a></td>");

            tr.append("<td class='text-left'><a href='javascript:void(0)' class='text-decoration-none' style='color: black !important;' onclick='FormEdit(\"" + result[i].category_uid + "\");'>" + result[i].category_desc + "</a></td>");
            //tr.append("<td class='text-center'>" + result[i].category_desc + "</td>");
            tr.append("<td class='text-center'>" + result[i].document_name + "</td>");
           
            serial_no++;
            $("#tbl_ItemCategory tbody").append(tr);
        }
    }
}

//ITEM CATEGORY LIST PAGE INDEX
function FormList(pageindex) {
    try {
        const dataString = {};
        dataString.PageSize = $("#ddlPageSize").val();
        dataString.PageIndex = pageindex;
        dataString.CategoryCode = $("#CategoryCodeSearch").val();
        dataString.CategoryDesc = $("#CategoryDescSearch").val();

        dataString.OrderBy = $("#sort-column").val().trim() + " " + $("#sort-type").val().trim();
        //ShowLoader();
        AjaxSubmission(JSON.stringify(dataString), "/Master/ItemCategory/FormList ", $('input[name=__RequestVerificationToken]').val()).done(function (result) {
            let obj = result;
            if (obj.status == true) {
                if (obj.responsecode == '100') {
                    var ser = ((parseInt(obj.data.Table1[0].PageIndex) - 1) * parseInt(obj.data.Table1[0].PageSize)) + 1;
                    BindFormTable(obj.data.Table, ser);
                    if (obj.data.Table1 != undefined && obj.data.Table1.length > 0) {
                        $(".pagination").BindPaging({
                            ActiveCssClass: "current",
                            PagerCssClass: "pager",
                            PageIndex: parseInt(obj.data.Table1[0].PageIndex),
                            PageSize: parseInt(obj.data.Table1[0].PageSize),
                            RecordCount: parseInt(obj.data.Table1[0].count)
                        });
                    }
                }
                else {
                    Toast(RetrieveMessage(obj.responsecode), "Message", "error");
                }
            }
            else {
                window.location.href = '/ClientLogin/ClientLogin';
            }
            //HideLoader();
        }).fail(function (result) {
            console.log(result.Message);
            //HideLoader();
        });
    }
    catch (e) {
        console.log(e.message);
        //HideLoader();
    }
}


//FUNCTION FOR SORTING FIELD
function Sorting(obj) {
    if (Firstcolumn != "") {
        document.getElementById(Firstcolumn).innerHTML = document.getElementById(Firstcolumn).getAttribute("data-column") + " <i class='fa-solid fa-sort'></i>";
    }
    Firstcolumn = obj.id;
    var colname = $(obj).data("column");
    $("#sort-column").val(Firstcolumn);
    var sorttype = $("#sort-type").val();
    if (sorttype == "ASC") {
        $("#sort-type").val("DESC");
        $(obj).html(colname + " <i style='margin-left:10px;' class='fa-solid fa-sort-up'></i>");
    } else if (sorttype == "DESC") {
        $("#sort-type").val("ASC");
        $(obj).html(colname + " <i style='margin-left:10px;' class='fa-solid fa-sort-down'></i>");
    }
    FormList(1);
}

// AUTO COMPLETE DROPDOWN FOR LEDGER ACC HEAD NAME
function ItemCategoryDocumentTypeautocomplete() {

    $(".DocumentType").autocomplete({
        source: function (request, response) {
            $.ajax({
                type: 'POST',
                url: "/Master/ItemCategory/GetListDocumentTypeName",
                dataType: "json",
                async: false,
                data: {
                    DocType: request.term
                },
                success: function (result) {
                    response($.map(result.data.Table, function (DoucmentName) {
                        return {
                            label: DoucmentName.doc_type,
                            value: DoucmentName.doc_type,
                            id: DoucmentName.doc_type_uid,
                        }
                    }));
                },
                error: function (response) {
                    console.log(response.responseText);
                }
            });
        },
        minLength: 1,
        selectFirst: true,
        selectOnly: true,
        select: function (e, i) {

            $("#HiddenDocTypeId").val(i.item.id);
        },

        focus: function (event, ui) { }
    }).focus(function () {
        $(this).autocomplete("search");
    });

}


// ADD  ITEM CATEGORY BUTTON CLICK
$("#FormAdd").click(function () {
    var flag = 0;
    RemoveAllError('ItemCategory');
    ValidateAllFieldNewTest('ItemCategory');

    if (Ercount == 0) {
        $("#DocumentUpload_Table tbody tr").each(function (index, ele) {
            if ($(ele).find('.DocumentType').val() == '0') {
                //  if ($(ele).find('.DocumentType').val() == '0') {
                Toast(RetrieveMessage(903), 'Message', 'error');
                flag = 1;
                return false;
            }
        });
        FormAdd();
    }

});

//FUNCTION FOR ADD  ITEM CATEGORY
function FormAdd() {
    try {
        debugger;
        const dataString = {};
        dataString.CategoryCode = $("#CategoryCode").val();
        dataString.CategoryDesc = $("#CategoryDesc").val();
        dataString.RitcNo = $("#RitcNo").val();
        dataString.ItcHsCode = $("#ItcHsCode").val();
        dataString.Ceth = $("#Ceth").val();
        dataString.Cth = $("#Cth").val();
        dataString.BcdNotiNo = $("#BcdNotiNo").val();
        dataString.BcdSiNo = $("#BcdSiNo").val();
        dataString.CvdNotiNo = $("#CvdNotiNo").val();
        dataString.CvdSiNo = $("#CvdSiNo").val();
        dataString.GsiaNotiNo = $("#GsiaNotiNo").val();
        dataString.GsiaSiNo = $("#GsiaSiNo").val();
        dataString.CentralExciseNotiNo = $("#CentralExciseNotiNo").val();
        dataString.CentralExciseSiNo = $("#CentralExciseSiNo").val();
        dataString.TtaNotiNo = $("#TtaNotiNo").val();
        dataString.TtaSiNo = $("#TtaSiNo").val();
        dataString.EduCessNotiNo = $("#EduCessNotiNo").val();
        dataString.EduCessSiNo = $("#EduCessSiNo").val();


        dataString.NcdNotiNo = $("#NcdNotiNo").val();
        dataString.NcdSiNo = $("#NcdSiNo").val();
        dataString.AntiDumpingNotiNo = $("#AntiDumpingNotiNo").val();
        dataString.AntiDumpingSiNo = $("#AntiDumpingSiNo").val();

        dataString.TariffNotiNo = $("#TariffNotiNo").val();
        dataString.TariffSiNo = $("#TariffSiNo").val();
        dataString.SaptaNo = $("#SaptaNo").val();
        dataString.SaptaSiNo = $("#SaptaSiNo").val();


        dataString.HealthNotiNo = $("#HealthNotiNo").val();
        dataString.HealthSiNo = $("#HealthSiNo").val();
        dataString.SadNotiNo = $("#SadNotiNo").val();
        dataString.SadSINo = $("#SadSINo").val();


        dataString.AggregateNotiNo = $("#AggregateNotiNo").val();
        dataString.AggregateSiNo = $("#AggregateSiNo").val();
        dataString.SafeguardNo = $("#SafeguardNo").val();
        dataString.SafeguardSiNo = $("#SafeguardSiNo").val();

        dataString.SubChargeNotiNo = $("#SubChargeNotiNo").val();
        dataString.SubChargeSiNo = $("#SubChargeSiNo").val();
        dataString.OtherNotiNo = $("#OtherNotiNo").val();
        dataString.OtherSiNo = $("#OtherSiNo").val();

        dataString.DepbNotiNo = $("#DepbNotiNo").val();
        dataString.DepbSiNo = $("#DepbSiNo").val();
        dataString.EpcgNotiNo = $("#EpcgNotiNo").val();
        dataString.DfrcNotiNo = $("#DfrcNotiNo").val();


        dataString.SionGroup = $("#SionGroup").val();
        dataString.SionSiNo = $("#SionSiNo").val();



        dataString.BasicDuty = $("#BasicDuty").val();
        dataString.DutyQtyRs = $("#DutyQtyRs").val();
        dataString.AuxDuty = $("#AuxDuty").val();
        dataString.SurCharge = $("#SurCharge").val();

        dataString.Cvd = $("#Cvd").val();
        dataString.Excise = $("#Excise").val();
        dataString.Additional = $("#Additional").val();

        dataString.Cess = $("#Cess").val();
        dataString.ECess = $("#ECess").val();
        dataString.CeCess = $("#CeCess").val();

        dataString.Sad = $("#Sad").val();
        dataString.Igst = $("#Igst").val();

        var DocDetail = new Array();
        $("#DocumentUpload_Table tbody tr").each(function () {
            var DocumentTypeDetail = {};
            DocumentTypeDetail.DocumentTypeId = $(this).find(".HiddenDocTypeId").val();
            DocDetail.push(DocumentTypeDetail);
        });
        dataString.itemCateDocTypeModals = DocDetail;
        //ShowLoader();
        AjaxSubmission(JSON.stringify(dataString), "/Master/ItemCategory/FormAdd", $('input[name=__RequestVerificationToken]').val()).done(function (result) {
            let obj = result;
            if (obj.status == true) {
                if (obj.responsecode == '101') {
                    Toast(RetrieveMessage(obj.responsecode), "Message", "success");
                    setTimeout(FormList(1), 500);
                    $("#FormAdd").hide();
                    $("#FormUpdate").show();
                    $("#FormReset").show();
                    $("#ItemCategory-tab").html("Edit Item Category");
                    $("#Timestamp").val(obj.data.Table[0].time_stemp);
                    $("#CategoryUid").val(obj.data.Table[0].category_uid);
                    // AddItemCategoryDocumentType();
                }
                else {
                    Toast(RetrieveMessage(obj.responsecode), "Message", "error");
                }
            }
            else {
                window.location.href = '/ClientLogin/ClientLogin';
            }
            //HideLoader();
        }).fail(function (result) {
            console.log(result.Message);
            //HideLoader();
        });
    }
    catch (e) {
        console.log(e.message);
        //HideLoader();
    }
}

//FUNCTION FOR EDIT  ITEM CATEGORY
function FormEdit(CategoryId) {

    try {
        const dataString = {};

        dataString.CategoryId = parseInt(CategoryId);
        //ShowLoader();
        AjaxSubmission(JSON.stringify(dataString), "/Master/ItemCategory/FormEdit", $('[name="__RequestVerificationToken"]').val()).done(function (data) {
            let obj = data;
            if (obj.status == true) {
                if (obj.responsecode == '100') {
                    TabShow();
                    var FirstChild = $("#DocumentUpload_Table").find("tbody tr:first-child");
                    var DocumentTableData = obj.data.Table;

                    $.each(DocumentTableData, function (index, ele) {
                        if (index == 0) {
                            FirstChild.find('.HiddenDocTypeId').val(ele.doc_type);
                            FirstChild.find('.DocumentType').val(ele.doc_type_name);
                        }
                        else {
                            var CloneChild = FirstChild.clone();
                            CloneChild.find('.HiddenDocTypeId').val('0');
                            CloneChild.find('.DocumentType').val('');

                            CloneChild.find('.HiddenDocTypeId').val(ele.doc_type);
                            CloneChild.find('.DocumentType').val(ele.doc_type_name);
                            $("#DocumentUpload_Table tbody").append(CloneChild);
                        }
                    });
                    $("#Timestamp").val(obj.data.Table1[0].time_stemp);
                    $("#CategoryUid").val(obj.data.Table1[0].category_uid);
                    $("#CategoryCode").val(obj.data.Table1[0].category_code);
                    $("#CategoryDesc").val(obj.data.Table1[0].category_desc);
                    $("#RitcNo").val(obj.data.Table1[0].ritc_code);
                    $("#ItcHsCode").val(obj.data.Table1[0].itc_hs_code);
                    $("#Ceth").val(obj.data.Table1[0].ceth);
                    $("#Cth").val(obj.data.Table1[0].cth);
                    $("#BcdNotiNo").val(obj.data.Table1[0].bcd_noti_no);
                    $("#BcdSiNo").val(obj.data.Table1[0].bcd_sl_no);
                    $("#CvdNotiNo").val(obj.data.Table1[0].cvd_noti_no);
                    $("#CvdSiNo").val(obj.data.Table1[0].cvd_sl_no);
                    $("#GsiaNotiNo").val(obj.data.Table1[0].gsia_noti_no);
                    $("#GsiaSiNo").val(obj.data.Table1[0].gsia_sl_no);
                    $("#CentralExciseNotiNo").val(obj.data.Table1[0].ce_noti_no);
                    $("#CentralExciseSiNo").val(obj.data.Table1[0].ce_sl_no);
                    $("#TtaNotiNo").val(obj.data.Table1[0].tta_noti_no);
                    $("#TtaSiNo").val(obj.data.Table1[0].tta_sl_no);
                    $("#EduCessNotiNo").val(obj.data.Table1[0].edu_cess_noti_no);
                    $("#EduCessSiNo").val(obj.data.Table1[0].edu_cess_sl_no);
                    $("#NcdNotiNo").val(obj.data.Table1[0].ncd_noti_no);
                    $("#NcdSiNo").val(obj.data.Table1[0].ncd_sl_no);
                    $("#AntiDumpingNotiNo").val(obj.data.Table1[0].anti_dump_noti_no);
                    $("#AntiDumpingSiNo").val(obj.data.Table1[0].anti_dump_sl_no);
                    $("#TariffNotiNo").val(obj.data.Table1[0].tarrif_noti_no);
                    $("#TariffSiNo").val(obj.data.Table1[0].tarrif_sl_no);
                    $("#SaptaNo").val(obj.data.Table1[0].sapta_no);
                    $("#SaptaSiNo").val(obj.data.Table1[0].sapta_sl_no);
                    $("#HealthNotiNo").val(obj.data.Table1[0].health_noti_no);
                    $("#HealthSiNo").val(obj.data.Table1[0].health_sl_no);
                    $("#SadNotiNo").val(obj.data.Table1[0].sad_noti_no);
                    $("#SadSINo").val(obj.data.Table1[0].sad_sl_no);
                    $("#AggregateNotiNo").val(obj.data.Table1[0].agg_noti_no);
                    $("#AggregateSiNo").val(obj.data.Table1[0].agg_sl_no);
                    $("#SafeguardNo").val(obj.data.Table1[0].safeguard_noti_no);
                    $("#SafeguardSiNo").val(obj.data.Table1[0].safeguard_sl_no);
                    $("#SubChargeNotiNo").val(obj.data.Table1[0].surcharge_noti_no);
                    $("#SubChargeSiNo").val(obj.data.Table1[0].surcharge_sl_no);
                    $("#OtherNotiNo").val(obj.data.Table1[0].other_noti_no);
                    $("#OtherSiNo").val(obj.data.Table1[0].other_sl_no);
                    $("#DepbNotiNo").val(obj.data.Table1[0].depb_noti_no);
                    $("#DepbSiNo").val(obj.data.Table1[0].depb_sl_no);
                    $("#EpcgNotiNo").val(obj.data.Table1[0].epcg_noti_no);
                    $("#DfrcNotiNo").val(obj.data.Table1[0].dfrc_noti_no);
                    $("#SionGroup").val(obj.data.Table1[0].sion_group_no);
                    $("#SionSiNo").val(obj.data.Table1[0].sion_sl_no);
                    $("#BasicDuty").val(obj.data.Table1[0].basic_duty.toFixed(2));
                    $("#DutyQtyRs").val(obj.data.Table1[0].qty_dty.toFixed(2));
                    $("#AuxDuty").val(obj.data.Table1[0].aux_duty.toFixed(2));
                    $("#SurCharge").val(obj.data.Table1[0].srch_duty.toFixed(2));
                    $("#Cvd").val(obj.data.Table1[0].cvd_duty.toFixed(2));
                    $("#Excise").val(obj.data.Table1[0].excise_duty.toFixed(2));
                    $("#Additional").val(obj.data.Table1[0].add_duty.toFixed(2));
                    $("#Cess").val(obj.data.Table1[0].cess_duty.toFixed(2));
                    $("#ECess").val(obj.data.Table1[0].e_cess_dty.toFixed(2));
                    $("#CeCess").val(obj.data.Table1[0].ce_dty.toFixed(2));
                    $("#Sad").val(obj.data.Table1[0].sad_duty.toFixed(2));
                    $("#Igst").val(obj.data.Table1[0].igst.toFixed(2));
                }
                else {
                    Toast(RetrieveMessage(obj.responsecode), "Message", "error");
                }
            }
            else {
                window.location.href = '/ClientLogin/ClientLogin';
            }
            //HideLoader();
        }).fail(function (data) {
            console.log(data.Message);
            //HideLoader();
        });
    }
    catch (e) {
        console.log(e.message);
        //HideLoader();
    }
}

// UPDATE  ITEM CATEGORY BUTTON CLICK
$("#FormUpdate").click(function () {
    var flag = 0
    RemoveAllError('ItemCategory');
    ValidateAllField('ItemCategory');
    if (Ercount == 0) {
        $("#DocumentUpload_Table tbody tr").each(function (index, ele) {

            if ($(ele).find('.DocumentType').val() == '') {
                Toast(RetrieveMessage(903), 'Message', 'error');
                flag = 1;
                return false;
            }
        });

        FormUpdate();

    }

});

//FUNCTION FOR UPDATE ITEM CATEGORY
function FormUpdate() {
    try {
        const dataString = {};
        dataString.CategoryCode = $("#CategoryCode").val();
        dataString.CategoryDesc = $("#CategoryDesc").val();
        dataString.RitcNo = $("#RitcNo").val();
        dataString.ItcHsCode = $("#ItcHsCode").val();
        dataString.Ceth = $("#Ceth").val();
        dataString.Cth = $("#Cth").val();
        dataString.BcdNotiNo = $("#BcdNotiNo").val();
        dataString.BcdSiNo = $("#BcdSiNo").val();
        dataString.CvdNotiNo = $("#CvdNotiNo").val();
        dataString.CvdSiNo = $("#CvdSiNo").val();
        dataString.GsiaNotiNo = $("#GsiaNotiNo").val();
        dataString.GsiaSiNo = $("#GsiaSiNo").val();
        dataString.CentralExciseNotiNo = $("#CentralExciseNotiNo").val();
        dataString.CentralExciseSiNo = $("#CentralExciseSiNo").val();
        dataString.TtaNotiNo = $("#TtaNotiNo").val();
        dataString.TtaSiNo = $("#TtaSiNo").val();
        dataString.EduCessNotiNo = $("#EduCessNotiNo").val();
        dataString.EduCessSiNo = $("#EduCessSiNo").val();
        dataString.NcdNotiNo = $("#NcdNotiNo").val();
        dataString.NcdSiNo = $("#NcdSiNo").val();
        dataString.AntiDumpingNotiNo = $("#AntiDumpingNotiNo").val();
        dataString.AntiDumpingSiNo = $("#AntiDumpingSiNo").val();
        dataString.TariffNotiNo = $("#TariffNotiNo").val();
        dataString.TariffSiNo = $("#TariffSiNo").val();
        dataString.SaptaNo = $("#SaptaNo").val();
        dataString.SaptaSiNo = $("#SaptaSiNo").val();
        dataString.HealthNotiNo = $("#HealthNotiNo").val();
        dataString.HealthSiNo = $("#HealthSiNo").val();
        dataString.SadNotiNo = $("#SadNotiNo").val();
        dataString.SadSINo = $("#SadSINo").val();
        dataString.AggregateNotiNo = $("#AggregateNotiNo").val();
        dataString.AggregateSiNo = $("#AggregateSiNo").val();
        dataString.SafeguardNo = $("#SafeguardNo").val();
        dataString.SafeguardSiNo = $("#SafeguardSiNo").val();
        dataString.SubChargeNotiNo = $("#SubChargeNotiNo").val();
        dataString.SubChargeSiNo = $("#SubChargeSiNo").val();
        dataString.OtherNotiNo = $("#OtherNotiNo").val();
        dataString.OtherSiNo = $("#OtherSiNo").val();
        dataString.DepbNotiNo = $("#DepbNotiNo").val();
        dataString.DepbSiNo = $("#DepbSiNo").val();
        dataString.EpcgNotiNo = $("#EpcgNotiNo").val();
        dataString.DfrcNotiNo = $("#DfrcNotiNo").val();
        dataString.SionGroup = $("#SionGroup").val();
        dataString.SionSiNo = $("#SionSiNo").val();
        dataString.BasicDuty = $("#BasicDuty").val();
        dataString.DutyQtyRs = $("#DutyQtyRs").val();
        dataString.AuxDuty = $("#AuxDuty").val();
        dataString.SurCharge = $("#SurCharge").val();
        dataString.Cvd = $("#Cvd").val();
        dataString.Excise = $("#Excise").val();
        dataString.Additional = $("#Additional").val();
        dataString.Cess = $("#Cess").val();
        dataString.ECess = $("#ECess").val();
        dataString.CeCess = $("#CeCess").val();
        dataString.Sad = $("#Sad").val();
        dataString.Igst = $("#Igst").val();
        dataString.timestamp = $("#Timestamp").val();
        dataString.CategoryId = $("#CategoryUid").val();
        var DocDetail = new Array();
        $("#DocumentUpload_Table tbody tr").each(function () {
            var DocumentTypeDetail = {};
            DocumentTypeDetail.DocumentTypeId = $(this).find(".HiddenDocTypeId").val();
            DocDetail.push(DocumentTypeDetail);
        });
        dataString.itemCateDocTypeModals = DocDetail;
        //ShowLoader();
        AjaxSubmission(JSON.stringify(dataString), "/Master/ItemCategory/FormUpdate", $('input[name=__RequestVerificationToken]').val()).done(function (result) {
            let obj = result;
            if (obj.status == true) {
                if (obj.responsecode == '107') {
                    Toast(RetrieveMessage(obj.responsecode), "Message", "success");
                    setTimeout(FormList(1), 500);
                    $("#Timestamp").val(obj.data.Table[0].time_stemp);
                    $("#CategoryUid").val(obj.data.Table[0].category_uid);

                }
                else {
                    Toast(RetrieveMessage(obj.responsecode), "Message", "error");
                }
            }
            else {
                window.location.href = '/ClientLogin/ClientLogin';
            }
            //HideLoader();
        }).fail(function (result) {
            console.log(result.Message);
            //HideLoader();
        });
    }
    catch (e) {
        console.log(e.message);
        //HideLoader();
    }
}


//FUNCTION FOR DELETE ITEM CATEGORY
function FormDelete(e) {
    try {
        $.confirm({
            title: '',
            content: 'Are You Sure Want To Delete ?',
            type: 'red',
            boxWidth: '300px',
            useBootstrap: false,
            columnClass: 'small',
            containerFluid: true,
            typeAnimated: true,
            buttons: {
                tryAgain: {
                    text: 'Confirm',
                    btnClass: 'btn-red',
                    action: function () {

                        const datastring = {};
                        datastring.CategoryId = parseInt(e);
                        //ShowLoader();
                        AjaxSubmission(JSON.stringify(datastring), "/Master/ItemCategory/FormDelete", $('[name="__RequestVerificationToken"]').val()).done(function (data) {
                            let obj = data;
                            if (obj.status == true) {
                                if (obj.responsecode == '102') {
                                    Toast(RetrieveMessage(obj.responsecode), "Message", "success");
                                    FormList(1);
                                    /* GetParentMenuName();*/
                                }
                                else {
                                    Toast(RetrieveMessage(obj.responsecode), "Message", "error");
                                }
                            }
                            else {
                                window.location.href = 'ClientLogin/ClientLogin';
                            }
                            //HideLoader();
                        }).fail(function (data) {
                            console.log(data.Message);
                            //HideLoader();
                        });
                    }
                },
                close: function () {
                    //HideLoader();
                }
            }
        });
    }
    catch (e) {
        console.log(e.message);
        //HideLoader();
    }
}


//FUNCTION FOR REST INPUT TYPE FIELD
function ResetForm() {
    $("#FormAdd").show();
    $("#FormUpdate").hide();
    $("#FormReset").hide();
    $("#ItemCategory-tab").html("Add Item Category");

    $("#Timestamp").val('');
    $("#CategoryUid").val('');
    $("#CategoryCodeError").html("");
    $("#CategoryDescError").html("");


    $("#CategoryCode").val("");
    $("#CategoryDesc").val("");


    $("#RitcNo").val("");
    $("#ItcHsCode").val("");
    $("#Ceth").val("");
    $("#Cth").val("");


    $("#BcdNotiNo").val("");
    $("#BcdSiNo").val("");
    $("#CvdNotiNo").val("");
    $("#CvdSiNo").val("");

    $("#GsiaNotiNo").val("");
    $("#GsiaSiNo").val("");
    $("#CentralExciseNotiNo").val("");
    $("#CentralExciseSiNo").val("");


    $("#TtaNotiNo").val("");
    $("#TtaSiNo").val("");
    $("#EduCessNotiNo").val("");
    $("#EduCessSiNo").val("");


    $("#NcdNotiNo").val("");
    $("#NcdSiNo").val("");
    $("#AntiDumpingNotiNo").val("");
    $("#AntiDumpingSiNo").val("");

    $("#TariffNotiNo").val("");
    $("#TariffSiNo").val("");
    $("#SaptaNo").val("");
    $("#SaptaSiNo").val("");


    $("#HealthNotiNo").val("");
    $("#HealthSiNo").val("");
    $("#SadNotiNo").val("");
    $("#SadSINo").val("");


    $("#AggregateNotiNo").val("");
    $("#AggregateSiNo").val("");
    $("#SafeguardNo").val("");
    $("#SafeguardSiNo").val("");

    $("#SubChargeNotiNo").val("");
    $("#SubChargeSiNo").val("");
    $("#OtherNotiNo").val("");
    $("#OtherSiNo").val("");

    $("#DepbNotiNo").val("");
    $("#DepbSiNo").val("");
    $("#EpcgNotiNo").val("");
    $("#DfrcNotiNo").val("");


    $("#SionGroup").val("");
    $("#SionSiNo").val("");



    $("#BasicDuty").val("0.00");
    $("#DutyQtyRs").val("0.00");
    $("#AuxDuty").val("0.00");
    $("#SurCharge").val("0.00");

    $("#Cvd").val("0.00");
    $("#Excise").val("0.00");
    $("#Additional").val("0.00");

    $("#Cess").val("0.00");
    $("#ECess").val("0.00");
    $("#CeCess").val("0.00");

    $("#Sad").val("0.00");
    $("#Igst").val("0.00");

    var tbody = $("#DocumentUpload_Table").find("tbody");
    var Tr = $(tbody).find("tr");

    var rowCount = Tr.length;
    if (rowCount > 1) {
        $("#DocumentUpload_Table tbody tr").each(function (index, ele) {
            if (index > 0) {
                $(ele).remove();
            }
            else {
                $(ele).find('.DocumentType').val('');
                $(ele).find('.HiddenDocTypeId').val('');
                $("#DocumentUpload_Table").find("tbody").append(ele);
            }
        });

    }
    else {
        Tr.find('.DocumentType').val('');
        Tr.find('.HiddenDocTypeId').val('');
        $("#DocumentUpload_Table").find("tbody").append(Tr);
    }
};

//FUNCTION FOR EXPORT DATA IN EXCEL
function FormExcel() {
    ShowLoader();
    let date = new Date();
    let NewDate = ("00" + date.getDate()).slice(-2) + "_" + ("00" + (date.getMonth() + 1)).slice(-2) + "_" + date.getFullYear() + "_" + ("00" + date.getHours()).slice(-2) + "_" + ("00" + date.getMinutes()).slice(-2) + "_" + ("00" + date.getSeconds()).slice(-2);
    let fileName = "ItemCategory_" + NewDate + ".xlsx";

    $('#FormSearch').trigger('click');
    AjaxSubmission(null, '/Master/ItemCategory/FormExcel', $('input[name=__RequestVerificationToken]').val()).done(function (result) {
        let obj = result;
        if (obj.status == true) {
            if (obj.responsecode == '100') {

                let bytes = Base64ToBytes(obj.data.FileData[0].Base64Data);
                let blob = new Blob([bytes], { type: "application/octetstream" });
                let isIE = false || !!document.documentMode;
                if (isIE) {
                    window.navigator.msSaveBlob(blob, fileName);
                } else {
                    let url = window.URL || window.webkitURL;
                    link = url.createObjectURL(blob);
                    let a = $("<a />");
                    a.attr("download", fileName);
                    a.attr("href", link);
                    $("body").append(a);
                    a[0].click();
                    $("body").remove(a);
                }
            }
            else if (obj.responsecode == '302')
                Toast("No Records found.", 'Message', 'success');
            else
                Toast(RetrieveMessage(obj.responsecode), 'Message', 'error');

        } else
            window.location.href = '/ClientLogin/ClientLogin';
        HideLoader();

    }).fail(function (result) {
        console.log(result.Message);
        HideLoader();
    });
}
//FUCNTION FOR TAB SHOW
function TabShow() {
    $('#ItemCategory_list-tab').removeClass('active');
    $('#ItemCategory-tab').addClass('active');
    $('#ItemCategory_list').removeClass('active show');
    $('#ItemCategory').addClass('active show');
    $("#FormAdd").hide();
    $("#FormUpdate").show();
    $("#FormReset").show();
    $("#ItemCategory-tab").html("Edit Item Category");
}

//FUNCTION FOR TAB HIDE
function TabHide() {
    $('#ItemCategory-tab').removeClass('active');
    $('#ItemCategory_list-tab').addClass('active ');
    $('#ItemCategory_list').addClass('active show');
    $('#ItemCategory').removeClass('active show');
    $("#FormAdd").show();
    $("#FormUpdate").hide();
    $("#FormReset").hide();
    $("#ItemCategory-tab").html("Add Item Category");
}

//MENU LIST TAB CLICKED
$("#ItemCategory_list-tab").click(function () {
    RemoveAllError('ItemCategory');
    ResetForm();
})

$(".ItemCategory_list").click(function () {
    $("#CategoryCodeSearch").focus();
});
$("#FormReset").click(function () {
    ResetForm();
})

document.addEventListener("keydown", function (zEvent) {
    if (zEvent.ctrlKey && zEvent.altKey && (zEvent.key == "j" || zEvent.key == "J")) {
        $('#ItemCategory_list-tab').removeClass('active ');
        $('#ItemCategory_list').removeClass('active show');
        $('#ItemCategory-tab').addClass('active');
        $('#ItemCategory').addClass('active show');
        $("#FormAdd").show();
        $("#FormUpdate").hide();
        $("#FormReset").hide();
        $("#ItemCategory-tab").html("Add Item Category ");
        $('#CategoryCode').focus();
        RemoveAllError('ItemCategory');
        ResetForm();
       
    }
});