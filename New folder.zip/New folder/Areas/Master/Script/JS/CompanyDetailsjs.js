﻿var Firstcolumn = "";
var Ercount = 0;
var Action = "";
var State_code_selected = "";


//DOCUMNET READY
$(document).ready(function () {
    Firstcolumn = "company_name";
    ShowLoader();
    localStorage.setItem('PageName', 'Company List');
    FillPageSizeList('ddlPageSize', FormList);


    $("#Country").select2({
        width: '100%'
    });
    $("#StateCode").select2({
        width: '100%'
    });

    FillCountryList('Country', 'Client');
    $("#InvoiceTemplate").val("Default");
    $("#SaleOrderTemplate").val("Default");
    $("#DebitNoteTemplate").val("Default");
    $("#CreditNoteTemplate").val("Default");


    HideLoader();
});
function ImagePreviewModel(e) {
    $("#image-model").modal('show');
    var SourceFile = $(e).prop('src');

    $("#PreviewImage").attr("src", SourceFile);

}
$("#EnableSSL").change(function () {
    if ($("#EnableSSL").is(':checked')) {
        $("#SmtpPort").val('587');
    }
    else {
        $("#SmtpPort").val('25');
    }
});

$(document).on("click", ".pagination .page", function () {
    FormList(($(this).attr('page')));
});

//SEARCH BUTTON CLICKED
$("#FormSearch").click(function () {
    FormList(1);
});
//PAGE SIZE CLICKED
$("#ddlPageSize").change(function () {
    FormList(1);
});
//FUNCTION FOR CLIENT COMPANY LIST
function FormList(pageindex) {
    try {
        const dataString = {};
        dataString.PageSize = $("#ddlPageSize").val();
        dataString.PageIndex = pageindex;
        dataString.CompanyId = parseInt($("#IdSearch").val().trim());
        dataString.CompanyName = $("#CompanyNameSearch").val();
        dataString.OrderBy = $("#sort-column").val().trim() + " " + $("#sort-type").val().trim();
        //ShowLoader();
        $('#IdSearch').focus();
        AjaxSubmission(JSON.stringify(dataString), "/Company/FormList", $('input[name=__RequestVerificationToken]').val()).done(function (result) {
            let obj = result;
            if (obj.status == true) {
                if (obj.responsecode == '100') {
                    var ser = ((parseInt(obj.data.Table1[0].PageIndex) - 1) * parseInt(obj.data.Table1[0].PageSize)) + 1;
                    BindFormTable(obj.data.Table, ser);
                    $(".pagination").BindPaging({
                        ActiveCssClass: "current",
                        PagerCssClass: "pager",
                        PageIndex: parseInt(obj.data.Table1[0].PageIndex),
                        PageSize: parseInt(obj.data.Table1[0].PageSize),
                        RecordCount: parseInt(obj.data.Table1[0].count)
                    });
                }
                else
                    Toast(RetrieveMessage(obj.responsecode), "Message", "error");
            }
            else
                window.location.href = '/ClientLogin/ClientLogin';
            //HideLoader();
        }).fail(function (result) {
            console.log(result.Message);
            //HideLoader();
        });
    }
    catch (e) {
        console.log(e.message);
        //HideLoader();
    }
}

//BIND CLIENT COMPANY TABLE
function BindFormTable(result, serial_no) {
    $("#tbl_client_company tbody tr").remove();
    if (result.length == 0) {
        tr = $('<tr/>');
        tr.append("<td class='text-center' colspan='7'>NO RESULTS FOUND</td>");
        $("#tbl_client_company tbody").append(tr);
    }
    else {
        for (i = 0; i < result.length; i++) {
            if (result[i].is_active == "Inactive")
                tr = $(' <tr style="background-color:#fdd2d2;"/>');
            else
                tr = $('<tr/>');

            tr.append("<td class='text-center'> <button type='button' onclick='FormEdit(\"" + result[i].company_id + "\");' class='common-btn common-btn-sm' ><i class='fa-solid fa-pen-to-square'></i></button > <button type='button' onclick='FormDelete(\"" + result[i].company_id + "\");' class='common-btn common-btn-sm' > <i class='fa-regular fa-trash-can'></i></button ></td > ");
            tr.append("<td class='text-left'>" + serial_no + "</td>");
            tr.append("<td class='text-left'>" + result[i].company_id + "</td>");
            tr.append("<td class='text-center'><a href='javascript:void(0)' class='text-decoration-none' style='color: black !important;' onclick='FormEdit(\"" + result[i].company_id + "\");'>" + result[i].company_name + "</a></td>");
            tr.append("<td class='text-center'>" + HandleNullTextValue(result[i].email_id_primary) + "</td>");
            tr.append("<td class='text-center'>" + HandleNullTextValue(result[i].mobile_no_primary) + "</td>");
            tr.append("<td class='text-center'>" + HandleNullTextValue(result[i].gstin_no) + "</td>");

            $("#tbl_client_company tbody").append(tr);
            serial_no++;
        }
    }
}


//FUNCTION FOR ADD COMPANY DETAILS
function FormAdd() {
    try {
        var form = $('#myform')[0];
        var mydata = new FormData(form);
        ShowLoader();
        AjaxSubmissionformdata(mydata, "/Master/Company/FormAdd", $('[name="__RequestVerificationToken"]').val()).done(function (result) {
            let obj = result;
            if (obj.status == true) {
                if (obj.responsecode == '101') {
                    Toast(RetrieveMessage(obj.responsecode), "Message", "success");
                    setTimeout(FormList(1), 2000);
                    $("#FormAdd").hide();
                    $("#FormUpdate").show();
                    $("#FormReset").show();
                    $("#Company-tab").html("Edit Company");
                }
                else
                    Toast(RetrieveMessage(obj.responsecode), "Message", "error");
            }
            else
                window.location.href = '/ClientLogin/ClientLogin';
            HideLoader();
        }).fail(function (result) {
            console.log(result.Message);
            HideLoader();
        });
    }
    catch (ex) {
        console.log(ex.message);
        HideLoader();
    }
}

//COMPANY DETAILS SAVE CLICK
$("#FormAdd").click(function () {
    try {
        RemoveAllError('Company');
        ValidateAllFieldNewTest('Company');       
        if (Ercount == 0) {
            if ($("#Country").val() == "0") {
                Toast(RetrieveMessage(707), 'Message', 'error');
                return;
            }
            if ($("#StateCode").val() == "0") {
                Toast(RetrieveMessage(708), 'Message', 'error');
                return;
            }
            if ($("#SmtpEmailId").val() != '') {
                Toast("Please Verify Email First !", 'Message', 'error');
                return;
            }
            FormAdd();
        }
    }
    catch (ex) {
        console.log(ex.message);
    }

});


//EDIT COMPANY DETAILS
function FormEdit(e) {
    try {
        const datastring = {};
        datastring.CompanyId = e;
        ShowLoader();
        AjaxSubmission(JSON.stringify(datastring), "/Master/Company/FormEdit", $('[name="__RequestVerificationToken"]').val()).done(function (data) {
            let obj = data;

            if (obj.status == true) {

                if (obj.responsecode == '100') {
                    TabShow();

                    if (obj.data.Table[0].company_logo != null) {
                        if (obj.data.Table[0].company_logo.length > 0) {

                            $("#CompanyLogoTmpImageFile").val(obj.data.Table[0].company_logo);
                            $("#CompanyLogoImagePreview").css("display", "block");
                            $("#CompanyLogoImagePreview").attr('src', obj.data.Table[0].company_logo);
                        }
                    }
                    if (obj.data.Table[0].company_letter_head != null) {
                        if (obj.data.Table[0].company_letter_head.length > 0) {
                            $("#CompanyLetterHeadTmpImageFile").val(obj.data.Table[0].company_letter_head);
                            $("#CompanyLetterHeadImagePreview").css("display", "block");
                            $("#CompanyLetterHeadImagePreview").attr('src', obj.data.Table[0].company_letter_head);
                        }
                    }
                    debugger;
                    $("#CompanyName").val(obj.data.Table[0].company_name);
                    $("#CompanyCode").val(obj.data.Table[0].CompanyCode);
                    $("#CompanyEmail").val(obj.data.Table[0].email_id_primary);
                    $("#InfoEmail").val(obj.data.Table[0].email_id_info);
                    $("#MobileNumber").val(obj.data.Table[0].mobile_no_primary);
                    $("#TelPhone").val(obj.data.Table[0].phone_number);
                    $("#Fax").val(obj.data.Table[0].fax);
                    $("#PanNo").val(obj.data.Table[0].pan_no);
                    $("#Gstin").val(obj.data.Table[0].gstin_no);
                    $("#CIN").val(obj.data.Table[0].cin_no);
                    $("#Website").val(obj.data.Table[0].website);
                    $("#AccessToken").val(obj.data.Table[0].access_token);

                    $("#EnableSms").prop("checked", obj.data.Table[0].sms_enable);
                    $("#EnableEmail").prop("checked", obj.data.Table[0].email_enable);
                    $("#IsDefault").prop("checked", obj.data.Table[0].is_default);
                    $("#ChangeTaxOnInvoice").prop("checked", obj.data.Table[0].allow_change_in_tax);

                    $("#CompanyAddressFirst").val(obj.data.Table[0].address_1);
                    $("#CompanyAddressSecond").val(obj.data.Table[0].address_2);
                    StateCodeSelected = obj.data.Table[0].state_code;
                    $("#Country").val(obj.data.Table[0].country).trigger("change");

                    $("#CityName").val(obj.data.Table[0].city);
                    $("#PinCode").val(obj.data.Table[0].pin_code);
                    $("#SmtpEmailId").val(obj.data.Table[0].email_id);
                    $("#SmtpEmailPassword").val(obj.data.Table[0].email_password);
                    $("#SmtpEmailserver").val(obj.data.Table[0].email_server);
                    $("#SmtpPort").val(obj.data.Table[0].email_smtp_port);

                    $("#EnableSSL").prop("checked", obj.data.Table[0].email_ssl);
                    $("#VerifySSL").prop("checked", obj.data.Table[0].email_verify_ssl);
                    $("#AlwaysCCToSmtp").prop("checked", obj.data.Table[0].email_cc_to_self);

                    $("#CCEmailAddress").val(obj.data.Table[0].email_cc_email);
                  

                    $("#ImapPopEmailId").val(obj.data.Table[0].ImapPopEmailId);
                    $("#ImapPopEmailPassword").val('');
                    $("#ServerType").val(obj.data.Table[0].ServerType == null ? 'IMAP' : obj.data.Table[0].ServerType);
                    $("#IncomingMailServer").val(obj.data.Table[0].IncomingMailServer);
                    $("#IncomingPort").val(obj.data.Table[0].IncomingPort);
                    $("#IncomingSSL").prop("checked", obj.data.Table[0].IncomingSSL);
                    $("#ImportSenderId").val(obj.data.Table[0].ImportSenderId);
                    $("#ExportSenderId").val(obj.data.Table[0].ExportSenderId);
                    $("#ESanchitSenderId").val(obj.data.Table[0].ESanchitSenderId);


                    $("#RoundoffInvoice").prop("checked", obj.data.Table[0].round_off_invoice);
                    $("#ApproveInvoice").prop("checked", obj.data.Table[0].approve_invoice);
                    $("#ApprovePurchase").prop("checked", obj.data.Table[0].approve_purchase);
                    $("#ApproveVoucher").prop("checked", obj.data.Table[0].approve_voucher);
                    $("#InvoiceMinLength").val(obj.data.Table[0].invoice_no_min_length);
                    $("#EwayBillAmount").val(obj.data.Table[0].eway_bill_amount);
                    $("#PasswordResetDays").val(obj.data.Table[0].password_reset_day);
                    $("#UrlExpireDays").val(obj.data.Table[0].url_expire_time);
                    $("#WhiteListIp").val(obj.data.Table[0].white_list_ip);
                    $("#SMSAPI").val(obj.data.Table[0].sms_api);
                    $("#WhatsAppApi").val(obj.data.Table[0].whatsapp_api);
                    $("#FirebaseAccessKey").val(obj.data.Table[0].firebase_key);

                    if (obj.data.Table[0].template_invoice == null) {
                        $("#InvoiceTemplate").val('Default');
                    }
                    else {
                        $("#InvoiceTemplate").val(obj.data.Table[0].template_invoice);
                    }
                    if (obj.data.Table[0].template_so == null) {
                        $("#SaleOrderTemplate").val('Default');
                    }
                    else {
                        $("#SaleOrderTemplate").val(obj.data.Table[0].template_so);
                    }
                    if (obj.data.Table[0].template_dbn == null) {
                        $("#DebitNoteTemplate").val('Default');
                    }
                    else {
                        $("#DebitNoteTemplate").val(obj.data.Table[0].template_dbn);
                    }
                    if (obj.data.Table[0].template_crn == null) {
                        $("#CreditNoteTemplate").val('Default');
                    }
                    else {
                        $("#CreditNoteTemplate").val(obj.data.Table[0].template_crn);
                    }
                    $("#InvTopHeight").val(obj.data.Table[0].inv_top_height);
                    $("#InvHeaderHeight").val(obj.data.Table[0].inv_header_height);
                    $("#InvFooterHeight").val(obj.data.Table[0].inv_footer_height);
                    $("#SOTopHeight").val(obj.data.Table[0].so_top_height);
                    $("#SOHeaderHeight").val(obj.data.Table[0].so_header_height);
                    $("#SOFooterHeight").val(obj.data.Table[0].so_footer_height);
                }
                else
                    Toast(RetrieveMessage(obj.responsecode), "Message", "error");
            }
            else
                window.location.href = '/ClientLogin/ClientLogin';
            HideLoader();
        }).fail(function (data) {
            console.log(data.Message);
            HideLoader();
        });
    }
    catch (e) {
        console.log(e.message);
        HideLoader();
    }
}

//FUNCTION FOR UPDATE COMPANY DETAILS
function FormUpdate() {
    try {
        var form = $('#myform')[0];
        var mydata = new FormData(form);
        ShowLoader();
        AjaxSubmissionformdata(mydata, "/Master/Company/FormUpdate", $('[name="__RequestVerificationToken"]').val()).done(function (result) {
            let obj = result;
            if (obj.status == true) {
                if (obj.responsecode == '107') {
                    Toast(RetrieveMessage(obj.responsecode), "Message", "success");
                    setTimeout(FormList(1), 2000);
                }
                else if (obj.responsecode == '1011') {
                    Toast(RetrieveMessage(obj.responsecode), "Message", "success");
                    setTimeout(FormList(1), 2000);
                }
                else
                    Toast(RetrieveMessage(obj.responsecode), "Message", "error");
            }
            else
                window.location.href = '/ClientLogin/ClientLogin';
            HideLoader();
        }).fail(function (result) {
            console.log(result.Message);
            HideLoader();

        });
    }
    catch (ex) {
        console.log(ex.message);
        HideLoader();
    }
}

//COMPANY DETAILS UPDATE
$("#FormUpdate").click(function () {

    try {
        RemoveAllError('Company');
        ValidateAllFieldNewTest('Company');
        if (Ercount == 0) {
            if ($("#Country").val() == "0") {
                Toast(RetrieveMessage(707), 'Message', 'error');
                return;
            }
            if ($("#StateCode").val() == "0") {
                Toast(RetrieveMessage(708), 'Message', 'error');
                return;
            }
            //if ($("#SmtpEmailId").val().length != 0) {
            //    if ($("#SmtpEmailPassword").val().length == 0) {
            //        Toast("Please Enter Password !", 'Message', 'error');
            //        return;
            //    }
            //    if ($("#SmtpPort").val().length == 0) {
            //        Toast("Please Enter SMTP Port !", 'Message', 'error');
            //        return;
            //    }
            //    if ($("#SmtpEmailserver").val().length == 0) {
            //        Toast("Please Enter Email Server !", 'Message', 'error');
            //        return;
            //    }
            //}
            FormUpdate();
        }
    }
    catch (ex) {
        console.log(ex.message);
    }

});

function FormDelete(){

}

//FUNCTION FOR SORTING FIELD
function FormSorting(obj) {

    if (Firstcolumn != "") {
        document.getElementById(Firstcolumn).innerHTML = document.getElementById(Firstcolumn).getAttribute("data-column") + " <i class='fa-solid fa-sort'></i>";
    }
    Firstcolumn = obj.id;
    var colname = $(obj).data("column");
    $("#sort-column").val(Firstcolumn);
    var sorttype = $("#sort-type").val();
    if (sorttype == "ASC") {
        $("#sort-type").val("DESC");
        $(obj).html(colname + " <i style='margin-left:10px;' class='fa-solid fa-sort-down'></i>");
    } else if (sorttype == "DESC") {
        $("#sort-type").val("ASC");
        $(obj).html(colname + " <i style='margin-left:10px;' class='fa-solid fa-sort-up'></i>");
    }
    FormList(1);
}



//COUNTRY CHANGE EVENT
$("#Country").change(function () {
    FillStateList($("#Country").val(), 'StateCode');
});

//FUNCTION FOR RESET DATA
function ResetForm() {
    $("#FormAdd").show();
    $("#FormUpdate").hide();
    $("#FormReset").hide();
    $("#Company-tab").html("Add Company");

    $("#CompanyLogoImagePreview").attr('src', '');
    $("#CompanyLetterHeadImagePreview").attr('src', '');
    $("#CompanyLogoImagePreview").css('display', 'none');
    $("#CompanyLetterHeadImagePreview").css('display', 'none');


    FillCountryList('Country', 'Client');
    $("#StateCode").val(0).trigger("change");
    $("#CompanyName").val("");
    $("#CompanyCode").val("");
    $("#CompanyEmail").val("");
    $("#InfoEmail").val("");
    $("#MobileNumber").val("");
    $("#TelPhone").val("");
    $("#Fax").val("");
    $("#PanNo").val("");
    $("#Gstin").val("");
    $("#CIN").val("");
    $("#Website").val("");
    $("#AccessToken").val("");
    $("#EnableSms").prop("checked", false);
    $("#EnableEmail").prop("checked", false);
    $("#IsDefault").prop("checked", false);
    $("#ChangeTaxOnInvoice").prop("checked", false);
    $("#CompanyAddressFirst").val("");
    $("#CompanyAddressSecond").val("");
    $("#CityName").val("");
    $("#PinCode").val("");
    $("#SmtpEmailId").val("");
    $("#SmtpEmailPassword").val("");
    $("#SmtpEmailserver").val("");
    $("#SmtpPort").val("");
    $("#EnableSSL").prop("checked", false);
    $("#VerifySSL").prop("checked", false);
    $("#AlwaysCCToSmtp").prop("checked", false);
    $("#CCEmailAddress").val("");

    $("#ImapPopEmailId").val('');
    $("#ImapPopEmailPassword").val('');
    $("#ServerType").val('IMAP');
    $("#IncomingMailServer").val('');
    $("#IncomingPort").val('');
    $("#IncomingSSL").prop("checked", false);
    $("#ImportSenderId").val('');
    $("#ExportSenderId").val('');
    $("#ESanchitSenderId").val('');

    $("#RoundoffInvoice").prop("checked", false);
    $("#ApproveInvoice").prop("checked", false);
    $("#ApprovePurchase").prop("checked", false);
    $("#ApproveVoucher").prop("checked", false);
    $("#InvoiceMinLength").val("1");
    $("#EwayBillAmount").val("");
    $("#PasswordResetDays").val("0");
    $("#UrlExpireDays").val("0");
    $("#WhiteListIp").val("");
    $("#SMSAPI").val("");
    $("#WhatsAppApi").val("");
    $("#FirebaseAccessKey").val("");
    $("#InvoiceTemplate").val("Default");
    $("#SaleOrderTemplate").val("Default");
    $("#DebitNoteTemplate").val("Default");
    $("#CreditNoteTemplate").val("Default");
    $("#InvTopHeight").val("");
    $("#InvHeaderHeight").val("");
    $("#InvFooterHeight").val("");
    $("#SOTopHeight").val("");
    $("#SOHeaderHeight").val("");
    $("#SOFooterHeight").val("");
}

//FUNCTION FOR EXPORT DATA IN EXCEL
function FormExcel() {
    ShowLoader();
    let date = new Date();
    let NewDate = ("00" + date.getDate()).slice(-2) + "_" + ("00" + (date.getMonth() + 1)).slice(-2) + "_" + date.getFullYear() + "_" + ("00" + date.getHours()).slice(-2) + "_" + ("00" + date.getMinutes()).slice(-2) + "_" + ("00" + date.getSeconds()).slice(-2);
    let fileName = "Company_" + NewDate + ".xlsx";

    $('#FormSearch').trigger('click');
    AjaxSubmission(null, '/Master/Company/FormExcel', $('input[name=__RequestVerificationToken]').val()).done(function (result) {
        let obj = result;
        if (obj.status == true) {
            if (obj.responsecode == '100') {

                let bytes = Base64ToBytes(obj.data.FileData[0].Base64Data);
                let blob = new Blob([bytes], { type: "application/octetstream" });
                let isIE = false || !!document.documentMode;
                if (isIE) {
                    window.navigator.msSaveBlob(blob, fileName);
                } else {
                    let url = window.URL || window.webkitURL;
                    link = url.createObjectURL(blob);
                    let a = $("<a />");
                    a.attr("download", fileName);
                    a.attr("href", link);
                    $("body").append(a);
                    a[0].click();
                    $("body").remove(a);
                }
            }
            else if (obj.responsecode == '302')
                Toast("No Records found.", 'Message', 'success');
            else
                Toast(RetrieveMessage(obj.responsecode), 'Message', 'error');

        } else
            window.location.href = '/ClientLogin/ClientLogin';
        HideLoader();

    }).fail(function (result) {
        console.log(result.Message);
        HideLoader();
    });
}


//FUCNTION FOR TAB SHOW
function TabShow() {
    $('#Company_list-tab').removeClass('active');
    $('#Company-tab').addClass('active');
    $('#Company_list').removeClass('active show');
    $('#Company').addClass('active show');
    $("#FormAdd").hide();
    $("#FormUpdate").show();
    $("#FormReset").show();
    $("#Company-tab").html("Edit Company");
}

//FUNCTION FOR TAB HIDE
function TabHide() {
    $('#Company-tab').removeClass('active');
    $('#Company_list-tab').addClass('active ');
    $('#Company_list').addClass('active show');
    $('#Company').removeClass('active show');
    $("#FormAdd").show();
    $("#FormUpdate").hide();
    $("#FormReset").hide();
    $("#Company-tab").html("Add Company");
}

//COMPANY LIST TAB CLICKED
$("#Company_list-tab").click(function () {
    ResetForm();
    window.location.reload();
    RemoveAllError('Company');
});
$("#VerifyEmail").click(function () {
    if ($("#SmtpEmailId").val().length == 0) {
        Toast("Please Enter Email Id To Verify !", 'Message', 'error');
        $("#SmtpEmailId").focus();
        return;
    }
    if ($("#SmtpEmailId").val().length != 0) {
        if ($("#SmtpEmailPassword").val().length == 0) {
            Toast("Please Enter Password !", 'Message', 'error');
            $("#SmtpEmailPassword").focus();
            return;
        }
        if ($("#SmtpPort").val().length == 0) {
            Toast("Please Enter SMTP Port !", 'Message', 'error');
            $("#SmtpPort").focus();
            return;
        }
        if ($("#SmtpEmailserver").val().length == 0) {
            $("#SmtpEmailserver").focus();
            Toast("Please Enter Email Server !", 'Message', 'error');
            return;
        }
    }
    VerifyEmail();
});
function VerifyEmail() {
    try {
        const dataString = {};

        dataString.Email = $("#SmtpEmailId").val();
        dataString.To = $("#SmtpEmailId").val();
        dataString.Password = $("#SmtpEmailPassword").val();
        dataString.smtpPort = $("#SmtpPort").val();
        dataString.EmailServer = $("#SmtpEmailserver").val();
        dataString.VerifySSl = $("#VerifySSL").is(":checked");
        dataString.EnableSSL = $("#EnableSSL").is(':checked');

        //ShowLoader();
        AjaxSubmission(JSON.stringify(dataString), "/Company/VerifyEmail", $('input[name=__RequestVerificationToken]').val()).done(function (result) {
            let obj = result;
            if (obj.status == true) {
                if (obj.responsecode == '100')
                    Toast(RetrieveMessage(obj.responsecode), "Message", "success");
                else
                    Toast(RetrieveMessage(obj.responsecode), "Message", "error");
            }
            else
                window.location.href = '/ClientLogin/ClientLogin';
            //HideLoader();
        }).fail(function (result) {
            console.log(result.Message);
            //HideLoader();
        });
    }
    catch (e) {
        console.log(e.message);
        //HideLoader();
    }
}
$(".Company_list").click(function () {
    $("#IdSearch").focus();
})

$("#FormReset").click(function () {
    ResetForm();
})

document.addEventListener("keydown", function (zEvent) {
    if (zEvent.ctrlKey && zEvent.altKey && (zEvent.key == "j" || zEvent.key == "J")) {
        $('#Company_list-tab').removeClass('active ');
        $('#Company_list').removeClass('active show');
        $('#Company-tab').addClass('active');
        $('#Company').addClass('active show');
        $("#FormAdd").show();
        $("#FormUpdate").hide();
        $("#FormReset").hide();
        $("#Company-tab").html("Add Company");
        $('#CompanyName').focus();
        ResetForm();
    }
});