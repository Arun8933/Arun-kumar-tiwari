﻿var DateFrom = "";
var DateTo = "";
var Count;
// DOCUMENT ON READY FUNCTION
$(document).ready(function () {
    FillPageSizeList('ddlPageSize');
    GetFinancialYearDate();
    $(".datepickerAll").datepicker({
        changeMonth: true,
        changeYear: true,
        dateFormat: 'dd/mm/yy'
    });
    FillBranchList('SelectBranch', false);
    $("#SelectBranch").select2({
        width: '100%'
    });
    $("#BookTypeSearch").select2({
        width: '100%'
    });
    $("#BalanceTypeSearch").select2({
        width: '100%'
    });
    $("#TransactionTypeSearch").select2({
        width: '100%'
    });
    //DATEPICKER FOR SEARCHJOBDATEFROM AND SEARCHJOBDATETO
    $('#SearchDateFrom,#SearchDateTo').datepicker({
        toolbarPlacement: "bottom",
        showButtonPanel: true,
        changeMonth: true,
        changeYear: true,
        dateFormat: 'dd/mm/yy',
        onClose: function () {
            if ($('#SearchDateFrom').val().length == 10 || $('#SearchDateTo').val().length == 10)
                CompareSearchDate($('#SearchDateFrom').val(), $('#SearchDateTo').val(), 'SearchDate');
        }
    });

})

// PAGINATION BUTTON CLICKED
$(document).on("click", ".pagination .page", function () {
    FormList(($(this).attr('page')));
});
//PAGE SIZE CLICKED
$("#ddlPageSize").change(function () {
    FormList(1);
});

//FUNCTION FOR GET FINANCIAL YEAR DATE
function GetFinancialYearDate() {
    try {
        AjaxSubmission(null, '/_Layout/GetFinancialYearDate', $('[name="__RequestVerificationToken"]').val()).done(function (result) {
            let obj = result;
            console.log(obj)
            if (obj.status == true) {
                if (obj.responsecode == '100') {
                    $("#SearchDateFrom").val(obj.data.Table[0].finyr_start_date);
                    $("#SearchDateTo").val(obj.data.Table[0].finyr_end_date);
                }
            }
            else
                window.location.href = '/ClientLogin/ClientLogin';
            HideLoader();
        }).fail(function (result) {
            HideLoader();
            console.log(result.message);
        });
        HideLoader();
    }
    catch (e) {
        HideLoader();
        console.log(e.message);
    }
}

//SEARCH ARROW UP/DOWN
$("#Arrow").click(function () {
    if (srbtn == 'up') {
        $("#icn").html("<i class='fa-solid fa-angle-down'></i>");
        srbtn = 'down';
    } else {
        $("#icn").html("<i class='fa-solid fa-angle-up'></i>");
        srbtn = 'up';
    }
});

// AUTOCOMPLETE FUNCTION FOR FILL ACCHEAD
$("#AccHeadSearch").autocomplete({
    source: function (request, response) {
        $.ajax({
            type: 'POST',
            url: "/Master/DayBook/SearchAccHeadNameList",
            dataType: "json",
            async: false,
            data: { AccDescription: request.term },
            success: function (result) {
                response($.map(result.data.Table, function (LedgerName) {
                    return {
                        label: LedgerName.AccHead,
                        value: LedgerName.AccHead,
                        id: LedgerName.ledgeruid,
                        LedgerGroup: LedgerName.LedgerGroup,
                    }
                }));
            },
            error: function (response) {
                console.log(response.responseText);
            }
        });
    },
    autoFocus: true,
    minLength: 1,
    selectFirst: true,
    selectOnly: true,
    select: function (e, i) {
        $("#HiddenLedgerId").val(i.item.id);
    },
});

//FUNCTION FOR FORM SORTING
function FormSorting(obj) {
    if (Firstcolumn != "") {
        document.getElementById(Firstcolumn).innerHTML = document.getElementById(Firstcolumn).getAttribute("data-column") + " <i class='fa-solid fa-sort'></i>";
    }
    let cn = obj.id;
    Firstcolumn = cn;
    var colname = $(obj).data("column");
    $("#sort-column").val(cn.replaceAll("_", ""));
    var sorttype = $("#sort-type").val();
    if (sorttype == "ASC") {
        $("#sort-type").val("DESC");
        $(obj).html(colname + " <i style='margin-left:10px;' class='fa-solid fa-sort-up'></i>");
    } else if (sorttype == "DESC") {
        $("#sort-type").val("ASC");
        $(obj).html(colname + " <i style='margin-left:10px;' class='fa-solid fa-sort-down'></i>");
    }
    FormList(1);
}

$("#FormSearch").click(function () {
    var flag = 0;
    var FromDate = $("#SearchDateFrom").val();
    var ToDate = $("#SearchDateTo").val();
    //if ($("#AccHeadSearch").val() == "") {
    //    Toast("Please Select Acchead*", "Message", "error");
    //    flag = 1;
    //    return false;
    //}

    if (FromDate == "") {
        Toast("Please Enter Date From", "Message", "error");
        flag = 1;
        return false;
    }
    if (ToDate == "") {
        Toast("Please Enter Date To", "Message", "error");
        flag = 1;
        return false;
    }
    if (FromDate > ToDate) {
        Toast("To Date Must Be Greater Than From Date!", "Message", "error");
        flag = 1;
        return false;
    }
    if (ToDate < FromDate) {
        Toast("To Date Must Be Greater Than From Date!", "Message", "error");
        flag = 1;
        return false;
    }
    if (flag == 0) {
        $(".ReportDNone").show();
        FormList();
    }
});

//FUNCTION FOR FILL TRIAL BALANCE LIST
function FormList(pageindex) {
    try {
        const dataString = {};
        dataString.PageSize = $("#ddlPageSize").val();
        dataString.PageIndex = pageindex;
        dataString.OrderBy = $("#sort-column").val().trim() + " " + $("#sort-type").val().trim();
        dataString.FromDate = $("#SearchDateFrom").val();
        dataString.ToDate = $("#SearchDateTo").val();
        dataString.BranchUid = $("#SelectBranch").val();
        dataString.LedgerUid = $("#HiddenLedgerId").val();
        dataString.TransactionType = $("#TransactionTypeSearch").val();
        dataString.BalanceType = $("#BalanceTypeSearch").val();
        dataString.BookType = $("#BookTypeSearch").val();
        dataString.HiddenSearchJobNo = $("#HiddenSearchJobNo").val();
        ShowLoader();
        AjaxSubmission(JSON.stringify(dataString), "/Master/DayBook/FormList", $('input[name=__RequestVerificationToken]').val()).done(function (result) {
            let obj = result;
            if (obj.status == true) {
                if (obj.responsecode == '100') {
                    var ser = ((parseInt(obj.data.Table1[0].PageIndex) - 1) * parseInt(obj.data.Table1[0].PageSize)) + 1;
                    BindFormTable(obj.data.Table, ser);
                    $(".pagination").BindPaging({
                        ActiveCssClass: "current",
                        PagerCssClass: "pager",
                        PageIndex: parseInt(obj.data.Table1[0].PageIndex),
                        PageSize: parseInt(obj.data.Table1[0].PageSize),
                        RecordCount: parseInt(obj.data.Table1[0].count)
                    });
                }
                else
                    Toast(RetrieveMessage(obj.responsecode), "Message", "error");
            }
            else
                window.location.href = '/ClientLogin/ClientLogin';

            HideLoader();
        }).fail(function (result) {
            console.log(result.Message);
            HideLoader();
        });
    }
    catch (e) {
        console.log(e.message);
        HideLoader();
    }
}


//FUNCTION FOR BIND LETTER LIST TABLE
function BindFormTable(Result, SerialNo) {
    console.log(Result);
    $("#tbl_DayBook tbody tr").remove();
    if (Result.length == 0) {
        tr = $('<tr/>');
        tr.append("<td class='text-center' colspan='11'>NO RESULTS FOUND</td>");
        $("#tbl_DayBook tbody").append(tr);
    }
    else {
        var TotalDebit = 0.00;
        var TotalCredit = 0.00;
        for (i = 0; i < Result.length; i++) {
            tr = $('<tr/>');
            tr.append("<td class='text-center'>" + SerialNo + "</td>");
            tr.append("<td class='text-center'>" + Result[i].Date + "</td>");
            tr.append("<td class='text-center'>" + Result[i].RefNo + "</td>");
            tr.append("<td class='text-left'>" + HandleNullTextValue(Result[i].AccHead) + "</td>");
            tr.append("<td class='text-left'>" + HandleNullTextValue(Result[i].Particular) + "</td>");
            tr.append("<td class='text-center'>" + HandleNullTextValue(Result[i].JobNo) + "</td>");
            tr.append("<td class='text-end'>" + HandleNullTextValue(Result[i].ChequeNo) + "</td>");
            tr.append("<td class='text-end'>" + HandleNullTextValue(Result[i].DebitAmount) + "</td>");
            tr.append("<td class='text-end'>" + HandleNullTextValue(Result[i].CrebitAmount) + "</td>");
            SerialNo++;
            $("#tbl_DayBook tbody").append(tr);
            TotalDebit += parseFloat(HandleNullNumericValue(HandleNullTextValue(Result[i].DebitAmount).replace(',', '')));
            TotalCredit += parseFloat(HandleNullNumericValue(HandleNullTextValue(Result[i].CrebitAmount).replace(',', '')));
        }
        if (Result.length > 0) {
            tr = $('<tr/>');
            tr.append("<td class='text-end' colspan='7'><b>Total : </b></td>");
            tr.append("<td class='text-end'><b>" + TotalDebit.toFixed(2) + "</b></td>");
            tr.append("<td class='text-end'><b>" + TotalCredit.toFixed(2) + "</b></td>");
            $("#tbl_DayBook tbody").append(tr);
        }

    }
}


//ON CLICK FUNCTION FOR PDF
$("#DayBookPDF").click(function () {
    try {
        const dataString = {};
        dataString.PageSize = $("#ddlPageSize").val();
        dataString.PageIndex = 1;
        dataString.OrderBy = $("#sort-column").val().trim() + " " + $("#sort-type").val().trim();
        dataString.FromDate = $("#SearchDateFrom").val();
        dataString.ToDate = $("#SearchDateTo").val();
        dataString.BranchUid = $("#SelectBranch").val();
        dataString.LedgerUid = $("#HiddenLedgerId").val();
        dataString.TransactionType = $("#TransactionTypeSearch").val();
        dataString.BalanceType = $("#BalanceTypeSearch").val();
        dataString.BookType = $("#BookTypeSearch").val();
        dataString.HiddenSearchJobNo = $("#HiddenSearchJobNo").val();
        ShowLoader();
        AjaxSubmission(JSON.stringify(dataString), "/Master/DayBook/GetDayBookReport", $('input[name=__RequestVerificationToken]').val()).done(function (result) {
            let obj = result;
            console.log(obj);
            if (obj.status == true) {
                if (obj.responsecode == '100') {
                    window.open($("#MyReport").attr('href'), '_blank');
                }
                else
                    Toast(RetrieveMessage(obj.responsecode), "Message", "error");
            }
            else
                window.location.href = '/ClientLogin/ClientLogin';
            HideLoader();
        }).fail(function (result) {
            console.log(result.Message);
            HideLoader();
        });
    }
    catch (e) {
        console.log(e.message);
        HideLoader();
    }
});


//FUNCTION FOR EXPORT DATA IN EXCEL
function FormExcel() {
    debugger;
    ShowLoader();
    let date = new Date();
    let NewDate = ("00" + date.getDate()).slice(-2) + "_" + ("00" + (date.getMonth() + 1)).slice(-2) + "_" + date.getFullYear() + "_" + ("00" + date.getHours()).slice(-2) + "_" + ("00" + date.getMinutes()).slice(-2) + "_" + ("00" + date.getSeconds()).slice(-2);
    let fileName = "DayBook_" + NewDate + ".xlsx";

    $('#FormSearch').trigger('click');
    AjaxSubmission(null, '/Master/DayBook/FormExcel', $('input[name=__RequestVerificationToken]').val()).done(function (result) {
        let obj = result;
        if (obj.status == true) {
            if (obj.responsecode == '100') {

                let bytes = Base64ToBytes(obj.data.FileData[0].Base64Data);
                let blob = new Blob([bytes], { type: "application/octetstream" });
                let isIE = false || !!document.documentMode;
                if (isIE) {
                    window.navigator.msSaveBlob(blob, fileName);
                } else {
                    let url = window.URL || window.webkitURL;
                    link = url.createObjectURL(blob);
                    let a = $("<a />");
                    a.attr("download", fileName);
                    a.attr("href", link);
                    $("body").append(a);
                    a[0].click();
                    $("body").remove(a);
                }
            }
            else if (obj.responsecode == '302')
                Toast('No Records found.', 'Message', 'success');
            else
                Toast(RetrieveMessage(obj.responsecode), 'Message', 'error');

        } else
            window.location.href = '/ClientLogin/ClientLogin';
        HideLoader();

    }).fail(function (result) {
        console.log(result.Message);
        HideLoader();
    });
}

