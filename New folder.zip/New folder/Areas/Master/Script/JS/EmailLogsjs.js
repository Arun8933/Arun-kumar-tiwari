﻿//DOCUMENT READY
$(document).ready(function () {
    //$("#SearchSubJobNo").focus();
    FillPageSizeList('ddlPageSize', FormList);
    $(".datepickerAll").datepicker({
        changeMonth: true,
        changeYear: true,
        dateFormat: 'dd/mm/yy',

    });
    FillUserList('UserName');
    FillRefType()
})
//LETTER ASSIGN LIST FUNCTION
function FormList(pageindex) {
    try {
        const dataString = {};
        dataString.PageSize = $("#ddlPageSize").val();
        dataString.PageIndex = pageindex;
        dataString.RefId = $("#RefId").val();
        dataString.FromDate = $("#FromDate").val();
        dataString.ToDate = $("#ToDate").val();
        dataString.SendTo = $("#SendTo").val();
        dataString.SendToName = $("#SendToName").val();
        dataString.Type = $("#Type").val();
        dataString.Reference = $("#References").val();
        dataString.Subject = $("#SubjectData").val();
        dataString.UserName = $("#UserName").val();


        dataString.OrderBy = $("#sort-column").val().trim() + " " + $("#sort-type").val().trim();
        //Showloader();
        AjaxSubmission(JSON.stringify(dataString), "/Master/EmailLogs/FormList", $('input[name=__RequestVerificationToken]').val()).done(function (result) {
            let obj = result;
            if (obj.status == true) {
                if (obj.responsecode == '100') {
                    var ser = ((parseInt(obj.data.Table1[0].PageIndex) - 1) * parseInt(obj.data.Table1[0].PageSize)) + 1;
                    BindFormTable(obj.data.Table, ser);
                    if (obj.data.Table1 != undefined && obj.data.Table1.length > 0) {
                        $(".pagination").BindPaging({
                            ActiveCssClass: "current",
                            PagerCssClass: "pager",
                            PageIndex: parseInt(obj.data.Table1[0].PageIndex),
                            PageSize: parseInt(obj.data.Table1[0].PageSize),
                            RecordCount: parseInt(obj.data.Table1[0].count)
                        });
                    }
                }
                else {
                    Toast(RetrieveMessage(obj.responsecode), "Message", "error");
                }
            }
            else {
                window.location.href = '/ClientLogin/ClientLogin';
            }
            //Hideloader();
        }).fail(function (result) {
            console.log(result.Message);
            //Hideloader();
        });
    }
    catch (e) {
        console.log(e.message);
        //Hideloader();
    }
}

//FUNCTION FOR BIND LETTER ASSIGN TABLE
function BindFormTable(Result, SerialNo) {
    $("#TblEmailLogs tbody tr").remove();
    if (Result.length == 0) {
        tr = $('<tr/>');
        tr.append("<td class='text-center' colspan='8'>NO RESULTS FOUND</td>");
        $("#TblEmailLogs tbody").append(tr);
    }
    else {
        for (i = 0; i < Result.length; i++) {
            if (Result[i].is_active == "Inactive") {
                tr = $(' <tr style="background-color:#fdd2d2;"/>');
            }
            else {
                tr = $('<tr/>');

                tr.append("<td class='text-left'>" + SerialNo + "</td>");
                tr.append("<td class='text-center'>" + Result[i].LogType + "</td>");
                tr.append("<td class='text-center'>" + Result[i].RefName + "</td>");
                tr.append("<td class='text-left'>" + Result[i].RefId + "</td>");
                tr.append("<td class='text-center'>" + Result[i].SendTo + "</td>");
                tr.append("<td class='text-center'>" + Result[i].SendToName + "</td>");
                tr.append("<td class='text-center'>" + Result[i].Subject + "</td>");
                tr.append("<td class='text-center'>" + Result[i].SendDate + "</td>");
                tr.append("<td class='text-center'>" + Result[i].SendBy + "</td>");


            }
            SerialNo++;
            $("#TblEmailLogs tbody").append(tr);
        }
    }
}
//FORM SORTING LETTER MASTER
function FormSorting(obj) {
    if (Firstcolumn != "") {
        document.getElementById(Firstcolumn).innerHTML = document.getElementById(Firstcolumn).getAttribute("data-column") + " <i class='fa-solid fa-sort'></i>";
    }
    let cn = obj.id;
    Firstcolumn = cn;
    var colname = $(obj).data("column");
    $("#sort-column").val(cn.replaceAll("_", ""));
    var sorttype = $("#sort-type").val();
    if (sorttype == "ASC") {
        $("#sort-type").val("DESC");
        $(obj).html(colname + " <i style='margin-left:10px;' class='fa-solid fa-sort-up'></i>");
    } else if (sorttype == "DESC") {
        $("#sort-type").val("ASC");
        $(obj).html(colname + " <i style='margin-left:10px;' class='fa-solid fa-sort-down'></i>");
    }
    FormList(1);
}

//FUNCTION FOR PEGINATION PREVIOUS NEXT CLICK
$(document).on("click", ".pagination .page", function () {
    FormList(($(this).attr('page')));
});

//PAGE SIZE DROPDOWN ON CHANGE
$("#ddlPageSize").change(function () {
    FormList(1);
});

//SEARCH BUTTON CLICK
$("#FormSearch").click(function () {
    FormList(1);
});
//FUNCTION FOR BIND GROUP NAME
function FillRefType() {
    try {
        //ShowLoader();
        AjaxSubmission(null, "/Master/EmailLogs/FillReferenceType", $('input[name=__RequestVerificationToken]').val()).done(function (result) {
            let obj = result;
            if (obj.status == true) {
                if (obj.responsecode == '100') {
                    BindDropdown(obj.data.Table, 'References', 'RefName', 'RefName', 'All');
                }
                else if (obj.responsecode == '604') {
                    BindDropdown(null, 'References', 'RefName', 'RefName', 'All');
                }
                else {
                    Toast(RetrieveMessage(obj.responsecode), "Message", "error");
                }
                //setTimeout(FormList(1), 1000);
            }
            else {
                window.location.href = '/ClientLogin/ClientLogin';
            }
            //HideLoader();
        }).fail(function (result) {
            console.log(result.Message);
            HideLoader();
        });
    }
    catch (e) {
        console.log(e.message);
        //HideLoader();
    }
}