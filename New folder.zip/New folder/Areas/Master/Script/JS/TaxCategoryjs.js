﻿//DOCUMENT READY 
$(document).ready(function () {
    ShowLoader();
    FillPageSizeList('ddlPageSize', FormList);
    $("#SelectFields").select2({ width: '100%' });
    HideLoader();
});

//LETTER MASTER LIST FUNCTION
function FormList(pageindex) {
    try {
        const dataString = {};
        dataString.PageSize = $("#ddlPageSize").val();
        dataString.PageIndex = pageindex;
        dataString.CategoryUid = $("#CategoryIdSearch").val().trim();
        dataString.CategoryName = $("#CategoryNameSearch").val().trim();
        dataString.OrderBy = $("#sort-column").val().trim() + " " + $("#sort-type").val().trim();
        //ShowLoader();
        AjaxSubmission(JSON.stringify(dataString), "/Master/TaxCategory/FormList", $('input[name=__RequestVerificationToken]').val()).done(function (result) {
            let obj = result;
            if (obj.status == true) {
                if (obj.responsecode == '100') {
                    var ser = ((parseInt(obj.data.Table1[0].PageIndex) - 1) * parseInt(obj.data.Table1[0].PageSize)) + 1;
                    BindFormTable(obj.data.Table, ser);
                    if (obj.data.Table1 != undefined && obj.data.Table1.length > 0) {
                        $(".pagination").BindPaging({
                            ActiveCssClass: "current",
                            PagerCssClass: "pager",
                            PageIndex: parseInt(obj.data.Table1[0].PageIndex),
                            PageSize: parseInt(obj.data.Table1[0].PageSize),
                            RecordCount: parseInt(obj.data.Table1[0].count)
                        });
                    }
                }
                else {
                    Toast(RetrieveMessage(obj.responsecode), "Message", "error");
                }
            }
            else {
                window.location.href = '/ClientLogin/ClientLogin';
            }
            //HideLoader();
        }).fail(function (result) {
            console.log(result.Message);
            //HideLoader();
        });
    }
    catch (e) {
        console.log(e.message);
        //HideLoader();
    }
}

//FUNCTION FOR BIND LETTER LIST TABLE
function BindFormTable(Result, SerialNo) {
    $("#Tbl_TaxCategory tbody tr").remove();
    if (Result.length == 0) {
        tr = $('<tr/>');
        tr.append("<td class='text-center' colspan='8'>NO RESULTS FOUND</td>");
        $("#Tbl_TaxCategory tbody").append(tr);
    }
    else {
        for (i = 0; i < Result.length; i++) {

            if (Result[i].Status == "Inactive") {
                tr = $(' <tr style="background-color:#fdd2d2;"/>');
            }
            else
                tr = $('<tr/>');
            tr.append("<td class='text-center'><button type='button' onclick='FormEdit(\"" + Result[i].CategoryUid + "\");' class='common-btn common-btn-sm'><i class='fa-solid fa-pen-to-square'></i></button ><button type='button' onclick='FormDelete(\"" + Result[i].CategoryUid + "\");' class='common-btn common-btn-sm ms-1'> <i class='fa-regular fa-trash-can'></i></button ></td > ");
            tr.append("<td class='text-left'>" + SerialNo + "</td>");
            tr.append("<td class='text-left'>" + Result[i].CategoryUid + "</td>");
            tr.append("<td class='text-center'><a href='javascript:void(0)' class='text-decoration-none ' style='color: black !important;' onclick='FormEdit(\"" + Result[i].CategoryUid + "\");'>" + Result[i].CategoryName + "</a></td>");



            SerialNo++;
            $("#Tbl_TaxCategory tbody").append(tr);
        }
    }
}

//FORM SORTING LETTER MASTER
function FormSorting(obj) {
    if (Firstcolumn != "") {
        document.getElementById(Firstcolumn).innerHTML = document.getElementById(Firstcolumn).getAttribute("data-column") + " <i class='fa-solid fa-sort'></i>";
    }
    let cn = obj.id;
    Firstcolumn = cn;
    var colname = $(obj).data("column");
    $("#sort-column").val(cn.replaceAll("_", ""));
    var sorttype = $("#sort-type").val();
    if (sorttype == "ASC") {
        $("#sort-type").val("DESC");
        $(obj).html(colname + " <i style='margin-left:10px;' class='fa-solid fa-sort-up'></i>");
    } else if (sorttype == "DESC") {
        $("#sort-type").val("ASC");
        $(obj).html(colname + " <i style='margin-left:10px;' class='fa-solid fa-sort-down'></i>");
    }
    FormList(1);
}

//FUNCTION FOR PEGINATION PREVIOUS NEXT CLICK
$(document).on("click", ".pagination .page", function () {
    FormList(($(this).attr('page')));
});

//PAGE SIZE DROPDOWN ON CHANGE
$("#ddlPageSize").change(function () {
    FormList(1);
});

//SEARCH BUTTON CLICK
$("#FormSearch").click(function () {
    FormList(1);
});

$("#FormAdd").click(function () {
    var flag = 0;
    if ($("#CategoryName").val().length == 0) {
        Toast('Please Fill Category Name !', 'Message', 'error');
        return;
    }
    $("#TblTaxCategory tbody tr").each(function (index, ele) {
        if ($(ele).find('.HiddenTax').val().length == 0) {
            Toast('Please Fill Tax !', 'Message', 'error');
            flag = 1;
            return false;
        }
        //if ($(ele).find('.TaxValue').val() == '0.00') {
        //    Toast('Please Fill Tax Value !', 'Message', 'error');
        //    flag = 1;
        //    return false;
        //}
    });
    if (flag == 0) {
        FormAdd();
    }
});

function FormAdd() {
    try {
        const datastring = {};
        var TaxCategory = new Array();

        datastring.CategoryName = $("#CategoryName").val();
        datastring.Status = $("#Status").val();

        $("#TblTaxCategory tbody tr").each(function () {
            var g = {};
            g.LedgerUid = $(this).find(".HiddenTax").val();
            g.TaxValue = $(this).find(".TaxValue").val();
            g.TaxType = $(this).find(".TaxType").val();

            TaxCategory.push(g);
        });
        datastring.TaxCategoryList = TaxCategory;
        ShowLoader();

        AjaxSubmission(JSON.stringify(datastring), "/Master/TaxCategory/FormAdd", $('input[name=__RequestVerificationToken]').val()).done(function (result) {
            let obj = result;
            if (obj.status == true) {
                if (obj.responsecode == '101') {
                    Toast(RetrieveMessage(obj.responsecode), "Message", "success");
                    setTimeout(FormList(1), 500);
                    $("#FormAdd").hide();
                    $("#FormUpdate").show();
                    $("#FormReset").show();
                    $("#TaxCategory-tab").html("Edit Tax Category");
                }
                else {
                    Toast(RetrieveMessage(obj.responsecode), "Message", "error");
                }
            }
            else {
                window.location.href = '/ClientLogin/ClientLogin';
            }
            HideLoader();
        }).fail(function (result) {
            console.log(result.Message);
            HideLoader();
        });
    }
    catch (e) {
        console.log(e.message);
        HideLoader();
    }
}
//EDIT PURCHASE ENTRY FUNCTION 
function FormEdit(e) {
    try {
        const datastring = {};
        datastring.CategoryUid = e;
        ShowLoader();
        AjaxSubmission(JSON.stringify(datastring), "/Master/TaxCategory/FormEdit", $('[name="__RequestVerificationToken"]').val()).done(function (data) {
            let obj = data;
            if (obj.status == true) {
                if (obj.responsecode == '100') {
                    TabShow();
                    $("#CategoryId").css("display", "block");
                    $("#CategoryId").val(obj.data.Table1[0].CategoryUid)
                    $("#CategoryName").val(obj.data.Table1[0].CategoryName);
                    if (obj.data.Table1[0].Status == true)
                        $("#Status").val("1");
                    else
                        $("#Status").val("0");

                    var TaxList = obj.data.Table;
                    var firstChild = $("#TblTaxCategory").find("tbody tr:first-child");

                    $.each(TaxList, function (index, ele) {
                        if (index == 0) {
                            firstChild.find('.HiddenTax').val(ele.LedgerUid);
                            firstChild.find('.Tax').val(ele.AccHead);
                            firstChild.find('.TaxValue').val(parseFloat(ele.TaxValue).toFixed(2));
                            firstChild.find('.TaxType').val(ele.TaxType);
                        }
                        else {
                            var cloneChild = firstChild.clone();

                            cloneChild.find('.HiddenTax').val('');
                            cloneChild.find('.Tax').val('');
                            cloneChild.find('.TaxValue').val('');
                            cloneChild.find('.TaxType').val('');

                            cloneChild.find('.HiddenTax').val(ele.LedgerUid);
                            cloneChild.find('.Tax').val(ele.AccHead);
                            cloneChild.find('.TaxValue').val(parseFloat(ele.TaxValue).toFixed(2));
                            cloneChild.find('.TaxType').val(ele.TaxType);

                            $("#TblTaxCategory tbody").append(cloneChild);
                        }
                    });
                }
                else {
                    Toast(RetrieveMessage(obj.responsecode), "Message", "error");
                }

            }
            else {
                window.location.href = '/ClientLogin/ClientLogin';
            }
            HideLoader();
        }).fail(function (data) {
            console.log(data.Message);
            HideLoader();
        });
    }
    catch (e) {
        console.log(e.message);
        HideLoader();
    }
}
$("#FormUpdate").click(function () {
    var flag = 0;
    if ($("#CategoryName").val().length == 0) {
        Toast('Please Fill Category Name !', 'Message', 'error');
        return;
    }
    $("#TblTaxCategory tbody tr").each(function (index, ele) {
        if ($(ele).find('.HiddenTax').val().length == 0) {
            Toast('Please Fill Tax !', 'Message', 'error');
            flag = 1;
            return false;
        }
        //if ($(ele).find('.TaxValue').val() == '0.00') {
        //    Toast('Please Fill Tax Value !', 'Message', 'error');
        //    flag = 1;
        //    return false;
        //}
    });
    if (flag == 0) {
        FormUpdate();
    }
})
function FormUpdate() {
    try {
        const datastring = {};
        var TaxCategory = new Array();

        datastring.CategoryName = $("#CategoryName").val();
        datastring.Status = $("#Status").val();

        $("#TblTaxCategory tbody tr").each(function () {
            var g = {};
            g.LedgerUid = $(this).find(".HiddenTax").val();
            g.TaxValue = $(this).find(".TaxValue").val();
            g.TaxType = $(this).find(".TaxType").val();

            TaxCategory.push(g);
        });
        datastring.TaxCategoryList = TaxCategory;
        ShowLoader();

        AjaxSubmission(JSON.stringify(datastring), "/Master/TaxCategory/FormUpdate", $('input[name=__RequestVerificationToken]').val()).done(function (result) {
            let obj = result;
            if (obj.status == true) {
                if (obj.responsecode == '107') {
                    Toast(RetrieveMessage(obj.responsecode), "Message", "success");
                    setTimeout(FormList(1), 500);
                }
                else {
                    Toast(RetrieveMessage(obj.responsecode), "Message", "error");
                }
            }
            else {
                window.location.href = '/ClientLogin/ClientLogin';
            }
            HideLoader();
        }).fail(function (result) {
            console.log(result.Message);
            HideLoader();
        });
    }
    catch (e) {
        console.log(e.message);
        HideLoader();
    }
}
//FUNCTION FOR DELETE INVOICE TYPE
function FormDelete(e) {
    try {
        $.confirm({
            title: '',
            content: 'Are You Sure Want To Delete ?',
            type: 'red',
            boxWidth: '300px',
            useBootstrap: false,
            columnClass: 'small',
            containerFluid: true,
            typeAnimated: true,
            buttons: {
                tryAgain: {
                    text: 'Confirm',
                    btnClass: 'btn-red',
                    action: function () {

                        const datastring = {};
                        datastring.CategoryUid = parseInt(e);
                        ShowLoader();
                        AjaxSubmission(JSON.stringify(datastring), "/Master/TaxCategory/FormDelete", $('[name="__RequestVerificationToken"]').val()).done(function (data) {
                            let obj = data;
                            if (obj.status == true) {
                                if (obj.responsecode == '102') {
                                    Toast(RetrieveMessage(obj.responsecode), "Message", "success");
                                    FormList(1);
                                }
                                else {
                                    Toast(RetrieveMessage(obj.responsecode), "Message", "error");
                                }
                            }
                            else {
                                window.location.href = 'ClientLogin/ClientLogin';
                            }
                            HideLoader();
                        }).fail(function (data) {
                            console.log(data.Message);
                            HideLoader();
                        });
                    }
                },
                close: function () {

                }
            }
        });
    }
    catch (e) {
        console.log(e.message);
        HideLoader();
    }
}

//ADD MORE CLICK 
$("#AddTaxRow").click(function () {
    $("#RemoveTaxRow").removeAttr('disabled');

    var Tbody = $("#TblTaxCategory").find("tbody");
    var FirstTr = $(Tbody).find('tr:first');

    var NewRow = $(FirstTr).clone();
    NewRow.find('.HiddenTax').val('');
    NewRow.find('.Tax').val('');
    NewRow.find('.TaxValue').val('0.00');
    NewRow.find('.TaxType').val('All');

    $("#TblTaxCategory tbody").append(NewRow);

    var LastTr = $(Tbody).find("tr:last");
    LastTr.find('.Tax').focus();
});
//FUNCTION FOR DELETE ROW 
function DeleteTaxRow(obj) {
    var rowCount = $("#TblTaxCategory tbody tr").length;

    if (rowCount > 1) {
        $(obj).parent().parent().remove();
    }
    else {
        $("#RemoveTaxRow").attr("disabled", "disabled");
    }
}
//AUTOCOMPLETE FOR WILL DUTIES AND TAXES GROUP LEDGERS
function AutoCompleteAjaxWithClassWithColumn(className, PageUrl, HiddenId) {
    $("." + className).autocomplete({
        source: function (request, response) {
            $.ajax({
                type: 'POST',
                url: PageUrl,
                dataType: "json",
                async: false,
                data: { SearchField: request.term },
                success: function (result) {
                    if (result.status == true) {
                        if (result.responsecode == '100') {
                            response($.map(result.data.Table, function (item, id) {
                                return {
                                    label: item.name,
                                    value: item.name,
                                    id: item.id,
                                    TaxLedgerPer: item.TaxLedgerPer,
                                };
                            }));
                        }
                    }
                    else {
                        window.location.href = '/ClientLogin/ClientLogin';
                    }
                }
            });
        },
        minLength: 1,
        selectFirst: true,
        selectOnly: true,
        select: function (e, i) {

            var parentTr = $(this).parents('tr');
            parentTr.find("." + HiddenId).val(i.item.id);
            if (i.item.TaxLedgerPer != null) {
                parentTr.find(".TaxValue").val(parseFloat(i.item.TaxLedgerPer).toFixed(2));
            }
            else {
                parentTr.find(".TaxValue").val('0.00');
            }
        },
        change: function (e, i) {
            var parentTr = $(this).parents('tr');

            if (i.item == null || i.item == undefined) {

                parentTr.find("." + HiddenId).val('');
                parentTr.find(".TaxValue").val('0.00');
                //parentTr.find(".JobExpense").val('');

            }
        }
    });
}

//FUNCTION FOR TAB HIDE
function TabShow() {
    $('#TaxCategory_list-tab').removeClass('active');
    $('#TaxCategory-tab').addClass('active');
    $('#TaxCategory_list').removeClass('active show');
    $('#TaxCategory').addClass('active show');
    $("#FormAdd").hide();
    $("#FormUpdate").show();
    $("#FormReset").show();
    $("#TaxCategory-tab").html("Edit Tax Category");
}

//FUNCTION FOR TAB HIDE
function TabHide() {
    $('#TaxCategory-tab').removeClass('active');
    $('#TaxCategory_list-tab').addClass('active ');
    $('#TaxCategory_list').addClass('active show');
    $('#TaxCategory').removeClass('active show');
    $("#FormAdd").show();
    $("#FormUpdate").hide();
    $("#FormReset").hide();
    $("#TaxCategory-tab").html("Add Tax Category");
}

//LETTER MASTER LIST TAB ON CLICK 
$('#TaxCategory_list-tab').click(function () {
    ResetForm();

    //RemoveAllError('Letter');
});

//FUNCTION FOR EXPORT DATA IN EXCEL
function FormExcel() {
    ShowLoader();
    let date = new Date();
    let NewDate = ("00" + date.getDate()).slice(-2) + "_" + ("00" + (date.getMonth() + 1)).slice(-2) + "_" + date.getFullYear() + "_" + ("00" + date.getHours()).slice(-2) + "_" + ("00" + date.getMinutes()).slice(-2) + "_" + ("00" + date.getSeconds()).slice(-2);
    let fileName = "TaxCategory_" + NewDate + ".xlsx";

    $('#FormSearch').trigger('click');
    AjaxSubmission(null, '/Master/TaxCategory/FormExcel', $('input[name=__RequestVerificationToken]').val()).done(function (result) {
        let obj = result;
        if (obj.status == true) {
            if (obj.responsecode == '100') {

                let bytes = Base64ToBytes(obj.data.FileData[0].Base64Data);
                let blob = new Blob([bytes], { type: "application/octetstream" });
                let isIE = false || !!document.documentMode;
                if (isIE) {
                    window.navigator.msSaveBlob(blob, fileName);
                } else {
                    let url = window.URL || window.webkitURL;
                    link = url.createObjectURL(blob);
                    let a = $("<a />");
                    a.attr("download", fileName);
                    a.attr("href", link);
                    $("body").append(a);
                    a[0].click();
                    $("body").remove(a);
                }
            }
            else if (obj.responsecode == '302')
                Toast("No Records found.", 'Message', 'success');
            else
                Toast(RetrieveMessage(obj.responsecode), 'Message', 'error');

        } else
            window.location.href = '/ClientLogin/ClientLogin';
        HideLoader();

    }).fail(function (result) {
        console.log(result.Message);
        HideLoader();
    });
}

//FUNCTION FOR RESET DATA
function ResetForm() {
    $("#IdField").css("display", "none");
    $("#CategoryName").val('');
    $("#Status").val('1');
    $("#FormAdd").show();
    $("#FormUpdate").hide();
    $("#FormReset").hide();
    $("#TaxCategory-tab").html("Add Tax Category");
    var tbody = $("#TblTaxCategory").find("tbody");
    var Tr = $(tbody).find("tr");

    var rowCount = Tr.length;

    if (rowCount > 1) {
        $("#TblTaxCategory tbody tr").each(function (index, ele) {
            if (index > 0) {
                $(ele).remove();
            }
            else {

                $(ele).find(".HiddenTax").val('');
                $(ele).find(".Tax").val('');
                $(ele).find(".TaxValue").val('0.00');
                $(ele).find(".TaxType").val('All');

                $("#TblTaxCategory").find("tbody").append(ele);
            }
        });

    }
    else {
        Tr.find(".HiddenTax").val('');
        Tr.find(".Tax").val('');
        Tr.find(".TaxValue").val('0.00');
        Tr.find(".TaxType").val('All');

        $("#TblTaxCategory").find("tbody").append(Tr);
    }
}
$("#FormReset").click(function () {
    ResetForm();
})

document.addEventListener("keydown", function (zEvent) {
    if (zEvent.ctrlKey && zEvent.altKey && (zEvent.key == "j" || zEvent.key == "J")) {
        $('#TaxCategory_list-tab').removeClass('active ');
        $('#TaxCategory_list').removeClass('active show');
        $('#TaxCategory-tab').addClass('active');
        $('#TaxCategory').addClass('active show');
        $("#FormAdd").show();
        $("#FormUpdate").hide();
        $("#FormReset").hide();
        $("#TaxCategory-tab").html("Add Tax Category ");
        ResetForm();
        $('#CategoryName').focus();
    }
});
