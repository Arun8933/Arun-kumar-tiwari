﻿
var Firstcolumn = "";

// DOCUMENT READY
$(document).ready(function () {
    Firstcolumn = "TemplateAssign_Uid";
    FillPageSizeList('ddlPageSize', FormList);
    BindTemplateName('TemplateNameSearch');
    BindTemplateName('TemplateUid');
    BindTableName('TemplateForSearch');
    BindTableName('TemplateFor');   
});

// PAGINATION BUTTON CLICKED
$(document).on("click", ".pagination .page", function () {
    FormList(($(this).attr('page')));    
});
//PAGE SIZE CHANGE
$("#ddlPageSize").change(function () {
    FormList(1);
});
// SELECT 2
$("#TemplateNameSearch,#TemplateForSearch,#TemplateStatusSearch,#TemplateFor,#TemplateUid,#TemplateStatus").select2({
    width: '100%'
});


//FORMSEARCH BUTTON CLICK 
$("#FormSearch").click(function () {
    FormList(1);
});

//FUNCTION FOR FORM SORTING
function FormSorting(obj) {
    if (Firstcolumn != "") {
        document.getElementById(Firstcolumn).innerHTML = document.getElementById(Firstcolumn).getAttribute("data-column") + " <i class='fa-solid fa-sort'></i>";
    }
    let cn = obj.id;
    Firstcolumn = cn;
    var colname = $(obj).data("column");
    $("#sort-column").val(cn.replaceAll("_", ""));
    var sorttype = $("#sort-type").val();
    if (sorttype == "ASC") {
        $("#sort-type").val("DESC");
        $(obj).html(colname + " <i style='margin-left:10px;' class='fa-solid fa-sort-down'></i>");
    } else if (sorttype == "DESC") {
        $("#sort-type").val("ASC");
        $(obj).html(colname + " <i style='margin-left:10px;' class='fa-solid fa-sort-up'></i>");
    }
    FormList(1);
}

//FUNCTION FOR FOR LIST
function FormList(pageindex) {
    try {
        const dataString = {};
        dataString.PageSize = $("#ddlPageSize").val();
        dataString.PageIndex = pageindex;
        dataString.TempFor = $("#TemplateForSearch").val();
        dataString.TemplateUid = $("#TemplateNameSearch").val();
        dataString.Status = $("#TemplateStatusSearch").val();
        dataString.OrderBy = $("#sort-column").val().trim() + " " + $("#sort-type").val().trim();

        AjaxSubmission(JSON.stringify(dataString), "/Master/TemplateAssign/FormList", $('input[name=__RequestVerificationToken]').val()).done(function (result) {
            let obj = result;
            if (obj.status == true) {
                if (obj.responsecode == '100') {
                    var ser = ((parseInt(obj.data.Table1[0].PageIndex) - 1) * parseInt(obj.data.Table1[0].PageSize)) + 1;
                    BindFormTable(obj.data.Table, ser);
                    if (obj.data.Table1 != undefined && obj.data.Table1.length > 0) {
                        $(".pagination").BindPaging({
                            ActiveCssClass: "current",
                            PagerCssClass: "pager",
                            PageIndex: parseInt(obj.data.Table1[0].PageIndex),
                            PageSize: parseInt(obj.data.Table1[0].PageSize),
                            RecordCount: parseInt(obj.data.Table1[0].count)
                        });
                    }
                }
                else
                    Toast(RetrieveMessage(obj.responsecode), "Message", "error");
            }
        }).fail(function (result) {
            console.log(result.Message);
        });
    }
    catch (e) {
        console.log(e.message);
    }
};

//FUNCTION FOR EXPORT DATA IN EXCEL
function FormExcel() {
    ShowLoader();
    let date = new Date();
    let NewDate = ("00" + date.getDate()).slice(-2) + "_" + ("00" + (date.getMonth() + 1)).slice(-2) + "_" + date.getFullYear() + "_" + ("00" + date.getHours()).slice(-2) + "_" + ("00" + date.getMinutes()).slice(-2) + "_" + ("00" + date.getSeconds()).slice(-2);
    let fileName = "TemplateAssign_" + NewDate + ".xlsx";

    $('#FormSearch').trigger('click');
    AjaxSubmission(null, '/Master/TemplateAssign/FormExcel', $('input[name=__RequestVerificationToken]').val()).done(function (result) {
        let obj = result;
        if (obj.status == true) {
            if (obj.responsecode == '100') {

                let bytes = Base64ToBytes(obj.data.FileData[0].Base64Data);
                let blob = new Blob([bytes], { type: "application/octetstream" });
                let isIE = false || !!document.documentMode;
                if (isIE) {
                    window.navigator.msSaveBlob(blob, fileName);
                } else {
                    let url = window.URL || window.webkitURL;
                    link = url.createObjectURL(blob);
                    let a = $("<a />");
                    a.attr("download", fileName);
                    a.attr("href", link);
                    $("body").append(a);
                    a[0].click();
                    $("body").remove(a);
                }
            }
            else if (obj.responsecode == '302')
                Toast("No Records found.", 'Message', 'success');
            else
                Toast(RetrieveMessage(obj.responsecode), 'Message', 'error');

        } else
            window.location.href = '/ClientLogin/ClientLogin';
        HideLoader();

    }).fail(function (result) {
        console.log(result.Message);
        HideLoader();
    });
}

//FUNCTIO FOR BIND FORM TABLE
function BindFormTable(Result, SerialNo) {
    $("#TblTemplateAssign tbody tr").remove();
    if (Result.length == 0) {
        tr = $('<tr/>');
        tr.append("<td class='text-center' colspan='8'>NO RESULTS FOUND</td>");
        $("#TblTemplateAssign tbody").append(tr);
    }
    else {
        for (i = 0; i < Result.length; i++) {
            if (Result[i].Status == "Active") {
                tr = $('<tr/>');
            }
            else
                tr = $('<tr style="background-color:#fdd2d2;"/>');
            tr.append("<td class='text-center'><button type='button' onclick='FormEdit(\"" + Result[i].TemplateAssignUid + "\");' class= 'common-btn common-btn-sm'><i class='fa-solid fa-pen-to-square'></i></button ><button type='button' onclick='FormDelete(\"" + Result[i].TemplateAssignUid + "\");' class= 'common-btn common-btn-sm '> <i class='fa-regular fa-trash-can'></i></button ></td > ");

            tr.append("<td class='text-left no-cursor'>" + SerialNo + "</td>");
            tr.append("<td class='text-left no-cursor'>" + HandleNullTextValue(Result[i].TemplateAssignUid) + "</td>");
            tr.append("<td class='text-center edit-cursor'><a href='javascript:void(0)' class='text-decoration-none ' style='color: black !important;' onclick='FormEdit(\"" + Result[i].TemplateAssignUid + "\");'>" + Result[i].TempFor + "</a></td>");
            tr.append("<td class='text-left no-cursor'>" + HandleNullTextValue(Result[i].TemplateName) + "</td>");
            tr.append("<td class='text-center no-cursor'>" + HandleNullTextValue(Result[i].Status) + "</td>");

            SerialNo++;
            $("#TblTemplateAssign tbody").append(tr);
        }
    }
};

// FORM ADD BUTTON CLICK EVENT
$("#FormAdd").click(function () {
    if ($("#TemplateFor").val().length <= 1)
        Toast('Please Select Template For', 'Message', 'error');
    else if ($("#TemplateUid").val() <= 0)
        Toast('Please Select Template Name', 'Message', 'error');
    else
        FormAdd();
});

//FUNCTION FOR FORM ADD
function FormAdd() {
    try {
        const dataString = {};
        dataString.TempFor = $("#TemplateFor").val();
        dataString.TemplateUid = $("#TemplateUid").val();
        dataString.Status = $("#TemplateStatus").val();
        AjaxSubmission(JSON.stringify(dataString), "/Master/TemplateAssign/FormAdd", $('[name="__RequestVerificationToken"]').val()).done(function (result) {
            let obj = result;
            if (obj.status == true) {
                if (obj.responsecode == '101') {                    
                    $("#FormAdd").hide();
                    $("#FormUpdate").show();
                    $("#FormReset").show();
                    $("#TemplateAssign-tab").html("Edit Assign Template");
                    $("#Timestamp").val(obj.data.Table[0].TimeStamp);
                    $("#TemplateAssignUid").val(obj.data.Table[0].TemplateAssignUid);
                    Toast(RetrieveMessage(101), 'message', 'success');
                }
                else
                    Toast(RetrieveMessage(obj.responsecode), "Message", "error");
            }
            else
                window.location.href = '/ClientLogin/ClientLogin';
        }).fail(function (result) {
            console.log(result.Message);
        });
    }
    catch (ex) {
        console.log(ex.message);
    }
}

function DeleteTemplateTables(obj) {
    $.confirm({

        title: '',
        content: 'Are You Sure Want To Delete ?',
        type: 'red',
        boxWidth: '300px',
        useBootstrap: false,
        columnClass: 'small',
        containerFluid: true,
        typeAnimated: true,
        buttons: {
            tryAgain: {
                text: 'Confirm',
                btnClass: 'btn-red',
                action: function () {
                    var rowCount = $("#tbl_templateAssign tbody tr").length;
                    if (rowCount > 1) {
                        $(obj).parent().parent().remove();
                        GenerateSearchReportTableRowNumber();
                    }
                    else {
                        $("#Remove_templateAssign").attr("disabled", "disabled");
                    }
                }
            },
            close: function () {
            }
        }
    });
}

//FUNCTION FOR BIND TABLE NAME FOR TEMPLATE
function BindTableName(DrpId) {
    try {      
        AjaxSubmission(null, "/Master/TemplateAssign/AllTemplateFor", $('input[name=__RequestVerificationToken]').val()).done(function (result) {
            let obj = result;
            if (obj.status == true) {
                if (obj.responsecode == '100') 
                    BindDropdown(obj.data.Table, DrpId, 'TableName', 'TableName', '-----Select-----');
                else if (obj.responsecode == '302') 
                    BindDropdown(null, DrpId, 'TableName', 'TableName', '-----Select-----');
                else 
                    Toast(RetrieveMessage(obj.responsecode), "Message", "error");
            }
            else 
                window.location.href = '/ClientLogin/ClientLogin';
        }).fail(function (result) {
            console.log(result.Message);           
        });
    }
    catch (e) {
        console.log(e.message);       
    }
}





//FUNCTION  FOR FORM EDIT
function FormEdit(e) {
    try {
        const datastring = {};
        datastring.TemplateAssignUid = e;
        AjaxSubmission(JSON.stringify(datastring), "/Master/TemplateAssign/FormEdit", $('[name="__RequestVerificationToken"]').val()).done(function (data) {
            let obj = data;
            if (obj.status == true) {
                if (obj.responsecode == '100') {                    
                    TabShow();
                    $("#Timestamp").val(obj.data.Table[0].TimeStamp);
                    $("#TemplateAssignUid").val(obj.data.Table[0].TemplateAssignUid);
                    $("#TemplateFor").val(obj.data.Table[0].TempFor).trigger('change');
                    $("#TemplateUid").val(obj.data.Table[0].TemplateUid).trigger('change');
                    if (obj.data.Table[0].Status == true)
                        $("#TemplateStatus").val("1").trigger('change');
                    else
                        $("#TemplateStatus").val("0").trigger('change');
                } else 
                    Toast(RetrieveMessage(obj.responsecode), "Message", "error");
            }
            else 
                window.location.href = '/ClientLogin/ClientLogin';
        }).fail(function (data) {
            console.log(data.Message);
        });
    }
    catch (e) {
        console.log(e.message);
    }
}


// FORM UPDATE BUTTON CLICK EVENT
$("#FormUpdate").click(function () {
    if ($("#TemplateFor").val().length <= 1)
        Toast('Please Select Template For', 'Message', 'error');
    else if ($("#TemplateUid").val()<= 0)
        Toast('Please Select Template Name', 'Message', 'error');
    else
        Formupdate();
});

//FUNCTION FORM FORM UPDATE
function Formupdate() {
    try {
        const dataString = {};

        dataString.TempFor = $("#TemplateFor").val();
        dataString.TemplateUid = $("#TemplateUid").val();
        dataString.Status = $("#TemplateStatus").val();
        dataString.Timestamp = $("#Timestamp").val();
        dataString.TemplateAssignUid = $("#TemplateAssignUid").val();
        AjaxSubmission(JSON.stringify(dataString), "/Master/TemplateAssign/Formupdate", $('[name="__RequestVerificationToken"]').val()).done(function (result) {
            let obj = result;            
            if (obj.status == true) {
                if (obj.responsecode == '107') {
                    Toast(RetrieveMessage(107), 'message', 'success');
                    $("#Timestamp").val(obj.data.Table[0].TimeStamp);
                    setTimeout(FormList(1), 1000);
                }
                else 
                    Toast(RetrieveMessage(obj.responsecode), "Message", "error");              
            }
            else
                window.location.href = '/ClientLogin/ClientLogin';   
        }).fail(function (result) {
            console.log(result.Message);          
        });
    }
    catch (ex) {      
        console.log(ex.message);
    }
}

//FUNCTION FOR FORM DELETE
function FormDelete(e) {
    try {
        $.confirm({
            title: '',
            content: 'Are You Sure Want To Delete ?',
            type: 'red',
            boxWidth: '300px',
            useBootstrap: false,
            columnClass: 'small',
            containerFluid: true,
            typeAnimated: true,
            buttons: {
                tryAgain: {
                    text: 'Confirm',
                    btnClass: 'btn-red',
                    action: function () {
                        const datastring = {};
                        datastring.TemplateAssignUid = parseInt(e);
                        AjaxSubmission(JSON.stringify(datastring), "/TemplateAssign/FormDelete", $('[name="__RequestVerificationToken"]').val()).done(function (data) {
                            let obj = data;
                            if (obj.status == true) {
                                if (obj.responsecode == '102') {
                                    Toast(RetrieveMessage(obj.responsecode), "Message", "success");
                                    setTimeout(FormList(1), 1000);
                                }
                                else
                                    Toast(RetrieveMessage(obj.responsecode), "Message", "error");                                
                            }
                            else 
                                window.location.href = 'ClientLogin/ClientLogin';                           
                        }).fail(function (data) {
                            console.log(data.Message);
                        });
                    }
                },
                close: function () {

                }
            }
        });
    }
    catch (e) {
        console.log(e.message);
    }
}
function ResetForm() {
    $("#TemplateFor").val("0").trigger('change');
    $("#TemplateUid").val("0").trigger('change');
    $("#TemplateStatus").val("1").trigger('change');
    $("#TemplateAssign-tab").html("Add Assign Template");   
    $("#FormAdd").show();
    $("#FormUpdate").hide();
    $("#FormReset").hide();

}
// FUNCTION FOR TAB SHOW
function TabShow() {
    $('#TemplateAssign-tab').addClass('active');
    $('#TemplateAssignList-tab').removeClass('active ');
    $('#TemplateAssign').addClass('active show');
    $('#TemplateAssignList').removeClass('active show');
    $("#TemplateAssign-tab").html("Edit Assign Template");
    $("#FormAdd").hide();
    $("#FormUpdate").show();
    $("#FormReset").show();
}


//FUNCTION FOR TAB HIDE
function TabHide() {
    $('#TemplateAssign-tab').removeClass('active');
    $('#TemplateAssignList-tab').addClass('active');
    $('#TemplateAssign').removeClass('active show');
    $('#TemplateAssignList').addClass('active show');
    $("#TemplateAssign-tab").html("Add Template");
    $("#FormAdd").show();
    $("#FormUpdate").hide();
    $("#FormReset").hide();

}
$("#TemplateAssignList-tab").click(function () {  
    ResetForm();
})

$("#FormReset").click(function () {   
    ResetForm();
})

document.addEventListener("keydown", function (zEvent) {
    if (zEvent.ctrlKey && zEvent.altKey && (zEvent.key == "j" || zEvent.key == "J")) {
        $('#TemplateAssignList-tab').removeClass('active ');
        $('#TemplateAssignList').removeClass('active show');
        $('#TemplateAssign-tab').addClass('active');
        $('#TemplateAssign').addClass('active show');
        $("#FormAdd").show();
        $("#FormUpdate").hide();
        $("#FormReset").hide();
        $("#TemplateAssign-tab").html("Add Assign Template ");
        $('#TemplateFor').focus();
        ResetForm();

    }
});


