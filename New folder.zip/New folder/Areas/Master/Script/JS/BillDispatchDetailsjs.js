﻿
let flag = true;
let ValidateResult = 0;
let Firstcolumn = '';

$(document).ready(() => {
    FillBillType()
    $("#BillDate").datepicker();
    BillNoAutoCompleteAjax('BillNo', '/Master/BillDispatchDetails/GetBillNumberAutoComplete', 'HiddenBillId', 'HiddenJobNo', 'BillType', 0);
    BillNoAutoCompleteAjax('SearchBillNo', '/Master/BillDispatchDetails/GetBillNumberAutoComplete', 'HiddenSearchBillNo', 'HiddenSearchJobNo', 'SearchBillType', 0);
    var LIS = setInterval(() => {
        if (Get_Cookie("BillDispatchUid") != null)
            FillPageSizeList('ddlPageSize');
        else {
            FillPageSizeList('ddlPageSize', FormList);
            clearInterval(LIS);
            return;
        }
    }, 100);
    flag = true;
    ValidateResult = 0;
})

//FUNCTION FOR BIND BILL TYPE
function FillBillType() {
    try {
        //ShowLoader();
        AjaxSubmission(null, "/Master/BillDispatchDetails/FillBillType", $('input[name=__RequestVerificationToken]').val()).done(function (result) {
            let obj = result;
            if (obj.status == true) {
                if (obj.responsecode == '100') {
                    BindDropdown(obj.data.Table, 'SearchBillType', 'BillTypeUid', 'BillTypeName', '0');
                    BindDropdown(obj.data.Table, 'BillType', 'BillTypeUid', 'BillTypeName', '0');
                    //BindDropdown(obj.data.Table, 'SearchBillType', 'SearchBillTypeUid', 'BillTypeName', '0');
                }
                else if (obj.responsecode == '604') {
                    BindDropdown(null, 'SearchBillType', 'SearchBillTypeUid', 'SearchBillTypeName', '0');
                    BindDropdown(null, 'BillType', 'BillTypeUid', 'BillTypeName', '0');
                }
                else {
                    Toast(RetrieveMessage(obj.responsecode), "Message", "error");
                }
            }
            else {
                window.location.href = '/ClientLogin/ClientLogin';
            }
            //HideLoader();
        }).fail(function (result) {
            console.log(result.Message);
            HideLoader();
        });
    }
    catch (e) {
        console.log(e.message);
        //HideLoader();
    }
}


$(document).on('change', '#JobNo', () => {
    try {
        if ($("#HiddenJobNo").val() != "" && $("#JobNo").val() != "") {
            let dataString = {};
            dataString.JobNo = $('#JobNo').val();
            let url = '/Master/BillDispatchDetails/GetBillNumber';
            AjaxSubmission(JSON.stringify(dataString), url, $('input[name=__RequestVerificationToken]').val()).done(function (result) {
                let obj = result;
                if (obj.status == true) {
                    if (obj.responsecode == '100') {
                        let data = obj.data.Table;
                        flag = false;
                        if (data.length == 1) {
                            ResetForm(true, false, false);
                            $("#HiddenBillId").val(data[0]["BillUid"]);
                            $("#BillNo").val(data[0]["BillNo"]);
                            $("#BillDate").val(data[0]["BillDate"]);
                            $("#PartyName").val(data[0]["ClientName"]);
                        } else if (data.length > 1) {
                            ResetForm(true, false, false);
                            $("#BillNo").prop("disabled", false);
                        }
                    }
                    else if (obj.responsecode == '105') {
                        flag = true;
                        ResetForm(false, false, false);
                        Toast("Bill No not exists on this job no!", "Message", "error");
                    }
                    else {
                        flag = true;
                        ResetForm(false, false, false);
                        Toast(RetrieveMessage(obj.responsecode), "Message", "error");
                    }
                }
                else
                    window.location.href = '/ClientLogin/ClientLogin';
                //Hideloader();
            }).fail(function (result) {
                //Hideloader();
                console.log(result.Message);
            });
        } else
            ResetForm(false, false, false);
    }
    catch (ex) {
        console.log(ex);
    }
});

$(document).on('blur', '#BillNo', () => {
    try {
        if ($("#BillNo").val() == "") {
            ResetForm(true, false, false);
        }
    } catch (ex) {
        console.log(ex);
    }
});
//FUNCTION FOR AUTOCOMPLETE AJAX WITH ID
function BillNoAutoCompleteAjax(id, Url, HiddenId, HiddenJobNo, BillType, PageLoad) {
    try {
        if (PageLoad == 1) {
            return;
        }
        $("#" + id).autocomplete({
            source: function (request, response) {
                AjaxSubmissionAutocomplete(JSON.stringify({ SearchField: request.term, BillType: $("#" + BillType).val(), JobNo: $("#" + HiddenJobNo).val() }), Url, $('input[name=__RequestVerificationToken]').val()).done(function (result) {
                    let obj = result;
                    if (obj.status == true) {
                        if (obj.responsecode == '100') {
                            flag = true;
                            $("#ui-id-1").removeClass("d-none");
                            response($.map(result.data.Table1, function (item, id) {
                                return {
                                    label: item.BillNo,
                                    value: item.BillNo,
                                    id: item.BillUid,
                                    date: item.BillDate,
                                    clientName: item.ClientName,
                                    clientId: item.ClientId
                                };
                            }));
                        } else {
                            $("#ui-id-1").addClass("d-none");
                        }
                    }
                    else
                        window.location.href = '/ClientLogin/ClientLogin';
                    //Hideloader();
                }).fail(function (result) {
                    //Hideloader();
                    console.log(result.Message);
                });
            },
            minLength: 1,
            selectOnly: true,
            select: function (e, i) {
                $("#" + HiddenId).val(i.item.id);
                $("#BillDate").val(i.item.date);
                $("#PartyName").val(i.item.clientName);
                $("#HiddenPartyName").val(i.item.clientId);
            },
            change: function (e, i) {
                if (flag == true) {
                    if (i.item == null || i.item == undefined) {
                        $("#" + id).val('');
                        $("#" + HiddenId).val('');
                        $("#BillDate").val('');
                        $("#PartyName").val('');
                        $("#HiddenPartyName").val('');
                    }
                }
            }
        })
    }
    catch (e) {
        console.log(e);
    }
}

//ADDING BILL DISPATCH DETAILS FUNCTION
$(document).on("click", "#FormAdd", function () {
    ValidationForAddUpdate();
    if (ValidateResult == 0)
        AddBillDispatchDetails();
    else
        return;
})
//ADDING BILL DISPATCH DETAILS FUNCTION
$(document).on("click", "#FormUpdate", function () {

    ValidationForAddUpdate();
    if (ValidateResult == 0)
        FormUpdate();
    else
        return;
})

//FUNCTION FOR ADDING BILL DISPATCH DETAILS AFTER FILLING MANDATORY FIELDS
function AddBillDispatchDetails() {
    try {
        debugger
        let dataString = {};
        dataString.BillType = $("#BillType").val();
        dataString.JobNo = $("#HiddenJobNo").val();
        dataString.HiddenBillId = $("#HiddenBillId").val();
        dataString.DispatchDate = $("#DispatchDate").val();
        dataString.CourierCompany = $("#CourierCompany").val();
        dataString.PODNo = $("#PODNo").val();
        dataString.PartyRecDt = $("#PartyRecDt").val();
        dataString.RecBy = $("#RecBy").val();
        dataString.BESBWithBill = $("#BESBWithBill").val();
        dataString.Remarks = $("#Remarks").val();
        dataString.BillDate = $("#BillDate").val();
        AjaxSubmission(JSON.stringify(dataString), "/Master/BillDispatchDetails/FormAdd", $('input[name=__RequestVerificationToken]').val()).done(function (result) {
            let obj = result;
            if (obj.status == true) {
                if (obj.responsecode == '101') {
                    Toast(RetrieveMessage(obj.responsecode), "Message", "success");
                    $("#BillDispatchUid").val(obj.data.Table1[0]["BillDispatchUid"]);
                    $("#timestamp").val(obj.data.Table1[0]["timestamp"]);
                    $("#FormUpdate").show();
                    $("#FormReset").show();
                    $("#FormAdd").hide();
                    $("#BillEntry-tab").html("Edit Bill Dispatch");
                    FormList(1);
                }
                else if (obj.responsecode == '703') {
                    Toast(obj.error, 'Message', 'error');
                    $("#" + obj.data).focus();
                }
            }
        });
    } catch (e) {
        console.log(e.message);
    }
    finally {
        ValidateResult = 0;
    }
}

//FILL BILL DISPATCH DETAILS  TABLE
function FormList(pageindex) {
    try {
        if ($("#ddlPageSize").val() > 0) {
            const dataString = {};
            dataString.PageSize = $("#ddlPageSize").val();
            dataString.PageIndex = pageindex;
            dataString.BillType = $("#SearchBillType").val();
            dataString.BillUid = $("#HiddenSearchBillNo").val();
            dataString.JobNo = $("#HiddenSearchJobNo").val();
            dataString.ClientName = $("#HiddenSearchClient").val();
            dataString.OrderBy = $("#sort-column").val().trim() + " " + $("#sort-type").val().trim();
            ShowLoader();
            AjaxSubmission(JSON.stringify(dataString), "/Master/BillDispatchDetails/Formlist", $('input[name=__RequestVerificationToken]').val()).done(function (result) {

                let obj = result;

                if (obj.status == true) {
                    if (obj.responsecode == '100') {

                        var ser = ((parseInt(obj.data.Table1[0].PageIndex) - 1) * parseInt(obj.data.Table1[0].PageSize)) + 1;
                        BindBillDispatchFormList(obj.data.Table, ser);
                        if (obj.data.Table1 != undefined && obj.data.Table1.length > 0) {
                            $(".pagination").BindPaging({
                                ActiveCssClass: "current",
                                PagerCssClass: "pager",
                                PageIndex: parseInt(obj.data.Table1[0].PageIndex),
                                PageSize: parseInt(obj.data.Table1[0].PageSize),
                                RecordCount: parseInt(obj.data.Table1[0].count)
                            });
                        }
                    }
                    else
                        Toast(RetrieveMessage(obj.responsecode), "Message", "error");
                }
                else
                    window.location.href = '/ClientLogin/ClientLogin';
            }).fail(function (result) {
                console.log(result.Message);
            });
        }
    }
    catch (e) {
        console.log(e.message);
    }
    finally {
        HideLoader();
    }
}

//BIND BILL DISPATCH TABLE FUNCTION 
function BindBillDispatchFormList(result, serial_no) {
    $("#tbl_BillDispatchDetails tbody tr").remove();

    if (result.length == 0) {
        tr = $('<tr/>');
        tr.append("<td class='text-center' colspan='14'>NO RESULTS FOUND</td>");
        $("#tbl_BillDispatchDetails tbody").append(tr);
    }
    else {
        for (i = 0; i < result.length; i++) {
            if (result[i].CancelBill == true)
                tr = $(' <tr style="background-color:#fdd2d2;"/>');
            else
                tr = $('<tr/>');
            tr.append("<td class='text-center'><button type='button' onclick='FormEdit(\"" + result[i].BillDispatchUid + "\");' class= 'common-btn common-btn-sm'><i class='fa-solid fa-pen-to-square'></i></button > <button type='button' onclick='FormDelete(\"" + result[i].BillDispatchUid + "\");' class= 'common-btn common-btn-sm ms-1'> <i class='fa-regular fa-trash-can'></i></button ></td > ");
            tr.append("<td class='text-left'>" + serial_no + "</td>");
            tr.append("<td class='text-left'>" + result[i].BillDispatchUid + "</td>");
            tr.append("<td class='text-center'>" + result[i].BillNo + "</td>");
            /*tr.append("<td class='text-center fw-bold'><a href='javascript:void(0)' class='text-decoration-none ' style='color: black !important;' onclick='FormEdit(\"" + result[i].BillUid + "\");'>" + result[i].SubBillNo + "</a></td>");*/
            tr.append("<td class='text-center'><a href='javascript:void(0)' class='text-decoration-none ' style='color: black !important;' onclick='FormEdit(\"" + result[i].BillDispatchUid + "\");'>" + result[i].AccHead + "</a></td>");
            tr.append("<td class='text-center'>" + result[i].JobNo + "</td>");
            tr.append("<td class='text-center'>" + result[i].DispatchDate + "</td>");
            tr.append("<td class='text-center'>" + result[i].PODNo + "</td>");
            tr.append("<td class='text-center'>" + result[i].CourierCompany + "</td>");
            tr.append("<td class='text-center'>" + result[i].PartyRecDt + "</td>");
            tr.append("<td class='text-center'>" + result[i].ReceivedBy + "</td>");
            let BESB = result[i].BESBWithBill == 1 ? "YES" : (result[i].BESBWithBill == 0 ? "NO" : "");
            tr.append("<td class='text-center'>" + BESB + "</td>");
            serial_no++;

            $("#tbl_BillDispatchDetails tbody").append(tr);
        }
    }
}

// BILL DISPATCH DETAILS FORM EDIT FUNCTION
function FormEdit(e) {
    try {
        const datastring = {};
        datastring.BillDispatchUid = e;
        AjaxSubmission(JSON.stringify(datastring), "/Master/BillDispatchDetails/FormEdit", $('[name="__RequestVerificationToken"]').val()).done(function (data) {
            let obj = data;
            if (obj.status == true) {
                if (obj.responsecode == '100') {
                    let Row = obj.data.Table[0];
                    $("#GstInvoiceCategory").val(Row["BillTypeUid"]);
                    $("#HiddenJobNo").val(Row["JobNo"]);
                    $("#JobNo").val(Row["JobNo"]);
                    $("#HiddenBillId").val(Row["BillUid"]);
                    $("#BillNo").val(Row["BillNo"]);
                    $("#BillDate").val(Row["BillDate"]);
                    $("#PartyName").val(Row["PartyName"]);
                    $("#DispatchDate").val(Row["DispatchDate"]);
                    $("#CourierCompany").val(Row["CourierCompany"]);
                    $("#PODNo").val(Row["PODNo"]);
                    $("#PartyRecDt").val(Row["PartyRecDt"]);
                    $("#RecBy").val(Row["ReceivedBy"]);
                    let optionValue = Row["BESBWithBill"] === 1 ? "YES" : (Row["BESBWithBill"] === 0 ? "NO" : "SELECT");
                    $("#BESBWithBill").val(optionValue);
                    $("#timestamp").val(Row["TimeStamp"]);
                    $("#BillDispatchUid").val(Row["BillDispatchUid"]);
                    $("#Remarks").val(Row["Remarks"]);
                    TabShow();
                }
                else {
                    Toast(RetrieveMessage(obj.responsecode), "Message", "error");
                }

            }
            else {
                window.location.href = '/ClientLogin/ClientLogin';
            }
        }).fail(function (data) {
            console.log(data.Message);
        });
    }
    catch (e) {
        console.log(e.message);
    }
}

//// BILL ENTRY FORM UPDATE BUTTON CLICK
//$("#FormUpdate").click(function () {
//    flag = 0;
//    BillAddUpdateValidation();
//    if (flag == 0) {
//        FormUpdate();
//    }
//});

// BILL ENTRY FORM UPDATE FUNCTION
function FormUpdate() {
    try {
        let dataString = {};
        dataString.BillType = $("#BillType").val();
        dataString.JobNo = $("#HiddenJobNo").val();
        dataString.HiddenBillId = $("#HiddenBillId").val();
        dataString.DispatchDate = $("#DispatchDate").val();
        dataString.CourierCompany = $("#CourierCompany").val();
        dataString.PODNo = $("#PODNo").val();
        dataString.PartyRecDt = $("#PartyRecDt").val();
        dataString.RecBy = $("#RecBy").val();
        dataString.BESBWithBill = $("#BESBWithBill").val();
        dataString.Timestamp = $("#timestamp").val();
        dataString.BillDispatchUid = $("#BillDispatchUid").val();
        dataString.Remarks = $("#Remarks").val();

        AjaxSubmission(JSON.stringify(dataString), "/Master/BillDispatchDetails/FormUpdate", $('input[name=__RequestVerificationToken]').val()).done(function (result) {
            let obj = result;

            if (obj.status == true) {
                if (obj.responsecode == '107') {
                    Toast(RetrieveMessage(obj.responsecode), "Message", "success");
                    $('#timestamp').val(obj.data.Table1[0].timestamp);
                    $('#BillDispatchUid').val(obj.data.Table1[0].BillDispatchUid);
                    FormList(1);
                }
                else if (obj.responsecode == '703') {
                    Toast(obj.error, 'Message', 'error');
                    $("#" + obj.data).focus();
                }
                else if (obj.responsecode == '104') {
                    Toast(RetrieveMessage(obj.responsecode), "Message", "error");
                }
                else {
                    Toast(RetrieveMessage(obj.responsecode), "Message", "error");
                }
            }
            else {
                window.location.href = '/ClientLogin/ClientLogin';
            }
            //HideLoader();
        }).fail(function (result) {
            console.log(result.Message);
            //HideLoader();
        });
    }
    catch (e) {
        console.log(e.message);
    }
    finally {
        ValidateResult = 0;
    }
}

// BILL DISPATCH DETAILS FORM DELETE FUNCTION
function FormDelete(BillDispatchUid) {
    try {
        $.confirm({
            title: '',
            content: 'Are You Sure Want To Delete ?',
            type: 'red',
            boxWidth: '300px',
            useBootstrap: false,
            columnClass: 'small',
            containerFluid: true,
            typeAnimated: true,
            buttons: {
                tryAgain: {
                    text: 'Confirm',
                    btnClass: 'btn-red',
                    action: function () {
                        const datastring = {};
                        datastring.BillDispatchUid = BillDispatchUid;
                        //ShowLoader();
                        AjaxSubmission(JSON.stringify(datastring), "/Master/BillDispatchDetails/FormDelete", $('[name="__RequestVerificationToken"]').val()).done(function (data) {
                            let obj = data;
                            if (obj.status == true) {
                                if (obj.responsecode == '102') {
                                    Toast(RetrieveMessage(obj.responsecode), "Message", "success");
                                    FormList(1);
                                }
                                else {
                                    Toast(RetrieveMessage(obj.responsecode), "Message", "error");
                                }
                            }
                            else {
                                window.location.href = 'ClientLogin/ClientLogin';
                            }
                            //HideLoader();
                        }).fail(function (data) {
                            console.log(data.Message);
                            //HideLoader();
                        });
                    }
                },
                close: function () {
                    //HideLoader();
                }
            }
        });
    }
    catch (e) {
        console.log(e.message);
        //HideLoader();
    }
}


//FUNCTION FOR VALIDATING ADD AND UPDATE FORM
function ValidationForAddUpdate() {
    ValidateResult = 0;
    if (!$("#HiddenBillId").val() && !$("#BillNo").val()) {
        Toast("Please Fill Bill Number!", "Message", "error");
        $("#BillNo").focus();
        ValidateResult = 1;
        return;
    }
    if (!$("#BillDate").val()) {
        Toast("Please Fill Bill Number!", "Message", "error");
        ValidateResult = 1;
        return;
    }
    if (!$("#PartyName").val() && !$("#HiddenPartyName").val()) {
        Toast("Please Fill Bill Number!", "Message", "error");
        ValidateResult = 1;
        return;
    }
    if (!$("#DispatchDate").val()) {
        Toast("Please Fill Dispatch Date!", "Message", "error");
        $("#DispatchDate").focus();
        ValidateResult = 1;
        return;
    }
    if (!$("#CourierCompany").val()) {
        Toast("Please Fill Courier Company!", "Message", "error");
        $("#CourierCompany").focus();
        ValidateResult = 1;
        return;
    }
    if (!$("#PartyRecDt").val()) {
        Toast("Please Fill Party Received Date!", "Message", "error");
        $("#PartyRecDt").focus();
        ValidateResult = 1;
        return;
    }
    if (!$("#RecBy").val()) {
        Toast("Please Fill Received By!", "Message", "error");
        $("#RecBy").focus();
        ValidateResult = 1;
        return;
    }
}

//ON CHANGING THE BILL TYPE
$(document).on('change', '#BillType', () => {
    ResetForm(false, true, false);
})
//ON RESETING THE FORM
$(document).on('click', '#FormReset,#BillDispatch_list-tab', () => {
    ResetForm(false, true, true);
})

//ADD DATEPICKER IN ALL TEXTBOX HAVING CLASS DATEPICKERALL
$(".datepickerAll").datepicker({
    toolbarPlacement: "bottom",
    showButtonPanel: true,
    changeMonth: true,
    changeYear: true,
    dateFormat: 'dd/mm/yy',
});

//RESET ON FILLING JOB NUMBER
function ResetForm(val, BillTypeChange, AllReset) {
    if (!val)
        $("#JobNo,#HiddenJobNo").val('');
    $("#BillNo,#HiddenBillId,#BillDate,#PartyName,#HiddenPartyName").val('');
    if (BillTypeChange) {
        $('#DispatchDate,#CourierCompany,#PODNo,#PartyRecDt,#RecBy,#Remarks').val('');
        $('#BESBWithBill').val('SELECT');
    }
    if (AllReset) {
        $("#BillType").val(1);
        $("#FormAdd").show();
        $("#timestamp,#BillDispatchUid").val('');
        $("#FormUpdate").hide();
        $("#FormReset").hide();
        $("#BillDispatch-tab").html("Add Bill Dispatch");
    }
}

//FUNCTION FOR TAB SHOW
function TabShow() {
    $('#BillDispatch_list-tab').removeClass('active');
    $('#BillDispatch-tab').addClass('active');
    $('#BillDispatch_list').removeClass('active show');
    $('#BillDispatch').addClass('active show');
    $("#FormAdd").hide();
    $("#FormUpdate").show();
    $("#FormReset").show();
    $("#BillDispatch-tab").html("Edit Bill Dispatch");
}

//FUNCTION FOR TAB HIDE
function TabHide() {
    $('#BillDispatch-tab').removeClass('active');
    $('#BillDispatch_list-tab').addClass('active ');
    $('#BillDispatch_list').addClass('active show');
    $('#BillDispatch').removeClass('active show');
    $("#FormAdd").show();
    $("#FormUpdate").hide();
    $("#FormReset").hide();
    $("#BillDispatch-tab").html("Add Bill Dispatch");
}
//FUNCTION FOR FORM SORTING
function FormSorting(obj) {

    if (Firstcolumn != "") {
        document.getElementById(Firstcolumn).innerHTML = document.getElementById(Firstcolumn).getAttribute("data-column") + " <i style='margin-left:10px;' class='fa-solid fa-sort'></i>";
    }
    let cn = obj.id;
    Firstcolumn = cn;
    let colname = $(obj).data('column');
    $('#sort-column').val(cn.replaceAll('_', ''));
    let sorttype = $('#sort-type').val();
    if (sorttype == 'ASC') {
        $('#sort-type').val('DESC');
        $(obj).html(colname + " <i style='margin-left:10px;' class='fa-solid fa-sort-down'></i>");
    } else if (sorttype == 'DESC') {
        $('#sort-type').val('ASC');
        $(obj).html(colname + " <i style='margin-left:10px;' class='fa-solid fa-sort-up'></i>");
    }
    FormList(1);
}

//FORMSEARCH BUTTON CLICK 
$('#FormSearch').click(function () {
    FormList(1);
});


//FUNCTION FOR EXPORT DATA IN EXCEL
function FormExcel() {
    ShowLoader(); 
    let date = new Date();
    let NewDate = ("00" + date.getDate()).slice(-2) + "_" + ("00" + (date.getMonth() + 1)).slice(-2) + "_" + date.getFullYear() + "_" + ("00" + date.getHours()).slice(-2) + "_" + ("00" + date.getMinutes()).slice(-2) + "_" + ("00" + date.getSeconds()).slice(-2);
    let fileName =  "BillDispatchDetails_" + NewDate + ".xlsx";

    $('#FormSearch').trigger('click');
    AjaxSubmission(null, '/Master/BillDispatchDetails/FormExcel', $('input[name=__RequestVerificationToken]').val()).done(function (result) {
        let obj = result;
        if (obj.status == true) {
            if (obj.responsecode == '100') {

                let bytes = Base64ToBytes(obj.data.FileData[0].Base64Data);
                let blob = new Blob([bytes], { type: "application/octetstream" });
                let isIE = false || !!document.documentMode;
                if (isIE) {
                    window.navigator.msSaveBlob(blob, fileName);
                } else {
                    let url = window.URL || window.webkitURL;
                    link = url.createObjectURL(blob);
                    let a = $("<a />");
                    a.attr("download", fileName);
                    a.attr("href", link);
                    $("body").append(a);
                    a[0].click();
                    $("body").remove(a);
                }
            }
            else if (obj.responsecode == '302')
                Toast('No Records found.', 'Message', 'success');
            else
                Toast(RetrieveMessage(obj.responsecode), 'Message', 'error');

        } else
            window.location.href = '/ClientLogin/ClientLogin';
        HideLoader();

    }).fail(function (result) {
        console.log(result.Message);
        HideLoader();
    });
}