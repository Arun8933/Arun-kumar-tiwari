﻿var Firstcolumn = "";
//DOCUMENT READY FUNCTION
$(document).ready(function () {
    Firstcolumn = "IceGate_Id";
    FillPageSizeList('ddlPageSize', FormList);
    $("#SearchIceGateId").focus();
});

//ICEGATEID LIST FUNCTION
function FormList(pageindex) {
    try {
        
        const dataString = {};
        dataString.PageSize = $("#ddlPageSize").val();
        dataString.PageIndex = pageindex;
        dataString.SearchIceGateIdMasterUid = $("#SearchIceGateIdMasterUid").val().trim();
        dataString.SearchIceGateId = $("#SearchIceGateId").val().trim();
        dataString.OrderBy = $("#sort-column").val().trim() + " " + $("#sort-type").val().trim();       
        AjaxSubmission(JSON.stringify(dataString), "/Master/IceGateId/FormList", $('input[name=__RequestVerificationToken]').val()).done(function (result) {
            let obj = result;
            if (obj.status == true) {
                if (obj.responsecode == '100') {                  
                    var ser = ((parseInt(obj.data.Table1[0].PageIndex) - 1) * parseInt(obj.data.Table1[0].PageSize)) + 1;
                    BindFormTable(obj.data.Table, ser);
                    if (obj.data.Table1 != undefined && obj.data.Table1.length > 0) {
                        $(".pagination").BindPaging({
                            ActiveCssClass: "current",
                            PagerCssClass: "pager",
                            PageIndex: parseInt(obj.data.Table1[0].PageIndex),
                            PageSize: parseInt(obj.data.Table1[0].PageSize),
                            RecordCount: parseInt(obj.data.Table1[0].count)
                        });
                    }
                }
                else
                    Toast(RetrieveMessage(obj.responsecode), "Message", "error");
                
            }
            else
                window.location.href = '/ClientLogin/ClientLogin';
        }).fail(function (result) {
            console.log(result.Message);
        });
    }
    catch (e) {
        console.log(e.message);
    }
}

//FUNCTION FOR BIND ICEGATEID TABLE
function BindFormTable(Result, SerialNo) {
    $("#TblIceGateIdMaster tbody tr").remove();
    if (Result.length == 0) {
        tr = $('<tr/>');
        tr.append("<td class='text-center' colspan='8'>NO RESULTS FOUND</td>");
        $("#TblIceGateIdMaster tbody").append(tr);
    }
    else {
        for (i = 0; i < Result.length; i++) {
            if (Result[i].is_active == "Inactive") {
                tr = $(' <tr style="background-color:#fdd2d2;"/>');
            }
            else {
                tr = $('<tr/>');
                tr.append("<td class='text-center'><button type='button' onclick='FormEdit(\"" + Result[i].IceGateIdMasterUid + "\");' class='common-btn common-btn-sm'><i class='fa-solid fa-pen-to-square'></i></button ><button type='button' onclick='FormDelete(\"" + Result[i].IceGateIdMasterUid + "\");' class='common-btn common-btn-sm ms-1'> <i class='fa-regular fa-trash-can'></i></button ></td > ");
                tr.append("<td class='text-left'>" + SerialNo + "</td>");
                tr.append("<td class='text-left'>" + Result[i].IceGateIdMasterUid + "</td>");
                tr.append("<td class='text-center'><a href='javascript:void(0)' class='text-decoration-none ' style='color: black !important;' onclick='FormEdit(\"" + Result[i].IceGateIdMasterUid + "\");'>" + Result[i].IceGateId + "</a></td>");
                tr.append("<td class='text-left'>" + HandleNullTextValue(Result[i].CreatedBy) + "</td>");
                tr.append("<td class='text-center'>" + HandleNullTextValue(Result[i].CreatedAt) + "</td>");
                tr.append("<td class='text-left'>" + HandleNullTextValue(Result[i].LastUpdatedBy) + "</td>");
                tr.append("<td class='text-center'>" + HandleNullTextValue(Result[i].LastUpdatedAt) + "</td>");
                

            }
            SerialNo++;
            $("#TblIceGateIdMaster tbody").append(tr);
        }
    }
}

//FUNCTION FOR PAGINATION  CLICK
$(document).on("click", ".pagination .page", function () {
    FormList(($(this).attr('page')));
});

//PAGE SIZE DROPDOWN ON CHANGE
$("#ddlPageSize").change(function () {
    FormList(1);
});

//SEARCH BUTTON CLICK
$("#FormSearch").click(function () {
    FormList(1);
});

//FUNCTION FOR FORM SORTING
function FormSorting(obj) {
    if (Firstcolumn != "") {
        document.getElementById(Firstcolumn).innerHTML = document.getElementById(Firstcolumn).getAttribute("data-column") + " <i class='fa-solid fa-sort'></i>";
    }
    let cn = obj.id;
    Firstcolumn = cn;
    var colname = $(obj).data("column");
    $("#sort-column").val(cn.replaceAll("_", ""));
    var sorttype = $("#sort-type").val();
    if (sorttype == "ASC") {
        $("#sort-type").val("DESC");
        $(obj).html(colname + " <i style='margin-left:10px;' class='fa-solid fa-sort-down'></i>");
    } else if (sorttype == "DESC") {
        $("#sort-type").val("ASC");
        $(obj).html(colname + " <i style='margin-left:10px;' class='fa-solid fa-sort-up'></i>");
    }
    FormList(1);
}

//FUNCTION FOR EXPORT DATA IN EXCEL
function FormExcel() {
    ShowLoader();
    let date = new Date();
    let NewDate = ("00" + date.getDate()).slice(-2) + "_" + ("00" + (date.getMonth() + 1)).slice(-2) + "_" + date.getFullYear() + "_" + ("00" + date.getHours()).slice(-2) + "_" + ("00" + date.getMinutes()).slice(-2) + "_" + ("00" + date.getSeconds()).slice(-2);
    let fileName = "IceFateId_" + NewDate + ".xlsx";

    $('#FormSearch').trigger('click');
    AjaxSubmission(null, '/Master/IceGateId/FormExcel', $('input[name=__RequestVerificationToken]').val()).done(function (result) {
        let obj = result;
        if (obj.status == true) {
            if (obj.responsecode == '100') {

                let bytes = Base64ToBytes(obj.data.FileData[0].Base64Data);
                let blob = new Blob([bytes], { type: "application/octetstream" });
                let isIE = false || !!document.documentMode;
                if (isIE) {
                    window.navigator.msSaveBlob(blob, fileName);
                } else {
                    let url = window.URL || window.webkitURL;
                    link = url.createObjectURL(blob);
                    let a = $("<a />");
                    a.attr("download", fileName);
                    a.attr("href", link);
                    $("body").append(a);
                    a[0].click();
                    $("body").remove(a);
                }
            }
            else if (obj.responsecode == '302')
                Toast("No Records found.", 'Message', 'success');
            else
                Toast(RetrieveMessage(obj.responsecode), 'Message', 'error');

        } else
            window.location.href = '/ClientLogin/ClientLogin';
        HideLoader();

    }).fail(function (result) {
        console.log(result.Message);
        HideLoader();
    });
}

//ICEGATEID ADD BUTTON CLICK
$("#FormAdd").click(function () {
    RemoveAllError('IceGateIdMaster');
    ValidateAllFieldNewTest('IceGateIdMaster');
    if (Ercount == 0) 
        FormAdd();
});

//FUNCTION FOR ADD ICEGATEID 
function FormAdd() {
    try {
        const datastring = {};
        datastring.IceGateId = $("#IceGateId").val();       
        ShowLoader();
        AjaxSubmission(JSON.stringify(datastring), "/Master/IceGateId/FormAdd", $('input[name=__RequestVerificationToken]').val()).done(function (result) {
            let obj = result;
            if (obj.status == true) {
                if (obj.responsecode == '101') {
                    Toast(RetrieveMessage(obj.responsecode), "Message", "success");
                    setTimeout(FormList(1), 1000);
                    $("#FormAdd").hide();
                    $("#FormUpdate").show();
                    $("#FormReset").show();
                    $("#IceGateIdMaster-tab").html("Edit IceGate Id");
                    $("#IceGateIdMasterUid").val(obj.data.Table[0].IceGateIdMasterUid);
                    $("#TimeStamp").val(obj.data.Table[0].TimeStamp);
                }
                else
                    Toast(RetrieveMessage(obj.responsecode), "Message", "error");
            }
            else 
                window.location.href = '/ClientLogin/ClientLogin';
            HideLoader();
        }).fail(function (result) {
            console.log(result.Message);
            HideLoader();
        });
    }
    catch (e) {
        console.log(e.message);
        HideLoader();
    }
}

//EDIT ICEGATEID FUNCTION
function FormEdit(e) {
    try {
        ShowLoader();
        const datastring = {};
        datastring.IceGateIdMasterUid = e;
        AjaxSubmission(JSON.stringify(datastring), "/Master/IceGateId/FormEdit", $('[name="__RequestVerificationToken"]').val()).done(function (data) {
            let obj = data;
            if (obj.status == true) {
                if (obj.responsecode == '100') {
                    TabShow();
                   
                    $("#IceGateIdMasterUid").val(obj.data.Table[0].IceGateIdMasterUid);
                    $("#TimeStamp").val(obj.data.Table[0].TimeStamp);
                    $("#IceGateId").val(obj.data.Table[0].IceGateId);
                    
                } else {
                    Toast(RetrieveMessage(obj.responsecode), "Message", "error");
                }
            }
            else {
                window.location.href = '/ClientLogin/ClientLogin';
            }
            HideLoader();
        }).fail(function (data) {
            console.log(data.Message);
            HideLoader();
        });

    }
    catch (e) {
        console.log(e.message);
        HideLoader();
    }
}

//ICEGATEID UPDATE BUTTON CLICK
$("#FormUpdate").click(function () {
    RemoveAllError('IceGateIdMaster');
    ValidateAllFieldNewTest('IceGateIdMaster');
    if (Ercount == 0)
        FormUpdate();
});

//UPDATE ICEGATEID FUNCTION
function FormUpdate() {
    try {
        const datastring = {};
        datastring.IceGateIdMasterUid = $("#IceGateIdMasterUid").val();
        datastring.IceGateId = $("#IceGateId").val();
        datastring.TimeStamp = $("#TimeStamp").val();       
        AjaxSubmission(JSON.stringify(datastring), "/Master/IceGateId/FormUpdate", $('input[name=__RequestVerificationToken]').val()).done(function (result) {
            let obj = result;
            if (obj.status == true) {
                if (obj.responsecode == '107') {
                    Toast(RetrieveMessage(obj.responsecode), "Message", "success");
                    FormList(1);               
                    $("#TimeStamp").val(obj.data.Table[0].TimeStamp);
                }
                else 
                    Toast(RetrieveMessage(obj.responsecode), "Message", "error");
            }
            else
                window.location.href = '/ClientLogin/ClientLogin';
          
        }).fail(function (result) {
            console.log(result.Message);
        });
    }
    catch (e) {
        console.log(e.Message);
       
    }
}

//DELETE ICEGATEID FUNCTION
function FormDelete(e) {
    try {
        $.confirm({
            title: '',
            content: 'Are You Sure Want To Delete ?',
            type: 'red',
            boxWidth: '300px',
            useBootstrap: false,
            columnClass: 'small',
            containerFluid: true,
            typeAnimated: true,
            buttons: {
                tryAgain: {
                    text: 'Confirm',
                    btnClass: 'btn-red',
                    action: function () {
                        const datastring = {};
                        datastring.IceGateIdMasterUid = parseInt(e);                        
                        AjaxSubmission(JSON.stringify(datastring), "/Master/IceGateId/FormDelete", $('[name="__RequestVerificationToken"]').val()).done(function (data) {
                            let obj = data;
                            if (obj.status == true) {
                                if (obj.responsecode == '102') {
                                    Toast(RetrieveMessage(obj.responsecode), "Message", "success");
                                    FormList(1);
                                }
                                else
                                    Toast(RetrieveMessage(obj.responsecode), "Message", "error");
                            }
                            else
                                window.location.href = 'ClientLogin/ClientLogin';                           
                        }).fail(function (data) {
                            console.log(data.Message);                           
                        });
                    }
                },
                close: function () {

                }
            }
        });
    }
    catch (e) {
        console.log(e.message);       
    }
}


//FUNCTION FOR TAB HIDE
function TabShow() {
    $('#IceGateIdMaster_list-tab').removeClass('active');
    $('#IceGateIdMaster-tab').addClass('active');
    $('#IceGateIdMaster_list').removeClass('active show');
    $('#IceGateIdMaster').addClass('active show');
    $("#FormAdd").hide();
    $("#FormUpdate").show();
    $("#FormReset").show();
    $("#IceGateIdMaster-tab").html("Edit IceGate Id");
}

//FUNCTION FOR TAB HIDE
function TabHide() {
    $('#IceGateIdMaster-tab').removeClass('active');
    $('#IceGateIdMaster_list-tab').addClass('active ');
    $('#IceGateIdMaster_list').addClass('active show');
    $('#IceGateIdMaster').removeClass('active show');
    $("#FormAdd").show();
    $("#FormUpdate").hide();
    $("#FormReset").hide();
    $("#IceGateIdMaster-tab").html("Add IceGate Id");
}

//ICEGATE ID MASTER LIST TAB ON CLICK
$('#IceGateIdMaster_list-tab').click(function () {
    ResetForm();
    TabHide();
    RemoveAllError('IceGateIdMaster');
});

//FUNCTION FOR RESET DATA
function ResetForm() {
    $("#IceGateIdMasterUid").val('');
    $("#IceGateId").val('');
    $("#TimeStamp").val('');
    $("#FormAdd").show();
    $("#FormUpdate").hide();
    $("#FormReset").hide();
   
}
$("#FormReset").click(function () {
    $("#IceGateIdMaster-tab").html("Add IceGate Id");
    ResetForm();
})

document.addEventListener("keydown", function (zEvent) {
    if (zEvent.ctrlKey && zEvent.altKey && (zEvent.key == "j" || zEvent.key == "J")) {
        $('#IceGateIdMaster_list-tab').removeClass('active ');
        $('#IceGateIdMaster_list').removeClass('active show');
        $('#IceGateIdMaster-tab').addClass('active');
        $('#IceGateIdMaster').addClass('active show');
        $("#FormAdd").show();
        $("#FormUpdate").hide();
        $("#FormReset").hide();
        $("#IceGateIdMaster-tab").html("Add IceGate Id ");
        ResetForm();
        $('#IceGateId').focus();
    }
});

