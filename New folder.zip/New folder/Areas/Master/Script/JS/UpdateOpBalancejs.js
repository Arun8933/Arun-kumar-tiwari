﻿$(document).ready(function () {
    $("#FinYear").select2({
        width: '100%'
    });
    FillFinancialYearList('FinYear')
})

$("#UpdateFinyrOpBal").click(function () {
    $("#tbl_UpdateOpBalance tbody").html('');
    tr = $('<tr/>');
    tr.append("<td class='text-center' colspan='9'>NO RESULTS FOUND</td>");
    $("#tbl_UpdateOpBalance tbody").append(tr);
    var flag = 0;
    if ($("#FinYear").val() == 0) {
        Toast("Please Select Financial Year !", "message", 'error');
        flag = 1;
        return false;
    }
    else {
        let fin = new Array;
        $("#FinYear option").each(function (i) {
            fin.push($(this).val());
        });
        for (i = 0; i < fin.length; i++) {
            if ($("#FinYear").val() == fin[i]) {
                if (i == 1) {
                    Toast('First Financial Year can have only manual entry', 'Message', 'error');
                } else
                    FormList();
            }
        }  
    }
});

//FUNCTION FOR FILL CLIENT USER LIST
function FillFinancialYearList(DrpID) {
    try {
        //Showloader();
        AjaxSubmission(null, "/_Layout/GetListFinancialYearName", $('input[name=__RequestVerificationToken]').val()).done(function (result) {
            let obj = result;
            if (obj.status == true) {
                if (obj.responsecode == '100')
                    BindDropdown(obj.data.Table, DrpID, 'finyr_id', 'finyr_name', '-----Select-----');


                else if (obj.responsecode == '604')
                    BindDropdown(null, DrpID, 'finyr_id', 'finyr_name', '-----Select-----');
                else
                    Toast(RetrieveMessage(obj.responsecode), "Message", "error");
            }
            else
                window.location.href = '/ClientLogin/ClientLogin';
            //Hideloader();
        }).fail(function (result) {
            //Hideloader();
            console.log(result.Message);
        });
    }
    catch (e) {
        //Hideloader();
        console.log(e.message);
    }
}



// UPDATE OPENING BALANCE LIST 
function FormList() {
    try {
        const dataString = {};
        dataString.FinancialYearId = $("#FinYear").val();
        AjaxSubmission(JSON.stringify(dataString), "/Master/UpdateOpBalance/FormList ", $('input[name=__RequestVerificationToken]').val()).done(function (result) {
            let obj = result;
            if (obj.status == true) {
                if (obj.responsecode == '100') {
                    BindFormTable(obj.data.Table);
                }
                else {
                    Toast(RetrieveMessage(obj.responsecode), "Message", "error");
                }
            }
            else {
                window.location.href = '/ClientLogin/ClientLogin';
            }

            //HideLoader();

        }).fail(function (result) {
            console.log(result.Message);
            //HideLoader();
        });
    }
    catch (e) {
        console.log(e.message);
        //HideLoader();
    }
}


// BIND  CHARGES TYPE TABLE
function BindFormTable(result, serial_no) {
    $("#tbl_UpdateOpBalance tbody tr").remove();
    if (result.length == 0) {
        tr = $('<tr/>');
        tr.append("<td class='text-center' colspan='9'>NO RESULTS FOUND</td>");
        $("#tbl_UpdateOpBalance tbody").append(tr);
    }
    else {
        for (i = 0; i < result.length; i++) {
            tr = $('<tr/>');
            tr.append("<td class='text-center'>" + parseInt(i + 1) + "</td>");
            tr.append("<td class='text-center' id='" + result[i].LedgerUid + "'>" + result[i].AccHead + "</td>");
            tr.append("<td class='text-center'>" + result[i].PreviousYear + "</td>");
            tr.append("<td class='text-center'>" + result[i].CurrentYear + "</td>");
            tr.append("<td class='text-end'>" + result[i].CurrentBalance + "</td>");
            tr.append("<td class='text-end'>" + result[i].OpeningBalance + "</td>");
            serial_no++;
            $("#tbl_UpdateOpBalance tbody").append(tr);
        }
    }
}




$("#UpdateOpeningBalance").click(function () {
    $("#tbl_UpdateOpBalance tbody").html('');
    tr = $('<tr/>');
    tr.append("<td class='text-center' colspan='9'>NO RESULTS FOUND</td>");
    $("#tbl_UpdateOpBalance tbody").append(tr);
    var flag = 0;
    if ($("#FinYear").val() == 0) {
        Toast("Please Select Financial Year !", "message", 'error');
        flag = 1;
        return false;
    }
    else {
        let fin = new Array;
        $("#FinYear option").each(function (i) {
            fin.push($(this).val());
        });
        for (i = 0; i < fin.length; i++) {
            if ($("#FinYear").val() == fin[i]) {
                if (i == 1) {
                    Toast('First Financial Year can have only manual entry', 'Message', 'error');
                } else {                    
                    UpdateOpeningBalnce();
                }
                   
            }
        }
    }
});

// UPDATE OPENING BALANCE 
function UpdateOpeningBalnce() {
    try {
        $.confirm({
            title: '',
            content: 'Are You Sure Want To Update Ledger Opening Balance Because This Will Delete all The Manual Enteries of Opening Balnce For THis Financial Year ?',
            type: 'red',
            boxWidth: '400px',
            useBootstrap: false,
            columnClass: 'small',
            containerFluid: true,
            typeAnimated: true,
            buttons: {
                tryAgain: {
                    text: 'Confirm',
                    btnClass: 'btn-red',
                    action: function () {
                        const dataString = {};
                        dataString.FinancialYearId = $("#FinYear").val();
                        AjaxSubmission(JSON.stringify(dataString), "/Master/UpdateOpBalance/UpdateOpeningBalnce ", $('input[name=__RequestVerificationToken]').val()).done(function (data) {
                            let obj = data;
                            if (obj.status == true) {
                                console.log(obj);
                                if (obj.responsecode == '107') {
                                    Toast(RetrieveMessage(obj.responsecode), "Message", "success");
                                    FormList();
                                }
                                else {
                                    Toast(RetrieveMessage(obj.responsecode), "Message", "error");
                                }
                            }
                            else {
                                window.location.href = 'ClientLogin/ClientLogin';
                            }
                            HideLoader();
                        }).fail(function (data) {
                            console.log(data.Message);
                            HideLoader();
                        });
                    }
                },
                close: function () {
                    HideLoader();
                }
            }
        });
    }
    catch (e) {
        console.log(e.message);
        HideLoader();
    }
}


// FUNCTION FOR GO TO REDIRECT VIEW
function GoToRedirectView(e, E1) {
    var RefId = e;
    var substring = RefId.slice(3);
    var firstTwoChars = RefId.slice(0, 2);
    if (firstTwoChars == 'PU') {
        window.open('/Master/PurchaseEntry/PurchaseEntry', '_blank');
        SetCookie('LedgerGroupName', e, 's', 50);

    }
   
}
