﻿var srbtn = 'up';
var DateFrom = "";
var DateTo = "";
var LedgerId = "";
var sel = "";

//DOCUMNET READY
$(document).ready(function () {
    //  GetFinancialYearDate();
    FillBankNameLedger('BankName');
    //DATEPICKER FOR SEARCHJOBDATEFROM AND SEARCHJOBDATETO
    $('#FromDate,#ToDate').datepicker({
        toolbarPlacement: "bottom",
        showButtonPanel: true,
        changeMonth: true,
        changeYear: true,
        dateFormat: 'dd/mm/yy',
        onClose: function () {
            if ($('#FromDate').val().length == 10 || $('#ToDate').val().length == 10)
                CompareSearchDate($('#FromDate').val(), $('#ToDate').val(), '');
        }
    });

    $(".datepickerAll1").datepicker({
        changeMonth: true,
        changeYear: true,
        dateFormat: 'dd/mm/yy'
    });
    $(".datepickerAll1").datepicker('setDate', 'today');
    ReportBy();

});

$("#BankName").select2({
    width: '100%'
});

$("#ReportBy").select2({
    width: '100%'
});

//SEARCH ARROW UP/DOWN
$("#Arrow").click(function () {
    if (srbtn == 'up') {
        $("#icn").html("<i class='fa-solid fa-angle-down'></i>");
        srbtn = 'down';
    } else {
        $("#icn").html("<i class='fa-solid fa-angle-up'></i>");
        srbtn = 'up';
    }
});

function FillBankNameLedger(DrpID) {
    try {
        //Showloader();
        AjaxSubmission(null, "/Master/BankReconciliationReport/FillBankNameLedger", $('input[name=__RequestVerificationToken]').val()).done(function (data) {
            let obj = data;
            if (obj.status == true) {
                if (obj.responsecode == '100')
                    BindDropdown(obj.data.Table, DrpID, 'LedgerUid', 'AccHead', '---Select---');
                else if (obj.responsecode == '100')
                    BindDropdown(obj.data.Table, DrpID, 'LedgerUid', 'AccHead', '---Select---');
                else
                    Toast(RetrieveMessage(obj.responsecode), "Message", "error");
            }
            else
                window.location.href = '/ClientLogin/ClientLogin';
        }).fail(function (result) {
            console.log(result.Message);
        });
    }
    catch (e) {
        console.log(e.message);
    }
}

function ReportBy() {
    if ($("#ReportBy").val() == '0') {
        $("#FromDate").attr('disabled', true);
        $("#ToDate").attr('disabled', true);
        $("#OnDate").attr('disabled', false);
        $("#FromDate").val('');
        $("#ToDate").val('');
    }
    else if ($("#ReportBy").val() == '1') {
        $("#OnDate").attr('disabled', true);
        $("#FromDate").attr('disabled', false);
        $("#ToDate").attr('disabled', false);
        $("#OnDate").val('');
    }
}



$("#FormSearch").click(function () {

    var FromDate = $("#FromDate").val();
    var ToDate = $("#ToDate").val();
    var OnDate = $("#OnDate").val();
    var flag = 0;
    if ($("#BankName").val() == "0") {
        Toast("Please Select BankName !", 'Message', 'error');
        flag = 1;
        return false;
    }
    if ($("#ReportBy").val() == "0") {
        if (OnDate == "") {
            Toast("Please Enter OnDate*", "Message", "error");
            flag = 1;
            return false;
        }
        else {
            $("#ShowPdf").show();
            $(".ReportDNone").show();
            FormList();
        }
    }

    if ($("#ReportBy").val() == "1") {
        if (FromDate == "") {
            Toast("Please Enter Date From", "Message", "error");
            flag = 1;
            return false;
        }
        if (ToDate == "") {
            Toast("Please Enter Date To", "Message", "error");
            flag = 1;
            return false;
        }
        if (FromDate >= ToDate) {
            Toast("To Date Must Be Greater Than From Date*", "Message", "error");
            flag = 1;
            return false;
        }
        else {
            $("#ShowPdf").show();
            $(".ReportDNone").show();
            FormList();
        }
    }

});

//BANK RECONCILIATION MASTER LIST FUNCTION
function FormList() {
    try {
        const dataString = {};
        dataString.BankName = parseInt($("#BankName").val());
        dataString.ReportBy = $("#ReportBy").val();
        dataString.FromDate = $("#FromDate").val();
        dataString.ToDate = $("#ToDate").val();
        dataString.OnDate = $("#OnDate").val();
        ShowLoader();
        AjaxSubmission(JSON.stringify(dataString), "/Master/BankReconciliationReport/FormList", $('input[name=__RequestVerificationToken]').val()).done(function (result) {
            let obj = result;
            console.log(obj);
            if (obj.status == true) {
                if (obj.responsecode == '100') {
                    BindFormTable(obj.data.Table, obj.data.Table[0].ReportBy);
                }
                else
                    Toast(RetrieveMessage(obj.responsecode), "Message", "error");
            }
            else
                window.location.href = '/ClientLogin/ClientLogin';
            HideLoader();
        }).fail(function (result) {
            console.log(result.Message);
            HideLoader();
        });
    }
    catch (e) {
        console.log(e.message);
        HideLoader();
    }
}

//FUNCTION FOR BIND BANK RECONCILIATION LIST TABLE
function BindFormTable(Result, ReportBy) {
    $("#tbl_BankReconciliationReport tbody tr").remove();
    if (ReportBy == '0') {
        if (Result.length == 0) {
            tr = $('<tr/>');
            tr.append("<td class='text-center' colspan='8'>NO RESULTS FOUND</td>");
            $("#tbl_BankReconciliationReport tbody").append(tr);
        }
        else {

            for (i = 0; i < Result.length; i++) {
                tr = $('<tr/>');
                if ((Result[i].type == 1) || (Result[i].type == 2) || (Result[i].type == 4) || (Result[i].type == 6)) {

                    tr.append("<td class='text-end ' colspan='8'><b>" + Result[i].BalanceType + "</b></td>")
                }
                else {
                    if ((Result[i].type == 3) || (Result[i].type == 5)) {
                        tr.append("<td class='text-center'>" + Result[i].SerialNo + " </td>")
                    }
                    else {
                        tr.append("<td class='text-center'></td>")
                    }
                    tr.append("<td class='text-center '>" + HandleNullTextValue(Result[i].DocNo) + "</td>")
                    tr.append("<td class='text-center '>" + HandleNullTextValue(Result[i].Date) + "</td>")
                    tr.append("<td class='text-center'> " + HandleNullTextValue(Result[i].ChequeNo) + "</td>")
                    tr.append("<td class='text-center'> " + HandleNullTextValue(Result[i].RefDescription) + "</td>")
                    tr.append("<td class='text-center'> " + HandleNullTextValue(Result[i].Particular) + "</td>")
                    tr.append("<td class='text-end'> " + HandleNullTextValue(Result[i].Amount) + "</td>")
                    tr.append("<td class='text-end'> " + Result[i].BalanceType + "</td>")
                }
                $("#tbl_BankReconciliationReport tbody").append(tr);
            }
        }
    }
    else {

        if (Result.length == 0) {
            tr = $('<tr/>');
            tr.append("<td class='text-center' colspan='8'>NO RESULTS FOUND</td>");
            $("#tbl_BankReconciliationReport tbody").append(tr);
        }
        else {
            for (i = 0; i < Result.length; i++) {
                tr = $('<tr/>');
                if ((Result[i].type == 1) || (Result[i].type == 3) || (Result[i].type == 4)) {

                    tr.append("<td class='text-end ' colspan='8'><b>" + Result[i].BalanceType + "</b></td>")
                }
                else {

                    if ((Result[i].type == 2)) {
                        tr.append("<td class='text-center'>" + Result[i].SerialNo + " </td>")
                    }
                    else {
                        tr.append("<td class='text-center'></td>")
                    }
                    tr.append("<td class='text-center '>" + HandleNullTextValue(Result[i].DocNo) + "</td>")
                    tr.append("<td class='text-center '>" + HandleNullTextValue(Result[i].Date) + "</td>")
                    tr.append("<td class='text-center'> " + HandleNullTextValue(Result[i].ChequeNo) + "</td>")
                    tr.append("<td class='text-center'> " + HandleNullTextValue(Result[i].RefDescription) + "</td>")
                    tr.append("<td class='text-center'> " + HandleNullTextValue(Result[i].Particular) + "</td>")
                    tr.append("<td class='text-end'> " + HandleNullTextValue(Result[i].Amount) + "</td>")
                    tr.append("<td class='text-end'> " + Result[i].BalanceType + "</td>")

                }
                $("#tbl_BankReconciliationReport tbody").append(tr);
            }
        }
    }
}


//ON CLICK FUNCTION FOR PDF
$("#BankReconciliationPDF").click(function () {
    try {
        const dataString = {};
        dataString.BankName = parseInt($("#BankName").val());
        dataString.ReportBy = $("#ReportBy").val();
        dataString.FromDate = $("#FromDate").val();
        dataString.ToDate = $("#ToDate").val();
        dataString.OnDate = $("#OnDate").val();
        ShowLoader();
        AjaxSubmission(JSON.stringify(dataString), "/Master/BankReconciliationReport/BankReconciliationReportPdf", $('input[name=__RequestVerificationToken]').val()).done(function (result) {
            let obj = result;
            if (obj.status == true) {
                if (obj.responsecode == '100') {
                    window.open($("#MyReport").attr('href'), '_blank');
                }
                else
                    Toast(RetrieveMessage(obj.responsecode), "Message", "error");
            }
            else
                window.location.href = '/ClientLogin/ClientLogin';
            HideLoader();
        }).fail(function (result) {
            console.log(result.Message);
            HideLoader();
        });
    }
    catch (e) {
        console.log(e.message);
        HideLoader();
    }
});
