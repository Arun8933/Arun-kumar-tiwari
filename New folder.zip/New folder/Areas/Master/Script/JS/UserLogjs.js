﻿$(document).ready(function () {
    Firstcolumn = 'LogDate';
    var date = new Date();
  
    var NewDate = date.getDate().toString().padStart(2, 0) + '/' + (date.getMonth() + 1).toString().padStart(2, 0) +
        '/'+ date.getFullYear().toString();
    $("#FromDate").val(NewDate);
    $("#ToDate").val(NewDate);

    FillUserListUserLog('UserNameSearch');

    FillPageSizeList('ddlPageSize', FormList);
   
    $(".datepickerAll").datepicker({
        changeMonth: true,
        changeYear: true,
        dateFormat: 'dd/mm/yy'
    });
});

//FUNCTION FOR FILL CLIENT USER LIST
function FillUserListUserLog(DrpID) {
    try {
       
        //Showloader();
        
        AjaxSubmission(null, "/Master/_Layout/UserList", $('input[name=__RequestVerificationToken]').val()).done(function (result) {
            let obj = result;
            if (obj.status == true) {
                if (obj.responsecode == '100')
                    BindDropdown(obj.data.Table, DrpID, 'user_id', 'user_name', '-----All-----');
                else if (obj.responsecode == '604')
                    BindDropdown(null, DrpID, 'user_id', 'user_name', '-----All-----');
                else
                    Toast(RetrieveMessage(obj.responsecode), "Message", "error");
            }
            else
                window.location.href = '/ClientLogin/ClientLogin';
            //Hideloader();
        }).fail(function (result) {
            //Hideloader();
            console.log(result.Message);
        });
    }
    catch (e) {
        //Hideloader();
        console.log(e.message);
    }
}
//PAGE SIZE CLICKED
$("#ddlPageSize").change(function () {
    FormList(1);
});

// PAGINATION BUTTON CLICKED
$(document).on("click", ".pagination .page", function () {
    FormList(($(this).attr('page')));
});

//FORMSEARCH BUTTON CLICK 
$("#FormSearch").click(function () {
    FormList(1);
});
//FUNCTION  FOR BIND FORM TABLE
function BindFormTable(Result, SerialNo) {   
    $("#TblUserLogDetails tbody tr").remove();

    if (Result.length == 0) {
        tr = $('<tr/>');
        tr.append("<td class='text-center' colspan='7'>NO RECORDS FOUND</td>");
        $("#TblUserLogDetails tbody").append(tr);
    } else {
        for (i = 0; i < Result.length; i++) {
            tr = $('<tr/>');          
            tr.append("<td class='text-left'>" + SerialNo + "</td>");
            tr.append("<td class='text-left'>" + Result[i].LogUid + "</td>");
            tr.append("<td class='text-center'>" + Result[i].UserId + "</td>");
            tr.append("<td class='text-center'>" + Result[i].UserName + "</td>");
            tr.append("<td class='text-center'>" + Result[i].Ip + "</td>");
            tr.append("<td class='text-left'>" + Result[i].LogDesc + "</td>");
            tr.append("<td class='text-center'>" + Result[i].LogDate + "</td>");
            $("#TblUserLogDetails tbody").append(tr);
            SerialNo++;

        }
    }
}

//FUNCTION FOR FORM SORTING
function FormSorting(obj) {
    if (Firstcolumn != "") {
        document.getElementById(Firstcolumn).innerHTML = document.getElementById(Firstcolumn).getAttribute("data-column") + " <i class='fa-solid fa-sort'></i>";
    }
    let cn = obj.id;
    Firstcolumn = cn;
    var colname = $(obj).data("column");
    $("#sort-column").val(cn.replaceAll("_", ""));
    var sorttype = $("#sort-type").val();   
    if (sorttype == "ASC") {
        $("#sort-type").val("DESC");
        $(obj).html(colname + " <i style='margin-left:10px;' class='fa-solid fa-sort-down'></i>");
    } else if (sorttype == "DESC") {
        $("#sort-type").val("ASC");
        $(obj).html(colname + " <i style='margin-left:10px;' class='fa-solid fa-sort-up'></i>");
    }
    FormList(1);
}
function FormList(PageIndex) {
    try {

        if ($('#FromDate').val().trim().length < 10) {
            Toast('Plaese Enter Valid From Date.', 'Message', 'error');
            $('#FromDate').focus();
        }
        else if ($('#ToDate').val().trim().length < 10) {
            Toast('Please Enter Valid To Date.', 'Message', 'error');
            $('#ToDate').focus();
        } else {
            const dataString = {};
            dataString.PageIndex = PageIndex;
            dataString.PageSize = $("#ddlPageSize").val();
            dataString.UserId = $("#UserNameSearch").val();
            dataString.FromDate = $("#FromDate").val();
            dataString.ToDate = $("#ToDate").val();
            dataString.LogDescription = $("#LogDescription").val();
            dataString.OrderBy = "order by " + $("#sort-column").val().trim() + " " + $("#sort-type").val().trim();

            //Showloader();

            AjaxSubmission(JSON.stringify(dataString), '/Master/UserLog/FormList', $('input[name=__RequestVerificationToken]').val()).done(function (result) {
                let obj = result;
                if (obj.status == true) {
                    if (obj.responsecode == '100') {
                        var Ser = ((parseInt(obj.data.Table1[0].PageIndex) - 1) * parseInt(obj.data.Table1[0].PageSize)) + 1;
                        BindFormTable(obj.data.Table, Ser);
                        $(".pagination").BindPaging({
                            ActiveCssClass: "current",
                            PagerCssClass: "pager",
                            PageIndex: parseInt(obj.data.Table1[0].PageIndex),
                            PageSize: parseInt(obj.data.Table1[0].PageSize),
                            RecordCount: parseInt(obj.data.Table1[0].count)
                        });
                    }
                    else if (obj.responsecode == "703")
                        Toast(obj.error, 'Message', 'error');
                    else
                        Toast(RetrieveMessage(obj.responsecode), 'Message', 'error');
                }
                else
                    window.location.href = '/ClientLogin/ClientLogin';
                //Hideloader();
            }).fail(function (result) {
                console.log(result.Message);
                //Hideloader();
            });
        }
        
    }
    catch (e) {
        console.log(e.message);
        //Hideloader();
    }
}

//FUNCTION FOR EXPORT DATA IN EXCEL
function FormExcel() {
    ShowLoader();
    let date = new Date();
    let NewDate = ("00" + date.getDate()).slice(-2) + "_" + ("00" + (date.getMonth() + 1)).slice(-2) + "_" + date.getFullYear() + "_" + ("00" + date.getHours()).slice(-2) + "_" + ("00" + date.getMinutes()).slice(-2) + "_" + ("00" + date.getSeconds()).slice(-2);
    let fileName = "UserLog_" + NewDate + ".xlsx";

    $('#FormSearch').trigger('click');
    AjaxSubmission(null, '/Master/UserLog/FormExcel', $('input[name=__RequestVerificationToken]').val()).done(function (result) {
        let obj = result;
        if (obj.status == true) {
            if (obj.responsecode == '100') {

                let bytes = Base64ToBytes(obj.data.FileData[0].Base64Data);
                let blob = new Blob([bytes], { type: "application/octetstream" });
                let isIE = false || !!document.documentMode;
                if (isIE) {
                    window.navigator.msSaveBlob(blob, fileName);
                } else {
                    let url = window.URL || window.webkitURL;
                    link = url.createObjectURL(blob);
                    let a = $("<a />");
                    a.attr("download", fileName);
                    a.attr("href", link);
                    $("body").append(a);
                    a[0].click();
                    $("body").remove(a);
                }
            }
            else if (obj.responsecode == '302')
                Toast("No Records found.", 'Message', 'success');
            else
                Toast(RetrieveMessage(obj.responsecode), 'Message', 'error');

        } else
            window.location.href = '/ClientLogin/ClientLogin';
        HideLoader();

    }).fail(function (result) {
        console.log(result.Message);
        HideLoader();
    });
}