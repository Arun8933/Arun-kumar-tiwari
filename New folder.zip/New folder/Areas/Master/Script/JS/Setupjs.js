﻿
//DOCUMENT READY 
$(document).ready(function () {
    FillSetupEmailList();
    $('#ClientState').select2({
        width: '100%'
    });
    FillAllStateList('ClientState');   
    let Set = setInterval(() => {
        if ($("#ClientState").val() =='0') {
            FillClientFullDetails();
            clearInterval(Set);
        }
    }, 100);
});

//FUNCTION FOR FILL SETUP EMAIL LIST
function FillSetupEmailList() {
    try {
        AjaxSubmissionformdata(null, "/Master/Setup/SetupEmailList", $('[name="__RequestVerificationToken"]').val()).done(function (data) {
            let obj = data;
            if (obj.status == true) {
                if (obj.responsecode == '100') {                 
                    let tr = "";
                    $("#TblSetupEmail tbody tr").remove();
                    if (obj.data.length == 0) {
                        tr = "<tr>";
                        tr += "<td class='text-center' colspan='17'>NO RECORDS FOUND</td></tr>";
                        $("#TblSetupEmail tbody").html(tr);
                    }
                    else {
                        for (let i = 0; i < obj.data.length; i++) {
                            if (HandleNullTextValue(obj.data[i].Status) == 'Inactive')
                                tr += '<tr style="background-color:#fdd2d2;"/>';
                            else
                                tr += "<tr>";
                            tr += "<td class='text-left'><button type='button' title='Edit Setup Email' onclick='EditSetupEmail(\"" + obj.data[i].Uid + "\");' class= 'Edit common-btn common-btn-sm ms-1' ><i class='fa-solid fa-pen-to-square'></i></button > <button type='button' title='Delete Setup Email' onclick='DeleteSetupEmail(\"" + obj.data[i].Uid + "\");' class= 'Delete common-btn common-btn-sm ms-1' > <i class='fa-regular fa-trash-can'></i> </td>";

                            tr += "<td class='text-left'>" + ( i + 1 ) + "</td>";
                            tr += "<td><a href='javascript:void(0)' class='text-decoration-none fw-bold' style='color: black !important;' onclick='EditSetupEmail(\"" + obj.data[i].Uid + "\");'>" + obj.data[i].ImapPopEmaild + "</a></td>";
                            tr += "<td class='text-left'>" + HandleNullTextValue(obj.data[i].IncomingServerType) + "</td>";
                            tr += "<td class='text-left'>" + HandleNullTextValue(obj.data[i].IncomingMailServer) + "</td>";

                            tr += "<td class='text-left'>" + HandleNullTextValue(obj.data[i].IncomingPort) + "</td>";
                            tr += "<td class='text-center'>" + HandleNullTextValue(obj.data[i].IncomingSSL) + "</td>";
                            tr += "<td class='text-center'>" + HandleNullTextValue(obj.data[i].SaveEmail) + "</td>";
                            tr += "<td class='text-center'>" + HandleNullTextValue(obj.data[i].SaveAttachment) + "</td>";
                            tr += "<td class='text-left'>" + HandleNullTextValue(obj.data[i].FetchEmailId) + "</td>";
                            tr += "<td class='text-center'>" + HandleNullTextValue(obj.data[i].CreatedAt) + "</td>";
                            tr += "<td class='text-left'>" + HandleNullTextValue(obj.data[i].CreatedBy) + "</td>";
                            tr += "<td class='text-center'>" + HandleNullTextValue(obj.data[i].LastUpdatedAt) + "</td>";
                            tr += "<td class='text-left'>" + HandleNullTextValue(obj.data[i].LastUpdatedBy) + "</td>";                            
                            tr += "<td class='text-center'>" + HandleNullTextValue(obj.data[i].Status) + "</td>";                            
                        }
                        $("#TblSetupEmail tbody").html(tr);
                    }
                    
                }
                else
                    Toast(RetrieveMessage(obj.responsecode), 'message', 'error');
            } else
                window.location.href = '/ClientLogin/ClientLogin';           
        }).fail(function (result) {
            console.log(result.Message);           
        });
    }
    catch (e) {
        console.log(e.message);      
    }
}
//FUNCTION FOR SHOW/HIDE PASSWORD
function ShowHidePassword(Id,Icon) {
    let Type = document.getElementById(Id);
    if (Type.type === 'password') {
        $('#' + Icon).addClass('fa-solid fa-eye');
        Type.type = "text";
    }
    else {
        Type.type = "password";
        $('#' + Icon).addClass('fa-solid fa-eye-slash');
    }
}
//GSTCERTIFICATE BUTTON CLICKED EVENT
$('#ShowFile').click(function () {
    DownloadGstFile($('#ClientId').val().trim());    
});

//FUNCTION FOR DOWNLOAD GSTFILE
function DownloadGstFile(ClientId) {
    try {
        ShowLoader();
        const dataString = {};
        dataString.ClientId = ClientId;
        AjaxSubmission(JSON.stringify(dataString), "/Setup/DownloadGstFile", $('[name="__RequestVerificationToken"]').val()).done(function (data) {
            let obj = data;
            if (obj.status == true) {
                if (obj.responsecode == '100') {
                    let bytes = Base64ToBytes(obj.data[0].RawData);
                    let Ext = obj.data[0].FileExt;
                    let blob = new Blob([bytes], { type: "application/octetstream" });
                    let isIE = false || !!document.documentMode;
                    if (isIE) 
                        window.navigator.msSaveBlob(blob, "GstCertificate" + Ext);
                    else
                    {
                        let url = window.URL || window.webkitURL;
                        link = url.createObjectURL(blob);
                        let a = $("<a />");
                        a.attr("download", "GstCertificate" + Ext);
                        a.attr("href", link);
                        $("body").append(a);
                        a[0].click();
                        $("body").remove(a);
                    }
                }
            }
            else
                window.location.href = '/ClientLogin/ClientLogin';
            HideLoader();
        }).fail(function (data) {
            console.log(data.Message);
            HideLoader();
        });
    }
    catch (e) {
        console.log(e.message);
        HideLoader();
    }
}

//FUNCTION FOR BIND SETUP PLAN TABLE
function BindFormTable(Result, SerialNo) {
    $("#TblSetupPlan tbody tr").remove();
    if (Result.length == 0) {
        tr = $('<tr/>');
        tr.append("<td class='text-center' colspan='8'>NO RESULTS FOUND</td>");
        $("#TblSetupPlan tbody").append(tr);
    }
    else
    {
        for (i = 0; i < Result.length; i++) {
            tr = $('<tr/>');
            tr.append("<td class='text-center'>" + SerialNo + "</td>");
            tr.append("<td class='text-center'>" + Result[i].plan_name + "</td>");
            tr.append("<td class='text-center'>" + Result[i].allowed_company + "</td>");
            tr.append("<td class='text-center'>" + Result[i].allowed_user + "</td>");
            tr.append("<td class='text-center'>" + Result[i].PLanPeriod + "</td>");
            tr.append("<td class='text-center'>" + Result[i].PlanStartDate + "</td>");
            tr.append("<td class='text-center'>" + Result[i].ExpiryDate + "</td>");
            SerialNo++;
            $("#TblSetupPlan tbody").append(tr);
        }
    }
   
}

//FUNCTION FOR FILL STATE CODE IN SPAN
function FillStateCodeInSpan() {
    let a = $('#ClientState').val();
    $('#state_code').html(a);
}

//FUNCTION FOR FILL FULL CLIENT DETAILS
function FillClientFullDetails() {
    try {
        AjaxSubmission(null, '/Setup/GetClientFullDetails', $('[name="__RequestVerificationToken"]').val()).done(function (data) {
            let obj = data;
            if (obj.status == true) {
                if (obj.responsecode == '100') {                  
                    $('#ClientId').val(HandleNullTextValue(obj.data.Table1[0].ClientId));
                    $('#PlanName').val(HandleNullTextValue(obj.data.Table1[0].CurrentPlanName));
                    if (obj.data.Table1[0].ShowToggle == 1)
                        $('#PlanExpiry').addClass('blink_me');
                    $('#PlanExpiry').val(HandleNullTextValue(obj.data.Table1[0].ExpiryDate));
                    $('#TimeStamp').val(HandleNullTextValue(obj.data.Table1[0].TimeStamp));
                    $('#ClientName').val(HandleNullTextValue(obj.data.Table1[0].ClientName));
                    $('#ClientEmail').val(HandleNullTextValue(obj.data.Table1[0].PrimaryEmail));
                    $('#ClientPassword').val(HandleNullTextValue(obj.data.Table1[0].LoginPwd));
                    $('#AlternativeEmail').val(HandleNullTextValue(obj.data.Table1[0].AlternativeEmail));
                    $('#ClientPhone').val(HandleNullTextValue(obj.data.Table1[0].PrimaryPhone));
                    $('#AlternativePhone').val(HandleNullTextValue(obj.data.Table1[0].AlternatePhone));
                    $('#ClientState').val(HandleNullTextValue(obj.data.Table1[0].StateCode)).trigger('change');
                    $('#PinCode').val(HandleNullTextValue(obj.data.Table1[0].PinCode));
                    $('#ClientAddress').val(HandleNullTextValue(obj.data.Table1[0].Address));
                    $('#PanNo').val(HandleNullTextValue(obj.data.Table1[0].PANNo));
                    $('#ShowFile').css('display', 'none');
                    if (obj.data.Table1[0].GSTCertificate != null && obj.data.Table1[0].GSTCertificate.length > 0)
                        $('#ShowFile').css('display', 'block');
                    $('#GSTCertificateFile').val(obj.data.Table1[0].GSTCertificate);
                    let gstno = obj.data.Table1[0].GSTin.substring(2);
                    $("#GstNo").val(gstno);
                  
                    $('#WhiteListIp').val(HandleNullTextValue(obj.data.Table1[0].WhiteListIp));
                   
                    BindFormTable(obj.data.Table2, 1);
                    Toast(RetrieveMessage(obj.responsecode), "Message", "success");
                }
                else
                    Toast(RetrieveMessage(obj.responsecode), "Message", "error");
            }
            else 
                window.location.href = '/ClientLogin/ClientLogin';

        }).fail(function (data) {
            console.log(data.Message);
        });
    }
    catch (e) {
        console.log(e.message);
    }
}

//FUNCTION FOR VALIDTAE FILED IN SETUP
function ValidateFieldInSetup() {
    let container = document.getElementById('MyForm');
    let ele = container.getElementsByTagName('input');

    for (i = 0; i < ele.length; i++) {
        if (ele[i].type == 'text' || ele[i].type=='password' ) {
            if ($(ele[i]).siblings('label').find('span').html() == "*") {
                $(ele[i]).trigger('blur');
                if ($(ele[i]).hasClass('error-textbox')) {
                    Ercount = 1;
                    return;
                }
            }
        }
        if (ele[i].type == 'password') {
            $(ele[i]).trigger('blur');
            if ($(ele[i]).hasClass('error-textbox')) {
                Ercount = 1;
                return;
            }
        }

    }
}

//FORMUPDATE BUTTON CLICK EVENT
$('#FormUpdate').click(function () {
    RemoveAllError('MyForm');
    Ercount = 0;
    ValidateFieldInSetup();

    if ($('#AlternativeEmail').val().trim().length > 0) {
        let MultEmail = $('#AlternativeEmail').val().trim().split(",");
        for (let i = 0; i < MultEmail.length; i++) {
            if (!EMAIL_EXPR.test(MultEmail[i])) {
                $('#AlternativeEmail').addClass('error-textbox');
                Ercount = 1;
                Toast('Invalid Email ', 'message', 'error');
                $('#AlternativeEmail').focus();
                return;
            } else {
                $('#AlternativeEmail').attr('style', 'border:1px solid #d9dbde');
                $('#AlternativeEmail').removeClass('error-textbox');
            }
        }
    }

    if ($('#WhiteListIp').val().trim().length > 0) {
        let MultIp = $('#WhiteListIp').val().trim().split(",");
        for (let i = 0; i < MultIp.length; i++) {
            if (!IP_EXPR.test(MultIp[i])) {
                $('#WhiteListIp').addClass('error-textbox');
                Ercount = 1;
                Toast('Invalid Ip Address. ', 'message', 'error');
                $('#WhiteListIp').focus();
                return;
            } else {
                $('#WhiteListIp').attr('style', 'border:1px solid #d9dbde');
                $('#WhiteListIp').removeClass('error-textbox');
            }
        }
    }


    if (Ercount == 0) {

        
        if ($('#ClientState').val().trim() == "0") {
            Toast('Plaese Select State', 'Message', 'error');
            $('#ClientState').select2('open');
        } else if (!CheckPasswordPattern($("#ClientPassword").val())) {
            Toast(RetrieveMessage(988), "Message", "warning");
            $('#password').focus();
        }
        else
            FormUpdate();
    }
});

//FUNCTION FOR FORM UPDATE
function FormUpdate() {
    try {
        ShowLoader();
        let form = $('#MyForm')[0];
        let mydata = new FormData(form);
        AjaxSubmissionformdata(mydata, "/Master/Setup/FormUpdate", $('[name="__RequestVerificationToken"]').val()).done(function (data) {
            let obj = data;          
            if (obj.status == true) {
                if (obj.responsecode == '107') {
                    $('#TimeStamp').val(obj.data);
                    Toast(RetrieveMessage(obj.responsecode), 'message', 'success');
                }
                else if (obj.responsecode == '1042')
                    Toast(obj.error, 'message', 'error');
                else 
                    Toast(RetrieveMessage(obj.responsecode), 'message', 'error');
            } else 
                window.location.href = '/ClientLogin/ClientLogin';
            HideLoader();
        }).fail(function (result) {
            console.log(result.Message);
            HideLoader();
        });
    }
    catch (e) {
        console.log(e.message);
        HideLoader();
    }
}
//FUNCTION FOR GET SETUPEMAILDATA

function GetSetupEmailData() {
    const dataString = {};
    dataString.Uid = $('#SetupUid').val();
    dataString.ImapPopEmailId = $('#ImapPopEmailId').val();
    dataString.ImapPopEmailPassword = $('#ImapPopEmailPassword').val();
    dataString.IncomingServerType = $('#ServerType').val();
    dataString.IncomingMailServer = $('#IncomingMailServer').val();
    dataString.IncomingPort = $('#IncomingPort').val().trim();
    dataString.IncomingSSL = $('#IncomingSSL').is(':checked')
    dataString.FetchEmailId = $('#FetchEmailId').val().trim();
    dataString.SaveAttachment = $('#SaveAttachment').is(':checked');
    dataString.SaveEmail = $('#SaveEmail').is(':checked')
    dataString.TimeStamp = $('#TimeStamp').val();
    dataString.Status = $('#Status').val();
    return dataString;
}

//SETUPEMAILADD BUTTON CLICKED EVENT
$('#SetupEmailAdd').click(function () {
    RemoveAllError('EmailSetup');
    ValidateAllFieldNewTest('EmailSetup');
    if (Ercount == 0)
        SetupEmailAdd();
});
//FUNCTION FOR SETUP EMAIL ADD
function SetupEmailAdd() {
    try {
        const dataString = GetSetupEmailData();
        if (dataString == false)
            return;       
        AjaxSubmission(JSON.stringify(dataString), "/Master/Setup/SetupEmailAdd", $('input[name=__RequestVerificationToken]').val()).done(function (result) {
            let obj = result;
            if (obj.status == true) {
                if (obj.responsecode == '101') {
                    Toast(RetrieveMessage(obj.responsecode), "Message", "success");
                    FillSetupEmailList();                               
                }
                else
                    Toast(RetrieveMessage(obj.responsecode), "Message", "error");
            }
            else 
                window.location.href = '/ClientLogin/ClientLogin';          
        }).fail(function (result) {
            console.log(result.Message);           
        });
    }
    catch (e) {
        console.log(e.message);       
    }
}

//FUNCTION FOR FILL SETUP EMAIL DATA
function FillSetupEmailData(obj) {
    $('#TimeStamp').val(obj.TimeStamp);
    $('#SetupUid').val(obj.Uid);
    $('#ImapPopEmailId').val(obj.ImapPopEmaild);
    $('#ImapPopEmailPassword').val(obj.ImapPopEmailPassword);
    $('#ServerType').val(obj.IncomingServerType);
    $('#IncomingMailServer').val(obj.IncomingMailServer);
    $('#IncomingPort').val(obj.IncomingPort);
    $('#IncomingSSL').prop('checked', obj.IncomingSSL == true ? true : false);
    $('#SaveEmail').prop('checked', obj.SaveEmail == true ? true : false);
    $('#SaveAttachment').prop('checked', obj.SaveAttachment == true ? true : false);
    $('#FetchEmailId').val(obj.FetchEmailId);
    $('#Status').val(obj.Status == true ? 1 : 0);
}
//FUNCTION FOR EDIT SETUP EMAIL
function EditSetupEmail(Uid) {
    try {
        const dataString = {};
        dataString.Uid = Uid;
        AjaxSubmission(JSON.stringify(dataString), "/Setup/SetupEmailEdit", $('[name="__RequestVerificationToken"]').val()).done(function (data) {
            let obj = data;
            if (obj.status == true) {              
                if (obj.responsecode == '100') {
                    FillSetupEmailData(obj.data.Table[0]);                    
                    $('#SetupEmailAdd').addClass('d-none');
                    $('#SetupEmailUpdate').removeClass('d-none');
                }
                else
                    Toast(RetrieveMessage(obj.responsecode), "Message", "error");
            }
            else
                window.location.href = '/ClientLogin/ClientLogin';
          
        }).fail(function (data) {
            console.log(data.Message);          
        });
    }
    catch (e) {
        console.log(e.message);
    }
}
//SETUPEMAILUPDATE BUTTON CLICKED EVENT
$('#SetupEmailUpdate').click(function () {
    RemoveAllError('EmailSetup');
    ValidateAllFieldNewTest('EmailSetup');
    if (Ercount == 0)
        SetupEmailUpdate();
});

//FUNCTION FOR SETUP EMAIL UPDATE
function SetupEmailUpdate() {
    try {
        const dataString = GetSetupEmailData();
        if (dataString == false)
            return;
        AjaxSubmission(JSON.stringify(dataString), "/Master/Setup/SetupEmailUpdate", $('input[name=__RequestVerificationToken]').val()).done(function (result) {
            let obj = result;
            if (obj.status == true) {
                if (obj.responsecode == '107') {
                    Toast(RetrieveMessage(obj.responsecode), "Message", "success");
                    FillSetupEmailList();
                    SetupEmailReset();
                }
                else
                    Toast(RetrieveMessage(obj.responsecode), "Message", "error");
            }
            else
                window.location.href = '/ClientLogin/ClientLogin';
        }).fail(function (result) {
            console.log(result.Message);
        });
    }
    catch (e) {
        console.log(e.message);
    }
}

function DeleteSetupEmail(Uid) {
    try {
        $.confirm({
            title: '',
            content: 'Are You Sure Want To Delete ?',
            type: 'red',
            boxWidth: '300px',
            useBootstrap: false,
            typeAnimated: true,
            columnClass: 'small',
            containerFluid: true,
            draggable: true,
            buttons: {
                tryAgain: {
                    text: 'Confirm',
                    btnClass: 'btn-red',
                    action: function () {
                        const dataString = {};
                        dataString.Uid = Uid;
                        AjaxSubmission(JSON.stringify(dataString), "/Setup/SetupEmailDelete", $('[name="__RequestVerificationToken"]').val()).done(function (data) {
                            let obj = data;
                            if (obj.status == true) {
                                if (obj.responsecode == '102') {
                                    Toast(RetrieveMessage(obj.responsecode), "Message", "success");
                                    FillSetupEmailList();
                                    SetupEmailReset();
                                }
                                else
                                    Toast(RetrieveMessage(obj.responsecode), "Message", "error");
                            }
                            else
                                window.location.href = '/ClientLogin/ClientLogin';
                        }).fail(function (data) {
                            console.log(data.Message);
                        });
                    }
                },
                close: function () {
                }
            }
        });
    }
    catch (e) {
        console.log(e.message);
    }
}

//SetupEmailReset BUTTON CLICKED EVENT
$('#SetupEmailReset').click(function () {
    SetupEmailReset();
});

//FUNCTION FOR RESET SETUP EMAIL
function SetupEmailReset() {
    $('#TimeStamp,#SetupUid,#ImapPopEmailId,#ImapPopEmailPassword,#IncomingMailServer,#IncomingPort,#FetchEmailId').val('');
    $('#IncomingSSL,#SaveEmail,#SaveAttachment').prop('checked', false);
    $('#Status').val(1);
    $('#SetupEmailAdd').removeClass('d-none');
    $('#SetupEmailUpdate').addClass('d-none');
}
