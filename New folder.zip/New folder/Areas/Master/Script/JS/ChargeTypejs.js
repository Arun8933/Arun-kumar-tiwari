﻿var Firstcolumn = "";

//DOCUMENT READY FUNCTION
$(document).ready(function () {
    Firstcolumn = "charges_type";
    FillPageSizeList('ddlPageSize', FormList);
    $("#ChargesTypeIdSearch").focus();
})

// CHARGES TYPE LIST PAGE INDEX
function FormList(pageindex) {
    try {
        const dataString = {};
        dataString.PageSize = $("#ddlPageSize").val();
        dataString.PageIndex = pageindex;
        dataString.ChargesTypeId = $("#ChargesTypeIdSearch").val();
        dataString.ChargesTypeName = $("#ChargesTypeNameSearch").val();
        dataString.OrderBy = $("#sort-column").val().trim() + " " + $("#sort-type").val().trim();

        //ShowLoader();

        AjaxSubmission(JSON.stringify(dataString), "/Master/ChargesType/FormList ", $('input[name=__RequestVerificationToken]').val()).done(function (result) {

            let obj = result;

            if (obj.status == true) {
                if (obj.responsecode == '100') {

                    var ser = ((parseInt(obj.data.Table1[0].PageIndex) - 1) * parseInt(obj.data.Table1[0].PageSize)) + 1;
                    BindFormTable(obj.data.Table, ser);

                    if (obj.data.Table1 != undefined && obj.data.Table1.length > 0) {
                        $(".pagination").BindPaging({
                            ActiveCssClass: "current",
                            PagerCssClass: "pager",
                            PageIndex: parseInt(obj.data.Table1[0].PageIndex),
                            PageSize: parseInt(obj.data.Table1[0].PageSize),
                            RecordCount: parseInt(obj.data.Table1[0].count)
                        });
                    }
                }
                else {
                    Toast(RetrieveMessage(obj.responsecode), "Message", "error");
                }
            }
            else {
                window.location.href = '/ClientLogin/ClientLogin';
            }

            //HideLoader();

        }).fail(function (result) {
            console.log(result.Message);
            //HideLoader();
        });
    }
    catch (e) {
        console.log(e.message);
        //HideLoader();
    }
}

// BIND  CHARGES TYPE TABLE
function BindFormTable(result, serial_no) {
    $("#tbl_ChargesType tbody tr").remove();

    if (result.length == 0) {
        tr = $('<tr/>');
        tr.append("<td class='text-center' colspan='9'>NO RESULTS FOUND</td>");
        $("#tbl_ChargesType tbody").append(tr);
    }
    else {
        for (i = 0; i < result.length; i++) {

            if (result[i].is_active == "Inactive")
                tr = $(' <tr style="background-color:#fdd2d2;"/>');

            else
                tr = $('<tr/>');
            tr.append("<td class='text-center'><button type='button' onclick='FormEdit(\"" + result[i].charges_type_uid + "\");' class= 'common-btn common-btn-sm'><i class='fa-solid fa-pen-to-square'></i></button ><button type='button' onclick='FormDelete(\"" + result[i].charges_type_uid + "\");' class='common-btn common-btn-sm ms-1'> <i class='fa-regular fa-trash-can'></i></button ></td > ");
            tr.append("<td class='text-left'>" + serial_no + "</td>");
            tr.append("<td class='text-left'>" + result[i].charges_type_uid + "</td>");
            tr.append("<td class='text-center'><a href='javascript:void(0)' class='text-decoration-none' style='color: black !important;' onclick='FormEdit(\"" + result[i].charges_type_uid + "\");'>" + result[i].charges_type + "</a></td>");

            serial_no++;

            $("#tbl_ChargesType tbody").append(tr);
        }
    }
}

//PAGINATION BUTTON PREVEIOUS NEXT CLICK
$(document).on("click", ".pagination .page", function () {
    FormList(($(this).attr('page')));
});
//PAGE SIZE CLICKED
$("#ddlPageSize").change(function () {
    FormList(1);
});

//SEARCH BUTTON CLICKED
$("#FormSearch").click(function () {
    FormList(1);
});

//FUNCTION FOR SORTING FIELD
function FormSorting(obj) {
    if (Firstcolumn != "") {
        document.getElementById(Firstcolumn).innerHTML = document.getElementById(Firstcolumn).getAttribute("data-column") + "<i style='margin-left:10px;' class='fa-solid fa-sort'></i>";
    }
    Firstcolumn = obj.id;
    let colname = $(obj).data("column");
    $("#sort-column").val(Firstcolumn);
    let sorttype = $("#sort-type").val();
    if (sorttype == "ASC") {
        $("#sort-type").val("DESC");
        $(obj).html(colname + "<i style='margin-left:10px;' class='fa-solid fa-sort-down'></i>");
    } else if (sorttype == "DESC") {
        $("#sort-type").val("ASC");
        $(obj).html(colname + "<i style='margin-left:10px;' class='fa-solid fa-sort-up'></i>");
    }
    FormList(1);
}

//ADD BUTTON CLICK FUNCTION 
$("#FormAdd").click(function () {
    RemoveAllError('ChargesType');
    ValidateAllFieldNewTest('ChargesType');
    if (Ercount == 0)
        FormAdd();
});

//FUNCTION FOR ADD  CHARGES TYPE
function FormAdd() {
    try {
        debugger;
        const dataString = {};
        dataString.ChargesTypeName = $("#ChargesTypeName").val().trim();
        //ShowLoader();

        AjaxSubmission(JSON.stringify(dataString), "/Master/ChargesType/FormAdd", $('input[name=__RequestVerificationToken]').val()).done(function (result) {

            let obj = result;
            if (obj.status == true) {
                if (obj.responsecode == '101') {

                    Toast(RetrieveMessage(obj.responsecode), "Message", "success");
                    setTimeout(FormList(1), 500);
                    $("#ChargesType-tab").html("Edit CFS Charges");
                    $("#FormAdd").hide();
                    $("#FormUpdate").show();
                    $("#FormReset").show();
                    $("#ChargesTypeId").val(obj.data.Table[0].charges_type_uid);
                    $("#Timestamp").val(obj.data.Table[0].timestamp);

                }
                else {
                    Toast(RetrieveMessage(obj.responsecode), "Message", "error");
                }
            }
            else {
                window.location.href = '/ClientLogin/ClientLogin';
            }

            //HideLoader();
        }).fail(function (result) {
            console.log(result.Message);

            //HideLoader();
        });
    }
    catch (e) {
        console.log(e.message);

        //HideLoader();
    }
}

//FUNCTION FOR EDIT  CHARGES TYPE
function FormEdit(ChargesTypeId) {
    try {
        const dataString = {};

        dataString.ChargesTypeId = parseInt(ChargesTypeId);
        //ShowLoader();
        AjaxSubmission(JSON.stringify(dataString), "/Master/ChargesType/FormEdit", $('[name="__RequestVerificationToken"]').val()).done(function (data) {
            let obj = data;

            if (obj.status == true) {
                if (obj.responsecode == '100') {
                    TabShow();
                    $("#ChargesTypeId").val(obj.data.Table[0].charges_type_uid);
                    $("#Timestamp").val(obj.data.Table[0].timestamp);
                    $("#ChargesTypeName").val(obj.data.Table[0].charges_type);

                }
                else {
                    Toast(RetrieveMessage(obj.responsecode), "Message", "error");
                }
            }
            else {
                window.location.href = '/ClientLogin/ClientLogin';
            }
            //HideLoader();
        }).fail(function (data) {
            console.log(data.Message);
            //HideLoader();
        });
    }
    catch (e) {
        console.log(e.message);
        //HideLoader();
    }
}

$("#FormUpdate").click(function () {

    RemoveAllError('ChargesType');
    ValidateAllFieldNewTest('ChargesType');
    if (Ercount == 0)
        FormUpdate();
});

//FUNCTION FOR UPDATE  CHARGES TYPE
function FormUpdate() {
    try {
        const dataString = {};
        dataString.ChargesTypeName = $("#ChargesTypeName").val().trim();
        dataString.ChargesTypeId = $("#ChargesTypeId").val();
        dataString.timestamp = $("#Timestamp").val();

        //ShowLoader();
        AjaxSubmission(JSON.stringify(dataString), "/Master/ChargesType/FormUpdate", $('input[name=__RequestVerificationToken]').val()).done(function (result) {

            let obj = result;
            if (obj.status == true) {
                if (obj.responsecode == '107') {

                    Toast(RetrieveMessage(obj.responsecode), "Message", "success");
                    setTimeout(FormList(1), 500);
                    $("#ChargesTypeId").val(obj.data.Table[0].charges_type_uid);
                    $("#Timestamp").val(obj.data.Table[0].timestamp);
                    //ResetForm();
                    //TabHide();
                }
                else {
                    Toast(RetrieveMessage(obj.responsecode), "Message", "error");
                }
            }
            else {
                window.location.href = '/ClientLogin/ClientLogin';
            }

            //HideLoader();
        }).fail(function (result) {
            console.log(result.Message);
            //HideLoader();
        });
    }
    catch (e) {
        console.log(e.message);
        //HideLoader();
    }
}

//FUNCTION FOR DELETE  CHARGES TYPE
function FormDelete(e) {
    try {
        $.confirm({
            title: '',
            content: 'Are You Sure Want To Delete ?',
            type: 'red',
            boxWidth: '300px',
            useBootstrap: false,
            columnClass: 'small',
            containerFluid: true,
            typeAnimated: true,
            buttons: {
                tryAgain: {
                    text: 'Confirm',
                    btnClass: 'btn-red',
                    action: function () {

                        const datastring = {};
                        datastring.ChargesTypeId = parseInt(e);
                        //ShowLoader();
                        AjaxSubmission(JSON.stringify(datastring), "/Master/ChargesType/FormDelete", $('[name="__RequestVerificationToken"]').val()).done(function (data) {
                            let obj = data;
                            if (obj.status == true) {
                                if (obj.responsecode == '102') {
                                    Toast(RetrieveMessage(obj.responsecode), "Message", "success");
                                    FormList(1);
                                }
                                else {
                                    Toast(RetrieveMessage(obj.responsecode), "Message", "error");
                                }
                            }
                            else {
                                window.location.href = 'ClientLogin/ClientLogin';
                            }
                            //HideLoader();
                        }).fail(function (data) {
                            console.log(data.Message);
                            //HideLoader();
                        });
                    }
                },
                close: function () {
                    //HideLoader();
                }
            }
        });
    }
    catch (e) {
        console.log(e.message);
        //HideLoader();
    }
}

//FUNCTION FOR REST INPUT TYPE FIELD
function ResetForm() {
    $("#ChargesTypeName").val("");
    $("#ChargesTypeName").removeClass('error-textbox');
    $("#ChargesTypeNameError").html("");
    $("#FormAdd").show();
    $("#FormUpdate").hide();
    $("#FormReset").hide();
    $("#ChargesType-tab").html("Add CFS Charges");
    $("#ChargesTypeId").val('');
    $("#Timestamp").val('');
};

//FUCNTION FOR TAB SHOW
function TabShow() {
    $('#ChargesType_list-tab').removeClass('active');
    $('#ChargesType-tab').addClass('active');
    $('#ChargesType_list').removeClass('active show');
    $('#ChargesType').addClass('active show');
    $("#FormAdd").hide();
    $("#FormUpdate").show();
    $("#FormReset").show();
    $("#ChargesType-tab").html("Edit CFS Charges");
}

//FUNCTION FOR TAB HIDE
function TabHide() {
    $('#ChargesType-tab').removeClass('active');
    $('#ChargesType_list-tab').addClass('active ');
    $('#ChargesType_list').addClass('active show');
    $('#ChargesType').removeClass('active show');
    $("#FormAdd").show();
    $("#FormUpdate").hide();
    $("#FormReset").hide();
    $("#ChargesType-tab").html("Add CFS Charges");
}

//MENU LIST TAB CLICKED
$("#ChargesType_list-tab").click(function () {
    RemoveAllError('ChargesType');
    ResetForm();
    TabHide();
})

//FUNCTION FOR GET DEFAULT PAGE
function FillDefaultPage() {
    try {

        //ShowLoader();
        AjaxSubmission(null, "/Master/ChargesType/GetDefaultPageSize", $('input[name=__RequestVerificationToken]').val()).done(function (data) {
            let obj = data;
            if (obj.status == true) {
                $("#ddlPageSize").val(obj.data.Table[0].DefaultPageSize);
                setTimeout(FormList(1), 2000);

            }
            else {
                window.location.href = '/ClientLogin/ClientLogin';
            }
            //HideLoader();

        }).fail(function (result) {
            console.log(result.Message);
            //HideLoader();
        });
    }
    catch (e) {
        console.log(e.message);
        //HideLoader();
    }
}
$(".ChargesType_list").click(function () {
    $("#ChargesTypeIdSearch").focus();

});

$("#FormReset").click(function () {
    ResetForm();
})

document.addEventListener("keydown", function (zEvent) {
    if (zEvent.ctrlKey && zEvent.altKey && (zEvent.key == "j" || zEvent.key == "J")) {
        $('#ChargesType_list-tab').removeClass('active ');
        $('#ChargesType_list').removeClass('active show');
        $('#ChargesType-tab').addClass('active');
        $('#ChargesType').addClass('active show');
        $("#FormAdd").show();
        $("#FormUpdate").hide();
        $("#FormReset").hide();
        $("#ChargesType-tab").html("Add CFS Charges  ");
        ResetForm();
        $('#ChargesTypeName').focus();
    }
});
