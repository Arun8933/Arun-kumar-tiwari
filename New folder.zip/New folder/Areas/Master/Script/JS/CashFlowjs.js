﻿var DateFrom = "";
var DateTo = "";
var Count;
// DOCUMENT ON READY FUNCTION
$(document).ready(function () {
    GetFinancialYearDate();
    $(".datepickerAll").datepicker({
        changeMonth: true,
        changeYear: true,
        dateFormat: 'dd/mm/yy'
    });
    FillBranchList('SelectBranch', false);
    $("#SelectBranch").select2({
        width: '100%'
    });
    $("#ReportBySearch").select2({
        width: '100%'
    });
    $("#GroupSearch").select2({
        width: '100%'
    });
    //DATEPICKER FOR SEARCHJOBDATEFROM AND SEARCHJOBDATETO
    $('#SearchDateFrom,#SearchDateTo').datepicker({
        toolbarPlacement: "bottom",
        showButtonPanel: true,
        changeMonth: true,
        changeYear: true,
        dateFormat: 'dd/mm/yy',
        onClose: function () {
            if ($('#SearchDateFrom').val().length == 10 || $('#SearchDateTo').val().length == 10)
                CompareSearchDate($('#SearchDateFrom').val(), $('#SearchDateTo').val(), 'SearchDate');
        }
    });
    FillPageSizeList('ddlPageSize');

    FillGroup('GroupSearch');

})


//FUNCTION FOR GET FINANCIAL YEAR DATE
function GetFinancialYearDate() {
    try {
        AjaxSubmission(null, '/_Layout/GetFinancialYearDate', $('[name="__RequestVerificationToken"]').val()).done(function (result) {
            let obj = result;
            console.log(obj)
            if (obj.status == true) {
                if (obj.responsecode == '100') {
                    $("#SearchDateFrom").val(obj.data.Table[0].finyr_start_date);
                    $("#SearchDateTo").val(obj.data.Table[0].finyr_end_date);
                }
            }
            else
                window.location.href = '/ClientLogin/ClientLogin';
            HideLoader();
        }).fail(function (result) {
            HideLoader();
            console.log(result.message);
        });
        HideLoader();
    }
    catch (e) {
        HideLoader();
        console.log(e.message);
    }
}

//SEARCH ARROW UP/DOWN
$("#Arrow").click(function () {
    if (srbtn == 'up') {
        $("#icn").html("<i class='fa-solid fa-angle-down'></i>");
        srbtn = 'down';
    } else {
        $("#icn").html("<i class='fa-solid fa-angle-up'></i>");
        srbtn = 'up';
    }
});

$("#AccHeadSearch").autocomplete({
    source: function (request, response) {
        $.ajax({
            type: 'POST',
            url: "/Master/CashFlow/SearchAccHeadNameList",
            dataType: "json",
            async: false,
            data: {
                AccDescription: request.term, GroupUid: $("#GroupSearch").val()
            },
            success: function (result) {
                response($.map(result.data.Table, function (LedgerName) {
                    return {
                        label: LedgerName.AccHead,
                        value: LedgerName.AccHead,
                        id: LedgerName.ledgeruid,
                        LedgerGroup: LedgerName.LedgerGroup,
                    }
                }));
            },
            error: function (response) {
                console.log(response.responseText);
            }
        });
    },
    autoFocus: true,
    minLength: 1,
    selectFirst: true,
    selectOnly: true,
    select: function (e, i) {
        $("#HiddenLedgerId").val(i.item.id);
        $("#GroupSearch").val(i.item.LedgerGroup);
    },

});


//FUNCTION FOR FILL GROUP
function FillGroup(DrpID) {
    try {
        //Showloader();
        AjaxSubmission(null, "/CashFlow/FillGroup", $('input[name=__RequestVerificationToken]').val()).done(function (data) {
            let obj = data;
            if (obj.status == true) {
                if (obj.responsecode == '100')
                    BindDropdown(obj.data.Table, DrpID, 'SubgroupHeadUid', 'SubgroupHeadName', '---Select---');
                else if (obj.responsecode == '100')
                    BindDropdown(obj.data.Table, DrpID, 'SubgroupHeadUid', 'SubgroupHeadName', '---Select---');
                else
                    Toast(RetrieveMessage(obj.responsecode), "Message", "error");
            }
            else
                window.location.href = '/ClientLogin/ClientLogin';
            //Hideloader();
        }).fail(function (result) {
            console.log(result.Message);
            //Hideloader();
        });
    }
    catch (e) {
        console.log(e.message);
        //Hideloader();
    }
}


$('#ReportBySearch').on('change', function () {
    if ($('#ReportBySearch').val() == 1) {
        $("#acchide").show();
    }
    else {
        $("#acchide").hide();
        $("#HiddenLedgerId").val('');

    }
});

$("#FormSearch").click(function () {
    var FromDate = $("#SearchDateFrom").val();
    var ToDate = $("#SearchDateTo").val();
    var ReportBySearch = $('#ReportBySearch').val();
    var HiddenLedgerId = $('#HiddenLedgerId').val();

    if ($('#SearchDateFrom').val().length == 10 || $('#SearchDateTo').val().length == 10)
        CompareSearchDate($('#SearchDateFrom').val(), $('#SearchDateTo').val(), '');
    var flag = 0;
    if ($("#GroupSearch").val() == "0") {
        Toast("Please Select Account Group !", 'Message', 'error');
        return false;
    }

    if ((ReportBySearch == "1") && (HiddenLedgerId == "0")) {
        Toast("Please Select Account Head !", 'Message', 'error');
        return false;
    }
    if (FromDate == "") {
        Toast("Please Enter Date From", "Message", "error");
        flag = 1;
        return false;
    }
    if (ToDate == "") {
        Toast("Please Enter Date To", "Message", "error");
        flag = 1;
        return false;
    }
    if (FromDate >= ToDate) {
        Toast("To Date Must Be Greater Than From Date*", "Message", "error");
        flag = 1;
        return false;
    }
    else {
        var type = $("#ReportBySearch").val();
        if (type == "0") {
            $(".ReportDNone").show();
            $("#tbl_cashFlow").show();
            $("#tbl_cashFlow1").hide();
        }
        else if (type == "1") {
            $(".ReportDNone").show();
            $("#tbl_cashFlow").hide();
            $("#tbl_cashFlow1").show();
        }
        FormList();
    }
});



//FUNCTION FOR FILL PROFIT LOSS STATEMENT
function FormList() {
    try {
        const dataString = {};
        dataString.FromDate = $("#SearchDateFrom").val();
        dataString.ToDate = $("#SearchDateTo").val();
        dataString.BranchUid = $("#SelectBranch").val();
        dataString.ReportBy = $("#ReportBySearch").val();
        dataString.GroupUid = $("#GroupSearch").val();
        dataString.LedgerUid = $("#HiddenLedgerId").val();
        ShowLoader();
        AjaxSubmission(JSON.stringify(dataString), "/Master/CashFlow/FormList", $('input[name=__RequestVerificationToken]').val()).done(function (result) {
            let obj = result;
            console.log(obj);
            if (obj.status == true) {
                if (obj.responsecode == '100') {

                    BindFormTable(obj.data.Table, obj.data.Table1[0].ReportBy);
                }
                else
                    Toast(RetrieveMessage(obj.responsecode), "Message", "error");
            }
            else
                window.location.href = '/ClientLogin/ClientLogin';
            HideLoader();
        }).fail(function (result) {
            console.log(result.Message);
            HideLoader();
        });
    }
    catch (e) {
        console.log(e.message);
        HideLoader();
    }
}


//FUNCTION FOR BIND LETTER LIST TABLE
function BindFormTable(Result, ReportBy) {

    if (ReportBy == '0') {
        $("#tbl_cashFlow tbody tr").remove();
        if (Result.length == 0) {
            $("#ShowPdf").hide();
            tr = $('<tr/>');
            tr.append("<td class='text-center' colspan='8'>NO RESULTS FOUND</td>");
            $("#tbl_cashFlow tbody").append(tr);

        }
        else {
            $("#ShowPdf").show();
            var debit = 0.00;
            var credit = 0.00;
            for (i = 0; i < Result.length; i++) {
                tr = $('<tr/>');
                tr.append("<td class='text-center ' >" + (i + 1) + "</td>")
                tr.append("<td class='text-center ' >" + Result[i].SubgroupHeadName + "</td>")
                tr.append("<td class='text-end ' >" + Result[i].OutFlow.toFixed(2) + "</td>")
                tr.append("<td class='text-end ' >" + Result[i].InFlow.toFixed(2) + "</td>")
                $("#tbl_cashFlow tbody").append(tr);
                debit += Result[i].OutFlow;
                credit += Result[i].InFlow;
            }

            tr = $('<tr/>');
            tr.append("<td align='Right' colspan='2'> <span style='font-weight:bold;'>Total :</span></td>");
            tr.append("<td class='text-end ' ><b>" + parseFloat(debit).toFixed(2) + "</b></td>")
            tr.append("<td class='text-end ' ><b>" + parseFloat(credit).toFixed(2) + "</b></td>")
            $("#tbl_cashFlow tbody").append(tr);

            var NetFlow = debit - credit;
            tr = $('<tr/>');
            tr.append("<td align='Right' colspan='3'> <span style='font-weight:bold;'>Net Flow :</span></td>");
            tr.append("<td class='text-end ' ><b>" + parseFloat(NetFlow).toFixed(2) + "</b></td>")
            $("#tbl_cashFlow tbody").append(tr);
        }
    }

    else {
        $("#tbl_cashFlow1 tbody tr").remove();
        if (Result.length == 0) {
            $("#ShowPdf").hide();
            tr = $('<tr/>');
            tr.append("<td class='text-center' colspan='8'>NO RESULTS FOUND</td>");
            $("#tbl_cashFlow1 tbody").append(tr);

        }
        else {
            $("#ShowPdf").show();
            var debit = 0.00;
            var credit = 0.00;
            for (i = 0; i < Result.length; i++) {
                tr = $('<tr/>');
                tr.append("<td class='text-center ' >" + (i + 1) + "</td>")
                tr.append("<td class='text-center ' >" + Result[i].RefNo + "</td>")
                tr.append("<td class='text-center ' >" + Result[i].AccHead + "</td>")
                tr.append("<td class='text-end ' >" + Result[i].OutFlow.toFixed(2) + "</td>")
                tr.append("<td class='text-end ' >" + Result[i].InFlow.toFixed(2) + "</td>")
                $("#tbl_cashFlow1 tbody").append(tr);
                debit += Result[i].OutFlow;
                credit += Result[i].InFlow;
            }
            tr = $('<tr/>');
            tr.append("<td align='Right' colspan='3'> <span style='font-weight:bold;'>Total :</span></td>");
            tr.append("<td class='text-end ' ><b>" + parseFloat(debit).toFixed(2) + "</b></td>")
            tr.append("<td class='text-end ' ><b>" + parseFloat(credit).toFixed(2) + "</b></td>")
            $("#tbl_cashFlow1 tbody").append(tr);

            var NetFlow = debit - credit;
            tr = $('<tr/>');
            tr.append("<td align='Right' colspan='4'> <span style='font-weight:bold;'>Net Flow :</span></td>");
            tr.append("<td class='text-end ' ><b>" + parseFloat(NetFlow).toFixed(2) + "</b></td>")
            $("#tbl_cashFlow1 tbody").append(tr);
        }
    }

}


//ON CLICK FUNCTION FOR PDF
$("#CashFlowPDF").click(function () {
    try {
        const dataString = {};
        dataString.FromDate = $("#SearchDateFrom").val();
        dataString.ToDate = $("#SearchDateTo").val();
        dataString.BranchUid = $("#SelectBranch").val();
        dataString.ReportBy = $("#ReportBySearch").val();
        dataString.GroupUid = $("#GroupSearch").val();
        dataString.LedgerUid = $("#HiddenLedgerId").val();
        ShowLoader();
        AjaxSubmission(JSON.stringify(dataString), "/Master/CashFlow/CashFlowReport", $('input[name=__RequestVerificationToken]').val()).done(function (result) {
            let obj = result;
            console.log(obj);
            if (obj.status == true) {
                if (obj.responsecode == '100') {
                    window.open($("#MyReport").attr('href'), '_blank');
                }
                else
                    Toast(RetrieveMessage(obj.responsecode), "Message", "error");
            }
            else
                window.location.href = '/ClientLogin/ClientLogin';
            HideLoader();
        }).fail(function (result) {
            console.log(result.Message);
            HideLoader();
        });
    }
    catch (e) {
        console.log(e.message);
        HideLoader();
    }
});

//FUNCTION FOR EXPORT DATA IN EXCEL
function FormExcel() {
    debugger;
    ShowLoader();
    let date = new Date();
    let NewDate = ("00" + date.getDate()).slice(-2) + "_" + ("00" + (date.getMonth() + 1)).slice(-2) + "_" + date.getFullYear() + "_" + ("00" + date.getHours()).slice(-2) + "_" + ("00" + date.getMinutes()).slice(-2) + "_" + ("00" + date.getSeconds()).slice(-2);
    let fileName = "CashFlow_" + NewDate + ".xlsx";

    $('#FormSearch').trigger('click');
    AjaxSubmission(null, '/Master/CashFlow/FormExcel', $('input[name=__RequestVerificationToken]').val()).done(function (result) {
        let obj = result;
        if (obj.status == true) {
            if (obj.responsecode == '100') {

                let bytes = Base64ToBytes(obj.data.FileData[0].Base64Data);
                let blob = new Blob([bytes], { type: "application/octetstream" });
                let isIE = false || !!document.documentMode;
                if (isIE) {
                    window.navigator.msSaveBlob(blob, fileName);
                } else {
                    let url = window.URL || window.webkitURL;
                    link = url.createObjectURL(blob);
                    let a = $("<a />");
                    a.attr("download", fileName);
                    a.attr("href", link);
                    $("body").append(a);
                    a[0].click();
                    $("body").remove(a);
                }
            }
            else if (obj.responsecode == '302')
                Toast('No Records found.', 'Message', 'success');
            else
                Toast(RetrieveMessage(obj.responsecode), 'Message', 'error');

        } else
            window.location.href = '/ClientLogin/ClientLogin';
        HideLoader();

    }).fail(function (result) {
        console.log(result.Message);
        HideLoader();
    });
}
