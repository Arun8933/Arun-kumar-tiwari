﻿var Firstcolumn = "";


if (Get_Cookie("UserGroupId") != null) {
    ShowLoader();
    var a = setInterval(() => {
        if ($("#GroupId").val() != null) {
            if (Get_Cookie("UserGroupId") != '' && Get_Cookie("UserGroupId") != 0) {
                FormEdit(Get_Cookie("UserGroupId"));
            } else {
                $('#UserGroup_list-tab').removeClass('active');
                $('#UserGroup-tab').addClass('active');
                $('#UserGroup_list').removeClass('active show');
                $('#UserGroup').addClass('active show');
                $("#FormAdd").show();
                $("#FormUpdate").hide();
                $("#UserGroup-tab").html("Add User Group");
            }
            HideLoader();
            EraseCookie('UserGroupId');
            clearInterval(a);
        }
    }, 1000);
}

$(document).on("click", ".pagination .page", function () {
    FormList(($(this).attr('page')));
});



//PAGE SIZE CLICKED
$("#ddlPageSize").change(function () {
    FormList(1);
});

//SEARCH BUTTON CLICKED
$("#FormSearch").click(function () {
    FormList(1);
});

$(document).ready(function () {
    ShowLoader();
    FillPageSizeList('ddlPageSize', FormList);
    $("#GroupIdSearch").focus();
    HideLoader();
})

$("#FormAdd").click(function () {
    RemoveAllError('UserGroup');
    ValidateAllFieldNewTest('UserGroup');
    if (Ercount == 0) {
        FormAdd();
    }
});

// BIND USER GROUP TABLE

function BindFormTable(result, serial_no) {
    $("#tbl_UserGroup tbody tr").remove();

    if (result.length == 0) {
        tr = $('<tr/>');
        tr.append("<td class='text-center' colspan='9'>NO RESULTS FOUND</td>");
        $("#tbl_UserGroup tbody").append(tr);
    }
    else {
        for (i = 0; i < result.length; i++) {
            if (result[i].is_active == "Inactive")
                tr = $(' <tr style="background-color:#fdd2d2;"/>');
            else
                tr = $('<tr/>'); 

            tr.append("<td class='text-center'><button type='button' onclick='FormEdit(\"" + result[i].UserGroupUid + "\");' class= 'common-btn common-btn-sm'><i class='fa-solid fa-pen-to-square'></i></button ><button type='button' onclick='FormDelete(\"" + result[i].UserGroupUid + "\");' class= 'common-btn common-btn-sm ms-1'> <i class='fa-regular fa-trash-can'></i></button ></td > ");
            tr.append("<td class='text-left'>" + serial_no + "</td>");
            tr.append("<td class='text-left'>" + result[i].UserGroupUid + "</td>");           

            tr.append("<td class='text-center'><a href='javascript:void(0)' class='text-decoration-none' style='color: black !important;' onclick='FormEdit(\"" + result[i].UserGroupUid + "\");'>" + result[i].UserGroupName + "</a></td>");

          

            serial_no++;

            $("#tbl_UserGroup tbody").append(tr);

        }

    }
}
//INVOICE TYPE LIST PAGE INDEX
function FormList(pageindex) {
    try {
        const dataString = {};
        dataString.PageSize = $("#ddlPageSize").val();
        dataString.PageIndex = pageindex;
        dataString.GroupId = $("#GroupIdSearch").val();
        dataString.GroupName = $("#GroupNameSearch").val();
        dataString.OrderBy = $("#sort-column").val().trim() + " " + $("#sort-type").val().trim();
        //ShowLoader();
        AjaxSubmission(JSON.stringify(dataString), "/Master/UserGroup/FormList", $('input[name=__RequestVerificationToken]').val()).done(function (result) {
            let obj = result;
            if (obj.status == true) {
                if (obj.responsecode == '100') {
                    var ser = ((parseInt(obj.data.Table1[0].PageIndex) - 1) * parseInt(obj.data.Table1[0].PageSize)) + 1;
                    BindFormTable(obj.data.Table, ser);
                    if (obj.data.Table1 != undefined && obj.data.Table1.length > 0) {
                        $(".pagination").BindPaging({
                            ActiveCssClass: "current",
                            PagerCssClass: "pager",
                            PageIndex: parseInt(obj.data.Table1[0].PageIndex),
                            PageSize: parseInt(obj.data.Table1[0].PageSize),
                            RecordCount: parseInt(obj.data.Table1[0].count)
                        });
                    }
                }
                else {
                    Toast(RetrieveMessage(obj.responsecode), "Message", "error");
                }
            }
            else {
                window.location.href = '/ClientLogin/ClientLogin';
            }
            //HideLoader();
        }).fail(function (result) {
            console.log(result.Message);
            //HideLoader();
        });
    }
    catch (e) {
        console.log(e.message);
        //HideLoader();
    }
}

//FUNCTION FOR SORTING FIELD
function Sorting(obj) {

    if (Firstcolumn != "") {
        document.getElementById(Firstcolumn).innerHTML = document.getElementById(Firstcolumn).getAttribute("data-column") + " <i class='fa-solid fa-sort'></i>";
    }
    Firstcolumn = obj.id;
    var colname = $(obj).data("column");
    $("#sort-column").val(Firstcolumn);
    var sorttype = $("#sort-type").val();
    if (sorttype == "ASC") {
        $("#sort-type").val("DESC");
        $(obj).html(colname + " <i style='margin-left:10px;' class='fa-solid fa-sort-up'></i>");
    } else if (sorttype == "DESC") {
        $("#sort-type").val("ASC");
        $(obj).html(colname + " <i style='margin-left:10px;' class='fa-solid fa-sort-down'></i>");
    }

    FormList(1);
}

//FUNCTION FOR EXPORT DATA IN EXCEL
function FormExcel() {
    ShowLoader();
    let date = new Date();
    let NewDate = ("00" + date.getDate()).slice(-2) + "_" + ("00" + (date.getMonth() + 1)).slice(-2) + "_" + date.getFullYear() + "_" + ("00" + date.getHours()).slice(-2) + "_" + ("00" + date.getMinutes()).slice(-2) + "_" + ("00" + date.getSeconds()).slice(-2);
    let fileName = "UserGroup_" + NewDate + ".xlsx";

    $('#FormSearch').trigger('click');
    AjaxSubmission(null, '/Master/UserGroup/FormExcel', $('input[name=__RequestVerificationToken]').val()).done(function (result) {
        let obj = result;
        if (obj.status == true) {
            if (obj.responsecode == '100') {

                let bytes = Base64ToBytes(obj.data.FileData[0].Base64Data);
                let blob = new Blob([bytes], { type: "application/octetstream" });
                let isIE = false || !!document.documentMode;
                if (isIE) {
                    window.navigator.msSaveBlob(blob, fileName);
                } else {
                    let url = window.URL || window.webkitURL;
                    link = url.createObjectURL(blob);
                    let a = $("<a />");
                    a.attr("download", fileName);
                    a.attr("href", link);
                    $("body").append(a);
                    a[0].click();
                    $("body").remove(a);
                }
            }
            else if (obj.responsecode == '302')
                Toast("No Records found.", 'Message', 'success');
            else
                Toast(RetrieveMessage(obj.responsecode), 'Message', 'error');

        } else
            window.location.href = '/ClientLogin/ClientLogin';
        HideLoader();

    }).fail(function (result) {
        console.log(result.Message);
        HideLoader();
    });
}

//FUNCTION FOR USER GROUP TYPE
function FormAdd() {
    try {
        const dataString = {};
        dataString.GroupName = $("#GroupName").val().trim();
        ShowLoader();
        AjaxSubmission(JSON.stringify(dataString), "/Master/UserGroup/FormAdd", $('input[name=__RequestVerificationToken]').val()).done(function (result) {
            let obj = result;
            if (obj.status == true) {
                if (obj.responsecode == '101') {
                    Toast(RetrieveMessage(obj.responsecode), "Message", "success");
                    setTimeout(FormList(1), 500);                   
                    $("#FormAdd").hide();
                    $("#FormUpdate").show();
                    $("#FormReset").show();
                    $("#UserGroup-tab").html("Edit User Group");
                }
                else {
                    Toast(RetrieveMessage(obj.responsecode), "Message", "error");
                }
            }
            else {
                window.location.href = '/ClientLogin/ClientLogin';
            }
            HideLoader();
        }).fail(function (result) {
            console.log(result.Message);
            HideLoader();
        });
    }
    catch (e) {
        console.log(e.message);
        HideLoader();
    }
}


//FUNCTION FOR EDIT USER GROUP TYPE
function FormEdit(e) {
    try {
        const dataString = {};
        dataString.GroupId = (e);
        ShowLoader();
        AjaxSubmission(JSON.stringify(dataString), "/Master/UserGroup/FormEdit", $('[name="__RequestVerificationToken"]').val()).done(function (data) {
            let obj = data;
            if (obj.status == true) {
                if (obj.responsecode == '100') {
                    TabShow();
                    $("#GroupId").val(obj.data.Table[0].UserGroupUid);
                    $("#GroupName").val(obj.data.Table[0].UserGroupName);
                    $("#timestamp").val(obj.data.Table[0].timestamp);
                }
                else {
                    Toast(RetrieveMessage(obj.responsecode), "Message", "error");
                }
            }
            else {
                window.location.href = '/ClientLogin/ClientLogin';
            }
            HideLoader();
        }).fail(function (data) {
            console.log(data.Message);
            HideLoader();
        });
    }
    catch (e) {
        console.log(e.message);
        HideLoader();
    }
}




$("#FormUpdate").click(function () {
    RemoveAllError('UserGroup');
    ValidateAllFieldNewTest('UserGroup');
    if (Ercount == 0) {
        FormUpdate();
    }

});


//FUNCTION FOR USER GROUP TYPE 
function FormUpdate() {
    try {
        const dataString = {};
        dataString.GroupId = $("#GroupId").val();
        dataString.timestamp = $("#timestamp").val();
        dataString.GroupName = $("#GroupName").val().trim();
        ShowLoader();
        AjaxSubmission(JSON.stringify(dataString), "/Master/UserGroup/FormUpdate", $('input[name=__RequestVerificationToken]').val()).done(function (result) {
            let obj = result;
            if (obj.status == true) {
                if (obj.responsecode == '107') {
                    Toast(RetrieveMessage(obj.responsecode), "Message", "success");
                    setTimeout(FormList(1), 500);                    
                }
                else {
                    Toast(RetrieveMessage(obj.responsecode), "Message", "error");
                }
            }
            else {
                window.location.href = '/ClientLogin/ClientLogin';
            }
            HideLoader();
        }).fail(function (result) {
            console.log(result.Message);
            HideLoader();
        });
    }
    catch (e) {
        console.log(e.message);
        HideLoader();
    }

}



//FUNCTION FOR DELETE USER GROUP TYPE
function FormDelete(e) {
    try {
        $.confirm({
            title: '',
            content: 'Are You Sure Want To Delete ?',
            type: 'red',
            boxWidth: '300px',
            useBootstrap: false,
            columnClass: 'small',
            containerFluid: true,
            typeAnimated: true,
            buttons: {
                tryAgain: {
                    text: 'Confirm',
                    btnClass: 'btn-red',
                    action: function () {

                        const datastring = {};
                        datastring.GroupId = parseInt(e);
                        ShowLoader();
                        AjaxSubmission(JSON.stringify(datastring), "/Master/UserGroup/FormDelete", $('[name="__RequestVerificationToken"]').val()).done(function (data) {
                            let obj = data;
                            if (obj.status == true) {
                                if (obj.responsecode == '102') {
                                    Toast(RetrieveMessage(obj.responsecode), "Message", "success");
                                    FormList(1);

                                }
                                else {
                                    Toast(RetrieveMessage(obj.responsecode), "Message", "error");
                                }
                            }
                            else {
                                window.location.href = 'ClientLogin/ClientLogin';
                            }
                            HideLoader();
                        }).fail(function (data) {
                            console.log(data.Message);
                            HideLoader();
                        });
                    }
                },
                close: function () {
                  
                }
            }
        });
    }
    catch (e) {
        console.log(e.message);
        HideLoader();
    }
}

//FUNCTION FOR REST INPUT TYPE FIELD
function ResetForm() {
    $("#GroupName").val("");
    $("#GroupId").val("");
    $("#FormAdd").show();
    $("#FormUpdate").hide();
    $("#FormReset").hide();
    $("#UserGroup-tab").html("Add User Group");
};


//FUCNTION FOR TAB SHOW
function TabShow() {
    $('#UserGroup_list-tab').removeClass('active');
    $('#UserGroup-tab').addClass('active');
    $('#UserGroup_list').removeClass('active show');
    $('#UserGroup').addClass('active show');
    $("#FormAdd").hide();
    $("#FormUpdate").show();
    $("#FormReset").show();
    $("#UserGroup-tab").html("Edit User Group");
}

//FUNCTION FOR TAB HIDE
function TabHide() {
    $('#UserGroup-tab').removeClass('active');
    $('#UserGroup_list-tab').addClass('active ');
    $('#UserGroup_list').addClass('active show');
    $('#UserGroup').removeClass('active show');
    $("#FormAdd").show();
    $("#FormUpdate").hide();
    $("#FormReset").hide();
    $("#UserGroup-tab").html("Add User Group");
}

//USER GROUP LIST TAB CLICKED
$("#UserGroup_list-tab").click(function () {
    RemoveAllError('UserGroup');
    ResetForm();
})
$(".UserGroup_list").click(function () {
    $("#GroupIdSearch").focus();
})
$("#FormReset").click(function () {
    ResetForm();
})

document.addEventListener("keydown", function (zEvent) {
    if (zEvent.ctrlKey && zEvent.altKey && (zEvent.key == "j" || zEvent.key == "J")) {
        $('#UserGroup_list-tab').removeClass('active ');
        $('#UserGroup_list').removeClass('active show');
        $('#UserGroup-tab').addClass('active');
        $('#UserGroup').addClass('active show');
        $("#FormAdd").show();
        $("#FormUpdate").hide();
        $("#UserGroup-tab").html("Add User Group ");
        $('#GroupName').focus();
        ResetForm();
    }
});