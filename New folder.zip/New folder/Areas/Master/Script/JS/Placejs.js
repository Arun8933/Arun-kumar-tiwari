﻿
var Ercount = 0;
var Firstcolumn = "";
if (Get_Cookie("PlaceId") != null) {
    var a = setInterval(() => {
        if (Get_Cookie("PlaceId") != '' && Get_Cookie("PlaceId") != 0) {
            FormEdit(Get_Cookie("PlaceId"));
        } else {
            $('#Place_list-tab').removeClass('active');
            $('#Place-tab').addClass('active');
            $('#Place_list').removeClass('active show');
            $('#Place').addClass('active show');
            $("#FormAdd").show();
            $("#FormUpdate").hide();
            $("#Place-tab").html("Add Place");
        }
        EraseCookie('PlaceId');
        clearInterval(a);

    }, 100);
}



// DOCUMENT READY
$(document).ready(function () {
    Firstcolumn = "Port_Code";
    FillCountryListWithCode('CountryCode');

    if (Get_Cookie("PlaceId") == null) {
        FillPageSizeList('ddlPageSize', FormList);
    }
    else {
        FillPageSizeList('ddlPageSize');
        HideLoader();
    }


   /* FillPageSizeList('ddlPageSize', FormList);*/

    $("#CountryCode").select2({
        width: '100%'
    });
});

//PAGE SIZE CLICKED
$("#ddlPageSize").change(function () {
    FormList(1);
});

// PAGINATION BUTTON CLICKED
$(document).on("click", ".pagination .page", function () {
    FormList(($(this).attr('page')));
});

//FORMSEARCH BUTTON CLICK 
$("#FormSearch").click(function () {
    FormList(1);
});

//FUNCTION FOR GET FORM LIST DATA
function FormList(PageIndex) {
    try {

        const dataString = {};
        dataString.PageSize = $("#ddlPageSize").val();
        dataString.PageIndex = PageIndex;
        dataString.OrderBy = $("#sort-column").val().trim() + " " + $("#sort-type").val().trim();
        dataString.PortCode = $("#PortCodeSearch").val();
        dataString.Place = $("#PlaceSearch").val();

        ShowLoader();

        AjaxSubmission(JSON.stringify(dataString), '/Master/Place/FormList', $('input[name=__RequestVerificationToken]').val()).done(function (result) {
            let obj = result;
            if (obj.status == true) {
                if (obj.responsecode == '100') {
                    $("#TblPlace tbody").html('');
                    $("#TblPlace tbody").html(obj.data.HtmlData[0].TableHtmlData);
                    $(".pagination").BindPaging({
                        ActiveCssClass: "current",
                        PagerCssClass: "pager",
                        PageIndex: parseInt(obj.data.Table1[0].PageIndex),
                        PageSize: parseInt(obj.data.Table1[0].PageSize),
                        RecordCount: parseInt(obj.data.Table1[0].count)
                    });
                }
                else
                    Toast(RetrieveMessage(obj.responsecode), 'Message', 'error');

            } else
                window.location.href = '/ClientLogin/ClientLogin';
            HideLoader();

        }).fail(function (result) {
            console.log(result.Message);
            HideLoader();
        });
    }
    catch (e) {
        console.log(e.message);
        HideLoader();
    }
}

//FUNCTION  FOR BIND FORM TABLE
function BindFormTable(Result, SerialNo) {
    $("#TblPlace tbody tr").remove();

    if (Result.length == 0) {
        tr = $('<tr/>');
        tr.append("<td class='text-center' colspan='8'>NO RECORDS FOUND</td>");
        $("#TblPlace tbody").append(tr);
    } else {
        for (i = 0; i < Result.length; i++) {
            tr = $('<tr/>');
            tr.append("<td class='text-left'><button type='button' onclick='FormEdit(\"" + Result[i].PlaceUid + "\");' class= 'Edit common-btn common-btn-sm' ><i class='fa-solid fa-pen-to-square'></i></button > <button type='button' onclick='FormDelete(\"" + Result[i].PlaceUid + "\");' class= 'Delete common-btn common-btn-sm ms-1' > <i class='fa-regular fa-trash-can'></i></button> " + SerialNo + "</td>");
            tr.append("<td><a href='javascript:void(0)' class='text-decoration-none' style='color: black !important;' onclick='FormEdit(\"" + Result[i].PlaceUid + "\");'>" + Result[i].Place + "</a></td>");
            tr.append("<td class='text-left'>" + Result[i].PortCode + "</td>");
            tr.append("<td class='text-center'>" + Result[i].CountryCode + "</td>");

            tr.append("<td class='text-left'>" + HandleNullTextValue(Result[i].CreatedBy) + "</td>");
            tr.append("<td class='text-center'>" + HandleNullTextValue(Result[i].CreatedAt) + "</td>");
            tr.append("<td class='text-left'>" + HandleNullTextValue(Result[i].LastUpdatedAt) + "</td>");
            tr.append("<td class='text-left'>" + HandleNullTextValue(Result[i].LastUpdatedBy) + "</td>");

            $("#TblPlace tbody").append(tr);
            SerialNo++;

        }
    }
}

//FUNCTION FOR FORM SORTING
function FormSorting(obj) {
    if (Firstcolumn != "") {
        document.getElementById(Firstcolumn).innerHTML = document.getElementById(Firstcolumn).getAttribute("data-column") + " <i class='fa-solid fa-sort'></i>";
    }
    let cn = obj.id;
    Firstcolumn = cn;
    var colname = $(obj).data("column");
    $("#sort-column").val(cn.replaceAll("_", ""));
    var sorttype = $("#sort-type").val();
    if (sorttype == "ASC") {
        $("#sort-type").val("DESC");
        $(obj).html(colname + " <i style='margin-left:10px;' class='fa-solid fa-sort-down'></i>");
    } else if (sorttype == "DESC") {
        $("#sort-type").val("ASC");
        $(obj).html(colname + " <i style='margin-left:10px;' class='fa-solid fa-sort-up'></i>");
    }
    FormList(1);
}

// FORM ADD BUTTON CLICK EVENT
$("#FormAdd").click(function () {
    RemoveAllError('PlaceForm');
    ValidateAllFieldNewTest('PlaceForm');
    if (Ercount == 0) {
        if ($("#ContryCode").val() == "0") {
            Toast(RetrieveMessage(707), 'Message', 'error');
            return;
        }
        FormAdd();
    }
});

// FUNCTION FOR FORM ADD
function FormAdd() {
    try {

        //ShowLoader();
        const dataString = {};
        dataString.PortCode = $("#PortCode").val().trim();
        dataString.Place = $("#PlaceName").val().trim();
        dataString.CountryCode = $("#CountryCode").val().trim();
        AjaxSubmission(JSON.stringify(dataString), "/Master/Place/FormAdd", $('[name="__RequestVerificationToken"]').val()).done(function (result) {
            let obj = result;           
            if (obj.status == true) {
                if (obj.responsecode == '101') {
                    Toast(RetrieveMessage(obj.responsecode), "Message", "success");
                    $("#PlaceId").val(obj.data.Table[0].PlaceUid);
                    $("#Timestamp").val(obj.data.Table[0].Timestamp);
                    $("#FormAdd").hide();
                    $("#FormUpdate").show();
                    $("#FormReset").show();
                    $("#Place-tab").html("Edit Place");
                     FormList(1);

                }
                else
                    Toast(RetrieveMessage(obj.responsecode), "Message", "error");

            } else
                window.location.href = '/ClientLogin/ClientLogin';
            //HideLoader();
        }).fail(function (result) {
            //HideLoader();
            console.log(result.message);
        });
    }
    catch (e) {
        //HideLoader();
        console.log(e.message);
    }
}

//FUNCTION FOR FORM EDIT 
function FormEdit(e) {

    try {
        const dataString = {};
        dataString.PlaceUid = (e);
        //ShowLoader();
        AjaxSubmission(JSON.stringify(dataString), "/Place/FormEdit", $('[name="__RequestVerificationToken"]').val()).done(function (data) {
            let obj = data;
            if (obj.status == true) {
                if (obj.responsecode == '100') {
                    TabShow();
                    $("#PlaceId").val(obj.data.Table[0].PlaceUid);
                    $("#Timestamp").val(obj.data.Table[0].Timestamp);
                    $("#PortCode").val(obj.data.Table[0].PortCode);
                    $("#PlaceName").val(obj.data.Table[0].Place);
                    $("#CountryCode").val(obj.data.Table[0].CountryCode).trigger('change');
                }
                else
                    Toast(RetrieveMessage(obj.responsecode), "Message", "error");
            }
            else
                window.location.href = '/ClientLogin/ClientLogin';
            //HideLoader();
        }).fail(function (data) {
            //HideLoader();
            console.log(data.Message);
        });
    }
    catch (e) {
        //HideLoader();
        console.log(e.message);

    }
}

// FORM UPDATE BUTTON CLICK EVENT
$("#FormUpdate").click(function () {
    RemoveAllError('PlaceForm');
    ValidateAllFieldNewTest('PlaceForm');
    if (Ercount == 0) {
        if ($("#ContryCode").val() == "0") {
            Toast(RetrieveMessage(707), 'Message', 'error');
            return;
        }
        FormUpdate();;
    }
});

//FUNCTION FOR FORM UPDATE
function FormUpdate() {
    try {
        //ShowLoader();
        const dataString = {};
        dataString.PlaceUid = $("#PlaceId").val().trim();
        dataString.TimeStamp = $("#Timestamp").val().trim();
        dataString.PortCode = $("#PortCode").val().trim();
        dataString.Place = $("#PlaceName").val().trim();
        dataString.CountryCode = $("#CountryCode").val().trim();
        AjaxSubmission(JSON.stringify(dataString), "/Place/FormUpdate", $('input[name=__RequestVerificationToken]').val()).done(function (result) {
            let obj = result;           
            if (obj.status == true) {
                if (obj.responsecode == '107') {
                    Toast(RetrieveMessage(obj.responsecode), "Message", "success");
                    $("#PlaceId").val(obj.data.Table[0].PlaceUid);
                    $("#Timestamp").val(obj.data.Table[0].Timestamp);
                    FormList(1);                   
                }
                else
                    Toast(RetrieveMessage(obj.responsecode), "Message", "error");
            }
            else
                window.location.href = '/ClientLogin/ClientLogin';
            //HideLoader();
        }).fail(function (result) {
            //HideLoader();
            console.log(result.Message);
        });
    }
    catch (e) {
        //HideLoader();
        console.log(e.message);
    }
}

//FUNCTION FOR FORM DELETE
function FormDelete(e) {
    try {
        $.confirm({
            title: '',
            content: 'Are You Sure Want To Delete ?',
            type: 'red',
            boxWidth: '300px',
            useBootstrap: false,
            typeAnimated: true,
            columnClass: 'small',
            containerFluid: true,
            buttons: {
                tryAgain: {
                    text: 'Confirm',
                    btnClass: 'btn-red',
                    action: function () {
                        const dataString = {};
                        dataString.PlaceUid = e;
                        AjaxSubmission(JSON.stringify(dataString), "/Place/FormDelete", $('[name="__RequestVerificationToken"]').val()).done(function (data) {
                            let obj = data;
                            if (obj.status == true) {
                                if (obj.responsecode == '102') {
                                    Toast(RetrieveMessage(obj.responsecode), "Message", "success");
                                    FormList(1);
                                }
                                else
                                    Toast(RetrieveMessage(obj.responsecode), "Message", "error");
                            }
                            else
                                window.location.href = '/ClientLogin/ClientLogin';
                            //HideLoader();
                        }).fail(function (data) {
                            console.log(data.Message);
                            //HideLoader();
                        });
                    }
                },
                close: function () {

                }
            }
        });
    }
    catch (e) {
        //HideLoader();
        console.log(e.message);

    }
}

//FUNCTION FOR EXPORT DATA IN EXCEL
function FormExcel() {
    ShowLoader();
    let date = new Date();
    let NewDate = ("00" + date.getDate()).slice(-2) + "_" + ("00" + (date.getMonth() + 1)).slice(-2) + "_" + date.getFullYear() + "_" + ("00" + date.getHours()).slice(-2) + "_" + ("00" + date.getMinutes()).slice(-2) + "_" + ("00" + date.getSeconds()).slice(-2);
    let fileName = "Place_" + NewDate + ".xlsx";

    $('#FormSearch').trigger('click');
    AjaxSubmission(null, '/Master/Place/FormExcel', $('input[name=__RequestVerificationToken]').val()).done(function (result) {
        let obj = result;
        if (obj.status == true) {
            if (obj.responsecode == '100') {

                let bytes = Base64ToBytes(obj.data.FileData[0].Base64Data);
                let blob = new Blob([bytes], { type: "application/octetstream" });
                let isIE = false || !!document.documentMode;
                if (isIE) {
                    window.navigator.msSaveBlob(blob, fileName);
                } else {
                    let url = window.URL || window.webkitURL;
                    link = url.createObjectURL(blob);
                    let a = $("<a />");
                    a.attr("download", fileName);
                    a.attr("href", link);
                    $("body").append(a);
                    a[0].click();
                    $("body").remove(a);
                }
            }
            else if (obj.responsecode == '302')
                Toast("No Records found.", 'Message', 'success');
            else
                Toast(RetrieveMessage(obj.responsecode), 'Message', 'error');

        } else
            window.location.href = '/ClientLogin/ClientLogin';
        HideLoader();

    }).fail(function (result) {
        console.log(result.Message);
        HideLoader();
    });
}
// FUNCTION FOR TAB SHOW
function TabShow() {
    $('#Place_list-tab').removeClass('active');
    $('#Place-tab').addClass('active');
    $('#Place_list').removeClass('active show');
    $('#Place').addClass('active show');
    $("#FormAdd").hide();
    $("#FormUpdate").show();
    $("#FormReset").show();
    $("#Place-tab").html("Edit Place");
}

//FUNCTION FOR TAB HIDE
function TabHide() {
    $('#Place-tab').removeClass('active');
    $('#Place_list-tab').addClass('active ');
    $('#Place_list').addClass('active show');
    $('#Place').removeClass('active show');
    $("#FormAdd").show();
    $("#FormUpdate").hide();
    $("#FormReset").hide();
    $("#Place-tab").html("Add Place");
}

//Branch LIST TAB CLICKED
$("#Place_list-tab").click(function () {
    ResetForm();
    RemoveAllError('PlaceForm');
});

//FUNCTION FOR RESET FORM
function ResetForm() {
    $("#PlaceId").val("");
    $("#Timestamp").val("");
    $("#PortCode").val("");
    $("#PlaceName").val("");
    $("#CountryCode").val("0").trigger('change');
    $("#FormAdd").show();
    $("#FormUpdate").hide();
    $("#FormReset").hide();
    $("#Place-tab").html("Add Place");
};
$("#FormReset").click(function () {
    ResetForm();
})

document.addEventListener("keydown", function (zEvent) {
    if (zEvent.ctrlKey && zEvent.altKey && (zEvent.key == "j" || zEvent.key == "J")) {       
        $('#Place_list-tab').removeClass('active ');
        $('#Place_list').removeClass('active show');
        $('#Place-tab').addClass('active');
        $('#Place').addClass('active show');
        $("#FormAdd").show();
        $("#FormUpdate").hide();
        $("#FormReset").hide();
        $("#Place-tab").html("Add Place");
        RemoveAllError('PlaceForm');
        $('#PortCode').focus();
        ResetForm();
       

    }
});