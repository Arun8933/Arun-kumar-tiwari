﻿var Firstcolumn = "";
$(document).on("click", ".pagination .page", function () {
    FormList(($(this).attr('page')));
});
//PAGE SIZE CLICKED
$("#ddlPageSize").change(function () {
    FormList(1);
});


if (Get_Cookie("CustomPortId") != null) {    
    var a = setInterval(() => {       
        if (Get_Cookie("CustomPortId") != '') {
           
            FormEdit(Get_Cookie("CustomPortId"));
        } else {
            $('#Port_list-tab').removeClass('active');
            $('#Port-tab').addClass('active');
            $('#Port_list').removeClass('active show');
            $('#Port').addClass('active show');
            $("#FormAdd").show();
            $("#FormUpdate").hide();
            $("#Port-tab").html("Add Custom Port");
        }
        EraseCookie('CustomPortId');
        clearInterval(a);
        
    }, 500);
}

//SEARCH BUTTON CLICKED
$("#FormSearch").click(function () {
    Firstcolumn = "Port_Name";
    FormList(1);
});

// DOCUMENT READY
$(document).ready(function () {
    ShowLoader();
    if (Get_Cookie("CustomPortId") != null)
        FillPageSizeList('ddlPageSize', FormList);
    else
        FillPageSizeList('ddlPageSize', FormList);
    HideLoader();
})

$("#PortModeSearch").select2({ width: '100%' });
$("#PortMode").select2({ width: '100%' });

// BIND CUSTOM PORT  TABLE

function BindFormTable(Result, SerialNo) {
    $("#TblPortMaster tbody tr").remove();
    if (Result.length == 0) {
        tr = $('<tr/>');
        tr.append("<td class='text-center' colspan='9'>NO RESULTS FOUND</td>");
        $("#TblPortMaster tbody").append(tr);
    }
    else {
        for (i = 0; i < Result.length; i++) {
            if (Result[i].is_active == "InActive")
                tr = $(' <tr style="background-color:#fdd2d2;"/>');
            else
                tr = $('<tr/>');
            tr.append("<td class='text-center'><button type='button' onclick='FormEdit(\"" + Result[i].PortUid + "\");' class= 'common-btn common-btn-sm '><i class='fa-solid fa-pen-to-square'></i></button ><button type='button' onclick='FormDelete(\"" + Result[i].PortUid + "\");' class='common-btn common-btn-sm ms-1'> <i class='fa-regular fa-trash-can'></i></button ></td > ");
            tr.append("<td class='text-left'>" + SerialNo + "</td>");
            tr.append("<td class='text-left'>" + Result[i].PortUid + "</td>");
            tr.append("<td class='text-left'><a href='javascript:void(0)' class='text-decoration-none' style='color: black !important;' onclick='FormEdit(\"" + Result[i].PortUid + "\");'>" + Result[i].PortCode + "</a></td>");
            tr.append("<td class='text-center'>" + Result[i].PortName + "</td>");
            tr.append("<td class='text-center'>" + Result[i].ModeOfTransport + "</td>");
            
            SerialNo++;
            $("#TblPortMaster tbody").append(tr);
        }
    }
}

//CUSTOM PORT  LIST PAGE INDEX
function FormList(pageindex) {
    try {
        const dataString = {};
        dataString.PageSize = $("#ddlPageSize").val();
        dataString.PageIndex = pageindex;
        dataString.PortUId = $("#PortUIdSearch").val();
        dataString.PortCode = $("#PortCodeSearch").val();
        dataString.PortName = $("#PortNameSearch").val();
        dataString.ModeOfTransPort = $("#PortModeSearch").val();
        dataString.OrderBy = $("#sort-column").val().trim() + " " + $("#sort-type").val().trim();
        //Showloader();
        AjaxSubmission(JSON.stringify(dataString), "/Master/CustomPort/FormList", $('input[name=__RequestVerificationToken]').val()).done(function (result) {
            let obj = result;          
            if (obj.status == true) {
                if (obj.responsecode == '100') {
                    var ser = ((parseInt(obj.data.Table1[0].PageIndex) - 1) * parseInt(obj.data.Table1[0].PageSize)) + 1;
                    BindFormTable(obj.data.Table, ser);
                    if (obj.data.Table1 != undefined && obj.data.Table1.length > 0) {
                        $(".pagination").BindPaging({
                            ActiveCssClass: "current",
                            PagerCssClass: "pager",
                            PageIndex: parseInt(obj.data.Table1[0].PageIndex),
                            PageSize: parseInt(obj.data.Table1[0].PageSize),
                            RecordCount: parseInt(obj.data.Table1[0].count)
                        });
                    }
                }
                else {
                    Toast(RetrieveMessage(obj.responsecode), "Message", "error");
                }
            }
            else {
                window.location.href = '/ClientLogin/ClientLogin';
            }
            //Hideloader();
        }).fail(function (result) {
            console.log(result.Message);
            //Hideloader();
        });
    }
    catch (e) {
        console.log(e.message);
        //Hideloader();
    }
}



//FUNCTION FOR FORM SORTING
function FormSorting(obj) {
    if (Firstcolumn != "") {
        document.getElementById(Firstcolumn).innerHTML = document.getElementById(Firstcolumn).getAttribute("data-column") + " <i class='fa-solid fa-sort'></i>";
    }
    let cn = obj.id;
    Firstcolumn = cn;
    var colname = $(obj).data("column");
    $("#sort-column").val(cn.replaceAll("_", ""));
    var sorttype = $("#sort-type").val();
    if (sorttype == "ASC") {
        $("#sort-type").val("DESC");
        $(obj).html(colname + " <i style='margin-left:10px;' class='fa-solid fa-sort-down'></i>");
    } else if (sorttype == "DESC") {
        $("#sort-type").val("ASC");
        $(obj).html(colname + " <i style='margin-left:10px;' class='fa-solid fa-sort-up'></i>");
    }
    FormList(1);
}

//FUNCTION FOR EXPORT DATA IN EXCEL
function FormExcel() {
    ShowLoader();
    let date = new Date();
    let NewDate = ("00" + date.getDate()).slice(-2) + "_" + ("00" + (date.getMonth() + 1)).slice(-2) + "_" + date.getFullYear() + "_" + ("00" + date.getHours()).slice(-2) + "_" + ("00" + date.getMinutes()).slice(-2) + "_" + ("00" + date.getSeconds()).slice(-2);
    let fileName = "CustomPort_" + NewDate + ".xlsx";

    $('#FormSearch').trigger('click');
    AjaxSubmission(null, '/Master/CustomPort/FormExcel', $('input[name=__RequestVerificationToken]').val()).done(function (result) {
        let obj = result;
        if (obj.status == true) {
            if (obj.responsecode == '100') {

                let bytes = Base64ToBytes(obj.data.FileData[0].Base64Data);
                let blob = new Blob([bytes], { type: "application/octetstream" });
                let isIE = false || !!document.documentMode;
                if (isIE) {
                    window.navigator.msSaveBlob(blob, fileName);
                } else {
                    let url = window.URL || window.webkitURL;
                    link = url.createObjectURL(blob);
                    let a = $("<a />");
                    a.attr("download", fileName);
                    a.attr("href", link);
                    $("body").append(a);
                    a[0].click();
                    $("body").remove(a);
                }
            }
            else if (obj.responsecode == '302')
                Toast("No Records found.", 'Message', 'success');
            else
                Toast(RetrieveMessage(obj.responsecode), 'Message', 'error');

        } else
            window.location.href = '/ClientLogin/ClientLogin';
        HideLoader();

    }).fail(function (result) {
        console.log(result.Message);
        HideLoader();
    });
}

$("#FormAdd").click(function () {

    if ($("#PortCode").val() == "") {
        Toast("Please Enter Port Code !", 'Message', 'error');
        return;
    }
    if ($("#PortName").val() == "") {
        Toast("Please Enter Port Name !", 'Message', 'error');
        return;
    }
    if ($("#PortMode").val() == "0") {
        Toast("Please Select Mode Of Transport !", 'Message', 'error');
        return;
    }
    else if (Ercount == 0) {
        FormAdd();

    }
});


//FUNCTION FOR ADD PORT
function FormAdd() {

    try {
        const dataString = {};

        dataString.PortName = $("#PortName").val();
        dataString.PortCode = $("#PortCode").val();
        dataString.ModeOfTransPort = $("#PortMode").val();
        ShowLoader();

        AjaxSubmission(JSON.stringify(dataString), "/CustomPort/FormAdd", $('input[name=__RequestVerificationToken]').val()).done(function (result) {
            let obj = result;
            if (obj.status == true) {
                if (obj.responsecode == '101') {
                    Toast(RetrieveMessage(obj.responsecode), "Message", "success");
                    $("#HidPortUId").val(obj.data.Table[0].PortUid);
                    $("#Timestamp").val(obj.data.Table[0].Timestamp);
                    $("#FormAdd").hide();
                    $("#FormUpdate").show();
                    $("#FormReset").show();
                    $("#CustomPort-tab").html("Edit Job");
                    FormList(1);
                }
                else
                    Toast(RetrieveMessage(obj.responsecode), "Message", "error");
            }
            else
                window.location.href = '/ClientLogin/ClientLogin';
            HideLoader();
        }).fail(function (result) {            
            console.log(result.Message);
            HideLoader();
        });
    }
    catch (e) {      
        console.log(e.message);
        HideLoader();
    }
}

//FUNCTION FOR EDIT Port 
function FormEdit(PortUid) {

    try {
        const dataString = {};
        dataString.PortUid = parseInt(PortUid);
        ShowLoader();
        AjaxSubmission(JSON.stringify(dataString), "/Master/CustomPort/FormEdit", $('[name="__RequestVerificationToken"]').val()).done(function (data) {
            let obj = data;           
            if (obj.status == true) {
                if (obj.responsecode == '100') {
                    TabShow();
                    $("#HidPortUId").val(obj.data.Table[0].PortUid);
                    $("#Timestamp").val(obj.data.Table[0].TimeStamp);
                    $("#PortName").val(obj.data.Table[0].PortName);
                    $("#PortCode").val(obj.data.Table[0].PortCode);
                    $("#PortMode").val(obj.data.Table[0].ModeOfTransport).trigger('change');
                }
                else {
                    Toast(RetrieveMessage(obj.responsecode), "Message", "error");
                }
            }
            else {
                window.location.href = '/ClientLogin/ClientLogin';
            }
            HideLoader();
        }).fail(function (data) {
            console.log(data.Message);
            HideLoader();
        });
    }
    catch (e) {
        console.log(e.message);
        HideLoader();
    }
}


$("#FormUpdate").click(function () {    
    if ($("#PortCode").val() == "") {
        Toast("Please Enter Port Code !", 'Message', 'error');
        return;
    }
    if ($("#PortName").val() == "") {
        Toast("Please Enter Port Name !", 'Message', 'error');
        return;
    }
    if ($("#PortMode").val() == "0") {
        Toast("Please Select Mode Of Transport !", 'Message', 'error');
        return;
    }
    else if (Ercount == 0) {
        FormUpdate();
    }
});


//FUNCTION FOR CUSTOM PORT 
function FormUpdate() {
    try {
        const dataString = {};

        dataString.PortUid = $("#HidPortUId").val();
        dataString.TimeStamp = $("#Timestamp").val();
        dataString.PortName = $("#PortName").val();
        dataString.PortCode = $("#PortCode").val();
        dataString.ModeOfTransPort = $("#PortMode").val();
        ShowLoader();
        AjaxSubmission(JSON.stringify(dataString), "/Master/CustomPort/FormUpdate", $('input[name=__RequestVerificationToken]').val()).done(function (result) {
            let obj = result;
            if (obj.status == true) {
                if (obj.responsecode == '107') {
                    Toast(RetrieveMessage(obj.responsecode), "Message", "success");
                    $("#HidPortUId").val(obj.data.Table[0].PortUid);
                    $("#Timestamp").val(obj.data.Table[0].TimeStamp);
                    FormList(1); 
                }
                else
                    Toast(RetrieveMessage(obj.responsecode), "Message", "error");
            }
            else {
                window.location.href = '/ClientLogin/ClientLogin';
            }
            HideLoader();
        }).fail(function (result) {
            console.log(result.Message);
            HideLoader();
        });
    }
    catch (e) {
        console.log(e.message);
        HideLoader();
    }
}


//FUNCTION FOR DELETE CUSTOM PORT 
function FormDelete(e) {
    try {
        $.confirm({
            title: '',
            content: 'Are You Sure Want To Delete ?',
            type: 'red',
            boxWidth: '300px',
            useBootstrap: false,
            typeAnimated: true,
            columnClass: 'small',
            containerFluid: true,
            buttons: {
                tryAgain: {
                    text: 'Confirm',
                    btnClass: 'btn-red',
                    action: function () {

                        const datastring = {};
                        datastring.PortUid = parseInt(e);
                        ShowLoader();
                        AjaxSubmission(JSON.stringify(datastring), "/Master/CustomPort/FormDelete", $('[name="__RequestVerificationToken"]').val()).done(function (data) {
                            let obj = data;
                            if (obj.status == true) {
                                if (obj.responsecode == '102') {
                                    Toast(RetrieveMessage(obj.responsecode), "Message", "success");
                                    FormList(1);

                                }
                                else {
                                    Toast(RetrieveMessage(obj.responsecode), "Message", "error");
                                }
                            }
                            else {
                                window.location.href = 'ClientLogin/ClientLogin';
                            }
                            HideLoader();
                        }).fail(function (data) {
                            console.log(data.Message);
                            HideLoader();
                        });
                    }
                },
                close: function () {
                   
                }
            }
        });
    }
    catch (e) {
        console.log(e.message);
        HideLoader();
    }
}
//FUNCTION FOR REST INPUT TYPE FIELD
function ResetForm() {
    $("#HidPortUId").val("");
    $("#Timestamp").val("");
    $("#PortName").val("");
    $("#PortCode").val("");
    $("#PortMode").val("0").trigger('change');
    $("#FormAdd").show();
    $("#FormUpdate").hide();
    $("#FormReset").hide();
    $("#Port-tab").html("Add Custom Port");
    RemoveAllError("Port");
};

//FUCNTION FOR TAB SHOW
function TabShow() {
    $('#Port_list-tab').removeClass('active');
    $('#Port-tab').addClass('active');
    $('#Port_list').removeClass('active show');
    $('#Port').addClass('active show');
    $("#FormAdd").hide();
    $("#FormUpdate").show();
    $("#FormReset").show();
    $("#Port-tab").html("Edit Custom Port");
}

//FUNCTION FOR TAB HIDE
function TabHide() {
    $('#Port-tab').removeClass('active');
    $('#Port_list-tab').addClass('active ');
    $('#Port_list').addClass('active show');
    $('#Port').removeClass('active show');
    $("#FormAdd").show();
    $("#FormUpdate").hide();
    $("#FormReset").hide();
    $("#Port-tab").html("Add Custom Port");
}

//CUSTOM PORT  LIST TAB CLICKED
$("#Port_list-tab").click(function () {
    ResetForm();
})

$("#FormReset").click(function () {
    ResetForm();
})

document.addEventListener("keydown", function (zEvent) {
    if (zEvent.ctrlKey && zEvent.altKey && (zEvent.key == "j" || zEvent.key == "J")) {
        $('#Port_list-tab').removeClass('active ');
        $('#Port_list').removeClass('active show');
        $('#Port-tab').addClass('active');
        $('#Port').addClass('active show');
        $("#FormAdd").show();
        $("#FormUpdate").hide();
        $("#FormReset").hide();
        $("#Port-tab").html("Add Custom Port");
        $('#PortCode').focus();
        ResetForm();

    }
});
