﻿
var jobflag = 0;
var srbtn = 'up';
var Firstcolumn = '';
var TPSelecBranc = '';
var Fedit = 0;
var CliSelecBranc = '';
var ShSelecBranc = '';
var HSSelecBranc = '';
var Detslab = '';
var dupInv = 0;
var firssr = 0;
var JobAc = 0;
var State_code_selected = '';
let container_num_count = true;
//VARIABLE FOR DOCUMENT UPLOAD
let formname = 'Job';
let formid;
let VoucherType = '';
let ItemESanchitModal = document.getElementById('ItemESanchitModal');

$('#StateOfOrigin').select2({
    width: '100%'
});

//DATE PICKER
$('.dateTimepickerAll').datetimepicker({
    format: 'd/m/Y H:i',
});

$('.card-body').css({ 'overflow': '', 'height': '' });

// DOCUMENT READY
$(document).ready(function () {
    Firstcolumn = 'sub_job_no';
    firssr = 0;

    let date = new Date();
    let NewDate = date.getDate().toString().padStart(2, 0) + '/' + (date.getMonth() + 1).toString().padStart(2, 0) + '/' + date.getFullYear().toString();

    $('#JobDate').val(NewDate);

    if (Get_Cookie('ClientId') != null || Get_Cookie('JobUid') != null) {
        FillPageSizeList('ddlPageSize');
        $('#SearchJobDateFrom').val('');
        $('#SearchJobDateTo').val('');
    }
    else {
        GetFinancialYearDate();
        let iju = setInterval(() => {
            if ($('#SearchSelectBranch').val() != null && $('#SearchJobDateFrom').val() != null && $('#SearchJobDateFrom').val() != undefined && $('#SearchJobDateFrom').val().trim().length == 10 && $('#SearchJobDateTo').val() != null && $('#SearchJobDateTo').val() != undefined && $('#SearchJobDateTo').val().trim().length == 10) {
                FillPageSizeList('ddlPageSize', FormList);
                clearInterval(iju);
            }
        }, 100);
    }

    if (Get_Cookie('ClientId') != null) {
        let acd = setInterval(() => {
            if (Get_Cookie('ClientId') != '' && Get_Cookie('ClientId') != 0) {
                $('#HiddenSearchClient').val(Get_Cookie('ClientId'));
                if (Get_Cookie('HiddenSrchLedgName') != null)
                    $('#SearchClient').val(Get_Cookie('HiddenSrchLedgName'));
                if (Get_Cookie('Type') != null) {
                    if (Get_Cookie('Type') == 'PendingJob')
                        $('#PendingJob').prop('checked', true);
                    else if (Get_Cookie('Type') == 'BilledJob')
                        $('#BilledJob').prop('checked', true);
                    else if (Get_Cookie('Type') == 'UnBilledJob')
                        $('#UnBilledJob').prop('checked', true);
                }
                $('#FormSearch').trigger('click');
            }
            EraseCookie('ClientId');
            EraseCookie('HiddenSrchLedgName');
            EraseCookie('Type');
            clearInterval(acd);

        }, 1000);
    }

    if (Get_Cookie('JobType') != null) {
        let JbType = Get_Cookie('JobType');
        if (JbType == 'PendingJob')
            $('#PendingJob').prop('checked', true);
        else if (JbType == 'BilledJob')
            $('#BilledJob').prop('checked', true);
        else if (JbType == 'UnBilledJob')
            $('#UnBilledJob').prop('checked', true);

        var poli = setInterval(() => {
            if ($('#SearchSelectBranch').val() != null && $('#SearchJobDateFrom').val() != null && $('#SearchJobDateTo').val() != null) {
                $('#SearchSelectBranch').val(Get_Cookie('SearchBranch'));
                $('#SearchJobDateFrom').val(Get_Cookie('SearchFrmDate'));
                $('#SearchJobDateTo').val(Get_Cookie('SearchToDate'));

                EraseCookie('JobType');
                clearInterval(poli);
            }
        }, 100);
    }

    FillBranchList('SearchSelectBranch', false);
    FillBranchList('SelectBranch');

    let oio = setInterval(() => {
        if ($('#SelectBranch').val() > 0 && $('#JobDate').val().trim().length == 10) {
            const dataString = {};
            dataString.BranchId = $('#SelectBranch').val();
            dataString.JobDate = $('#JobDate').val();
            dataString.JobUid = $('#JobUid').val();
            dataString.JobType = $('#JobType').val();
            AjaxSubmission(JSON.stringify(dataString), '/_Layout/GetJobno', $('[name="__RequestVerificationToken"]').val()).done(function (result) {
                let obj = result;
                if (obj.status == true) {
                    if (obj.responsecode == '100') {
                        if (obj.data.Table[0].In_Valid_Job_No == false) {
                            $('#JobNo').val('');
                            $('#SubJobNo').val('');
                            $('#JobNo').val(obj.data.Table[0].job_no);
                            $('#SubJobNo').val(obj.data.Table[0].sub_job_no);

                            if (Get_Cookie('JobUid') != null) {
                                let bvgb = setInterval(() => {
                                    if (Get_Cookie('JobUid') != '' && Get_Cookie('JobUid') != 0) {
                                        FormEdit(Get_Cookie('JobUid'));
                                    }
                                    EraseCookie('JobUid');
                                    clearInterval(bvgb);
                                }, 100);
                            }
                        }
                    }
                }
                else
                    window.location.href = '/ClientLogin/ClientLogin';
            }).fail(function (result) {
                console.log(result.message);
            });
            clearInterval(oio);
        }
    }, 100);

    GetInvoiceTerm('NewNatureOfContract');
    GetInvoiceTerm('NatureOfContract');

    FillSchemeCode('SchemeCode', 'Export');

    FillAllStateList('StateOfOrigin');

    FillIceGateId('TblIceGate', '----Select----', '.');
    FillIceGateId('TblNewItemIceGate', '----Select----', '.');
    FillIceGateId('FlatFileModalICEGATEUserId', '----Select----');

    if (Get_Cookie('JobUid') == null)
        HideLoader();

    $('#SearchJobNo').autocomplete({
        source: function (request, response) {
            AjaxSubmissionAutocomplete(JSON.stringify({
                SearchField: request.term, SubJobNo: $('#SearchSubJobNo').val(), JobDateFrom: $('#SearchJobDateFrom').val(), JobDateTo: $('#SearchJobDateTo').val(), Type: null, JobType: 'Export/Amendment'
            }), '/Master/_Layout/GetJobNumberAutoComplete', $('input[name=__RequestVerificationToken]').val()).done(function (result) {
                let obj = result;
                if (obj.status == true) {
                    if (obj.responsecode == '100') {
                        response($.map(result.data.Table, function (item, id) {
                            return {
                                label: item.name,
                                value: item.name,
                                id: item.id
                            };
                        }));
                    }
                }
                else
                    window.location.href = '/ClientLogin/ClientLogin';
            }).fail(function (result) {
                console.log(result.Message);
            });
        },
        autoFocus: true,
        minLength: 1,
        selectFirst: true,
        selectOnly: true,
        select: function (e, i) {
            //$('#' + HiddenId).val(i.item.id);
            $('#HiddenSearchJobNo').val(i.item.id);

        },
        change: function (e, i) {
            if (i.item == null || i.item == undefined) {
                //$('#' + id).val('');
                //$('#' + HiddenId).val('');

                $('#SearchJobNo').val('');
                $('#HiddenSearchJobNo').val('');
            }
        }
    }).on('focus', function () {
        $(this).autocomplete('search', $('#SearchSubJobNo').val());
    });
});

//#region /****************************MAIN START**********************/

//CLIENT NAME ON INPUT  EVENT
$('#ClientName').on('input', function () {
    $('#HiddenClientName').val('');
});

//CLIENT NAME  BLUR EVENT
$("#ClientName").blur(function () {
    $("#Address,#BranchCode").html('');
    if ($("#HiddenClientName").val().trim().length > 0)
        ClientAddress();
});

//FUNCTION FOR FILL IMPORTER ADDRESS
function ClientAddress() {
    try {
        const dataString = {};
        var LId = parseInt($('#HiddenClientName').val().trim());
        dataString.LedgerId = LId;
        AjaxSubmission(JSON.stringify(dataString), '/Master/_Layout/GetLedgerAddressWithBranch', $('input[name=__RequestVerificationToken]').val()).done(function (result) {
            let obj = result;
            if (obj.status == true) {
                if (obj.responsecode == '100') {
                    BindDropdownNew(obj.data.Table, 'Address', 'BranchUid', 'BranchAddress', '--Select--');
                    if (CliSelecBranc == '' || CliSelecBranc == undefined || CliSelecBranc == null)
                        $('#Address').val(obj.data.Table[0].BranchUid).trigger('change');
                    else {
                        $('#Address').val(CliSelecBranc).trigger('change');
                        CliSelecBranc = '';
                    }
                }
                else
                    BindDropdownNew(null, 'Address', 'BranchUid', 'BranchAddress', '--Select--');

            } else
                window.location.href = '/ClientLogin/ClientLogin';

        }).fail(function (result) {
            console.log(result.Message);
        });
    }
    catch (e) {
        console.log(e.message);
    }
}

//ADDRESS DROPDOWN CHANGE EVENT
$('#Address').change(function () {
    if ($('#Address').val() == "00")
        $('#BranchCode').val('')
    else
        FillBranchCode($('#Address').val());
});

// FUNCTION FOR FILL BRANCH CODE
function FillBranchCode(e) {
    try {
        if (e <= 0) {
            Toast('Please Choose Client Address', 'Message', 'error');
            $('#BranchCode').val('');
        } else {
            const dataString = {};
            dataString.BranchUid = e;
            AjaxSubmission(JSON.stringify(dataString), '/Master/_Layout/GetBranchCode', $('input[name=__RequestVerificationToken]').val()).done(function (result) {
                let obj = result;
                if (obj.status == true) {
                    if (obj.responsecode == '100')
                        $('#BranchCode').val(obj.data.Table[0].BranchCode);
                    else
                        Toast(obj.responsecode, 'Message', 'error');
                } else
                    window.location.href = '/ClientLogin/ClientLogin';
            }).fail(function (result) {
                console.log(result.message);
            });
        }
    }
    catch (e) {
        console.log(e.message);
    }
}

//CONSIGNEE NAME ON INPUT  EVENT
$('#Consignee').on('input', function () {
    $('#HiddenConsignee').val('');
})

//CONSIGNEE NAME BUTTON BLUR EVENT
$('#Consignee').blur(function () {
    $('#ConsigneeAddress1,#ConsigneeAddress2,#ConsigneeAddress3,#ConsigneeAddress4,#HiddenConsigneeCountry,#ConsigneeCountry').val('');
    if ($('#HiddenConsignee').val().trim().length > 0)
        FillConsigneeDetails();
});

//FUNCTION FOR FILL CONSIGNEE DETAILS
function FillConsigneeDetails() {
    try {
        const dataString = {};
        let LId = parseInt($('#HiddenConsignee').val().trim());
        dataString.LedgerId = LId;
        AjaxSubmission(JSON.stringify(dataString), '/Master/_Layout/GetConsigneeDetails', $('input[name=__RequestVerificationToken]').val()).done(function (result) {
            let obj = result;
            if (obj.status == true) {
                if (obj.responsecode == '100') {
                    $('#ConsigneeAddress1').val(obj.data.Table[0].Address1);
                    $('#ConsigneeAddress2').val(obj.data.Table[0].Address2);
                    $('#ConsigneeAddress3,#ConsigneeAddress4').val('');
                    $('#HiddenConsigneeCountry').val(obj.data.Table[0].Country);
                    $('#ConsigneeCountry').val(obj.data.Table[0].CountryName);

                    if ($('#ConsgineeBuyer').is(':checked') == true) {
                        $('#HiddenBuyer').val($('#HiddenConsignee').val().trim());
                        $('#Buyer').val($('#Consignee').val().trim());
                        $('#BuyerAddress1').val(obj.data.Table[0].Address1);
                        $('#BuyerAddress2').val(obj.data.Table[0].Address2);
                        $('#BuyerAddress3').val($('#ConsigneeAddress3').val().trim());
                        $('#BuyerAddress4').val($('#ConsigneeAddress4').val().trim());
                    }
                }
                else
                    $('#ConsigneeAddress1,#ConsigneeAddress2,#ConsigneeAddress3,#ConsigneeAddress4,#HiddenConsigneeCountry,#ConsigneeCountry').val('');
            }
            else
                window.location.href = '/ClientLogin/ClientLogin';
        }).fail(function (result) {
            console.log(result.Message);
        });
    }
    catch (e) {
        console.log(e.message);
    }
}

//THIRD PARTY  ON INPUT EVENT
$('#ThirdParty').on('input', function () {
    $('#HiddenThirdParty').val('');
});

//THIRD PARTY  BLUR EVENT
$('#ThirdParty').blur(function () {
    if ($("#HiddenThirdParty").val().trim().length > 0)
        FillThirdPartyAddress();
    else {
        $("#ThirdPartyAddress").html('');
        $("#ThirdPartyAddress1,#ThirdPartyAddress2,#HiddenThirdPartyCountry,#ThirdPartyCountry,#HiddenThirdPartyState,#ThirdPartyState,#ThirdPartyCity,#ThirdPartyPinCode").val('');
    }
});

//FUNCTION FOR FILL THIRD PART ADDRESS
function FillThirdPartyAddress() {
    try {
        const dataString = {};
        let LId = parseInt($('#HiddenThirdParty').val().trim());
        dataString.LedgerId = LId;
        AjaxSubmission(JSON.stringify(dataString), '/Master/_Layout/GetLedgerAddressWithBranch', $('input[name=__RequestVerificationToken]').val()).done(function (result) {
            let obj = result;
            if (obj.status == true) {
                if (obj.responsecode == '100') {
                    BindDropdownNew(obj.data.Table, 'ThirdPartyAddress', 'BranchUid', 'BranchAddress', '--Select--');
                    if (TPSelecBranc == '' || TPSelecBranc == undefined || TPSelecBranc == null) {
                        if (Fedit == 0)
                            $('#ThirdPartyAddress').val(obj.data.Table[0].BranchUid).trigger('change');
                        else
                            $('#ThirdPartyAddress').val(obj.data.Table[0].BranchUid);
                    }
                    else {
                        $('#ThirdPartyAddress').val(TPSelecBranc);
                        TPSelecBranc = '';
                    }
                }
                else
                    BindDropdownNew(null, 'ThirdPartyAddress', 'BranchUid', 'BranchAddress', '--Select--');
                Fedit = 0;
            } else
                window.location.href = '/ClientLogin/ClientLogin';

        }).fail(function (result) {
            console.log(result.Message);
        });
    }
    catch (e) {
        console.log(e.message);
    }
}

//THIRD PART ADDRESS DROPDOWN CHANGE EVENT
$('#ThirdPartyAddress').change(function () {
    if ($('#ThirdPartyAddress').val() == "00")
        $('#ThirdPartyAddress1,#ThirdPartyAddress2,#HiddenThirdPartyCountry,#ThirdPartyCountry,#HiddenThirdPartyState,#ThirdPartyState,#ThirdPartyCity,#ThirdPartyPinCode').val('');
    else
        FillThirdPartyDetails($("#ThirdPartyAddress").val());
});

//FUNCTION FILL THIRD PARTY DETAILS
function FillThirdPartyDetails(e) {
    try {
        if (e <= 0)
            Toast('Please Choose Third Party Address', 'Message', 'error');
        else {
            const dataString = {};
            dataString.BranchUid = e;
            AjaxSubmission(JSON.stringify(dataString), '/Master/_Layout/GetThirdPartyBranchDetails', $('input[name=__RequestVerificationToken]').val()).done(function (result) {
                let obj = result;
                if (obj.status == true) {
                    if (obj.responsecode == '100') {
                        $('#ThirdPartyAddress1').val(obj.data.Table[0].Address1);
                        $('#ThirdPartyAddress2').val(obj.data.Table[0].Address2);
                        $('#HiddenThirdPartyCountry').val(obj.data.Table[0].CountryUid);
                        $('#ThirdPartyCountry').val(obj.data.Table[0].CountryName);
                        $('#HiddenThirdPartyState').val(obj.data.Table[0].StateCode);
                        $('#ThirdPartyState').val(obj.data.Table[0].StateName);
                        $('#ThirdPartyCity').val(obj.data.Table[0].BranchCity);
                        $('#ThirdPartyPinCode').val(obj.data.Table[0].PinCode);
                    }
                    else
                        $('#ThirdPartyAddress1,#ThirdPartyAddress2,#HiddenThirdPartyCountry,#ThirdPartyCountry,#HiddenThirdPartyState,#ThirdPartyState,#ThirdPartyCity,#ThirdPartyPinCode').val('');

                } else
                    window.location.href = '/ClientLogin/ClientLogin';
            }).fail(function (result) {
                console.log(result.message);
            });
        }
    }
    catch (e) {
        console.log(e.message);
    }
}

//BUYER NAME ON INPUT  EVENT
$('#Buyer').on('input', function () {
    $('#HiddenBuyer').val('');
});

//BUYER NAME BUTTON BLUR EVENT
$("#Buyer").blur(function () {
    $('#BuyerAddress1,#BuyerAddress2,#BuyerAddress3,#BuyerAddress4').val('');
    if ($('#HiddenBuyer').val().trim().length > 0)
        FillBuyerDetails();
});

//FUNCTION FOR FILL BUYER DETAILS
function FillBuyerDetails() {
    try {
        const dataString = {};
        let LId = parseInt($('#HiddenBuyer').val().trim());
        dataString.LedgerId = LId;
        AjaxSubmission(JSON.stringify(dataString), '/Master/_Layout/GetBuyerDetails', $('input[name=__RequestVerificationToken]').val()).done(function (result) {
            let obj = result;
            if (obj.status == true) {
                if (obj.responsecode == '100') {
                    $('#BuyerAddress1').val(obj.data.Table[0].Address1);
                    $('#BuyerAddress2').val(obj.data.Table[0].Address2);
                    $('#BuyerAddress3,#BuyerAddress4').val('');
                }
                else
                    $('#BuyerAddress1,#BuyerAddress2,#BuyerAddress3,#BuyerAddress4').val('');
            }
            else
                window.location.href = '/ClientLogin/ClientLogin';
        }).fail(function (result) {
            console.log(result.Message);
        });
    }
    catch (e) {
        console.log(e.message);
    }
}

//CONSGINEEBUYER CHECKBOX CHANGE EVENT
$('#ConsgineeBuyer').change(function () {
    if (this.checked) {
        $('#HiddenBuyer').val($('#HiddenConsignee').val().trim());
        $('#Buyer').val($('#Consignee').val().trim());
        $('#BuyerAddress1').val($('#ConsigneeAddress1').val().trim());
        $('#BuyerAddress2').val($('#ConsigneeAddress2').val().trim());
        $('#BuyerAddress3').val($('#ConsigneeAddress3').val().trim());
        $('#BuyerAddress4').val($('#ConsigneeAddress4').val().trim());
    }
    else
        $('#HiddenBuyer,#Buyer,#BuyerAddress1,#BuyerAddress2,#BuyerAddress3,#BuyerAddress4').val('');
});

//CONSIGNEEADDRESS1 AND CONSIGNEEADDRESS2 AND CONSIGNEEADDRESS3 AND CONSIGNEEADDRESS4 AND CONSIGNEECOUNTRY TEXTBOX BLUR EVENT
$('#ConsigneeAddress1,#ConsigneeAddress2,#ConsigneeAddress3,#ConsigneeAddress4').on('blur', function () {
    if ($('#ConsgineeBuyer').is(':checked') == true) {
        $('#BuyerAddress1').val($('#ConsigneeAddress1').val().trim());
        $('#BuyerAddress2').val($('#ConsigneeAddress2').val().trim());
        $('#BuyerAddress3').val($('#ConsigneeAddress3').val().trim());
        $('#BuyerAddress4').val($('#ConsigneeAddress4').val().trim());
    }
});

//#endregion

//#region /****************************FORM ADD START**********************/

// FORM ADD BUTTON CLICK EVENT
$("#FormAdd").click(function () {
    if ($('#SelectBranch').val() == 0) {
        Toast('Please Select Branch', 'Message', 'error');
        $("#SelectBranch").focus();
    }
    else if ($('#JobNo').val().trim().length <= 0) {
        Toast('Job Number Error!', 'Message', 'error');
        $('#SubJobNo').focus();
    }
    else if ($("#JobDate").val().trim().length < 10) {
        Toast('Please Select Job Date', 'Message', 'error');
        $("#JobDate").focus();
    }
    else if ($("#HiddenClientName").val().trim().length <= 0) {
        Toast('Please Add Client', 'Message', 'error');
        $("#ClientName").focus();
    } else if ($("#BranchCode").val().trim().length <= 0) {
        Toast('Please Choose Client Address', 'Message', 'error');
        $("#Address").focus();
    } else
        FormAdd();
});

// FUNCTION FOR FORM ADD
function FormAdd() {
    try {
        const dataString = GetJobHeaderData();
        if (dataString == false)
            return;
        let Vflag = 0;

        let ContainerDetails = new Array();
        let InvoiceDetails = new Array();
        let ItemDetails = new Array();
        let PackingDetails = new Array();

        Vflag = ValidateContainerDetailsData(); //VALIDATE CONTAINER DETAILS DATA

        if (Vflag == 0) {
            ContainerDetails = GetContainerDetailsData(); //RETURN CONTAINER DETAILS DATA
            if (!container_num_count)
                return;
            dataString.exportContainerDetails = ContainerDetails;
            //Vflag = ValidateInvoiceDetailsData(); //VALIDATE INVOICE DETAILS DATA
            if (Vflag == 0) {
                InvoiceDetails = GetInvoiceDetailsData(); //RETURN INVOICE DETAILS DATA
                dataString.exportInvoiceDetails = InvoiceDetails;
                Vflag = ValidateNtWtGrWtInVl(); //VALIDATE NET WEIGHT,GROSS WEIGHT AND INVOICE VALUE

                if (Vflag == 0) {
                    //Vflag = ValidateAllInvVlWtAllItem();  //VALIDATE ALL INVOICE WITH VALUE WITH ALL ITEM

                    if (Vflag == 0) {
                        //Vflag = ValidateItemDetailsData();  //VALIDATE ITEM DETAILS DATA
                        Vflag = 0
                        if (Vflag == 0) {

                            ItemDetails = GetItemDetailsData(); //RETURN ITEM DETAILS DATA
                            dataString.exportItemDetails = ItemDetails;
                            // Vflag = ValidateLicenseDetailsData();  //VALIDATE LICENSE DETAILS DATA

                            if (Vflag == 0) {
                                //Vflag = ValidateLicenseDataItemDetailsData()  //VALIDATE ALL ITEM WITH ALL LICENSE                               
                                if (Vflag == 0) {
                                    //LicenseDetails = GetLicenseDetailsData(); //RETURN LICENSE DETAILS DATA
                                    //dataString.licenseDetails = LicenseDetails;

                                    // Vflag = ValidateDestuffDetailsData();  //VALIDATE DESTUFF DETAILS DATA
                                    if (Vflag == 0) {
                                        //DestuffDetails = GetDestuffDetailsData() //RETURN DESTUFF DETAILS DATA
                                        //dataString.destuffDetails = DestuffDetails;

                                        //BondDetails = GetBondDetailsData(); //RETURN BOND DETAILS DATA
                                        //dataString.bondDetails = BondDetails;

                                        //CertificateDetails = GetCertificateDetailsData(); //RETURN CERTIFICATE DETAILS DATA
                                        //dataString.certificateDetails = CertificateDetails;

                                        JobSupportDocsDetails = GetJobSupportDocsDetailsData();  //RETURN JOB SUPPORT DOCS DETAILS DATA
                                        dataString.jobExportSupportDocsDetails = JobSupportDocsDetails;
                                        PackingDetails = GetPackingDetailsData();
                                        dataString.exportPackingDetails = PackingDetails;
                                        AjaxSubmission(JSON.stringify(dataString), "/Master/ExportJobEntry/FormAdd", $('[name="__RequestVerificationToken"]').val()).done(function (result) {
                                            let obj = result;

                                            if (obj.status == true) {
                                                if (obj.responsecode == '101') {
                                                    Toast(RetrieveMessage(obj.responsecode), "Message", "success");
                                                    $("#JobUid").val(obj.data.Table[0].JobUid);
                                                    $("#TimeStamp").val(obj.data.Table[0].TimeStamp);
                                                    $("#FormAdd").hide();
                                                    $("#FormUpdate").show();
                                                    $("#GenCheckList").show();
                                                    $("#GenFlatFile").show();
                                                    $("#FormReset").show();
                                                    $("#UploadDocument").show();
                                                    $("#ExportJob-tab").html("Edit Job");

                                                    FormList(1);
                                                }
                                                else if (obj.responsecode == '703')
                                                    Toast(obj.error, "Message", "error");
                                                else if (obj.responsecode == '1013') {
                                                    JobAc = 1;
                                                    NewJobNoConfirmation();
                                                }

                                                else
                                                    Toast(RetrieveMessage(obj.responsecode), "Message", "error");

                                            } else
                                                window.location.href = '/ClientLogin/ClientLogin';
                                            HideLoader();
                                        }).fail(function (result) {
                                            HideLoader();
                                            console.log(result.message);
                                        });
                                    }
                                }
                            }

                        }
                    }
                }
            }
        }
    }
    catch (e) {
        HideLoader();
        console.log(e.message);
    }
}

//#endregion

//#region /****************************FORM EDIT START**********************/

// FUNCTION FOR FORM EDIT
function FormEdit(e) {
    try {
        $("#UploadDocument").show();
        const dataString = {};
        dataString.JobId = e;
        formid = e;
        AjaxSubmission(JSON.stringify(dataString), "/ExportJobEntry/FormEdit", $('[name="__RequestVerificationToken"]').val()).done(function (data) {
            let obj = data;

            if (obj.status == true) {
                if (obj.responsecode == '100') {
                    TabShow();
                    Fedit = 1;
                    FillLetters(obj.data.Table5[0].JobNo);
                    FillBillDetails(obj.data.Table5[0].JobUid);
                    $('#CreatedByModifiedBy').css('display', 'block');
                    $('#CreatedByModifiedBy').css('width', '100%');
                    FillMainDetialsData(obj.data.Table5[0]);
                    FillContainerDetailsData(obj.data.Table);
                    FillInvoiceDetailsData(obj.data.Table1);
                    FillItemDetailsData(obj.data.Table2);
                    FillPackingDetailsData(obj.data.Table3);
                    FillJobSupportDocDetailsData(obj.data.Table4);
                }
                else
                    Toast(RetrieveMessage(obj.responsecode), "Message", "error");
            }
            else
                window.location.href = '/ClientLogin/ClientLogin';

        }).fail(function (data) {
            console.log(data.Message);
            HideLoader();
        });
    }
    catch (e) {
        console.log(e.message);
    }
}

//#endregion

//#region /****************************FORM UPDATE START**********************/

$("#FormUpdate").click(function () {
    if ($("#JobUid").val().trim().length == 0)
        Toast('JobUid Not Found', 'Message', 'error');
    else if ($('#SelectBranch').val() == 0) {
        Toast('Please Select Branch', 'Message', 'error');
        $("#SelectBranch").focus();
    }
    else if ($('#JobNo').val().trim().length <= 0) {
        Toast('Job Number Error!', 'Message', 'error');
        $('#SubJobNo').focus();
    }
    else if ($("#JobDate").val().trim().length < 10) {
        Toast('Please Select Job Date', 'Message', 'error');
        $("#JobDate").focus();
    }
    else if ($("#HiddenClientName").val().trim().length <= 0) {
        Toast('Please Add Client', 'Message', 'error');
        $("#ClientName").focus();
    } else if ($("#BranchCode").val().trim().length <= 0) {
        Toast('Please Choose Client Address', 'Message', 'error');
        $("#Address").focus();
    } else
        FormUpdate();

});

// FUNCTION FOR FORM UPDATE
function FormUpdate() {
    try {
        const dataString = GetJobHeaderData();
        if (dataString == false)
            return;
        let Vflag = 0;

        let ContainerDetails = new Array();
        let InvoiceDetails = new Array();
        let ItemDetails = new Array();
        let PackingDetails = new Array();

        Vflag = ValidateContainerDetailsData(); //VALIDATE CONTAINER DETAILS DATA

        if (Vflag == 0) {
            ContainerDetails = GetContainerDetailsData(); //RETURN CONTAINER DETAILS DATA
            if (!container_num_count)
                return;
            dataString.exportContainerDetails = ContainerDetails;
            //Vflag = ValidateInvoiceDetailsData(); //VALIDATE INVOICE DETAILS DATA
            if (Vflag == 0) {
                InvoiceDetails = GetInvoiceDetailsData(); //RETURN INVOICE DETAILS DATA
                dataString.exportInvoiceDetails = InvoiceDetails;
                Vflag = ValidateNtWtGrWtInVl(); //VALIDATE NET WEIGHT,GROSS WEIGHT AND INVOICE VALUE

                if (Vflag == 0) {
                    //Vflag = ValidateAllInvVlWtAllItem();  //VALIDATE ALL INVOICE WITH VALUE WITH ALL ITEM

                    if (Vflag == 0) {
                        //Vflag = ValidateItemDetailsData();  //VALIDATE ITEM DETAILS DATA
                        Vflag = 0
                        if (Vflag == 0) {

                            ItemDetails = GetItemDetailsData(); //RETURN ITEM DETAILS DATA
                            dataString.exportItemDetails = ItemDetails;
                            // Vflag = ValidateLicenseDetailsData();  //VALIDATE LICENSE DETAILS DATA

                            if (Vflag == 0) {
                                //Vflag = ValidateLicenseDataItemDetailsData()  //VALIDATE ALL ITEM WITH ALL LICENSE                               
                                if (Vflag == 0) {
                                    //LicenseDetails = GetLicenseDetailsData(); //RETURN LICENSE DETAILS DATA
                                    //dataString.licenseDetails = LicenseDetails;

                                    // Vflag = ValidateDestuffDetailsData();  //VALIDATE DESTUFF DETAILS DATA
                                    if (Vflag == 0) {
                                        //DestuffDetails = GetDestuffDetailsData() //RETURN DESTUFF DETAILS DATA
                                        //dataString.destuffDetails = DestuffDetails;

                                        //BondDetails = GetBondDetailsData(); //RETURN BOND DETAILS DATA
                                        //dataString.bondDetails = BondDetails;

                                        //CertificateDetails = GetCertificateDetailsData(); //RETURN CERTIFICATE DETAILS DATA
                                        //dataString.certificateDetails = CertificateDetails;

                                        JobSupportDocsDetails = GetJobSupportDocsDetailsData();  //RETURN JOB SUPPORT DOCS DETAILS DATA
                                        dataString.jobExportSupportDocsDetails = JobSupportDocsDetails;
                                        PackingDetails = GetPackingDetailsData();
                                        dataString.exportPackingDetails = PackingDetails;
                                        AjaxSubmission(JSON.stringify(dataString), "/Master/ExportJobEntry/FormUpdate", $('[name="__RequestVerificationToken"]').val()).done(function (result) {
                                            let obj = result;
                                            console.log(obj);
                                            if (obj.status == true) {
                                                //if (obj.responsecode == '101') {
                                                //    console.log(obj,'asdf');
                                                //    Toast(RetrieveMessage(obj.responsecode), "Message", "success");
                                                //    $("#JobUid").val(obj.data.Table[0].JobUid);
                                                //    $("#TimeStamp").val(obj.data.Table[0].TimeStamp);
                                                //    $("#FormAdd").hide();
                                                //    $("#FormUpdate").show();
                                                //    $("#GenCheckList").show();
                                                //    $("#GenFlatFile").show();
                                                //    $("#FormReset").show();
                                                //    $("#ExportJob-tab").html("Edit Job");
                                                //    $('#AddNewJobESanchit').removeClass('d-none');

                                                //    FormList(1);
                                                //}
                                                //else if (obj.responsecode == '703')
                                                //    Toast(obj.error, "Message", "error");
                                                //else if (obj.responsecode == '1013') {
                                                //    JobAc = 1;
                                                //    NewJobNoConfirmation();
                                                //}

                                                //else
                                                //    Toast(RetrieveMessage(obj.responsecode), "Message", "error");
                                                if (obj.status == true) {
                                                    if (obj.responsecode == '107') {
                                                        Toast(RetrieveMessage(obj.responsecode), "Message", "success");
                                                        $("#JobUid").val(obj.data.Table[0].JobUid);
                                                        $("#TimeStamp").val(obj.data.Table[0].TimeStamp);
                                                        FormList(1);
                                                    }
                                                    else if (obj.responsecode == '703')
                                                        Toast(obj.error, "Message", "error");
                                                    else if (obj.responsecode == '1013')
                                                        Toast('Job Number Already Exist', 'Message', 'error');
                                                    else
                                                        Toast(RetrieveMessage(obj.responsecode), "Message", "error", 2500);
                                                }
                                            } else
                                                window.location.href = '/ClientLogin/ClientLogin';
                                            HideLoader();
                                        }).fail(function (result) {
                                            HideLoader();
                                            console.log(result.message);
                                        });
                                    }
                                }
                            }

                        }
                    }
                }
            }
        }
    }
    catch (e) {
        console.log(e.message);
    }
}

//#endregion

//#region /****************************FORM DELETE START**********************/

function FormDelete(id) {
    try {

        $.confirm({
            title: '',
            content: 'Are You Sure Want To Delete ?',
            type: 'red',
            boxWidth: '300px',
            useBootstrap: false,
            typeAnimated: true,
            columnClass: 'small',
            containerFluid: true,
            draggable: true,
            buttons: {
                tryAgain: {
                    text: 'Confirm',
                    btnClass: 'btn-red',
                    action: function () {

                        const dataString = {};
                        dataString.JobUid = id;
                        AjaxSubmission(JSON.stringify(dataString), "/ExportJobEntry/FormDelete", $('[name="__RequestVerificationToken"]').val()).done(function (data) {
                            let obj = data;
                            if (obj.status == true) {

                                if (obj.responsecode == '102') {
                                    Toast(RetrieveMessage(obj.responsecode), "Message", "success");
                                    FormList(1);
                                }
                                else
                                    Toast(RetrieveMessage(obj.responsecode), "Message", "error");
                            }
                            else
                                window.location.href = '/ClientLogin/ClientLogin';
                            //Hideloader();
                        }).fail(function (data) {
                            console.log(data.Message);
                            //Hideloader();
                        });
                    }
                },
                close: function () {

                }
            }
        });

    }
    catch (e) {
        console.log(e.message);
        //Hideloader();
    }
}

//#endregion

//#region /****************************COMMON FUNCTION START**********************/

//FOR TODAY DATE
jQuery.datepicker._gotoToday = function (id) {
    let today = new Date();
    let dateRef = jQuery("<td><a>" + today.getDate() + "</a></td>");
    this._selectDay(id, today.getMonth(), today.getFullYear(), dateRef);
};

//DATEPICKER FOR JOBDATE
$('#JobDate').datepicker({
    toolbarPlacement: 'bottom',
    showButtonPanel: true,
    changeMonth: true,
    changeYear: true,
    dateFormat: 'dd/mm/yy',
    onClose: function (e) {
        GetJobNo($('#JobType').val());
    }
});

//DATEPICKER FOR SEARCHJOBDATEFROM AND SEARCHJOBDATETO
$('#SearchJobDateFrom,#SearchJobDateTo').datepicker({
    toolbarPlacement: 'bottom',
    showButtonPanel: true,
    changeMonth: true,
    changeYear: true,
    dateFormat: 'dd/mm/yy',
    onClose: function () {
        if ($('#SearchJobDateFrom').val().length == 10 || $('#SearchJobDateTo').val().length == 10)
            CompareSearchDate($('#SearchJobDateFrom').val(), $('#SearchJobDateTo').val(), 'Job Date');
    }
});

//DATEPICKER FOR SEARCHSHIPPINGBILLDATEFROM AND SEARCHSHIPPINGBILLDATETO
$('#SearchSBDateFrom,#SearchSBDateTo').datepicker({
    toolbarPlacement: 'bottom',
    showButtonPanel: true,
    changeMonth: true,
    changeYear: true,
    dateFormat: 'dd/mm/yy',
    onClose: function () {
        if ($('#SearchSBDateFrom').val().length == 10 || $('#SearchSBDateTo').val().length == 10)
            CompareSearchDate($('#SearchSBDateFrom').val(), $('#SearchSBDateTo').val(), 'ShippingBill Date');
    }
});

//JOB DATE INPUT EVENT
$('#JobDate').on('input', function () {
    GetJobNo($('#JobType').val());
});

//SELECT BRANCH DROPDOWN CHANGE EVENT
$("#SelectBranch").change(function () {
    GetJobNo($('#JobType').val());
});

//SUB JOB NUMBER TEXT BLUR EVENT
$("#SubJobNo").blur(function () {
    GetJobNo($('#JobType').val());
});

//FUNCTION FOR GET JOB NUMBER
function GetJobNo(JobType) {
    try {
        if ($('#SelectBranch').val() > 0 && $('#JobDate').val().trim().length == 10) {
            const dataString = {};
            dataString.BranchId = $('#SelectBranch').val();
            dataString.JobDate = $('#JobDate').val();
            if (jobflag != 1) {
                dataString.SubJobNo = $('#SubJobNo').val();
            }
            dataString.JobUid = $('#JobUid').val();
            dataString.JobType = JobType;
            AjaxSubmission(JSON.stringify(dataString), '/_Layout/GetJobno', $('[name="__RequestVerificationToken"]').val()).done(function (result) {
                let obj = result;
                if (obj.status == true) {
                    if (obj.responsecode == '100') {
                        if (obj.data.Table[0].In_Valid_Job_No == false) {
                            $('#JobNo,#SubJobNo').val('');
                            $('#JobNo').val(obj.data.Table[0].job_no);
                            $('#SubJobNo').val(obj.data.Table[0].sub_job_no);
                            if (jobflag == 1) {
                                if (JobAc == 1) {
                                    jobflag = 0;
                                    JobAc = 0;
                                    FormAdd();
                                }
                                else if (JobAc == 2) {
                                    jobflag = 0;
                                    JobAc = 0;
                                    FormUpdate();
                                }

                            }
                        }
                        else
                            Toast('Job Number Already Exist', 'Message', 'error');
                    }
                    else
                        Toast(RetrieveMessage(obj.responsecode), 'Message', 'error');

                }
                else
                    window.location.href = '/ClientLogin/ClientLogin';


            }).fail(function (result) {
                console.log(result.message);
            });

        } else
            $('#JobNo,#SubJobNo').val('');
    }
    catch (e) {
        console.log(e.message);
    }
}

// FUNCTION FOR NEW JOB NUMBER CONFIRMATION
function NewJobNoConfirmation() {
    try {
        $.confirm({
            title: '',
            content: 'This Job Number has been used.',
            type: 'green',
            boxWidth: '300px',
            useBootstrap: false,
            typeAnimated: true,
            columnClass: 'small',
            containerFluid: true,
            draggable: true,
            buttons: {
                tryAgain: {
                    text: 'Confirm',
                    btnClass: 'btn-green',
                    action: function () {
                        jobflag = 1;
                        GetJobNo($('#JobType').val());
                    }
                },
                cancel: function () {
                    $('#JobDate').focus();
                }
            }
        });
    }
    catch (e) {
        console.log(e.message);
    }
};

//FOR ALL DATEPICKER
$('.datepickerAll').datepicker({
    toolbarPlacement: 'bottom',
    showButtonPanel: true,
    changeMonth: true,
    changeYear: true,
    dateFormat: 'dd/mm/yy',

});

//PAGE SIZE CHANGE
$('#ddlPageSize').change(function () {
    FormList(1);
});

// PAGINATION BUTTON CLICKED
$(document).on('click', '.pagination .page', function () {
    FormList(($(this).attr('page')));
});

//FORMSEARCH BUTTON CLICK 
$('#FormSearch').click(function () {
    FormList(1);
});

//ALL INPUT TYPE SEARCH TEXT BOX WHEN ENTER KEY PRESS
$('#SearchJobDateFrom,#SearchJobDateTo,#SearchSubJobNo,#SearchJobNo,#SearchClient,#SearchNetWeight,#SearchSBNo,#SearchSBDateFrom,#SearchSBDateTo,#SearchPortLoading,#SearchPortDischarge,#SearchDeliveryPlace,#SearchContainerNo').bind('keypress', function (e) {
    if (e.keyCode == 13) {
        $("#FormSearch").trigger('click');
    }
});

//FUNCTION FOR GET FORM LIST DATA
function FormList(PageIndex) {
    try {

        const dataString = {};
        dataString.PageSize = $('#ddlPageSize').val();
        dataString.PageIndex = PageIndex;
        dataString.OrderBy = $('#sort-column').val().trim() + ' ' + $('#sort-type').val().trim();
        dataString.SearchJobDateFrom = $('#SearchJobDateFrom').val();
        dataString.SearchJobDateTo = $('#SearchJobDateTo').val();
        dataString.SearchSubJobNo = $('#SearchSubJobNo').val().trim();
        dataString.SearchJobNo = $('#SearchJobNo').val();
        dataString.SearchClient = $('#HiddenSearchClient').val().trim();
        dataString.SearchSBNo = $('#SearchSBNo').val().trim();
        dataString.SearchSBDateFrom = $('#SearchSBDateFrom').val();
        dataString.SearchSBDateTo = $('#SearchSBDateTo').val();
        dataString.SearchPortLoading = $('#SearchPortLoading').val();
        dataString.SearchPortDischarge = $('#SearchPortDischarge').val().trim();
        dataString.SearchDeliveryPlace = $('#SearchDeliveryPlace').val().trim();
        dataString.SearchContainerNo = $('#SearchContainerNo').val().trim();
        dataString.PendingJob = $('#PendingJob').is(':checked');
        dataString.ClearedJob = $('#ClearedJob').is(':checked');
        dataString.BilledJob = $('#BilledJob').is(':checked');
        dataString.UnBilledJob = $('#UnBilledJob').is(':checked');
        dataString.SearchNetWeight = HandleNullNumericValue($('#SearchNetWeight').val().trim());
        dataString.SearchSelectBranch = $('#SearchSelectBranch').val();
        dataString.SearchSBType = $('#SearchSBType').val();
        ShowLoader();

        AjaxSubmission(JSON.stringify(dataString), '/Master/ExportJobEntry/FormList', $('input[name=__RequestVerificationToken]').val()).done(function (result) {

            let obj = result;
            if (obj.status == true) {
                if (obj.responsecode == '100') {
                    var Ser = ((parseInt(obj.data.Table1[0].PageIndex) - 1) * parseInt(obj.data.Table1[0].PageSize)) + 1;
                    BindFormTable(obj.data.Table, Ser);
                    $('.pagination').BindPaging({
                        ActiveCssClass: 'current',
                        PagerCssClass: 'pager',
                        PageIndex: parseInt(obj.data.Table1[0].PageIndex),
                        PageSize: parseInt(obj.data.Table1[0].PageSize),
                        RecordCount: parseInt(obj.data.Table1[0].count)
                    });
                    if (firssr == 1) {
                        $('#TblExport tbody tr').each(function (ind, ele) {
                            if (ind == 0) {
                                $(ele).find('.Edit').focus();
                                return;
                            }
                        });
                    }
                    else
                        $('#SearchSubJobNo').focus();
                    firssr = 1;

                }
                else if (obj.responsecode == "703")
                    Toast(obj.error, 'Message', 'error');
                else
                    Toast(RetrieveMessage(obj.responsecode), 'Message', 'error');

            } else
                window.location.href = '/ClientLogin/ClientLogin';
            HideLoader();

        }).fail(function (result) {
            console.log(result.Message);
            HideLoader();
        });
    }
    catch (e) {
        console.log(e.message);
        HideLoader();
    }
}

//FUNCTION  FOR BIND FORM TABLE
function BindFormTable(Result, SerialNo) {
    let tr = "";
    $("#TblExport tbody tr").remove();

    if (Result.length == 0) {

        tr = "<tr>";
        tr += "<td class='text-center' colspan='20'>NO RECORDS FOUND</td></tr>";
        $("#TblExport tbody").html(tr);

    }
    else {
        for (i = 0; i < Result.length; i++) {
            if (HandleNullTextValue(Result[i].SBNo) == '')
                tr += '<tr style="background-color:#fdd2d2;"/>';
            else if (HandleNullTextValue(Result[i].SBNo) != '')
                tr += "<tr>";
            else
                tr += "<tr>";

            tr += "<td class='text-left'><button type='button' title='Edit Job' onclick='FormEdit(\"" + Result[i].JobUid + "\");' class= 'Edit common-btn common-btn-sm ms-1' ><i class='fa-solid fa-pen-to-square'></i></button > <button type='button' title='Delete Job' onclick='FormDelete(\"" + Result[i].JobUid + "\");' class= 'Delete common-btn common-btn-sm ms-1' > <i class='fa-regular fa-trash-can'></i></button> <button type='button' title='Check List' onclick='ImportCheckList(\"" + Result[i].JobUid + "\");' class= ' common-btn common-btn-sm ms-1' > <i class='fa-solid fa-list-check'></i></button> <button type='button' title='Generate Flat File' onclick='GenerateFlatFile(\"" + Result[i].JobUid + "\");' class= ' common-btn common-btn-sm ms-1'><i class='fa-regular fa-file'></i></button> </td>";

            tr += "<td class='text-left'>" + SerialNo + "</td>";
            tr += "<td class='text-left'>" + Result[i].BranchName + "</td>";
            tr += "<td class='text-left fw-bold'>" + Result[i].SubJobNo + "</td>";
            tr += "<td><a href='javascript:void(0)' class='text-decoration-none fw-bold' style='color: black !important;' onclick='FormEdit(\"" + Result[i].JobUid + "\");'>" + Result[i].JobNo + "</a></td>";
            tr += "<td class='text-center'>" + Result[i].JobDate + "</td>";
            tr += "<td class='text-center'>" + HandleNullTextValue(Result[i].SBType) + "</td>";
            tr += "<td class='text-left'>" + HandleNullTextValue(Result[i].SBNo) + "</td>";
            tr += "<td class='text-center'>" + HandleNullTextValue(Result[i].SBDate) + "</td>";
            tr += "<td class='text-left'>" + HandleNullTextValue(Result[i].ClientName) + "</td>";
            tr += "<td class='text-left'>" + HandleNullTextValue(Result[i].ItemCode) + "</td>";
            tr += "<td class='text-left'>" + HandleNullTextValue(Result[i].NoOfPkgs) + "</td>";
            tr += "<td class='text-left'>" + HandleNullTextValue(Result[i].NoOfContainer) + "</td>";
            tr += "<td class='text-end'>" + (Result[i].TotalNetWeight == null ? ' ' : Result[i].TotalNetWeight.toFixed(3)) + "</td>";

            tr += "<td class='text-center'>" + HandleNullTextValue(Result[i].CreatedBy) + "</td>";
            tr += "<td class='text-center'>" + HandleNullTextValue(Result[i].CreatedAt) + "</td>";
            tr += "<td class='text-center'>" + HandleNullTextValue(Result[i].LastUpdatedBy) + "</td>";
            tr += "<td class='text-center'>" + HandleNullTextValue(Result[i].LastUpdatedAt) + "</td>";

            let Finyr = Result[i].FinYr;

            let GenLink = "";
            if (Result[i].AllBillUid != null) {
                let AllBillUid = Result[i].AllBillUid.split(",");
                let AllBillNo = Result[i].AllBillNo.split(",");
                let AllFinyrId = Result[i].AllFinYrId.split(",");
                $.each(AllBillUid, function (ind, ele) {

                    if (AllFinyrId[ind] == Finyr)
                        GenLink += "<a href='javascript:void(0)' class='text-break text-decoration-none fw-bold BillLink' onclick='EditBillDetails(\"" + ele + "\");'>" + AllBillNo[ind] + "</a> ";
                    else
                        GenLink += AllBillNo[ind] + " ";
                });

                tr += "<td class='text-end'>" + GenLink + "</td>";

            }
            else {
                tr += "<td class='text-end'>" + GenLink + "</td>";

                tr += "<td class='text-end'>" + (Result[i].TotalBillAmount == null ? '0.00' : Result[i].TotalBillAmount.toFixed(2)) + "</td>";

                SerialNo++;

            }
            $("#TblExport tbody").html(tr);

        }
    }

}

//FUNCTION FOR FORM SORTING
function FormSorting(obj) {
    if (Firstcolumn != "") {
        document.getElementById(Firstcolumn).innerHTML = document.getElementById(Firstcolumn).getAttribute("data-column") + " <i style='margin-left:10px;' class='fa-solid fa-sort'></i>";
    }
    let cn = obj.id;
    Firstcolumn = cn;
    var colname = $(obj).data("column");
    $("#sort-column").val(cn.replaceAll("_", ""));
    var sorttype = $("#sort-type").val();
    if (sorttype == "ASC") {
        $("#sort-type").val("DESC");
        $(obj).html(colname + " <i style='margin-left:10px;' class='fa-solid fa-sort-down'></i>");
    } else if (sorttype == "DESC") {
        $("#sort-type").val("ASC");
        $(obj).html(colname + " <i style='margin-left:10px;' class='fa-solid fa-sort-up'></i>");
    }
    FormList(1);
}

//FUNCTION FOR GET FINANCIAL YEAR DATE
function GetFinancialYearDate() {
    try {
        AjaxSubmission(null, '/_Layout/GetFinancialYearDate', $('[name="__RequestVerificationToken"]').val()).done(function (result) {
            let obj = result;
            if (obj.status == true) {
                if (obj.responsecode == '100') {
                    $('#SearchJobDateFrom').val(obj.data.Table[0].finyr_start_date);
                    $('#SearchJobDateTo').val(obj.data.Table[0].finyr_end_date);
                }
            }
            else
                window.location.href = '/ClientLogin/ClientLogin';

        }).fail(function (result) {
            console.log(result.message);
        });
    }
    catch (e) {
        console.log(e.message);
    }
}

//SEARCH ARROW UP/DOWN
$('#oko').click(function () {
    if (srbtn == 'up') {
        $('#icn').html("<i class='fa-solid fa-angle-down'></i>");
        srbtn = 'down';
    } else {
        $('#icn').html("<i class='fa-solid fa-angle-up'></i>");
        srbtn = 'up';
    }
});

// GOTOCONTAINERDETAILSTAB BUTTON CLICK EVENT
$('#GoToContainerDetailsTab').click(function () {
    $('#ShipmentDetails-tab').removeClass('active');
    $('#ContainerDetails-tab').addClass('active');
    $('#ShipmentDetails').removeClass('active show');
    $('#ContainerDetails').addClass('active show');
});

// BACKTOSHIPMENTDETAILSTAB BUTTON CLICK EVENT
$('#BackToShipmentDetailsTab').click(function () {
    $('#ContainerDetails-tab').removeClass('active');
    $('#ShipmentDetails-tab').addClass('active');
    $('#ContainerDetails').removeClass('active show');
    $('#ShipmentDetails').addClass('active show');
});

// GOTOINVOICEDETAILSTAB BUTTON CLICK EVENT
$('#GoToInvoiceDetailsTab').click(function () {
    $('#ContainerDetails-tab').removeClass('active');
    $('#InvoiceDetails-tab').addClass('active');
    $('#ContainerDetails').removeClass('active show');
    $('#InvoiceDetails').addClass('active show');
});

// BACKTOCONTAINERDETAILSTAB BUTTON CLICK EVENT
$('#BackToContainerDetailsTab').click(function () {
    $('#InvoiceDetails-tab').removeClass('active');
    $('#ContainerDetails-tab').addClass('active');
    $('#InvoiceDetails').removeClass('active show');
    $('#ContainerDetails').addClass('active show');
});

// GOTOEDIDETAILSTAB BUTTON CLICK EVENT
$('#GoToEDIDetailsTab').click(function () {
    $('#InvoiceDetails-tab').removeClass('active');
    $('#EDIDetails-tab').addClass('active');
    $('#InvoiceDetails').removeClass('active show');
    $('#EDIDetails').addClass('active show');
});

// BACKTOINVOICEDETAILSTAB BUTTON CLICK EVENT
$('#BackToInvoiceDetailsTab').click(function () {
    $('#EDIDetails-tab').removeClass('active');
    $('#InvoiceDetails-tab').addClass('active');
    $('#EDIDetails').removeClass('active show');
    $('#InvoiceDetails').addClass('active show');
});

// GOTOITEMDETAILSTAB BUTTON CLICK EVENT
$('#GoToItemDetailsTab').click(function () {
    $('#EDIDetails-tab').removeClass('active');
    $('#ItemDetails-tab').addClass('active');
    $('#EDIDetails').removeClass('active show');
    $('#ItemDetails').addClass('active show');
});

// BACKTOEDIDETAILSTAB BUTTON CLICK
$('#BackToEDIDetailsTab').click(function () {
    $('#EDIDetails-tab').addClass('active');
    $('#ItemDetails-tab').removeClass('active');
    $('#EDIDetails').addClass('active show');
    $('#ItemDetails').removeClass('active show');
});

//GOTOPACKINGDETAILSTAB BUTTON CLICK EVENT
$('#GoToFactoryStuffPackingDetailsTab').click(function () {
    $('#ItemDetails-tab').removeClass('active');
    $('#PackingDetails-tab').addClass('active');
    $('#ItemDetails').removeClass('active show');
    $('#PackingDetails').addClass('active show');
})

//BACKTOITEMDETAILSTAB BUTTON CLICK EVENT
$('#BackToItemDetailsTab').click(function () {
    $('#PackingDetails-tab').removeClass('active');
    $('#ItemDetails-tab').addClass('active');
    $('#PackingDetails').removeClass('active show');
    $('#ItemDetails').addClass('active show');
});

//GOTOESANCHITDETAILSTAB BUTTON CLICK EVENT
$('#GoToESanchitDetailsTab').click(function () {
    $('#PackingDetails-tab').removeClass('active');
    $('#ESanchitDetails-tab').addClass('active');
    $('#PackingDetails').removeClass('active show');
    $('#ESanchitDetails').addClass('active show');
})

//BACKTOPACKINGDETAILSTAB BUTTON CLICK EVENT
$('#BackToPackingDetailsTab').click(function () {
    $('#ESanchitDetails-tab').removeClass('active');
    $('#PackingDetails-tab').addClass('active');
    $('#ESanchitDetails').removeClass('active show');
    $('#PackingDetails').addClass('active show');
});

//FACTORYSTUFF CHECKBOX CHANGE EVENT
$('#FactoryStuff').change(function () {
    if (this.checked) {
        $('#WhetherSampleAccompanied, #SelfSealing, #CentralExciseSealing').prop('disabled', false);
        $('#SealingAgency,#FactNameAddr').removeAttr('disabled');
    }
    else {
        $('#WhetherSampleAccompanied, #SelfSealing, #CentralExciseSealing').prop('disabled', true);
        $('#WhetherSampleAccompanied,#CentralExciseSealing,#SelfSealing').prop('checked', false);
        $('#SealingAgency,#FactNameAddr').attr('disabled', 'disabled').val('');
    }
});

//SELFSEALING,CENTRALEXCISESEALING CHECKBOX EVENT
$('#SelfSealing, #CentralExciseSealing').change(function () {
    if (this.id === 'SelfSealing' && this.checked) {
        $('#CentralExciseSealing').prop('checked', false);
    } else if (this.id === 'CentralExciseSealing' && this.checked) {
        $('#SelfSealing').prop('checked', false);
    }
});

//EXPORT JOB LIST TAB CLICKED
$("#ExportJob_list-tab").click(function () {
    $("#SearchSubJobNo").focus();
    ResetForm();
    TabHide();
    $('#uju').removeAttr('style');
});

//EXPORT JOB TAB CLCIKED
$("#ExportJob-tab").click(function () {
    $('#uju').removeAttr('style');
    $("#SubJobNo").focus();

});

//LETTERS DETAILS TAB AND BILL DETAILS TAB AND DOCUMENT DETAILS TABCLICKED
$("#LettersDetails-tab,#BillDetails-tab,#DocumentDetails-tab").click(function () {
    $('#uju').css({ 'overflow': 'scroll', 'height': parseInt(screen.height) - 335 });
});

//FUCNTION FOR TAB SHOW
function TabShow() {
    $('#ExportJob_list-tab').removeClass('active');
    $('#ExportJob-tab').addClass('active');
    $('#ExportJob_list').removeClass('active show');
    $('#ExportJob').addClass('active show');

    $('#FormAdd').hide();
    $('#FormUpdate,#FormReset,#GenFlatFile,#GenCheckList').show();

    $('#ExportJob-tab').html('Edit Job');

    $('#LettersDetails-tab,#BillDetails-tab,#DocumentDetails-tab').removeClass('d-none');
}

//FUNCTION FOR TAB HIDE
function TabHide() {
    $('#ExportJob-tab').removeClass('active');
    $('#ExportJob_list-tab').addClass('active ');
    $('#ExportJob_list').addClass('active show');
    $('#ExportJob').removeClass('active show');
    $('#FormAdd').show();
    $('#FormUpdate,#FormReset,#GenFlatFile,#GenCheckList').hide();

    $('#ExportJob-tab').html('Add Job');

    $('#TblLetters tbody,#BillDetails tbody,#DocumentDetails tbody').html('');
    $('#LettersDetails-tab,#BillDetails-tab,#DocumentDetails-tab').addClass('d-none');

}

//FORM RESET BUTTON CLICKED
$('#FormReset').click(function () {
    $('#FormAdd').show();
    $('#FormUpdate,#FormReset,#GenFlatFile,#GenCheckList').hide();
    $('#ExportJob-tab').html('Add Job');
    ResetForm();
});

// FUNCTION FOR RESET EXPORT JOB DATA
function ResetForm() {
    $("#collapseExample").addClass('show');
    $("#icn").html("<i class='fa-solid fa-angle-up'></i>");
    srbtn = 'up';
    $("#JobUid").val('');
    $("#TimeStamp").val('');
    $("#SelectBranch").val(0);
    $("#IceGateUserId").val(0);
    $("#JobNo").val('');
    $("#SubJobNo").val('');
    $("#JobCancel").prop('checked', false);
    $("#HiddenClientName").val('');
    $("#ClientName").val('');
    $("#Address").html('');
    $("#BranchCode").val('');
    $("#HiddenAdCode").val('');
    $("#AdCode").val('');
    $("#SBType").val('DUTY FREE');
    $("#SBNo").val('');
    $("#SBDate").val('');
    $("#ModeOfTransport").val('L');
    $("#CustomPortCode").val('');
    $("#CustomPortName").val('');
    $("#VslName").val('');
    $("#VoyageNo").val('');
    $("#VIANo").val('');
    $("#BookingNo").val('');
    $("#BookedBy").val('');
    $("#RbiWaiverNumber").val('');
    $("#RbiWaiverDate").val('');
    $("#EPZCode").val('');
    $("#HiddenPortLoading").val('');
    $("#PortLoading").val('');
    $("#HiddenPortFinalDestination").val('');
    $("#PortFinalDestination").val('');
    $("#HiddenCountryFinalDestination").val('');
    $("#CountryFinalDestination").val('');
    $("#HiddenCountryDischarge").val('');
    $("#CountryDischarge").val('');
    $("#HiddenPortDischarge").val('');
    $("#PortDischarge").val('');
    $("#MBLNo").val('');
    $("#MBLDate").val('');
    $("#HBLNo").val('');
    $("#HBLDate").val('');
    $("#MAWBNo").val('');
    $("#MAWBDate").val('');
    $("#HAWBNo").val('');
    $("#HAWBDate").val('');
    $("#BoxTypeNo").val('');
    $("#HiddenBoxType").val('');
    $("#BoxType").val('');
    $("#ContainerTypeNo").val('');
    $("#HiddenContainerType").val('');
    $("#ContainerType").val('');
    $("#BalesTypeNo").val('');
    $("#HiddenBalesType").val('');
    $("#BalesType").val('');
    $("#LoosePackets").val('');
    $("#StateOfOrigin").val('0').trigger('change');
    $("#ExporterClass").val('P');
    $("#ExporterType").val('M');
    $("#NatureOfCargo").val('C');
    $("#FactoryStuff,#WhetherSampleAccompanied,#SelfSealing,#CentralExciseSealing").prop('checked', false);
    $("#WhetherSampleAccompanied,#SelfSealing,#CentralExciseSealing,#SealingAgency,#FactNameAddr").prop("disabled", true);
    $("#SealingAgency").val('');
    $("#FactNameAddr").val('');
    $("#TotalNetWeight").val('0.000');
    $("#TotalGrossWeight").val('0.000');
    $("#TotalInvoiceValue").val('0.00');
    $("#DutyAmount").val('0.00');
    $("#ClientRemarks").val('');
    $("#Remarks").val('');
    $("#MarksNo").val('');
    $("#PaymentTerms").val('DP');
    $("#PeriodOfPayment").val('');
    $("#HiddenConsignee").val('');
    $("#Consignee").val('');
    $("#ConsigneeAddress1").val('');
    $("#ConsigneeAddress2").val('');
    $("#ConsigneeAddress3").val('');
    $("#ConsigneeAddress4").val('');
    $("#HiddenConsigneeCountry").val('');
    $("#ConsigneeCountry").val('');
    $("#HiddenThirdParty").val('');
    $("#ThirdParty").val('');
    $("#ThirdPartyAddress").html('');
    $("#ThirdPartyAddress1").val('');
    $("#ThirdPartyAddress2").val('');
    $("#HiddenThirdPartyCountry").val('');
    $("#ThirdPartyCountry").val('');
    $("#HiddenThirdPartyState").val('');
    $("#ThirdPartyState").val('');
    $("#ThirdPartyCity").val('');
    $("#ThirdPartyPinCode").val('');
    $("#ConsgineeBuyer").prop('checked', false);
    $("#HiddenBuyer").val('');
    $("#Buyer").val('');
    $("#BuyerAddress1").val('');
    $("#BuyerAddress2").val('');
    $("#BuyerAddress3").val('');
    $("#BuyerAddress4").val('');
    $("#RotationNo").val('');
    $("#RotationDate").val('');
    $('#UploadDocument').hide();

    $("#CreatedBy").text('');
    $("#CreatedAt").text('');

    $("#ModifiedBy").text('');
    $("#ModifiedAt").text('');
    $("#CreatedByModifiedBy").css('display', 'none');

    $("#CrBy").addClass('d-none');
    $("#CrDt").addClass('d-none');
    $("#MoBy").addClass('d-none');
    $("#MoDt").addClass('d-none');

    $('#TblLetters tbody').html('');
    $('#LettersDetails-tab').addClass('d-none');
    $('#BillDetails tbody').html('');
    $('#BillDetails-tab').addClass('d-none');
    $('#DocumentDetails tbody').html('');
    $('#DocumentDetails-tab').addClass('d-none');

    $("#ContainerDetails-tab,#InvoiceDetails-tab,#EDIDetails-tab,#ItemDetails-tab,#PackingDetails-tab,#ESanchitDetails-tab").removeClass('active');
    $("#ContainerDetails,#InvoiceDetails,#EDIDetails,#ItemDetails,#PackingDetails,#ESanchitDetails").removeClass('active show');
    $("#ShipmentDetails-tab").addClass('active');
    $("#ShipmentDetails").addClass('active show');

    //CONTAINER DETAILS RESET START
    $('#TblContainerDetails tbody tr').each(function (ind, ele) {
        if (ind == 0) {
            $(ele).find('.ContainerNo,.HiddenContType,.ContType,.SealNo ,.ExciseSealNumber,.SealDate,.SealDeviceId,.NoOfPackage,.HiddenPackageType,.PackageType,.HiddenTransporter,.Transporter,.TruckNo,.PickupDate,.StuffingDate,.PortGateInDate,.ContainerRemarks').val('');
            $(ele).find('.NetWeight,.GrossWeight,.TareWeight,.VGMWeight').val('0.000');
            $(ele).find('.SealType').val('BTSL');
            $(ele).find('.NetWeightType').val('KGS');
        }

        else
            $(ele).remove();
    });

    //CONTAINER DETAILS RESET END

    //INVOICE DETAILS RESET START

    ResetNewInvoice();

    $('#TblInvoiceDetails tbody tr').each(function (ind, ele) {
        if (ind == 0) {
            $(ele).find('.Relation').val('N'); $(ele).find('.InvoiceNo,.InvoiceDate,.HiddenInvoiceCurrency,.InvoiceCurrency,.HiddenFreightCurrency,.FreightCurrency,.HiddenInsuranceCurrency,.InsuranceCurrency,.HiddenCommissionCurrency,.CommissionCurrency,.HiddenDiscountCurrency,.DiscountCurrency,.HiddenOtherChargesCurrency,.OtherChargesCurrency,.NetUnit').val('');

            $(ele).find('.NatureOfTransaction').val(0);
            $(ele).find('.NatureOfContract').val(0);
            $(ele).find('.InvoiceCurrencyExchangeRate,.InvoiceValue,.ActualFreight,.FreightExchangeRate,.ActualInsurance,.InsuranceExchangeRate,.InsuranceINR,.ActualCommission,.CommissionExchangeRate,.CommissionINR,.ActualDiscount,.DiscountExchangeRate,.DiscountINR,.MiscCharges,.MiscChargesINR,.ActualOtherCharges,.OtherChargesExchangeRate,.OtherChargesExchangeRate,.OtherChargesINR,.FOBValue,.PMVRateInvoice,.PMVRateInvoice,.PMVQuantity,.PMVValue,.FreightINR').val('0.00');
            $(ele).find('.NetWeightMetric,.GrossWeightKg').val('0.000');
            $(ele).find('.FreightPer,.InsurancePer,.CommissionPer,.DiscountPer,.OtherChargesPer').val('0.0000');
        }
        else
            $(ele).remove();
    });

    //INVOICE DETAILS RESET END

    //ITEM DETAILS RESET START

    ResetNewItem();

    $('#TblItemDetails tbody tr').each(function (ind, ele) {
        if (ind == 0) {
            $(ele).find('.TblItemInvoiceNo,.TblItemName,.TblItemDescription,.TblItemEndUse,.TblItemEndUseDesc,.TblUnitQuantityCode,.TblItemManufacturerProducerGrowerName,.TblItemManufacturerProducerCodeType,.TblItemManufacturerProducerGrowerCode,.TblItemManufacturerProducerGrowerAddress1,.TblItemManufacturerProducerGrowerAddress2,.TblItemManufacturerProducerGrowerCity,.TblItemManufacturerProducerGrowerCountrySubDivision,.TblItemManufacturerProducerGrowerPin,.TblItemManufacturerCountryName,.TblSourceCountryName,.TblTransitCountryName').val('');

            $(ele).find('.TblItemQuantity,.TblItemUnitPrice').val('0.000000');
            $(ele).find('.TblItemAmount,.TblItemFreight,.TblItemInsurance,.TblItemCommission,.TblItemDiscount,.TblItemMiscCharge,.TblItemOtherCharges,.TblFOBValue,.TblPMVValue,.TblJobWorkNotificationNo,.TblTaxableValue,.TblIGSTRate,.TblIGSTAmount').val('0.00');
            $(ele).find('.TblRewardItem').val(1);
            $(ele).find('.TblAccessStatus').val(0);
            $(ele).find('.TblIGSTPaymentStatus').val('.NA');
        } else
            $(ele).remove();
    });

    //ITEM DETAILS RESET END

    //PACKING DETAILS RESET START

    $('#TblPackingDetails tbody tr').each(function (ind, ele) {
        if (ind == 0) {
            $(ele).find('.PacketNoFrom,.PacketNoTo,.HiddenPacketType,.PacketType').val('');
        } else
            $(ele).remove();
    });

    //PACKING DETAILS RESET END


    //ESANCHITDETAILS RESET START

    $("#TblJobSupportDocs tbody tr").each(function (ind, ele) {
        if (ind == 0) {
            $(ele).parent().parent().find('.TblUniqueItemSrNo,.TblFileName,.TblInvoiceSrNo,.TblItemSrNo,.TblImgRefNo,.HiddenTblDocType,.TblDocType,.TblDocUploadDate,.TblPlaceOfIssue,.TblDocIssueDate,.TblDocExpiryDate,.HiddenTblDocIssueParty,.TblDocIssuingParty,.TblDocIssuingPartyCode,.HiddenTblDocBeneficiaryParty,.TblDocBeneficiaryParty,.TblDocBeneficiaryPartyCode').val('');
            $(ele).parent().parent().find('.TblDocLevel').val('JOB');
            $(ele).parent().parent().find('.TblIceGate').val(0);
        }
        else
            $(ele).remove();
    });

    //ESANCHITDETAILS RESET END
}

//FUNCTION FOR EDIT LETTERS
function EditLetters(e) {
    SetCookie('LettersId', e, 's', 50);
    window.open('/Master/Letters/Letters', '_blank');
}

//FUNCTION FOR EDIT BILL DETAILS
function EditBillDetails(e) {
    SetCookie('BillEntryUid', e, 's', 50);
    window.open('/Master/BillEntry/BillEntry', '_blank');
}

//FUNCTION FOR FILL LETTER DETAILS
function FillLetters(e) {
    try {
        const dataString = {};
        dataString.JobNo = e;
        AjaxSubmission(JSON.stringify(dataString), "/_Layout/GetLetters", $('[name="__RequestVerificationToken"]').val()).done(function (data) {
            let obj = data;

            if (obj.status == true) {
                if (obj.responsecode == '100')
                    BindLetters(obj.data.Table);
            }
            else
                window.location.href = '/ClientLogin/ClientLogin';
        }).fail(function (data) {
            console.log(data.Message);
        });
    }
    catch (e) {
        console.log(e.message);
    }
}

//FUNCTION FOR BIND ALL LETTER AGAINST JOB
function BindLetters(Result) {
    $("#TblLetters tbody tr").remove();
    if (Result.length == 0) {
        tr = $('<tr/>');
        tr.append("<td class='text-center' colspan='6'>NO RECORDS FOUND</td>");
        $("#TblLetters tbody").append(tr);
    } else {
        for (i = 0; i < Result.length; i++) {
            tr = $('<tr/>');
            tr.append("<td class='text-left'><button type='button' title='Edit Letter' onclick='EditLetters(\"" + Result[i].LetterAssignUid + "\");' class= 'Edit common-btn common-btn-sm ms-4 me-2'><i class='fa-solid fa-pen-to-square'></i></button>" + (i + 1) + "</td>");

            tr.append("<td><a href='javascript:void(0)' class='text-decoration-none' style='color: black !important;' onclick='EditLetters(\"" + Result[i].LetterAssignUid + "\");'>" + HandleNullTextValue(Result[i].LetterName) + "</a></td>");
            tr.append("<td class='text-center'>" + HandleNullTextValue(Result[i].CreatedBy) + "</td>");
            tr.append("<td class='text-center'>" + HandleNullTextValue(Result[i].CreatedAt) + "</td>");
            tr.append("<td class='text-center'>" + HandleNullTextValue(Result[i].LastUpdatedBy) + "</td>");
            tr.append("<td class='text-center'>" + HandleNullTextValue(Result[i].LastUpdatedAt) + "</td>");
            $("#TblLetters tbody").append(tr);
        }
    }
}

//FUNCTION FOR FILL JOB DETAILS
function FillBillDetails(e) {
    try {
        const dataString = {};
        dataString.JobUid = e;
        AjaxSubmission(JSON.stringify(dataString), "/_Layout/GetBillDetails", $('[name="__RequestVerificationToken"]').val()).done(function (data) {
            let obj = data;
            if (obj.status == true) {
                if (obj.responsecode == '100')
                    BindBillDetails(obj.data.Table);
            }
            else
                window.location.href = '/ClientLogin/ClientLogin';
        }).fail(function (data) {
            console.log(data.Message);
        });
    }
    catch (e) {
        console.log(e.message);
    }
}

//FUNCTION FOR BIND ALL BILL JOB
function BindBillDetails(Result) {
    $("#TblBillDetails tbody tr").remove();
    if (Result.length == 0) {
        tr = $('<tr/>');
        tr.append("<td class='text-center' colspan='8'>NO RECORDS FOUND</td>");
        $("#TblBillDetails tbody").append(tr);
    } else {
        for (i = 0; i < Result.length; i++) {
            tr = $('<tr/>');
            tr.append("<td class='text-left'><button type='button' title='Edit Bill' onclick='EditBillDetails(\"" + Result[i].BillUid + "\");' class= 'Edit common-btn common-btn-sm ms-4 me-2'><i class='fa-solid fa-pen-to-square'></i></button>" + (i + 1) + "</td>");
            tr.append("<td class='text-center'>" + HandleNullTextValue(Result[i].BillTypeName) + "</td>");

            tr.append("<td><a href='javascript:void(0)' class='text-decoration-none' style='color: black !important;' onclick='EditBillDetails(\"" + Result[i].BillUid + "\");'>" + HandleNullTextValue(Result[i].BillNo) + "</a></td>");

            tr.append("<td class='text-center'>" + HandleNullTextValue(Result[i].BillDate) + "</td>");
            tr.append("<td class='text-center'>" + HandleNullTextValue(Result[i].AccHead) + "</td>");

            //tr.append("<td class='text-center'>" + HandleNullTextValue(Result[i].BillUid) + "</td>");
            tr.append("<td class='text-end'>" + HandleNullTextValueFixed(Result[i].TotalAmount, 2) + "</td>");
            tr.append("<td class='text-end'>" + HandleNullTextValueFixed(Result[i].TaxAmount, 2) + "</td>");
            tr.append("<td class='text-end'>" + HandleNullTextValueFixed(Result[i].NetAmount, 2) + "</td>");
            $("#TblBillDetails tbody").append(tr);
        }
    }
}

//FUNCTION FOR VALID NET WEIGHT,GROSS WEIGHT AND INVOICE VALUE
function ValidateNtWtGrWtInVl() {
    let T_NtWt = 0, T_GrWt = 0, T_Invl = 0;

    $('#TblInvoiceDetails tbody tr').each(function (ind, ele) {

        if ($(ele).find('.InvoiceNo').val().trim().length > 0) {
            T_NtWt += parseFloat(HandleNullNumericValue($(ele).find('.NetWeightMetric').val()));
            T_GrWt += parseFloat(HandleNullNumericValue($(ele).find('.GrossWeightKg').val()));
            T_Invl += parseFloat(HandleNullNumericValue($(ele).find('.InvoiceValue').val()));
        }

    });

    T_NtWt = T_NtWt.toFixed(3);
    T_GrWt = T_GrWt.toFixed(3);
    T_Invl = T_Invl.toFixed(2);

    let F_NtWt = 0, F_GrWt = 0, F_Invl = 0;

    F_NtWt = HandleNullNumericValue($('#TotalNetWeight').val());
    F_GrWt = HandleNullNumericValue($('#TotalGrossWeight').val());
    F_Invl = HandleNullNumericValue($('#TotalInvoiceValue').val());


    if (T_NtWt != F_NtWt) {
        Toast('Total Net Weight Not Matched.', 'Message', 'error');
        return 1;
    }

    if (T_GrWt != F_GrWt) {
        Toast('Total Gross Weight Not Matched.', 'Message', 'error');
        return 1;
    }

    if (T_Invl != F_Invl) {
        Toast('Total Invoice Value Not Matched.', 'Message', 'error');
        return 1;
    }
    return 0;
}

//FUNCTION FOR CALCULATE TOTAL INVOICE VALUE
function CalculateTotalInvoiceValue() {
    let TotalInvoiceValue = 0;
    $('#TotalInvoiceValue').val(parseInt(0).toFixed(2));
    $('#TblInvoiceDetails tbody tr').each(function () {
        TotalInvoiceValue += parseFloat($(this).find('.InvoiceValue').val().trim());
    });
    if (isNaN(TotalInvoiceValue))
        $('#TotalInvoiceValue').val('0.00');
    else
        $('#TotalInvoiceValue').val(TotalInvoiceValue.toFixed(2));
}

//FUNCTION FOR CALCULATE TOTAL NET WEIGHT
function CalculateTotalNetWeight() {
    let TotalNetWeight = 0;
    $("#TblInvoiceDetails tbody tr").each(function () {
        TotalNetWeight += parseFloat($(this).find('.NetWeightMetric').val().trim());
    });
    if (isNaN(TotalNetWeight))
        $("#TotalNetWeight").val("0.000");
    else
        $("#TotalNetWeight").val(TotalNetWeight.toFixed(3));
}

//FUNCTION FORM CALCULATE TOTAL GROSS WEIGHT
function CalculateTotalGrossWeight() {
    let TotalGrossWeight = 0;
    $("#TblInvoiceDetails tbody tr").each(function () {
        TotalGrossWeight += parseFloat($(this).find('.GrossWeightKg').val().trim());
    });
    if (isNaN(TotalGrossWeight))
        $("#TotalGrossWeight").val("0.000");
    else
        $("#TotalGrossWeight").val(TotalGrossWeight.toFixed(3));

}

//FUNCTION FOR MATCH ALL INVOICE AMOUNT WITH ALL ITEM AMOUNT
function ValidateAllInvVlWtAllItem() {
    let fl = 0;
    $("#TblInvoiceDetails tbody tr").each(function (InvInd, InvEle) {

        let Inv_Ser, Inv_Amt = 0, It_Amt = 0, It_Inv = 0;

        Inv_Ser = InvInd + 1;
        Inv_Amt = parseFloat(HandleNullNumericValue($(InvEle).find('.InvoiceValue').val()));
        Inv_Amt = Inv_Amt.toFixed(2);

        $("#TblItemDetails tbody tr").each(function (ItInd, ItEle) {
            if (Inv_Ser == $(ItEle).find('.TblItemInvoiceNo').val()) {
                It_Inv = $(ItEle).find('.TblItemInvoiceNo').val();
                It_Amt += parseFloat(HandleNullNumericValue($(ItEle).find('.TblItemAmount').val()));
            }
        });

        It_Amt = It_Amt.toFixed(2);
        if (Inv_Ser == It_Inv) {
            if (Inv_Amt != It_Amt) {
                Toast('Invoice Value Not Matched In Item Details Against Invoice :-' + $(InvEle).find('.InvoiceNo').val() + '', 'Message', 'error');
                fl = 1;
                return;
            }
        }
    });
    return fl;
}
//FUNCTION FOR FILL MAIN TABLE DATA FOR EDIT
function FillMainDetialsData(obj, OldJob = true) {
    console.log(obj);
    $('#JobUid').val(obj.JobUid);
    $('#TimeStamp').val(obj.TimeStamp);
    $('#SelectBranch').val(obj.BranchId);


    $('#JobDate').val(obj.JobDate);
    $('#SubJobNo').val(obj.SubJobNo);
    $('#JobNo').val(obj.JobNo);

    if (obj.JobCancel == true)
        $('#JobCancel').prop('checked', true);
    else
        $('#JobCancel').prop('checked', false);

    $('#HiddenClientName').val(obj.ClientId);
    CliSelecBranc = obj.ClientBranchUid;
    $('#ClientName').val(obj.AccHead).trigger('blur');
    $('#AdCode').val(obj.AdCode);
    $('#SBType').val(obj.SBType);
    $('#SBNo').val(obj.SBNo);
    $('#SBDate').val(obj.SBDate);
    $('#ModeOfTransport').val(obj.ModeOfTransport);
    $('#CustomPortCode').val(obj.CustomPortCode);
    $('#CustomPortName').val(obj.CustomPortName);

    $('#VslName').val(obj.VslName);
    $('#VoyageNo').val(obj.VoyageNo);
    $('#VIANo').val(obj.VIANo);
    $('#BookingNo').val(obj.BookingNo);
    $('#BookedBy').val(obj.BookedBy);
    $('#RbiWaiverNumber').val(obj.RbiWaiverNumber);
    $('#RbiWaiverDate').val(obj.RbiWaiverDate);
    $('#EPZCode').val(obj.EPZCode);

    $("#HiddenPortLoading").val(obj.PortLoadingCode);
    $("#PortLoading").val(obj.PortLoading);
    $("#HiddenPortFinalDestination").val(obj.PortFinalDestinationCode);
    $("#PortFinalDestination").val(obj.PortFinalDestination);
    $("#HiddenCountryFinalDestination").val(obj.CountryFinalDestinationCode);
    $("#CountryFinalDestination").val(obj.CountryFinalDestination);
    $("#HiddenCountryDischarge").val(obj.CountryDischargeCode);
    $("#CountryDischarge").val(obj.CountryDischarge);
    $("#HiddenPortDischarge").val(obj.PortDischargeCode);
    $("#PortDischarge").val(obj.PortDischarge);

    $("#MBLNo").val(obj.MBLNo);
    $("#MBLDate").val(obj.MBLDate);
    $("#HBLNo").val(obj.HBLNo);
    $("#HBLDate").val(obj.HBLDate);
    $("#MAWBNo").val(obj.MAWBNo);
    $("#MAWBDate").val(obj.MAWBDate);
    $("#HAWBNo").val(obj.HAWBNo);
    $("#HAWBDate").val(obj.HAWBDate);

    $("#BoxTypeNo").val(obj.BoxTypeNo);
    $("#BoxType").val(obj.BoxType);
    $("#ContainerTypeNo").val(obj.ContainerTypeNo);
    $("#ContainerType").val(obj.ContainerType);
    $("#BalesTypeNo").val(obj.BalesNo);
    $("#BalesType").val(obj.BalesType);
    $("#LoosePackets").val(obj.Numberloosepackets);
    $("#StateOfOrigin").val(obj.StateOfOrigin).trigger('change');
    $("#ExporterClass").val(obj.ClientClass);
    $("#ExporterType").val(obj.ClientType);

    $("#NatureOfCargo").val(obj.NatureCargo);
    $("#FactoryStuff").prop('checked', obj.FactoryStuff).trigger('change');
    $("#WhetherSampleAccompanied").prop('checked', obj.WhetherSampleAccompanied);
    $("#SelfSealing").prop('checked', obj.SelfSealing);
    $("#CentralExciseSealing").prop('checked', obj.CentralExciseSealing);
    $("#SealingAgency").val(obj.SealingAgency);
    $("#FactNameAddr").val(obj.FactNameAddr);

    $("#TotalNetWeight").val('0.000');
    $("#TotalGrossWeight").val('0.000');
    $("#TotalInvoiceValue").val('0.00');
    $("#DutyAmount").val('0.00');

    if (obj.TotalNetWeight != null)
        $("#TotalNetWeight").val(obj.TotalNetWeight.toFixed(3));

    if (obj.TotalGrossWeight != null)
        $("#TotalGrossWeight").val(obj.TotalGrossWeight.toFixed(3));

    if (obj.TotalInvoiceValue != null)
        $("#TotalInvoiceValue").val(obj.TotalInvoiceValue.toFixed(2));

    if (obj.DutyAmount != null)
        $("#DutyAmount").val(obj.DutyAmount.toFixed(2));

    if (obj.CreatedByName != null && obj.CreatedByName.length > 0)
        $("#CrBy").removeClass('d-none');

    if (obj.CreatedAt != null && obj.CreatedAt.length > 0)
        $("#CrDt").removeClass('d-none');

    if (obj.LastUpdatedByName != null && obj.LastUpdatedByName.length > 0)
        $("#MoBy").removeClass('d-none');

    if (obj.LastUpdatedAt != null && obj.LastUpdatedAt.length > 0)
        $("#MoDt").removeClass('d-none');

    $("#CreatedBy").text(HandleNullTextValue(obj.CreatedByName));
    $("#CreatedAt").text(HandleNullTextValue(obj.CreatedAt));

    $("#ModifiedBy").text(HandleNullTextValue(obj.LastUpdatedByName));
    $("#ModifiedAt").text(HandleNullTextValue(obj.LastUpdatedAt));

    $("#ClientRemarks").val(obj.ClientRemarks);
    $("#Remarks").val(obj.Remarks);
    $("#MarksNo").val(obj.MarksNo);

    $("#PaymentTerms").val(obj.PaymentTerms);
    $("#PeriodOfPayment").val(obj.PeriodOfPayment);

    $("#HiddenConsignee").val(obj.ConsigneeUid);
    $("#Consignee").val(obj.Consignee);
    $("#ConsigneeAddress1").val(obj.ConsigneeAddress1);
    $("#ConsigneeAddress2").val(obj.ConsigneeAddress2);
    $("#ConsigneeAddress3").val(obj.ConsigneeAddress3);
    $("#ConsigneeAddress4").val(obj.ConsigneeAddress4);
    $("#HiddenConsigneeCountry").val(obj.ConsigneeCountryCode);
    $("#ConsigneeCountry").val(obj.ConsigneeCountry);

    $("#HiddenThirdParty").val(obj.ThirdPartyUid);
    TPSelecBranc = obj.ThirdPartyBranchUid;
    $("#ThirdParty").val(obj.ThirdPartyName);
    $("#ThirdParty").val(obj.ThirdPartyName).trigger('blur');
    $("#ThirdPartyAddress").val(obj.ThirdPartyBranchUid);
    $("#ThirdPartyAddress1").val(obj.ThirdPartyAddress1);
    $("#ThirdPartyAddress2").val(obj.ThirdPartyAddress2);
    $("#HiddenThirdPartyCountry").val(obj.ThirdPartyCountryCode);
    $("#ThirdPartyCountry").val(obj.ThirdPartyCountry);
    $("#HiddenThirdPartyState").val(obj.ThirdPartyStateCode);
    $("#ThirdPartyState").val(obj.ThirdPartyState);
    $("#ThirdPartyCity").val(obj.ThirdPartyCity);
    $("#ThirdPartyPinCode").val(obj.ThirdPartyPinCode);

    $("#ConsgineeBuyer").prop('checked', obj.ConsigneeBuyer);

    $("#HiddenBuyer").val(obj.BuyerUid);
    $("#Buyer").val(obj.Buyer);
    $("#BuyerAddress1").val(obj.BuyerAddress1);
    $("#BuyerAddress2").val(obj.BuyerAddress2);
    $("#BuyerAddress3").val(obj.BuyerAddress3);
    $("#BuyerAddress4").val(obj.BuyerAddress4);
    $("#RotationNo").val(obj.RotationNo);
    $("#RotationDate").val(obj.RotationDate);
}

//FUNCTION FOR FILL CONTAINER TABLE DATA IN CONTAINER TABLE FOR EDIT
function FillContainerDetailsData(obj) {
    let ContainerFirstChild = $("#TblContainerDetails").find('tbody tr:first-child');
    let Con = '';

    $.each(obj, function (ind, ele) {
        if (ind == 0) {
            Con = ContainerFirstChild;
            fn();
        }
        else {
            Con = ContainerFirstChild.clone();
            ContainerFirstChild.find('.SealDate,.PickupDate,.StuffingDate,.PortGateInDate').datepicker("destroy");
            ContainerFirstChild.find('.SealDate,.PickupDate,.StuffingDate,.PortGateInDate').removeAttr("id");
            fn();
            $('#TblContainerDetails tbody').append(Con);
            $(".datepickerAll").datepicker({
                changeMonth: true,
                changeYear: true,
                dateFormat: 'dd/mm/yy'
            });
        }
        function fn() {
            Con.find('.rn').text(ind + 1);
            Con.find('.ContainerNo').val(ele.ContainerNo);
            Con.find('.ContType').val(ele.ContType).trigger('blur');
            Con.find('.SealNo').val(ele.SealNo);
            Con.find('.ExciseSealNumber').val(ele.ExciseSealNo);
            Con.find('.SealDate').val(ele.SealDate);
            Con.find('.SealType').val(ele.SealType);
            Con.find('.SealDeviceId').val(ele.SealDeviceId);
            Con.find('.NetWeight').val(HandleNullTextValueFixed(ele.NetWeight, 3));
            Con.find('.NetWeightType').val(ele.NetWeightType);
            Con.find('.GrossWeight').val(HandleNullTextValueFixed(ele.GrossWeight, 3));

            Con.find('.TareWeight').val(HandleNullTextValueFixed(ele.TareWeight, 3));
            Con.find('.VGMWeight').val(HandleNullTextValueFixed(ele.VGMWeight, 3));
            Con.find('.NoOfPackage').val(ele.NoOfPackage);
            Con.find('.PackageType').val(ele.PackageType);
            Con.find('.HiddenTransporter').val(ele.Transporter);
            Con.find('.Transporter').val(ele.TransporterName);
            Con.find('.TruckNo').val(ele.TruckNo);
            Con.find('.PickupDate').val(ele.PickupDate);
            Con.find('.StuffingDate').val(ele.StuffingDate);
            Con.find('.PortGateInDate').val(ele.PortGateInDate);

            Con.find('.ContainerRemarks').val(ele.ContainerRemarks);

        }
    });
}


//FUNCTION FOR FILL INVOICE TABLE DATA IN INVOICE TABLE FOR EDIT
function FillInvoiceDetailsData(obj) {
    let InvT = '';
    let InvHtml = '';
    let InvoiceFirstChild = $("#TblInvoiceDetails").find('tbody tr:first-child');
    $.each(obj, function (ind, ele) {
        if (InvHtml == '')
            InvHtml = '<option value="0">---Select---</option>';
        InvHtml += '<option value="' + (ind + 1) + '">' + ele.InvoiceNo + '</option>';
        if (ind == 0) {
            InvT = InvoiceFirstChild;
            fn();
        }
        else {
            InvoiceFirstChild.find('.InvoiceDate').datepicker("destroy").removeAttr("id");
            InvT = InvoiceFirstChild.clone();
            fn();
            $('#TblInvoiceDetails tbody').append(InvT);

            $('.datepickerAll').datepicker({
                changeMonth: true,
                changeYear: true,
                dateFormat: 'dd/mm/yy'
            });
        }
        function fn() {
            InvT.find('.rn').text(ind + 1);
            InvT.find('.Relation').val(ele.Relation);
            InvT.find('.InvoiceNo').val(ele.InvoiceNo);
            InvT.find('.InvoiceDate').val(ele.InvoiceDate);
            InvT.find('.NatureOfContract').val(ele.InvoiceTerms);
            InvT.find('.InvoiceCurrency').val(ele.InvoiceCurrency).trigger('blur');
            InvT.find('.InvoiceCurrencyExchangeRate').val(HandleNullTextValueFixed(ele.InvoiceCurrencyExchangeRate, 2));
            InvT.find('.GrossWeightKg').val(HandleNullTextValueFixed(ele.GrossWeightKg, 3));
            InvT.find('.NetWeightMetric').val(HandleNullTextValueFixed(ele.NetWeightMetric, 3));
            InvT.find('.NetUnit').val(ele.NetUnit).trigger('blur');
            InvT.find('.InvoiceValue').val(HandleNullTextValueFixed(ele.InvoiceValue, 2));

            InvT.find('.FreightPer').val(HandleNullTextValueFixed(ele.FreightPer, 4));
            InvT.find('.ActualFreight').val(HandleNullTextValueFixed(ele.ActualFreight, 2));
            InvT.find('.FreightCurrency').val(ele.FreightCurrency).trigger('blur');
            InvT.find('.FreightExchangeRate').val(HandleNullTextValueFixed(ele.FreightExchangeRate, 2));
            InvT.find('.FreightINR').val(HandleNullTextValueFixed(ele.FreightINR, 2));
            InvT.find('.InsurancePer').val(HandleNullTextValueFixed(ele.InsurancePer, 4));
            InvT.find('.ActualInsurance').val(HandleNullTextValueFixed(ele.ActualInsurance, 2));
            InvT.find('.InsuranceCurrency').val(ele.InsuranceCurrency).trigger('blur');
            InvT.find('.InsuranceExchangeRate').val(HandleNullTextValueFixed(ele.InsuranceExchangeRate, 2));
            InvT.find('.InsuranceINR').val(HandleNullTextValueFixed(ele.InsuranceINR, 2));

            InvT.find('.CommissionPer').val(HandleNullTextValueFixed(ele.CommissionPer, 4));
            InvT.find('.ActualCommission').val(HandleNullTextValueFixed(ele.ActualCommission, 2));
            InvT.find('.CommissionCurrency').val(ele.CommissionCurrency).trigger('blur');
            InvT.find('.CommissionExchangeRate').val(HandleNullTextValueFixed(ele.CommissionExchangeRate, 2));
            InvT.find('.CommissionINR').val(HandleNullTextValueFixed(ele.CommissionINR, 2));
            InvT.find('.DiscountPer').val(HandleNullTextValueFixed(ele.DiscountPer, 4));
            InvT.find('.ActualDiscount').val(HandleNullTextValueFixed(ele.ActualDiscount, 2));
            InvT.find('.DiscountCurrency').val(ele.DiscountCurrency).trigger('blur');
            InvT.find('.DiscountExchangeRate').val(HandleNullTextValueFixed(ele.DiscountExchangeRate, 2));
            InvT.find('.DiscountINR').val(HandleNullTextValueFixed(ele.DiscountINR, 2));

            InvT.find('.MiscCharges').val(HandleNullTextValueFixed(ele.MiscCharges, 2));
            InvT.find('.MiscChargesINR').val(HandleNullTextValueFixed(ele.MiscChargesINR, 2));
            InvT.find('.OtherChargesPer').val(HandleNullTextValueFixed(ele.OtherChargesPer, 4));
            InvT.find('.ActualOtherCharges').val(HandleNullTextValueFixed(ele.ActualOtherCharges, 2));
            InvT.find('.OtherChargesCurrency').val(ele.OtherChargesCurrency).trigger('blur');
            InvT.find('.OtherChargesExchangeRate').val(HandleNullTextValueFixed(ele.OtherChargesExchangeRate, 2));
            InvT.find('.OtherChargesINR').val(HandleNullTextValueFixed(ele.OtherChargesINR, 2));
            InvT.find('.FOBValue').val(HandleNullTextValueFixed(ele.FOBValue, 2));
            InvT.find('.PMVRateInvoice').val(ele.PMVRateInvoice);
            InvT.find('.PMVUnitInvoice').val(ele.PMVUnitInvoice);

            InvT.find('.PMVQuantity').val(ele.PMVQuantity).trigger('blur');
            InvT.find('.PMVValue').val(HandleNullTextValueFixed(ele.PMVVALUE, 2));
        }
        $('#NewItemInvoiceNo').html(InvHtml);
        $('.TblItemInvoiceNo').html(InvHtml);
    });
}

//FUNCTION FOR FILL ITEM TABLE DATA IN ITEM TABLE FOR EDIT
function FillItemDetailsData(obj) {
    let ItemFirstChild = $("#TblItemDetails").find('tbody tr:first-child');
    let It = '';
    $.each(obj, function (ind, ele) {
        if (ind == 0) {
            It = ItemFirstChild;
            fn();
        }
        else {
            It = ItemFirstChild.clone();
            fn();
            $('#TblItemDetails tbody').append(It);
        }
        function fn() {
            It.find('.rn').text(ind + 1);
            It.find('.TblItemInvoiceNo').val(ele.InvoiceSrNo);
            It.find('.TblItemName').val(ele.ItemName);
            It.find('.TblItemDescription').val((ele.ItemDescription1 == null ? '' : ele.ItemDescription1) + (ele.ItemDescription2 == null ? '' : ele.ItemDescription2));
            It.find('.TblItemEndUse').val(ele.EndUse);
            It.find('.TblItemEndUseDesc').val(ele.EndUseDesc);
            It.find('.TblItemAmount').val(HandleNullTextValueFixed(ele.ItemAmount, 2));
            It.find('.TblItemQuantity').val(HandleNullTextValueFixed(ele.Quantity, 3));
            It.find('.TblItemUnitPrice').val(HandleNullTextValueFixed(ele.ItemUnitPrice, 3));
            It.find('.TblUnitQuantityCode').val(ele.UnitQuantityCode);
            It.find('.TblItemFreight').val(HandleNullTextValueFixed(ele.ItemFreight, 2));
            It.find('.TblItemInsurance').val(HandleNullTextValueFixed(ele.ItemInsurance, 2));
            It.find('.TblItemCommission').val(HandleNullTextValueFixed(ele.ItemCommission, 2));
            It.find('.TblItemDiscount').val(HandleNullTextValueFixed(ele.ItemDiscount, 2));
            It.find('.TblItemMiscCharge').val(HandleNullTextValueFixed(ele.ItemMiscCharge, 2));
            It.find('.TblItemOtherCharges').val(HandleNullTextValueFixed(ele.ItemOtherCharges, 2));
            It.find('.TblFOBValue').val(HandleNullTextValueFixed(ele.ItemFOBValue, 2));
            It.find('.TblPMVValue').val(HandleNullTextValueFixed(ele.ItemPMVValue, 2));
            It.find('.TblRewardItem').val(ele.RewardItem == false ? 0 : 1);
            It.find('.TblJobWorkNotificationNo').val(ele.JobWorkNotificationNo);
            It.find('.TblAccessStatus').val(ele.AccessoryStatus);
            It.find('.TblIGSTPaymentStatus').val(ele.ItemIGSTPaymentStatus);
            //It.find('.TblIGSTPaymentStatus').val($('#TblIGSTPaymentStatus option:selected').text());
            It.find('.TblTaxableValue').val(HandleNullTextValueFixed(ele.ItemTaxableValue, 2));
            It.find('.TblIGSTAmount').val(HandleNullTextValueFixed(ele.ItemIGSTValue, 2));
            It.find('.TblIGSTRate').val(HandleNullTextValueFixed(ele.ItemIGSTRate, 2));
            It.find('.HiddenTblItemManufacturerProducerGrowerName').val(ele.ManufacturerProducerGrower);
            It.find('.TblItemManufacturerProducerGrowerName').val(ele.ManufacturerProducerGrowerName);
            It.find('.TblItemManufacturerProducerCodeType').val(ele.ItemManufacturerProducerCodeType);
            It.find('.TblItemManufacturerProducerGrowerCode').val(ele.ItemManufacturerProducerGrowerCode);
            It.find('.TblItemManufacturerProducerGrowerAddress1').val(ele.ItemManufacturerProducerGrowerAddress1);
            It.find('.TblItemManufacturerProducerGrowerAddress2').val(ele.ItemManufacturerProducerGrowerAddress2);
            It.find('.TblItemManufacturerProducerGrowerCity').val(ele.ItemManufacturerProducerGrowerCity);
            It.find('.TblItemManufacturerProducerGrowerPin').val(ele.ItemManufacturerProducerGrowerPin);
            It.find('.HiddenTblItemManufacturerCountry').val(ele.ItemManufacturerCountry);
            It.find('.TblItemManufacturerCountryName').val(ele.ItemManufacturerCountryName);
            It.find('.HiddenTblSourceCountryName').val(ele.SourceCountry);
            It.find('.TblSourceCountryName').val(ele.SourceCountryName);
            It.find('.HiddenTblTransitCountry').val(ele.TransitCountry);
            It.find('.TblTransitCountryName').val(ele.TransitCountryName);
            It.find('.TblItemManufacturerProducerGrowerCountrySubDivision').val(ele.ItemManufacturerProducerGrowerCountrySubDivision);

        }

    });
}

//FUNCTION FOR FILL PACKING TABLE DATA IN ITEM TABLE FOR EDIT

function FillPackingDetailsData(obj) {

    let PackingFirstChild = $("#TblPackingDetails").find('tbody tr:first-child');

    let Pt = '';

    $.each(obj, function (ind, ele) {

        if (ind == 0) {
            Pt = PackingFirstChild;
            fn();
        }
        else {
            Pt = PackingFirstChild.clone();
            fn();
            $('#TblPackingDetails tbody').append(Pt);
        }
        function fn() {
            Pt.find('.rn').text(ind + 1);
            Pt.find('.PacketNoFrom').val(ele.PacketNoFrom);
            Pt.find('.PacketNoTo').val(ele.PacketNoTo);
            Pt.find('.HiddenPacketType').val(ele.PackingCode);
            Pt.find('.PacketType').val(ele.PacketType);
        }
    });

}

//FUNCTION FOR FILL JOB SUPPORT DOC TABLE DATA IN JOB SUPPORT DOC TABLE FOR EDIT
function FillJobSupportDocDetailsData(obj) {

    let JobSupportFirstChild = $('#TblJobSupportDocs').find('tbody tr:first-child');
    let JobSupportT = '';

    $.each(obj, function (ind, ele) {
        if (ind == 0) {
            JobSupportT = JobSupportFirstChild;
            fn();
        }
        else {
            JobSupportT = JobSupportFirstChild.clone();
            fn();
            $('#TblJobSupportDocs').append(JobSupportT);
        }
        function fn() {
            JobSupportT.find('.TblUniqueItemSrNo').val(ele.UniqueSerialNo);
            JobSupportT.find('.TblFileName').val(ele.FileName);
            JobSupportT.find('.TblInvoiceSrNo').val(ele.InvoiceSrNo);
            JobSupportT.find('.TblItemSrNo').val(ele.ItemSrno);
            JobSupportT.find('.TblDocLevel').val(ele.DocumentLevel);
            JobSupportT.find('.TblIceGate').val(ele.ICEGATEUserId);
            JobSupportT.find('.TblImgRefNo').val(ele.ImageReferenceNo);
            /*    JobSupportT.find('.TblDocRefNo').val(ele.DocumentReferenceNo);*/
            JobSupportT.find('.HiddenTblDocType').val(ele.DocumentTypeCode);
            JobSupportT.find('.TblDocType').val(ele.DocumentTypeCodeDescriptions);
            JobSupportT.find('.TblFileType').val(ele.FileType);
            JobSupportT.find('.TblDocUploadDate').val(ele.UploadDateTime);
            JobSupportT.find('.TblPlaceOfIssue').val(ele.PlaceOfIssue);
            JobSupportT.find('.TblDocIssueDate').val(ele.DocumentIssueDate);
            JobSupportT.find('.TblDocExpiryDate').val(ele.DocumentExpiryDate);
            JobSupportT.find('.HiddenTblDocIssuingParty').val(ele.DocumentIssuingParty);
            JobSupportT.find('.TblDocIssuingParty').val(ele.DocumentIssuingPartyName);
            JobSupportT.find('.TblDocIssuingPartyCode').val(ele.DocumentIssuingPartyCode);
            JobSupportT.find('.HiddenTblDocBeneficiaryParty').val(ele.DocumentBeneficiaryParty);
            JobSupportT.find('.TblDocBeneficiaryParty').val(ele.DocumentBeneficiaryPartyName);
            JobSupportT.find('.TblDocBeneficiaryPartyCode').val(ele.DocumentBeneficiaryPartyCode);
        }
    });
    GenerateSerialNumberTable('TblJobSupportDocs', 'rn');
}
//FUNCTION FOR GET MAIN TABLE DATA 
function GetJobHeaderData() {
    const dataString = {};

    dataString.TimeStamp = $("#TimeStamp").val().trim();
    dataString.JobUid = $('#JobUid').val().trim();
    dataString.JobNo = $('#JobNo').val().trim();
    dataString.SubJobNo = $('#SubJobNo').val().trim();
    dataString.JobDate = $('#JobDate').val().trim();
    dataString.JobCancel = $('#JobCancel').is(':checked');
    dataString.BranchId = $('#SelectBranch').val();
    dataString.ClientId = parseInt($('#HiddenClientName').val().trim());
    dataString.ClientBranchUid = $('#Address').val().trim();
    dataString.AdCode = $('#AdCode').val().trim();
    dataString.SBType = $('#SBType').val().trim();
    dataString.SBNo = $('#SBNo').val().trim();
    dataString.SBDate = $('#SBDate').val().trim();
    dataString.ModeOfTransport = $("#ModeOfTransport").val().trim();
    dataString.CustomPortCode = $("#CustomPortCode").val();
    dataString.CustomPortName = $("#CustomPortName").val();

    dataString.VslName = $('#VslName').val().trim();
    dataString.VoyageNo = $('#VoyageNo').val().trim();
    dataString.VIANo = $('#VIANo').val().trim();
    dataString.BookingNo = $('#BookingNo').val().trim();
    dataString.BookedBy = $('#BookedBy').val().trim();
    dataString.RbiWaiverNumber = $('#RbiWaiverNumber').val().trim();
    dataString.RbiWaiverDate = $('#RbiWaiverDate').val().trim();
    dataString.EPZCode = $('#EPZCode').val().trim();
    dataString.PortLoadingCode = $('#HiddenPortLoading').val();
    dataString.PortLoading = $('#PortLoading').val().trim();
    dataString.PortFinalDestinationCode = $('#HiddenPortFinalDestination').val();
    dataString.PortFinalDestination = $('#PortFinalDestination').val().trim();
    dataString.CountryFinalDestinationCode = $('#HiddenCountryFinalDestination').val();
    dataString.CountryFinalDestination = $('#CountryFinalDestination').val().trim();
    dataString.CountryDischargeCode = $('#HiddenCountryDischarge').val();
    dataString.CountryDischarge = $('#CountryDischarge').val().trim();
    dataString.PortDischargeCode = $('#HiddenPortDischarge').val();
    dataString.PortDischarge = $('#PortDischarge').val().trim();
    dataString.MBLNo = $('#MBLNo').val().trim();
    dataString.MBLDate = $('#MBLDate').val().trim();
    dataString.HBLNo = $('#HBLNo').val().trim();
    dataString.HBLDate = $('#HBLDate').val().trim();
    dataString.MAWBNo = $('#MAWBNo').val().trim();
    dataString.MAWBDate = $('#MAWBDate').val().trim();
    dataString.HAWBNo = $('#HAWBNo').val().trim();
    dataString.HAWBDate = $('#HAWBDate').val().trim();
    if ($('#BoxTypeNo').val().trim().length > 0) {
        if ($('#BoxType').val().trim().length <= 0) {
            $('#BoxType').focus();
            Toast('Please Add Package Type.', 'Message', 'error');
            return false;
        }
    }

    if ($('#BoxType').val().trim().length > 0) {
        if ($('#BoxTypeNo').val().trim().length <= 0) {
            $('#BoxTypeNo').focus();
            Toast('Please Add Number Of Package.', 'Message', 'error');
            return false;
        }
    }

    dataString.BoxTypeNo = parseInt($('#BoxTypeNo').val().trim());
    dataString.BoxType = $('#BoxType').val().trim();
    if ($('#ContainerTypeNo').val().trim().length > 0) {
        if ($('#ContainerType').val().trim().length <= 0) {
            $('#ContainerType').focus();
            Toast('Please Add Container Type.', 'Message', 'error');
            return false;
        }
    }

    if ($('#ContainerType').val().trim().length > 0) {
        if ($('#ContainerTypeNo').val().trim().length <= 0) {
            $('#ContainerTypeNo').focus();
            Toast('Please Add Number Of Container.', 'Message', 'error');
            return false;
        }
    }

    dataString.ContainerTypeNo = parseInt($('#ContainerTypeNo').val().trim());
    dataString.ContainerType = $('#ContainerType').val().trim();

    if ($('#BalesTypeNo').val().trim().length > 0) {
        if ($('#BalesType').val().trim().length <= 0) {
            $('#BalesType').focus();
            Toast('Please Add Bales Type.', 'Message', 'error');
            return false;
        }
    }

    if ($('#BalesType').val().trim.length > 0) {
        if ($('#BalesTypeNo').val().trim().length <= 0) {
            $('#BalesTypeNo').focus();
            Toast('Please Add Number Of Bales.', 'Message', 'error');
            return false;
        }
    }
    dataString.BalesNo = parseInt($('#BalesTypeNo').val().trim());
    dataString.BalesType = $('#BalesType').val().trim();

    dataString.LoosePackets = parseInt($('#LoosePackets').val().trim());
    dataString.StateOfOrigin = $('#StateOfOrigin').val().trim();
    dataString.ExporterClass = $('#ExporterClass').val().trim();
    dataString.ExporterType = $('#ExporterType').val().trim();
    dataString.NatureOfCargo = $('#NatureOfCargo').val().trim();

    dataString.PaymentTerms = $('#PaymentTerms').val().trim();
    dataString.PeriodOfPayment = parseInt($('#PeriodOfPayment').val().trim());
    dataString.ConsigneeUid = $('#HiddenConsignee').val().trim();
    dataString.ConsigneeName = $('#Consignee').val().trim();
    dataString.ConsigneeAddress1 = $('#ConsigneeAddress1').val().trim();
    dataString.ConsigneeAddress2 = $('#ConsigneeAddress2').val().trim();
    dataString.ConsigneeAddress3 = $('#ConsigneeAddress3').val().trim();
    dataString.ConsigneeAddress4 = $('#ConsigneeAddress4').val().trim();
    dataString.ConsigneeCountryCode = $('#HiddenConsigneeCountry').val().trim();
    dataString.ConsigneeCountry = $('#ConsigneeCountry').val().trim();
    dataString.ThirdPartyUid = $('#HiddenThirdParty').val().trim();
    dataString.ThirdPartyName = $('#ThirdParty').val().trim();
    dataString.ThirdPartyBranchUid = $('#ThirdPartyAddress').val();
    dataString.ThirdPartyAddress1 = $('#ThirdPartyAddress1').val().trim();
    dataString.ThirdPartyAddress2 = $('#ThirdPartyAddress2').val().trim();
    dataString.ThirdPartyCity = $('#ThirdPartyCity').val().trim();
    dataString.ThirdPartyCountryCode = $('#HiddenThirdPartyCountry').val().trim();
    dataString.ThirdPartyCountry = $('#ThirdPartyCountry').val().trim();
    dataString.ThirdPartyStateCode = $('#HiddenThirdPartyState').val().trim();
    dataString.ThirdPartyState = $('#ThirdPartyState').val().trim();
    dataString.ThirdPartyPinCode = $('#ThirdPartyPinCode').val().trim();
    dataString.ConsigneeBuyer = $("#ConsgineeBuyer").is(':checked');
    dataString.BuyerUid = $('#HiddenBuyer').val().trim();
    dataString.Buyer = $('#Buyer').val().trim();
    dataString.BuyerAddress1 = $('#BuyerAddress1').val().trim();
    dataString.BuyerAddress2 = $('#BuyerAddress2').val().trim();
    dataString.BuyerAddress3 = $('#BuyerAddress3').val().trim();
    dataString.BuyerAddress4 = $('#BuyerAddress4').val().trim();

    dataString.FactoryStuff = $("#FactoryStuff").is(':checked');
    dataString.WhetherSampleAccompanied = $("#WhetherSampleAccompanied").is(':checked');
    dataString.SelfSealing = $("#SelfSealing").is(':checked');
    dataString.CentralExciseSealing = $("#CentralExciseSealing").is(':checked');
    if (!$("#FactoryStuff").is(':checked'))
        if ($('#SealingAgency').val().trim().length > 0 || $('#FactNameAddr').val().trim().length > 0)
            $("#FactoryStuff").prop('checked', true);
    dataString.SealingAgency = $('#SealingAgency').val().trim();
    dataString.FactNameAddr = $('#FactNameAddr').val().trim();
    dataString.RotationNo = $('#RotationNo').val().trim();
    dataString.RotationDate = $('#RotationDate').val().trim();

    dataString.TotalNetWeight = parseFloat($("#TotalNetWeight").val().trim());
    dataString.TotalGrossWeight = parseFloat($("#TotalGrossWeight").val().trim());
    dataString.TotalInvoiceValue = parseFloat($("#TotalInvoiceValue").val().trim());
    dataString.FOBValue = parseFloat($("#FOBValue").val().trim());
    dataString.ClientRemarks = $("#ClientRemarks").val().trim();
    dataString.Remarks = $("#Remarks").val().trim();

    dataString.MarksNo = $("#MarksNo").val().trim();

    let InvDesc = "", InvDate = "", InvCur = "", InvExRat = "";

    $("#TblInvoiceDetails tbody tr").each(function (ind, ele) {
        if ($(ele).find('.InvoiceNo').val().trim().length > 0) {
            InvDesc += $(ele).find('.InvoiceNo').val() + "@";
            InvDesc += $(ele).find('.InvoiceDate').val() + ",";
            if (InvDate == "")
                InvDate = $(ele).find('.InvoiceDate').val();
            if (InvCur == "")
                InvCur = $(ele).find('.InvoiceCurrency').val();
            if (InvExRat == "")
                InvExRat = $(ele).find('.InvoiceCurrencyExchangeRate').val();
        }
    });

    dataString.InvoiceDescriptions = InvDesc.substring(0, InvDesc.length - 1);
    dataString.InvoiceDate = InvDate;
    dataString.InvoiceCurrency = InvCur;
    dataString.InvoiceCurrenyExchRate = InvExRat;

    let ItemDesc = "";
    $('#TblItemDetails tbody tr').each(function (ind, ele) {

        if ($(ele).find('.TblItemName').val().trim().length > 0) {
            ItemDesc += $(ele).find('.TblItemName').val() + ',';
        }
    });
    dataString.ItemDescriptions = ItemDesc.substring(0, ItemDesc.length - 1);
    return dataString;
}

//FUNCTION FOR GET CONTAINER DETAILS DATA 
function GetContainerDetailsData() {
    let ContainerDetails = new Array();
    let CheckRowCount = $("#ContainerTypeNo").val();
    let ContainerRow = $('#TblContainerDetails tbody').children().length;
    if (CheckRowCount == '') {
        if (ContainerRow > 1) {
            container_num_count = false;
            Toast('Container Numbers are not matching with the Container Type Number', 'Message', 'error');
            return;
        }

        else if ($('#TblContainerDetails tbody').children().find('.ContainerNo').val() != '') {
            container_num_count = false;
            Toast("Container Number can't be filled while Container Type Number is not given ", 'Message', 'error');
            return;
        }
    }
    else if (CheckRowCount != ContainerRow) {
        container_num_count = false;
        Toast('Container Rows must be equal to the Container Type Number', 'Message', 'error');
        return;
    }
    else if (CheckRowCount == ContainerRow) {
        $('#TblContainerDetails tbody tr').each(function (ind, ele) {
            if ($(ele).find('.ContainerNo').val().trim().length == 0) {
                console.log(ind);
                container_num_count = false;
                Toast('Container Rows must be equal to the Container Type Number', 'Message', 'error');
                return false;
            }
        });
    }

    $('#TblContainerDetails tbody tr').each(function (ind, ele) {
        if ($(ele).find('.ContainerNo').val().trim().length > 0) {
            let ContDet = {};
            ContDet.ContainerNo = $(ele).find('.ContainerNo').val().trim();
            ContDet.ContType = $(ele).find('.ContType').val().trim();
            ContDet.SealNo = $(ele).find('.SealNo').val().trim();
            ContDet.ExciseSealNo = $(ele).find('.ExciseSealNumber').val().trim();
            ContDet.SealDate = $(ele).find('.SealDate').val().trim();
            ContDet.SealType = $(ele).find('.SealType').val().trim();
            ContDet.SealDeviceId = $(ele).find('.SealDeviceId').val().trim();
            ContDet.NetWeight = parseFloat($(ele).find('.NetWeight').val().trim());
            ContDet.NetWeightType = $(ele).find('.NetWeightType').val().trim();
            ContDet.GrossWeight = parseFloat($(ele).find('.GrossWeight').val().trim());

            ContDet.TareWeight = parseFloat($(ele).find('.TareWeight').val().trim());
            ContDet.VGMWeight = parseFloat($(ele).find('.VGMWeight').val().trim());
            ContDet.NoOfPackage = parseInt($(ele).find('.NoOfPackage').val().trim());
            ContDet.PackageType = $(ele).find('.PackageType').val().trim();
            ContDet.Transporter = parseInt($(ele).find('.HiddenTransporter').val().trim());
            ContDet.TruckNo = $(ele).find('.TruckNo').val().trim();
            ContDet.PickupDate = $(ele).find('.PickupDate').val().trim();
            ContDet.StuffingDate = $(ele).find('.StuffingDate').val().trim();
            ContDet.PortGateInDate = $(ele).find('.PortGateInDate').val().trim();
            ContDet.ContainerRemarks = $(ele).find('.ContainerRemarks').val().trim();

            ContainerDetails.push(ContDet);
        }
    });
    return ContainerDetails;
}

//FUNCTION FOR GET INVOICE DETAILS DATA
function GetInvoiceDetailsData() {
    let InvoiceDetails = new Array();

    $('#TblInvoiceDetails tbody tr').each(function (ind, ele) {
        if ($(ele).find('.InvoiceNo').val().trim().length > 0) {
            let InvDet = {};
            InvDet.InvoiceSrNo = ind + 1;
            InvDet.Relation = $(ele).find('.Relation').val();
            InvDet.InvoiceNo = $(ele).find('.InvoiceNo').val().trim();
            InvDet.InvoiceDate = $(ele).find('.InvoiceDate').val().trim();
            InvDet.InvoiceTerms = $(ele).find('.NatureOfContract').val().trim();
            InvDet.InvoiceCurrency = $(ele).find('.InvoiceCurrency').val().trim();
            InvDet.InvoiceCurrencyExchangeRate = SetNullNumericField($(ele).find('.InvoiceCurrencyExchangeRate').val().trim());
            InvDet.GrossWeightKg = SetNullNumericField($(ele).find('.GrossWeightKg').val().trim());
            InvDet.NetWeightMetric = SetNullNumericField($(ele).find('.NetWeightMetric').val().trim());
            InvDet.NetUnit = $(ele).find('.NetUnit').val().trim();

            InvDet.InvoiceValue = SetNullNumericField($(ele).find('.InvoiceValue').val().trim());
            InvDet.FreightPer = SetNullNumericField($(ele).find('.FreightPer').val().trim());
            InvDet.ActualFreight = SetNullNumericField($(ele).find('.ActualFreight').val().trim());
            InvDet.FreightCurrency = $(ele).find('.FreightCurrency').val().trim();
            InvDet.FreightExchangeRate = SetNullNumericField($(ele).find('.FreightExchangeRate').val().trim());
            InvDet.FreightINR = SetNullNumericField($(ele).find('.FreightINR').val().trim());
            InvDet.InsurancePer = SetNullNumericField($(ele).find('.InsurancePer').val().trim());
            InvDet.ActualInsurance = SetNullNumericField($(ele).find('.ActualInsurance').val().trim());
            InvDet.InsuranceCurrency = $(ele).find('.InsuranceCurrency').val().trim();
            InvDet.InsuranceExchangeRate = SetNullNumericField($(ele).find('.InsuranceExchangeRate').val().trim());

            InvDet.InsuranceINR = SetNullNumericField($(ele).find('.InsuranceINR').val().trim());
            InvDet.CommissionPer = SetNullNumericField($(ele).find('.CommissionPer').val().trim());
            InvDet.ActualCommission = SetNullNumericField($(ele).find('.ActualCommission').val().trim());
            InvDet.CommissionCurrency = $(ele).find('.CommissionCurrency').val().trim();
            InvDet.CommissionExchangeRate = SetNullNumericField($(ele).find('.CommissionExchangeRate').val().trim());
            InvDet.CommissionInr = SetNullNumericField($(ele).find('.CommissionINR').val().trim());
            InvDet.DiscountPer = SetNullNumericField($(ele).find('.DiscountPer').val().trim());
            InvDet.ActualDiscount = SetNullNumericField($(ele).find('.ActualDiscount').val().trim());
            InvDet.DiscountCurrency = $(ele).find('.DiscountCurrency').val().trim();
            InvDet.DiscountExchangeRate = SetNullNumericField($(ele).find('.DiscountExchangeRate').val().trim());

            InvDet.DiscountInr = SetNullNumericField($(ele).find('.DiscountINR').val().trim());
            InvDet.MiscCharges = SetNullNumericField($(ele).find('.MiscCharges').val().trim());
            InvDet.MiscChargesINR = SetNullNumericField($(ele).find('.MiscChargesINR').val().trim());
            InvDet.OtherChargesPer = SetNullNumericField($(ele).find('.OtherChargesPer').val().trim());
            InvDet.ActualOtherCharges = SetNullNumericField($(ele).find('.ActualOtherCharges').val().trim());
            InvDet.OtherChargesCurrency = $(ele).find('.OtherChargesCurrency').val().trim();
            InvDet.OtherChargesExchangeRate = SetNullNumericField($(ele).find('.OtherChargesExchangeRate').val().trim());
            InvDet.OtherChargesInr = SetNullNumericField($(ele).find('.OtherChargesINR').val().trim());
            InvDet.FOBValue = SetNullNumericField($(ele).find('.FOBValue').val().trim());
            InvDet.PMVRateInvoice = SetNullNumericField($(ele).find('.PMVRateInvoice').val().trim());
            InvDet.PMVUnitInvoice = $(ele).find('.PMVUnitInvoice').val().trim();
            InvDet.PMVQuantity = SetNullNumericField($(ele).find('.PMVQuantity').val().trim());
            InvDet.PMVVALUE = SetNullNumericField($(ele).find('.PMVValue').val().trim());

            InvoiceDetails.push(InvDet);
        }
    });
    return InvoiceDetails;
}

//FUNCTION FOR GET ITEM DETAILS DATA
function GetItemDetailsData() {
    let ItemDetails = new Array();

    $('#TblItemDetails tbody tr').each(function (ind, ele) {

        let ItInv = $(ele).find('.TblItemInvoiceNo').val();

        if (ItInv != null && ItInv != undefined && ItInv != 0 && ItInv != '') {
            let ItDet = {};
            ItDet.InvoiceNumber = $(ele).find('.TblItemInvoiceNo option:selected').text();
            ItDet.InvoiceSrNo = $(ele).find('.TblItemInvoiceNo').val();
            ItDet.ItemSrNo = ind + 1;
            ItDet.ItemName = $(ele).find('.TblItemName').val().trim();
            ItDet.ItemDescription1 = $(ele).find('.TblItemDescription').val().substring(0, 59);
            ItDet.ItemDescription2 = $(ele).find('.TblItemDescription').val().substring(60, 119);
            ItDet.EndUse = $(ele).find('.TblItemEndUse').val().trim();
            ItDet.EndUseDesc = $(ele).find('.TblItemEndUseDesc').val().trim();
            ItDet.ItemAmount = SetNullNumericField($(ele).find('.TblItemAmount').val().trim());
            ItDet.Quantity = SetNullNumericField($(ele).find('.TblItemQuantity').val().trim());
            ItDet.ItemUnitPrice = SetNullNumericField($(ele).find('.TblItemUnitPrice').val().trim());
            ItDet.UnitQuantityCode = $(ele).find('.TblUnitQuantityCode').val().trim();

            ItDet.ItemFreight = SetNullNumericField($(ele).find('.TblItemFreight').val().trim());
            ItDet.ItemInsurance = SetNullNumericField($(ele).find('.TblItemInsurance').val().trim());
            ItDet.ItemCommission = SetNullNumericField($(ele).find('.TblItemCommission').val().trim());
            ItDet.ItemDiscount = SetNullNumericField($(ele).find('.TblItemDiscount').val().trim());
            ItDet.ItemMiscCharge = SetNullNumericField($(ele).find('.TblItemMiscCharge').val().trim());
            ItDet.ItemOtherCharges = SetNullNumericField($(ele).find('.TblItemOtherCharges').val().trim());
            ItDet.ItemFOBValue = SetNullNumericField($(ele).find('.TblFOBValue').val().trim());
            ItDet.ItemPMVValue = SetNullNumericField($(ele).find('.TblPMVValue').val().trim());

            ItDet.RewardItem = $(ele).find('.TblRewardItem').val() == 0 ? false : true;
            ItDet.JobWorkNotificationNo = SetNullNumericField($(ele).find('.TblJobWorkNotificationNo').val().trim());
            ItDet.AccessoryStatus = SetNullNumericField($(ele).find('.TblAccessStatus').val().trim());
            ItDet.ItemIGSTPaymentStatus = $(ele).find('.TblIGSTPaymentStatus').val().trim();
            ItDet.ItemTaxableValue = SetNullNumericField($(ele).find('.TblTaxableValue').val().trim());
            ItDet.ItemIGSTValue = SetNullNumericField($(ele).find('.TblIGSTAmount').val().trim());
            ItDet.ItemIGSTRate = SetNullNumericField($(ele).find('.TblIGSTRate').val().trim());


            ItDet.ManufacturerProducerGrower = $(ele).find('.HiddenTblItemManufacturerProducerGrowerName').val().trim();
            ItDet.ManufacturerProducerGrowerName = $(ele).find('.TblItemManufacturerProducerGrowerName').val().trim();
            ItDet.ItemManufacturerProducerCodeType = $(ele).find('.TblItemManufacturerProducerCodeType').val().trim();
            ItDet.ItemManufacturerProducerGrowerCode = $(ele).find('.TblItemManufacturerProducerGrowerCode').val().trim();
            ItDet.ItemManufacturerProducerGrowerAddress1 = $(ele).find('.TblItemManufacturerProducerGrowerAddress1').val().trim();
            ItDet.ItemManufacturerProducerGrowerAddress2 = $(ele).find('.TblItemManufacturerProducerGrowerAddress2').val().trim();
            ItDet.ItemManufacturerProducerGrowerCity = $(ele).find('.TblItemManufacturerProducerGrowerCity').val().trim();
            ItDet.ItemManufacturerProducerGrowerCountrySubDivision = $(ele).find('.TblItemManufacturerProducerGrowerCountrySubDivision').val().trim();
            ItDet.ItemManufacturerProducerGrowerPin = $(ele).find('.TblItemManufacturerProducerGrowerPin').val().trim();
            ItDet.ItemManufacturerCountry = $(ele).find('.HiddenTblItemManufacturerCountry').val().trim();
            ItDet.ItemManufacturerCountryName = $(ele).find('.TblItemManufacturerCountryName').val().trim();
            ItDet.SourceCountry = $(ele).find('.HiddenTblSourceCountryName').val().trim();
            ItDet.SourceCountryName = $(ele).find('.TblSourceCountryName').val().trim();
            ItDet.TransitCountry = $(ele).find('.HiddenTblTransitCountry').val().trim();
            ItDet.TransitCountryName = $(ele).find('.TblTransitCountryName').val().trim();
            ItemDetails.push(ItDet);
        }
    });
    return ItemDetails;
}

//FUNCTION FOR GET PACKING DETAILS DATA
function GetPackingDetailsData() {
    let PackingDetails = new Array();

    $('#TblPackingDetails tbody tr').each(function (ind, ele) {

        let PackDet = {};
        if ($(ele).find('.PacketNoTo').val().trim().length > 0 && $(ele).find('.PacketNoFrom').val().trim().length > 0 && $(ele).find('.PacketType').val().trim().length > 0) {
            PackDet.PacketNoFrom = $(ele).find('.PacketNoFrom').val().trim();
            PackDet.PacketNoTo = $(ele).find('.PacketNoTo').val().trim();
            PackDet.PacketType = $(ele).find('.PacketType').val().trim();
            PackDet.PackingCode = $(ele).find('.PacketType').val().trim().substring(0, 3);
            PackingDetails.push(PackDet);
        }
    });

    return PackingDetails;
}

//FUNCTION FOR GET JOB SUPPORT DOCS DETAILS DATA
function GetJobSupportDocsDetailsData() {
    let JobSupportDocsDetails = new Array();
    $('#TblJobSupportDocs tbody tr').each(function (ind, ele) {
        let ImgRefNo = $(ele).find('.TblImgRefNo').val();
        if (ImgRefNo != undefined && ImgRefNo != null && ImgRefNo != '') {
            let JobSupportDocsDet = {};
            JobSupportDocsDet.ESanchitSrNo = ind + 1;
            JobSupportDocsDet.JobNo = $('#JobNo').val().trim();
            JobSupportDocsDet.DeclarationType = 'E';
            JobSupportDocsDet.DocumentLevel = $(ele).find('.TblDocLevel').val().trim();
            JobSupportDocsDet.InvoiceSrNo = $(ele).find('.TblInvoiceSrNo').val().trim();
            JobSupportDocsDet.ItemSrNo = $(ele).find('.TblItemSrNo').val().trim();
            JobSupportDocsDet.ICEGATEUserId = $(ele).find('.TblIceGate').val().trim();
            JobSupportDocsDet.ImageReferenceNo = $(ele).find('.TblImgRefNo').val().trim();
            JobSupportDocsDet.DocumentTypeCode = $(ele).find('.HiddenTblDocType').val().trim();
            JobSupportDocsDet.UploadDateTime = $(ele).find('.TblDocUploadDate').val().trim();
            JobSupportDocsDet.DocumentIssuingPartyCode = $(ele).find('.TblDocIssuingPartyCode').val().trim();
            JobSupportDocsDet.DocumentIssuingParty = $(ele).find('.HiddenTblDocIssuingParty').val().trim();
            /* JobSupportDocsDet.DocumentReferenceNo = $(ele).find('.TblDocRefNo').val().trim();*/
            JobSupportDocsDet.PlaceOfIssue = $(ele).find('.TblPlaceOfIssue').val().trim();
            JobSupportDocsDet.DocumentIssueDate = $(ele).find('.TblDocIssueDate').val().trim();
            JobSupportDocsDet.DocumentExpiryDate = $(ele).find('.TblDocExpiryDate').val().trim();
            JobSupportDocsDet.DocumentBeneficiaryPartyCode = $(ele).find('.TblDocBeneficiaryPartyCode').val().trim();
            JobSupportDocsDet.DocumentBeneficiaryParty = $(ele).find('.HiddenTblDocBeneficiaryParty').val().trim();
            JobSupportDocsDet.FileType = $(ele).find('.TblFileType').val().trim();
            JobSupportDocsDet.DocumentTypeCodeDescriptions = $(ele).find('.TblDocType').val().trim();
            JobSupportDocsDet.FileName = $(ele).find('.TblFileName').val().trim();
            JobSupportDocsDet.UniqueSerialNo = $(ele).find('.TblUniqueItemSrNo').val().trim();
            JobSupportDocsDetails.push(JobSupportDocsDet);
        }
    });
    return JobSupportDocsDetails;
}

//FUNCTION FOR GET CURRENCY EXCHANGE RATE AND SET IN EXCHANGE RATE FIELD
function GetCurrencyExchangeRate(Hid, Id, JobDate, JobType) {
    try {
        const dataString = {};
        dataString.CurrencyUid = $('#' + Hid).val();
        dataString.JobDate = $('#' + JobDate).val().trim();
        dataString.JobType = JobType;
        AjaxSubmission(JSON.stringify(dataString), '/Master/_Layout/GetCurrencyExchangeRate', $('input[name=__RequestVerificationToken]').val()).done(function (result) {
            let obj = result;
            if (obj.status == true) {
                if (obj.responsecode == '100')
                    $('#' + Id).val(HandleNullNumericValue(obj.data.Table[0].currency_ie_rate).toFixed(2));
                else if (obj.responsecode == '604')
                    $('#' + Id).val('0.00');
                else
                    Toast(RetrieveMessage(obj.responsecode), 'Message', 'error');
            } else
                window.location.href = '/ClientLogin/ClientLogin';

        }).fail(function (result) {
            console.log(result.message);
        });
    }
    catch (e) {
        console.log(e.message);
    }
}

//FUNCTION FOR CALCULATE INSURANCE WITH INSURANCE PERCENTAGE
function InsuranceCalculate(e, fx) {
    let InvValue = 0, Excrate = 0, TInsurance = 0, Iper = 0;

    InvValue = HandleNullNumericValue($(e).parent().parent().find('.InvoiceValue').val());
    Excrate = HandleNullNumericValue($(e).parent().parent().find('.InvoiceCurrencyExchangeRate').val());
    Iper = HandleNullNumericValue($(e).parent().parent().find('.InsurancePer').val());

    if (InvValue > 0 && Excrate > 0 && Iper > 0) {
        TInsurance = (InvValue * Excrate * Iper) / 100;
        $(e).parent().parent().find('.InsuranceINR').val(TInsurance.toFixed(fx));
    } else {
        $(e).parent().parent().find('.InsuranceINR').val('0.00');
    }

}

/*SCHEME CODE CHANGE*/
function SchemCodeChange(e) {
    let sval = $(e).val();
    if (sval == '99')
        $('#NFEICategory').removeAttr('disabled');
    else
        $('#NFEICategory').attr('disabled', 'disabled');
    GetSchemeFeautures(sval);
}

/*FUNCTION FOR GET SCHEME FEATURES*/

function GetSchemeFeautures(e) {
    try {
        const dataString = {};
        dataString.SchemeCode = e;
        AjaxSubmission(JSON.stringify(dataString), '/Master/_Layout/GetSchemeFeautures', $('input[name=__RequestVerificationToken]').val()).done(function (result) {
            let obj = result;
            if (obj.status == true) {
                if (obj.responsecode == '100') {

                    console.log('DEEC', obj.data.Table[0].DEEC);
                    console.log('DEPB', obj.data.Table[0].DEPB);
                    console.log('DFIA', obj.data.Table[0].DFIA);
                    console.log('DrawBack', obj.data.Table[0].DrawBack);
                    console.log('EOU', obj.data.Table[0].EOU);
                    console.log('EPCG', obj.data.Table[0].EPCG);
                    console.log('JobWork', obj.data.Table[0].JobWork);
                    console.log('ROSCTL', obj.data.Table[0].ROSCTL);
                }
            }
            else
                window.location.href = '/ClientLogin/ClientLogin';
        }).fail(function (result) {
            console.log(result.Message);
        });
    }
    catch (e) {
        console.log(e.message);
    }
}

function DutyCalculation() {
    $("#TblInvoiceDetails tbody tr").each(function (InvInd, InvEle) {
        let Inv_Ser, Inv_Amt, Inv_Exch_Rate, Inv_Misc_Chrg, Inv_Misc_Chrg_Inr, Inv_Fr_Inr, Inv_Ins_Inr, Inv_Commission_Inr, Inv_Discount_Inr, Inv_OtherCharges_Inr, Inv_Pmv, _Amt = 0;
        let It_Inv;
        Inv_Ser = InvInd + 1;
        Inv_Amt = HandleNullNumericValue($(InvEle).find('.InvoiceValue').val());
        Inv_Exch_Rate = HandleNullNumericValue($(InvEle).find('.InvoiceCurrencyExchangeRate').val());
        Inv_Fr_Inr = HandleNullNumericValue($(InvEle).find('.FreightINR').val());
        Inv_Ins_Inr = HandleNullNumericValue($(InvEle).find('.InsuranceINR').val());
        Inv_Commission_Inr = HandleNullNumericValue($(InvEle).find('.CommissionINR').val());
        Inv_Discount_Inr = HandleNullNumericValue($(InvEle).find('.DiscountINR').val());
        Inv_Misc_Chrg = HandleNullNumericValue($(InvEle).find('.MiscCharges').val());
        Inv_Misc_Chrg_Inr = HandleNullNumericValue($(InvEle).find('.MiscChargesINR').val());
        Inv_OtherCharges_Inr = HandleNullNumericValue($(InvEle).find('.OtherChargesINR').val());
        Inv_Pmv = HandleNullNumericValue($(InvEle).find('.PMVValue').val());
        It_Inv = $('#NewItemInvoiceNo option:selected').val();
        if (Inv_Amt > 0 && Inv_Exch_Rate > 0) {
            if (It_Inv == Inv_Ser) {
                let It_Amt = 0, It_Wt = 0, It_Un_Pr = 0, It_Frt = 0, It_Insu = 0, It_Pmv = 0, It_Misc_Chrg = 0, It_Commission = 0, It_Discount = 0, It_Other_Charges = 0, _Amt = 0, _Amount;
                let It_FOB_Amt = 0;

                if ($('#NewItemName').val().trim().length > 0 &&
                    HandleNullNumericValue($('#NewItemAmount').val()) > 0 &&
                    HandleNullNumericValue($('#NewItemQuantity').val()) > 0) {

                    //FOR UNIT PRICE
                    It_Amt = HandleNullNumericValue($('#NewItemAmount').val());
                    It_Wt = HandleNullNumericValue($('#NewItemQuantity').val());

                    _Amount = _Amt = It_Amt * Inv_Exch_Rate;
                    It_Un_Pr = It_Amt / It_Wt;
                    $('#NewItemUnitPrice').val(It_Un_Pr.toFixed(5));

                    //FOR FREIGHT(INR)
                    if (Inv_Fr_Inr > 0) {
                        It_Frt = (Inv_Fr_Inr * It_Amt) / Inv_Amt;
                        $('#NewItemFreight').val(It_Frt.toFixed(2));
                        _Amt = _Amt + It_Frt;
                    }

                    //FOR INSURANCE(INR)
                    if (Inv_Ins_Inr > 0) {
                        It_Insu = (Inv_Ins_Inr * It_Amt) / Inv_Amt;
                        $('#NewItemInsurance').val(It_Insu.toFixed(2));
                        _Amt = _Amt + It_Insu;
                    }

                    //FOR COMMISSION(INR)
                    if (Inv_Commission_Inr > 0) {
                        It_Commission = (Inv_Commission_Inr * It_Amt) / Inv_Amt;
                        $('#NewItemCommission').val(It_Commission.toFixed(2));
                        _Amt = _Amt + It_Commission;
                    }

                    //FOR DISCOUNT(INR)
                    if (Inv_Discount_Inr > 0) {
                        It_Discount = (Inv_Discount_Inr * It_Amt) / Inv_Amt;
                        $('#NewItemDiscount').val(It_Discount.toFixed(2));
                        _Amt = _Amt - It_Discount;
                    }

                    //FOR MISCELLANEOUS CHARGE
                    if (Inv_Misc_Chrg > 0) {
                        It_Misc_Chrg = (Inv_Misc_Chrg * It_Amt) / Inv_Amt;
                        $('#NewItemMiscCharge').val(It_Misc_Chrg.toFixed(2));
                    }

                    //FOR MISCELLANEOUS CHARGES(INR)
                    if (Inv_Misc_Chrg_Inr > 0) {
                        It_Misc_Chrg = (Inv_Misc_Chrg_Inr * It_Amt) / Inv_Amt;
                        $('#NewItemMiscCharge').val(It_Misc_Chrg.toFixed(2));
                    }

                    _Amt = _Amt + It_Misc_Chrg;

                    //FOR OTHER CHARGES
                    if (Inv_OtherCharges_Inr > 0) {
                        It_Other_Charges = (Inv_OtherCharges_Inr * It_Amt) / Inv_Amt;
                        $('#NewItemOtherCharges').val(It_Other_Charges.toFixed(2));
                        _Amt = _Amt + It_Other_Charges;
                    }

                    _Amt = _Amt + It_Other_Charges;
                    /* console.log(_Amt);*/
                    It_FOB_Amt = _Amount - It_Frt - It_Insu - It_Other_Charges - It_Discount + It_Misc_Chrg;
                    /*console.log(It_FOB_Amt);*/
                    //  $('#TotalInvoiceValue').val(It_FOB_Amt.toFixed(2));
                    $('#NewItemFOBValue').val(It_FOB_Amt.toFixed(2));

                    //FOR PMV
                    if (Inv_Pmv > 0) {
                        It_Pmv = (Inv_Pmv * It_Amt) / Inv_Amt;
                        $('#NewItemPMVValue').val(It_Pmv.toFixed(2));
                        /*_Amt = _Amt + It_Frt;*/
                    }
                }
            }
        }
    });
}

//#endregion

//#region /****************************INVOICE DETAILS TAB ALL FUNCTION START****************************/

//NEWADDINVOICE BUTTON CLICK EVENT
$('#NewAddInvoice').click(function () {
    if ($('#NewInvoiceNo').val().trim().length <= 0) {
        $('#NewInvoiceNo').focus();
        Toast('Please Add Invioce Number', 'Message', 'error');
        return;
    }
    else if ($('#NewInvoiceDate').val().trim().length < 10) {
        $('#NewInvoiceDate').focus();
        Toast('Please Add Invioce Date', 'Message', 'error');
        return;
    }
    else if ($('#NewNatureOfContract').val() == "0") {
        $('#NewNatureOfContract').focus();
        Toast('Please Select Nature Of Contract.', 'Message', 'error');
        return;
    }
    else if ($('#NewInvoiceCurrency').val().trim().length <= 0) {
        $('#NewInvoiceCurrency').focus();
        Toast('Please Add Invioce Currency', 'Message', 'error');
        return;
    }
    else if ($('#NewInvoiceCurrencyExchangeRate').val().trim() <= 0) {
        $('#NewInvoiceCurrencyExchangeRate').focus();
        Toast('Please Add Invioce Currency Exchange Rate', 'Message', 'error');
        return;
    }
    else if ($('#NewNetUnit').val().trim() <= 0) {
        $('#NewNetUnit').focus();
        Toast('Please Add Net Unit', 'Message', 'error');
        return;
    }

    else if ($('#NewInvoiceValue').val().trim() <= 0) {
        $('#NewInvoiceValue').focus();
        Toast('Please Add Invoice Value', 'Message', 'error');
        return;
    }

    else if ($('#NewFOBValue').val().trim() <= 0) {
        $('#NewFOBValue').focus();
        Toast('Please Add FOB Value', 'Message', 'error');
        return;
    }

    else if ($('#NewPMVRateInvoice').val().trim() <= 0) {
        $('#NewPMVRateInvoice').focus();
        Toast('Please Add PMV Value', 'Message', 'error');
        return;
    }

    else if ($('#NewPMVUnitInvoice').val() <= 0) {
        $('#NewPMVUnitInvoice').focus();
        Toast('Please Add PMV Unit', 'Message', 'error');
        return;
    }
    else {
        NewAddInvoiceRow();
    }

});

//FUNCTION FOR NEW ADD INVOICE 
function NewAddInvoiceRow() {
    let flag = 0;
    TblLen = $("#TblInvoiceDetails tbody tr").length;
    let tbody = $("#TblInvoiceDetails").find("tbody");
    let FirstTr = $(tbody).find("tr:first");
    let Invt = '';

    $("#TblInvoiceDetails tbody tr").each(function (ind, ele) {
        if ($(ele).find('.InvoiceNo').val().trim() == $('#NewInvoiceNo').val().trim()) {
            flag = 1;
            return;
        }
    });

    function AddInvoiceData() {
        Invt.find('.Relation').val($('#NewRelationInvoice').val());
        Invt.find('.InvoiceNo').val($('#NewInvoiceNo').val().trim());
        Invt.find('.InvoiceDate').val($('#NewInvoiceDate').val());
        Invt.find('.NatureOfContract').val($('#NewNatureOfContract').val());
        Invt.find('.InvoiceCurrency').val($('#NewInvoiceCurrency').val());
        Invt.find('.InvoiceCurrencyExchangeRate').val($('#NewInvoiceCurrencyExchangeRate').val());
        Invt.find('.GrossWeightKg').val($('#NewGrossWeightKgInvoice').val());
        Invt.find('.NetWeightMetric').val($('#NewNetWeightMetricInvoice').val());
        Invt.find('.InvoiceValue').val($('#NewInvoiceValue').val());
        Invt.find('.NetUnit').val($('#NewNetUnit').val());

        Invt.find('.FreightPer').val($('#NewFreightPerInvoice').val());
        Invt.find('.ActualFreight').val($('#NewActualFreightInvoice').val());
        Invt.find('.FreightCurrency').val($('#NewFreightCurrencyInvoice').val());
        Invt.find('.FreightExchangeRate').val($('#NewFreightExchangeRateInvoice').val());
        Invt.find('.FreightINR').val($('#NewFreightINRInvoice').val());

        Invt.find('.InsurancePer').val($('#NewInsurancePerInvoice').val());
        Invt.find('.ActualInsurance').val($('#NewActualInsuranceInvoice').val());
        Invt.find('.InsuranceCurrency').val($('#NewInsuranceCurrencyInvoice').val());
        Invt.find('.InsuranceExchangeRate').val($('#NewInsuranceExchangeRateInvoice').val());
        Invt.find('.InsuranceINR').val($('#NewInsuranceINRInvoice').val());

        Invt.find('.CommissionPer').val($('#NewCommissionPerInvoice').val());
        Invt.find('.ActualCommission').val($('#NewActualCommissionInvoice').val());
        Invt.find('.CommissionCurrency').val($('#NewCommissionCurrencyInvoice').val());
        Invt.find('.CommissionExchangeRate').val($('#NewCommissionExchangeRateInvoice').val());
        Invt.find('.CommissionINR').val($('#NewCommissionINRInvoice').val());


        Invt.find('.DiscountPer').val($('#NewDiscountPerInvoice').val());
        Invt.find('.ActualDiscount').val($('#NewActualDiscountInvoice').val());
        Invt.find('.DiscountCurrency').val($('#NewDiscountCurrencyInvoice').val());
        Invt.find('.DiscountExchangeRate').val($('#NewDiscountExchangeRateInvoice').val());
        Invt.find('.DiscountINR').val($('#NewDiscountINRInvoice').val());


        Invt.find('.MiscCharges').val($('#NewMiscChargesInvoice').val());
        Invt.find('.MiscChargesINR').val($('#NewMiscChargesINRInvoice').val());


        Invt.find('.OtherChargesPer').val($('#NewOtherChargesPerInvoice').val());
        Invt.find('.ActualOtherCharges').val($('#NewActualOtherChargesInvoice').val());
        Invt.find('.OtherChargesCurrency').val($('#NewOtherChargesCurrencyInvoice').val());
        Invt.find('.OtherChargesExchangeRate').val($('#NewOtherChargesExchangeRateInvoice').val());
        Invt.find('.OtherChargesINR').val($('#NewOtherChargesINRInvoice').val());


        Invt.find('.FOBValue').val($('#NewFOBValue').val());

        Invt.find('.PMVRateInvoice').val($('#NewPMVRateInvoice').val());
        // Invt.find('.HiddenPMVUnit').val($('#NewHiddenPMVUnit').val());
        Invt.find('.PMVUnitInvoice').val($('#NewPMVUnit').val());
        Invt.find('.PMVQuantity').val($('#NewPMVQuantity').val());
        Invt.find('.PMVValue').val($('#NewPMVValue').val());
    }

    if (flag == 0) {
        if ($('#TblInvoiceDetails tbody tr').find('.InvoiceNo').val().length <= 0 || $('#TblInvoiceDetails tbody tr').find('.InvoiceDate').val().length < 10 || $('#TblInvoiceDetails tbody tr').find('.InvoiceCurrency').val().length < 0 || $('#TblInvoiceDetails tbody tr').find('.InvoiceCurrencyExchangeRate').val().length < 0 || $('#TblInvoiceDetails tbody tr').find('.InvoiceValue').val().length < 0) {
            Invt = FirstTr;
            AddInvoiceData();
        }
        else {
            FirstTr.find('.InvoiceDate').datepicker("destroy");
            FirstTr.find('.InvoiceDate').removeAttr("id");
            Invt = $(FirstTr).clone();
            Invt.find('.Relation').val('N');
            Invt.find('.InvoiceNo,.InvoiceDate,.HiddenInvoiceCurrency,.InvoiceCurrency,.HiddenFreightCurrency,.FreightCurrency,.HiddenInsuranceCurrency,.InsuranceCurrency,.HiddenCommissionCurrency,.CommissionCurrency,.HiddenDiscountCurrency,.DiscountCurrency,.HiddenOtherChargesCurrency,.OtherChargesCurrency').val('');
            /*    Invt.find('.NatureOfTransaction').val('S');*/
            Invt.find('.NatureOfContract').val('0');
            Invt.find('.InvoiceCurrencyExchangeRate,.InvoiceValue,.ActualFreight,.FreightExchangeRate,.FreightINR,.ActualInsurance,.InsuranceExchangeRate,.InsuranceINR,.ActualCommission,.CommissionExchangeRate,.CommissionINR,.ActualDiscount,.DiscountExchangeRate,.DiscountINR,.ActualOtherCharges,.OtherChargesExchangeRate,.OtherChargesINR,.MiscCharges,.MiscChargesINR').val('0.00');
            Invt.find('.NetWeightMetric,.GrossWeightKg').val('0.000');
            Invt.find('.FreightPer,.InsurancePer,.OtherChargesPer,.CommissionPer,.DiscountPer').val('0.0000');
            AddInvoiceData();
            $("#TblInvoiceDetails").append(Invt);
            $(".datepickerAll").datepicker({
                changeMonth: true,
                changeYear: true,
                dateFormat: 'dd/mm/yy'
            });
            GenerateSerialNumberTable('TblInvoiceDetails', 'rn');
        }
        ResetNewInvoice(true);
        CalculateTotalNetWeight();
        CalculateTotalGrossWeight();
        CalculateTotalInvoiceValue();
        NewGenerateInvoiceNoList();
        Toast('Invoice Add Successfully.', 'Message', 'success');
    }
    else
        Toast('Duplicate Invoice Number.', 'Message', 'error');
};

//NEWRESETRESETINVOICE BUTTON CLICK EVENT
$('#NewResetInvoice').click(function () {
    ResetNewInvoice(true);
});

//FUNCTION FOR NEW RESET INVOICE
function ResetNewInvoice(flag) {

    const disabledInvoiceid = ['NewFreightPerInvoice', 'NewActualFreightInvoice', 'NewFreightExchangeRateInvoice', 'NewFreightINRInvoice', 'HiddenNewFreightCurrencyInvoice', 'NewFreightCurrencyInvoice', 'NewActualInsuranceInvoice', 'HiddenNewInsuranceCurrencyInvoice', 'NewInsuranceCurrencyInvoice', 'NewInsuranceExchangeRateInvoice', 'NewInsurancePerInvoice', 'NewInsuranceINRInvoice',];

    disabledInvoiceid.forEach((ele) => {
        $('#' + ele).attr('disabled', 'disabled');
    });

    const blankInvoiceId = ['NewRownNumInvoice', 'NewInvoiceNo', 'NewInvoiceDate', 'HiddenNewInvoiceCurrency', 'NewInvoiceCurrency', 'HiddenNewFreightCurrencyInvoice', 'NewFreightCurrencyInvoice', 'HiddenNewInsuranceCurrencyInvoice', 'NewInsuranceCurrencyInvoice', 'HiddenNewCommissionCurrencyInvoice', 'NewCommissionCurrencyInvoice', 'HiddenNewDiscountCurrencyInvoice', 'NewDiscountCurrencyInvoice', 'HiddenNewOtherChargesCurrencyInvoice', 'NewOtherChargesCurrencyInvoice', 'NewPMVQuantity', 'NewNetUnit', 'NewHiddenNetUnit'];

    blankInvoiceId.forEach((ele) => {
        $('#' + ele).val('');
    });
    const zeroInvoiceId = ['NewInvoiceCurrencyExchangeRate', 'NewInvoiceValue', 'NewActualFreightInvoice', 'NewFreightExchangeRateInvoice', 'NewFreightINRInvoice', 'NewActualInsuranceInvoice', 'NewInsuranceExchangeRateInvoice', 'NewInsuranceINRInvoice', 'NewMiscChargesInvoice', 'NewMiscChargesINRInvoice', 'NewActualCommissionInvoice', 'NewCommissionExchangeRateInvoice', 'NewCommissionINRInvoice', 'NewActualOtherChargesInvoice', 'NewOtherChargesExchangeRateInvoice', 'NewOtherChargesINRInvoice', 'NewActualDiscountInvoice', 'NewDiscountExchangeRateInvoice', 'NewDiscountINRInvoice', 'NewActualCommissionInvoice', 'NewCommissionExchangeRateInvoice', 'NewCommissionINRInvoice', 'NewFOBValue', 'NewPMVValue', 'NewPMVRateInvoice'];

    zeroInvoiceId.forEach((ele) => {
        $('#' + ele).val('0.00');
    });

    $('#NewRelationInvoice').val('N');
    $('#NewPMVUnit').val('FOB');
    //  $('#NewNatureOfTransactionInvoice').val('S');
    $('#NewNatureOfContract').val(0);
    $('#NewNetWeightMetricInvoice,#NewGrossWeightKgInvoice').val('0.000');
    $('#NewFreightPerInvoice,#NewInsurancePerInvoice,#NewCommissionPerInvoice,#NewDiscountPerInvoice,#NewOtherChargesPerInvoice').val('0.0000');

    $("#NewAddInvoice").removeClass('d-none');
    $("#NewUpdateInvoice").addClass('d-none');

    if (flag)
        $("#NewInvoiceNo").focus();
}

//FUNCTION FOR EDIT INVOICE ROW ENTRY
function EditInvoiceRowEntry(e) {
    let Rn = $(e).parent().parent().find('.rn').text().trim();
    let InvNo = $(e).parent().parent().find('.InvoiceNo').val().trim();

    if (InvNo.length == 0)
        Toast('Invoice Number Blank!', 'Message', 'error');
    else {

        ResetNewInvoice();

        $('#NewAddInvoice').addClass('d-none');
        $('#NewUpdateInvoice').removeClass('d-none');

        $('#NewRownNumInvoice').val(Rn);

        $('#NewRelationInvoice').val($(e).parent().parent().find('.Relation').val());
        $('#NewInvoiceNo').val($(e).parent().parent().find('.InvoiceNo').val());
        $('#NewInvoiceDate').val($(e).parent().parent().find('.InvoiceDate').val());
        $('#NewNatureOfContract').val($(e).parent().parent().find('.NatureOfContract').val()).trigger('change');
        $('#NewInvoiceCurrency').val($(e).parent().parent().find('.InvoiceCurrency').val());

        $('#NewInvoiceCurrencyExchangeRate').val($(e).parent().parent().find('.InvoiceCurrencyExchangeRate').val());

        $('#NewGrossWeightKgInvoice').val($(e).parent().parent().find('.GrossWeightKg').val());
        $('#NewNetWeightMetricInvoice').val($(e).parent().parent().find('.NetWeightMetric').val());

        $('#NewInvoiceValue').val($(e).parent().parent().find('.InvoiceValue').val());
        $('#NewNetUnit').val($(e).parent().parent().find('.NetUnit').val());

        $('#NewFreightPerInvoice').val($(e).parent().parent().find('.FreightPer').val());
        $('#NewActualFreightInvoice').val($(e).parent().parent().find('.ActualFreight').val());
        $('#NewFreightCurrencyInvoice').val($(e).parent().parent().find('.FreightCurrency').val());
        $('#NewFreightExchangeRateInvoice').val($(e).parent().parent().find('.FreightExchangeRate').val());
        $('#NewFreightINRInvoice').val($(e).parent().parent().find('.FreightINR').val());

        $('#NewInsurancePerInvoice').val($(e).parent().parent().find('.InsurancePer').val());
        $('#NewActualInsuranceInvoice').val($(e).parent().parent().find('.ActualInsurance').val());
        $('#NewInsuranceCurrencyInvoice').val($(e).parent().parent().find('.InsuranceCurrency').val());
        $('#NewInsuranceExchangeRateInvoice').val($(e).parent().parent().find('.InsuranceExchangeRate').val());
        $('#NewInsuranceINRInvoice').val($(e).parent().parent().find('.InsuranceINR').val());


        $('#NewCommissionPerInvoice').val($(e).parent().parent().find('.CommissionPer').val());
        $('#NewActualCommissionInvoice').val($(e).parent().parent().find('.ActualCommission').val());
        $('#NewCommissionCurrencyInvoice').val($(e).parent().parent().find('.CommissionCurrency').val());
        $('#NewCommissionExchangeRateInvoice').val($(e).parent().parent().find('.CommissionExchangeRate').val());
        $('#NewCommissionINRInvoice').val($(e).parent().parent().find('.CommissionINR').val());

        $('#NewDiscountPerInvoice').val($(e).parent().parent().find('.DiscountPer').val());
        $('#NewActualDiscountInvoice').val($(e).parent().parent().find('.ActualDiscount').val());
        $('#NewDiscountCurrencyInvoice').val($(e).parent().parent().find('.DiscountCurrency').val());
        $('#NewDiscountExchangeRateInvoice').val($(e).parent().parent().find('.DiscountExchangeRate').val());
        $('#NewDiscountINRInvoice').val($(e).parent().parent().find('.DiscountINR').val());

        $('#NewMiscChargesInvoice').val($(e).parent().parent().find('.MiscCharges').val());
        $('#NewMiscChargesINRInvoice').val($(e).parent().parent().find('.MiscChargesINR').val());

        $('#NewOtherChargesPerInvoice').val($(e).parent().parent().find('.OtherChargesPer').val());
        $('#NewActualOtherChargesInvoice').val($(e).parent().parent().find('.ActualOtherCharges').val());
        $('#NewOtherChargesCurrencyInvoice').val($(e).parent().parent().find('.OtherChargesCurrency').val());
        $('#NewOtherChargesExchangeRateInvoice').val($(e).parent().parent().find('.OtherChargesExchangeRate').val());
        $('#NewOtherChargesINRInvoice').val($(e).parent().parent().find('.OtherChargesINR').val());

        $('#NewFOBValue').val($(e).parent().parent().find('.FOBValue').val());

        $('#NewPMVRateInvoice').val($(e).parent().parent().find('.PMVRateInvoice').val());
        $('#NewPMVUnit').val($(e).parent().parent().find('.PMVUnitInvoice').val()).trigger('change');
        $('#NewPMVQuantity').val($(e).parent().parent().find('.PMVQuantity').val());
        $('#NewPMVValue').val($(e).parent().parent().find('.PMVValue').val());
    }
}

//NEWUPDATEINVOICE BUTTON CLICK EVENT
$('#NewUpdateInvoice').click(function () {
    if ($('#NewInvoiceNo').val().trim().length <= 0) {
        $('#NewInvoiceNo').focus();
        Toast('Please Add Invioce Number', 'Message', 'error');
        return;
    }
    else if ($('#NewInvoiceDate').val().trim().length < 10) {
        $('#NewInvoiceDate').focus();
        Toast('Please Add Invioce Date', 'Message', 'error');
        return;
    }
    else if ($('#NewNatureOfContract').val() == "0") {
        $('#NewNatureOfContract').focus();
        Toast('Please Select Nature Of Contract.', 'Message', 'error');
        return;
    }
    else if ($('#NewInvoiceCurrency').val().trim().length <= 0) {
        $('#NewInvoiceCurrency').focus();
        Toast('Please Add Invioce Currency', 'Message', 'error');
        return;
    }
    else if ($('#NewInvoiceCurrencyExchangeRate').val().trim() <= 0) {
        $('#NewInvoiceCurrencyExchangeRate').focus();
        Toast('Please Add Invioce Currency Exchange Rate', 'Message', 'error');
        return;
    }
    else if ($('#NewNetUnit').val().trim() <= 0) {
        $('#NewNetUnit').focus();
        Toast('Please Add Net Unit', 'Message', 'error');
        return;
    }

    else if ($('#NewInvoiceValue').val().trim() <= 0) {
        $('#NewInvoiceValue').focus();
        Toast('Please Add Goods Value', 'Message', 'error');
        return;
    }

    else if ($('#NewFOBValue').val().trim() <= 0) {
        $('#NewFOBValue').focus();
        Toast('Please Add FOB Value', 'Message', 'error');
        return;
    }

    else if ($('#NewPMVRateInvoice').val().trim() <= 0) {
        $('#NewPMVRateInvoice').focus();
        Toast('Please Add PMV Value', 'Message', 'error');
        return;
    }

    else if ($('#NewPMVUnitInvoice').val() <= 0) {
        $('#NewPMVUnitInvoice').focus();
        Toast('Please Add PMV Unit', 'Message', 'error');
        return;
    }
    else
        UpdateNewInvoiceRow($('#NewRownNumInvoice').val());
});

//FUNCTION FOR NEW UPDATE INVOICE 
function UpdateNewInvoiceRow(Rn) {
    let flag = 0;
    $("#TblInvoiceDetails tbody tr").each(function (ind, ele) {
        if ($(ele).find('.InvoiceNo').val().trim() == $('#NewInvoiceNo').val().trim() && $(ele).find('.rn').text().trim() != Rn) {
            flag = 1;
            return;
        }
    });

    if (flag == 1)
        Toast('Duplicate Invoice.', 'Message', 'error');
    else {
        $('#TblInvoiceDetails tbody tr').each(function (ind, ele) {
            if ($(ele).find('.rn').text().trim() == Rn) {

                $(ele).find('.Relation').val($('#NewRelationInvoice').val());
                $(ele).find('.InvoiceNo').val($('#NewInvoiceNo').val().trim());
                $(ele).find('.InvoiceDate').val($('#NewInvoiceDate').val());
                $(ele).find('.NatureOfContract').val($('#NewNatureOfContract').val());
                $(ele).find('.InvoiceCurrency').val($('#NewInvoiceCurrency').val());
                $(ele).find('.InvoiceCurrencyExchangeRate').val($('#NewInvoiceCurrencyExchangeRate').val());
                $(ele).find('.GrossWeightKg').val($('#NewGrossWeightKgInvoice').val());
                $(ele).find('.NetWeightMetric').val($('#NewNetWeightMetricInvoice').val());
                $(ele).find('.InvoiceValue').val($('#NewInvoiceValue').val());
                $(ele).find('.NetUnit').val($('#NewNetUnit').val());

                $(ele).find('.FreightPer').val($('#NewFreightPerInvoice').val());
                $(ele).find('.ActualFreight').val($('#NewActualFreightInvoice').val());
                $(ele).find('.FreightCurrency').val($('#NewFreightCurrencyInvoice').val());
                $(ele).find('.FreightExchangeRate').val($('#NewFreightExchangeRateInvoice').val());
                $(ele).find('.FreightINR').val($('#NewFreightINRInvoice').val());

                $(ele).find('.InsurancePer').val($('#NewInsurancePerInvoice').val());
                $(ele).find('.ActualInsurance').val($('#NewActualInsuranceInvoice').val());
                $(ele).find('.InsuranceCurrency').val($('#NewInsuranceCurrencyInvoice').val());
                $(ele).find('.InsuranceExchangeRate').val($('#NewInsuranceExchangeRateInvoice').val());
                $(ele).find('.InsuranceINR').val($('#NewInsuranceINRInvoice').val());

                $(ele).find('.CommissionPer').val($('#NewCommissionPerInvoice').val());
                $(ele).find('.ActualCommission').val($('#NewActualCommissionInvoice').val());
                $(ele).find('.CommissionCurrency').val($('#NewCommissionCurrencyInvoice').val());
                $(ele).find('.CommissionExchangeRate').val($('#NewCommissionExchangeRateInvoice').val());
                $(ele).find('.CommissionINR').val($('#NewCommissionINRInvoice').val());

                $(ele).find('.DiscountPer').val($('#NewDiscountPerInvoice').val());
                $(ele).find('.ActualDiscount').val($('#NewActualDiscountInvoice').val());
                $(ele).find('.DiscountCurrency').val($('#NewDiscountCurrencyInvoice').val());
                $(ele).find('.DiscountExchangeRate').val($('#NewDiscountExchangeRateInvoice').val());
                $(ele).find('.DiscountINR').val($('#NewDiscountINRInvoice').val());

                $(ele).find('.MiscCharges').val($('#NewMiscChargesInvoice').val());
                $(ele).find('.MiscChargesINR').val($('#NewMiscChargesINRInvoice').val());

                $(ele).find('.OtherChargesPer').val($('#NewOtherChargesPerInvoice').val());
                $(ele).find('.ActualOtherCharges').val($('#NewActualOtherChargesInvoice').val());
                $(ele).find('.OtherChargesCurrency').val($('#NewOtherChargesCurrencyInvoice').val());
                $(ele).find('.OtherChargesExchangeRate').val($('#NewOtherChargesExchangeRateInvoice').val());
                $(ele).find('.OtherChargesINR').val($('#NewOtherChargesINRInvoice').val());

                $(ele).find('.FOBValue').val($('#NewFOBValue').val());

                $(ele).find('.PMVRateInvoice').val($('#NewPMVRateInvoice').val());
                $(ele).find('.PMVUnitInvoice').val($('#NewPMVUnit').val());
                $(ele).find('.PMVQuantity').val($('#NewPMVQuantity').val());
                $(ele).find('.PMVValue').val($('#NewPMVValue').val());


                ResetNewInvoice();
                //CalculateTotalNetWeight();
                //CalculateTotalGrossWeight();
                //CalculateTotalInvoiceValue();
                Toast('Update Invoice Successfully.', 'Message', 'success');
                NewGenerateInvoiceNoList();
            }
        });
    }
}

// FUNCTION FOR DELETE INVOICE ROW  
function DeleteInvoiceRowEntry(e) {
    let flag = 0;
    let RowCount = $("#TblInvoiceDetails tbody tr").length;
    let InvNo = $(e).parent().parent().find('.InvoiceNo').val().trim();
    let InvRowNo = $(e).parent().parent().find('.rn').text();;
    let DelItSr = [];

    $('#TblItemDetails tbody tr').each(function (ind, ele) {
        if ($(ele).find('.TblItemInvoiceNo').val().trim().length > 0) {
            if ($(ele).find('.TblItemInvoiceNo option:selected').text() == InvNo) {
                flag = 1;
                DelItSr.push((ind + 1));
            }
        }
    });

    if (InvNo.length == 0)
        Toast('Invoice Number Blank!', 'Message', 'error');
    else {
        $.confirm({
            title: '',
            content: 'Are You Sure Want To Delete ?',
            type: 'red',
            boxWidth: '300px',
            useBootstrap: false,
            typeAnimated: true,
            columnClass: 'small',
            containerFluid: true,
            draggable: true,
            buttons: {
                tryAgain: {
                    text: 'Confirm',
                    btnClass: 'btn-red',
                    action: function () {
                        if (flag == 1) {
                            $.confirm({
                                title: '',
                                content: 'This Invoice Number Use In Item Details.Are You Sure Want To Delete ?',
                                type: 'red',
                                boxWidth: '300px',
                                useBootstrap: false,
                                typeAnimated: true,
                                columnClass: 'small',
                                containerFluid: true,
                                draggable: true,
                                buttons: {
                                    tryAgain: {
                                        text: 'Confirm',
                                        btnClass: 'btn-red',
                                        action: function () {
                                            DeleteESanchitRowItemWise(DelItSr);  //DELETE ITEM FROM ESANCHIT
                                            //  DeleteDestuffRowItemWise(DelItSr); // DELETE ITEM FROM DESTUFF
                                            //   DeleteLicenseRowItemWise(DelItSr); // DELETE ITEM FROM LICENSE
                                            //   DeleteItemRowInvoiceWise(InvNo); // DELETE INVOICE FROM ITEM
                                            ResetDeleteInvoiceRowEntry(e, RowCount); //DELETE INVOICE ROW ENTRY
                                            // NewGenerateItemNameList();
                                            //  CalculateTotalNetWeight();
                                            //  CalculateTotalGrossWeight();
                                            //   CalculateTotalInvoiceValue();
                                            GenerateSerialNumberTable('TblInvoiceDetails', 'rn');
                                            NewGenerateInvoiceNoList('Delete', InvRowNo);
                                        }
                                    },
                                    cancel: function () {
                                    }
                                }
                            });
                        }
                        else {
                            ResetDeleteInvoiceRowEntry(e, RowCount); //DELETE INVOICE ROW ENTRY
                            // CalculateTotalNetWeight();
                            // CalculateTotalGrossWeight();
                            // CalculateTotalInvoiceValue();
                            GenerateSerialNumberTable('TblInvoiceDetails', 'rn');
                            NewGenerateInvoiceNoList();

                        }
                    }
                },
                close: function () {
                }
            }
        });
    }
}

//FUNCTION FOR RESET OR DELETE IN INVOICE ROW 
function ResetDeleteInvoiceRowEntry(e, RowCount) {
    if (RowCount > 1)
        $(e).parent().parent().remove();
    else {
        $(e).parent().parent().find('.Relation').val('N');
        //   $(e).parent().parent().find('.NatureOfTransaction').val('S');
        $(e).parent().parent().find('.NatureOfContract').val('0');
        $(e).parent().parent().find('.PMVUnitInvoice').val('FOB');
        $(e).parent().parent().find('.InvoiceNo,.InvoiceDate,.HiddenInvoiceCurrency,.InvoiceCurrency,.HiddenFreightCurrency,.FreightCurrency,.HiddenInsuranceCurrency,.InsuranceCurrency,.HiddenCommissionCurrency,.CommissionCurrency,.HiddenDiscountCurrency,.DiscountCurrency,.HiddenOtherChargesCurrency,.OtherChargesCurrency,.NetUnit').val('');

        $(e).parent().parent().find('.InvoiceCurrencyExchangeRate,.InvoiceValue,.ActualFreight,.FreightExchangeRate,.FreightINR,.ActualInsurance,.InsuranceExchangeRate,.InsuranceINR,.MiscCharges,.MiscChargesINR,.ActualOtherCharges,.OtherChargesExchangeRate,.OtherChargesINR,.ActualDiscount,.DiscountExchangeRate,.DiscountINR,.ActualCommission,.CommissionExchangeRate,.CommissionINR,.FOBValue,.PMVRateInvoice,.PMVQuantity,.PMVValue').val('0.00');

        $(e).parent().parent().find('.NetWeightMetric,.GrossWeightKg').val('0.000');
        $(e).parent().parent().find('.FreightPer,.InsurancePer,.CommissionPer,.DiscountPer,.OtherChargesPer').val('0.0000');
    }
}

//FUNCTION FOR NEW INVOICE NUMBER LIST IN ITEM DETAILS
function NewGenerateInvoiceNoList(Type, InvRowNo) {
    let InvAr = [];
    let InvHtml = '';
    $('#TblInvoiceDetails tbody tr').each(function (ind, ele) {
        if ($(this).find('.InvoiceNo').val().trim().length > 0)
            InvAr.push($(this).find('.InvoiceNo').val().trim());
    });

    for (i = 0; i < InvAr.length; i++) {
        if (InvHtml == '')
            InvHtml = '<option value="0">---Select---</option>';
        InvHtml += '<option value="' + (i + 1) + '">' + InvAr[i] + '</option>';
    }

    $('#NewItemInvoiceNo').html(InvHtml);
    $('#NewJobInvoice,#NewJobItem').html('<option value="0">---Select---</option>');

    if (InvHtml != '')
        $('#NewJobInvoice').html(InvHtml);

    let ItmInvAr = [];
    $('#TblItemDetails tbody tr').each(function () {
        ItmInvAr.push($(this).find('.TblItemInvoiceNo').val());
    });
    $('.TblItemInvoiceNo').html(InvHtml);

    if (Type == 'Delete') {

        $('#TblItemDetails tbody tr').each(function (ind, ele) {
            if (ItmInvAr[ind] == null)
                ItmInvAr[ind] = 0;
            else if (ItmInvAr[ind] >= InvRowNo)
                ItmInvAr[ind] = ItmInvAr[ind] - 1;
            $(ele).find('.TblItemInvoiceNo').val(ItmInvAr[ind]);
        });
    }
    else {
        $('#TblItemDetails tbody tr').each(function (ind, ele) {
            if (ItmInvAr[ind] == null || ItmInvAr[ind] > InvAr.length)
                ItmInvAr[ind] = 0;
            $(ele).find('.TblItemInvoiceNo').val(ItmInvAr[ind]);
        });
    }
}

//FUNCTION FOR CALCULATE NEW FREIGHT WITH FREIGHT PERCENTAGE
function NewFreightCalculate(fx) {
    let InvValue = 0, Excrate = 0, Tfreight = 0, Fper = 0, FrtErate = 0, ActFr = 0;

    InvValue = HandleNullNumericValue($('#NewInvoiceValue').val());
    Excrate = HandleNullNumericValue($('#NewInvoiceCurrencyExchangeRate').val());
    Fper = HandleNullNumericValue($('#NewFreightPerInvoice').val());

    if (Fper > 0 && InvValue > 0 && Excrate > 0) {
        Tfreight = (InvValue * Excrate * Fper) / 100;
        $('#NewFreightINRInvoice').val(Tfreight.toFixed(fx));
        $('#NewActualFreightInvoice,#NewFreightExchangeRateInvoice').val('0.00');
        $('#HiddenNewFreightCurrencyInvoice,#NewFreightCurrencyInvoice').val('');
    }
    else if (Fper == 0) {
        ActFr = HandleNullNumericValue($('#NewActualFreightInvoice').val());
        FrtErate = HandleNullNumericValue($('#NewFreightExchangeRateInvoice').val());
        if (ActFr > 0 && FrtErate > 0) {
            Tfreight = ActFr * FrtErate;
            $('#NewFreightINRInvoice').val(Tfreight.toFixed(fx));
        }
        else
            $('#NewFreightINRInvoice').val('0.00');
    }
    else
        $('#NewFreightINRInvoice').val('0.00');
}

//FUNCTION FOR CALCULATE NEW INSURANCE WITH INSURANCE PERCENTAGE
function NewInsuranceCalculate(fx) {
    let InvValue = 0, Excrate = 0, TInsurance = 0, Iper = 0, ActIn = 0, InsErate = 0;

    InvValue = HandleNullNumericValue($('#NewInvoiceValue').val());
    Excrate = HandleNullNumericValue($('#NewInvoiceCurrencyExchangeRate').val());
    Iper = HandleNullNumericValue($('#NewInsurancePerInvoice').val());

    if (InvValue > 0 && Excrate > 0 && Iper > 0) {
        TInsurance = (InvValue * Excrate * Iper) / 100;
        $('#NewInsuranceINRInvoice').val(TInsurance.toFixed(fx));
        $('#NewActualInsuranceInvoice,#NewInsuranceExchangeRateInvoice').val('0.00');
        $('#HiddenNewInsuranceCurrencyInvoice,#NewInsuranceCurrencyInvoice').val('');
    }
    else if (Iper == 0) {
        ActIn = HandleNullNumericValue($('#NewActualInsuranceInvoice').val());
        InsErate = HandleNullNumericValue($('#NewInsuranceExchangeRateInvoice').val());
        if (ActIn > 0 && InsErate > 0) {
            TInsurance = ActIn * InsErate;
            $('#NewInsuranceINRInvoice').val(TInsurance.toFixed(fx));
        }
        else
            $('#NewInsuranceINRInvoice').val('0.00');
    }
    else
        $('#NewInsuranceINRInvoice').val('0.00');
}

//FUNCTION FOR CALCULATE NEW COMMISSION WITH COMMISSION PERCENTAGE
function NewCommissionCalculate(fx) {
    let InvValue = 0, Excrate = 0, TCommission = 0, Commissionper = 0, ActCommission = 0, CommissionErate = 0, FOBValue = 0;

    let InvoiceValue = 0, TFreight = 0, TInsurance = 0, TOtherCharges = 0, TDiscount = 0, TMiscCharges = 0, TCharges = 0, AfterTchargesPerValue = 0, AfterCommissionMinusValue = 0, FinalFOB = 0;
    InvoiceValue = HandleNullNumericValue($('#NewInvoiceValue').val());
    Excrate = HandleNullNumericValue($('#NewInvoiceCurrencyExchangeRate').val());
    TFreight = HandleNullNumericValue($('#NewFreightINRInvoice').val());
    TInsurance = HandleNullNumericValue($('#NewInsuranceINRInvoice').val());
    TCommission = HandleNullNumericValue($('#NewCommissionINRInvoice').val());
    TDiscount = HandleNullNumericValue($('#NewDiscountINRInvoice').val());
    TMiscCharges = HandleNullNumericValue($('#NewMiscChargesINRInvoice').val());
    TOtherCharges = HandleNullNumericValue($('#NewOtherChargesINRInvoice').val());
    TCharges = ((InvoiceValue * Excrate) - TFreight - TInsurance - TOtherCharges + TMiscCharges - TDiscount);
    $('#NewFOBValue').val(TCharges.toFixed(fx));

    InvValue = HandleNullNumericValue($('#NewInvoiceValue').val());
    //  Excrate = HandleNullNumericValue($('#NewInvoiceCurrencyExchangeRate').val());
    Commissionper = HandleNullNumericValue($('#NewCommissionPerInvoice').val());
    FOBValue = HandleNullNumericValue($('#NewFOBValue').val());

    if (InvValue > 0 && Excrate > 0 && Commissionper > 0) {
        TCommission = (FOBValue * Commissionper) / 100;
        // TCommission = (InvValue * Excrate * Commissionper) / 100;
        $('#NewCommissionINRInvoice').val(TCommission.toFixed(fx));
        $('#NewActualCommissionInvoice,#NewCommissionExchangeRateInvoice').val('0.00');
        $('#HiddenNewCommissionCurrencyInvoice,#NewCommissionCurrencyInvoice').val('');
    }
    else if (Commissionper == 0) {
        ActCommission = HandleNullNumericValue($('#NewActualCommissionInvoice').val());
        CommissionErate = HandleNullNumericValue($('#NewCommissionExchangeRateInvoice').val());
        if (ActCommission > 0 && CommissionErate > 0) {
            TCommission = ActCommission * CommissionErate;
            $('#NewCommissionINRInvoice').val(TCommission.toFixed(fx));
        }
        else
            $('#NewCommissionINRInvoice').val('0.00');
    }
    else
        $('#NewCommissionINRInvoice').val('0.00');
}

//FUNCTION FOR CALCULATE NEW DISCOUNT WITH DISCOUNT PERCENTAGE
function NewDiscountCalculate(fx) {
    let InvValue = 0, Excrate = 0, TDiscount = 0, Iper = 0, ActIn = 0, InsErate = 0;

    InvValue = HandleNullNumericValue($('#NewInvoiceValue').val());
    Excrate = HandleNullNumericValue($('#NewInvoiceCurrencyExchangeRate').val());
    Iper = HandleNullNumericValue($('#NewDiscountPerInvoice').val());

    if (InvValue > 0 && Excrate > 0 && Iper > 0) {
        TDiscount = (InvValue * Excrate * Iper) / 100;
        $('#NewDiscountINRInvoice').val(TDiscount.toFixed(fx));
        $('#NewActualDiscountInvoice,#NewDiscountExchangeRateInvoice').val('0.00');
        $('#HiddenNewDiscountCurrencyInvoice,#NewDiscountCurrencyInvoice').val('');
    }
    else if (Iper == 0) {
        ActIn = HandleNullNumericValue($('#NewActualDiscountInvoice').val());
        InsErate = HandleNullNumericValue($('#NewDiscountExchangeRateInvoice').val());
        if (ActIn > 0 && InsErate > 0) {
            TDiscount = ActIn * InsErate;
            $('#NewDiscountINRInvoice').val(TDiscount.toFixed(fx));
        }
        else
            $('#NewDiscountINRInvoice').val('0.00');
    }
    else
        $('#NewDiscountINRInvoice').val('0.00');
}

//FUNCTION FOR CALCULATE NEW OTHERCHARGES WITH OTHERCHARGES PERCENTAGE
function NewOtherChargesCalculate(fx) {
    let InvValue = 0, Excrate = 0, TOtherCharges = 0, Iper = 0, ActIn = 0, InsErate = 0;

    InvValue = HandleNullNumericValue($('#NewInvoiceValue').val());
    Excrate = HandleNullNumericValue($('#NewInvoiceCurrencyExchangeRate').val());
    Iper = HandleNullNumericValue($('#NewOtherChargesPerInvoice').val());

    if (InvValue > 0 && Excrate > 0 && Iper > 0) {
        TOtherCharges = (InvValue * Excrate * Iper) / 100;
        $('#NewOtherChargesINRInvoice').val(TOtherCharges.toFixed(fx));
        $('#NewActualOtherChargesInvoice,#NewOtherChargesExchangeRateInvoice').val('0.00');
        $('#HiddenNewOtherChargesCurrencyInvoice,#NewOtherChargesCurrencyInvoice').val('');
    }
    else if (Iper == 0) {
        ActIn = HandleNullNumericValue($('#NewActualOtherChargesInvoice').val());
        InsErate = HandleNullNumericValue($('#NewOtherChargesExchangeRateInvoice').val());
        if (ActIn > 0 && InsErate > 0) {
            TOtherCharges = ActIn * InsErate;
            $('#NewOtherChargesINRInvoice').val(TOtherCharges.toFixed(fx));
        }
        else
            $('#NewOtherChargesINRInvoice').val('0.00');
    }
    else
        $('#NewOtherChargesINRInvoice').val('0.00');
}

//FUNCTION FOR CALCULATE NEW MISCELLANEOUS CHARGE
function NewMiscellaneousChargeCalculate(fx) {
    let InvValue = 0, Excrate = 0, MiscInr = 0, Misc = 0;

    InvValue = HandleNullNumericValue($('#NewInvoiceValue').val());
    Excrate = HandleNullNumericValue($('#NewInvoiceCurrencyExchangeRate').val());
    Misc = HandleNullNumericValue($('#NewMiscChargesInvoice').val());
    MiscInr = HandleNullNumericValue($('#NewMiscChargesINRInvoice').val());

    if (InvValue > 0 && Excrate > 0 && Misc > 0) {
        MiscInr = Misc * Excrate;
        if (MiscInr > 0)
            $('#NewMiscChargesINRInvoice').val(MiscInr.toFixed(fx));
        else
            $('#NewMiscChargesINRInvoice').val('0.00');
    }
}

//NEWINVOICETERMS SELECT CHANGE EVENT
$('#NewNatureOfContract').change(function () {
    let Vl = $('#NewNatureOfContract option:selected').text();
    if (Vl == 'FOB') {
        $('#NewFreightPerInvoice,#NewInsurancePerInvoice').val('0.0000').attr('disabled', 'disabled');
        $('#NewActualFreightInvoice,#NewFreightExchangeRateInvoice,#NewFreightINRInvoice,#NewActualInsuranceInvoice,#NewInsuranceExchangeRateInvoice,#NewInsuranceINRInvoice').val('0.00').attr('disabled', 'disabled');
        $('#HiddenNewFreightCurrencyInvoice,#NewFreightCurrencyInvoice,#HiddenNewInsuranceCurrencyInvoice,#NewInsuranceCurrencyInvoice').val('').attr('disabled', 'disabled');

    }
    else if (Vl == 'CF') {
        $('#NewInsurancePerInvoice').val('0.0000').attr('disabled', 'disabled');
        $('#NewActualInsuranceInvoice,#NewInsuranceExchangeRateInvoice,#NewInsuranceINRInvoice').val('0.00').attr('disabled', 'disabled');
        $('#HiddenNewInsuranceCurrencyInvoice,#NewInsuranceCurrencyInvoice').val('').attr('disabled', 'disabled');

        $('#NewFreightPerInvoice').val('0.0000').removeAttr('disabled');
        $('#NewActualFreightInvoice,#NewFreightExchangeRateInvoice,#NewFreightINRInvoice').val('0.00').removeAttr('disabled');
        $('#HiddenNewFreightCurrencyInvoice,#NewFreightCurrencyInvoice').val('').removeAttr('disabled');

    }
    else if (Vl == 'CI') {
        $('#NewFreightPerInvoice').val('0.0000').attr('disabled', 'disabled');
        $('#HiddenNewFreightCurrencyInvoice,#NewFreightCurrencyInvoice').val('').attr('disabled', 'disabled');
        $('#NewActualFreightInvoice,#NewFreightExchangeRateInvoice,#NewFreightINRInvoice').val('0.00').attr('disabled', 'disabled');

        $('#NewInsurancePerInvoice').val('0.0000').removeAttr('disabled');
        $('#NewActualInsuranceInvoice,#NewInsuranceExchangeRateInvoice,#NewInsuranceINRInvoice').val('0.00').removeAttr('disabled');
        $('#HiddenNewInsuranceCurrencyInvoice,#NewInsuranceCurrencyInvoice').val('').removeAttr('disabled', 'disabled');
    }
    else if (Vl == 'CIF') {
        $('#NewFreightPerInvoice,#NewActualFreightInvoice,#NewFreightExchangeRateInvoice,#NewFreightINRInvoice,#HiddenNewFreightCurrencyInvoice,#NewFreightCurrencyInvoice,#NewInsurancePerInvoice,#NewActualInsuranceInvoice,#HiddenNewInsuranceCurrencyInvoice,#NewInsuranceCurrencyInvoice,#NewInsuranceExchangeRateInvoice,#NewInsuranceINRInvoice').removeAttr('disabled');

    }
});

//FUNCTION FOR CALCULATE NEW FREE ON BOARD (FOB) VALUE
function NewFOBValueCalculate(fx) {
    let InvoiceValue = 0, Excrate = 0, TFreight = 0, TInsurance = 0, TOtherCharges = 0, TCommission = 0, TDiscount = 0, TMiscCharges = 0, TCharges = 0, AfterTchargesPerValue = 0, AfterCommissionMinusValue = 0, FinalFOB = 0;
    InvoiceValue = HandleNullNumericValue($('#NewInvoiceValue').val());
    Excrate = HandleNullNumericValue($('#NewInvoiceCurrencyExchangeRate').val());
    TFreight = HandleNullNumericValue($('#NewFreightINRInvoice').val());
    TInsurance = HandleNullNumericValue($('#NewInsuranceINRInvoice').val());
    TCommission = HandleNullNumericValue($('#NewCommissionINRInvoice').val());
    TDiscount = HandleNullNumericValue($('#NewDiscountINRInvoice').val());
    TMiscCharges = HandleNullNumericValue($('#NewMiscChargesINRInvoice').val());
    TOtherCharges = HandleNullNumericValue($('#NewOtherChargesINRInvoice').val());
    TCharges = ((InvoiceValue * Excrate) - TFreight - TInsurance - TOtherCharges + TMiscCharges - TDiscount);

    if (TCommission > 0) {
        AfterTchargesPerValue = TCharges * 12.5 / 100;
        FinalFOB = (TCommission - AfterTchargesPerValue) > 0 ? (TCommission - AfterTchargesPerValue) : 0;
        //FinalFOB = (TCommission - AfterTchargesPerValue);
        $('#NewFOBValue').val((TCharges - FinalFOB).toFixed(fx));
    }
    else {
        $('#NewFOBValue').val(TCharges.toFixed(fx));
    }
}

//FUNCTION FOR CALCULATE NEW PMV VALUE 
function NewPMVValueCalculate(fx) {
    let PMVRate = 0, PMVUnit = "", PMVQty = 0, FOBValue = 0, FinalPMVValue = 0, FinalPMVValueInPer = 0;
    $('#NewPMVQuantity').attr('disabled', 'disabled');
    PMVRate = HandleNullNumericValue($('#NewPMVRateInvoice').val());
    PMVUnit = $('#NewPMVUnit').val();
    PMVQty = HandleNullNumericValue($('#NewPMVQuantity').val());
    FOBValue = HandleNullNumericValue($('#NewFOBValue').val());
    if (PMVUnit == 'FOB') {
        FinalPMVValueInPer = FOBValue * PMVRate / 100;
        $('#NewPMVValue').val((FOBValue + FinalPMVValueInPer).toFixed(fx));
    }
    else if (PMVUnit == 'Amount') {
        FinalPMVValue = FOBValue + PMVRate;
        $('#NewPMVValue').val(FinalPMVValue.toFixed(fx));
    }
    else {
        $('#NewPMVQuantity').removeAttr('disabled');
        FinalPMVValue = PMVQty * PMVRate;
        $('#NewPMVValue').val(FinalPMVValue.toFixed(fx));
    }

}

//#endregion

//#region /****************************ITEM DETAILS TAB ALL FUNCTION START****************************/

//FUNCTION FOR FILL CURRENT ITEM DETAILS
function FillCurrentItemDetails() {
    let ItemDeText = '';
    if ($('#NewItemName').val().trim().length > 0) {
        ItemDeText += 'Item Name: ' + '<span>' + $('#NewItemName').val().trim() + '</span>';
        ItemDeText += '  | Amount: ' + '<span > ' + $('#NewItemAmount').val().trim() + '</span > ';
        ItemDeText += '  | Quantity: ' + '<span>' + $('#NewItemQuantity').val().trim() + '</span>';
        ItemDeText += '  | Unit Price: ' + '<span>' + $('#NewItemUnitPrice').val().trim() + '</span>';
        ItemDeText += '  | Unit : ' + '<span>' + $('#NewUnitQuantityCode').val().trim() + '</span>';
        //   ItemDeText += '  | CIF Value: ' + '<span>' + $('#NewItemCIFValue').val().trim() + '</span>';
    }
    $('.ItemDe').html(ItemDeText);
    $('.ItemDe').find('span').css('color', 'red');
}

//NEWITEMMASTERTARIFF DROPDOWN CHANGE EVENT
$('#NewItemMasterTariff').change(function () {
    if ($('#NewItemMasterTariff').val() == 'Master')
        $('#NewItemName').attr('onkeypress', "AutoCompleteAjax('NewItemName', '/Master/_Layout/GetItemNameAutoComplete', 'HiddenNewItemName')");
    else {
        if ($('#NewItemName').hasClass('ui-autocomplete-input'))
            $('#NewItemName').autocomplete('destroy');
        $('#NewItemName').removeAttr('onkeypress').removeClass('ui-autocomplete-input');
    }
});

//NEWITEMNAME BLUR EVENT
$('#NewItemName').blur(function () {
    if ($('#NewItemMasterTariff').val() == 'Master') {
        if ($('#HiddenNewItemName').val() != '')
            GetItemDescriptionForExport('HiddenNewItemName', 'NewItemDescription', 'NewItemGenericDescription', 'NewItemEndUse', 'NewItemEndUseDesc', 'NewRITCCode', 'NewItemCTH', 'NewItemCTEH');
    }
});

//FUNCTION FOR GET ITEM DESCRIPTION FROM MASTER
function GetItemDescriptionForExport(ItemUid, ItemDesc, GenDesc, EndUsItm, EndUsDesc, RITC, CTH, CETH) {
    try {
        const dataString = {};
        dataString.ItemUid = $('#' + ItemUid).val();
        if (ItemUid.length > 0) {
            AjaxSubmissionAutocomplete(JSON.stringify(dataString), '/Master/_Layout/GetItemDescription', $('input[name=__RequestVerificationToken]').val()).done(function (result) {
                let obj = result;
                if (obj.status == true) {
                    if (obj.responsecode == '100') {
                        $('#' + ItemDesc).val(obj.data.Table[0].ItemDesc);
                        $('#' + GenDesc).val(obj.data.Table[0].ItemDesc);
                        $('#' + EndUsItm).val(obj.data.Table[0].EndUseOfItem);
                        $('#' + EndUsDesc).val(obj.data.Table[0].EndUseDesc);
                        $('#Hidden' + RITC).val(obj.data.Table[0].ritc_code);
                        $('#' + RITC).val(obj.data.Table[0].ritc_code);
                        $('#Hidden' + CTH).val(obj.data.Table[0].cth);
                        $('#' + CTH).val(obj.data.Table[0].cth);
                        $('#Hidden' + CETH).val(obj.data.Table[0].ceth);
                        $('#' + CETH).val(obj.data.Table[0].ceth);
                    }
                }
                else
                    window.location.href = '/ClientLogin/ClientLogin';
            }).fail(function (result) {
                console.log(result.Message);
            });
        }
    }
    catch (e) {
        console.log(e.message);
    }
}

//FUNCTION FOR CHECK IGST PAYMENT STATUS
function CheckIGSTPaymentStatus() {
    if ($("#NewIGSTPaymentStatus").val() == 'P') {

        $('#NewItemTaxableValue').removeAttr('disabled');
        $('#NewItemIGSTAmount').removeAttr('disabled');
    }
    else {
        $("#NewItemTaxableValue").attr("disabled", "disabled");
        $("#NewItemIGSTAmount").attr("disabled", "disabled");
        $("#NewItemTaxableValue").val('0.00');
        $("#NewItemIGSTAmount").val('0.00');
    }
};

//FUNCTION FOR ITEM IGST VALUE
function IgstCalculate() {
    let taxValue = $('#NewItemTaxableValue').val().trim();
    let igstRate = $('#NewItemIGSTRate').val().trim();
    let igstAmount = 0;

    $('#NewItemIGSTAmount').val('0.00');
    if (taxValue != null && taxValue != undefined && taxValue > 0 && igstRate != null && igstRate != undefined && igstRate > 0) {
        igstAmount = (taxValue * igstRate) / 100;
        $('#NewItemIGSTAmount').val(igstAmount.toFixed(2));
    }
}

//FUNCTION FOR FILL AMOUNT IN ITEM DETAILS
function FillAmountInItemDetails(fx) {
    let TAmount = 0.00; ItemQuantity = 0.00; ItemUnitPrice = 0.00;
    if (($('#NewItemQuantity').val() != null || $('#NewItemQuantity').val() != '0.00') && ($('#NewItemUnitPrice').val() != null || $('#NewItemUnitPrice').val() != '0.00')) {
        ItemQuantity = $('#NewItemQuantity').val();
        ItemUnitPrice = $('#NewItemUnitPrice').val();
        TAmount = ItemQuantity * ItemUnitPrice;
        $('#NewItemAmount').val(TAmount.toFixed(2))
    }
    else {
        $('#NewItemAmount').val(0.00);
    }
};

//NEWADDITEM BUTTON CLICK EVENT
$('#NewAddItem').click(function () {
    if ($('#NewItemInvoiceNo').val() == null) {
        Toast('Please Add Invoice Details.', 'Message', 'error');
        ActiveInvoiceDetailsTab();
        $('#NewInvoiceNo').focus();
        return;
    }
    else if ($('#NewItemInvoiceNo').val() == '0') {
        Toast('Please Select Invoice Number', 'Message', 'error');
        $('#NewItemInvoiceNo').focus();
        return;
    }
    else if ($('#NewItemName').val().trim().length <= 0) {
        Toast('Please Add Item.', 'Message', 'error');
        $('#NewItemName').focus();
        return;
    }
    else if ($('#NewItemDescription').val().trim().length <= 0) {
        Toast('Please Add Item Descriptions.', 'Message', 'error');
        $('#NewItemDescription').focus();
        return;
    }
    else if ($('#NewItemEndUse').val().trim().length <= 0) {
        Toast('Please Add End Use.', 'Message', 'error');
        $('#NewItemEndUse').focus();
        return;
    }
    else if ($('#NewItemEndUseDesc').val().trim().length <= 0) {
        Toast('Please Add End Use Descriptions.', 'Message', 'error');
        $('#NewItemEndUseDesc').focus();
        return;
    }

    else if ($('#NewItemQuantity').val().trim() <= 0) {
        Toast('Please Add Item Quantity.', 'Message', 'error');
        $('#NewItemQuantity').focus();
        return;
    }

    else if ($('#NewUnitQuantityCode').val().trim().length <= 0) {
        Toast('Please Add Item Unit.', 'Message', 'error');
        $('#NewUnitQuantityCode').focus();
        return;
    }
    else if ($('#NewItemUnitPrice').val() <= 0) {
        $('#NewPMVUnitInvoice').focus();
        Toast('Please Add Unit Price', 'Message', 'error');
        return;
    }
    else if ($('#NewItemAmount').val().trim() <= 0) {
        Toast('Please Enter Item Amount.', 'Message', 'error');
        $('#NewItemAmount').focus();
        return;
    }
    else if ($('#NewIGSTPaymentStatus').val() == 'P') {
        if ($('#NewItemTaxableValue').val() == null || $('#NewItemTaxableValue').val() == '0.00') {
            $('#NewItemTaxableValue').removeAttr('disabled');
            $('#NewItemTaxableValue').focus();
            Toast('Please Add Taxable Value', 'Message', 'error');
            return;
        }
        else if ($('#NewItemIGSTAmount').val() == null || $('#NewItemIGSTAmount').val() == '0.00') {
            $('#NewItemIGSTAmount').removeAttr('disabled');
            $('#NewItemIGSTAmount').focus();
            Toast('Please Add IGST Amount', 'Message', 'error');
            return;
        }
        else
            NewAddItemRow();

    }
    else
        NewAddItemRow();
});

//FUNCTION FOR NEW ADD ITEM
function NewAddItemRow() {
    DutyCalculation();
    let flag = 0;
    let TblLen = $("#TblItemDetails tbody tr").length;
    let tbody = $("#TblItemDetails").find("tbody");
    let FirstTr = $(tbody).find("tr:first");
    let Itemt = '';

    if (TblLen == 1 && $('#TblItemDetails tbody tr').find('.TblItemName').val().trim().length == 0) {
        Itemt = FirstTr;
        AddItemData();
    }
    else {
        Itemt = $(FirstTr).clone();
        AddItemData();
        $("#TblItemDetails").append(Itemt);
    }
    GenerateSerialNumberTable('TblItemDetails', 'rn');
    ResetNewItem(true);
    NewGenerateItemNameList();
    Toast('Item Add Successfully.', 'Message', 'success');
    //  CalcAssCifDuty();

    function AddItemData() {

        //MAIN DETAILS

        Itemt.find('.TblItemInvoiceNo').val($('#NewItemInvoiceNo').val());
        Itemt.find('.TblReImport').val($('#NewReImport').val());
        Itemt.find('.HiddenTblItemName').val($('#HiddenNewItemName').val());
        Itemt.find('.TblItemName').val($('#NewItemName').val());
        Itemt.find('.TblItemDescription').val($('#NewItemDescription').val());
        Itemt.find('.TblItemGenericDescription').val($('#NewItemGenericDescription').val());
        Itemt.find('.HiddenTblItemEndUse').val($('#HiddenNewItemEndUse').val());
        Itemt.find('.TblItemEndUse').val($('#NewItemEndUse').val());
        Itemt.find('.TblItemEndUseDesc').val($('#NewItemEndUseDesc').val());
        Itemt.find('.TblItemQuantity').val($('#NewItemQuantity').val());
        Itemt.find('.TblItemUnitPrice').val($('#NewItemUnitPrice').val());
        Itemt.find('.HiddenTblUnitQuantityCode').val($('#HiddenNewUnitQuantityCode').val());
        Itemt.find('.TblUnitQuantityCode').val($('#NewUnitQuantityCode').val());
        Itemt.find('.TblItemAmount').val($('#NewItemAmount').val());

        Itemt.find('.TblItemFreight').val($('#NewItemFreight').val());
        Itemt.find('.TblItemInsurance').val($('#NewItemInsurance').val());
        Itemt.find('.TblItemCommission').val($('#NewItemCommission').val());
        Itemt.find('.TblItemDiscount').val($('#NewItemDiscount').val());
        Itemt.find('.TblItemMiscCharge').val($('#NewItemMiscCharge').val());
        Itemt.find('.TblItemOtherCharges').val($('#NewItemOtherCharges').val());
        Itemt.find('.TblFOBValue').val($('#NewItemFOBValue').val());

        Itemt.find('.TblPMVValue').val($('#NewItemPMVValue').val());
        Itemt.find('.TblRewardItem').val($('#NewRewardItem').val());
        Itemt.find('.TblJobWorkNotificationNo').val($('#NewItemJobWorkNotiNo').val());
        Itemt.find('.TblAccessStatus').val($('#NewAccessoryStatus').val());
        Itemt.find('.TblIGSTPaymentStatus').val($('#NewIGSTPaymentStatus').val());
        Itemt.find('.TblTaxableValue').val($('#NewItemTaxableValue').val());
        Itemt.find('.TblIGSTAmount').val($('#NewItemIGSTAmount').val());
        Itemt.find('.TblIGSTRate').val($('#NewItemIGSTRate').val());

        //MANUFACTURER/PRODUCER DETAILS

        Itemt.find('.HiddenTblItemManufacturerProducerGrowerName').val($('#HiddenNewItemManufacturerProducerGrowerName').val());
        Itemt.find('.TblItemManufacturerProducerGrowerName').val($('#NewItemManufacturerProducerGrowerName').val());
        Itemt.find('.TblItemManufacturerProducerCodeType').val($('#NewItemManufacturerProducerCodeType').val());
        Itemt.find('.TblItemManufacturerProducerGrowerCode').val($('#NewItemManufacturerProducerGrowerCode').val());
        Itemt.find('.TblItemManufacturerProducerGrowerAddress1').val($('#NewItemManufacturerProducerGrowerAddress1').val());
        Itemt.find('.TblItemManufacturerProducerGrowerAddress2').val($('#NewItemManufacturerProducerGrowerAddress2').val());
        Itemt.find('.TblItemManufacturerProducerGrowerCity').val($('#NewItemManufacturerProducerGrowerCity').val());
        Itemt.find('.TblItemManufacturerProducerGrowerCountrySubDivision').val($('#NewItemManufacturerProducerGrowerCountrySubDivision').val());
        Itemt.find('.TblItemManufacturerProducerGrowerPin').val($('#NewItemManufacturerProducerGrowerPin').val());
        Itemt.find('.HiddenTblItemManufacturerCountry').val($('#HiddenNewItemManufacturerCountry').val());
        Itemt.find('.TblItemManufacturerCountryName').val($('#NewItemManufacturerCountryName').val());
        Itemt.find('.HiddenTblSourceCountryName').val($('#HiddenNewSourceCountry').val());
        Itemt.find('.TblSourceCountryName').val($('#NewSourceCountryName').val());
        Itemt.find('.HiddenTblTransitCountry').val($('#HiddenNewTransitCountry').val());
        Itemt.find('.TblTransitCountryName').val($('#NewTransitCountryName').val());
    }
    ResetNewItem(true);
}

//FUNCTION FOR EDIT ITEM ROW ENTRY
function EditItemRowEntry(e) {
    let Rn = $(e).parent().parent().find('.rn').text().trim();
    let InvNo = $(e).parent().parent().find('.TblItemInvoiceNo').val();

    if (InvNo == null || InvNo == undefined || InvNo == '0' || InvNo.length == 0)
        Toast('Invalid Invoice Number.', 'Message', 'error');
    else {
        ResetNewItem();
        $('#NewAddItem').addClass('d-none');
        $('#NewUpdateItem').removeClass('d-none');
        //MAIN DETAILS
        $('#NewRowNumItem').val(Rn);
        $('#NewItemInvoiceNo').val($(e).parent().parent().find('.TblItemInvoiceNo').val());
        $('#HiddenNewItemName').val($(e).parent().parent().find('.HiddenTblItemName').val());
        $('#NewItemName').val($(e).parent().parent().find('.TblItemName').val());
        $('#NewItemDescription').val($(e).parent().parent().find('.TblItemDescription').val());
        $('#HiddenNewItemEndUse').val($(e).parent().parent().find('.HiddenTblItemEndUse').val());
        $('#NewItemEndUse').val($(e).parent().parent().find('.TblItemEndUse').val());
        $('#NewItemEndUseDesc').val($(e).parent().parent().find('.TblItemEndUseDesc').val());

        $('#NewItemQuantity').val($(e).parent().parent().find('.TblItemQuantity').val());
        $('#HiddenNewUnitQuantityCode').val($(e).parent().parent().find('.HiddenTblUnitQuantityCode').val());
        $('#NewUnitQuantityCode').val($(e).parent().parent().find('.TblUnitQuantityCode').val());
        $('#NewItemUnitPrice').val($(e).parent().parent().find('.TblItemUnitPrice').val());
        $('#NewItemAmount').val($(e).parent().parent().find('.TblItemAmount').val());


        $('#NewItemFreight').val($(e).parent().parent().find('.TblItemFreight').val());
        $('#NewItemInsurance').val($(e).parent().parent().find('.TblItemInsurance').val());
        $('#NewItemCommission').val($(e).parent().parent().find('.TblItemCommission').val());
        $('#NewItemDiscount').val($(e).parent().parent().find('.TblItemDiscount').val());
        $('#NewItemMiscCharge').val($(e).parent().parent().find('.TblItemMiscCharge').val());
        $('#NewItemOtherCharges').val($(e).parent().parent().find('.TblItemOtherCharges').val());
        $('#NewItemFOBValue').val($(e).parent().parent().find('.TblFOBValue').val());


        $('#NewItemPMVValue').val($(e).parent().parent().find('.TblPMVValue').val());
        $('#NewRewardItem').val($(e).parent().parent().find('.TblRewardItem').val());
        $('#NewItemJobWorkNotiNo').val($(e).parent().parent().find('.TblJobWorkNotificationNo').val());
        $('#NewAccessoryStatus').val($(e).parent().parent().find('.TblAccessStatus').val());
        $('#NewIGSTPaymentStatus').val($(e).parent().parent().find('.TblIGSTPaymentStatus').val());
        $('#NewItemTaxableValue').val($(e).parent().parent().find('.TblTaxableValue').val());
        $('#NewItemIGSTRate').val($(e).parent().parent().find('.TblIGSTRate').val());
        $('#NewItemIGSTAmount').val($(e).parent().parent().find('.TblIGSTAmount').val());


        //MANUFACTURER / PRODUCER DETAILS
        $('#HiddenNewItemManufacturerProducerGrowerName').val($(e).parent().parent().find('.HiddenTblItemManufacturerProducerGrowerName').val());
        $('#NewItemManufacturerProducerGrowerName').val($(e).parent().parent().find('.TblItemManufacturerProducerGrowerName').val()).trigger('blur');
        $('#NewItemManufacturerProducerCodeType').val($(e).parent().parent().find('.TblItemManufacturerProducerCodeType').val());
        $('#NewItemManufacturerProducerGrowerCode').val($(e).parent().parent().find('.TblItemManufacturerProducerGrowerCode').val());
        $('#NewItemManufacturerProducerGrowerAddress1').val($(e).parent().parent().find('.TblItemManufacturerProducerGrowerAddress1').val());
        $('#NewItemManufacturerProducerGrowerAddress2').val($(e).parent().parent().find('.TblItemManufacturerProducerGrowerAddress2').val());
        $('#NewItemManufacturerProducerGrowerCity').val($(e).parent().parent().find('.TblItemManufacturerProducerGrowerCity').val());
        $('#NewItemManufacturerProducerGrowerCountrySubDivision').val($(e).parent().parent().find('.TblItemManufacturerProducerGrowerCountrySubDivision').val());
        $('#NewItemManufacturerProducerGrowerPin').val($(e).parent().parent().find('.TblItemManufacturerProducerGrowerPin').val());
        $('#HiddenNewItemManufacturerCountry').val($(e).parent().parent().find('.HiddenTblItemManufacturerCountry').val());
        $('#NewItemManufacturerCountryName').val($(e).parent().parent().find('.TblItemManufacturerCountryName').val());
        $('#HiddenNewSourceCountry').val($(e).parent().parent().find('.HiddenTblSourceCountryName').val());
        $('#NewSourceCountryName').val($(e).parent().parent().find('.TblSourceCountryName').val());
        $('#HiddenNewTransitCountry').val($(e).parent().parent().find('.HiddenTblTransitCountry').val());
        $('#NewTransitCountryName').val($(e).parent().parent().find('.TblTransitCountryName').val());
    }
}

//NEWUPDATEITEM BUTTON CLICK EVENT
$('#NewUpdateItem').click(function () {
    if ($('#NewItemInvoiceNo').val() == null) {
        Toast('Please Add Invoice Details.', 'Message', 'error');
        ActiveInvoiceDetailsTab();
        $('#NewInvoiceNo').focus();
        return;
    }
    else if ($('#NewItemInvoiceNo').val() == '0') {
        Toast('Please Select Invoice Number', 'Message', 'error');
        $('#NewItemInvoiceNo').focus();
        return;
    }
    else if ($('#NewItemName').val().trim().length <= 0) {
        Toast('Please Add Item.', 'Message', 'error');
        $('#NewItemName').focus();
        return;
    }
    else if ($('#NewItemDescription').val().trim().length <= 0) {
        Toast('Please Add Item Descriptions.', 'Message', 'error');
        $('#NewItemDescription').focus();
        return;
    }
    else if ($('#NewItemEndUse').val().trim().length <= 0) {
        Toast('Please Add End Use.', 'Message', 'error');
        $('#NewItemEndUse').focus();
        return;
    }
    else if ($('#NewItemEndUseDesc').val().trim().length <= 0) {
        Toast('Please Add End Use Descriptions.', 'Message', 'error');
        $('#NewItemEndUseDesc').focus();
        return;
    }

    else if ($('#NewItemQuantity').val().trim() <= 0) {
        Toast('Please Add Item Quantity.', 'Message', 'error');
        $('#NewItemQuantity').focus();
        return;
    }

    else if ($('#NewUnitQuantityCode').val().trim().length <= 0) {
        Toast('Please Add Item Unit.', 'Message', 'error');
        $('#NewUnitQuantityCode').focus();
        return;
    }
    else if ($('#NewItemUnitPrice').val() <= 0) {
        $('#NewPMVUnitInvoice').focus();
        Toast('Please Add Unit Price', 'Message', 'error');
        return;
    }
    else if ($('#NewItemAmount').val().trim() <= 0) {
        Toast('Please Enter Item Amount.', 'Message', 'error');
        $('#NewItemAmount').focus();
        return;
    }
    else if ($('#NewIGSTPaymentStatus').val() == 'P') {
        if ($('#NewItemTaxableValue').val() == null || $('#NewItemTaxableValue').val() == '0.00') {
            $('#NewItemTaxableValue').removeAttr('disabled');
            $('#NewItemTaxableValue').focus();
            Toast('Please Add Taxable Value', 'Message', 'error');
            return;
        }
        else if ($('#NewItemIGSTAmount').val() == null || $('#NewItemIGSTAmount').val() == '0.00') {
            $('#NewItemIGSTAmount').removeAttr('disabled');
            $('#NewItemIGSTAmount').focus();
            Toast('Please Add IGST Amount', 'Message', 'error');
            return;
        }
        NewUpdateItemRow($('#NewRowNumItem').val());
    }
    else
        NewUpdateItemRow($('#NewRowNumItem').val());
});

//FUNCTION FOR UPDATE NEW ITEM ROW ENTRY
function NewUpdateItemRow(Rn) {
    //DutyCalculation();

    $('#TblItemDetails tbody tr').each(function (ind, ele) {
        if ($(ele).find('.rn').text().trim() == Rn) {

            $(ele).find('.TblItemInvoiceNo').val($('#NewItemInvoiceNo').val());
            $(ele).find('.TblReImport').val($('#NewReImport').val());
            $(ele).find('.HiddenTblItemName').val($('#HiddenNewItemName').val());
            $(ele).find('.TblItemName').val($('#NewItemName').val());
            $(ele).find('.TblItemDescription').val($('#NewItemDescription').val());
            $(ele).find('.TblItemGenericDescription').val($('#NewItemGenericDescription').val());
            $(ele).find('.HiddenTblItemEndUse').val($('#HiddenNewItemEndUse').val());
            $(ele).find('.TblItemEndUse').val($('#NewItemEndUse').val());
            $(ele).find('.TblItemEndUseDesc').val($('#NewItemEndUseDesc').val());
            $(ele).find('.TblItemQuantity').val($('#NewItemQuantity').val());
            $(ele).find('.TblItemUnitPrice').val($('#NewItemUnitPrice').val());
            $(ele).find('.HiddenTblUnitQuantityCode').val($('#HiddenNewUnitQuantityCode').val());
            $(ele).find('.TblUnitQuantityCode').val($('#NewUnitQuantityCode').val());
            $(ele).find('.TblItemAmount').val($('#NewItemAmount').val());


            $(ele).find('.TblItemFreight').val($('#NewItemFreight').val());
            $(ele).find('.TblItemInsurance').val($('#NewItemInsurance').val());
            $(ele).find('.TblItemCommission').val($('#NewItemCommission').val());
            $(ele).find('.TblItemDiscount').val($('#NewItemDiscount').val());
            $(ele).find('.TblItemMiscCharge').val($('#NewItemMiscCharge').val());
            $(ele).find('.TblItemOtherCharges').val($('#NewItemOtherCharges').val());
            $(ele).find('.TblFOBValue').val($('#NewItemFOBValue').val());

            $(ele).find('.TblPMVValue').val($('#NewItemPMVValue').val());
            $(ele).find('.TblRewardItem').val($('#NewRewardItem').val());
            $(ele).find('.TblJobWorkNotificationNo').val($('#NewItemJobWorkNotiNo').val());
            $(ele).find('.TblAccessStatus').val($('#NewAccessoryStatus').val());
            $(ele).find('.TblIGSTPaymentStatus').val($('#NewIGSTPaymentStatus').val());
            $(ele).find('.TblTaxableValue').val($('#NewItemTaxableValue').val());
            $(ele).find('.TblIGSTAmount').val($('#NewItemIGSTAmount').val());
            $(ele).find('.TblIGSTRate').val($('#NewItemIGSTRate').val());

            //MANUFACTURER/PRODUCER DETAILS

            $(ele).find('.HiddenTblItemManufacturerProducerGrowerName').val($('#HiddenNewItemManufacturerProducerGrowerName').val());
            $(ele).find('.TblItemManufacturerProducerGrowerName').val($('#NewItemManufacturerProducerGrowerName').val());
            $(ele).find('.TblItemManufacturerProducerCodeType').val($('#NewItemManufacturerProducerCodeType').val());
            $(ele).find('.TblItemManufacturerProducerGrowerCode').val($('#NewItemManufacturerProducerGrowerCode').val());
            $(ele).find('.TblItemManufacturerProducerGrowerAddress1').val($('#NewItemManufacturerProducerGrowerAddress1').val());
            $(ele).find('.TblItemManufacturerProducerGrowerAddress2').val($('#NewItemManufacturerProducerGrowerAddress2').val());
            $(ele).find('.TblItemManufacturerProducerGrowerCity').val($('#NewItemManufacturerProducerGrowerCity').val());
            $(ele).find('.TblItemManufacturerProducerGrowerCountrySubDivision').val($('#NewItemManufacturerProducerGrowerCountrySubDivision').val());
            $(ele).find('.TblItemManufacturerProducerGrowerPin').val($('#NewItemManufacturerProducerGrowerPin').val());
            $(ele).find('.HiddenTblItemManufacturerCountry').val($('#HiddenNewItemManufacturerCountry').val());
            $(ele).find('.TblItemManufacturerCountryName').val($('#NewItemManufacturerCountryName').val());
            $(ele).find('.HiddenTblSourceCountryName').val($('#HiddenNewSourceCountry').val());
            $(ele).find('.TblSourceCountryName').val($('#NewSourceCountryName').val());
            $(ele).find('.HiddenTblTransitCountry').val($('#HiddenNewTransitCountry').val());
            $(ele).find('.TblTransitCountryName').val($('#NewTransitCountryName').val());



            ResetNewItem();
            GenerateSerialNumberTable('TblItemDetails', 'rn');
            NewGenerateItemNameList();
            Toast('Update Item Successfully.', 'Message', 'success');
            // CalcAssCifDuty();
        }
    });
}
//FUNCTION FOR DELETE ITEM ROW ENTRY
function DeleteItemRowEntry(e) {
    let RowCount = $("#TblItemDetails tbody tr").length;
    let ItN = $(e).parent().parent().find('.TblItemName').val().trim();
    let ItRn = $(e).parent().parent().find('.rn').text();
    let ItLi = [];
    let ItDe = [];
    let ItEs = [];

    //$("#TblLicenceDetails tbody tr").each(function (ind, ele) {
    //    if ($(ele).find('.TblLicenseItemSr').val().trim().length > 0) {
    //        ItLi.push($(ele).find('.TblLicenseItemSr').val());
    //    }
    //});

    //$("#TblDestuffDetails tbody tr").each(function (ind, ele) {
    //    if ($(ele).find('.TblDestuffItemSr').val().trim().length > 0) {
    //        ItDe.push($(ele).find('.TblDestuffItemSr').val());
    //    }
    //});

    //$('#TblJobSupportDocs tbody tr').each(function (inde, ele) {
    //    if ($(ele).find('.TblItemSrNo').val() == ItRn)
    //        ItEs.push($(ele).find('.TblItemSrNo').val());
    //});

    if (ItN.length == 0)
        Toast('Item Name Blank.', 'Message', 'error');
    else {
        $.confirm({
            title: '',
            content: 'Are You Sure Want To Delete ?',
            type: 'red',
            boxWidth: '300px',
            useBootstrap: false,
            typeAnimated: true,
            columnClass: 'small',
            containerFluid: true,
            draggable: true,
            buttons: {
                tryAgain: {
                    text: 'Confirm',
                    btnClass: 'btn-red',
                    action: function () {
                        if (ItLi.includes(ItRn) == true || ItDe.includes(ItRn) == true || ItEs.includes(ItRn) == true) {
                            $.confirm({
                                title: '',
                                // content: 'This Item  Use In Destuff Details/License/ESanchit Details.Are You Sure Want To Delete ?',
                                content: 'Are You Sure Want To Delete ?',
                                type: 'red',
                                boxWidth: '300px',
                                useBootstrap: false,
                                typeAnimated: true,
                                columnClass: 'small',
                                containerFluid: true,
                                draggable: true,
                                buttons: {
                                    tryAgain: {
                                        text: 'Confirm',
                                        btnClass: 'btn-red',
                                        action: function () {
                                            let RowNumItem = [];
                                            RowNumItem.push(ItRn);
                                            DeleteESanchitRowItemWise(RowNumItem);  //DELETE ITEM FROM ESANCHIT
                                            // DeleteDestuffRowItemWise(RowNumItem); //DELETE ITEM FROM DESTUFF
                                            //  DeleteLicenseRowItemWise(RowNumItem);  //DELETE ITEM FROM LICENSE
                                            //  ResetDeleteItemRowEntry(e, RowCount);  // DELETE ITEM ROW ENTRY
                                            GenerateSerialNumberTable('TblItemDetails', 'rn');
                                            //  CalcAssCifDuty();
                                            NewGenerateItemNameList('Delete', ItRn); // GENERATE ITEM NAME LIST
                                        }
                                    },
                                    cancel: function () {
                                    }
                                }
                            });
                        }
                        else {
                            ResetDeleteItemRowEntry(e, RowCount);   // DELETE ITEM ROW ENTRY
                            GenerateSerialNumberTable('TblItemDetails', 'rn');
                            //  CalcAssCifDuty();
                            NewGenerateItemNameList();  // GENERATE ITEM NAME LIST
                        }
                    }
                },
                close: function () {
                }
            }
        });
    }
}

//FUNCTION FOR RESET OR DELETE IN ITEM ROW ENTRY
function ResetDeleteItemRowEntry(e, RowCount) {

    if (RowCount > 1)
        $(e).parent().parent().remove();
    else {
        $(e).parent().parent().find('.HiddenTblItemName,.TblItemName,.TblItemDescription,.HiddenTblItemEndUse,.TblItemEndUse,.TblItemEndUseDesc,.HiddenTblUnitQuantityCode,.TblUnitQuantityCode').val('');
        $(e).parent().parent().find('.TblItemAmount', '.TblPMVValue', '.TblTaxableValue', '.TblIGSTAmount', '.TblItemFreight', '.TblItemInsurance', '.TblItemCommission', '.TblItemDiscount', '.TblItemMiscCharge', '.TblItemOtherCharges', '.TblFOBValue').val('0.00');
        $(e).parent().parent().find('.TblItemQuantity,.TblItemUnitPrice').val('0.00');
        $('#TblRewardItem').val('N');
        $('#TblAccessStatus').val('0');
        $('#TblIGSTPaymentStatus').val('NA');
    }
}


//FUNCTION FOR VIEW ADD ESANCHIT ROW ENTRY
function ESanchitItemRowEntry(e) {

    let ItN = $(e).parent().parent().find('.TblItemName').val().trim();
    if (ItN.length == 0)
        Toast('Item Name Blank.', 'Message', 'error');
    else if ($('#NewAddItem').hasClass('d-none')) {
        Toast('Please Update Item.', 'Message', 'error');
    }
    else {

        $('#RowNumInvoice').val($(e).parent().parent().find('.TblItemInvoiceNo').val());
        $('#RownNumItem').val($(e).parent().parent().find('.rn').text());

        //$('#TblItemESanchit tbody tr').find('.TblNewItemPlaceOfIssue').val($('#CountryOrigin').val());

        //$('#TblItemESanchit tbody tr').find('.HiddenTblNewItemDocumentIssuingParty').val($('#HiddenShipper').val());
        //$('#TblItemESanchit tbody tr').find('.TblNewItemDocumentIssuingPartyName').val($('#Shipper').val());

        //$('#TblItemESanchit tbody tr').find('.HiddenTblNewItemDocumentBeneficiaryParty').val($('#HiddenImporterName').val());
        //$('#TblItemESanchit tbody tr').find('.TblNewItemDocumentBeneficiaryPartyName').val($('#ImporterName').val());
        ItemESanchitModal.style.display = 'block';
        GetAllDataFromESanchit($(e).parent().parent().find('.rn').text());
    }
}

//FUNCTION FOR FILL ESANCHIT DETAILS 
function FillESanchitDetails(e) {
    if ($(e).parent().parent().find('.TblNewItemFileNameType').val() == 'AUTO') {
        if ($(e).parent().parent().find('.HiddenTblNewItemFileName').val().trim().length > 0) {
            $(e).parent().parent().find('.TblNewItemIceGate').val(0);
            $(e).parent().parent().find('.TblItemNewImageReferenceNo,.HiddenTblNewItemDocumentTypeCode,.TblNewItemDocumentTypeCode,.TblNewItemUploadDateTime,.TblNewItemDocumentIssueDate,.TblNewItemDocumentExpiryDate,.TblNewItemDocumentIssuingPartyCode,.TblNewItemDocumentBeneficiaryPartyCode ').val('');

            try {
                const dataString = {};
                dataString.ESanchitDocumentUid = parseInt($(e).parent().parent().find('.HiddenTblNewItemFileName').val().trim());

                AjaxSubmission(JSON.stringify(dataString), '/Master/_Layout/GetESanchitDetails', $('input[name=__RequestVerificationToken]').val()).done(function (result) {
                    let obj = result.data.Table[0];
                    if (result.status == true) {
                        if (result.responsecode == '100') {
                            $(e).parent().parent().find('.TblNewItemIceGate').val(obj.ICEGATEUserId);
                            $(e).parent().parent().find('.TblItemNewImageReferenceNo').val(obj.ImageReferenceNo);
                            /* $(e).parent().parent().find('.TblItemNewDocumentReferenceNo').val(obj.DocumentReferenceNo);*/
                            $(e).parent().parent().find('.HiddenTblNewItemDocumentTypeCode').val(obj.DocumentTypeCode);
                            $(e).parent().parent().find('.TblNewItemDocumentTypeCode').val(obj.DocumentTypeCodeDescriptions);
                            $(e).parent().parent().find('.TblNewItemFileType').val(obj.FileType);
                            $(e).parent().parent().find('.TblNewItemUploadDateTime').val(obj.UploadDateTime);
                            /*$(e).parent().parent().find('.TblNewItemPlaceOfIssue').val(obj.PlaceOfIssue);*/
                            $(e).parent().parent().find('.TblNewItemDocumentIssueDate').val(obj.DocumentIssueDate);
                            $(e).parent().parent().find('.TblNewItemDocumentExpiryDate').val(obj.DocumentExpiryDate);
                            //$(e).parent().parent().find(".HiddenTblNewItemDocumentIssuingParty").val(obj.DocumentIssuingParty);
                            //$(e).parent().parent().find('.TblNewItemDocumentIssuingPartyName').val(obj.IName);
                            $(e).parent().parent().find('.TblNewItemDocumentIssuingPartyCode').val(obj.DocumentIssuingPartyCode);
                            //$(e).parent().parent().find('.HiddenTblNewItemDocumentBeneficiaryParty').val(obj.DocumentBeneficiaryParty);
                            //$(e).parent().parent().find('.TblNewItemDocumentBeneficiaryPartyName ').val(obj.BName);
                            $(e).parent().parent().find('.TblNewItemDocumentBeneficiaryPartyCode ').val(obj.DocumentBeneficiaryPartyCode);
                        }
                    } else
                        window.location.href = '/ClientLogin/ClientLogin';
                }).fail(function (result) {
                    console.log(result.Message);
                });

            }
            catch (e) {
                console.log(e.message);
            }

        }
    }
}

//ADDITEMESANCHITROW BUTTON CLICK EVENT
$('#AddItemESanchitRow').click(function () {
    let flag = 0;

    if (flag == 0) {
        let tbody = $('#TblItemESanchit').find('tbody');
        let firstTr = $(tbody).find('tr:first');

        firstTr.find('.TblNewItemUploadDateTime ').datetimepicker('destroy').removeAttr('id');
        firstTr.find('.TblNewItemDocumentIssueDate,.TblNewItemDocumentExpiryDate').datepicker('destroy').removeAttr('id');

        let newRow = $(firstTr).clone();
        /* newRow.find('.TblNewItemPlaceOfIssue,.HiddenTblNewItemDocumentIssuingParty,.TblNewItemDocumentIssuingPartyName,.HiddenTblNewItemDocumentBeneficiaryParty,.TblNewItemDocumentBeneficiaryPartyName').val('');*/
        newRow.find('.HiddenTblNewItemFileName,.TblNewItemFileName,.TblItemNewImageReferenceNo,.TblNewItemDocumentTypeCode,.TblNewItemUploadDateTime,.TblNewItemDocumentIssueDate,.TblNewItemDocumentExpiryDate,.TblNewItemDocumentIssuingPartyCode,.TblNewItemDocumentBeneficiaryPartyCode').val('');

        newRow.find('.TblNewItemESanchitLevel ').val('JOB');
        newRow.find('.TblNewItemIceGate').val(0);
        $('#TblItemESanchit').append(newRow);

        $(".dateTimepickerAll").datetimepicker({
            format: "d/m/Y H:i",
        });

        $(".datepickerAll").datepicker({
            toolbarPlacement: "bottom",
            showButtonPanel: true,
            changeMonth: true,
            changeYear: true,
            dateFormat: 'dd/mm/yy',
        });
    }
    else {
        Toast('Please Fill All Details.', 'Message', 'error');
    }

    GenerateSerialNumberTable('TblItemESanchit', 'rn')

});

// FUNCTION FOR DELETE ITEM ESANCHIT ROW 
function DeleteRemoveItemESanchitRowEntry(e) {

    let ImgRefNo = $(e).parent().parent().find('.TblItemNewImageReferenceNo ').val();
    if (ImgRefNo == null || ImgRefNo == undefined || ImgRefNo == '' || ImgRefNo.length == 0)
        Toast('Invalid Document.', 'Message', 'error');
    else {
        $.confirm({
            title: '',
            content: 'Are You Sure Want To Delete ?',
            type: 'red',
            boxWidth: '300px',
            useBootstrap: false,
            typeAnimated: true,
            columnClass: 'small',
            containerFluid: true,
            draggable: true,
            buttons: {
                tryAgain: {
                    text: 'Confirm',
                    btnClass: 'btn-red',
                    action: function () {
                        let uniqueItemSr = $('#RownNumItem').val() + ($(e).parent().parent().find('.rn').text().trim() - 1);

                        let rowCount = $('#TblItemESanchit tbody tr').length;

                        //DELETE FROM TABLE ITEM ESANCHIT
                        if (rowCount > 1)
                            $(e).parent().parent().remove();
                        else {
                            $(e).parent().parent().find('.HiddenTblNewItemFileName,.TblNewItemFileName,.TblItemNewImageReferenceNo,.TblNewItemDocumentTypeCode,.TblNewItemUploadDateTime,.TblNewItemPlaceOfIssue,.TblNewItemDocumentIssueDate,.TblNewItemDocumentExpiryDate,.HiddenTblNewItemDocumentIssuingParty,.TblNewItemDocumentIssuingPartyName,.TblNewItemDocumentIssuingPartyCode,.TblNewItemDocumentBeneficiaryPartyName,.TblNewItemDocumentBeneficiaryPartyCode').val('');
                            $(e).parent().parent().find('.TblNewItemESanchitLevel ').val('JOB');
                            $(e).parent().parent().find('.TblNewItemIceGate').val(0);

                        }

                        //DELETE FROM TABLE SUPPORT DOCS
                        $('#TblJobSupportDocs tbody tr').each(function () {

                            if ($(this).find('.TblUniqueItemSrNo').val()[0] == $('#RownNumItem').val()) {

                                if ($('#TblJobSupportDocs tbody tr').length > 1)
                                    $(this).remove();
                                else {
                                    $(this).find('.TblUniqueItemSrNo,.TblFileName,.TblInvoiceSrNo,.TblItemSrNo,.TblImgRefNo,.HiddenTblDocType,.TblDocType,.TblDocUploadDate,.TblPlaceOfIssue,.TblDocIssueDate,.TblDocExpiryDate,.HiddenTblDocIssueParty,.TblDocIssuingParty,.TblDocIssuingPartyCode,.HiddenTblDocBeneficiaryParty,.TblDocBeneficiaryParty,.TblDocBeneficiaryPartyCode').val('');
                                    $(this).find('.TblDocLevel').val('JOB');
                                    $(this).find('.TblIceGate').val(0);
                                }
                            }

                        });

                        GenerateSerialNumberTable('TblItemESanchit', 'rn');
                        GenerateSerialNumberTable('TblJobSupportDocs', 'rn');
                    }
                },
                close: function () {
                }
            }
        });
    }
}

//FUNCTION FOR DELETE ESANCHIT ROW ITEM WISE
function DeleteESanchitRowItemWise(SrNoAr) {
    SrNoAr.forEach(function (val) {
        $('#TblJobSupportDocs tbody tr').each(function (ind, ele) {
            let EsRowCount = $('#TblJobSupportDocs tbody tr').length;
            let EsItSr = $(ele).find('.TblItemSrNo').val();
            if (EsRowCount == 1) {
                if (EsItSr != null && EsItSr != undefined && EsItSr != 0 && EsItSr != '') {
                    if (EsItSr == val) {
                        $(ele).find('.TblFileName,.TblInvoiceSrNo,.TblItemSrNo,.TblImgRefNo,.HiddenTblDocType,.TblDocType,.TblDocUploadDate,.TblPlaceOfIssue,.TblDocIssueDate,.TblDocExpiryDate,.HiddenTblDocIssueParty,.TblDocIssuingParty,.TblDocIssuingPartyCode,.HiddenTblDocBeneficiaryParty,.TblDocBeneficiaryParty,.TblDocBeneficiaryPartyCode').val('');
                        $(ele).find('.TblDocLevel').val('JOB');
                        $(ele).find('.TblIceGate').val(0);
                    }
                }
            }
            else {
                if (EsItSr != null && EsItSr != undefined && EsItSr != 0 && EsItSr != '') {
                    if (EsItSr == val) {
                        $(ele).remove();
                    }
                }
            }
        });
    });
    GenerateSerialNumberTable('TblJobSupportDocs', 'rn')
}

//FUNCTION FOR CLOSE ITEM ESANCHIT MODAL
function CloseItemESanchitModal() {
    SaveIndividualItemESanchit($('#RowNumInvoice').val(), $('#RownNumItem').val());
    ItemESanchitModal.style.display = 'none';
}

//FUNCTION FOR SAVE INDIVIDUAL ITEM ESANCHIT IN TBLJOBSUPPORTDOCS
function SaveIndividualItemESanchit(invoiceSr, itemSr) {

    let uniqueItemSr = '';
    let TblLen = $("#TblJobSupportDocs tbody tr").length;
    let tbody = $("#TblJobSupportDocs").find("tbody");
    let firstTr = $(tbody).find("tr:first");
    let eSanchitt = '';
    let allRecord = new Array();

    $('#TblJobSupportDocs tbody tr').each(function () {
        allRecord.push($(this).find('.TblUniqueItemSrNo').val());
    });



    $('#TblItemESanchit tbody tr').each(function (indItem, eleItem) {
        if ($(eleItem).find('.TblNewItemFileName ').val().trim().length > 0 &&
            $(eleItem).find('.TblNewItemIceGate').val().length > 0 &&
            $(eleItem).find('.TblItemNewImageReferenceNo').val().trim().length > 0 &&
            $(eleItem).find('.HiddenTblNewItemDocumentTypeCode').val().trim().length > 0 &&
            $(eleItem).find('.TblNewItemDocumentTypeCode').val().trim().length > 0) {

            uniqueItemSr = itemSr + indItem;

            let invSr = $(eleItem).find('.TblNewItemESanchitLevel').val() == 'JOB' ? 0 : invoiceSr;
            let itSr = $(eleItem).find('.TblNewItemESanchitLevel').val() == 'JOB' || $(eleItem).find('.TblNewItemESanchitLevel').val() == 'INVOICE' ? 0 : itemSr;

            let flag = 0;
            allRecord.forEach(function (value, index) {
                if (value == uniqueItemSr) {
                    eSanchitt = $(`#TblJobSupportDocs tbody tr:eq(${index})`);
                    flag = 1;
                    return;
                }
            });

            if (flag == 1) {
                addESanchitData();
            } else {
                if (TblLen == 1 && $('#TblJobSupportDocs tbody tr').find('.TblImgRefNo').val().trim().length == 0) {
                    eSanchitt = $(`#TblJobSupportDocs tbody tr:eq(0)`);
                    addESanchitData();
                }
                else {
                    eSanchitt = $(firstTr).clone();
                    addESanchitData();
                    $("#TblJobSupportDocs").append(eSanchitt);
                }
            }
            function addESanchitData() {
                eSanchitt.find('.TblUniqueItemSrNo').val(uniqueItemSr);
                eSanchitt.find('.TblFileName').val($(eleItem).find('.TblNewItemFileName').val().trim());
                eSanchitt.find('.TblDocLevel').val($(eleItem).find('.TblNewItemESanchitLevel').val());
                eSanchitt.find('.TblInvoiceSrNo').val(invSr);
                eSanchitt.find('.TblItemSrNo').val(itSr);
                eSanchitt.find('.TblIceGate').val($(eleItem).find('.TblNewItemIceGate').val());
                eSanchitt.find('.TblImgRefNo').val($(eleItem).find('.TblItemNewImageReferenceNo').val());
                /* eSanchitt.find('.TblDocRefNo').val($(eleItem).find('.TblItemNewDocumentReferenceNo').val());*/
                eSanchitt.find('.HiddenTblDocType').val($(eleItem).find('.HiddenTblNewItemDocumentTypeCode').val());
                eSanchitt.find('.TblDocType').val($(eleItem).find('.TblNewItemDocumentTypeCode').val());
                eSanchitt.find('.TblFileType').val($(eleItem).find('.TblNewItemFileType').val());
                eSanchitt.find('.TblDocUploadDate').val($(eleItem).find('.TblNewItemUploadDateTime').val());
                eSanchitt.find('.TblPlaceOfIssue').val($(eleItem).find('.TblNewItemPlaceOfIssue').val());
                eSanchitt.find('.TblDocIssueDate').val($(eleItem).find('.TblNewItemDocumentIssueDate').val());
                eSanchitt.find('.TblDocExpiryDate').val($(eleItem).find('.TblNewItemDocumentExpiryDate').val());
                eSanchitt.find('.HiddenTblDocIssuingParty').val($(eleItem).find('.HiddenTblNewItemDocumentIssuingParty').val());
                eSanchitt.find('.TblDocIssuingParty').val($(eleItem).find('.TblNewItemDocumentIssuingPartyName').val());
                eSanchitt.find('.TblDocIssuingPartyCode').val($(eleItem).find('.TblNewItemDocumentIssuingPartyCode').val());
                eSanchitt.find('.HiddenTblDocBeneficiaryParty').val($(eleItem).find('.HiddenTblNewItemDocumentBeneficiaryParty').val());
                eSanchitt.find('.TblDocBeneficiaryParty').val($(eleItem).find('.TblNewItemDocumentBeneficiaryPartyName').val());
                eSanchitt.find('.TblDocBeneficiaryPartyCode').val($(eleItem).find('.TblNewItemDocumentBeneficiaryPartyCode').val());
            }
        }
    });

    $("#TblItemESanchit tbody").find("tr:gt(0)").remove();

    $('#TblItemESanchit tbody tr').find('.HiddenTblNewItemFileName,.TblNewItemFileName,.TblItemNewImageReferenceNo,.TblNewItemDocumentTypeCode,.TblNewItemUploadDateTime,.TblNewItemPlaceOfIssue,.TblNewItemDocumentIssueDate,.TblNewItemDocumentExpiryDate,.HiddenTblNewItemDocumentIssuingParty,.TblNewItemDocumentIssuingPartyName,.TblNewItemDocumentIssuingPartyCode,.TblNewItemDocumentBeneficiaryPartyName,.TblNewItemDocumentBeneficiaryPartyCode').val('');
    $('#TblItemESanchit tbody tr').find('.TblNewItemESanchitLevel ').val('JOB');
    $('#TblItemESanchit tbody tr').find('.TblNewItemIceGate').val(0);

    $('#RowNumInvoice,#RownNumItem').val('');

    GenerateSerialNumberTable('TblItemESanchit', 'rn');
    GenerateSerialNumberTable('TblJobSupportDocs', 'rn');
}

//FUNCTION FOR GET ALL DATA FROM ESANCHIT
function GetAllDataFromESanchit(rowVal) {
    let tbody = $("#TblItemESanchit").find("tbody");
    let firstTr = $(tbody).find("tr:first");
    let itemESanchit = '';

    $('#TblJobSupportDocs tbody tr').each(function (ind, ele) {

        if ($(this).find('.TblUniqueItemSrNo').val()[0] == rowVal) {
            if ($("#TblItemESanchit tbody tr").length == 1 && $('#TblItemESanchit tbody tr').find('.TblItemNewImageReferenceNo').val().trim().length == 0) {
                itemESanchit = firstTr;
                getData();

            } else {
                firstTr.find('.TblNewItemUploadDateTime ').datetimepicker('destroy').removeAttr('id');
                firstTr.find('.TblNewItemDocumentIssueDate,.TblNewItemDocumentExpiryDate').datepicker('destroy').removeAttr('id');

                itemESanchit = $(firstTr).clone();
                getData();
                $('#TblItemESanchit').append(itemESanchit);

                $(".dateTimepickerAll").datetimepicker({
                    format: "d/m/Y H:i",
                });

                $(".datepickerAll").datepicker({
                    toolbarPlacement: "bottom",
                    showButtonPanel: true,
                    changeMonth: true,
                    changeYear: true,
                    dateFormat: 'dd/mm/yy',
                });
            }
        }

        function getData() {
            itemESanchit.find('.TblNewItemFileName').val($(ele).find('.TblFileName').val().trim());
            itemESanchit.find('.TblNewItemESanchitLevel').val($(ele).find('.TblDocLevel').val());
            itemESanchit.find('.TblNewItemIceGate').val($(ele).find('.TblIceGate').val());
            itemESanchit.find('.TblItemNewImageReferenceNo').val($(ele).find('.TblImgRefNo').val());
            /*itemESanchit.find('.TblItemNewDocumentReferenceNo').val($(ele).find('.TblDocRefNo').val());*/
            itemESanchit.find('.HiddenTblNewItemDocumentTypeCode').val($(ele).find('.HiddenTblDocType').val());
            itemESanchit.find('.TblNewItemDocumentTypeCode').val($(ele).find('.TblDocType').val());
            itemESanchit.find('.TblNewItemFileType').val($(ele).find('.TblFileType').val());
            itemESanchit.find('.TblNewItemUploadDateTime').val($(ele).find('.TblDocUploadDate').val());
            itemESanchit.find('.TblNewItemPlaceOfIssue').val($(ele).find('.TblPlaceOfIssue').val());
            itemESanchit.find('.TblNewItemDocumentIssueDate').val($(ele).find('.TblDocIssueDate').val());
            itemESanchit.find('.TblNewItemDocumentExpiryDate').val($(ele).find('.TblDocExpiryDate').val());
            itemESanchit.find('.HiddenTblNewItemDocumentIssuingParty').val($(ele).find('.HiddenTblDocIssuingParty').val());
            itemESanchit.find('.TblNewItemDocumentIssuingPartyName').val($(ele).find('.TblDocIssuingParty').val());
            itemESanchit.find('.TblNewItemDocumentIssuingPartyCode').val($(ele).find('.TblDocIssuingPartyCode').val());
            itemESanchit.find('.HiddenTblNewItemDocumentBeneficiaryParty').val($(ele).find('.HiddenTblDocBeneficiaryParty').val());
            itemESanchit.find('.TblNewItemDocumentBeneficiaryPartyName').val($(ele).find('.TblDocBeneficiaryParty').val());
            itemESanchit.find('.TblNewItemDocumentBeneficiaryPartyCode').val($(ele).find('.TblDocBeneficiaryPartyCode').val());
        }

        GenerateSerialNumberTable('TblItemESanchit', 'rn');
    });
}

//FUNCTION FOR ADD AUTOCOMPLETE FUNCTION IN ITEM ESANCHIT
function AddFunction(e) {
    if ($(e).parent().parent().find('.TblNewItemFileNameType').val() == 'AUTO')
        $(e).parent().parent().find('.TblNewItemFileName').attr('onkeypress', AutoCompleteAjaxWithClass('TblNewItemFileName', '/Master/_Layout/GetFileNameAutoComplete', 'HiddenTblNewItemFileName'));
    else {
        if ($(e).parent().parent().find('.TblNewItemFileName').hasClass('ui-autocomplete-input'))
            $(e).parent().parent().find('.TblNewItemFileName').autocomplete('destroy');

        $(e).parent().parent().find('.TblNewItemFileName').removeAttr('onkeypress').removeClass('ui-autocomplete-input');

    }
}

//FUNCTION FOR GET DOCUMENT LEVEL
function GetDocumentLevel(e) {
    let DocumentCode = $(e).parent().parent().find('.HiddenTblNewItemDocumentTypeCode').val();

    if (DocumentCode.length > 0) {
        try {
            const dataString = {};
            dataString.DocumentCode = DocumentCode;
            AjaxSubmission(JSON.stringify(dataString), '/Master/_Layout/GetDocumentLevel', $('input[name=__RequestVerificationToken]').val()).done(function (result) {
                let obj = result;
                if (obj.status == true) {
                    if (obj.responsecode == '100')
                        $(e).parent().parent().find('.TblNewItemESanchitLevel').val(obj.data.Table[0].DocumentLevel);
                    else
                        $(e).parent().parent().find('.TblNewItemESanchitLevel').val('JOB');
                }
                else
                    window.location.href = '/ClientLogin/ClientLogin';
            }).fail(function (result) {
                console.log(result.message);
            });
        }
        catch (e) {
            console.log(e.message);
        }
    }
}

//NEW RESET ITEM BUTTON CLICK EVENT
$('#NewResetItem').click(function () {
    ResetNewItem(true);
});

//FUNCTION FOR GET END USE DESCRIPTION
function GetEndUseDescriptionForExport(EndUseCode, EndUseDesc) {
    try {
        const dataString = {};
        dataString.EndUseCode = $('#' + EndUseCode).val();
        if (EndUseCode.length > 0) {
            AjaxSubmissionAutocomplete(JSON.stringify(dataString), '/Master/_Layout/GetEndUseDescription', $('input[name=__RequestVerificationToken]').val()).done(function (result) {
                let obj = result;
                if (obj.status == true) {
                    if (obj.responsecode == '100') {
                        $('#' + EndUseDesc).val(obj.data.Table[0].EndUseDesc);
                    }
                }
                else
                    window.location.href = '/ClientLogin/ClientLogin';
            }).fail(function (result) {
                console.log(result.Message);
            });
        }
    }
    catch (e) {
        console.log(e.message);
    }
}

//NEWITEMMANUFACTURERPRODUCERGROWERNAME ON INPUT EVENT
$('#NewItemManufacturerProducerGrowerName').on('input', function () {
    $('#HiddenNewItemManufacturerProducerGrowerName').val('');
});

//NEWITEMMANUFACTURERPRODUCERGROWERNAME ON BLUR EVENT
$('#NewItemManufacturerProducerGrowerName').blur(function () {
    $('#NewItemManufacturerProducerGrowerAddress').html('');
    if ($('#HiddenNewItemManufacturerProducerGrowerName').val().trim().length > 0)
        FillManufacturerBranchAddress();
});

//FUNCTION FOR FILL MANUFACTURER BRANCH ADDRESS
function FillManufacturerBranchAddress() {
    try {
        const dataString = {};
        let LId = parseInt($("#HiddenNewItemManufacturerProducerGrowerName").val().trim());
        dataString.LedgerId = LId;
        AjaxSubmission(JSON.stringify(dataString), '/Master/_Layout/GetLedgerAddressWithBranch', $('input[name=__RequestVerificationToken]').val()).done(function (result) {
            let obj = result;
            if (obj.status == true) {
                if (obj.responsecode == '100')
                    BindDropdownNew(obj.data.Table, 'NewItemManufacturerProducerGrowerAddress', 'BranchUid', 'BranchAddress', '--Select--');
                else
                    BindDropdownNew(null, 'NewItemManufacturerProducerGrowerAddress', 'BranchUid', 'BranchAddress', '--Select--');

            } else
                window.location.href = '/ClientLogin/ClientLogin';
        }).fail(function (result) {
            console.log(result.Message);
        });
    }
    catch (e) {
        console.log(e.message);
    }
}

//NEW ITEM MANUFACTURER PRODUCER GROWER ADDRESS CHANGE EVENT
$('#NewItemManufacturerProducerGrowerAddress').change(function () {
    try {
        const dataString = {};
        let BranchUid = parseInt($("#NewItemManufacturerProducerGrowerAddress").val().trim());
        dataString.BranchUid = BranchUid;
        dataString.LedgerUid = $('#HiddenNewItemManufacturerProducerGrowerName').val();
        AjaxSubmission(JSON.stringify(dataString), '/Master/_Layout/GetLedgerFullBranchDetails', $('input[name=__RequestVerificationToken]').val()).done(function (result) {
            let obj = result;
            if (obj.status == true) {
                if (obj.responsecode == '100') {
                    $('#NewItemManufacturerProducerGrowerAddress1').val(obj.data.Table[0].Address1);
                    $('#NewItemManufacturerProducerGrowerAddress2').val(obj.data.Table[0].Address2);
                    $('#NewItemManufacturerProducerGrowerCity').val(obj.data.Table[0].BranchCity);
                    $('#NewItemManufacturerProducerGrowerPin').val(obj.data.Table[0].BranchPincode);
                    $('#HiddenNewItemManufacturerCountry').val(obj.data.Table[0].Country);
                    $('#NewItemManufacturerCountryName').val(obj.data.Table[0].CountryName);
                }
                else {
                    $('#NewItemManufacturerProducerGrowerAddress1,#NewItemManufacturerProducerGrowerAddress2,#NewItemManufacturerProducerGrowerCity').val('');
                    $('#NewItemManufacturerProducerGrowerPin,#HiddenNewItemManufacturerCountry,#NewItemManufacturerCountryName').val('');
                }


            } else
                window.location.href = '/ClientLogin/ClientLogin';
        }).fail(function (result) {
            console.log(result.Message);
        });
    }
    catch (e) {
        console.log(e.message);
    }
});

//NEW ITEM INVOICE NO DROPDOWN CHANGE EVENT
$('#NewItemInvoiceNo').change(function () {
    let InvText = '';
    if ($('#NewItemInvoiceNo').val() == "0") {
        $('#InvDe').text('');
    }
    else {
        $("#TblInvoiceDetails tbody tr").each(function (ind, ele) {
            if ($('#NewItemInvoiceNo option:selected').text() == $(this).find('.InvoiceNo').val().trim()) {
                InvText += 'Invoice: ' + '<span >' + $(this).find('.InvoiceNo').val() + '</span>';
                InvText += '  | InvoiceDate: ' + '<span >' + $(this).find('.InvoiceDate').val() + '</span>';
                InvText += '  | Currency: ' + '<span >' + $(this).find('.InvoiceCurrency').val() + '</span>';
                InvText += '  | Exchange Rate: ' + '<span >' + $(this).find('.InvoiceCurrencyExchangeRate').val() + '</span>';
                InvText += '  | Net Weight: ' + '<span >' + $(this).find('.NetWeightMetric').val() + ' MT</span>';
                InvText += '  | Gross Weight: ' + '<span >' + $(this).find('.GrossWeightKg').val() + ' KG</span>';
                InvText += '  | Invoice Value: ' + '<span >' + $(this).find('.InvoiceValue').val() + '</span>';
                InvText += '  | Freight: ' + '<span>' + $(this).find('.FreightINR').val() + '</span>';
                InvText += '  | Insurance: ' + '<span>' + $(this).find('.InsuranceINR').val() + '</span>';
                InvText += '  | Commission: ' + '<span>' + $(this).find('.CommissionINR').val() + '</span>';
                //   InvText += '  | Commission: ' + '<span>' + $(this).find('.CommissionINR').val() + '</span>';
                InvText += '  | Discount: ' + '<span>' + $(this).find('.DiscountINR').val() + '</span>';
                InvText += '  | MiscCharges: ' + '<span>' + $(this).find('.MiscChargesINR').val() + '</span>';
                InvText += '  | OtherCharges: ' + '<span>' + $(this).find('.OtherChargesINR').val() + '</span>';
                $('#InvDe').html(InvText);
                $('#InvDe').find('span').css('color', 'red');
                DutyCalculation();
            }
        });
    }
});


//FUNCTION FOR CALCULATE TOTAL INVOICE VALUE
function CalculateTotalInvoiceValue() {
    let TotalInvoiceValue = 0;
    $('#TotalInvoiceValue').val(parseInt(0).toFixed(2));
    $('#TblInvoiceDetails tbody tr').each(function () {
        TotalInvoiceValue += parseFloat($(this).find('.InvoiceValue').val().trim());
    });
    if (isNaN(TotalInvoiceValue))
        $('#TotalInvoiceValue').val('0.00');
    else
        $('#TotalInvoiceValue').val(TotalInvoiceValue.toFixed(2));
}

//FUNCTION FOR CALCULATE TOTAL NET WEIGHT
function CalculateTotalNetWeight() {
    let TotalNetWeight = 0;
    $("#TblInvoiceDetails tbody tr").each(function () {
        TotalNetWeight += parseFloat($(this).find('.NetWeightMetric').val().trim());
    });
    if (isNaN(TotalNetWeight))
        $("#TotalNetWeight").val("0.000");
    else
        $("#TotalNetWeight").val(TotalNetWeight.toFixed(3));
}

//FUNCTION FORM CALCULATE TOTAL GROSS WEIGHT
function CalculateTotalGrossWeight() {
    let TotalGrossWeight = 0;
    $("#TblInvoiceDetails tbody tr").each(function () {
        TotalGrossWeight += parseFloat($(this).find('.GrossWeightKg').val().trim());
    });
    if (isNaN(TotalGrossWeight))
        $("#TotalGrossWeight").val("0.000");
    else
        $("#TotalGrossWeight").val(TotalGrossWeight.toFixed(3));

}

//FUNCTION FOR NEW RESET ITEM
function ResetNewItem(flag) {
    const blankItemId = ['HiddenNewItemName', 'NewItemName', 'NewItemDescription', 'HiddenNewItemEndUse', 'NewItemEndUse', 'NewItemEndUseDesc', 'HiddenNewUnitQuantityCode', 'NewUnitQuantityCode', 'NewItemJobWorkNotiNo'];
    blankItemId.forEach((ele) => {
        $('#' + ele).val('');
    });
    const zeroItemId = ['NewItemAmount', 'NewItemPMVValue', 'NewItemTaxableValue', 'NewItemIGSTRate', 'NewItemIGSTAmount', 'TblItemFreight', 'TblItemInsurance', 'TblItemCommission', 'TblItemDiscount', 'TblItemMiscCharge', 'TblItemOtherCharges', 'TblFOBValue', 'NewItemFreight', 'NewItemInsurance', 'NewItemCommission', 'NewItemDiscount', 'NewItemOtherCharges', 'NewItemFOBValue', 'NewItemPMVValue', 'NewItemMiscCharge'];
    zeroItemId.forEach((ele) => {
        $('#' + ele).val('0.00');
    }); NewItemManufacturerProducerGrowerAddress
    $('.ItemDe').html('');
    $('#NewItemMasterTariff').val('TARIFF');
    $('#NewRewardItem').val('1');
    $('#NewAccessoryStatus').val('0');
    $('#NewIGSTPaymentStatus').val('NA');
    if ($('#NewItemName').hasClass('ui-autocomplete-input'))
        $('#NewItemName').autocomplete('destroy');
    $('#NewItemName').removeAttr('onkeypress').removeClass('ui-autocomplete-input');
    $('#NewItemQuantity,#NewItemUnitPrice').val('0.00');

    $('#NewAddItem').removeClass('d-none');
    $('#NewUpdateItem').addClass('d-none');
    $('#NewItemInvoiceNo').val(0);
    //    ActiveItemMainTab();
    ResetNewItemManufactureDetails();
    if (flag)
        $('#NewItemInvoiceNo').focus();
}

//FUNCTION FOR RESET ITEM MANUFACTURER DETAILS
function ResetNewItemManufactureDetails() {
    $('#HiddenNewItemManufacturerProducerGrowerName,#NewItemManufacturerProducerGrowerName,#NewItemManufacturerProducerCodeType').val('');
    $('#NewItemManufacturerProducerGrowerCode,#NewItemManufacturerProducerGrowerAddress1,#NewItemManufacturerProducerGrowerAddress2').val('');
    $('#NewItemManufacturerProducerGrowerCity,#NewItemManufacturerProducerGrowerCountrySubDivision,#NewItemManufacturerProducerGrowerPin').val('');
    $('#HiddenNewItemManufacturerCountry,#NewItemManufacturerCountryName,#HiddenNewSourceCountry,#NewSourceCountryName').val('');
    $('#HiddenNewTransitCountry,#NewTransitCountryName').val('');
    $('#NewItemManufacturerProducerGrowerAddress').html('');
}

//FUNCTION FOR FILL ITEM DETAILS IN LICENSE AND DESTUFF TAB
function NewGenerateItemNameList(Type, ItRn) {
    let ItemAr = [];
    let ItemHtml = '';
    $('#TblItemDetails tbody tr').each(function (ind, ele) {
        if ($(this).find('.TblItemName').val().trim().length > 0)
            ItemAr.push($(this).find('.TblItemName').val().trim());
    });

    for (i = 0; i < ItemAr.length; i++) {
        if (ItemHtml == '')
            ItemHtml = '<option value="0">---Select---</option>';
        ItemHtml += '<option value="' + (i + 1) + '">' + (i + 1) + '-' + ItemAr[i] + '</option>';
    }
    //  $('#NewItemLicense,#NewItemDestuff').html(ItemHtml);

    // let ItemLicenceAr = [];
    //  $('#TblLicenceDetails tbody tr').each(function () {
    //      ItemLicenceAr.push($(this).find('.TblLicenseItemSr').val());
    //  });

    //let ItemDestuffAr = [];
    // $('#TblDestuffDetails tbody tr').each(function () {
    //      ItemDestuffAr.push($(this).find('.TblDestuffItemSr').val());
    //  });

    //  $('#NewJobItem').html('<option value="0">---Select---</option>');

    //   $(".TblLicenseItemSr,.TblDestuffItemSr").html(ItemHtml);

    //if (Type == 'Delete') {
    //    $('#TblLicenceDetails tbody tr').each(function (ind, ele) {
    //        if (ItemLicenceAr[ind] == null)
    //            ItemLicenceAr[ind] = 0;
    //        else if (ItemLicenceAr[ind] > ItRn) {
    //            ItemLicenceAr[ind] = ItemLicenceAr[ind] - 1;
    //        }
    //        $(ele).find('.TblLicenseItemSr').val(ItemLicenceAr[ind]);
    //    });

    //    $('#TblDestuffDetails tbody tr').each(function (ind, ele) {
    //        if (ItemDestuffAr[ind] == null)
    //            ItemDestuffAr[ind] = 0;
    //        else if (ItemDestuffAr[ind] > ItRn) {
    //            ItemDestuffAr[ind] = ItemDestuffAr[ind] - 1;
    //        }
    //        $(ele).find('.TblDestuffItemSr').val(ItemDestuffAr[ind]);
    //    });


    //}
    //else {
    //    $('#TblLicenceDetails tbody tr').each(function (ind, ele) {
    //        if (ItemLicenceAr[ind] == null || ItemLicenceAr[ind] > ItemAr.length)
    //            ItemLicenceAr[ind] = 0;
    //        $(ele).find('.TblLicenseItemSr').val(ItemLicenceAr[ind]);
    //    });

    //    $('#TblDestuffDetails tbody tr').each(function (ind, ele) {
    //        if (ItemDestuffAr[ind] == null || ItemDestuffAr[ind] > ItemAr.length)
    //            ItemDestuffAr[ind] = 0;
    //        $(ele).find('.TblDestuffItemSr').val(ItemDestuffAr[ind]);
    //    });
    //}

    //FUNCTION FOR VALIDATE ITEM DETAILS DATA
    function ValidateItemDetailsData() {
        let Vflag = 0;
        $('#TblItemDetails tbody tr').each(function (ind, ele) {
            if ($('#TblItemDetails tbody tr').length == 1) {
                if ($(ele).find('.TblItemName').val().trim().length > 0) {
                    if (HandleNullNumericValue($(ele).find('.TblItemAmount').val()) <= 0) {
                        Toast('Please Enter Item Amount', 'Message', 'error');
                        Vflag = 1;
                        return;
                    }
                    if (HandleNullNumericValue($(ele).find('.TblItemQuantity').val()) <= 0) {
                        Toast('Please Enter Item Quantity', 'Message', 'error');
                        Vflag = 1;
                        return;
                    }
                }
            }
            else {
                if (HandleNullNumericValue($(ele).find('.TblItemAmount').val()) <= 0) {
                    Toast('Please Enter Item Amount', 'Message', 'error');
                    Vflag = 1;
                    return;
                }
                if (HandleNullNumericValue($(ele).find('.TblItemQuantity').val()) <= 0) {
                    Toast('Please Enter Item Quantity', 'Message', 'error');
                    Vflag = 1;
                    return;
                }
            }
        });
        return Vflag;
    }
}

//#endregion

//#region /****************************CONTAINER DETAILS TAB ALL FUNCTION START****************************/

//FUNCTION FOR CLONE CONTAINER ROW
function CloneContainerRow() {
    let contNo = $('#ContainerTypeNo').val().trim();
    let contType = $('#ContainerType').val().trim();
    let tblContLength = $('#TblContainerDetails tbody tr').length;
    let tbody = $('#TblContainerDetails').find('tbody');
    let firstTr = $(tbody).find('tr:first');

    if (contNo != null && contNo != undefined && contNo.length > 0 && contType != null && contType != undefined && contType.length > 0) {
        if (contNo > tblContLength) {
            let rowClone = contNo - tblContLength;
            for (let i = 0; i < rowClone; i++) {
                firstTr.find('.SealDate,.PickupDate,.StuffingDate,.PortGateInDate').datepicker('destroy').removeAttr('id').val('');
                let newRow = $(firstTr).clone();

                newRow.find('.ContainerNo,.HiddenContType,.ContType,.SealNo,.ExciseSealNumber,.SealDeviceId,.NoOfPackage,.HiddenPackageType,.PackageType,.HiddenTransporter,.Transporter,.TruckNo,.ContainerRemarks').val('');

                newRow.find('.SealType').val('BTSL');
                newRow.find('.NetWeightType').val('KGS');

                newRow.find('.NetWeight,.GrossWeight,.TareWeight,.VGMWeight').val('0.000');


                $('#TblContainerDetails').append(newRow);

                $('.datepickerAll').datepicker({
                    changeMonth: true,
                    changeYear: true,
                    dateFormat: 'dd/mm/yy'
                });


            }
        }
        else if (contNo < tblContLength)
            $('#TblContainerDetails tbody').find(`tr:gt(${contNo - 1})`).remove();
        $('#TblContainerDetails tbody tr').find('.ContType').val($('#ContainerType').val());
    }
    else {
        $('#TblContainerDetails tbody').find(`tr:gt(0)`).remove();

        $('#TblContainerDetails tbody').find('.SealDate,.PickupDate,.StuffingDate,.PortGateInDate,.ContainerNo,.HiddenContType,.ContType,.SealNo,.ExciseSealNumber,.SealDeviceId,.NoOfPackage,.HiddenPackageType,.PackageType,.HiddenTransporter,.Transporter,.TruckNo,.ContainerRemarks').val('');

        $('#TblContainerDetails tbody').find('.SealType').val('BTSL');
        $('#TblContainerDetails tbody').find('.NetWeightType').val('KGS');

        $('#TblContainerDetails tbody').find('.NetWeight,.GrossWeight,.TareWeight,.VGMWeight').val('0.000');
    }
    GenerateSerialNumberTable('TblContainerDetails', 'rn')
}

//FUNCTION FOR VALIDATE DUPLICATE CONATINER NUMBER
function ValidateDuplicateConatinerNumber() {
    let arr = [];
    let duplicates = [];

    $("#TblContainerDetails tbody tr").each(function () {
        arr.push($(this).find('.ContainerNo').val().trim());
    });

    arr.forEach(function (value, index, array) {
        if (array.indexOf(value, index + 1) !== -1 && duplicates.indexOf(value) === -1) {
            duplicates.push(value);
        }
    });

    if (duplicates.length > 0) {
        Toast('Duplicate Container Number.', 'Message', 'error');
    }
}


//FUNCTION FOR ADD MARKS NUMBER
function AddMarksNumber() {
    let MarksNo = "";
    $("#TblContainerDetails tbody tr").each(function () {
        if ($(this).find('.ContainerNo').val().trim().length > 0)
            MarksNo = MarksNo + $(this).find('.ContainerNo').val().trim() + ",";
    });
    $("#MarksNo").val(MarksNo.substring(0, MarksNo.length - 1));
}

//FUNCTION FOR VALIDATE CONTAINER DETAILS DATA
function ValidateContainerDetailsData() {
    let Vflag = 0;

    let contNo = $('#ContainerTypeNo').val().trim();
    let contType = $('#ContainerType').val().trim();

    if (contNo != null && contNo != undefined && contNo.length > 0 && contType != null && contType != undefined && contType.length > 0) {
        $('#TblContainerDetails tbody tr').each(function (ind, ele) {
            if ($(ele).find('.ContainerNo').val().trim().length <= 0) {
                Toast('Please Add Container Number in Row-' + (ind + 1) + '', 'Message', 'error');
                Vflag = 1;
                return false;
            }
        });
    }

    return Vflag;
}

//FUNCTION FOR CALCULATE VGM WEIGHT
function CalculateVGWeight(e) {
    let grossWeight = parseFloat($(e).parent().parent().find('.GrossWeight').val());
    let tareWeight = parseFloat($(e).parent().parent().find('.TareWeight').val());
    let vgmWeight = 0.00;

    if (tareWeight != null && tareWeight != undefined && grossWeight != null && grossWeight != undefined)
        vgmWeight = grossWeight + tareWeight;

    $(e).parent().parent().find('.VGMWeight').val(vgmWeight.toFixed(3));
}
//#endregion

//#region /****************************PACKING DETAILS TAB ALL FUNCTION START****************************/

// ADDPACKINGROW BUTTON CLICK EVENT
$('#AddPackingRow').click(function () {
    let pflag = 0;
    $(".common-remove-btn").removeAttr('disabled');

    $("#TblPackingDetails tbody tr").each(function (ind, ele) {

        if ($(ele).find('.PacketNoTo').val().trim().length <= 0 || $(ele).find('.PacketNoFrom').val().trim().length <= 0 || $(ele).find('.PacketType').val().trim().length <= 0) {
            pflag = 1;
            return
        }
    });

    if (pflag == 0) {

        let tbody = $("#TblPackingDetails").find("tbody");
        let FirstTr = $(tbody).find("tr:first");
        let NewRow = $(FirstTr).clone();

        NewRow.find('.PacketNoFrom').val('');
        NewRow.find('.PacketNoTo').val('');
        NewRow.find('.HiddenPacketType').val('');
        NewRow.find('.PacketType').val('');
        $("#TblPackingDetails").append(NewRow);
        GenerateSerialNumberTable('TblPackingDetails', 'rn');
    }
});

// FUNCTION FOR DELETE PACKING ROW ENTRY
function DeletePackingRowEntry(e) {
    var RowCount = $("#TblPackingDetails tbody tr").length;
    if (RowCount > 1)
        $(e).parent().parent().remove();
    else {
        $(e).parent().parent().find('.PacketNoFrom').val('');
        $(e).parent().parent().find('.PacketNoTo').val('');
        $(e).parent().parent().find('.HiddenPacketType').val('');
        $(e).parent().parent().find('.PacketType').val('');
    }
    GenerateSerialNumberTable('TblPackingDetails', 'rn');
}


//#endregion


//#region CODE FOR EPCG DETAILS 

// Initialize serial number
var EPCGserialNumber = $("#TblEPCGLicenceDetails tbody tr:last .rn").text() !== "" ? parseInt($("#TblEPCGLicenceDetails tbody tr:last .rn").text()) : 0;

$("#EPCGAddLicense").click(function () {
    var licenseNumber = $("#EPCGLicenseNumber").val();
    var licenseDate = $("#EPCGLicenseDate").val();
    var registerNumber = $("#EPCGRegisterNumber").val();
    var registerDate = $("#EPCGRegisterDate").val();
    var quantity = $("#EPCGQuantity").val();
    var unit = $("#EPCGQtyUnit").val();
    var Hiddenunit = $("#HiddenEPCGQtyUnit").val();
    var rowCount = $("#TblEPCGLicenceDetails tbody tr").length;

    if (licenseNumber == "" || licenseDate == "") {
        Toast('Licence No and Date are mandatory', 'Message', 'error');
        return;
    }

    // Check if the license number already exists
    var exists = false;
    $("#TblEPCGLicenceDetails tbody tr").each(function () {
        var existingLicenseNumber = $(this).find("input[name='TblEPCGLicenceNo']").val();
        if (existingLicenseNumber === licenseNumber) {
            exists = true;
            return false; // break the loop
        }
    });

    if (exists) {
        Toast('Licence No already exists', 'Message', 'error');
        return;
    }

    var firstRow = $("#TblEPCGLicenceDetails tbody tr:first");
    if (firstRow.find("input[name='TblEPCGLicenceNo']").val() === "") {
        firstRow.find("input[name='TblEPCGLicenceNo']").val(licenseNumber);
        firstRow.find("input[name='TblEPCGLicenceDate']").val(licenseDate);
        firstRow.find("input[name='TblEPCGRegisNumber']").val(registerNumber);
        firstRow.find("input[name='TblEPCGRegisDate']").val(registerDate);
        firstRow.find("input[name='TblEPCGQty']").val(quantity);
        firstRow.find("input[name='TblEPCGQtyUnit']").val(unit);
        firstRow.find("input[name='HiddenTblEPCGQtyUnit']").val(Hiddenunit);
        Toast('Record Add Successfully', 'Message', 'success');
    }
    else {
        var newRow = "<tr>" +
            "<td class=''>" +
            "<button name='EditEPCGRow' type='button' class='common-btn common-btn-sm' onclick='EditEPCGRowEntry(this);'><i class='fa-solid fa-pen-to-square'></i></button>" +
            "<button name='RemoveEPCGRow' type='button' class='common-btn common-btn-sm' onclick='DeleteEPCGRowEntry(this);'><i class='fa-regular fa-trash-can'></i></button>" +
            "</td>" +
            "<td class='text-center rn' style='padding-top:10px;'>" + (EPCGserialNumber + 1) + "</td>" +
            "<td><input type='text' name='TblEPCGLicenceNo' class='form-control input-md mybox textbox-height TblEPCGLicenceNo' maxlength='10' title='License Number' value='" + licenseNumber + "' /></td>" +
            "<td><input type='text' name='TblEPCGLicenceDate' class='form-control input-md mybox textbox-height TblEPCGLicenceDate' maxlength='10' title='EPCG Licence Date' value='" + licenseDate + "' /></td>" +
            "<td><input type='text' name='TblEPCGRegisNumber' class='form-control input-md mybox textbox-height TblEPCGRegisNumber' maxlength='10' title='License Regis Number' value='" + registerNumber + "' /></td>" +
            "<td><input type='text' name='TblEPCGRegisDate' class='datepickerAll form-control input-md mybox textbox-height TblEPCGRegisDate' placeholder='dd/mm/yyyy' maxlength='10' value='" + registerDate + "' disabled /></td>" +
            "<td><input type='text' name='TblEPCGQty' class='form-control form-control-md TblEPCGDebitQty' style='text-align:right' value='" + quantity + "' readonly /></td>" +
            "<td><input type='hidden' name='HiddenTblEPCGQtyUnit' class='form-control form-control-md HiddenTblEPCGQtyUnit' readonly value='" + Hiddenunit + "' /></td><input type='text' name='TblEPCGQtyUnit' class='form-control form-control-md TblEPCGQtyUnit' readonly value='" + unit + "' /></td>" +
            "</tr>";

        $("#TblEPCGLicenceDetails tbody").append(newRow);
        EPCGserialNumber++;
        Toast('Record Add Successfully', 'Message', 'success');
    }
    ResetEPCGDetails();
});

// Edit table row
EditEPCGRowEntry = function (btn) {
    $("#EPCGLicenseNumber").focus();
    var row = $(btn).closest("tr");
    var licenseNumber = row.find("input[name='TblEPCGLicenceNo']").val();
    var licenseDate = row.find("input[name='TblEPCGLicenceDate']").val();
    var registerNumber = row.find("input[name='TblEPCGRegisNumber']").val();
    var registerDate = row.find("input[name='TblEPCGRegisDate']").val();
    var quantity = row.find("input[name='TblEPCGQty']").val();
    var unit = row.find("input[name='TblEPCGQtyUnit']").val();
    var Hiddenunit = row.find("input[name='HiddenTblEPCGQtyUnit']").val();

    $("#EPCGLicenseNumber").val(licenseNumber);
    $("#EPCGLicenseDate").val(licenseDate);
    $("#EPCGRegisterNumber").val(registerNumber);
    $("#EPCGRegisterDate").val(registerDate);
    $("#EPCGQuantity").val(quantity);
    $("#EPCGQtyUnit").val(unit);
    $("#HiddenEPCGQtyUnit").val(Hiddenunit);

    // Hide save button and show update button
    $("#EPCGAddLicense").addClass("d-none");
    $("#EPCGUpdateLicense").removeClass("d-none");

    // Store the current row for updating
    $("#EPCGUpdateLicense").data("currentRow", row);
};

// Update table row
$("#EPCGUpdateLicense").click(function () {
    var licenseNumber = $("#EPCGLicenseNumber").val();
    var licenseDate = $("#EPCGLicenseDate").val();
    var registerNumber = $("#EPCGRegisterNumber").val();
    var registerDate = $("#EPCGRegisterDate").val();
    var quantity = $("#EPCGQuantity").val();
    var unit = $("#EPCGQtyUnit").val();
    var Hiddenunit = $("#HiddenEPCGQtyUnit").val();

    var row = $("#EPCGUpdateLicense").data("currentRow");
    row.find("input[name='TblEPCGLicenceNo']").val(licenseNumber);
    row.find("input[name='TblEPCGLicenceDate']").val(licenseDate);
    row.find("input[name='TblEPCGRegisNumber']").val(registerNumber);
    row.find("input[name='TblEPCGRegisDate']").val(registerDate);
    row.find("input[name='TblEPCGQty']").val(quantity);
    row.find("input[name='TblEPCGQtyUnit']").val(unit);
    row.find("input[name='HiddenTblEPCGQtyUnit']").val(Hiddenunit);

    ResetEPCGDetails();
    // Show save button and hide update button
    $("#EPCGAddLicense").removeClass("d-none");
    $("#EPCGUpdateLicense").addClass("d-none");
    Toast('Record Update Successfully', 'Message', 'success');
});

// Delete table row
DeleteEPCGRowEntry = function (btn) {
    if ($("#TblEPCGLicenceDetails tbody tr").length > 1) {
        $(btn).closest("tr").remove();
        // Update serial numbers
        updateSerialNumbers();
    }
    else {
        ResetEPCGTblDetails();
        // Update serial numbers
        updateSerialNumbers();
    }
    Toast('Record Deleted Successfully', 'Message', 'success');
};

// Update serial numbers
function updateSerialNumbers() {
    $("#TblEPCGLicenceDetails tbody tr").each(function (index) {
        $(this).find(".rn").text(index + 1);
        EPCGserialNumber = index + 1;
    });
}

function ResetEPCGDetails() {
    // Reset form fields
    $("#EPCGLicenseNumber").val("");
    $("#EPCGLicenseDate").val("");
    $("#EPCGRegisterNumber").val("");
    $("#EPCGRegisterDate").val("");
    $("#EPCGQuantity").val("0.00");
    $("#EPCGQtyUnit").val("");
    $("#HiddenEPCGQtyUnit").val("");
}
function ResetEPCGTblDetails() {
    // Reset the first row fields
    $("#TblEPCGLicenceDetails tbody tr:first input[name='TblEPCGLicenceNo']").val("");
    $("#TblEPCGLicenceDetails tbody tr:first input[name='TblEPCGLicenceDate']").val("");
    $("#TblEPCGLicenceDetails tbody tr:first input[name='TblEPCGRegisNumber']").val("");
    $("#TblEPCGLicenceDetails tbody tr:first input[name='TblEPCGRegisDate']").val("");
    $("#TblEPCGLicenceDetails tbody tr:first input[name='TblEPCGQty']").val("0.00");
    $("#TblEPCGLicenceDetails tbody tr:first input[name='TblEPCGQtyUnit']").val("");
    $("#TblEPCGLicenceDetails tbody tr:first input[name='HiddenTblEPCGQtyUnit']").val("");
}
//#endregion

//#region CODE FOR DEEC DETAILS 

// Initialize serial number
var DEECserialNumber = $("#TblDEECLicenceDetails tbody tr:last .rn").text() !== "" ? parseInt($("#TblDEECLicenceDetails tbody tr:last .rn").text()) : 0;

$("#DEECAddLicense").click(function () {
    var licenseNumber = $("#DEECLicenseNumber").val();
    var licenseDate = $("#DEECLicenseDate").val();
    var registerNumber = $("#DEECRegisterNumber").val();
    var registerDate = $("#DEECRegisterDate").val();
    var quantity = $("#DEECQuantity").val();
    var unit = $("#DEECQtyUnit").val();
    var Hiddenunit = $("#HiddenDEECQtyUnit").val();
    var rowCount = $("#TblDEECLicenceDetails tbody tr").length;

    if (licenseNumber === "" || licenseDate === "") {
        Toast('Licence No and Date are mandatory', 'Message', 'error');
        return;
    }

    // Check if the license number already exists
    var exists = false;
    $("#TblDEECLicenceDetails tbody tr").each(function () {
        var existingLicenseNumber = $(this).find("input[name='TblDEECLicenceNo']").val();
        if (existingLicenseNumber === licenseNumber) {
            exists = true;
            return false; // break the loop
        }
    });

    if (exists) {
        Toast('Licence No already exists', 'Message', 'error');
        return;
    }

    var firstRow = $("#TblDEECLicenceDetails tbody tr:first");
    if (firstRow.find("input[name='TblDEECLicenceNo']").val() === "") {
        firstRow.find("input[name='TblDEECLicenceNo']").val(licenseNumber);
        firstRow.find("input[name='TblDEECLicenceDate']").val(licenseDate);
        firstRow.find("input[name='TblDEECRegisNumber']").val(registerNumber);
        firstRow.find("input[name='TblDEECRegisDate']").val(registerDate);
        firstRow.find("input[name='TblDEECQty']").val(quantity);
        firstRow.find("input[name='TblDEECQtyUnit']").val(unit);
        firstRow.find("input[name='HiddenTblDEECQtyUnit']").val(Hiddenunit);
        Toast('Record Add Successfully', 'Message', 'success');
    }
    else {
        var newRow = "<tr>" +
            "<td class=''>" +
            "<button name='EditDEECRow' type='button' class='common-btn common-btn-sm' onclick='EditDEECRowEntry(this);'><i class='fa-solid fa-pen-to-square'></i></button>" +
            "<button name='RemoveDEECRow' type='button' class='common-btn common-btn-sm' onclick='DeleteDEECRowEntry(this);'><i class='fa-regular fa-trash-can'></i></button>" +
            "</td>" +
            "<td class='text-center rn' style='padding-top:10px;'>" + (DEECserialNumber + 1) + "</td>" +
            "<td><input type='text' name='TblDEECLicenceNo' class='form-control input-md mybox textbox-height TblDEECLicenceNo' maxlength='10' title='License Number' value='" + licenseNumber + "' /></td>" +
            "<td><input type='text' name='TblDEECLicenceDate' class='form-control input-md mybox textbox-height TblDEECLicenceDate' maxlength='10' title='DEEC Licence Date' value='" + licenseDate + "' /></td>" +
            "<td><input type='text' name='TblDEECRegisNumber' class='form-control input-md mybox textbox-height TblDEECRegisNumber' maxlength='10' title='License Regis Number' value='" + registerNumber + "' /></td>" +
            "<td><input type='text' name='TblDEECRegisDate' class='datepickerAll form-control input-md mybox textbox-height TblDEECRegisDate' placeholder='dd/mm/yyyy' maxlength='10' value='" + registerDate + "' disabled /></td>" +
            "<td><input type='text' name='TblDEECQty' class='form-control form-control-md TblDEECDebitQty' style='text-align:right' value='" + quantity + "' readonly /></td>" +
            "<td><input type='hidden' name='HiddenTblDEECQtyUnit' class='form-control form-control-md HiddenTblDEECQtyUnit' readonly value='" + Hiddenunit + "' /></td><input type='text' name='TblDEECQtyUnit' class='form-control form-control-md TblDEECQtyUnit' readonly value='" + unit + "' /></td>" +
            "</tr>";

        $("#TblDEECLicenceDetails tbody").append(newRow);

        DEECserialNumber++;
        Toast('Record Add Successfully', 'Message', 'success');
    }
    ResetDEECDetails();
});


// Edit table row
EditDEECRowEntry = function (btn) {
    $("#DEECLicenseNumber").focus();
    var row = $(btn).closest("tr");
    var licenseNumber = row.find("input[name='TblDEECLicenceNo']").val();
    var licenseDate = row.find("input[name='TblDEECLicenceDate']").val();
    var registerNumber = row.find("input[name='TblDEECRegisNumber']").val();
    var registerDate = row.find("input[name='TblDEECRegisDate']").val();
    var quantity = row.find("input[name='TblDEECQty']").val();
    var unit = row.find("input[name='TblDEECQtyUnit']").val();
    var Hiddenunit = row.find("input[name='HiddenTblDEECQtyUnit']").val();

    $("#DEECLicenseNumber").val(licenseNumber);
    $("#DEECLicenseDate").val(licenseDate);
    $("#DEECRegisterNumber").val(registerNumber);
    $("#DEECRegisterDate").val(registerDate);
    $("#DEECQuantity").val(quantity);
    $("#DEECQtyUnit").val(unit);
    $("#HiddenDEECQtyUnit").val(Hiddenunit);

    // Hide save button and show update button
    $("#DEECAddLicense").addClass("d-none");
    $("#DEECUpdateLicense").removeClass("d-none");

    // Store the current row for updating
    $("#DEECUpdateLicense").data("currentRow", row);
};

// Update table row
$("#DEECUpdateLicense").click(function () {
    var licenseNumber = $("#DEECLicenseNumber").val();
    var licenseDate = $("#DEECLicenseDate").val();
    var registerNumber = $("#DEECRegisterNumber").val();
    var registerDate = $("#DEECRegisterDate").val();
    var quantity = $("#DEECQuantity").val();
    var unit = $("#DEECQtyUnit").val();
    var Hiddenunit = $("#HiddenDEECQtyUnit").val();

    var row = $("#DEECUpdateLicense").data("currentRow");
    row.find("input[name='TblDEECLicenceNo']").val(licenseNumber);
    row.find("input[name='TblDEECLicenceDate']").val(licenseDate);
    row.find("input[name='TblDEECRegisNumber']").val(registerNumber);
    row.find("input[name='TblDEECRegisDate']").val(registerDate);
    row.find("input[name='TblDEECQty']").val(quantity);
    row.find("input[name='TblDEECQtyUnit']").val(unit);
    row.find("input[name='HiddenTblDEECQtyUnit']").val(Hiddenunit);

    ResetDEECDetails();
    // Show save button and hide update button
    $("#DEECAddLicense").removeClass("d-none");
    $("#DEECUpdateLicense").addClass("d-none");
    Toast('Record Update Successfully', 'Message', 'success');
});

// Delete table row
DeleteDEECRowEntry = function (btn) {
    if ($("#TblDEECLicenceDetails tbody tr").length > 1) {
        $(btn).closest("tr").remove();
        // Update serial numbers
        updateSerialNumbers();
    }
    else {
        ResetTblDEECLicenceDetails();
        // Update serial numbers
        updateSerialNumbers();
    }

    Toast('Record Deleted Successfully', 'Message', 'success');
};

// Update serial numbers
function updateSerialNumbers() {
    $("#TblDEECLicenceDetails tbody tr").each(function (index) {
        $(this).find(".rn").text(index + 1);
        DEECserialNumber = index + 1;
    });
}

function ResetDEECDetails() {
    // Reset form fields
    $("#DEECLicenseNumber").val("");
    $("#DEECLicenseDate").val("");
    $("#DEECRegisterNumber").val("");
    $("#DEECRegisterDate").val("");
    $("#DEECQuantity").val("0.00");
    $("#DEECQtyUnit").val("");
    $("#HiddenDEECQtyUnit").val("");
}
function ResetTblDEECLicenceDetails() {
    // Reset the first row fields
    $("#TblDEECLicenceDetails tbody tr:first input[name='TblDEECLicenceNo']").val("");
    $("#TblDEECLicenceDetails tbody tr:first input[name='TblDEECLicenceDate']").val("");
    $("#TblDEECLicenceDetails tbody tr:first input[name='TblDEECRegisNumber']").val("");
    $("#TblDEECLicenceDetails tbody tr:first input[name='TblDEECRegisDate']").val("");
    $("#TblDEECLicenceDetails tbody tr:first input[name='TblDEECQty']").val("0.00");
    $("#TblDEECLicenceDetails tbody tr:first input[name='TblDEECQtyUnit']").val("");
    $("#TblDEECLicenceDetails tbody tr:first input[name='HiddenTblDEECQtyUnit']").val("");
}


//#endregion

//#region CODE FOR DFIA DETAILS 

// Initialize serial number
var DFIAserialNumber = $("#TblDFIALicenceDetails tbody tr:last .rn").text() !== "" ? parseInt($("#TblDFIALicenceDetails tbody tr:last .rn").text()) : 0;

$("#DFIAAddLicense").click(function () {
    var licenseNumber = $("#DFIALicenseNumber").val();
    var licenseDate = $("#DFIALicenseDate").val();
    var registerNumber = $("#DFIARegisterNumber").val();
    var registerDate = $("#DFIARegisterDate").val();
    var quantity = $("#DFIAQuantity").val();
    var unit = $("#DFIAQtyUnit").val();
    var Hiddenunit = $("#HiddenDFIAQtyUnit").val();
    var rowCount = $("#TblDFIALicenceDetails tbody tr").length;

    if (licenseNumber === "" || licenseDate === "") {
        Toast('Licence No and Date are mandatory', 'Message', 'error');
        return;
    }

    // Check if the license number already exists
    var exists = false;
    $("#TblDFIALicenceDetails tbody tr").each(function () {
        var existingLicenseNumber = $(this).find("input[name='TblDFIALicenceNo']").val();
        if (existingLicenseNumber === licenseNumber) {
            exists = true;
            return false; // break the loop
        }
    });

    if (exists) {
        Toast('Licence No already exists', 'Message', 'error');
        return;
    }

    var firstRow = $("#TblDFIALicenceDetails tbody tr:first");
    if (firstRow.find("input[name='TblDFIALicenceNo']").val() === "") {
        firstRow.find("input[name='TblDFIALicenceNo']").val(licenseNumber);
        firstRow.find("input[name='TblDFIALicenceDate']").val(licenseDate);
        firstRow.find("input[name='TblDFIARegisNumber']").val(registerNumber);
        firstRow.find("input[name='TblDFIARegisDate']").val(registerDate);
        firstRow.find("input[name='TblDFIAQty']").val(quantity);
        firstRow.find("input[name='TblDFIAQtyUnit']").val(unit);
        firstRow.find("input[name='HiddenTblDFIAQtyUnit']").val(Hiddenunit);
        Toast('Record Add Successfully', 'Message', 'success');
    }
    else {
        var newRow = "<tr>" +
            "<td class=''>" +
            "<button name='EditDFIARow' type='button' class='common-btn common-btn-sm' onclick='EditDFIARowEntry(this);'><i class='fa-solid fa-pen-to-square'></i></button>" +
            "<button name='RemoveDFIARow' type='button' class='common-btn common-btn-sm' onclick='DeleteDFIARowEntry(this);'><i class='fa-regular fa-trash-can'></i></button>" +
            "</td>" +
            "<td class='text-center rn' style='padding-top:10px;'>" + (DFIAserialNumber + 1) + "</td>" +
            "<td><input type='text' name='TblDFIALicenceNo' class='form-control input-md mybox textbox-height TblDFIALicenceNo' maxlength='10' title='License Number' value='" + licenseNumber + "' /></td>" +
            "<td><input type='text' name='TblDFIALicenceDate' class='form-control input-md mybox textbox-height TblDFIALicenceDate' maxlength='10' title='DFIA Licence Date' value='" + licenseDate + "' /></td>" +
            "<td><input type='text' name='TblDFIARegisNumber' class='form-control input-md mybox textbox-height TblDFIARegisNumber' maxlength='10' title='License Regis Number' value='" + registerNumber + "' /></td>" +
            "<td><input type='text' name='TblDFIARegisDate' class='datepickerAll form-control input-md mybox textbox-height TblDFIARegisDate' placeholder='dd/mm/yyyy' maxlength='10' value='" + registerDate + "' disabled /></td>" +
            "<td><input type='text' name='TblDFIAQty' class='form-control form-control-md TblDFIADebitQty' style='text-align:right' value='" + quantity + "' readonly /></td>" +
            "<td><input type='Hidden' name='HiddenTblDFIAQtyUnit' class='form-control form-control-md HiddenTblDFIAQtyUnit' readonly value='" + Hiddenunit + "' /></td><input type='text' name='TblDFIAQtyUnit' class='form-control form-control-md TblDFIAQtyUnit' readonly value='" + unit + "' /></td>" +
            "</tr>";

        $("#TblDFIALicenceDetails tbody").append(newRow);

        DFIAserialNumber++;
        Toast('Record Add Successfully', 'Message', 'success');
    }

    ResetDFIADetails();
});


// Edit table row
EditDFIARowEntry = function (btn) {
    $("#DFIALicenseNumber").focus();
    var row = $(btn).closest("tr");
    var licenseNumber = row.find("input[name='TblDFIALicenceNo']").val();
    var licenseDate = row.find("input[name='TblDFIALicenceDate']").val();
    var registerNumber = row.find("input[name='TblDFIARegisNumber']").val();
    var registerDate = row.find("input[name='TblDFIARegisDate']").val();
    var quantity = row.find("input[name='TblDFIAQty']").val();
    var unit = row.find("input[name='TblDFIAQtyUnit']").val();
    var Hiddenunit = row.find("input[name='HiddenTblDFIAQtyUnit']").val();

    $("#DFIALicenseNumber").val(licenseNumber);
    $("#DFIALicenseDate").val(licenseDate);
    $("#DFIARegisterNumber").val(registerNumber);
    $("#DFIARegisterDate").val(registerDate);
    $("#DFIAQuantity").val(quantity);
    $("#DFIAQtyUnit").val(unit);
    $("#HiddenDFIAQtyUnit").val(Hiddenunit);

    // Hide save button and show update button
    $("#DFIAAddLicense").addClass("d-none");
    $("#DFIAUpdateLicense").removeClass("d-none");

    // Store the current row for updating
    $("#DFIAUpdateLicense").data("currentRow", row);
};

// Update table row
$("#DFIAUpdateLicense").click(function () {
    var licenseNumber = $("#DFIALicenseNumber").val();
    var licenseDate = $("#DFIALicenseDate").val();
    var registerNumber = $("#DFIARegisterNumber").val();
    var registerDate = $("#DFIARegisterDate").val();
    var quantity = $("#DFIAQuantity").val();
    var unit = $("#DFIAQtyUnit").val();
    var Hiddenunit = $("#HiddenDFIAQtyUnit").val();

    var row = $("#DFIAUpdateLicense").data("currentRow");
    row.find("input[name='TblDFIALicenceNo']").val(licenseNumber);
    row.find("input[name='TblDFIALicenceDate']").val(licenseDate);
    row.find("input[name='TblDFIARegisNumber']").val(registerNumber);
    row.find("input[name='TblDFIARegisDate']").val(registerDate);
    row.find("input[name='TblDFIAQty']").val(quantity);
    row.find("input[name='TblDFIAQtyUnit']").val(unit);
    row.find("input[name='HiddenTblDFIAQtyUnit']").val(Hiddenunit);

    ResetDFIADetails();
    // Show save button and hide update button
    $("#DFIAAddLicense").removeClass("d-none");
    $("#DFIAUpdateLicense").addClass("d-none");
    Toast('Record Update Successfully', 'Message', 'success');
});

// Delete table row
DeleteDFIARowEntry = function (btn) {
    if ($("#TblDFIALicenceDetails tbody tr").length > 1) {
        $(btn).closest("tr").remove();
        // Update serial numbers
        updateSerialNumbers();
    }
    else {
        ResetTblDFIALicenceDetails();
        // Update serial numbers
        updateSerialNumbers();
    }

    Toast('Record Deleted Successfully', 'Message', 'success');
};

// Update serial numbers
function updateSerialNumbers() {
    $("#TblDFIALicenceDetails tbody tr").each(function (index) {
        $(this).find(".rn").text(index + 1);
        DFIAserialNumber = index + 1;
    });
}

function ResetDFIADetails() {
    // Reset form fields
    $("#DFIALicenseNumber").val("");
    $("#DFIALicenseDate").val("");
    $("#DFIARegisterNumber").val("");
    $("#DFIARegisterDate").val("");
    $("#DFIAQuantity").val("0.00");
    $("#DFIAQtyUnit").val("");
    $("#HiddenDFIAQtyUnit").val("");
}
function ResetTblDFIALicenceDetails() {
    // Reset the first row fields
    $("#TblDFIALicenceDetails tbody tr:first input[name='TblDFIALicenceNo']").val("");
    $("#TblDFIALicenceDetails tbody tr:first input[name='TblDFIALicenceDate']").val("");
    $("#TblDFIALicenceDetails tbody tr:first input[name='TblDFIARegisNumber']").val("");
    $("#TblDFIALicenceDetails tbody tr:first input[name='TblDFIARegisDate']").val("");
    $("#TblDFIALicenceDetails tbody tr:first input[name='TblDFIAQty']").val("0.00");
    $("#TblDFIALicenceDetails tbody tr:first input[name='TblDFIAQtyUnit']").val("");
    $("#TblDFIALicenceDetails tbody tr:first input[name='HiddenTblDFIAQtyUnit']").val("");
}
//#endregion

//#region CODE FOR ITEM JOB DETAILS
// Initialize serial number
var ItemJobserialNumber = $("#TblItemJobDetails tbody tr:last .rn").text() !== "" ? parseInt($("#TblItemJobDetails tbody tr:last .rn").text()) : 0;

$("#ItemJobAddLicense").click(function () {
    var invSrNo = $("#ItemJobInvSrNo").val();
    var itemSrNo = $("#ItemJobItemSrNo").val();
    var beNumber = $("#ItemJobBENumber").val();
    var beDate = $("#ItemJobBEDate").val();
    var invNo = $("#ItemJobInvNo").val();
    var portCode = $("#ItemJobPortCode").val();
    var qtyUsed = $("#ItemJobQtyUsed").val();
    var unit = $("#ItemJobQtyUnit").val();
    var Hiddenunit = $("#HiddenItemJobQtyUnit").val();

    if (invSrNo === "" || itemSrNo === "") {
        Toast('Inv Sr No and Item Sr No are mandatory', 'Message', 'error');
        return;
    }

    // Check if the invSrNo already exists
    var exists = false;
    $("#TblItemJobDetails tbody tr").each(function () {
        var existingInvSrNo = $(this).find("input[name='TblItemJobInvSrNo']").val();
        if (existingInvSrNo === invSrNo) {
            exists = true;
            return false; // break the loop
        }
    });

    if (exists) {
        Toast('Inv Sr No already exists', 'Message', 'error');
        return;
    }

    var firstRow = $("#TblItemJobDetails tbody tr:first");
    if (firstRow.find("input[name='TblItemJobInvSrNo']").val() === "") {
        firstRow.find("input[name='TblItemJobInvSrNo']").val(invSrNo);
        firstRow.find("input[name='TblItemJobItemSrNo']").val(itemSrNo);
        firstRow.find("input[name='TblItemJobBENo']").val(beNumber);
        firstRow.find("input[name='TblItemJobBEDate']").val(beDate);
        firstRow.find("input[name='TblItemJobInvNo']").val(invNo);
        firstRow.find("input[name='TblItemJobPortCode']").val(portCode);
        firstRow.find("input[name='TblItemJobQty']").val(qtyUsed);
        firstRow.find("input[name='TblItemJobQtyUnit']").val(unit);
        firstRow.find("input[name='HiddenTblItemJobQtyUnit']").val(Hiddenunit);
        Toast('Record Add Successfully', 'Message', 'success');
    }
    else {
        var newRow = "<tr>" +
            "<td class=''>" +
            "<button name='EditItemJobRow' type='button' class='common-btn common-btn-sm' onclick='EditItemJobRowEntry(this);'><i class='fa-solid fa-pen-to-square'></i></button>" +
            "<button name='RemoveItemJobRow' type='button' class='common-btn common-btn-sm' onclick='DeleteItemJobRowEntry(this);'><i class='fa-regular fa-trash-can'></i></button>" +
            "</td>" +
            "<td class='text-center rn' style='padding-top:10px;'>" + (ItemJobserialNumber + 1) + "</td>" +
            "<td><input type='text' name='TblItemJobInvSrNo' class='form-control input-md mybox textbox-height TblItemJobInvSrNo' maxlength='10' title='Inv Sr No' value='" + invSrNo + "' /></td>" +
            "<td><input type='text' name='TblItemJobItemSrNo' class='form-control input-md mybox textbox-height TblItemJobItemSrNo' maxlength='10' title='Item Sr No' value='" + itemSrNo + "' /></td>" +
            "<td><input type='text' name='TblItemJobBENo' class='form-control input-md mybox textbox-height TblItemJobBENo' maxlength='10' title='BE Number' value='" + beNumber + "' /></td>" +
            "<td><input type='text' name='TblItemJobBEDate' class='datepickerAll form-control input-md mybox textbox-height TblItemJobBEDate' placeholder='dd/mm/yyyy' maxlength='10' value='" + beDate + "' disabled /></td>" +
            "<td><input type='text' name='TblItemJobInvNo' class='form-control input-md mybox textbox-height TblItemJobInvNo' maxlength='10' title='Inv Number' value='" + invNo + "' /></td>" +
            "<td><input type='text' name='TblItemJobPortCode' class='form-control input-md mybox textbox-height TblItemJobPortCode' maxlength='10' title='Port Code' value='" + portCode + "' /></td>" +
            "<td><input type='text' name='TblItemJobQty' class='form-control form-control-md TblItemJobQty' style='text-align:right' value='" + qtyUsed + "' readonly /></td>" +
            "<td><input type='Hidden' name='HiddenTblItemJobQtyUnit' class='form-control form-control-md HiddenTblItemJobQtyUnit' readonly value='" + Hiddenunit + "' /></td><input type='text' name='TblItemJobQtyUnit' class='form-control form-control-md TblItemJobQtyUnit' readonly value='" + unit + "' /></td>" +
            "</tr>";

        $("#TblItemJobDetails tbody").append(newRow);

        ItemJobserialNumber++;
        Toast('Record Add Successfully', 'Message', 'success');
    }

    ResetItemJobDetails();
});

// Edit table row
EditItemJobRowEntry = function (btn) {
    $("#ItemJobInvSrNo").focus();
    var row = $(btn).closest("tr");
    var invSrNo = row.find("input[name='TblItemJobInvSrNo']").val();
    var itemSrNo = row.find("input[name='TblItemJobItemSrNo']").val();
    var beNumber = row.find("input[name='TblItemJobBENo']").val();
    var beDate = row.find("input[name='TblItemJobBEDate']").val();
    var invNo = row.find("input[name='TblItemJobInvNo']").val();
    var portCode = row.find("input[name='TblItemJobPortCode']").val();
    var qtyUsed = row.find("input[name='TblItemJobQty']").val();
    var unit = row.find("input[name='TblItemJobQtyUnit']").val();
    var Hiddenunit = row.find("input[name='HiddenTblItemJobQtyUnit']").val();

    $("#ItemJobInvSrNo").val(invSrNo);
    $("#ItemJobItemSrNo").val(itemSrNo);
    $("#ItemJobBENumber").val(beNumber);
    $("#ItemJobBEDate").val(beDate);
    $("#ItemJobInvNo").val(invNo);
    $("#ItemJobPortCode").val(portCode);
    $("#ItemJobQtyUsed").val(qtyUsed);
    $("#ItemJobQtyUnit").val(unit);
    $("#HiddenItemJobQtyUnit").val(Hiddenunit);

    // Hide save button and show update button
    $("#ItemJobAddLicense").addClass("d-none");
    $("#ItemJobUpdateLicense").removeClass("d-none");

    // Store the current row for updating
    $("#ItemJobUpdateLicense").data("currentRow", row);
};

// Update table row
$("#ItemJobUpdateLicense").click(function () {
    var invSrNo = $("#ItemJobInvSrNo").val();
    var itemSrNo = $("#ItemJobItemSrNo").val();
    var beNumber = $("#ItemJobBENumber").val();
    var beDate = $("#ItemJobBEDate").val();
    var invNo = $("#ItemJobInvNo").val();
    var portCode = $("#ItemJobPortCode").val();
    var qtyUsed = $("#ItemJobQtyUsed").val();
    var unit = $("#ItemJobQtyUnit").val();
    var Hiddenunit = $("#HiddenItemJobQtyUnit").val();

    var row = $("#ItemJobUpdateLicense").data("currentRow");
    row.find("input[name='TblItemJobInvSrNo']").val(invSrNo);
    row.find("input[name='TblItemJobItemSrNo']").val(itemSrNo);
    row.find("input[name='TblItemJobBENo']").val(beNumber);
    row.find("input[name='TblItemJobBEDate']").val(beDate);
    row.find("input[name='TblItemJobInvNo']").val(invNo);
    row.find("input[name='TblItemJobPortCode']").val(portCode);
    row.find("input[name='TblItemJobQty']").val(qtyUsed);
    row.find("input[name='TblItemJobQtyUnit']").val(unit);
    row.find("input[name='HiddenTblItemJobQtyUnit']").val(Hiddenunit);

    ResetItemJobDetails();
    // Show save button and hide update button
    $("#ItemJobAddLicense").removeClass("d-none");
    $("#ItemJobUpdateLicense").addClass("d-none");
    Toast('Record Update Successfully', 'Message', 'success');
});

// Delete table row
DeleteItemJobRowEntry = function (btn) {
    if ($("#TblItemJobDetails tbody tr").length > 1) {
        $(btn).closest("tr").remove();
        // Update serial numbers
        updateSerialNumbers();
    }
    else {
        ResetTblItemJobDetails();
        // Update serial numbers
        updateSerialNumbers();
    }
    Toast('Record Deleted Successfully', 'Message', 'success');
};

// Update serial numbers
function updateSerialNumbers() {
    $("#TblItemJobDetails tbody tr").each(function (index) {
        $(this).find(".rn").text(index + 1);
        ItemJobserialNumber = index + 1;
    });
}

function ResetItemJobDetails() {
    // Reset form fields
    $("#ItemJobInvSrNo").val("");
    $("#ItemJobItemSrNo").val("");
    $("#ItemJobBENumber").val("");
    $("#ItemJobBEDate").val("");
    $("#ItemJobInvNo").val("");
    $("#ItemJobPortCode").val("");
    $("#ItemJobQtyUsed").val("");
    $("#ItemJobQtyUnit").val("");
    $("#HiddenItemJobQtyUnit").val("");
}

function ResetTblItemJobDetails() {
    // Reset the first row fields
    $("#TblItemJobDetails tbody tr:first input[name='TblItemJobInvSrNo']").val("");
    $("#TblItemJobDetails tbody tr:first input[name='TblItemJobItemSrNo']").val("");
    $("#TblItemJobDetails tbody tr:first input[name='TblItemJobBENo']").val("");
    $("#TblItemJobDetails tbody tr:first input[name='TblItemJobBEDate']").val("");
    $("#TblItemJobDetails tbody tr:first input[name='TblItemJobInvNo']").val("");
    $("#TblItemJobDetails tbody tr:first input[name='TblItemJobPortCode']").val("");
    $("#TblItemJobDetails tbody tr:first input[name='TblItemJobQty']").val("0.00");
    $("#TblItemJobDetails tbody tr:first input[name='TblItemJobQtyUnit']").val("");
    $("#TblItemJobDetails tbody tr:first input[name='HiddenTblItemJobQtyUnit']").val("");
}

//DOCUMENT UPLOAD ON CLICK FUNCTION FOR GET LIST OF DOCUMENT UPLOAD
$("#UploadDocument").click(function () {
    DocUploadResetdata();
    CommonFormList('JobDocUpload JDU INNER JOIN document_type_master DTM ON DTM.doc_type_uid =JDU.DocTypeUid', ' JDU.DocUploadUId, DTM.doc_type, JDU.FilePath,JDU.JobNo', 'FilePath');
});