﻿var f = 0;

//DOCUMENT READY
$(document).ready(function () {
    FillClientGroupList('ClientUserGroupPermisssionList');
});

// SAVE BUTTON CLICKED
$("#Btn_save_changes").click(function () {
    UserGroupPermissionsRights();
})

// FUNCTION FOR UPDATE USER GROUP RIGHTS
function UserGroupPermissionsRights() {
    try {
        const dataString = {};
        var UserGroupRightsData = new Array();

        $('#RightsTbl .rowdata').each(function () {
            var UserGroupRight = {};
            UserGroupRight.FormId = $(this).closest('tr').attr('id');
            UserGroupRight.Open = $(this).find('td:nth-child(2) input:checkbox').is(':checked');
            UserGroupRight.Insert = $(this).find('td:nth-child(3) input:checkbox').is(':checked');
            UserGroupRight.Update = $(this).find('td:nth-child(4) input:checkbox').is(':checked');
            UserGroupRight.Delete = $(this).find('td:nth-child(5) input:checkbox').is(':checked');
            UserGroupRight.Excel = $(this).find('td:nth-child(6) input:checkbox').is(':checked');
            UserGroupRightsData.push(UserGroupRight);
        });
        dataString.GroupId = parseInt($("#ClientUserGroupPermisssionList").val());
        dataString.UserGroupRights = UserGroupRightsData;

        AjaxSubmission(JSON.stringify(dataString), "/UserGroupPermissions/UpdateClientGroupRight", $('[name="__RequestVerificationToken"]').val()).done(function (data) {
            let obj = data;
            if (obj.status == true) {
                if (obj.responsecode == '100') {
                    Toast(RetrieveMessage(107), 'message', 'success');
                    $("#RightsTbl").empty();
                    FillClientGroupList('ClientUserGroupPermisssionList');
                    $("#Btn_save_changes").css("display", "none");
                }
                else
                    Toast(RetrieveMessage(obj.responsecode), "Message", "error");
            }
            else
                window.location.href = '/ClientLogin/ClientLogin';

            //Hideloader();
        }).fail(function (data) {
            //Hideloader();
            console.log(data.Message);
        });


    }
    catch (e) {
        console.log(e.message);
        //Hideloader();
    }
}

//FUNCTION FOR LOAD CHECK UNCHECK
function LoadCheckUncheck() {
    var k = 0;
    const CLASSLIST = ['open', 'insert', 'update', 'delete', 'excel'];
    const IDCHECKBOX = ['CheckViewAll', 'CheckAddAll', 'CheckEditAll', 'CheckDeleteAll', 'CheckExcelAll'];

    let i = 0, j = 0;;

    for (i = 0; i < CLASSLIST.length; i++) {
        k = 0;
        var AllElement = document.getElementsByClassName(CLASSLIST[i]);
        for (j = 1; j < AllElement.length; j++) {
            if (AllElement[j].checked == false) {
                k = 1;
            }
        }
        if (k == 1) {
            $("#" + IDCHECKBOX[i] + "").prop("checked", false);
        } else {
            $("#" + IDCHECKBOX[i] + "").prop("checked", true);
        }
    }
    k = 0;
    $("#" + IDCHECKBOX[0] + ",#" + IDCHECKBOX[1] + ",#" + IDCHECKBOX[2] + ",#" + IDCHECKBOX[3] + ",#" + IDCHECKBOX[4] + "").each(function (e, er) {
        if (er.checked == false) {
            k = 1;
            return false;
        }
    });

    if (k == 1) {
        $("#CheckAll").prop("checked", false);
    } else {
        $("#CheckAll").prop("checked", true);
    }
}
//FUNCTION FOR CHECK UNCHECK ALL CHECKBOXES
function CheckUncheckAllcheckbox() {

    let container = document.getElementById('RightsTbl');
    let ele = container.getElementsByTagName('input');
    if ($("#CheckAll")[0].checked == true) {
        for (i = 0; i < ele.length; i++) {
            if (ele[i].type == 'checkbox')
                $(ele[i]).prop('checked', true);
        }
    }
    else {
        for (i = 0; i < ele.length; i++) {
            if (ele[i].type == 'checkbox')
                $(ele[i]).prop('checked', false);
        }
    }
}

//FUNCTIO FOR COMMON CHECK
function CommonCheck() {
    f = 0;
    $(".open,.insert,.update,.delete,.excel").each(function (e, er) {
        if (er.checked == false) {
            f = 1;
            return false;
        }
    });
    if (f == 1) {
        $("#CheckAll").prop("checked", false);
        $("#RightsTbl").find(".Allind").each(function (e, el) {
            el.checked = false;
        });
    }
    else {
        $("#CheckAll").prop("checked", true);
        $("#RightsTbl").find(".Allind").each(function (e, el) {
            el.checked = true;
        });
    }
}

//FUNCTION FOR CHECK UNCHECK INDIVIDUAL
function CheckUncheck(e) {
    var clsname = $(e).attr('class').split(/\s+/);
    var all = document.getElementsByClassName(clsname[0]);

    for (let i = 0; i < all.length; i++)
        all[i].checked = e.checked;

    CommonCheck();
}

//FUNCTION FOR CHECK INDIVIDUAL
function CheckIndividual(e, r) {
    let flg = 0;
    var clsname = $(e).attr('class').split(/\s+/);
    var chkindex = clsname[0].search('ind');
    if (chkindex != -1) {
        $('#RightsTbl tbody ').find("." + $(e).parent().parent()[0].id).each(function (ind, el) {
            $(el).find('.' + clsname[1]).each(function (a, b) {
                if (e.checked == true)
                    b.checked = true
                else
                    b.checked = false;
            });
        });

        $('#RightsTbl tbody ').find("." + $(e).parent().parent()[0].id).each(function (ind, el) {
            $(el).find('.open,.insert,.update,.delete,.excel').each(function (a, b) {
                if (b.checked == false)
                    flg = 1;
            });
        });

        $('#RightsTbl tbody tr').each(function (ind, el) {
            if (el.id == $(e).parent().parent()[0].id) {
                $(el).find('.Allind').each(function (a, b) {
                    if (flg == 0)
                        b.checked = true;
                    else
                        b.checked = false;
                });
            }


        });


        Check(clsname[1]);
    } else {
        Check($(e).attr('class'));
    }
}

//FUNCTION FOR CHECK
function Check(cls) {
    let bool = false;
    $("#RightsTbl tbody").find("." + cls).each(function (i, e) {
        if (e.checked == false) {
            bool = true;
        }
    });
    if (bool == false) {
        $("." + cls + "all")[0].checked = true;
    }
    else
        $("." + cls + "all")[0].checked = false;
    CommonCheck();

}

function CheckIndividualAll(e) {
    $('#RightsTbl tbody ').find("." + $(e).parent().parent()[0].id).each(function (ind, el) {

        $(el).find('.open,.openind,.insert,.insertind,.update,.updateind,.delete,.deleteind,.excel,.excelind').each(function (a, b) {
            console.log(b);
            if (e.checked == true)
                b.checked = true
            else
                b.checked = false;
        });
    });

    $('#RightsTbl tbody ').find(".rowdata").each(function (ind, el) {

        if (el.id == $(e).parent().parent()[0].id) {
            $(el).find('.openind,.insertind,.updateind,.deleteind,.excelind').each(function (a, b) {
                console.log(b);
                if (e.checked == true)
                    b.checked = true
                else
                    b.checked = false;
            });
        }


    });
    $('#RightsTbl').find(".openall,.insertall,.updateall,.deleteall,.excelall,.CheckAll").each(function (ind, el) {

        if (e.checked == false)
            el.checked = false;

    });


}

// FUNCTION FOR FILL CLIENT USER RIGHTS
function FillClientGroupRights(GroupId) {
    try {

        const dataString = {};
        dataString.GroupId = parseInt(GroupId);
        AjaxSubmission(JSON.stringify(dataString), "/UserGroupPermissions/GetClientGroupRights", $('input[name=__RequestVerificationToken]').val()).done(function (data) {
            let obj = data;

            if (obj.status == true) {
                $("#Btn_save_changes").css("display", "block");

                let body = '<thead><tr><td colspan="8"><input type="checkbox" id="CheckAll" class="CheckAll" onclick="CheckUncheckAllcheckbox()"><label>&nbsp;Check All</label></td></tr>';

                body += '<tr><th><span><label>Page</label></span></th>';

                body += '<th><input type="checkbox"  class="open openall" onclick="CheckUncheck(this)" id="CheckViewAll"><label style=color:black;font-weight:bolder;text-transform:capitalize;>&nbsp;View</label></th>';
                body += '<th><input type="checkbox"  class="insert insertall" onclick="CheckUncheck(this)" id=CheckAddAll><label style=color:black;font-weight:bolder;text-transform:capitalize;>&nbsp;Add</label></th>';
                body += '<th><input type="checkbox"  class="update updateall" onclick="CheckUncheck(this)" id=CheckEditAll><label style=color:black;font-weight:bolder;text-transform:capitalize;>&nbsp;Edit</label></th>';
                body += '<th><input type="checkbox"  class="delete deleteall" onclick="CheckUncheck(this)" id=CheckDeleteAll><label style=color:black;font-weight:bolder;text-transform:capitalize;>&nbsp;Delete</label></th>';
                body += '<th><input type="checkbox"  class="excel excelall" onclick="CheckUncheck(this)" id=CheckExcelAll><label  style=color:black;font-weight:bolder;text-transform:capitalize;>&nbsp;Excel</label></th>';

                body += '</tr></thead><tbody>';

                const totalcount = obj.data.Table.length;
                const totalcount2 = obj.data.Table1.length;

                for (let i = 0; i < totalcount; i++) {

                    let pmi = obj.data.Table[i].form_id;

                    const open = obj.data.Table[i].form_open == false ? '' : 'checked="checked"';
                    const insert = obj.data.Table[i].form_insert == false ? '' : 'checked="checked"';
                    const update = obj.data.Table[i].form_update == false ? '' : 'checked="checked"';
                    const deleted = obj.data.Table[i].form_delete == false ? '' : 'checked="checked"';
                    const excel = obj.data.Table[i].export_excel == false ? '' : 'checked="checked"';
                    /*  const All = obj.data.Table[i].all == false ? '' : 'checked="checked"';*/

                    body += '<tr style="background-color: #e6e6e6;" class="rowdata" id="' + obj.data.Table[i].form_id + '"><td style="font-weight: bolder;">' + obj.data.Table[i].menu_name + '</td>';

                    body += '<td scope="col"><input type="checkbox" onclick="CheckIndividual(this)" ' + open + ' class="openind open" ><label style=color:black;font-weight:bolder;>&nbsp;View</label></td>';
                    body += '<td scope="col"><input type="checkbox" onclick="CheckIndividual(this)"' + insert + ' class="insertind insert" ><label style=color:black;font-weight:bolder;>&nbsp;Add</label></td>';
                    body += '<td scope="col"><input type="checkbox" onclick="CheckIndividual(this)"' + update + '  class="updateind update" ><label style=color:black;font-weight:bolder;>&nbsp;Edit</label></td>';
                    body += '<td scope="col"><input type="checkbox" onclick="CheckIndividual(this)"' + deleted + '  class="deleteind delete" ><label style=color:black;font-weight:bolder;>&nbsp;Delete</label></td>';
                    body += '<td scope="col"><input type="checkbox" onclick="CheckIndividual(this)"' + excel + '  class="excelind excel" ><label style=color:black;font-weight:bolder;>&nbsp;Excel</label></td>';
                    body += '<td scope="col"><input type="checkbox" onclick="CheckIndividualAll(this)" class="Allind"><label style=color:black;font-weight:bolder;>&nbsp;All</label></td>';
                    //body += '<td scope="col"><input type="checkbox" onclick="CheckIndividualAll(this)"' + All + 'class="Allind"><label style=color:black;font-weight:bolder;>&nbsp;All</label></td>';

                    for (let j = 0; j < totalcount2; j++) {
                        if (pmi == obj.data.Table1[j].parent_menu_id) {

                            const open = obj.data.Table1[j].form_open == false ? '' : 'checked="checked"';
                            const insert = obj.data.Table1[j].form_insert == false ? '' : 'checked="checked"';
                            const update = obj.data.Table1[j].form_update == false ? '' : 'checked="checked"';
                            const deleted = obj.data.Table1[j].form_delete == false ? '' : 'checked="checked"';
                            const excel = obj.data.Table1[j].export_excel == false ? '' : 'checked="checked"';

                            body += '<tr class="rowdata  ' + obj.data.Table[i].form_id + '" id="' + obj.data.Table1[j].form_id + '"><td>' + obj.data.Table1[j].menu_name + '</td>';
                            body += '<td scope="col"><input type="checkbox" onclick="CheckIndividual(this)"' + open + ' class="open" ></td>';
                            body += '<td scope="col"><input type="checkbox" onclick="CheckIndividual(this)"' + insert + ' class="insert" ></td>';
                            body += '<td scope="col"><input type="checkbox" onclick="CheckIndividual(this)"' + update + '  class="update" ></td>';
                            body += '<td scope="col"><input type="checkbox" onclick="CheckIndividual(this)"' + deleted + '  class="delete" ></td>';
                            body += '<td scope="col"><input type="checkbox" onclick="CheckIndividual(this)"' + excel + '  class="excel" ></td>';

                        }
                    }

                }
                $('#RightsTbl').append(body + '</tbody>');
                LoadCheckUncheck();
            }
            else {
                window.location.href = '/ClientLogin/ClientLogin';
            }
            //Hideloader();

        }).fail(function (result) {
            console.log(result.Message);
            //Hideloader();
        });
    }
    catch (e) {
        console.log(e.message);
    }
}

//CLIENT USER LIST CHANGE FUNCTION

$("#ClientUserGroupPermisssionList").change(function () {
    $("#RightsTbl").empty();
    if ($("#ClientUserGroupPermisssionList").val() == 0) {
        $("#Btn_save_changes").css("display", "none");
    } else {
        FillClientGroupRights($("#ClientUserGroupPermisssionList").val());
    }
});


