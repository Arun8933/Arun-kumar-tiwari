﻿var Firstcolumn = "";
$(document).on("click", ".pagination .page", function () {
    FormList(($(this).attr('page')));
});
//PAGE SIZE CLICKED
$("#ddlPageSize").change(function () {
    FormList(1);
});

//SEARCH BUTTON CLICKED
$("#FormSearch").click(function () {
    FormList(1);
});

// DOCUMENT READY
$(document).ready(function () {
    $(".datepickerAll").datepicker({
        changeMonth: true,
        changeYear: true,
        dateFormat: 'dd/mm/yy'
    });
    FillPageSizeList('ddlPageSize', FormList);
    GetListLicenceTypeName();
    GetListPartyName();
    GetPortName();
    LedgerAccHeadautocompleteForSearchLedger();
    PortNameautocompleteforLicence();
    LicenceTypeNameautocompleteforLicence();
})

$("#LicenceStatusTypeSearch").select2({ width: '100%' });
$("#SetLicenceType").select2({ width: '100%' });
$("#PartyName").select2({ width: '100%' });
$("#LicenceStatusType").select2({ width: '100%' });
$("#RegPort").select2({ width: '100%' });


$("#Amount").blur(function () {
    var amount = $("#Amount").val()
    if (amount != null) {
        $("#BalanceAmount").val(amount);
    } else {
        $("#BalanceAmount").val("");
    }
});

$("#LicenceNo").keyup(function () {
    if ($("#LicenceNo").val() != null) {
        $("#RegNo").val(parseInt($("#LicenceNo").val()));
    } else {
        $("#RegNo").val("");
    }
});

//$("#LicenceDate").keypress(function () {
//    if ($("#LicenceDate").val() != null) {
//        $("#RegDate").val($("#LicenceDate").val());
//    } else {
//        $("#RegDate").val("");
//    }
//});


//AUTO COMPLETE DROPDOWN FOR SEARCH LEDGER NAME 
function LedgerAccHeadautocompleteForSearchLedger() {
    $("#ClientNameSearch").autocomplete({
        source: function (request, response) {
            $.ajax({
                type: 'POST',
                url: "/Master/Licence/SearchAccHeadNameList",
                dataType: "json",
                async: false,
                data: {
                    AccDescription: request.term
                },
                success: function (result) {
                    response($.map(result.data.Table, function (LedgerName) {
                        return {
                            label: LedgerName.AccHead,
                            value: LedgerName.AccHead,
                            id: LedgerName.LedgerUid,
                        }
                    }));
                },
                error: function (response) {
                    console.log(response.responseText);
                }
            });
        },
        minLength: 1,
        selectFirst: true,
        selectOnly: true,
        //select: function (e, i) {
        //    console.log(i);
        //    $("#HiddenAccHeadId").val(i.item.id);
        //},
        focus: function (event, ui) { }
    }).focus(function () {
        $(this).autocomplete("search");
    });
}

//AUTO COMPLETE DROPDOWN FOR SEARCH LEDGER NAME 
function PortNameautocompleteforLicence() {
    $("#PortNameSearch").autocomplete({
        source: function (request, response) {
            $.ajax({
                type: 'POST',
                url: "/Master/Licence/SearchPortNameList",
                dataType: "json",
                async: false,
                data: {
                    PortName: request.term
                },
                success: function (result) {
                    response($.map(result.data.Table, function (PortName) {
                        return {
                            label: PortName.PortName,
                            value: PortName.PortName,
                            id: PortName.PortUid,
                        }
                    }));
                },
                error: function (response) {
                    console.log(response.responseText);
                }
            });
        },
        minLength: 1,
        selectFirst: true,
        selectOnly: true,
        //select: function (e, i) {
        //    console.log(i);
        //    $("#HiddenAccHeadId").val(i.item.id);
        //},
        focus: function (event, ui) { }
    }).focus(function () {
        $(this).autocomplete("search");
    });
}


//AUTO COMPLETE DROPDOWN FOR SEARCH LEDGER NAME 
function LicenceTypeNameautocompleteforLicence() {
    $("#LicenceTypeNameSearch").autocomplete({
        source: function (request, response) {
            $.ajax({
                type: 'POST',
                url: "/Master/Licence/SearchLicenceTypeNameList",
                dataType: "json",
                async: false,
                data: {
                    LicenceType: request.term
                },
                success: function (result) {
                    console.log(result);
                    response($.map(result.data.Table, function (LicenceType) {
                        return {
                            label: LicenceType.licence_type,
                            value: LicenceType.licence_type,
                            id: LicenceType.licence_type_uid,
                        }
                    }));
                },
                error: function (response) {
                    console.log(response.responseText);
                }
            });
        },
        minLength: 1,
        selectFirst: true,
        selectOnly: true,
        //select: function (e, i) {
        //    console.log(i);
        //    $("#HiddenAccHeadId").val(i.item.id);
        //},
        focus: function (event, ui) { }
    }).focus(function () {
        $(this).autocomplete("search");
    });
}



function GetListLicenceTypeName() {
    try {
        //Showloader();
        AjaxSubmission(null, "/Master/Licence/GetListLicenceTypeName", $('input[name=__RequestVerificationToken]').val()).done(function (data) {
            let obj = data;
            if (obj.status == true) {
                if (obj.responsecode == '100')
                    BindDropdown(obj.data.Table, 'SetLicenceType', 'licence_type_uid', 'licence_type', 'Select')
            }
            else {
                window.location.href = '/ClientLogin/ClientLogin';
            }
            //Hideloader();
        }).fail(function (result) {
            console.log(result.Message);
            //Hideloader();
        });
    }
    catch (e) {
        console.log(e.message);
        //Hideloader();
    }
}

function GetListPartyName() {
    try {
        //Showloader();
        AjaxSubmission(null, "/Master/Licence/GetListPartyName", $('input[name=__RequestVerificationToken]').val()).done(function (data) {
            let obj = data;
            if (obj.status == true) {
                if (obj.responsecode == '100')
                    BindDropdown(obj.data.Table, 'PartyName', 'LedgerUid', 'AccHead', 'Select')
            }
            else {
                window.location.href = '/ClientLogin/ClientLogin';
            }
            //Hideloader();
        }).fail(function (result) {
            console.log(result.Message);
            //Hideloader();
        });
    }
    catch (e) {
        console.log(e.message);
        //Hideloader();
    }
}

function GetPortName() {
    try {
        //Showloader();
        AjaxSubmission(null, "/Master/Licence/GetPortName", $('input[name=__RequestVerificationToken]').val()).done(function (data) {
            let obj = data;
            if (obj.status == true) {
                if (obj.responsecode == '100')
                    BindDropdown(obj.data.Table, 'RegPort', 'PortUid', 'PortName', 'Select')
            }
            else {
                window.location.href = '/ClientLogin/ClientLogin';
            }
            //Hideloader();
        }).fail(function (result) {
            console.log(result.Message);
            //Hideloader();
        });
    }
    catch (e) {
        console.log(e.message);
        //Hideloader();
    }
}



// BIND INVOICE TYPE TABLE

function BindFormTable(result, serial_no) {
    $("#tbl_Licence tbody tr").remove();
    if (result.length == 0) {
        tr = $('<tr/>');
        tr.append("<td class='text-center' colspan='9'>NO RESULTS FOUND</td>");
        $("#tbl_Licence tbody").append(tr);
    }
    else {
        for (i = 0; i < result.length; i++) {
            if (result[i].is_active == "InActive")
                tr = $(' <tr style="background-color:#fdd2d2;"/>');
            else
                tr = $('<tr/>');
            tr.append("<td class='text-center'><button type='button' onclick='FormEdit(\"" + result[i].licence_uid + "\");' class= 'common-btn common-btn-sm '><i class='fa-solid fa-pen-to-square'></i></button ><button type='button' onclick='FormDelete(\"" + result[i].licence_uid + "\");' class='common-btn common-btn-sm ms-1'> <i class='fa-regular fa-trash-can'></i></button ></td > ");
            tr.append("<td class='text-left'>" + serial_no + "</td>");
            tr.append("<td class='text-left'>" + result[i].licence_uid + "</td>");
            tr.append("<td class='text-left'><a href='javascript:void(0)' class='text-decoration-none' style='color: black !important;' onclick='FormEdit(\"" + result[i].licence_uid + "\");'>" + result[i].licence_no + "</a></td>");
            tr.append("<td class='text-center'>" + result[i].AccHead + "</td>");
            tr.append("<td class='text-center'>" + result[i].PortName + "</td>");
            tr.append("<td class='text-center'>" + result[i].licence_type + "</td>");
            tr.append("<td class='text-center'>" + result[i].licence_date + "</td>");
            tr.append("<td class='text-end'>" + result[i].amount + "</td>");
            tr.append("<td class='text-center'>" + result[i].is_active + "</td>");
            
            serial_no++;
            $("#tbl_Licence tbody").append(tr);
        }
    }
}

//LICENCE TYPE LIST PAGE INDEX
function FormList(pageindex) {
    try {
        const dataString = {};
        dataString.PageSize = $("#ddlPageSize").val();
        dataString.PageIndex = pageindex;
        dataString.LicenceNo = $("#LicenceNoSearch").val();
        dataString.LicenceType = $("#LicenceTypeNameSearch").val();
        dataString.PortName = $("#PortNameSearch").val();
        dataString.AccHead = $("#ClientNameSearch").val();
        dataString.Status = $("#LicenceStatusTypeSearch").val();
        dataString.OrderBy = $("#sort-column").val().trim() + " " + $("#sort-type").val().trim();
        //Showloader();
        AjaxSubmission(JSON.stringify(dataString), "/Master/Licence/FormList", $('input[name=__RequestVerificationToken]').val()).done(function (result) {
            let obj = result;

            console.log(obj);
            if (obj.status == true) {
                if (obj.responsecode == '100') {
                    var ser = ((parseInt(obj.data.Table1[0].PageIndex) - 1) * parseInt(obj.data.Table1[0].PageSize)) + 1;
                    BindFormTable(obj.data.Table, ser);
                    if (obj.data.Table1 != undefined && obj.data.Table1.length > 0) {
                        $(".pagination").BindPaging({
                            ActiveCssClass: "current",
                            PagerCssClass: "pager",
                            PageIndex: parseInt(obj.data.Table1[0].PageIndex),
                            PageSize: parseInt(obj.data.Table1[0].PageSize),
                            RecordCount: parseInt(obj.data.Table1[0].count)
                        });
                    }
                }
                else {
                    Toast(RetrieveMessage(obj.responsecode), "Message", "error");
                }
            }
            else {
                window.location.href = '/ClientLogin/ClientLogin';
            }
            //Hideloader();
        }).fail(function (result) {
            console.log(result.Message);
            //Hideloader();
        });
    }
    catch (e) {
        console.log(e.message);
        //Hideloader();
    }
}



//FUNCTION FOR SORTING FIELD
function Sorting(obj) {
    if (Firstcolumn != "") {
        document.getElementById(Firstcolumn).innerHTML = document.getElementById(Firstcolumn).getAttribute("data-column") + " <i class='fa-solid fa-sort'></i>";
    }
    Firstcolumn = obj.id;
    var colname = $(obj).data("column");
    $("#sort-column").val(Firstcolumn);
    var sorttype = $("#sort-type").val();
    if (sorttype == "ASC") {
        $("#sort-type").val("DESC");
        $(obj).html(colname + " <i  style='margin-left:10px;' class='fa-solid fa-sort-up'></i>");
    } else if (sorttype == "DESC") {
        $("#sort-type").val("ASC");
        $(obj).html(colname + " <i  style='margin-left:10px;' class='fa-solid fa-sort-down'></i>");
    }
    FormList(1);
}


$("#FormAdd").click(function () {
    RemoveAllError('Licence');
    ValidateAllFieldNewTest('Licence');
    if ($("#LicenceDate").val() == "") {
        Toast("Please Select Licence Date !", 'Message', 'error');
        return;
    }
    if ($("#RegPort").val() == "0") {
        Toast("Please Select Port Name !", 'Message', 'error');
        return;
    }
    if ($("#SetLicenceType").val() == "0") {
        Toast("Please Select Licence Type Name !", 'Message', 'error');
        return;
    }
    if ($("#PartyName").val() == "0") {
        Toast("Please Select Client Name !", 'Message', 'error');
        return;
    }
    if ($('#Amount').val() == '0.00') {
        Toast("Please Enter Amount !", 'Message', 'error');
        return;
    }
    else if (Ercount == 0) {
        FormAdd();
    }

});

//FUNCTION FOR LICENCE TYPE
function FormAdd() {
    try {
        const dataString = {};
        console.log(dataString);
        dataString.LicenceNo = $("#LicenceNo").val().trim();
        dataString.LicenceType = $("#SetLicenceType").val().trim();
        dataString.LicenceDate = $("#LicenceDate").val().trim();
        dataString.RegNo = $("#RegNo").val().trim();
        dataString.RegDate = $("#RegDate").val().trim();
        dataString.RegPort = $("#RegPort").val().trim();
        dataString.PartyName = $("#PartyName").val().trim();
        dataString.Amount = $("#Amount").val().trim();
        dataString.UsedAmount = $("#UsedAmount").val().trim();
        dataString.BalanceAmount = $("#BalanceAmount").val().trim();
        dataString.Status = $("#LicenceStatusType").val().trim();
        console.log(dataString);
        //Showloader();
        AjaxSubmission(JSON.stringify(dataString), "/Master/Licence/FormAdd", $('input[name=__RequestVerificationToken]').val()).done(function (result) {
            let obj = result;
            if (obj.status == true) {
                if (obj.responsecode == '101') {
                    Toast(RetrieveMessage(obj.responsecode), "Message", "success");
                    setTimeout(FormList(1), 500);
                    ResetForm();
                    TabHide();
                }
                else {
                    Toast(RetrieveMessage(obj.responsecode), "Message", "error");
                }
            }
            else {
                window.location.href = '/ClientLogin/ClientLogin';
            }
            //Hideloader();
        }).fail(function (result) {
            console.log(result.Message);
            //Hideloader();
        });
    }
    catch (e) {
        console.log(e.message);
        //Hideloader();
    }
}




//FUNCTION FOR EDIT LICENCE 
function FormEdit(LicenceId) {

    try {
        const dataString = {};
        dataString.LicenceId = parseInt(LicenceId);
        //Showloader();
        AjaxSubmission(JSON.stringify(dataString), "/Master/Licence/FormEdit", $('[name="__RequestVerificationToken"]').val()).done(function (data) {
            let obj = data;
            console.log(obj);
            if (obj.status == true) {
                if (obj.responsecode == '100') {
                    TabShow();
                    //$("#LicenceId").val(obj.data.Table[0].licence_uid);
                    $("#LicenceNo").val(obj.data.Table[0].licence_no);
                    $("#SetLicenceType").val(obj.data.Table[0].licence_type).trigger('change');
                    $("#LicenceDate").val(obj.data.Table[0].licence_date);
                    $("#PartyName").val(obj.data.Table[0].party_name).trigger('change');
                    $("#Amount").val(obj.data.Table[0].amount);
                    $("#UsedAmount").val(obj.data.Table[0].Used_amount);
                    $("#BalanceAmount").val(obj.data.Table[0].balance_amount);
                    $("#RegNo").val(obj.data.Table[0].reg_no);
                    $("#RegDate").val(obj.data.Table[0].reg_date);
                    $("#RegPort").val(obj.data.Table[0].reg_port).trigger('change');
                    if (obj.data.Table[0].is_active == true)
                        $("#LicenceStatusType").val(1).trigger('change');
                    else
                        $("#LicenceStatusType").val(0).trigger('change');
                }
                else {
                    Toast(RetrieveMessage(obj.responsecode), "Message", "error");
                }
            }
            else {
                window.location.href = '/ClientLogin/ClientLogin';
            }
            //Hideloader();
        }).fail(function (data) {
            console.log(data.Message);
            //Hideloader();
        });
    }
    catch (e) {
        console.log(e.message);
        //Hideloader();
    }
}



$("#FormUpdate").click(function () {
    RemoveAllError('Licence');
    ValidateAllFieldNewTest('Licence');
    if ($("#LicenceDate").val() == "") {
        Toast("Please Select Licence Date !", 'Message', 'error');
        return;
    }
    if ($("#RegPort").val() == "0") {
        Toast("Please Select Port Name !", 'Message', 'error');
        return;
    }
    if ($("#SetLicenceType").val() == "0") {
        Toast("Please Select Licence Type Name !", 'Message', 'error');
        return;
    }
    if ($("#PartyName").val() == "0") {
        Toast("Please Select Client Name !", 'Message', 'error');
        return;
    }
    if ($('#Amount').val() == '0.00') {
        Toast("Please Enter Amount !", 'Message', 'error');
        return;
    }
    else if (Ercount == 0) {
        FormUpdate();
    }
    //if (Ercount == 0)
    //    FormUpdate();
});


//FUNCTION FOR LICENCE TYPE
function FormUpdate() {
    try {
        const dataString = {};
        dataString.LicenceNo = $("#LicenceNo").val().trim();
        dataString.LicenceType = $("#SetLicenceType").val().trim();
        dataString.LicenceDate = $("#LicenceDate").val().trim();
        dataString.PartyName = $("#PartyName").val().trim();
        dataString.Amount = $("#Amount").val().trim();
        dataString.Status = $("#LicenceStatusType").val().trim();
        dataString.RegNo = $("#RegNo").val().trim();
        dataString.RegDate = $("#RegDate").val().trim();
        dataString.RegPort = $("#RegPort").val().trim();
        dataString.UsedAmount = $("#UsedAmount").val().trim();
        dataString.BalanceAmount = $("#BalanceAmount").val().trim();
        //Showloader();
        AjaxSubmission(JSON.stringify(dataString), "/Master/Licence/FormUpdate", $('input[name=__RequestVerificationToken]').val()).done(function (result) {
            let obj = result;
            if (obj.status == true) {
                if (obj.responsecode == '107') {
                    Toast(RetrieveMessage(obj.responsecode), "Message", "success");
                    setTimeout(FormList(1), 500);
                    ResetForm();
                    TabHide();
                }
                else {
                    Toast(RetrieveMessage(obj.responsecode), "Message", "error");
                }
            }
            else {
                window.location.href = '/ClientLogin/ClientLogin';
            }
            //Hideloader();
        }).fail(function (result) {
            console.log(result.Message);
            //Hideloader();
        });
    }
    catch (e) {
        console.log(e.message);
        //Hideloader();
    }
}



//FUNCTION FOR DELETE LICENCE TYPE
function FormDelete(e) {
    try {
        $.confirm({
            title: '',
            content: 'Are You Sure Want To Delete ?',
            type: 'red',
            typeAnimated: true,
            buttons: {
                tryAgain: {
                    text: 'Confirm',
                    btnClass: 'btn-red',
                    action: function () {

                        const datastring = {};
                        datastring.LicenceId = parseInt(e);
                        //Showloader();
                        AjaxSubmission(JSON.stringify(datastring), "/Master/Licence/FormDelete", $('[name="__RequestVerificationToken"]').val()).done(function (data) {
                            let obj = data;
                            if (obj.status == true) {
                                if (obj.responsecode == '102') {
                                    Toast(RetrieveMessage(obj.responsecode), "Message", "success");
                                    FormList(1);
                                    /* GetParentMenuName();*/
                                }
                                else {
                                    Toast(RetrieveMessage(obj.responsecode), "Message", "error");
                                }
                            }
                            else {
                                window.location.href = 'ClientLogin/ClientLogin';
                            }
                            //Hideloader();
                        }).fail(function (data) {
                            console.log(data.Message);
                            //Hideloader();
                        });
                    }
                },
                close: function () {
                    //Hideloader();
                }
            }
        });
    }
    catch (e) {
        console.log(e.message);
        //Hideloader();
    }
}


//FUNCTION FOR RESET FINANCIAL YEAR DATA FIELD
function ResetForm() {

    $("#LicenceNo").val("");
    $("#LicenceNoSearch").val("");
    $("#SetLicenceType").val("0").trigger('change');
    $("#LicenceDate").val("");
    $("#PartyName").val("0").trigger('change');
    $("#Amount").val("");
    $("#LicenceStatusType").val("1").trigger('change');

    $("#LicenceNoError").html("");
    $("#LicenceDateError").html("");


}

//FUCNTION FOR TAB SHOW
function TabShow() {
    $('#Licence_list-tab').removeClass('active');
    $('#Licence-tab').addClass('active');
    $('#Licence_list').removeClass('active show');
    $('#Licence').addClass('active show');
    $("#FormAdd").hide();
    $("#FormUpdate").show();
    $("#Licence-tab").html("Edit Licence");
}

//FUNCTION FOR TAB HIDE
function TabHide() {
    $('#Licence-tab').removeClass('active');
    $('#Licence_list-tab').addClass('active ');
    $('#Licence_list').addClass('active show');
    $('#Licence').removeClass('active show');
    $("#FormAdd").show();
    $("#FormUpdate").hide();
    $("#Licence-tab").html("Add Licence");
}

//MENU LIST TAB CLICKED
$("#Licence_list-tab").click(function () {
    RemoveAllError('Licence');
    ResetForm();
    TabHide();
})

//FUNCTION FOR GET DEFAULT PAGE
function FillDefaultPage() {
    try {

        //Showloader();
        AjaxSubmission(null, "/Master/Licence/GetDefaultPageSize", $('input[name=__RequestVerificationToken]').val()).done(function (data) {
            let obj = data;
            if (obj.status == true) {
                $("#ddlPageSize").val(obj.data.Table[0].DefaultPageSize);
                setTimeout(FormList(1), 1000);

            }
            else {
                window.location.href = '/ClientLogin/ClientLogin';
            }
            //Hideloader();

        }).fail(function (result) {
            console.log(result.Message);
            //Hideloader();
        });
    }
    catch (e) {
        console.log(e.message);
        //Hideloader();
    }
}

document.addEventListener("keydown", function (zEvent) {
    if (zEvent.ctrlKey && zEvent.altKey && (zEvent.key == "j" || zEvent.key == "J")) {
        $('#Licence_list-tab').removeClass('active ');
        $('#Licence_list').removeClass('active show');
        $('#Licence-tab').addClass('active');
        $('#Licence').addClass('active show');
        $("#FormAdd").show();
        $("#FormUpdate").hide();
        $("#FormReset").hide();
        $("#Licence-tab").html("Add Licence ");
        $('#LicenceNo').focus();
        ResetForm();

    }
});
