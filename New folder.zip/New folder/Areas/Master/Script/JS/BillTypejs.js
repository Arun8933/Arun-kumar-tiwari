﻿var Firstcolumn = "";

$(document).ready(function () {
    $('#BillTypeIdSearch').focus();
    FillPageSizeList('ddlPageSize', FormList);
});
//PAGINATION BUTTON PREVEIOUS NEXT CLICK
$(document).on("click", ".pagination .page", function () {
    FormList(($(this).attr('page')));
});

//PAGE SIZE DROPDOWN ON CHANGE
$("#ddlPageSize").change(function () {
    FormList(1);
});

//SEARCH BUTTON CLICK
$("#FormSearch").click(function () {
    FormList(1);
});
//FUNCTION FOR BILL LIST BIND
function FormList(pageindex) {
    try {

        const dataString = {};
        dataString.PageSize = $("#ddlPageSize").val();
        dataString.PageIndex = pageindex;
        dataString.BillTypeId = $("#BillTypeIdSearch").val().trim();
        dataString.BillTypeName = $("#BillTypeNameSearch").val().trim();
        dataString.OrderBy = $("#sort-column").val().trim() + " " + $("#sort-type").val().trim();
        ShowLoader();
        AjaxSubmission(JSON.stringify(dataString), "/Master/BillType/FormList", $('input[name=__RequestVerificationToken]').val()).done(function (result) {

            let obj = result;
            if (obj.status == true) {
                if (obj.responsecode == '100') {

                    var ser = ((parseInt(obj.data.Table1[0].PageIndex) - 1) * parseInt(obj.data.Table1[0].PageSize)) + 1;
                    //BindTable('tbl_group', obj.data.Table, true, true, ser, Sortcolumn, Sorttype);
                    BindFormTable(obj.data.Table, ser);
                    if (obj.data.Table1 != undefined && obj.data.Table1.length > 0) {
                        $(".pagination").BindPaging({
                            ActiveCssClass: "current",
                            PagerCssClass: "pager",
                            PageIndex: parseInt(obj.data.Table1[0].PageIndex),
                            PageSize: parseInt(obj.data.Table1[0].PageSize),
                            RecordCount: parseInt(obj.data.Table1[0].count)
                        });
                    }

                }
                else {
                    Toast(RetrieveMessage(obj.responsecode), "Message", "error");
                }
            }
            else {
                window.location.href = '/Login/Login';
            }
            HideLoader();
        }).fail(function (result) {
            console.log(result.Message);
            HideLoader();
        });
    }
    catch (e) {
        console.log(e.message);
        HideLoader();
    }
}

//BIND BILL TYPE TABLE
function BindFormTable(result, serial_no) {
    $("#tbl_BillType tbody tr").remove();

    if (result.length == 0) {
        tr = $('<tr/>');
        tr.append("<td class='text-center' colspan='8'>NO RESULTS FOUND</td>");
        $("#tbl_BillType tbody").append(tr);
    }
    else {
        for (i = 0; i < result.length; i++) {
            if (result[i].is_active == "Inactive")
                tr = $(' <tr style="background-color:#fdd2d2;"/>');
            else
                tr = $('<tr/>');
            tr.append("<td class='text-center'><button type='button' onclick='FormEdit(\"" + result[i].BillTypeUid + "\");' class='common-btn common-btn-sm'><i class='fa-solid fa-pen-to-square'></i></button ><button type='button' onclick='FormDelete(\"" + result[i].BillTypeUid + "\");' class='common-btn common-btn-sm'> <i class='fa-regular fa-trash-can'></i></button ></td > ");
            tr.append("<td class='text-left'>" + serial_no + "</td>");
            tr.append("<td class='text-left'>" + result[i].BillTypeUid + "</td>");
            tr.append("<td class='text-center'><a href='javascript:void(0)' class='text-decoration-none ' style='color: black !important;' onclick='FormEdit(\"" + result[i].BillTypeUid + "\");'>" + result[i].BillTypeName + "</a></td>");
            tr.append("<td class='text-center'>" + result[i].BookCode + "</td>");
            tr.append("<td class='text-center'>" + HandleNullTextValue(result[i].GstInvoiceCategory) + "</td>");



            serial_no++;

            $("#tbl_BillType tbody").append(tr);

        }

    }
}

//FUNCTION FOR FORM SORTING
function FormSorting(obj) {
    if (Firstcolumn != "") {
        document.getElementById(Firstcolumn).innerHTML = document.getElementById(Firstcolumn).getAttribute("data-column") + " <i class='fa-solid fa-sort'></i>";
    }
    let cn = obj.id;
    Firstcolumn = cn;
    var colname = $(obj).data("column");
    $("#sort-column").val(cn.replaceAll("_", ""));
    var sorttype = $("#sort-type").val();
    if (sorttype == "ASC") {
        $("#sort-type").val("DESC");
        $(obj).html(colname + " <i style='margin-left:10px;' class='fa-solid fa-sort-down'></i>");
    } else if (sorttype == "DESC") {
        $("#sort-type").val("ASC");
        $(obj).html(colname + " <i style='margin-left:10px;' class='fa-solid fa-sort-up'></i>");
    }
    FormList(1);
}

//FUNCTION FOR EXPORT DATA IN EXCEL
function FormExcel() {
    ShowLoader();
    let date = new Date();
    let NewDate = ("00" + date.getDate()).slice(-2) + "_" + ("00" + (date.getMonth() + 1)).slice(-2) + "_" + date.getFullYear() + "_" + ("00" + date.getHours()).slice(-2) + "_" + ("00" + date.getMinutes()).slice(-2) + "_" + ("00" + date.getSeconds()).slice(-2);
    let fileName = "BillType_" + NewDate + ".xlsx";

    $('#FormSearch').trigger('click');
    AjaxSubmission(null, '/Master/BillType/FormExcel', $('input[name=__RequestVerificationToken]').val()).done(function (result) {
        let obj = result;
        if (obj.status == true) {
            if (obj.responsecode == '100') {

                let bytes = Base64ToBytes(obj.data.FileData[0].Base64Data);
                let blob = new Blob([bytes], { type: "application/octetstream" });
                let isIE = false || !!document.documentMode;
                if (isIE) {
                    window.navigator.msSaveBlob(blob, fileName);
                } else {
                    let url = window.URL || window.webkitURL;
                    link = url.createObjectURL(blob);
                    let a = $("<a />");
                    a.attr("download", fileName);
                    a.attr("href", link);
                    $("body").append(a);
                    a[0].click();
                    $("body").remove(a);
                }
            }
            else if (obj.responsecode == '302')
                Toast("No Records found.", 'Message', 'success');
            else
                Toast(RetrieveMessage(obj.responsecode), 'Message', 'error');

        } else
            window.location.href = '/ClientLogin/ClientLogin';
        HideLoader();

    }).fail(function (result) {
        console.log(result.Message);
        HideLoader();
    });
}
//ADD BILL TYPE BUTTON CLICK
$("#FormAdd").click(function () {
    RemoveAllError('BillType');
    ValidateAllField('BillType');
    if (Ercount == 0)
        FormAdd();
});

//FUNCTION FOR ADD BILL TYPE
function FormAdd() {
    try {
        const datastring = {};
        datastring.BillTypeName = $("#BillTypeName").val();
        datastring.BookCode = $("#BookCode").val();
        datastring.GstInvoiceCategory = $("#GstInvoiceCategory").val();
        datastring.JobExpense = $("#JobExpense").is(":checked");


        ShowLoader();
        AjaxSubmission(JSON.stringify(datastring), "/Master/BillType/FormAdd", $('input[name=__RequestVerificationToken]').val()).done(function (result) {
            let obj = result;
            if (obj.status == true) {
                if (obj.responsecode == '101') {
                    Toast(RetrieveMessage(obj.responsecode), "Message", "success");
                    $("#FormAdd").hide();
                    $("#FormUpdate").show();
                    $("#FormReset").show();

                    FormList(1);
                    //ResetData();
                    //TabHide();
                }
                else {
                    Toast(RetrieveMessage(obj.responsecode), "Message", "error");
                }
            }
            else {
                window.location.href = '/Login/Login';
            }
            HideLoader();
        }).fail(function (result) {
            console.log(result.Message);
            HideLoader();
        });
    }
    catch (e) {
        console.log(e.message);
    }
}
//FUNCTION TO EDIT BILL TYPE
function FormEdit(e) {
    try {
        const datastring = {};
        datastring.BillTypeId = e;
        AjaxSubmission(JSON.stringify(datastring), "/BillType/FormEdit", $('[name="__RequestVerificationToken"]').val()).done(function (data) {
            let obj = data;
            if (obj.status == true) {
                if (obj.responsecode == '100') {
                    TabShow();
                    $("#GstInvoiceCategory").attr("disabled", "disabled");
                    $("#BillTypeId").val(obj.data.Table[0].BillTypeUid);
                    $("#BillTypeName").val(obj.data.Table[0].BillTypeName);
                    $("#BookCode").val(obj.data.Table[0].BookCode);
                    if (obj.data.Table[0].GstInvoiceCategory == null) {
                        $("#GstInvoiceCategory").val('0');
                    }
                    else {
                        $("#GstInvoiceCategory").val(obj.data.Table[0].GstInvoiceCategory);
                    }

                    $("#JobExpense").prop("checked", obj.data.Table[0].JobExpense);

                }
                else {
                    Toast(RetrieveMessage(obj.responsecode), "Message", "error");
                }
            }
            else {
                window.location.href = '/Login/Login';
            }
        }).fail(function (data) {
            console.log(data.Message);
        });

    }
    catch (e) {
        console.log(e.message);
    }
}
//UPDATE BILL TYPE BUTTON CLICK
$("#FormUpdate").click(function () {
    RemoveAllError('BillType');
    ValidateAllField('BillType');
    if (Ercount == 0)
        FormUpdate();
});

//FUNCTION FOR UPDATE BILL TYPE
function FormUpdate() {
    try {
        const datastring = {};
        datastring.BillTypeName = $("#BillTypeName").val();
        datastring.BookCode = $("#BookCode").val();
        datastring.GstInvoiceCategory = $("#GstInvoiceCategory").val();
        datastring.JobExpense = $("#JobExpense").is(":checked");


        ShowLoader();
        AjaxSubmission(JSON.stringify(datastring), "/Master/BillType/FormUpdate", $('input[name=__RequestVerificationToken]').val()).done(function (result) {
            let obj = result;
            if (obj.status == true) {
                if (obj.responsecode == '107') {
                    Toast(RetrieveMessage(obj.responsecode), "Message", "success");
                    FormList(1);
                    //ResetData();
                    //TabHide();
                }
                else {
                    Toast(RetrieveMessage(obj.responsecode), "Message", "error");
                }
            }
            else {
                window.location.href = '/Login/Login';
            }
            HideLoader();
        }).fail(function (result) {
            console.log(result.Message);
            HideLoader();
        });
    }
    catch (e) {
        console.log(e.message);
    }
}
//FUNCTION FOR DELETE BILL TYPE
function FormDelete(e) {
    try {
        $.confirm({
            title: '',
            content: 'Are You Sure Want To Delete ?',
            type: 'red',
            boxWidth: '300px',
            useBootstrap: false,
            columnClass: 'small',
            containerFluid: true,
            typeAnimated: true,
            buttons: {
                tryAgain: {
                    text: 'Confirm',
                    btnClass: 'btn-red',
                    action: function () {

                        const datastring = {};
                        datastring.BillTypeId = parseInt(e);
                        ShowLoader();
                        AjaxSubmission(JSON.stringify(datastring), "/Master/BillType/FormDelete", $('[name="__RequestVerificationToken"]').val()).done(function (data) {
                            let obj = data;
                            if (obj.status == true) {
                                if (obj.responsecode == '102') {
                                    Toast(RetrieveMessage(obj.responsecode), "Message", "success");
                                    FormList(1);

                                }
                                else {
                                    Toast(RetrieveMessage(obj.responsecode), "Message", "error");
                                }
                            }
                            else {
                                window.location.href = '/Login/Login';
                            }
                            HideLoader();
                        }).fail(function (data) {
                            console.log(data.Message);
                            HideLoader();
                        });
                    }
                },
                close: function () {
                    HideLoader();
                }
            }
        });
    }
    catch (e) {
        console.log(e.message);
        HideLoader();
    }
}
//FUNCTION FOR TAB SHOW
function TabShow() {
    $('#BillType_List-tab').removeClass('active');
    $('#BillType-tab').addClass('active');
    $('#BillType_list').removeClass('active show');
    $('#BillType').addClass('active show');
    $("#FormAdd").hide();
    $("#FormUpdate").show();
    $("#FormReset").show();
    $("#BillType-tab").html("Edit Bill Type");
}

//FUNCTION FOR TAB HIDE
function TabHide() {
    $('#BillType-tab').removeClass('active');
    $('#BillType_List-tab').addClass('active ');
    $('#BillType_list').addClass('active show');
    $('#BillType').removeClass('active show');
    $("#FormAdd").show();
    $("#FormUpdate").hide();
    $("#FormReset").hide();
    $("#BillType-tab").html("Add Bill Type");
}
function ResetData() {
    $("#FormAdd").show();
    $("#FormUpdate").hide();
    $("#FormReset").hide();
    $("#BillType-tab").html("Add Bill Type");
    $("#BillTypeId").val('');
    $("#BillTypeName").val('');
    $("#BookCode").val('');
    $("#GstInvoiceCategory").val('0');
    $("#BookCodeNameError").html("");
    $("#BillTypeNameError").html("");
    $("#JobExpense").prop("checked", false);
    $("#GstInvoiceCategory").removeAttr("disabled");
}
//CONTAINER TYPE LIST TAB ON CLICK 
$('#BillType_List-tab').click(function () {
    ResetData();
    TabHide();
});
$("#FormReset").click(function () {
    ResetData();
});

