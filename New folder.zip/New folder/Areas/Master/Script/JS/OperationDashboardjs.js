﻿let donutChart;
let donut;

function GetImportExportJobcount() {
    try {
        AjaxSubmission(null, '/Master/Dashboard/GetImportExportJobcount', $('input[name=__RequestVerificationToken]').val()).done(function (result) {
            let obj = result;
            if (obj.status == true) {
                if (obj.responsecode == '100') {                   
                    let Importjobdata = new Array();
                    let MonthName = new Array();
                    $.each(obj.data.Table1, function (ind, ele) {                     
                        Importjobdata.push(ele.Count);
                        MonthName.push(ele.Month);
                    });
                    let Exportjobdata = new Array();
                    $.each(obj.data.Table2, function (ind, ele) {
                        Exportjobdata.push(ele.Count);
                    });
                    
                    let options = {
                        series: [{
                            name: 'Import',
                            data: Importjobdata
                        }, {
                            name: 'Export',
                            data: Exportjobdata
                        }],
                        chart: {
                            type: 'bar',
                            height: 350
                        },
                        colors: ["#1d5faf", "#5d93d5"],
                        plotOptions: {
                            bar: {
                                horizontal: false,
                                columnWidth: '55%',
                                endingShape: 'rounded'
                            },
                        },
                        dataLabels: {
                            enabled: false
                        },
                        stroke: {
                            show: true,
                            width: 2,
                            colors: ['transparent']
                        },
                        xaxis: {
                            categories: MonthName,
                        },

                        yaxis: {
                            labels: {
                                /**
                                * Allows users to apply a custom formatter function to yaxis labels.
                                *
                                * @param { String } value - The generated value of the y-axis tick
                                * @param { index } index of the tick / currently executing iteration in yaxis labels array
                                */
                                formatter: function (val, index) {
                                    if (val != Infinity)
                                        return val.toFixed(0);
                                }
                            }
                        },
                        fill: {
                            opacity: 1
                        },
                        title: {
                            text: "Total Job Chart",
                            align: 'center',
                            margin: 10,
                            offsetX: 0,
                            offsetY: 0,
                            floating: false,
                            style:
                            {
                                fontSize: '14px',
                                fontWeight: 'bold',
                                fontFamily: 'Arial,Helvetica,sans-serif'
                            }
                        }
                    };

                    var chart = new ApexCharts(document.querySelector("#ImportExport"), options);
                    chart.render();

                }

            } else
                window.location.href = '/ClientLogin/ClientLogin';           
        }).fail(function (result) {
            console.log(result.Message);        
        });
    }
    catch (e) {        
        console.log(e.message);
    }
}

// DOCUMENT ON READY FUNCTION
$(document).ready(function () {

    GetImportExportJobcount();
    FillBranchList('SearchDashBoardBranch', false);
    GetFinancialYearDate();
    $("#SearchDashBoardBranch").select2({
        width: '100%'
    });

    //GetBillEntryChartDetailsData();
    //GetPurchaseEntryChartDetailsData();

    let DashRecord = setInterval(() => {
        if ($('#SearchDashBoardJobDateFrom').val().length == 10 && $('#SearchDashBoardJobDateTo').val().length == 10 && $('#SearchDashBoardBranch').val() == 0) {
            GetDashBoardImportExportJobInformation($('#SearchDashBoardJobDateFrom').val(), $('#SearchDashBoardJobDateTo').val(), $('#SearchDashBoardBranch').val());
            clearInterval(DashRecord);
        }
    }, 100);

    $('#SearchDashBoardJobDateFrom,#SearchDashBoardJobDateTo').datepicker({
        toolbarPlacement: 'bottom',
        showButtonPanel: true,
        changeMonth: true,
        changeYear: true,
        dateFormat: 'dd/mm/yy',
        onClose: function () {
            if ($('#SearchDashBoardJobDateFrom').val().length == 10 || $('#SearchDashBoardJobDateTo').val().length == 10)
                CompareSearchDate($('#SearchDashBoardJobDateFrom').val(), $('#SearchDashBoardJobDateTo').val(), 'Date');
        }
    });

});


//SEARCHDATEFROM ON INPUT EVENT
$('#SearchDashBoardJobDateFrom').on('input', function () {
    if ($('#SearchDashBoardJobDateFrom').val().length == 10)
        CompareSearchDate($('#SearchDashBoardJobDateFrom').val(), $('#SearchDashBoardJobDateTo').val(), 'Date');
});

//SEARCHDATETO ON INPUT EVENT
$('#SearchDashBoardJobDateTo').on('input', function () {
    if ($('#SearchDashBoardJobDateTo').val().length == 10)
        CompareSearchDate($('#SearchDashBoardJobDateFrom').val(), $('#SearchDashBoardJobDateTo').val(), 'Date');
});

// FUNCTION FOR BILL  CHART
function GetBillEntryChartDetailsData() {
    try {
        AjaxSubmission(null, "/Home/GetBillEntryChartDetailsData", $('[name="__RequestVerificationToken"]').val()).done(function (data) {
            let obj = data;
            if ((obj != null)) {
                if (obj.series.length > 0) {
                    let options = {
                        series: [{
                            name: 'Bill Entry',
                            data: data.series
                        }, {
                            name: 'Credit Note',
                            data: data.series1
                        }, {
                            name: 'Debit Note',
                            data: data.series2
                        }, {
                            name: 'Reimbursement Entry',
                            data: data.series3
                        }],
                        chart: {
                            height: 230,
                            type: 'area',
                            zoom: {
                                enabled: true
                            }
                        },
                        dataLabels: {
                            enabled: false
                        },
                        stroke: {
                            curve: 'smooth',
                            width: 1
                        },
                        xaxis: {
                            type: 'Month',
                            categories: data.label

                        },
                        tooltip: {
                            x: {
                                format: 'dd/MM'
                            },
                        },
                        legend: {
                            position: 'top'
                        },
                        title: {
                            text: "Yearly Bill Type Chart",
                            align: 'center',
                            margin: 10,
                            offsetX: 0,
                            offsetY: 0,
                            floating: false,
                            style:
                            {
                                fontSize: '14px',
                                fontWeight: 'bold',
                                fontFamily: 'Arial,Helvetica,sans-serif'
                                //color: '#263238'
                            }
                        }
                    };
                    let chart = new ApexCharts(document.querySelector("#timeline-chart"), options);
                    chart.render();
                }
                else {
                    Toast(RetrieveMessage(obj.responsecode), "Message", "error");
                }
            }
            else {
                window.location.href = '/ClientLogin/ClientLogin';
            }
        }).fail(function (data) {
            console.log(data.Message);
        });
    }
    catch (e) {
        console.log(e.message);
    }
}

// FUNCTION FOR PURCHASE ENTRY CHART
function GetPurchaseEntryChartDetailsData() {
    try {
        AjaxSubmission(null, "/Home/GetPurchaseEntryChartDetailsData", $('[name="__RequestVerificationToken"]').val()).done(function (data) {
            let obj = data;
            if ((obj != null)) {
                if (obj.series.length > 0) {
                    let options = {
                        series: [{
                            name: 'Purchase',
                            data: data.series
                        }],
                        chart: {
                            height: 230,
                            type: 'area',
                            zoom: {
                                enabled: true
                            }
                        },
                        dataLabels: {
                            enabled: false
                        },
                        stroke: {
                            curve: 'smooth',
                            width: 1
                        },
                        xaxis: {
                            type: 'Month',
                            categories: data.label

                        },
                        tooltip: {
                            x: {
                                format: 'dd/MM'
                            },
                        },
                        legend: {
                            position: 'top'
                        },
                        title: {
                            text: "Month Wise Purchase Chart",
                            align: 'center',
                            margin: 10,
                            offsetX: 0,
                            offsetY: 0,
                            floating: false,
                            style:
                            {
                                fontSize: '14px',
                                fontWeight: 'bold',
                                fontFamily: 'Arial,Helvetica,sans-serif'
                                //color: '#263238'
                            }
                        }
                    };
                    let chart = new ApexCharts(document.querySelector("#Purchase-chart"), options);
                    chart.render();
                }
                else {
                    Toast(RetrieveMessage(obj.responsecode), "Message", "error");
                }

            }
            else {
                window.location.href = '/ClientLogin/ClientLogin';
            }
        }).fail(function (data) {
            console.log(data.Message);
        });
    }
    catch (e) {
        console.log(e.message);
    }
}

// FUNCTION FOR IMPORT DONUT CHART JOB DETAILS
function GetImortChartDetailsData(FromDate, ToDate, BranchId) {
    try {
        const dataString = {};
        dataString.FromDate = FromDate;
        dataString.ToDate = ToDate;
        dataString.BranchId = BranchId;
        AjaxSubmission(JSON.stringify(dataString), "/Home/GetImortChartDetailsData", $('[name="__RequestVerificationToken"]').val()).done(function (data) {
            let obj = data;
            if (obj.success == true) {
                if (obj.series.length > 0) {
                    donutChart = {
                        chart: {
                            height: 320,
                            type: 'donut',
                            toolbar: {
                                show: false,
                            }
                        },
                        series: data.series,
                        labels: data.labels,
                        legend: {
                            position: 'top'
                        },
                        title: {
                            text: "Import Job Chart",
                            align: 'center',
                            margin: 10,
                            offsetX: 0,
                            offsetY: 0,
                            floating: false,
                            style:
                            {
                                fontSize: '14px',
                                fontWeight: 'bold',
                                fontFamily: 'Arial,Helvetica,sans-serif'
                                //color: '#263238'
                            }
                        }

                    }
                    donut = new ApexCharts(
                        document.querySelector("#donut-chart"),
                        donutChart
                    );
                    donut.render();
                }
                else {
                    Toast(RetrieveMessage(obj.responsecode), "Message", "error");
                }

            }
            else {
                window.location.href = '/ClientLogin/ClientLogin';
            }
        }).fail(function (data) {
            console.log(data.Message);
        });
    }
    catch (e) {
        console.log(e.message);
    }
}

// FUNCTION FOR EXPORT DONUT CHART JOB DETAILS
function GetExportChartDetailsData() {
    try {
        AjaxSubmission(null, "/Home/GetExportChartDetailsData", $('[name="__RequestVerificationToken"]').val()).done(function (data) {
            let obj = data;
            if (obj.success == true) {
                if (obj.series.length > 0) {
                    donutChart = {
                        chart: {
                            height: 320,
                            type: 'donut',
                            toolbar: {
                                show: false,
                            }
                        },
                        series: data.series,
                        labels: data.labels,
                        legend: {
                            position: 'top'
                        },
                        title: {
                            text: "Export Job Chart",
                            align: 'center',
                            margin: 10,
                            offsetX: 0,
                            offsetY: 0,
                            floating: false,
                            style:
                            {
                                fontSize: '14px',
                                fontWeight: 'bold',
                                fontFamily: 'Arial,Helvetica,sans-serif'
                                //color: '#263238'
                            }
                        }

                    }
                    donut = new ApexCharts(
                        document.querySelector("#donut-chart1"),
                        donutChart
                    );
                    donut.render();
                }
                else {
                    Toast(RetrieveMessage(obj.responsecode), "Message", "error");
                }

            }
            else {
                window.location.href = '/ClientLogin/ClientLogin';
            }
        }).fail(function (data) {
            console.log(data.Message);
        });
    }
    catch (e) {
        console.log(e.message);
    }
}


//FUNCTION FOR GO TO IMPORT JOB
function GoToSearchImportJob(e, Type, Status) {
    SetCookie('ClientId', $("#" + e).val(), 's', 50);
    SetCookie('HiddenSrchLedgName', $('#HiddenSrchLedgName').val(), 's', 50);
    if (Type != null && Type != undefined && Type != '') {
        SetCookie('Type', Type, 's', 50);
    }
    window.open('/Master/ImportJobEntry/ImportJobEntry');
}

// FUNCTION FOR GO TO REDIRECT VIEW ON IMPORT JOB ENTRY
function GoToRedirectViewOnImport(e) {
    window.open('/Master/ImportJobEntry/ImportJobEntry');
    localStorage.setItem('PageName', 'Import Job');

    SetCookie('JobType', e,);

}

// FUNCTION FOR GO TO REDIRECT VIEW ON BILL ENTRY
function GoToRedirectViewOnBillEntry(e) {
    window.open('/Master/BillEntry/BillEntry');
    localStorage.setItem("PageName", 'Bill Entry');
    SetCookie('BillType', e,);

}

//FUNCTION FOR GET FINANCIAL YEAR DATE
function GetFinancialYearDate() {
    try {
        AjaxSubmission(null, '/_Layout/GetFinancialYearDate', $('[name="__RequestVerificationToken"]').val()).done(function (result) {
            let obj = result;
            if (obj.status == true) {
                if (obj.responsecode == '100') {
                    $('#SearchDashBoardJobDateFrom').val(obj.data.Table[0].finyr_start_date);
                    $('#SearchDashBoardJobDateTo').val(obj.data.Table[0].finyr_end_date);
                }
            }
            else
                window.location.href = '/ClientLogin/ClientLogin';
            HideLoader();
        }).fail(function (result) {
            HideLoader();
            console.log(result.message);
        });
        HideLoader();
    }
    catch (e) {
        HideLoader();
        console.log(e.message);
    }
}


function ResetData() {
    $('#SearchDashBoardJobDateFrom,#SearchDashBoardJobDateTo').val(''); 
    $('#SearchDashBoardBranch').val('0').trigger('change');
    $('#SearchDashBoardJobDateFrom').focus();
    $('.datepickerAll').datepicker('setDate', 'today');

};

var demo = document.getElementById('demo');
$('#Calender').click(function () {
    demo.style.display = "block";
})


//ON CLICK FUNCTION FOR CLOSE BUTTON
$('#BtnClose').click(function () {
    demo.style.display = 'none';
    //ResetDataBillAdjModal();
});

//FUNCTION FOR DATE WISE FILTER RECORDS ON DASHBOARD
$('#DashBoardFormSearch').click(function () {
    let flag = 0;
    let FromDate = $('#SearchDashBoardJobDateFrom').val();
    let ToDate = $('#SearchDashBoardJobDateTo').val();
    let BranchId = $('#SearchDashBoardBranch').val();

    if ($("#SearchDashBoardJobDateFrom").val().length != 10) {
        Toast("Invalid From Date!", "Message", "error");
        return false;
    }

    if ($("#SearchDashBoardJobDateTo").val().length != 10) {
        Toast("Invalid To Date!", "Message", "error");
        return false;
    }

    if (flag == 0) {
        $('#demo').removeClass('show');
        $('#demo').css('visibility', 'hidden');
        $('#demo').removeAttr('role');
        $('#demo').removeAttr('aria-modal');
        $('#demo').attr('aria-hidden', true);
        $('#main_Body').attr('style', 'overflow:visible');

        GetDashBoardImportExportJobInformation(FromDate, ToDate, BranchId);
    }
});

//FUNCTION FOR GET DASHBOARD CARD  INFORMATION
function GetDashBoardImportExportJobInformation(FromDate, ToDate, BranchId) {
    try {
        EraseCookie('SearchFrmDate');
        EraseCookie('SearchToDate');
        EraseCookie('SearchBranch');
        const dataString = {};
        dataString.FromDate = FromDate;
        dataString.ToDate = ToDate;
        dataString.BranchId = BranchId;
        AjaxSubmission(JSON.stringify(dataString), "/Home/GetDashBoardImportExportJobInformation", $('input[name=__RequestVerificationToken]').val()).done(function (result) {
            let obj = result;
            if (obj.status == true) {

                if (obj.responsecode == "100") {


                    SetCookie('SearchFrmDate', $('#SearchDashBoardJobDateFrom').val());
                    SetCookie('SearchToDate', $('#SearchDashBoardJobDateTo').val());
                    SetCookie('SearchBranch', $('#SearchDashBoardBranch').val());

                    //FILL IMPORT CARD DETAILS
                    $('#TotalJob').html(obj.data.Table1[0].TotalImportJob);
                    $('#BilledJob').html(obj.data.Table1[0].TotalImportBilledJob);
                    $('#UnBilledJob').html(obj.data.Table1[0].TotalImportUnbilledJob);
                    $('#PendingJob').html(obj.data.Table1[0].TotalImportPendingJob);

                    //FILL EXPORT CARD DETAILS
                    $('#ETotalJob').html(obj.data.Table1[0].TotalExportJob);
                    $('#EBilledJob').html(obj.data.Table1[0].TotalExportBilledJob);
                    $('#EUnBilledJob').html(obj.data.Table1[0].TotalExportUnbilledJob);
                    $('#EPendingJob').html(obj.data.Table1[0].TotalExportPendingJob);

                    //var BlHtml = ' <h2>Account Deatils</h2>';
                    //if (obj.data.Table.length > 0) {
                    //    for (i = 0; i < obj.data.Table.length; i++) {
                    //        BlHtml += '      <div class="col-sm-6 col-lg-3" style="margin-top:-4px;"><a href =javascript:void(0) onclick=GoToRedirectViewOnBillEntry("' + obj.data.Table[i].BillTypeUid + '");><div class="card mybox"><div class="card-body row col-12 "> <table><tr><td rowspan="2" width="30%"><img src="' + obj.data.Table[i].fileloc + '" class="iconWidth" /></td><td align="left"><span class="subheader">' + obj.data.Table[i].BillTypeName + '</span></td></tr><tr><td align="left"><span class="me-1 " style="font-size: 18px !important;" id="TotalBill">' + obj.data.Table[i].TotalCount + '</span> &nbsp &nbsp<span class="text-end" style="font-size: 18px !important;"> ₹ ' + parseFloat(obj.data.Table[i].TotalAmount.toFixed(2)).toLocaleString("en-US") + ' </span></td></tr></table></div></div></a></div>';

                    //    }


                    //}

                    //$('#AllBIllCard').html(BlHtml);

                    let ImportSeries = new Array();
                    ImportSeries.push(obj.data.Table1[0].TotalImportUnbilledJob);
                    ImportSeries.push(obj.data.Table1[0].TotalImportBilledJob);
                    ImportSeries.push(obj.data.Table1[0].TotalImportPendingJob);

                    let ImportLabel = new Array();
                    ImportLabel.push("UnBilled Job");
                    ImportLabel.push("billed Job");
                    ImportLabel.push("Pending Job");


                    let ExportSeries = new Array();
                    ExportSeries.push(obj.data.Table1[0].TotalExportUnbilledJob);
                    ExportSeries.push(obj.data.Table1[0].TotalExportBilledJob);
                    ExportSeries.push(obj.data.Table1[0].TotalExportPendingJob);

                    let ExportLabel = new Array();
                    ExportLabel.push("UnBilled Job");
                    ExportLabel.push("billed Job");
                    ExportLabel.push("Pending Job");

                    donutChart = {
                        chart: {
                            type: "donut",
                            fontFamily: 'inherit',
                            height: 250,
                            sparkline: {
                                enabled: false
                            },
                            animations: {
                                enabled: true
                            },
                        },
                        fill: {
                            opacity: 1,
                        },
                        series: ImportSeries,
                        labels: ["UnBilled Job", "billed Job", "Pending Job"],
                        grid: {
                            strokeDashArray: 4,
                        },
                        colors: ["#5d93d5", "#1d5faf", "#86aedf"],
                        legend: {
                            show: true,
                            position: 'top',
                            offsetY: 12,
                            markers: {
                                width: 10,
                                height: 10,
                                radius: 100,
                            },
                            itemMargin: {
                                horizontal: 8,
                                vertical: 8
                            },

                        },
                        tooltip: {
                            fillSeriesColor: true
                        },

                        legend: {
                            position: 'top'
                        },
                        title: {
                            text: "Import Job Chart",
                            align: 'center',
                            margin: 10,
                            offsetX: 0,
                            offsetY: 0,
                            floating: false,
                            style:
                            {
                                fontSize: '14px',
                                fontWeight: 'bold',
                                fontFamily: 'Arial,Helvetica,sans-serif'
                            }
                        }

                    }


                    donut = new ApexCharts(
                        document.querySelector("#donut-chart"),
                        donutChart
                    );
                    donut.render();


                    donutChart = {
                        chart: {
                            type: "donut",
                            fontFamily: 'inherit',
                            height: 250,
                            sparkline: {
                                enabled: false
                            },
                            animations: {
                                enabled: true
                            },
                        },
                        fill: {
                            opacity: 1,
                        },

                        series: ExportSeries,
                        labels: ["UnBilled Job", "billed Job", "Pending Job"],
                        grid: {
                            strokeDashArray: 4,
                        },
                        colors: ["#5d93d5", "#1d5faf", "#86aedf"],
                        legend: {
                            show: true,
                            position: 'top',
                            offsetY: 12,
                            markers: {
                                width: 10,
                                height: 10,
                                radius: 100,
                            },
                            itemMargin: {
                                horizontal: 8,
                                vertical: 8
                            },

                        },
                        tooltip: {
                            fillSeriesColor: true
                        },

                        legend: {
                            position: 'top'
                        },
                        title: {
                            text: "Export Job Chart",
                            align: 'center',
                            margin: 10,
                            offsetX: 0,
                            offsetY: 0,
                            floating: false,
                            style:
                            {
                                fontSize: '14px',
                                fontWeight: 'bold',
                                fontFamily: 'Arial,Helvetica,sans-serif'
                            }
                        }

                    }

                    donut1 = new ApexCharts(
                        document.querySelector("#donut-chart1"),
                        donutChart
                    );
                    donut1.render();


                }
                else if (obj.responsecode == '703')
                    Toast(RetrieveMessage(obj.error), 'Message', 'error');

            }
            else
                window.location.href = '/ClientLogin/ClientLogin';
        }).fail(function (result) {
            console.log(result.message);
        });
    }
    catch (e) {
        console.log(e.message);
    }
}

