﻿var drid = "";
$(document).ready(function () {
    FillAllReport();
    FillPageSizeList2('ddlPageSize2');
    FillPageSizeList('ddlPageSize', CustomReportList);
    /* CustomReportList(1);*/
});

var FlagSearchTable = 0;
var FlagSearchTable2 = 0;
var FlagSearchTable4 = 0;

$("#ReportVisible").select2({
    width: '100%'
});

function FillPageSizeList2(drpid) {
    try {
        //Showloader();
        AjaxSubmission(null, "/_Layout/FillPageSizeList", $('input[name=__RequestVerificationToken]').val()).done(function (data) {
            let obj = data;

            if (obj.status == true) {
                if (obj.responsecode == '100')
                    BindDropdown(obj.data.Table, drpid, 'size', 'text', 0);
                else if (obj.responsecode == '604')
                    BindDropdown(null, drpid, 'size', 'text', 1);
            }
            else
                window.location.href = '/ClientLogin/ClientLogin';
            //Hideloader();

        }).fail(function (result) {
            console.log(result.Message);
            //Hideloader();
        });
    }
    catch (e) {
        console.log(e.message);
        //Hideloader();
    }
}


//FUNCTION FOR CHECK UNCHECK ALL CHECKBOXES
function CheckUncheckAllcheckbox() {
    let container = document.getElementById('RightsTbl');
    let ele = container.getElementsByTagName('input');
    if ($("#CheckAll")[0].checked == true) {
        for (i = 0; i < ele.length; i++) {
            if (ele[i].type == 'checkbox')
                $(ele[i]).prop('checked', true);
        }
    }
    else {
        for (i = 0; i < ele.length; i++) {
            if (ele[i].type == 'checkbox')
                $(ele[i]).prop('checked', false);
        }
    }
}

function FillAllUsers(e) {
    try {
        const dataString = {};
        dataString.ReportId = e
        $("#RightsTbl").empty();
        AjaxSubmission(JSON.stringify(dataString), "/Master/CustomReportDesign/FillAllUsers", $('input[name=__RequestVerificationToken]').val()).done(function (result) {
            let obj = result;
            if (obj.status == true) {
                let body = '<thead><tr><td colspan="2"><input type="checkbox" id="CheckAll" class="CheckAll" onclick="CheckUncheckAllcheckbox()"><label>&nbsp;Check All</label></td></tr>';
                body += "<tr><th><span><label>User Name</label></span></th>";
                body += "<th><span><label>View</label></span></th></thead><tbody>";
                for (i = 0; i < obj.data.Table.length; i++) {
                    const Permi = obj.data.Table[i].permission == false ? '' : 'checked="checked"';
                    body += '<tr class="rowdata" id="' + obj.data.Table[i].user_id + '"><td>' + obj.data.Table[i].user_name + '</td>';
                    body += '<td scope="col"><input type="checkbox" ' + Permi + ' class="view" ></td>';
                }
                $('#RightsTbl').append(body + '</tbody>');
            }
        }).fail(function (result) {
            console.log(result.Message);
            //Hideloader();
        });
    }
    catch (e) {
        console.log(e.message);
        //Hideloader();
    }
}

function CheckEmptySearchTableRow() {
    FlagSearchTable = 0;
    FlagSearchTable2 = 0;
    FlagSearchTable3 = 0;
    FlagSearchTable4 = 0;
    $("#SearchReportTables tbody tr").each(function () {
        var LTname, LTcolname, Rtname, Rtcolname, join;
        LTname = $(this).find(".LeftTableName").val().trim();
        LTcolname = $(this).find(".LeftColumnName").val().trim();
        LTAlias = $(this).find(".LeftTableAliasName").val().trim();
        Rtname = $(this).find(".RightTableName").val().trim();
        RtAlias = $(this).find(".RightTableAliasName").val().trim();
        Rtcolname = $(this).find(".RightColumnName").val().trim();
        join = $(this).find(".TableJoin").val();
        if (LTname.length <= 0 || LTcolname.length <= 0 || Rtname.length <= 0 || Rtcolname <= 0 || join <= 0) {
            Toast('Please Fill Blank Row', 'Message', 'error');
            FlagSearchTable = 1;
            return;
        } else {
            if (LTname == Rtname) {
                FlagSearchTable4 = 1;
                return;
            }
        }
    });
    $("#SearchReportTableColumn tbody tr").each(function () {
        var Reportfield;
        Reportfield = $(this).find(".ReportField").val().trim();
        if (Reportfield.length <= 0) {
            FlagSearchTable2 = 1;
            return;
        }
    });
    $("#SearchReportFields tbody tr").each(function () {
        var Reportfield2;
        Reportfield2 = $(this).find(".SearchOnField").val().trim();
        if (Reportfield2.length <= 0) {
            FlagSearchTable3 = 1;
            return;
        }
    });
};
function GenerateSearchReportTableRowNumber() {
    $("#SearchReportTables tbody tr").each(function (ind, ele) {
        $(ele).find('.rn').text(ind + 1);
    });
}
function GenerateSearchReportColumnRowNumber() {
    $("#SearchReportTableColumn tbody tr").each(function (ind, ele) {
        $(ele).find('.rn').text(ind + 1);
    });
}

//*******************************************FIRST TABLE ADD MORE **********************************************//
$("#AddSearchReportTable").click(function () {
    allright = [];
    CheckEmptySearchTableRow();
    if (FlagSearchTable == 1) {
        Toast("Please Fill Blank Rows", "Message", "error");
    }
    else {
        $("#SearchReportTables tbody tr").each(function (ind, ele) {
            if (ind == $("#SearchReportTables tbody tr").length - 1) {
                rtn = $(ele).find('.RightTableName').val();
                rcn = $(ele).find('.RightColumnName').val();
                rta = $(ele).find('.RightTableAliasName').val();
            }
        });
        $("#RemoveSearchReportTables").removeAttr('disabled');
        var tbody = $("#SearchReportTables").find("tbody");
        var FirstTr = $(tbody).find("tr:first");
        var NewRow = $(FirstTr).clone();
        NewRow.find(".HiddenLeftTableId").val(rtn);
        NewRow.find(".LeftTableName").val(rtn);
        NewRow.find(".HiddenLeftTableAliasId").val(rta);
        NewRow.find(".LeftTableAliasName").val(rta);
        NewRow.find(".HiddenLeftColumnId").val(rcn);
        NewRow.find(".LeftColumnName").val(rcn);
        NewRow.find(".TableJoin").val(0);
        NewRow.find(".HiddenRightTableId").val('');
        NewRow.find(".RightTableName").val('');
        NewRow.find(".HiddenRightTableAliasId").val('');
        NewRow.find(".RightTableAliasName").val('');
        NewRow.find(".HiddenRightColumnId").val('');
        NewRow.find(".RightColumnName").val('');
        $("#SearchReportTables").append(NewRow);
        GenerateSearchReportTableRowNumber();
    }
});

//*******************************************SECOND TABLE ADD MORE**********************************************//

$("#AddSearchReportTableColumn").click(function () {
    CheckEmptySearchTableRow();
    if (FlagSearchTable2 == 1) {
        Toast("Please Fill Blank Rows", "Message", "error");
    } else {
        $("#RemoveSearchReportTableColumn").removeAttr('disabled');
        var tbody = $("#SearchReportTableColumn").find("tbody");
        var FirstTr = $(tbody).find("tr:first");
        var NewRow = $(FirstTr).clone();
        NewRow.find(".ReportField").val(' ');
        NewRow.find(".FormulaField").val(' ');
        NewRow.find(".AggregateFunction").val(0);
        NewRow.find(".DisplayName").val(' ');
        NewRow.find(".GroupBy").prop('checked', false);
        NewRow.find(".OrderBy").prop('checked', false);
        NewRow.find(".Criteria").val(' ');
        NewRow.find(".Visible").prop('checked', true);
        NewRow.find(".Function").val(0);
        $("#SearchReportTableColumn").append(NewRow);
        GenerateSearchReportColumnRowNumber();
    }
});

//******************************************THIRD TABLE ADD MORE************************************************//

$("#AddSearchReportFields").click(function () {
    CheckEmptySearchTableRow();
    if (FlagSearchTable3 == 1) {
        Toast("Please Fill Blank Rows", "Message", "error");
    } else {
        $("#RemoveSearchReportFields").removeAttr('disabled');
        var tbody = $("#SearchReportFields").find("tbody");
        var FirstTr = $(tbody).find("tr:first");
        var NewRow = $(FirstTr).clone();
        NewRow.find(".SearchOnField").val(' ');
        NewRow.find(".DisplayName").val(' ');
        NewRow.find(".Parameter").val(' ');
        NewRow.find(".DefaultOperator").val('--select--');
        NewRow.find(".DefaultValue").val('');
        NewRow.find(".AllowNull").prop('checked', false);
        NewRow.find(".OtherDB").prop('checked', false);
        NewRow.find(".ControlType").val('--select--');
        NewRow.find(".ComboValue").val(' ');
        NewRow.find(".rn").text($("#Report_Search_Fields tbody tr").length + 1);
        $("#SearchReportFields").append(NewRow);
    }
});

//******************************************DELETE FUNCTION****************************************************//

$("#DeleteCustomReportTable").click(function () {
    DeleteCustomReport($("#SearchReport").val());
    TabHide();
});

//*****************************************FUNCTION TO DELETE BRANCH*******************************************//

function DeleteCustomReport(e) {
    try {
        $.confirm({
            title: '',
            content: 'Are You Sure Want To Delete ?',
            type: 'red',
            boxWidth: '300px',
            useBootstrap: false,
            columnClass: 'small',
            containerFluid: true,
            typeAnimated: true,
            buttons: {
                tryAgain: {
                    text: 'Confirm',
                    btnClass: 'btn-red',
                    action: function () {
                        const datastring = {};
                        datastring.ReportId = parseInt(e);
                        AjaxSubmission(JSON.stringify(datastring), "/CustomReportDesign/DeleteCustomReport", $('[name="__RequestVerificationToken"]').val()).done(function (data) {
                            let obj = data;
                            if (obj.status == true) {
                                if (obj.responsecode == '102') {
                                    Toast(RetrieveMessage(obj.responsecode), "Message", "success");
                                    TabHide();
                                    ResetData();
                                    CustomReportList(1);
                                    FillAllReport();
                                }
                                else if (obj.responsecode == '602') {
                                    window.location.href = '/ClientLogin/ClientLogin';
                                    TabHide();
                                }
                                else {
                                    Toast(RetrieveMessage(obj.responsecode), "Message", "error");
                                }
                            }
                            else {
                                window.location.href = 'ClientLogin/ClientLogin';
                                TabHide();
                            }
                        }).fail(function (data) {
                            console.log(data.Message);
                        });
                    }
                },
                close: function () {
                }
            }
        });
    }
    catch (e) {
        console.log(e.message);
    }
}

//****************************************FIRST TABLE DELETE FUNCTION*****************************************//

function DeleteSearchReportTables(obj) {
   
   
    $.confirm({
        title: '',
        content: 'Are You Sure Want To Delete ?',
        type: 'red',
        boxWidth: '300px',
        useBootstrap: false,
        columnClass: 'small',
        containerFluid: true,
        typeAnimated: true,
        buttons: {
            tryAgain: {
                text: 'Confirm',
                btnClass: 'btn-red',
                action: function () {
                    drid = $("#SearchReport").val();
                   
                    var rowCount = $("#SearchReportTables tbody tr").length;
                    if (rowCount > 1) {
                        $(obj).parent().parent().remove();
                        GenerateSearchReportTableRowNumber();
                    }
                    else {
                        $("#RemoveSearchReportTables").attr("disabled", "disabled");
                    }
                    AllTable();
                    if (drid != null && drid != 0)
                        $("#Update_CustomReportTable").trigger('click');

                }
            },
            close: function () {
            }
        }
    });
}
function RemoveAutoChangeReportField(T1, T2) {
    $("#SearchReportTableColumn tbody tr").each(function (ind, ele) {
        if ($(ele).find('.ReportField').val().split(".")[0].indexOf(T1) > -1 || $(ele).find('.ReportField').val().split(".")[0].indexOf(T2) > -1) {
            if ($("#SearchReportTableColumn tbody tr").length > 1) {
                $(ele).remove();
            } else {
                $(ele).find('.ReportField').val('');
                $(ele).find('.FormulaField').val('');
                $(ele).find('.AggregateFunction').val('0');
                $(ele).find('.DisplayName').val('');
                $(ele).find('.GroupBy').prop('checked', false);
                $(ele).find('.OrderBy').prop('checked', false);
                $(ele).find('.Criteria').val('');
                $(ele).find('.Visible').prop('checked', true);
                $(ele).find('.Function').val('0');
            }
        }
        GenerateSearchReportColumnRowNumber();
    });
}

//*****************************************SECOND TABLE DELETE FUNCTION***************************************// 
function DeleteSearchReportTableColumn(obj) {
    var rowCount = $("#SearchReportTableColumn tbody tr").length;
    if (rowCount > 1) {
        $(obj).parent().parent().remove();
        GenerateSearchReportColumnRowNumber();
    }
    else {
        $(obj).parent().parent()
        $("#RemoveSearchReportTableColumn").attr("disabled", "disabled");
    }
}
//****************************************THIRD TABLE DELETE FUNCTION ***************************************//
function DeleteSearchReportFields(obj) {
    var rowCount = $("#SearchReportFields tbody tr").length;
    if (rowCount > 1) {
        $(obj).parent().parent().remove();
        $("#SearchReportFields tbody tr").each(function (ind, ele) {
            $(ele).find('.rn').text(ind + 1);
        })
    }
    else {
        $("#RemoveSearchReportFields").attr("disabled", "disabled");
    }
}
//*****************************************AUTOCOMPLETE FUNCTION **********************************************//

function FillAllReport() {
    try {
        AjaxSubmission(null, "/Master/CustomReportDesign/GetAllReport", $('input[name=__RequestVerificationToken]').val()).done(function (result) {
            let obj = result;
            if (obj.status == true) {
                if (obj.responsecode == '100') {
                    BindDropdown(obj.data.Table, 'SearchReport', 'Report_Id', 'Report_Name', '-----Select-----');
                }
                else if (obj.responsecode == '604') {
                    BindDropdown(null, 'SearchReport', 'Report_Id', 'Report_Name', '-----Select-----');
                }
                else {
                    Toast(RetrieveMessage(obj.responsecode), "Message", "error");
                }
                if (drid != '') {
                    $("#SearchReport").val(drid);
                }
            }
            else {
                window.location.href = '/ClientLogin/ClientLogin';
            }
            //Hideloader();
        }).fail(function (result) {
            console.log(result.Message);
            //Hideloader();
        });
    }
    catch (e) {
        console.log(e.message);
        //Hideloader();
    }
}

function FillAllTablesNames() {
    try {
        //Showloader();
        AjaxSubmission(null, "/Master/CustomReportDesign/FillTableName", $('input[name=__RequestVerificationToken]').val()).done(function (result) {
            let obj = result;
            if (obj.status == true) {
                if (obj.responsecode == '100') {
                    BindDropdown(obj.data.Table, 'LeftTableName', 'NAME', 'table_name', '-----Select-----');
                    BindDropdown(obj.data.Table, 'RightTableName', 'NAME', 'table_name', '-----Select-----');
                }
                else if (obj.responsecode == '604') {
                    BindDropdown(null, 'LeftTableName', 'NAME', 'table_name', '-----Select-----');
                    BindDropdown(obj.data.Table, 'RightTableName', 'NAME', 'table_name', '-----Select-----');
                }
                else {
                    Toast(RetrieveMessage(obj.responsecode), "Message", "error");
                }
            }
            else {
                window.location.href = '/ClientLogin/ClientLogin';
            }
            //Hideloader();
            ResetData();
        }).fail(function (result) {
            console.log(result.Message);
            //Hideloader();
        });
    }
    catch (e) {
        console.log(e.message);
        //Hideloader();
    }
}

//*****************************************ADD NEW REPORT******************************************************//

$("#NewReportCustomReportTable").click(function () {
    ResetData();
    TabHide2();
});


//*****************************************UPDATE FORM ********************************************************//
var mych = 0;
var mych2 = 0;
var Rtable;
var Rcolumn;
var RAlias;
var Ltable;
var Lcolumn;
var LAlias;
var MyNewtable = new Array();
var mySecondTable = new Array();

function AllTable() {
    debugger;
    mych2 = 0;
    var All = new Array();
    var Alltable = new Array();
    $("#SearchReportTables tbody tr").each(function (ind, ele) {
        if (ind == 0) {
            All.push($(ele).find('.LeftTableAliasName').val());
            All.push($(ele).find('.LeftTableName').val());
            if (All.includes($(ele).find('.RightTableAliasName').val()) == false || All.includes($(ele).find('.RightTableName').val()) == false || All.includes($(ele).find('.RightTableAliasName').val().trim().length) == 0) {
                All.push($(ele).find('.RightTableName').val());
                All.push($(ele).find('.RightTableAliasName').val());
            }
            else {
                mych2 = 0;
                return false;
            }
        }
        else {
            if (All.includes($(ele).find('.LeftTableAliasName').val()) == false || All.includes($(ele).find('.LeftTableName').val()) == false || All.includes($(ele).find('.LeftTableAliasName').val().trim().length) == 0) {
                All.push($(ele).find('.LeftTableAliasName').val());
                All.push($(ele).find('.LeftTableName').val());
            }
            else {
                mych2 = 0;
                return false;
            }
            if (All.includes($(ele).find('.RightTableAliasName').val()) == false || All.includes($(ele).find('.RightTableName').val()) == false || All.includes($(ele).find('.RightTableAliasName').val().trim().length) == 0) {
                All.push($(ele).find('.RightTableAliasName').val());
                All.push($(ele).find('.RightTableName').val());
            }
            else {
                mych2 = 0;
                return false;
            }
        }
    });
    if (mych2 == 0) {
        $("#SearchReportTableColumn tbody tr").each(function (ind, ele) {
            if ($(ele).find('.ReportField').val().length > 0) {
                for (i = 0; i < All.length; i++) {
                    if ($(ele).find('.ReportField').val().split(".")[0] == All[i] || $(ele).find('.ReportField').val() == "---formula---") {
                        mych2 = 0
                        return;
                    } else {
                        mych2 = 1;
                    }
                }
                if (mych2 == 1) {
                    mych2 = 0;
                    if ($("#SearchReportTableColumn tbody tr").length > 1) {
                        $(ele).remove();
                    }
                    else {
                        $(ele).find('.ReportField').val('');
                        $(ele).find('.FormulaField').val('');
                        $(ele).find('.AggregateFunction').val('0');
                        $(ele).find('.DisplayName').val('');
                        $(ele).find('.GroupBy').prop('checked', false);
                        $(ele).find('.OrderBy').prop('checked', false);
                        $(ele).find('.Criteria').val('');
                        $(ele).find('.Visible').prop('checked', true);
                        $(ele).find('.Function').val('0');
                    }
                }
            }
        });
        $("#SearchReportFields tbody tr").each(function (ind, ele) {
            if ($(ele).find('.SearchOnField').val().length > 0) {
                for (i = 0; i < All.length; i++) {
                    if ($(ele).find('.SearchOnField').val().split(".")[0] == All[i]) {
                        mych2 = 0
                        return;
                    } else {
                        mych2 = 1;
                    }
                }
                if (mych2 == 1) {
                    mych2 = 0;
                    if ($("#SearchReportFields tbody tr").length > 1) {
                        $(ele).remove();
                    }
                    else {
                        $(ele).find('.SearchOnField').val('');
                        $(ele).find('.DisplayName').val('');
                        $(ele).find('.Parameter').val('');
                        $(ele).find('.DefaultOperator').val('0');
                        $(ele).find('.DefaultValue').val('');
                        $(ele).find('.AllowNull').prop('checked', false);
                        $(ele).find('.OtherDB').prop('checked', false);
                        $(ele).find('.ControlType').val('0');
                        $(ele).find('.ComboValue').val('');
                    }
                }
            }
        });
    }
}

function UpdateForm() {
    try {
        debugger;
        var flag = 0;
        AllTable();
        if (mych2 == 0) {
            //Showloader();
            const datastring = {};
            var SearchTableData = new Array();
            var ReportTableData = new Array();
            var SearchFieldData = new Array();
            $("#SearchReportTableColumn tbody tr").each(function (ind, ele) {
                var TblData2 = {};
                if ($('#SearchReportTableColumn tbody tr').length == 1) {
                    if ($(ele).find('.ReportField').val().trim().length > 0) {
                        if ($(ele).find('.GroupBy').is(':checked') == true) {
                            if ($(ele).find('.AggregateFunction').val() != 0) {
                                flag = 1;
                                Toast('Group by cannot come with Aggregate Function', 'Message', 'error');
                                return false;
                            }
                        }
                        if ($(ele).find('.Function').val() != "0") {
                            if ($(ele).find('.Criteria').val().trim().length == 0) {
                                flag = 1;
                                Toast('Criteria Required', 'Message', 'error');
                                return false;
                            }
                        }
                        TblData2.FieldName = $(this).find(".ReportField").val().trim();
                        TblData2.Data_Type = $(this).find(".HiddenReportFieldDtype").val();
                        TblData2.FieldFormula = $(this).find(".FormulaField").val().trim();
                        TblData2.FunctionName = $(this).find(".AggregateFunction").val();
                        TblData2.DisplayName = $(this).find(".DisplayName").val().trim();
                        TblData2.GroupBy = $(this).find(".GroupBy").is(":checked");
                        TblData2.OrderBy = $(this).find(".OrderBy").is(":checked");
                        TblData2.Criteria = $(this).find(".Criteria").val().trim();
                        TblData2.VisibleField = $(this).find(".Visible").is(":checked");
                        TblData2.GrandTotal = $(this).find(".Function").val();
                        ReportTableData.push(TblData2);
                    }
                }
                else {
                    if ($(ele).find('.ReportField').val().trim().length <= 0) {
                        Toast('Report Field Required', 'Message', 'error');
                        flag = 1;
                        return;
                    }
                    else {
                        if ($(ele).find('.Function').val() != "0") {
                            if ($(ele).find('.Criteria').val().trim().length == 0) {
                                flag = 1;
                                Toast('Criteria Required', 'Message', 'error');
                                return false;
                            }
                        }
                        TblData2.FieldName = $(this).find(".ReportField").val().trim();
                        TblData2.Data_Type = $(this).find(".HiddenReportFieldDtype").val();
                        TblData2.FieldFormula = $(this).find(".FormulaField").val().trim();
                        TblData2.FunctionName = $(this).find(".AggregateFunction").val();
                        TblData2.DisplayName = $(this).find(".DisplayName").val().trim();
                        TblData2.GroupBy = $(this).find(".GroupBy").is(":checked");
                        TblData2.OrderBy = $(this).find(".OrderBy").is(":checked");
                        TblData2.Criteria = $(this).find(".Criteria").val().trim();
                        TblData2.VisibleField = $(this).find(".Visible").is(":checked");
                        TblData2.GrandTotal = $(this).find(".Function").val();
                        ReportTableData.push(TblData2);
                    }
                }
            });
            $("#SearchReportFields tbody tr").each(function (ind, ele) {
                var TblData3 = {};
                if ($('#SearchReportFields tbody tr').length == 1) {
                    if ($(this).find(".SearchOnField").val().trim().length > 0) {
                        if ($(this).find(".DisplayName").val().trim().length > 0) {
                            if ($(this).find(".ControlType").val() != null) {
                                TblData3.SearchField = $(this).find(".SearchOnField").val().trim();
                                TblData3.Data_Type = $(this).find(".HiddenSearchOnFieldDtype").val();
                                TblData3.DisplayField = $(this).find(".DisplayName").val().trim();
                                TblData3.Parameter = $(this).find(".Parameter").val().trim();
                                TblData3.DefaultOperator = $(this).find(".DefaultOperator").val();
                                TblData3.DefaultValue = $(this).find(".DefaultValue").val().trim();
                                TblData3.AllowNull = $(this).find(".AllowNull").is(":checked");
                                TblData3.OtherDB = $(this).find(".OtherDB").is(":checked");
                                TblData3.ControlType = $(this).find(".ControlType").val();
                                TblData3.ComboValue = $(this).find(".ComboValue").val().trim();
                                SearchFieldData.push(TblData3);
                            }
                            else {
                                flag = 1;
                                Toast('Control Type Required in row number:-' + (ind + 1) + '', 'Message', 'error');
                                return;
                            }
                        }
                        else {
                            flag = 1;
                            Toast('Display Name Required in row number:-' + (ind + 1) + '', 'Message', 'error');
                            return;
                        }
                    }
                }
                else {
                    if ($(this).find(".SearchOnField").val().trim().length > 0) {
                        if ($(this).find(".DisplayName").val().trim().length > 0) {
                            if ($(this).find(".ControlType").val() != null) {
                                TblData3.SearchField = $(this).find(".SearchOnField").val().trim();
                                TblData3.Data_Type = $(this).find(".HiddenSearchOnFieldDtype").val();
                                TblData3.DisplayField = $(this).find(".DisplayName").val().trim();
                                TblData3.Parameter = $(this).find(".Parameter").val().trim();
                                TblData3.DefaultOperator = $(this).find(".DefaultOperator").val();
                                TblData3.DefaultValue = $(this).find(".DefaultValue").val().trim();
                                TblData3.AllowNull = $(this).find(".AllowNull").is(":checked");
                                TblData3.OtherDB = $(this).find(".OtherDB").is(":checked");
                                TblData3.ControlType = $(this).find(".ControlType").val();
                                TblData3.ComboValue = $(this).find(".ComboValue").val().trim();
                                SearchFieldData.push(TblData3);
                            }
                            else {
                                flag = 1;
                                Toast('Control Type Required in row number:-' + (ind + 1) + '', 'Message', 'error');
                                return
                            }
                        }
                        else {
                            flag = 1;
                            Toast('Display Name Required in row number:-' + (ind + 1) + '', 'Message', 'error');
                            return;
                        }
                    }
                }
            });
            if (flag == 0) {
                $("#SearchReportTables tbody tr").each(function () {
                    var TblData = {};
                    TblData.LeftTableName = $(this).find(".LeftTableName").val().trim();
                    TblData.LeftColumnDataType = $(this).find(".HiddenLeftColumnDtype").val();
                    TblData.LeftTableAlias = $(this).find(".LeftTableAliasName").val().trim();
                    TblData.LeftColumnName = $(this).find(".LeftColumnName").val().trim();
                    TblData.Join = $(this).find(".TableJoin").val();
                    TblData.RightTableName = $(this).find(".RightTableName").val().trim();
                    TblData.RightTableAlias = $(this).find(".RightTableAliasName").val().trim();
                    TblData.RightColumnDataType = $(this).find(".HiddenRightColumnDtype").val();
                    TblData.RightColumnName = $(this).find(".RightColumnName").val().trim();
                    SearchTableData.push(TblData);
                })
                var UserRightsData = new Array();
                $('#RightsTbl .rowdata').each(function () {
                    var UserRight = {};
                    UserRight.ReportId = $("#SearchReport").val();
                    UserRight.UserId = $(this).closest('tr').attr('id');
                    UserRight.View = $(this).find('td:nth-child(2) input:checkbox').is(':checked');
                    UserRightsData.push(UserRight);
                });
                datastring.ReportUserRightsModel = UserRightsData;
                datastring.customReportDesignModels = SearchTableData;
                datastring.ReportColumnModel = ReportTableData;
                datastring.ReportSearchFieldModel = SearchFieldData;
                datastring.SearchReportName = $("#SearchReport").val();
                datastring.ReportName = $("#ReportsName").val();
                datastring.RDLC_ReportName = $("#RDLCReportsName").val();
                datastring.Reporttable = $("#CopyReport").val();
                datastring.AllowExportToExcel = $("#AllowExportToExcel").is(":checked");
                datastring.AppReport = $("#AppReport").is(":checked");
                datastring.CustomQuery = $("#CustomQuery").is(":checked");
                datastring.Status = $("#ReportVisible").val();
                datastring.Query = $("#ReportQuery").val().trim();
                datastring.PageSelect = $("#ddlPageSize2").val();
                AjaxSubmission(JSON.stringify(datastring), "/Master/CustomReportDesign/UpdateForm", $('[name="__RequestVerificationToken"]').val()).done(function (result) {
                    let obj = result;
                    if (obj.status == true) {
                        if (obj.responsecode == '107') {
                            drid = $("#SearchReport").val();
                            Toast(RetrieveMessage(obj.responsecode), "Message", "success");
                            EditForm(drid);
                            CustomReportList(1);
                            FillAllReport();
                            TabHide3();
                        }
                        else {
                            Toast(RetrieveMessage(obj.responsecode), "Message", "error");
                        }
                    }
                    else {
                        window.location.href = '/ClientLogin/ClientLogin';
                    }
                    //Hideloader();
                }).fail(function (result) {
                    console.log(result.Message);
                    //Hideloader();
                });
            }
            else {
                //Hideloader();
            }
        }
        else {
            if (mych2 == 0) {
                return false;
            }
        }
    }
    catch (ex) {
        //Hideloader();
        console.log(ex.message);
    }
}
$("#Update_CustomReportTable").click(function () {
    if ($("#ReportsName").val().trim().length <= 0) {
        debugger;
        flag = 1;
        Toast('Report Name Required', 'Message', 'Error');
    } else {
        debugger;
        CheckEmptySearchTableRow();
        if (FlagSearchTable == 0) {
            if (FlagSearchTable4 == 1) {
                Toast('Left And Right table Should not be same', 'Message', 'error');
            } else {
                debugger;
                UpdateForm();
            }
        } else {
            if (FlagSearchTable == 1) {
                debugger;
                Toast('Please Fill Blank Row', 'Message', 'error');
            }
        }
    }
});


//*****************************************EDIT FORM **********************************************************//

function EditForm(e, ch) {
    try {
        const datastring = {};
        datastring.ReportId = e;
        AjaxSubmission(JSON.stringify(datastring), "/Master/CustomReportDesign/EditForm", $('[name="__RequestVerificationToken"]').val()).done(function (data) {
            let obj = data;
            if (obj.status == true) {
                if (obj.responsecode == '100') {
                    FillAllUsers(e);
                    ResetData();
                    TabShow(ch);

                    $("#SearchReport").val(obj.data.Table[0].Report_Id);
                    $("#ddlPageSize2").val(obj.data.Table[0].page_select);
                    $("#ReportsName").val(obj.data.Table[0].Report_Name);
                    $("#RDLCReportsName").val(obj.data.Table[0].RDLC_Report);

                    if (obj.data.Table[0].Status == true)
                        $("#ReportVisible").val(1).trigger('change');
                    else
                        $("#ReportVisible").val(0).trigger('change');


                    if (obj.data.Table[0].Allow_Export == true)
                        $("#AllowExportToExcel").prop("checked", true);
                    else
                        $("#AllowExportToExcel").prop("checked", false);
                    if (obj.data.Table[0].App_report == true)
                        $("#AppReport").prop("checked", true);
                    else
                        $("#AppReport").prop("checked", false);
                    if (obj.data.Table[0].Custom_Query == true) {
                        $("#CustomQuery").prop('checked', true);
                        $("#ReportQuery").removeAttr('disabled');
                    }
                    else {
                        $("#CustomQuery").prop('checked', false);
                        $("#ReportQuery").attr("disabled", "disabled");
                    }
                    $("#RemoveSearchReportTables").removeAttr('disabled');
                    $("#ReportQuery").val(obj.data.Table[0].Report_Query);
                    var CustomreportList = obj.data.Table1;
                    var firstChild = $("#SearchReportTables").find("tbody tr:first-child");
                    $.each(CustomreportList, function (index, ele) {
                        if (index == 0) {
                            firstChild.find('.rn').text('1');
                            firstChild.find('.LeftTableName').val(ele.Left_Table_Name);
                            firstChild.find('.LeftTableAliasName').val(ele.Left_Table_Alias);
                            firstChild.find('.LeftColumnName').val(ele.Left_Column_Name);
                            firstChild.find('.RightTableName').val(ele.Right_Table_Name);
                            firstChild.find('.RightTableAliasName').val(ele.Right_Table_Alias);
                            firstChild.find('.RightColumnName').val(ele.Right_Column_Name);


                            firstChild.find('.HiddenLeftTableId').val(ele.Left_Table_Name);
                            firstChild.find('.HiddenLeftTableAliasId').val(ele.Left_Table_Alias);
                            firstChild.find('.HiddenLeftColumnId').val(ele.Left_Column_Name);
                            firstChild.find('.HiddenLeftColumnDtype').val(ele.LeftColumnDataType);
                            firstChild.find('.HiddenRightTableId').val(ele.Right_Table_Name);
                            firstChild.find('.HiddenRightTableAliasId').val(ele.Right_Table_Alias);
                            firstChild.find('.HiddenRightColumnId').val(ele.Right_Column_Name);
                            firstChild.find('.HiddenRightColumnDtype').val(ele.RightColumnDataType);
                            firstChild.find('.TableJoin').val(ele.Join_Name);
                        }
                        else {
                            var cloneChild = firstChild.clone();
                            cloneChild.find('.rn').text(index + 1);
                            cloneChild.find('.LeftTableName').val(ele.Left_Table_Name);
                            cloneChild.find('.LeftTableAliasName').val(ele.Left_Table_Alias);
                            cloneChild.find('.LeftColumnName').val(ele.Left_Column_Name);
                            cloneChild.find('.RightTableName').val(ele.Right_Table_Name);
                            cloneChild.find('.RightTableAliasName').val(ele.Right_Table_Alias);
                            cloneChild.find('.RightColumnName').val(ele.Right_Column_Name);

                            cloneChild.find('.HiddenLeftTableId').val(ele.Left_Table_Name);
                            cloneChild.find('.HiddenLeftTableAliasId').val(ele.Left_Table_Alias);
                            cloneChild.find('.HiddenLeftColumnId').val(ele.Left_Column_Name);
                            cloneChild.find('.HiddenLeftColumnDtype').val(ele.LeftColumnDataType);
                            cloneChild.find('.HiddenRightTableId').val(ele.Right_Table_Name);
                            cloneChild.find('.HiddenRightTableAliasId').val(ele.Right_Table_Alias);
                            cloneChild.find('.HiddenRightColumnId').val(ele.Right_Column_Name);
                            cloneChild.find('.HiddenRightColumnDtype').val(ele.RightColumnDataType);
                            cloneChild.find('.TableJoin').val(ele.Join_Name);
                            $("#SearchReportTables tbody").append(cloneChild);
                        }
                    });
                    var CustomreportSearchFieldList = obj.data.Table3;
                    var firstChild = $("#SearchReportFields").find("tbody tr:first-child");
                    $.each(CustomreportSearchFieldList, function (index, ele) {
                        if (index == 0) {
                            firstChild.find('.rn').text('1');
                            firstChild.find('.SearchOnField').val(ele.Search_Field);
                            firstChild.find('.HiddenSearchOnFieldDtype').val(ele.Data_Type);
                            firstChild.find('.DisplayName').val(ele.Display_Field);
                            firstChild.find('.Parameter').val(ele.Parameter);
                            firstChild.find('.DefaultOperator').val(ele.Default_Operator);
                            firstChild.find('.DefaultValue').val(ele.Default_Value);
                            firstChild.find('.AllowNull').prop('checked', ele.Allow_Null);
                            firstChild.find('.OtherDB').prop('checked', ele.By_Other_Db);
                            firstChild.find('.ControlType').val(ele.Control_Type);
                            firstChild.find('.ComboValue').val(ele.Combo_Value);
                            firstChild.find('.HiddenReportFieldId').val(ele.Search_Field);
                        }
                        else {
                            var cloneChild = firstChild.clone();
                            cloneChild.find('.rn').text(index + 1);
                            cloneChild.find('.SearchOnField').val('');
                            cloneChild.find('.DisplayName').val('');
                            cloneChild.find('.Parameter').val('');
                            cloneChild.find('.DisplayName').val('');
                            cloneChild.find('.DefaultOperator').val('');
                            cloneChild.find('.DefaultValue').val('');
                            cloneChild.find('.AllowNull').prop('checked', false);
                            cloneChild.find('.OtherDB').prop('checked', false);
                            cloneChild.find('.ControlType').val('');
                            cloneChild.find('.ComboValue').val('');
                            cloneChild.find('.HiddenReportFieldId').val('');
                            cloneChild.find('.HiddenSearchOnFieldDtype').val('');

                            cloneChild.find('.SearchOnField').val(ele.Search_Field);
                            cloneChild.find('.DisplayName').val(ele.Display_Field);
                            cloneChild.find('.Parameter').val(ele.Parameter);
                            cloneChild.find('.DefaultOperator').val(ele.Default_Operator);
                            cloneChild.find('.DefaultValue').val(ele.Default_Value);
                            cloneChild.find('.AllowNull').prop('checked', ele.Allow_Null);
                            cloneChild.find('.OtherDB').prop('checked', ele.By_Other_Db);
                            cloneChild.find('.ControlType').val(ele.Control_Type);
                            cloneChild.find('.ComboValue').val(ele.Combo_Value);
                            cloneChild.find('.HiddenReportFieldId').val(ele.Search_Field);
                            cloneChild.find('.HiddenSearchOnFieldDtype').val(ele.Data_Type);
                            $("#SearchReportFields tbody").append(cloneChild)
                        }
                    });
                    var CustomreportColumnList = obj.data.Table2;
                    var firstChild = $("#SearchReportTableColumn").find("tbody tr:first-child");
                    $.each(CustomreportColumnList, function (index, ele) {
                        if (index == 0) {
                            firstChild.find('.rn').text('1');
                            firstChild.find('.ReportField').val(ele.Field_Name);
                            firstChild.find('.FormulaField').val(ele.Field_Formula);
                            firstChild.find('.AggregateFunction').val(ele.Function_Name);
                            firstChild.find('.DisplayName').val(ele.Display_Name);
                            firstChild.find('.GroupBy').prop('checked', ele.Group_By);
                            firstChild.find('.OrderBy').prop('checked', ele.Order_By);
                            firstChild.find('.Criteria').val(ele.Criteria);
                            firstChild.find('.Visible').prop('checked', ele.Visible_Field);
                            firstChild.find('.Function').val(ele.Grand_Total);
                            firstChild.find('.HiddenReportFieldId').val(ele.Left_Table_Name);
                            firstChild.find('.HiddenReportFieldDtype').val(ele.Data_Type);
                        }
                        else {
                            var cloneChild = firstChild.clone();
                            cloneChild.find('.rn').text(index + 1);
                            cloneChild.find('.ReportField').val('');
                            cloneChild.find('.FormulaField').val('');
                            cloneChild.find('.AggregateFunction').val('');
                            cloneChild.find('.DisplayName').val('');
                            cloneChild.find('.GroupBy').prop('checked', false);
                            cloneChild.find('.OrderBy').prop('checked', false);
                            cloneChild.find('.Criteria').val('');
                            cloneChild.find('.Visible').prop('checked', true);
                            cloneChild.find('.Function').val('');
                            cloneChild.find('.HiddenReportFieldId').val('');
                            cloneChild.find('.HiddenReportFieldDtype').val('');

                            cloneChild.find('.ReportField').val(ele.Field_Name);
                            cloneChild.find('.FormulaField').val(ele.Field_Formula);
                            cloneChild.find('.AggregateFunction').val(ele.Function_Name);
                            cloneChild.find('.DisplayName').val(ele.Display_Name);
                            cloneChild.find('.GroupBy').prop('checked', ele.Group_By);
                            cloneChild.find('.OrderBy').prop('checked', ele.Order_By);
                            cloneChild.find('.Criteria').val(ele.Criteria);
                            cloneChild.find('.Visible').prop('checked', ele.Visible_Field);
                            cloneChild.find('.Function').val(ele.Grand_Total);
                            cloneChild.find('.HiddenReportFieldId').val(ele.Left_Table_Name);
                            cloneChild.find('.HiddenReportFieldDtype').val(ele.Data_Type);
                            $("#SearchReportTableColumn tbody").append(cloneChild)
                        }
                    });
                }
                else {
                    Toast(RetrieveMessage(obj.responsecode), "Message", "error");
                }
            }
            else {
                window.location.href = '/ClientLogin/ClientLogin';
            }
        }).fail(function (data) {
            console.log(data.Message);
        });
    }
    catch (e) {
        console.log(e.message);
    }
}


//*****************************************ADD FORM ***********************************************************//

function AddForm() {
    try {
        var flag = 0;
        var myfl = 0;
        AllTable();
        var All = [];
        //$("#SearchReportTables tbody tr").each(function (ind, ele) {
        //    if (ind == 0) {
        //        alert("me");
        //        All.push($(ele).find('.LeftTableAliasName').val());
        //        All.push($(ele).find('.LeftTableName').val());
        //        alert("dferh");
        //        if (All.includes($(ele).find('.RightTableAliasName').val()) == false || All.includes($(ele).find('.RightTableName').val()) == false || All.includes($(ele).find('.RightTableAliasName').val()) == Null) {
        //            All.push($(ele).find('.RightTableAliasName').val());
        //            All.push($(ele).find('.RightTableName').val());
        //        } else {
        //            myfl = 0;
        //        }
        //    } else {

        //        if (All.includes($(ele).find('.LeftTableAliasName').val()) == false || All.includes($(ele).find('.LeftTableName').val()) == false || All.includes($(ele).find('.LeftTableAliasName').val()) == Null) {
        //            All.push($(ele).find('.LeftTableAliasName').val());
        //            All.push($(ele).find('.LeftTableName').val());
        //        }
        //        else {
        //            alert("pass");
        //            myfl = 0;
        //        }
        //        if (All.includes($(ele).find('.RightTableAliasName').val()) == false || All.includes($(ele).find('.RightTableName').val()) == false || All.includes($(ele).find('.RightTableAliasName').val()) == Null) {
        //            All.push($(ele).find('.RightTableAliasName').val());
        //            All.push($(ele).find('.RightTableName').val());
        //        }
        //        else {
        //            myfl = 0;
        //        }
        //    }
        //});
        if (myfl == 0) {
            const datastring = {};
            var SearchTableData = new Array();
            var ReportTableData = new Array();
            $("#SearchReportTables tbody tr").each(function () {
                flag = 0;
                var LTname, LTcolname, Rtname, Rtcolname, join;
                LTname = $(this).find(".LeftTableName").val();
                LTcolname = $(this).find(".LeftColumnName").val();
                Rtname = $(this).find(".RightTableName").val();
                Rtcolname = $(this).find(".RightColumnName").val();
                join = $(this).find(".TableJoin").val();
                if (join > 0) {
                    if (LTname.length <= 0) {
                        flag = 1;
                        Toast("Left Table Required", "Message", "error");
                    }
                    else {
                        if (LTcolname.length <= 0) {
                            flag = 1;
                            Toast("Left Table Column Name Required", "Message", "error");
                        } else {
                            if (Rtname.length <= 0) {
                                flag = 1;
                                Toast("Right Table Required", "Message", "error");
                            } else {
                                if (Rtcolname.length <= 0) {
                                    flag = 1;
                                    Toast("Right Table Column Name Required", "Message", "error");
                                }
                                else {
                                    if (LTname == Rtname) {
                                        flag = 1;
                                        Toast("Left Table And Right Table Should be Diffrent", "Message", "error");
                                    }
                                }
                            }
                        }
                    }
                }
                else if (LTname.length > 0 || Rtname.length > 0) {
                    flag = 1;
                    Toast('Join is Required', 'Message', 'Error');
                }
                //Hideloader();
            });
            $("#SearchReportTableColumn tbody tr").each(function () {
                var TblData2 = {};
                TblData2.FieldName = $(this).find(".ReportField").val().trim();
                TblData2.Data_Type = $(this).find(".HiddenReportFieldDtype").val().trim();
                TblData2.FieldFormula = $(this).find(".FormulaField").val().trim();
                TblData2.FunctionName = $(this).find(".AggregateFunction").val();
                TblData2.DisplayName = $(this).find(".DisplayName").val().trim();
                TblData2.GroupBy = $(this).find(".GroupBy").is(":checked");
                TblData2.OrderBy = $(this).find(".OrderBy").is(":checked");
                TblData2.Criteria = $(this).find(".Criteria").val().trim();
                TblData2.VisibleField = $(this).find(".Visible").is(":checked");
                TblData2.GrandTotal = $(this).find(".Function").val();
                ReportTableData.push(TblData2);
            })
            if (flag == 0) {
                $("#SearchReportTables tbody tr").each(function () {
                    var TblData = {};
                    TblData.LeftTableName = $(this).find(".LeftTableName").val().trim();
                    TblData.LeftColumnDataType = $(this).find(".HiddenLeftColumnDtype").val();
                    TblData.LeftTableAlias = $(this).find(".LeftTableAliasName").val().trim();
                    TblData.LeftColumnName = $(this).find(".LeftColumnName").val().trim();
                    TblData.Join = $(this).find(".TableJoin").val();
                    TblData.RightTableName = $(this).find(".RightTableName").val().trim();
                    TblData.RightColumnDataType = $(this).find(".HiddenRightColumnDtype").val();
                    TblData.RightTableAlias = $(this).find(".RightTableAliasName").val().trim();
                    TblData.RightColumnName = $(this).find(".RightColumnName").val().trim();
                    SearchTableData.push(TblData);
                })
                datastring.customReportDesignModels = SearchTableData;
                datastring.ReportColumnModel = ReportTableData;
                datastring.SearchReportName = $("#SearchReport").val();
                datastring.PageSelect = $("#ddlPageSize2").val();
                datastring.ReportName = $("#ReportsName").val();
                datastring.RDLC_ReportName = $("#RDLCReportsName").val();
                datastring.Reporttable = $("#CopyReport").val();
                datastring.AllowExportToExcel = $("#AllowExportToExcel").is(":checked");
                datastring.AppReport = $("#AppReport").is(":checked");
                datastring.CustomQuery = $("#CustomQuery").is(":checked");
                datastring.Query = $("#ReportQuery").val().trim();
                datastring.Status = $("#ReportVisible").val();

                AjaxSubmission(JSON.stringify(datastring), "/Master/CustomReportDesign/AddForm", $('[name="__RequestVerificationToken"]').val()).done(function (result) {
                    let obj = result;
                    if (obj.status == true) {
                        if (obj.responsecode == '101') {
                            drid = obj.data.Table[0].current_id;
                            Toast(RetrieveMessage(obj.responsecode), "Message", "success");
                            EditForm(drid);
                            TabHide3();
                            FillAllReport();
                        }
                        else {
                            Toast(RetrieveMessage(obj.responsecode), "Message", "error");
                        }
                    }
                    else {
                        window.location.href = '/ClientLogin/ClientLogin';
                    }
                    //Hideloader();
                }).fail(function (result) {
                    console.log(result.Message);
                    //Hideloader();
                });
            }
            else {
                //Hideloader();
            }
        }
        else {
            if (mych2 == 0) {
                0
                return false;
            }
        }
    }
    catch (ex) {
        //Hideloader();
        console.log(ex.message);
    }
}
$("#AddCustomReportTable").click(function () {
    if ($("#ReportsName").val().trim().length <= 0) {
        flag = 1;
        Toast('Report Name is Required', 'Message', 'Error');
    } else {
        CheckEmptySearchTableRow();
        if (FlagSearchTable == 0) {
            if (FlagSearchTable4 == 1) {
                Toast('Left And Right table Should not be same', 'Message', 'error');
            }
            else {
                AddForm();
            }
        } else {
            if (FlagSearchTable == 1) {
                Toast('Please Fill Blank Row', 'Message', 'error');
            }
        }
    }
});

//*****************************************CUSTOM QUERY********************************************************//

$("#CustomQuery").click(function () {
    if ($("#CustomQuery").is(':checked') == true) {
        $("#ReportQuery").removeAttr("disabled");
    }
    else {
        $("#ReportQuery").attr("disabled", "disabled");
    }
});
$("#SearchReport").change(function () {
    if ($("#SearchReport").val() != '0') {
        EditForm($("#SearchReport").val());
    }
    else {
        ResetData();
        TabHide2();
    }
});

//******************************************BIND TABLE*********************************************************//

function BindCustomReportTable(result, serial_no) {
    $("#tbl_Custom_report tbody tr").remove();
    if (result.length == 0) {
        tr = $('<tr/>');
        tr.append("<td class='text-center' colspan='8'>no results found</td>");
        $("#tbl_Custom_report tbody").append(tr);
    }
    else {
        for (i = 0; i < result.length; i++) {

            if (result[i].status == "Active")
                tr = $('<tr/>');
            else
                tr = $('<tr style="background-color:#fdd2d2;"/>');

            tr.append("<td style='text-align:center;'>" + serial_no + "</td>");
            tr.append("<td style='text-align:center;'>" + result[i].Report_Id + "</td>");
            tr.append("<td class='text-center'><a href='javascript:void(0)' class='text-decoration-none ' style='color: black !important;' onclick='EditForm(\"" + result[i].Report_Id + "\"," + 1 + ");'>" + result[i].Report_Name + "</a></td>");
            tr.append("<td class='text-center'>" + result[i].status + "</td>");
            tr.append("<td class='text-center'><button type='button' onclick='EditForm(\"" + result[i].Report_Id + "\"," + 1 + ");' class='common-btn common-btn-sm'><i class='fa-solid fa-pen-to-square'></i></button ></td > ");
            serial_no++;
            $("#tbl_Custom_report tbody").append(tr);
        }
    }
}

function BindUserTable(userid, reportid) {
    $("#tbl_Custom_report tbody tr").remove();
    if (result.length == 0) {
        tr = $('<tr/>');
        tr.append("<td class='text-center' colspan='8'>no results found</td>");
        $("#UserReportTable tbody").append(tr);
    }
    else {
        for (i = 0; i < result.length; i++) {
            tr = $('<tr/>');
            tr.append("<td style='text-align:center;'>" + serial_no + "</td>");
            tr.append("<td style='text-align:center;'>" + result[i].Report_Id + "</td>");
            tr.append("<td style='text-align:center;'>" + result[i].User_Id + "</td>");
            tr.append("<td class='text-center'><a href='javascript:void(0)' class='text-decoration-none ' style='color: black !important;' onclick='EditForm(\"" + result[i].Report_Id + "\"," + 1 + ");'>" + result[i].Report_Name + "</a></td>");
            tr.append("<td class='text-center'><button type='button' onclick='EditForm(\"" + result[i].Report_Id + "\"," + 1 + ");' class='common-btn common-btn-sm'><i class='fa-solid fa-pen-to-square'></i></button ><button type='button' onclick='deletecustomeUserreport(\"" + result[i].Report_Id + "\");' class= 'common-btn common-btn-sm '> <i class='fa-regular fa-trash-can'></i></button ></td > ");
            serial_no++;
            $("#UserReportTable tbody").append(tr);
        }
    }
}
//*************************************************************************************************************//

function ReportFieldDropdown(e) {
    try {
        const datastring = {};
        datastring.ReportId = $(e).val();
        AjaxSubmission(JSON.stringify(datastring), "/CustomReportDesign/ReportFieldDropdown", $('input[name=__RequestVerificationToken]').val()).done(function (result) {
            let obj = result;
            if (obj.status == true) {
                if (obj.responsecode == '100') {
                    BindDropdown(obj.data.Table, 'ReportField', 'Name', 'Name1', '-----Select-----');
                }
                else if (obj.responsecode == '604') {
                    BindDropdown(null, 'ReportField', 'Name', 'Name1', '-----Select-----');
                }
                else {
                    Toast(RetrieveMessage(obj.responsecode), "Message", "error");
                }
            }
            else {
                window.location.href = '/ClientLogin/ClientLogin';
            }
            //Hideloader();
        }).fail(function (result) {
            console.log(result.Message);
            //Hideloader();
        });
    }
    catch (e) {
        console.log(e.message);
        //Hideloader();
    }
}
function CustomReportList(pageindex) {
    try {
        const dataString = {};
        dataString.PageSize = $("#ddlPageSize").val();
        dataString.PageIndex = pageindex;
        dataString.ReportId = $("#SearchReportId").val().trim();
        dataString.ReportName = $("#SearchReportName").val().trim();
        dataString.OrderBy = $("#sort-column").val().trim() + " " + $("#sort-type").val();
        //Showloader();
        AjaxSubmission(JSON.stringify(dataString), "/CustomReportDesign/CustomReportList", $('input[name=__RequestVerificationToken]').val()).done(function (result) {
            let obj = result;
            if (obj.status == true) {
                if (obj.responsecode == '100') {
                    var ser = ((parseInt(obj.data.Table1[0].PageIndex) - 1) * parseInt(obj.data.Table1[0].PageSize)) + 1;
                    BindCustomReportTable(obj.data.Table, ser);
                    if (obj.data.Table1 != undefined && obj.data.Table1.length > 0) {
                        $(".pagination").BindPaging({
                            ActiveCssClass: "current",
                            PagerCssClass: "pager",
                            PageIndex: parseInt(obj.data.Table1[0].PageIndex),
                            PageSize: parseInt(obj.data.Table1[0].PageSize),
                            RecordCount: parseInt(obj.data.Table1[0].count)
                        });
                    }
                }
                else {
                    Toast(RetrieveMessage(obj.responsecode), "Message", "error");
                }
            }
            else {
                window.location.href = '/ClientLogin/ClientLogin';
            }
            //Hideloader();
        }).fail(function (result) {
            console.log(result.Message);
            //Hideloader();
        });
    }
    catch (e) {
        console.log(e.message);
        //Hideloader();
    }
}

$("#Btn_search").click(function () {
    CustomReportList(1);
});

//*************************************************************************************************************//

function clearfield(e, cls, cls2) {
    var parentTr = $(e).parents('tr');
    parentTr.find("." + cls).val('');
    parentTr.find("." + cls2).val('');
}

// **************************************CHANGE IN AGGREGATE FUNCTION WITH THE CHANGE OF GROUP BY **************//

//function my(e) {
//    if ($(e).parent().parent().find('.AggregateFunction').val() != 0)
//        $(e).parent().parent().find('.GroupBy').prop('checked', false);
//    else
//        $(e).parent().parent().find('.GroupBy').prop('checked', true);
//}

//*************************************************************************************************************//

//function my2(e) {

//    if ($(e).parent().parent().find('.GroupBy').is(':checked') == true)
//        $(e).parent().parent().find('.AggregateFunction').val("0");
//}

//*****************************************RESET DATA**********************************************************//

function ResetData() {
    $("#SearchReport").val("0");
    $("#ReportsName").val("");
    $("#RDLCReportsName").val("");
    $("#AllowExportToExcel").prop('checked', false);
    $("#AppReport").prop('checked', false);
    $("#CustomQuery").prop('checked', false);
    $("#ReportQuery").val('');
    var tbody = $("#SearchReportTables").find("tbody");
    var Tr = $(tbody).find("tr");
    var rowCount = Tr.length;
    if (rowCount > 1) {
        $("#SearchReportTables tbody tr").each(function (index, ele) {
            if (index > 0) {
                $(ele).remove();
            }
            else {
                $(ele).find(".LeftTableName").val('');
                $(ele).find(".LeftTableAliasName").val('');
                $(ele).find(".LeftColumnName").val('');
                $(ele).find(".RightTableName").val('');
                $(ele).find(".RightTableAliasName").val('');
                $(ele).find(".RightColumnName").val('');
                $(ele).find(".TableJoin").val(0);
            }
        });
    }
    else {
        Tr.find(".LeftTableName").val('');
        Tr.find(".LeftTableAliasName").val('');
        Tr.find(".LeftColumnName").val('');
        Tr.find(".RightTableName").val('');
        Tr.find(".RightTableAliasName").val('');
        Tr.find(".RightColumnName").val('');
        Tr.find(".TableJoin").val(0);
        $("#SearchReportTables").find("tbody").append(Tr);
    }
    var ReportColumntbody = $("#SearchReportTableColumn").find("tbody");
    var ReportColumnTr = $(ReportColumntbody).find("tr");
    var ReportColumnrowCount = ReportColumnTr.length;
    if (ReportColumnrowCount > 1) {
        $("#SearchReportTableColumn tbody tr").each(function (index, elee) {
            if (index > 0) {
                $(elee).remove();
            }
            else {
                $(elee).find(".ReportField").val('');
                $(elee).find(".FormulaField").val('');
                $(elee).find(".AggregateFunction").val('0');
                $(elee).find(".DisplayName").val('');
                $(elee).find(".GroupBy").prop('checked', false);
                $(elee).find(".OrderBy").prop('checked', false);
                $(elee).find(".Criteria").val('');
                $(elee).find(".Visible").prop('checked', true);
                $(elee).find(".Function").val('0');
                $("#SearchReportTableColumn").find("tbody").append(elee);
            }
        });
    }
    else {
        ReportColumnTr.find(".ReportField").val('');
        ReportColumnTr.find(".FormulaField").val('');
        ReportColumnTr.find(".AggregateFunction").val('0');
        ReportColumnTr.find(".DisplayName").val('');
        ReportColumnTr.find(".GroupBy").prop('checked', false);
        ReportColumnTr.find(".OrderBy").prop('checked', false);
        ReportColumnTr.find(".Criteria").val('');
        ReportColumnTr.find(".Visible").prop('checked', true);
        ReportColumnTr.find(".Function").val('0');
        $("#SearchReportTableColumn").find("tbody").append(ReportColumnTr);
    }
    var ReportSearchTabletbody = $("#SearchReportFields").find("tbody");
    var ReportSearchTableTr = $(ReportSearchTabletbody).find("tr");
    var ReportSearchTablerowCount = ReportSearchTableTr.length;
    if (ReportSearchTablerowCount > 1) {

        $("#SearchReportFields tbody tr").each(function (index, eleee) {
            if (index > 0) {
                $(eleee).remove();
            }
            else {
                $(eleee).find(".SearchOnField").val('');
                $(eleee).find(".DisplayName").val('');
                $(eleee).find(".Parameter").val('');
                $(eleee).find(".DefaultOperator").val('');
                $(eleee).find(".DefaultValue").val('');
                $(eleee).find(".AllowNull").prop('checked', false);
                $(eleee).find(".OtherDB").prop('checked', false);
                $(eleee).find(".ControlType").val('');
                $(eleee).find(".ComboValue").val('');
                $("#SearchReportFields").find("tbody").append(eleee);
            }
        });
    }
    else {
        ReportSearchTableTr.find(".SearchOnField").val('');
        ReportSearchTableTr.find(".DisplayName").val('');
        ReportSearchTableTr.find(".Parameter").val('');
        ReportSearchTableTr.find(".DefaultOperator").val('');
        ReportSearchTableTr.find(".DefaultValue").val('');
        ReportSearchTableTr.find(".AllowNull").prop('checked', false);
        ReportSearchTableTr.find(".OtherDB").prop('checked', false);
        ReportSearchTableTr.find(".ControlType").val('');
        ReportSearchTableTr.find(".ComboValue").val('');
        $("#SearchReportFields").find("tbody").append(ReportSearchTableTr);
    }

    $("#RightsTbl").empty();
}

//*****************************************TAB SHOW************************************************************//

function TabShow(ch) {
    if (ch == 1) {
        $('#Report_Input-tab').addClass('active ');
        $('#Report_Input').addClass('active show');
        $('#Report_Search_Fields-tab').removeClass('active ');
        $('#Report_Search_Fields-tab').removeClass('active');
        $('#Report_Query-tab').removeClass('active');
        $('#Report_User-tab').removeClass('active');
        $('#Report_list-tab').removeClass('active');
        $("#Report_Column").removeClass('active show');
        $("#Report_Search_Fields").removeClass('active show');
        $("#Report_Query").removeClass('active show');
        $("#Report_User").removeClass('active show');
        $("#Report_list").removeClass('active show');
    }
    $('#AddCustomReportTable').hide();
    $('#Update_CustomReportTable').show();
    $('#DeleteCustomReportTable').show();
    $('#NewReportCustomReportTable').show();
}

//*****************************************TAB HIDE ************************************************************//

function TabHide() {
    $('#AddCustomReportTable').show();
    $('#Update_CustomReportTable').hide();
    $('#DeleteCustomReportTable').hide();
    $('#NewReportCustomReportTable').show();
}
function TabHide2() {
    $('#AddCustomReportTable').show();
    $('#Update_CustomReportTable').hide();
    $('#DeleteCustomReportTable').hide();
    $('#NewReportCustomReportTable').show();
}
function TabHide3() {
    $('#AddCustomReportTable').hide();
    $('#Update_CustomReportTable').show();
    $('#DeleteCustomReportTable').show();
    $('#NewReportCustomReportTable').show();
}

//***************************************FIRST TABLE UP/DOWN FUNCTION*******************************************//

$("#SearchReportTables tbody").on('click', '.SearchReportTablesUp', function () {
    var TmpLeftTableNamen, TmpLeftColumnNamen, TmpRightTableNamen, TmpRightColumnNamen, TmpTableJoinn;
    var TmpLeftTableName, TmpLeftColumnName, TmpTableJoin, TmpRightTableName, TmpRightColumnName;
    var rowindex = $(this).closest('td').parent()[0].sectionRowIndex;
    TmpLeftTableName = $(this).closest('tr').find('.LeftTableName').val();
    TmpLeftColumnName = $(this).closest('tr').find('.LeftColumnName').val();
    TmpTableJoin = $(this).closest('tr').find('.TableJoin').val();
    TmpRightTableName = $(this).closest('tr').find('.RightTableName').val();
    TmpRightColumnName = $(this).closest('tr').find('.RightColumnName').val();

    var TableLenght = $("#SearchReportTables  tbody tr").length;
    if (rowindex > 0) {
        $("#SearchReportTables tbody tr").each(function (ind, el) {
            if (ind == rowindex - 1) {
                TmpLeftTableNamen = $(this).find(".LeftTableName").val();
                TmpLeftColumnNamen = $(this).find(".LeftColumnName").val();
                TmpRightTableNamen = $(this).find(".RightTableName").val();
                TmpRightColumnNamen = $(this).find(".RightColumnName").val();
                TmpTableJoinn = $(this).find(".TableJoin").val();
            }
        });
        $("#SearchReportTables tbody tr").each(function (ind, el) {
            if (ind == rowindex - 1) {
                $(this).find(".LeftTableName").val(TmpLeftTableName);
                $(this).find(".LeftColumnName").val(TmpLeftColumnName);
                $(this).find(".RightTableName").val(TmpRightTableName);
                $(this).find(".RightColumnName").val(TmpRightColumnName);
                $(this).find(".TableJoin").val(TmpTableJoin);
            }
            if (ind == rowindex) {
                $(this).find(".LeftTableName").val(TmpLeftTableNamen);
                $(this).find(".LeftColumnName").val(TmpLeftColumnNamen);
                $(this).find(".RightTableName").val(TmpRightTableNamen);
                $(this).find(".RightColumnName").val(TmpRightColumnNamen);
                $(this).find(".TableJoin").val(TmpTableJoinn);
            }
        });
    }
});
$("#SearchReportTables tbody").on('click', '.SearchReportTablesDown', function () {

    var TmpLeftTableNamen, TmpLeftColumnNamen, TmpRightTableNamen, TmpRightColumnNamen, TmpTableJoinn;
    var TmpLeftTableName, TmpLeftColumnName, TmpTableJoin, TmpRightTableName, TmpRightColumnName;
    var rowindex = $(this).closest('td').parent()[0].sectionRowIndex;
    TmpLeftTableName = $(this).closest('tr').find('.LeftTableName').val();
    TmpLeftColumnName = $(this).closest('tr').find('.LeftColumnName').val();
    TmpTableJoin = $(this).closest('tr').find('.TableJoin').val();
    TmpRightTableName = $(this).closest('tr').find('.RightTableName').val();
    TmpRightColumnName = $(this).closest('tr').find('.RightColumnName').val();
    if (rowindex < $("#SearchReportTables tbody tr ").length - 1) {
        $("#SearchReportTables tbody tr").each(function (ind, el) {
            if (ind == rowindex + 1) {
                if ($(this).find(".LeftTableName").length > 0) {
                    TmpLeftTableNamen = $(this).find(".LeftTableName").val();
                    TmpLeftColumnNamen = $(this).find(".LeftColumnName").val();
                    TmpRightTableNamen = $(this).find(".RightTableName").val();
                    TmpRightColumnNamen = $(this).find(".RightColumnName").val();
                    TmpTableJoinn = $(this).find(".TableJoin").val();
                }
            }
        });

        $("#SearchReportTables tbody tr").each(function (ind, el) {
            if (ind == rowindex + 1) {
                $(this).find(".LeftTableName").val(TmpLeftTableName);
                $(this).find(".LeftColumnName").val(TmpLeftColumnName);
                $(this).find(".RightTableName").val(TmpRightTableName);
                $(this).find(".RightColumnName").val(TmpRightColumnName);
                $(this).find(".TableJoin").val(TmpTableJoin);
            }
            if (ind == rowindex) {
                $(this).find(".LeftTableName").val(TmpLeftTableNamen);
                $(this).find(".LeftColumnName").val(TmpLeftColumnNamen);
                $(this).find(".RightTableName").val(TmpRightTableNamen);
                $(this).find(".RightColumnName").val(TmpRightColumnNamen);
                $(this).find(".TableJoin").val(TmpTableJoinn);
            }
        });
    }
});
//***************************************SECOND TABLE UP/DOWN FUNCTION******************************************//

$("#SearchReportTableColumn tbody").on('click', '.SearchReportTableColumnsUp', function () {
    var TmpReportFieldn, TmpFormulaFieldn, TmpAggregateFunctionn, TmpDisplayNamen, TmpGroupByn, TmpOrderByn, TmpCriterian, TmpVisiblen, TmpFunctionn;
    var TmpReportField, TmpFormulaField, TmpAggregateFunction, TmpDisplayName, TmpGroupBy, TmpOrderBy, TmpCriteria, TmpVisible, TmpFunction;

    var rowindex = $(this).closest('td').parent()[0].sectionRowIndex;
    TmpReportField = $(this).closest('tr').find('.ReportField').val();
    TmpFormulaField = $(this).closest('tr').find('.FormulaField').val();
    TmpAggregateFunction = $(this).closest('tr').find('.AggregateFunction').val();
    TmpDisplayName = $(this).closest('tr').find('.DisplayName').val();
    TmpGroupBy = $(this).closest('tr').find('.GroupBy').prop('checked');
    TmpOrderBy = $(this).closest('tr').find('.OrderBy').prop('checked');
    TmpCriteria = $(this).closest('tr').find('.Criteria').val();
    TmpVisible = $(this).closest('tr').find('.Visible').prop('checked');
    TmpFunction = $(this).closest('tr').find('.Function').val();

    if (rowindex > 0) {
        $("#SearchReportTableColumn tbody tr").each(function (ind, el) {
            if (ind == rowindex - 1) {
                TmpReportFieldn = $(this).find(".ReportField").val();
                TmpFormulaFieldn = $(this).find(".FormulaField").val();
                TmpAggregateFunctionn = $(this).find(".AggregateFunction").val();
                TmpDisplayNamen = $(this).find(".DisplayName").val();
                TmpGroupByn = $(this).find(".GroupBy").prop('checked');
                TmpOrderByn = $(this).find(".OrderBy").prop('checked');
                TmpCriterian = $(this).find(".Criteria").val();
                TmpVisiblen = $(this).find(".Visible").prop('checked');
                TmpFunctionn = $(this).find(".Function").val();
            }
        });

        $("#SearchReportTableColumn tbody tr").each(function (ind, el) {
            if (ind == rowindex - 1) {
                $(this).find(".ReportField").val(TmpReportField);
                $(this).find(".FormulaField").val(TmpFormulaField);
                $(this).find(".AggregateFunction").val(TmpAggregateFunction);
                $(this).find(".DisplayName").val(TmpDisplayName);
                $(this).find(".GroupBy").prop('checked', TmpGroupBy);
                $(this).find(".OrderBy").prop('checked', TmpOrderBy);
                $(this).find(".Criteria").val(TmpCriteria);
                $(this).find(".Visible").prop('checked', TmpVisible);
                $(this).find(".Function").val(TmpFunction);
            }
            if (ind == rowindex) {
                $(this).find(".ReportField").val(TmpReportFieldn);
                $(this).find(".FormulaField").val(TmpFormulaFieldn);
                $(this).find(".AggregateFunction").val(TmpAggregateFunctionn);
                $(this).find(".DisplayName").val(TmpDisplayNamen);
                $(this).find(".GroupBy").prop('checked', TmpGroupByn);
                $(this).find(".OrderBy").prop('checked', TmpOrderByn);
                $(this).find(".Criteria").val(TmpCriterian);
                $(this).find(".Visible").prop('checked', TmpVisiblen);
                $(this).find(".Function").val(TmpFunctionn);
            }
        });
    }
});
$("#SearchReportTableColumn tbody").on('click', '.SearchReportTableColumnDown', function () {
    var TmpReportFieldn, TmpFormulaFieldn, TmpAggregateFunctionn, TmpDisplayNamen, TmpGroupByn, TmpOrderByn, TmpCriterian, TmpVisiblen, TmpFunctionn;
    var TmpReportField, TmpFormulaField, TmpAggregateFunction, TmpDisplayName, TmpGroupBy, TmpOrderBy, TmpCriteria, TmpVisible, TmpFunction;

    var rowindex = $(this).closest('td').parent()[0].sectionRowIndex;
    TmpReportField = $(this).closest('tr').find('.ReportField').val();
    TmpFormulaField = $(this).closest('tr').find('.FormulaField').val();
    TmpAggregateFunction = $(this).closest('tr').find('.AggregateFunction').val();
    TmpDisplayName = $(this).closest('tr').find('.DisplayName').val();
    TmpGroupBy = $(this).closest('tr').find('.GroupBy').prop('checked');
    TmpOrderBy = $(this).closest('tr').find('.OrderBy').prop('checked');
    TmpCriteria = $(this).closest('tr').find('.Criteria').val();
    TmpVisible = $(this).closest('tr').find('.Visible').prop('checked');
    TmpFunction = $(this).closest('tr').find('.Function').val();
    if (rowindex < $("#SearchReportTableColumn tbody tr").length - 1) {
        $("#SearchReportTableColumn tbody tr").each(function (ind, el) {
            if (ind == rowindex + 1) {

                if ($(this).find(".ReportField").length > 0) {
                    TmpReportFieldn = $(this).find(".ReportField").val();
                    TmpFormulaFieldn = $(this).find(".FormulaField").val();
                    TmpAggregateFunctionn = $(this).find(".AggregateFunction").val();
                    TmpDisplayNamen = $(this).find(".DisplayName").val();
                    TmpGroupByn = $(this).find(".GroupBy").prop('checked');
                    TmpOrderByn = $(this).find(".OrderBy").prop('checked');
                    TmpCriterian = $(this).find(".Criteria").val();
                    TmpVisiblen = $(this).find(".Visible").prop('checked');
                    TmpFunctionn = $(this).find(".Function").val();
                }
            }
        });

        $("#SearchReportTableColumn tbody tr").each(function (ind, el) {
            if (ind == rowindex + 1) {
                $(this).find(".ReportField").val(TmpReportField);
                $(this).find(".FormulaField").val(TmpFormulaField);
                $(this).find(".AggregateFunction").val(TmpAggregateFunction);
                $(this).find(".DisplayName").val(TmpDisplayName);
                $(this).find(".GroupBy").prop('checked', TmpGroupBy);
                $(this).find(".OrderBy").prop('checked', TmpOrderBy);
                $(this).find(".Criteria").val(TmpCriteria);
                $(this).find(".Visible").prop('checked', TmpVisible);
                $(this).find(".Function").val(TmpFunction);
            }
            if (ind == rowindex) {
                $(this).find(".ReportField").val(TmpReportFieldn);
                $(this).find(".FormulaField").val(TmpFormulaFieldn);
                $(this).find(".AggregateFunction").val(TmpAggregateFunctionn);
                $(this).find(".DisplayName").val(TmpDisplayNamen);
                $(this).find(".GroupBy").prop('checked', TmpGroupByn);
                $(this).find(".OrderBy").prop('checked', TmpOrderByn);
                $(this).find(".Criteria").val(TmpCriterian);
                $(this).find(".Visible").prop('checked', TmpVisiblen);
                $(this).find(".Function").val(TmpFunctionn);
            }
        });
    }
});

//****************************************THIRD TABLE UP/Down FUNCTION******************************************//

$("#SearchReportFields tbody").on('click', '.SearchReportFieldsUp', function () {
    var TmpSearchOnFieldn, TmpDisplayNamen, TmpParametern, TmpDefaultOperatorn, TmpDefaultValuen, TmpAllowNulln, TmpOtherDBn, TmpControlTypen, TmpComboValuen;
    var TmpSearchOnField, TmpDisplayName, TmpParameter, TmpDefaultOperator, TmpDefaultValue, TmpAllowNull, TmpOtherDB, TmpControlType, TmpComboValue;
    var rowindex = $(this).closest('td').parent()[0].sectionRowIndex;
    TmpSearchOnField = $(this).closest('tr').find('.SearchOnField').val();
    TmpDisplayName = $(this).closest('tr').find('.DisplayName').val();
    TmpParameter = $(this).closest('tr').find('.Parameter').val();
    TmpDefaultOperator = $(this).closest('tr').find('.DefaultOperator').val();
    TmpTDefaultValue = $(this).closest('tr').find('.DefaultValue').val();
    TmpAllowNull = $(this).closest('tr').find('.AllowNull').prop('checked');
    TmpOtherDB = $(this).closest('tr').find('.OtherDB').prop('checked');
    TmpControlType = $(this).closest('tr').find('.ControlType').val();
    TmpComboValue = $(this).closest('tr').find('.ComboValue').val();
    var TableLenght = $("#SearchReportFields  tbody tr").length;
    if (rowindex > 0) {
        $("#SearchReportFields tbody tr").each(function (ind, el) {
            if (ind == rowindex - 1) {
                TmpSearchOnFieldn = $(this).find(".SearchOnField").val();
                TmpDisplayNamen = $(this).find(".DisplayName").val();
                TmpParametern = $(this).find(".Parameter").val();
                TmpDefaultOperatorn = $(this).find(".DefaultOperator").val();
                TmpDefaultValuen = $(this).find(".DefaultValue").val();
                TmpAllowNulln = $(this).find(".AllowNull").prop('checked');
                TmpOtherDBn = $(this).find(".OtherDB").prop('checked');
                TmpControlTypen = $(this).find(".ControlType").val();
                TmpComboValuen = $(this).find(".ComboValue").val();
            }
        });
        $("#SearchReportFields tbody tr").each(function (ind, el) {
            if (ind == rowindex - 1) {
                $(this).find(".SearchOnField").val(TmpSearchOnField);
                $(this).find(".DisplayName").val(TmpDisplayName);
                $(this).find(".Parameter").val(TmpParameter);
                $(this).find(".DefaultOperator").val(TmpDefaultOperator);
                $(this).find(".DefaultValue").val(TmpDefaultValue);
                $(this).find(".AllowNull").prop('checked', TmpAllowNull);
                $(this).find(".OtherDB").prop('checked', TmpOtherDB);
                $(this).find(".ControlType").val(TmpControlType);
                $(this).find(".ComboValue").val(TmpComboValue);
            }
            if (ind == rowindex) {
                $(this).find(".SearchOnField").val(TmpSearchOnFieldn);
                $(this).find(".DisplayName").val(TmpDisplayNamen);
                $(this).find(".Parameter").val(TmpParametern);
                $(this).find(".DefaultOperator").val(TmpDefaultOperatorn);
                $(this).find(".DefaultValue").val(TmpDefaultValuen);
                $(this).find(".AllowNull").prop('checked', TmpAllowNulln);
                $(this).find(".OtherDB").prop('checked', TmpOtherDBn);
                $(this).find(".ControlType").val(TmpControlTypen);
                $(this).find(".ComboValue").val(TmpComboValuen);
            }
        });
    }
});
$("#SearchReportFields tbody").on('click', '.SearchReportFieldsDown', function () {
    var TmpSearchOnFieldn, TmpDisplayNamen, TmpParametern, TmpDefaultOperatorn, TmpDefaultValuen, TmpAllowNulln, TmpOtherDBn, TmpControlTypen, TmpComboValuen;
    var TmpSearchOnField, TmpDisplayName, TmpParameter, TmpDefaultOperator, TmpDefaultValue, TmpAllowNull, TmpOtherDB, TmpControlType, TmpComboValue;
    var rowindex = $(this).closest('td').parent()[0].sectionRowIndex;
    TmpSearchOnField = $(this).closest('tr').find('.SearchOnField').val();
    TmpDisplayName = $(this).closest('tr').find('.DisplayName').val();
    TmpParameter = $(this).closest('tr').find('.Parameter').val();
    TmpDefaultOperator = $(this).closest('tr').find('.DefaultOperator').val();
    TmpDefaultValue = $(this).closest('tr').find('.DefaultValue').val();
    TmpAllowNull = $(this).closest('tr').find('.AllowNull').prop('checked');
    TmpOtherDB = $(this).closest('tr').find('.OtherDB').prop('checked');
    TmpControlType = $(this).closest('tr').find('.ControlType').val();
    TmpComboValue = $(this).closest('tr').find('.ComboValue').val();
    if (rowindex < $("#SearchReportFields tbody tr ").length - 1) {
        $("#SearchReportFields tbody tr").each(function (ind, el) {
            if (ind == rowindex + 1) {
                if ($(this).find(".SearchOnField").length > 0) {
                    TmpSearchOnFieldn = $(this).find(".SearchOnField").val();
                    TmpDisplayNamen = $(this).find(".DisplayName").val();
                    TmpParametern = $(this).find(".Parameter").val();
                    TmpDefaultOperatorn = $(this).find(".DefaultOperator").val();
                    TmpTDefaultValuen = $(this).find(".DefaultValue").val();
                    TmpAllowNulln = $(this).find(".AllowNull").prop('checked');
                    TmpOtherDBn = $(this).find(".OtherDB").prop('checked');
                    TmpControlTypen = $(this).find(".ControlType").val();
                    TmpComboValuen = $(this).find(".ComboValue").val();
                }
            }
        });
        $("#SearchReportFields tbody tr").each(function (ind, el) {
            if (ind == rowindex + 1) {
                $(this).find(".SearchOnField").val(TmpSearchOnField);
                $(this).find(".DisplayName").val(TmpDisplayName);
                $(this).find(".Parameter").val(TmpParameter);
                $(this).find(".DefaultOperator").val(TmpDefaultOperator);
                $(this).find(".DefaultValue").val(TmpDefaultValue);
                $(this).find(".AllowNull").prop('checked', TmpAllowNull);
                $(this).find(".OtherDB").prop('checked', TmpOtherDB);
                $(this).find(".ControlType").val(TmpControlType);
                $(this).find(".ComboValue").val(TmpComboValue);
            }
            if (ind == rowindex) {
                $(this).find(".SearchOnField").val(TmpSearchOnFieldn);
                $(this).find(".DisplayName").val(TmpDisplayNamen);
                $(this).find(".Parameter").val(TmpParametern);
                $(this).find(".DefaultOperator").val(TmpDefaultOperatorn);
                $(this).find(".DefaultValue").val(TmpDefaultValuen);
                $(this).find(".AllowNull").prop('checked', TmpAllowNulln);
                $(this).find(".OtherDB").prop('checked', TmpOtherDBn);
                $(this).find(".ControlType").val(TmpControlTypen);
                $(this).find(".ComboValue").val(TmpComboValuen);
            }
        });
    }
});

/*NEW FUNCTION FOR AUTOCOMPLETE*/

//FUNCTION FOR AUTOCOMPLETE AJAX
function AutoCompleteAjaxWithClasswithConditionNew(ClassName, Url, HiddenClass, Condition, HiddenClass2) {
    $("." + ClassName).autocomplete({
        source: function (request, response) {
            AjaxSubmissionAutocomplete(JSON.stringify({ SearchField: request.term, Condition: Condition }), Url, $('input[name=__RequestVerificationToken]').val()).done(function (result) {
                let obj = result;
                if (obj.status == true) {
                    if (obj.responsecode == '100') {
                        response($.map(result.data.Table, function (item, id) {
                            return {
                                label: item.name,
                                value: item.name,
                                id: item.id,
                                DTpe: item.DATA_TYPE
                            };
                        }));
                    }
                }
                else
                    window.location.href = '/ClientLogin/ClientLogin';
                //Hideloader();
            }).fail(function (result) {
                //Hideloader();
                console.log(result.Message);
            });
        },
        autoFocus: true,
        minLength: 1,
        selectFirst: true,
        selectOnly: true,
        select: function (e, i) {
            var parentTr = $(this).parents('tr');
            parentTr.find("." + HiddenClass).val(i.item.id);
            parentTr.find("." + HiddenClass2).val(i.item.DTpe);
        },
        change: function (e, i) {
            if (i.item == null || i.item == undefined) {
                var parentTr = $(this).parents('tr');
                parentTr.find("." + ClassName).val('');
                parentTr.find("." + HiddenClass).val('');
                parentTr.find("." + HiddenClass2).val('');
            }
        }
    });
}

function Sorting(obj) {
    if (Firstcolumn != "") {
        document.getElementById(Firstcolumn).innerHTML = document.getElementById(Firstcolumn).getAttribute("data-column") + " <i class='fa-solid fa-sort'></i>";
    }
    Firstcolumn = obj.id;
    var colname = $(obj).data("column");
    $("#sort-column").val(Firstcolumn);
    var sorttype = $("#sort-type").val();
    if (sorttype == "ASC") {
        $("#sort-type").val("DESC");
        $(obj).html(colname + " <i style='margin-left:10px;' class='fa-solid fa-sort-down'></i>");
    } else if (sorttype == "DESC") {
        $("#sort-type").val("ASC");
        $(obj).html(colname + " <i style='margin-left:10px;' class='fa-solid fa-sort-up'></i>");
    }

    CustomReportList(1);
}
