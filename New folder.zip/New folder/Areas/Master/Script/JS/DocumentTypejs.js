﻿var Firstcolumn = "";
$(document).on("click", ".pagination .page", function () {
    FormList(($(this).attr('page')));

});


//PAGE SIZE CLICKED
$("#ddlPageSize").change(function () {
    FormList(1);
});

//SEARCH BUTTON CLICKED
$("#FormSearch").click(function () {
    FormList(1);
});

$(document).ready(function () {
    FillPageSizeList('ddlPageSize', FormList);

    $("#SearchStatus").select2();
    $("#DocumentTypeStatus").select2({
        width: '100%', "id": "value attribute" || "option text",
        "text": "label attribute" || "option text",
        "element": HTMLOptionElement
    });
    $("#DocumentIdSearch").focus();

    /*   FillPageSizeList();*/
})
// BIND DOCUMENT TYPE TABLE

function BindFormTable(result, serial_no) {
    $("#tbl_DocumentType tbody tr").remove();
    if (result.length == 0) {
        tr = $('<tr/>');
        tr.append("<td class='text-center' colspan='9'>NO RESULTS FOUND</td>");
        $("#tbl_DocumentType tbody").append(tr);
    }
    else {
        for (i = 0; i < result.length; i++) {
            if (result[i].is_active == "Inactive")
                tr = $(' <tr style="background-color:#fdd2d2;"/>');
            else
                tr = $('<tr/>');
            tr.append("<td class='text-center'><button type='button' onclick='FormEdit(\"" + result[i].doc_type_uid + "\");' class='common-btn common-btn-sm'><i class='fa-solid fa-pen-to-square'></i></button ><button type='button' onclick='FormDelete(\"" + result[i].doc_type_uid + "\");' class='common-btn common-btn-sm ms-1'> <i class='fa-regular fa-trash-can'></i></button ></td > ");
            tr.append("<td class='text-left'>" + serial_no + "</td>");
            tr.append("<td class='text-left'>" + result[i].doc_type_uid + "</td>");
            tr.append("<td class='text-center'><a href='javascript:void(0)' class='text-decoration-none' style='color: black !important;' onclick='FormEdit(\"" + result[i].doc_type_uid + "\");'>" + result[i].doc_type + "</a></td>");
            tr.append("<td class='text-center'>" + result[i].is_active + "</td>");
           
            serial_no++;
            $("#tbl_DocumentType tbody").append(tr);
        }
    }
}


//DOCUMENT TYPE LIST PAGE INDEX
function FormList(pageindex) {
    try {
        const dataString = {};
        dataString.PageSize = $("#ddlPageSize").val();
        dataString.PageIndex = pageindex;
        dataString.DocumentTypeId = $("#DocumentIdSearch").val();
        dataString.DocumentTypeName = $("#DocumentTypeNameSearch").val();
        dataString.Status = $("#SearchStatus").val();
        dataString.OrderBy = $("#sort-column").val().trim() + " " + $("#sort-type").val().trim();
        ShowLoader();
        AjaxSubmission(JSON.stringify(dataString), "/Master/DocumentType/FormList", $('input[name=__RequestVerificationToken]').val()).done(function (result) {
            let obj = result;
            if (obj.status == true) {
                if (obj.responsecode == '100') {
                    var ser = ((parseInt(obj.data.Table1[0].PageIndex) - 1) * parseInt(obj.data.Table1[0].PageSize)) + 1;
                    BindFormTable(obj.data.Table, ser);
                    if (obj.data.Table1 != undefined && obj.data.Table1.length > 0) {
                        $(".pagination").BindPaging({
                            ActiveCssClass: "current",
                            PagerCssClass: "pager",
                            PageIndex: parseInt(obj.data.Table1[0].PageIndex),
                            PageSize: parseInt(obj.data.Table1[0].PageSize),
                            RecordCount: parseInt(obj.data.Table1[0].count)
                        });
                    }
                }
                else {
                    Toast(RetrieveMessage(obj.responsecode), "Message", "error");
                }
            }
            else {
                window.location.href = '/ClientLogin/ClientLogin';
            }
            HideLoader();
        }).fail(function (result) {
            console.log(result.Message);
            HideLoader();
        });
    }
    catch (e) {
        console.log(e.message);
        HideLoader();
    }
}



//FUNCTION FOR SORTING FIELD
function Sorting(obj) {
    if (Firstcolumn != "") {
        document.getElementById(Firstcolumn).innerHTML = document.getElementById(Firstcolumn).getAttribute("data-column") + " <i class='fa-solid fa-sort'></i>";
    }
    Firstcolumn = obj.id;
    var colname = $(obj).data("column");
    $("#sort-column").val(Firstcolumn);
    var sorttype = $("#sort-type").val();
    if (sorttype == "ASC") {
        $("#sort-type").val("DESC");
        $(obj).html(colname + " <i  style='margin-left:10px;' class='fa-solid fa-sort-up'></i>");
    } else if (sorttype == "DESC") {
        $("#sort-type").val("ASC");
        $(obj).html(colname + " <i  style='margin-left:10px;' class='fa-solid fa-sort-down'></i>");
    }
    FormList(1);
}


$("#FormAdd").click(function () {
    RemoveAllError('Document');
    ValidateAllFieldNewTest('Document');
    if (Ercount == 0)
        FormAdd();
});

//FUNCTION FOR DOCUMENT TYPE
function FormAdd() {
    try {
        debugger;
        const dataString = {};
        dataString.DocumentTypeName = $("#DocumentTypeName").val().trim();
        dataString.Status = $("#DocumentTypeStatus").val();
        /* dataString.DefaultPageSize = parseInt($("#DefaultPageSize").val());*/
        ShowLoader();
        AjaxSubmission(JSON.stringify(dataString), "/Master/DocumentType/FormAdd", $('input[name=__RequestVerificationToken]').val()).done(function (result) {
            let obj = result;
            if (obj.status == true) {
                if (obj.responsecode == '101') {
                    Toast(RetrieveMessage(obj.responsecode), "Message", "success");
                    setTimeout(FormList(1), 1000);
                    $("#FormAdd").hide();
                    $("#FormUpdate").show();
                    $("#FormReset").show();
                    $("#Document-tab").html("Edit Document");
                    //ResetForm();
                    //TabHide();
                }
                else {
                    Toast(RetrieveMessage(obj.responsecode), "Message", "error");
                }
            }
            else {
                window.location.href = '/ClientLogin/ClientLogin';
            }
            HideLoader();
        }).fail(function (result) {
            console.log(result.Message);
            HideLoader();
        });
    }
    catch (e) {
        console.log(e.message);
        HideLoader();
    }
}


//FUNCTION FOR EDIT INVOICE TYPE
function FormEdit(DocumentTypeId) {

    try {
        const dataString = {};
        dataString.DocumentTypeId = parseInt(DocumentTypeId);
        ShowLoader();
        AjaxSubmission(JSON.stringify(dataString), "/Master/DocumentType/FormEdit", $('[name="__RequestVerificationToken"]').val()).done(function (data) {
            let obj = data;
            console.log(obj);
            debugger
            if (obj.status == true) {
                if (obj.responsecode == '100') {
                    TabShow();
                    $("#DocumentTypeName").val(obj.data.Table[0].DocType);
                    if (obj.data.Table[0].is_active == true)
                        $("#DocumentTypeStatus").val('1').trigger('change');
                    else
                        $("#DocumentTypeStatus").val('0').trigger('change');


                }
                else {
                    Toast(RetrieveMessage(obj.responsecode), "Message", "error");
                }
            }
            else {
                window.location.href = '/ClientLogin/ClientLogin';
            }
            HideLoader();
        }).fail(function (data) {
            console.log(data.Message);
            HideLoader();
        });
    }
    catch (e) {
        console.log(e.message);
        HideLoader();
    }
}

$("#FormUpdate").click(function () {
    RemoveAllError('Document');
    ValidateAllFieldNewTest('Document');
    if (Ercount == 0)
        FormUpdate();
});


//FUNCTION FOR INVOICE TYPE
function FormUpdate() {
    try {
        const dataString = {};
        dataString.DocumentTypeName = $("#DocumentTypeName").val().trim();
        dataString.Status = $("#DocumentTypeStatus").val();
        ShowLoader();
        AjaxSubmission(JSON.stringify(dataString), "/Master/DocumentType/FormUpdate", $('input[name=__RequestVerificationToken]').val()).done(function (result) {
            let obj = result;
            if (obj.status == true) {
                if (obj.responsecode == '107') {
                    Toast(RetrieveMessage(obj.responsecode), "Message", "success");
                    setTimeout(FormList(1), 500);
                    //ResetForm();
                    //TabHide();
                }
                else {
                    Toast(RetrieveMessage(obj.responsecode), "Message", "error");
                }
            }
            else {
                window.location.href = '/ClientLogin/ClientLogin';
            }
            HideLoader();
        }).fail(function (result) {
            console.log(result.Message);
            HideLoader();
        });
    }
    catch (e) {
        console.log(e.message);
        HideLoader();
    }
}
//FUNCTION FOR DELETE INVOICE TYPE
function FormDelete(e) {
    try {
        $.confirm({
            title: '',
            content: 'Are You Sure Want To Delete ?',
            type: 'red',
            boxWidth: '300px',
            useBootstrap: false,
            columnClass: 'small',
            containerFluid: true,
            typeAnimated: true,
            buttons: {
                tryAgain: {
                    text: 'Confirm',
                    btnClass: 'btn-red',
                    action: function () {

                        const datastring = {};
                        datastring.DocumentTypeId = parseInt(e);
                        ShowLoader();
                        AjaxSubmission(JSON.stringify(datastring), "/Master/DocumentType/FormDelete", $('[name="__RequestVerificationToken"]').val()).done(function (data) {
                            let obj = data;
                            if (obj.status == true) {
                                if (obj.responsecode == '102') {
                                    Toast(RetrieveMessage(obj.responsecode), "Message", "success");
                                    FormList(1);
                                    /* GetParentMenuName();*/
                                }
                                else {
                                    Toast(RetrieveMessage(obj.responsecode), "Message", "error");
                                }
                            }
                            else {
                                window.location.href = 'ClientLogin/ClientLogin';
                            }
                            HideLoader();
                        }).fail(function (data) {
                            console.log(data.Message);
                            HideLoader();
                        });
                    }
                },
                close: function () {
                    HideLoader();
                }
            }
        });
    }
    catch (e) {
        console.log(e.message);
        HideLoader();
    }
}

//FUNCTION FOR EXPORT DATA IN EXCEL
function FormExcel() {
    ShowLoader();
    let date = new Date();
    let NewDate = ("00" + date.getDate()).slice(-2) + "_" + ("00" + (date.getMonth() + 1)).slice(-2) + "_" + date.getFullYear() + "_" + ("00" + date.getHours()).slice(-2) + "_" + ("00" + date.getMinutes()).slice(-2) + "_" + ("00" + date.getSeconds()).slice(-2);
    let fileName = "DocumentType_" + NewDate + ".xlsx";

    $('#FormSearch').trigger('click');
    AjaxSubmission(null, '/Master/DocumentType/FormExcel', $('input[name=__RequestVerificationToken]').val()).done(function (result) {
        let obj = result;
        if (obj.status == true) {
            if (obj.responsecode == '100') {

                let bytes = Base64ToBytes(obj.data.FileData[0].Base64Data);
                let blob = new Blob([bytes], { type: "application/octetstream" });
                let isIE = false || !!document.documentMode;
                if (isIE) {
                    window.navigator.msSaveBlob(blob, fileName);
                } else {
                    let url = window.URL || window.webkitURL;
                    link = url.createObjectURL(blob);
                    let a = $("<a />");
                    a.attr("download", fileName);
                    a.attr("href", link);
                    $("body").append(a);
                    a[0].click();
                    $("body").remove(a);
                }
            }
            else if (obj.responsecode == '302')
                Toast("No Records found.", 'Message', 'success');
            else
                Toast(RetrieveMessage(obj.responsecode), 'Message', 'error');

        } else
            window.location.href = '/ClientLogin/ClientLogin';
        HideLoader();

    }).fail(function (result) {
        console.log(result.Message);
        HideLoader();
    });
}


//FUNCTION FOR REST INPUT TYPE FIELD
function ResetForm() {
    $("#DocumentTypeName").val("");
    $("#DocumentTypeStatus").val('1').trigger('change');
    $("#DocumentTypeNameError").html("");
    $("#DocumentTypeStatusError").html("");
};


//FUCNTION FOR TAB SHOW
function TabShow() {
    $('#Document_list-tab').removeClass('active');
    $('#Document-tab').addClass('active');
    $('#Document_list').removeClass('active show');
    $('#Document').addClass('active show');
    $("#FormAdd").hide();
    $("#FormUpdate").show();
    $("#FormReset").show();
    $("#Document-tab").html("Edit Document");
}

//FUNCTION FOR TAB HIDE
function TabHide() {
    $('#Document-tab').removeClass('active');
    $('#Document_list-tab').addClass('active ');
    $('#Document_list').addClass('active show');
    $('#Document').removeClass('active show');
    $("#FormAdd").show();
    $("#FormUpdate").hide();
    $("#FormReset").hide();
    $("#Document-tab").html("Add Document");
}

//MENU LIST TAB CLICKED
$("#Document_list-tab").click(function () {
    ResetForm();
    TabHide();
    RemoveAllError('Document');
})

$(".Document_list").click(function () {
    $("#DocumentIdSearch").focus();
})


$("#FormReset").click(function () {

    $("#FormReset").hide();
    $("#FormUpdate").hide();
    $("#FormAdd").show();
    ResetForm();
})

document.addEventListener("keydown", function (zEvent) {
    if (zEvent.ctrlKey && zEvent.altKey && (zEvent.key == "j" || zEvent.key == "J")) {
        $('#Document_list-tab').removeClass('active ');
        $('#Document_list').removeClass('active show');
        $('#Document-tab').addClass('active');
        $('#Document').addClass('active show');
        $("#FormAdd").show();
        $("#FormUpdate").hide();
        $("#FormReset").hide();
        $("#Document-tab").html("Add Document ");
        $('#DocumentTypeName').focus();
        ResetForm();

    }
});





