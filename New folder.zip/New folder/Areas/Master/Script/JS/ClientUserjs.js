﻿
var Firstcolumn = "";
var Ercount = 0;
var Action = "";
var SuccessPwd;
var sc = "";

//DATE PICKER
$(".datepickerAll").datepicker({
    toolbarPlacement: "bottom",
    showButtonPanel: true,
    changeMonth: true,
    changeYear: true,
    dateFormat: 'dd/mm/yy'
});

//FOR TODAY DATE
jQuery.datepicker._gotoToday = function (id) {
    let today = new Date();
    let dateRef = jQuery("<td><a>" + today.getDate() + "</a></td>");
    this._selectDay(id, today.getMonth(), today.getFullYear(), dateRef);
};

//FOR SELECT2 WIDTH SET
$('#User_type_search,#Manager,#Status,#UserGroup,#UserBranchL').select2({
    width: '100%'
});

//FUNCTION FOR IMAGE SHOW IN IMAGE MODAL
function ImagePreviewModel(e) {
    $('#image-model').modal('show');
    let SourceFile = $(e).prop('src');
    $('#PreviewImage').attr("src", SourceFile);

}

//DOCUMENT READY
$(document).ready(function () {
    Firstcolumn = 'user_name';
    FillPageSizeList('ddlPageSize', FormList);
    FillManagerList();
    FillClientGroupList('UserGroup');
    FillUserList();
    $('#User_id_search').focus();

});

//PAGINATION PAGE CLICKED
$(document).on('click', '.pagination .page', function () {
    FormList(($(this).attr('page')));
});

//SEARCH BUTTON CLICKED
$('#FormSearch').click(function () {
    FormList(1);
});

//PAGE SIZE CLICKED
$('#ddlPageSize').change(function () {
    FormList(1);
});

//PREVENTRYDAYS TEXTBOX BLUR EVENT
$('#PrevEntryDays').blur(function () {
    if ($('#PrevEntryDays').val().trim().length == 0)
        $('#PrevEntryDays').val(0);
});

//FUNCTION FOR SORTING FIELD
function FormSorting(obj) {
    if (Firstcolumn != "") {
        document.getElementById(Firstcolumn).innerHTML = document.getElementById(Firstcolumn).getAttribute("data-column") + " <i class='fa-solid fa-sort'></i>";
    }
    Firstcolumn = obj.id;
    let colname = $(obj).data("column");
    $("#sort-column").val(Firstcolumn);
    let sorttype = $("#sort-type").val();
    if (sorttype == "ASC") {
        $("#sort-type").val("DESC");
        $(obj).html(colname + " <i style='margin-left:10px;' class='fa-solid fa-sort-down'></i>");
    } else if (sorttype == "DESC") {
        $("#sort-type").val("ASC");
        $(obj).html(colname + " <i style='margin-left:10px;' class='fa-solid fa-sort-up'></i>");
    }
    FormList(1);
}

//USER BRANCH RIGHTS BUTTON CLICKED EVENT
$('#Btn_save_changes').click(function () {
    UpdateUserBranchRightsNew();
});

//FUNCTION FOR UPDATE USER BRANCH RIGHTS NEW
function UpdateUserBranchRightsNew() {
    try {
        let chchk = 0;
        const dataString = {};
        let UserBranchRightsData = new Array();
        $('#UserCompanyBranchTable  .rowdata').each(function (ind, ele) {
            let UserBranchright = {};
            UserBranchright.CompanyId = $(ele).find('.cm').html();
            UserBranchright.BranchId = $(ele).find('.br').html();

            if ($(ele).find('.action').is(':checked') == true)
                chchk = 1;

            if ($(ele).find('.rad').is(':checked') == true) {
                if ($(ele).find('.action').is(':checked') == false) {
                    UserBranchright.Action = $(ele).find('.action').is(':checked');
                    UserBranchright.Default = false;
                } else {
                    UserBranchright.Action = $(ele).find('.action').is(':checked');
                    UserBranchright.Default = true;
                }
            }
            else {
                UserBranchright.Action = $(ele).find('.action').is(':checked');
                UserBranchright.Default = $(ele).find('.rad').is(':checked');
            }

            UserBranchRightsData.push(UserBranchright);
        });
        if (chchk == 0) {
            Toast('Please check at least one Branch.', 'Message', 'Error');
        } else {
            dataString.UserId = $("#UserBranchL").val();
            dataString.userBranchRightNews = UserBranchRightsData;


            AjaxSubmission(JSON.stringify(dataString), "/User/UpdateUserBranchRightsNew", $('[name="__RequestVerificationToken"]').val()).done(function (data) {
                let obj = data;
                if (obj.status == true) {

                    if (obj.responsecode == '100') {
                        Toast(RetrieveMessage(107), 'message', 'success');
                        /* $("#UserBranchL").val(0).trigger('change');*/

                    } else {
                        Toast(RetrieveMessage(302), 'message', 'error');
                    }
                } else {
                    window.location.href = '/ClientLogin/ClientLogin';
                }
            }).fail(function (result) {
                console.log(result.Message);
            });
        }
    }
    catch (e) {
        console.log(e.message);
    }
}

//FUNCTION FOR FILL COMPANY WISE BRANCH NEW
function FillCompanyWiseBranchNew() {
    try {
        $('#UserCompanyBranchTable tbody').html('');

        $('#UserCompanyTable tbody tr ').find('input[type="checkbox"]').each(function (ind, ele) {

            if ($(ele).is(':checked') == true) {
                const dataString = {};
                dataString.CompanyId = $(ele).parent().parent()[0].id;
                dataString.UserId = $("#UserBranchL").val();

                AjaxSubmission(JSON.stringify(dataString), '/User/FillClientCompanyBranchRights', $('input[name=__RequestVerificationToken]').val()).done(function (result) {
                    let obj = result;
                    if (obj.status == true) {

                        const totalcount = obj.data.Table1.length;
                        body = '';
                        body += '<tr><th colspan="3">' + $(ele).parent().siblings().html() + '</th></tr>';
                        for (let i = 0; i < totalcount; i++) {
                            const action = obj.data.Table1[i].Is_accessable == false ? '' : 'checked="checked"';
                            const isdefault = obj.data.Table1[i].is_default == false ? '' : 'checked="checked"';
                            const name = 'default';

                            body += '<tr class="rowdata"><td>' + obj.data.Table1[i].BranchName + '</td>';
                            body += '<td scope="col" class="d-none cm">' + $(ele).parent().parent()[0].id + '</td>';
                            body += '<td scope="col" class="d-none br">' + obj.data.Table1[i].BranchUid + '</td>';
                            body += '<td scope="col"><input type="checkbox" ' + action + ' class="action" ></td>';
                            body += '<td scope="col"><input type="radio" class="rad" ' + isdefault + ' name=' + $(ele).parent().parent()[0].id + '></td>';

                        }

                        $("#UserCompanyBranchTable").append(body);

                    }
                    else {
                        window.location.href = '/ClientLogin/ClientLogin';
                    }
                }).fail(function (result) {
                    console.log(result.Message);
                });
            }
        });

    }
    catch (e) {
        console.log(e.message);
    }
}

//FUNCTION FOR FILL CLIENT COMPANY NEW
function FillClientCompanyNew(e) {
    try {
        const dataString = {};
        dataString.UserId = e
        AjaxSubmission(JSON.stringify(dataString), '/User/FillClientCompanyNew', $('input[name=__RequestVerificationToken]').val()).done(function (result) {
            let obj = result;
            if (obj.status == true) {
                if (obj.responsecode == '100') {
                    if (obj.data.Table.length == 0)
                        Toast('Company Not Found', 'Message', 'error');
                    else {
                        let body = '<tbody>'
                        for (i = 0; i < obj.data.Table.length; i++) {
                            const action = obj.data.Table[i].company_check == false ? '' : 'checked="checked"';
                            body += '<tr id=' + obj.data.Table[i].company_id + '>';
                            body += '<td>' + obj.data.Table[i].company_name + '</td>';
                            body += '<td scope="col"><input type="checkbox" ' + action + ' class="action" onclick="FillCompanyWiseBranchNew()" ></td>';
                            body += '</tr>';
                        }
                        $('#UserCompanyTable').append(body);
                        FillCompanyWiseBranchNew();
                    }
                }
            }
            else {
                window.location.href = '/ClientLogin/ClientLogin';
            }
        }).fail(function (result) {
            console.log(result.Message);
        });
    }
    catch (e) {
        console.log(e.message);
    }
}

//FUNCTION FOR FORM LIST
function FormList(pageindex) {
    try {
        const dataString = {};
        dataString.PageSize = $('#ddlPageSize').val();
        dataString.PageIndex = pageindex;
        dataString.UserId = parseInt($('#User_id_search').val().trim());
        dataString.Name = $('#User_name_search').val().trim();
        dataString.EmailId = $('#Email_search').val().trim();
        dataString.Phone = $('#User_phone_search').val().trim();
        dataString.IsActive = $('#User_type_search').val();
        dataString.OrderBy = $('#sort-column').val().trim() + ' ' + $('#sort-type').val().trim();

        AjaxSubmission(JSON.stringify(dataString), '/User/FormList', $('input[name=__RequestVerificationToken]').val()).done(function (result) {
            let obj = result;
            if (obj.status == true) {
                if (obj.responsecode == '100') {
                    var ser = ((parseInt(obj.data.Table1[0].PageIndex) - 1) * parseInt(obj.data.Table1[0].PageSize)) + 1;
                    BindFormTable(obj.data.Table, ser, obj.data.Table2[0].LogoutPermission);
                    $('.pagination').BindPaging({
                        ActiveCssClass: 'current',
                        PagerCssClass: 'pager',
                        PageIndex: parseInt(obj.data.Table1[0].PageIndex),
                        PageSize: parseInt(obj.data.Table1[0].PageSize),
                        RecordCount: parseInt(obj.data.Table1[0].count)
                    });
                }
                else {
                    Toast(RetrieveMessage(obj.responsecode), 'Message', 'error');
                }
            }
            else {
                window.location.href = '/ClientLogin/ClientLogin';
            }
        }).fail(function (result) {
            console.log(result.Message);
        });
    }
    catch (e) {
        console.log(e.message);
    }
}

//FUNCTION FOR EDIT CLIENT USER
function FormEdit(e) {
    try {
        const datastring = {};
        datastring.UserId = e;
        AjaxSubmission(JSON.stringify(datastring), '/User/FormEdit', $('[name="__RequestVerificationToken"]').val()).done(function (data) {
            let obj = data;
            if (obj.status == true) {
                if (obj.responsecode == '100') {
                    TabShow();
                    if (obj.data.Table[0].user_image_path != null) {
                        if (obj.data.Table[0].user_image_path.length > 0) {
                            $('#UserProifilePictureFile').val(obj.data.Table[0].user_image_path);
                            $('#UserProfilePicturePreview').css('display', 'block');
                            $('#UserProfilePicturePreview').attr('src', obj.data.Table[0].user_image_path);
                        }
                    }

                    $('#UserName').val(obj.data.Table[0].user_name);
                    $('#UserEmail').val(obj.data.Table[0].login_id);
                    $('#UserPhone').val(obj.data.Table[0].phone_no);
                    $('#UserDOB').val(obj.data.Table[0].user_dob);
                    $('#PrevEntryDays').val(obj.data.Table[0].prev_entry_days);

                    if (obj.data.Table[0].is_active == true)
                        $('#Status').val(1).trigger('change');
                    else
                        $('#Status').val(0).trigger('change');


                    $('#FutureEntry').prop('checked', obj.data.Table[0].future_entry);
                    $('#HideEmail').prop('checked', obj.data.Table[0].hide_email);
                    $('#HidePhone').prop('checked', obj.data.Table[0].hide_phone);
                    $('#TrackLocationOnApp').prop('checked', obj.data.Table[0].track_location);
                    $('#LogoutPermission').prop('checked', obj.data.Table[0].LogoutPermission);
                    $('#AppLogin').prop('checked', obj.data.Table[0].AppLogin);
                    $('#AuditAccount').prop('checked', obj.data.Table[0].AuditAccount);

                    $("#SmtpEmailId").val(obj.data.Table[0].smtp_email_id);
                    $("#EmailServer").val(obj.data.Table[0].smtp_email_server);
                    $("#SmtpPort").val(obj.data.Table[0].smtp_port);

                    $('#VerifiedSsl').prop('checked', obj.data.Table[0].verified_smtp_ssl);
                    $('#EnableSsl').prop('checked', obj.data.Table[0].enable_smtp_ssl);


                    $('#Manager').val(obj.data.Table[0].manager).trigger('change');
                    $('#UserGroup').val(obj.data.Table[0].user_group).trigger('change');
                    $('#UserBranchL').val(e).trigger('change');
                    $('#VerifiedDatetime').val(obj.data.Table[0].verify_dt);
                    sc = $('#SetCompany').val();
                    /*$("#UserCompanyL").val(sc).trigger('change');*/
                }
                else 
                    Toast(RetrieveMessage(obj.responsecode), 'Message', 'error');
                
            }
            else 
                window.location.href = '/ClientLogin/ClientLogin';
            
        }).fail(function (data) {
            console.log(data.Message);           
        });
    }
    catch (e) {
        console.log(e.message);      
    }
}

//CLIENT USER UPDATE BUTTON CLICKED
$('#FormUpdate').click(function () {
    try {
        let password = document.getElementById('UserPassword');
        password.type = 'password';
        $('#eye').addClass('fa-solid fa-eye-slash');
        SuccessPwd = true;
        Action = 'update';
        RemoveAllError('myform');
        ValidateAllUserField(Action);
        if (Ercount == 0) {
            if ($('#SmtpEmailId').val().length != 0) {

                if ($('#EmailServer').val().length == 0) {
                    Toast('Please Enter Email Server !', 'Message', 'error');
                    $('#EmailServer').focus();
                    return;
                }
                if ($('#SmtpPort').val().length == 0) {
                    Toast('Please Enter SMTP Port !', 'Message', 'error');
                    $('#SmtpPort').focus();
                    return;
                }
            }

            if ($('#UserPassword').val().trim().length > 0) {
                if (!CheckPasswordPattern($('#UserPassword').val())) {
                    Toast(RetrieveMessage(988), 'Message', 'warning');
                    SuccessPwd = false;
                }
                if (SuccessPwd == true) {
                    FormUpdate();
                }
            } else {
                if (SuccessPwd == true) {
                    FormUpdate();
                }
            }
        }
    }
    catch (ex) {
        console.log(ex.message);
    }

});

// FUNCTION FOR UPDATE CLIENT USER
function FormUpdate() {
    try {
        res = true;
        if ($('#UserProifilePicture').get(0).files.length === 0) {
        } else {
            var res = ValidateUploadFileSize(UserProifilePicture, 500);
        }
        if (res == false) {
            Toast(RetrieveMessage(803), "Message", "warning");
            return;
        }

        let form = $('#myform')[0];
        let mydata = new FormData(form);

        console.log(mydata);

        AjaxSubmissionformdata(mydata, '/Master/User/FormUpdate', $('[name="__RequestVerificationToken"]').val()).done(function (result) {
            let obj = result;
            if (obj.status == true) {
                if (obj.responsecode == '107') {
                    Toast(RetrieveMessage(obj.responsecode), 'Message', 'success');                    
                    FormList(1);                   
                }
                else
                    Toast(RetrieveMessage(obj.responsecode), 'Message', 'error');
            }
            else 
                window.location.href = '/ClientLogin/ClientLogin';
        }).fail(function (result) {
            console.log(result.Message);
           
        });
    }
    catch (e) {
        console.log(e.message);
    }
}

//FUNCTION FOR DELETE USER
function FormDelete(e) {
    try {
        $.confirm({
            title: '',
            content: 'Are You Sure Want To Delete?',
            type: 'red',
            boxWidth: '300px',
            useBootstrap: false,
            typeAnimated: true,
            columnClass: 'small',
            containerFluid: true,
            draggable: true,
            buttons: {
                tryAgain: {
                    text: 'Confirm',
                    btnClass: 'btn-red',
                    action: function () {
                        const dataString = {};
                        dataString.UserId = e;
                        AjaxSubmission(JSON.stringify(dataString), '/User/FormDelete', $('[name="__RequestVerificationToken"]').val()).done(function (data) {
                            let obj = data;
                            if (obj.status == true) {
                                if (obj.responsecode == '102') {
                                    Toast(RetrieveMessage(obj.responsecode), 'Message', 'success');
                                    FormList(1);
                                }
                                else
                                    Toast(RetrieveMessage(obj.responsecode), 'Message', 'error');
                            }
                            else
                                window.location.href = '/ClientLogin/ClientLogin';
                        }).fail(function (data) {
                            console.log(data.Message);
                        });
                    }
                },
                close: function () {
                }
            }
        });
    }
    catch (e) {
        console.log(e.message);
    }
}

//FUNCTION FOR BIND CLIENT USER TABLE
function BindFormTable(result, serial_no, Permission) {

    $('#tbl_user tbody tr').remove();
    if (result.length == 0) {
        tr = $('<tr/>');
        tr.append("<td class='text-center' colspan='13'>NO RESULTS FOUND</td>");
        $("#tbl_user tbody").append(tr);
    }

    for (i = 0; i < result.length; i++) {

        if (result[i].is_active == 'Inactive')
            tr = $(' <tr style="background-color:#fdd2d2;"/>');
        else
            tr = $('<tr/>');

        tr.append("<td class='text-center'> <button type='button' onclick='FormEdit(\"" + result[i].user_id + "\");' class= 'common-btn common-btn-sm' ><i class='fa-solid fa-pen-to-square'></i></button ><button type='button' onclick='FormDelete(\"" + result[i].user_id + "\");' class= 'common-btn common-btn-sm ms-1' > <i class='fa-regular fa-trash-can'></i></button ></td > ");
        tr.append("<td class='text-left'>" + serial_no + "</td>");

        tr.append("<td class='text-left'>" + result[i].user_id + "</td>");
        tr.append("<td class='text-center'><a href='javascript:void(0)' class='text-decoration-none' style='color: black !important;' onclick='FormEdit(\"" + result[i].user_id + "\");'>" + result[i].login_id + "</a></td>");
        tr.append("<td class='text-center'>" + result[i].user_name + "</td>");
        tr.append("<td class='text-center'>" + result[i].phone_no + "</td>");

        tr.append("<td class='text-center'>" + HandleNullTextValue(result[i].created_at) + "</td>");
        tr.append("<td class='text-center'>" + HandleNullTextValue(result[i].last_updated_at) + "</td>");
        tr.append("<td class='text-center'>" + result[i].is_active + "</td>");
        tr.append("<td class='text-center'>" + HandleNullTextValue(result[i].LastActivity) + "</td>");

        let ht = "";
        if (HandleNullTextValue(result[i].login_logout) == 'login') {

            if (Permission == true)
                ht = "<td class='text-left'><span style='margin-left:45px' class='login'></span> <input type='checkbox' class='ms-2 WebLogoutCheck form-check-input' style='padding: 0px;margin: 0px;'></td>";
            else
                ht = "<td class='text-left'><span style='margin-left:45px' class='login'></span></td>";

            tr.append(ht);
        }
        else if (HandleNullTextValue(result[i].login_logout) == 'logout')
            tr.append("<td class='text-left'><span style='margin-left:45px' class='logout'></span></td>");

        tr.append("<td class='text-center'>" + HandleNullTextValue(result[i].AppLastActivity) + "</td>");


        if (HandleNullTextValue(result[i].App_login_logout) == 'login') {
            if (Permission == true)
                ht = "<td class='text-left'><span style='margin-left:45px' class='login'></span> <input type='checkbox' class='ms-2 AppLogoutCheck form-check-input' style='padding: 0px;margin: 0px;'></td>";
            else
                ht = "<td class='text-left'><span style='margin-left:45px' class='login'></span></td>";

            tr.append(ht);
        }
        else if (HandleNullTextValue(result[i].App_login_logout) == 'logout')
        
        $('#tbl_user tbody').append(tr);

        serial_no++;
    }
}

//FUNCTION FOR FILL MANAGER LIST
function FillManagerList() {
    try {      
        AjaxSubmission(null, '/User/ManagerList', $('input[name=__RequestVerificationToken]').val()).done(function (result) {
            let obj = result;
            if (obj.status == true) {
                if (obj.responsecode == '100') {
                    BindDropdown(obj.data.Table, 'Manager', 'user_id', 'user_name', '-----Select-----');
                    /*  BindDropdown(obj.data.Table, 'UserBranch', 'user_id', 'user_name', '-----Select-----');*/
                }
                else if (obj.responsecode == '604') {
                    BindDropdown(null, 'Manager', 'user_id', 'user_name', '-----Select-----');
                    /* BindDropdown(obj.data.Table, 'UserBranch', 'user_id', 'user_name', '-----Select-----');*/
                }
                else 
                    Toast(RetrieveMessage(obj.responsecode), "Message", "error");
            }
            else 
                window.location.href = '/ClientLogin/ClientLogin';
            
        }).fail(function (result) {
            console.log(result.Message);          
        });
    }
    catch (e) {
        console.log(e.message);
    }
}

//FUNCTION FOR FILL USER LIST
function FillUserList() {
    try {        
        AjaxSubmission(null, '/User/UserList', $('input[name=__RequestVerificationToken]').val()).done(function (result) {
            let obj = result;
            if (obj.status == true) {
                if (obj.responsecode == '100') 
                    BindDropdown(obj.data.Table, 'UserBranchL', 'user_id', 'user_name', '-----Select-----');
                else if (obj.responsecode == '604') 
                    BindDropdown(null, 'UserBranchL', 'user_id', 'user_name', '-----Select-----');
                else 
                    Toast(RetrieveMessage(obj.responsecode), "Message", "error");
            }
            else 
                window.location.href = '/ClientLogin/ClientLogin';
        }).fail(function (result) {
            console.log(result.Message);           
        });
    }
    catch (e) {
        console.log(e.message);
    }
}

// USER EMAIL VERIFY 
$('#User_verify').click(function () {
    if ($('#SmtpEmailId').val().length == 0) {
        Toast('Please Enter Email Id To Verify !', 'Message', 'error');
        $('#SmtpEmailId').focus();
        return;
    }
    if ($('#SmtpEmailId').val().length != 0) {
        if ($('#SmtpEmailPassword').val().length == 0) {
            Toast('Please Enter Password !', 'Message', 'error');
            $('#SmtpEmailPassword').focus();
            return;
        }

        if ($('#EmailServer').val().length == 0) {
            Toast('Please Enter Email Server !', 'Message', 'error');
            $('#EmailServer').focus();
            return;
        }
        if ($('#SmtpPort').val().length == 0) {
            Toast('Please Enter SMTP Port !', 'Message', 'error');
            $('#SmtpPort').focus();
            return;
        }
    }
    VerifyEmail();    
});

//FUNCTION FOR VERIFY EMAIL
function VerifyEmail() {
    try {
        const dataString = {};

        dataString.Email = $('#SmtpEmailId').val();
        dataString.To = $('#SmtpEmailId').val();
        dataString.Password = $('#SmtpEmailPassword').val();
        dataString.smtpPort = $('#SmtpPort').val();
        dataString.EmailServer = $('#EmailServer').val();
        dataString.VerifySSl = $('#VerifiedSsl').is(':checked');
        dataString.EnableSSL = $('#EnableSSL').is(':checked');

        ShowLoader();
        AjaxSubmission(JSON.stringify(dataString), '/User/VerifyEmail', $('input[name=__RequestVerificationToken]').val()).done(function (result) {
            let obj = result;
            if (obj.status == true) {
                if (obj.responsecode == '100') {
                    $('#VerifiedDatetime').val(obj.data);
                    Toast(RetrieveMessage(obj.responsecode), 'Message', 'success');
                }
                else
                    Toast(RetrieveMessage(obj.responsecode), 'Message', 'error');
            }
            else
                window.location.href = '/ClientLogin/ClientLogin';
            HideLoader();
        }).fail(function (result) {
            console.log(result.Message);
            HideLoader();
        });
    }
    catch (e) {
        console.log(e.message);
        HideLoader();
    }
}

//FUNCTION FOR SEND OTP
function SendOtp() {
    try {
        const dataString = {};
        dataString.EmailId = $('#UserEmail').val().trim();
       
        AjaxSubmission(JSON.stringify(dataString), '/User/SendOtp', $('input[name=__RequestVerificationToken]').val()).done(function (result) {
            let obj = result;
            if (obj.status == true) {
                if (obj.responsecode == '304') {
                    Toast(RetrieveMessage(obj.responsecode), 'Message', 'success');
                    $('#modal-small').modal('show');
                }
                else if (obj.responsecode == '602') {
                    window.location.href = '/ClientLogin/ClientLogin';
                }
                else {
                    Toast(RetrieveMessage(obj.responsecode), 'Message', 'error');
                }
            }
            else 
                window.location.href = '/ClientLogin/ClientLogin';
        }).fail(function (result) {
            console.log(result.Message);            
        });
    }
    catch (e) {
        console.log(e.message);
    }
}

////RESEND OTP CLICKED
//$("#Resend_otp").click(function () {
//    $("#User_verify").trigger("click");
//});

// CANCEL OTP CLICKED
$('#Cancel').click(function () {
    $('#Otp').val('');
    $('#modal-small').modal('hide');
})

// VERIFY OTP
$('#Verify_otp').click(function () {

    if ($('#Otp').val().trim().length <= 0)
        alert('Please Enyter Six digit OTP');
    else {
        if (($('#Otp').val().trim().length < 6)) {
            alert('Please Enyter Six digit OTP');
        }
        else {
            VerifyOtp();
        }
    }
});

//FUNCTION FOR VERIFY OTP
function VerifyOtp() {
    try {
        const dataString = {};
        dataString.Otp = $('#Otp').val().trim();
        dataString.VerifyEmail = $('#UserEmail').val().trim();
       
        AjaxSubmission(JSON.stringify(dataString), '/User/VerifyOTP', $('input[name=__RequestVerificationToken]').val()).done(function (result) {
            let obj = result;
            if (obj.status == true) {
                if (obj.responsecode == '100') {
                    Toast(RetrieveMessage(obj.responsecode), 'Message', 'success');
                    //$("#Otp").val();
                    //$("#Login_id").val($("#EmailId").val());
                    $('#modal-small').modal('hide');
                }
                else {
                    Toast(RetrieveMessage(obj.responsecode), 'Message', 'error');
                }
            }
            else 
                window.location.href = '/ClientLogin/ClientLogin';
        }).fail(function (result) {
            console.log(result.Message);          
        });
    }
    catch (e) {
        console.log(e.message);       
    }
}

// CLIENT USER ADD BUUTON CLICKED
$('#FormAdd').click(function () {
    try {
        let password = document.getElementById('UserPassword');
        password.type = 'password';
        $('#eye').addClass('fa-solid fa-eye-slash');
        SuccessPwd = true;
        Action = 'add';
        RemoveAllError('myform')
        ValidateAllUserField(Action);
        if (Ercount == 0) {
            if (!CheckPasswordPattern($('#UserPassword').val())) {
                Toast(RetrieveMessage(988), 'Message', 'warning');
                SuccessPwd = false;
            }
            if (SuccessPwd == true) {
                FormAdd();
            }
        }

    }
    catch (ex) {
        console.log(ex.message);
    }
});


//FUNCTION FOR ADD NEW CLIENT USER
function FormAdd() {
    try {      
        let form = $('#myform')[0];
        let mydata = new FormData(form);

        AjaxSubmissionformdata(mydata, '/Master/User/FormAdd', $('[name="__RequestVerificationToken"]').val()).done(function (result) {
            let obj = result;
            if (obj.status == true) {
                if (obj.responsecode == '101') {
                    Toast(RetrieveMessage(obj.responsecode), 'Message', 'success');
                    $('#FormAdd').hide();
                    $('#FormUpdate').show();
                    $('#FormReset').show();
                    $('#User-Tab').html('Edit User');
                    FormList(1);
                    FillUserList();
                }
                else {
                    Toast(RetrieveMessage(obj.responsecode), 'Message', 'error');
                }
            }
            else 
                window.location.href = '/ClientLogin/ClientLogin';
        }).fail(function (result) {
            console.log(result.Message);
        });

    }
    catch (e) {
        console.log(e.message);
    }
}


// FUNCTION FOR VALIDATE ALL USER FIELD
function ValidateAllUserField(res) {
    Ercount = 0;
    let container = document.getElementById('User');
    let ele = container.getElementsByTagName('input');
    for (i = 0; i < ele.length; i++) {
        if (res == 'add') {
            if (ele[i].type == 'text') {
                if ($(ele[i]).siblings('label').find('span').html() == "*" || ele[i].value.length > 0 || $(ele[i]).parent().siblings('label').find('span').html() == "*") {
                    $(ele[i]).trigger('blur');
                    if ($(ele[i]).hasClass('error-textbox')) {
                        Ercount = 1;
                        return;
                    }

                }

            }
            if (ele[i].type == 'password') {
                if ($(ele[i]).parent().siblings('label').find('span').html() == "*"); {
                    $(ele[i]).trigger('blur');
                    if ($(ele[i]).hasClass('error-textbox')) {
                        Ercount = 1;
                        return;
                    }
                }

            }
        }
        if (res == 'update') {
            if (ele[i].type == 'text') {
                if ($(ele[i]).siblings('label').find('span').html() == "*" || ele[i].value.length > 0 || $(ele[i]).parent().siblings('label').find('span').html() == "*") {
                    $(ele[i]).trigger('blur');
                    if ($(ele[i]).hasClass('error-textbox')) {
                        Ercount = 1;
                        return;
                    }
                }
            }

        }

    }

}

//USERBRANCHL DROPDOWN CHANGE EVENT
$('#UserBranchL').change(function () {
    $('#Btn_save_changes').css('display', 'none');
    $('#UserCompanyTable').find('tbody').remove();
    $('#UserCompanyBranchTable').find('tbody').html('');
    if ($('#UserBranchL').val() != 0) {
        $('#Btn_save_changes').css('display', 'block');
        FillClientCompanyNew($('#UserBranchL').val());
    }
});

//FUNCTION FOR RESET DATA
function ResetForm() {

    $('#UserProifilePicture,#UserProifilePictureFile').val('');
    $('#UserProfilePicturePreview').attr('src', '');
    $('#UserProfilePicturePreview').css('display', 'none');
    $('#eye').addClass('fa-solid fa-eye-slash');
    $('#UserName,#UserEmail,#UserPhone,#UserPassword,#SmtpEmailId,#SmtpEmailPassword,#EmailServer,#SmtpPort,#UserDOB,#VerifiedDatetime').val('');   
    $('#PrevEntryDays').val(0);
    $('#FutureEntry,#HideEmail,#HidePhone,#TrackLocationOnApp,#LogoutPermission,#AppLogin,#AuditAccount,#VerifiedSsl,#EnableSsl').prop('checked', false);    
   
    $('#UserCompanyTable').find('tbody').remove();
    $('#UserCompanyBranchTable').find('tbody').html('');   
    $('#UserGroup').val(0).trigger('change');
    $('#FormAdd').show();
    $('#FormUpdate,#FormReset').hide();   
    $('#User-Tab').html('Add User');

}

//FUCNTION FOR TAB SHOW
function TabShow() {
    $('#UserList-Tab').removeClass('active');
    $('#User-Tab').addClass('active');
    $('#UserList').removeClass('active show');
    $('#User').addClass('active show');
    $('#FormAdd').hide();
    $('#FormUpdate,#FormReset').show();    
    $('#User-Tab').html('Edit User');
    $('#UserName').focus();
}

//FUNCTION FOR TAB HIDE
function TabHide() {
    $('#User-Tab').removeClass('active');
    $('#UserList-Tab').addClass('active');
    $('#UserList').addClass('active show');
    $('#User').removeClass('active show');
    $('#FormAdd').show();
    $('#FormUpdate,#FormReset').hide();   
    $('#User-Tab').html('Add User');


}

//USER TAB CLICKED
$('#User-Tab').click(function () {
    $('#UserCompanyL').find('option').remove().end();
    $('#RightsTbl').empty();
    FillUserList();
    $('#Btn_save_changes').css('display', 'none');

});

//USER LIST TAB CLICKED
$('#UserList-Tab').click(function () {
    ResetForm();
    $('#UserEmail').removeClass('error-textbox');
    RemoveAllError('User');
    $('#User_id_search').focus();
    $('#UserCompanyL').find('option').remove().end();
    $('#RightsTbl').empty();
    $('#Btn_save_changes').css('display', 'none');
    FillUserList();

});

//USER BRANCH TAB CLICKED
$('#UserBranch-Tab').click(function () {
    sc = $('#SetCompany').val();
})

//FUNCTION FOR SHOW PASSWORD
function ShowPassword() {
    let password = document.getElementById('UserPassword');
    if (password.type === 'password') {
        $('#eye').addClass('fa-solid fa-eye');
        password.type = 'text';
    }
    else {
        password.type = 'password';
        $('#eye').addClass('fa-solid fa-eye-slash');
    }
}

//WEBLOGOUT BUTTON CLICKED EVENT
$('#WebLogout').click(function () {
    try {
        let ClientUserId = new Array();
        $('#tbl_user tbody tr').each(function (ind, ele) {
            if ($(ele).find('.WebLogoutCheck').is(':checked') == true) {
                ClientUserId.push($(ele).find('td:eq(2)').text());
            }
        });

        if (ClientUserId.length > 0) {
            const dataString = {};
            dataString.ClientUserId = ClientUserId;
            console.log(JSON.stringify(dataString));
            AjaxSubmission(JSON.stringify(dataString), '/Master/User/WebLogoutUser', $('input[name=__RequestVerificationToken]').val()).done(function (result) {
                let obj = result;
                if (obj.status == true) {
                    if (obj.responsecode == '100') {
                        Toast('Logout User Successfully.', 'Message', 'success');
                        setTimeout(location.reload(), 1000);

                    }
                    else
                        Toast(RetrieveMessage(obj.responsecode), 'Message', 'error');
                }
                else
                    window.location.href = '/ClientLogin/ClientLogin';
            }).fail(function (result) {
                console.log(result.Message);
            });
        }
        else
            Toast('Please select atlest one user.', 'Message', 'error');

    }
    catch (e) {
        console.log(e.message);
    }


});

//APPLOGOUT BUTTON CLICKED EVENT
$('#AppLogout').click(function () {
    try {
        let ClientUserId = new Array();
        $('#tbl_user tbody tr').each(function (ind, ele) {
            if ($(ele).find('.AppLogoutCheck ').is(':checked') == true) {
                ClientUserId.push($(ele).find('td:eq(2)').text());
            }
        });

        if (ClientUserId.length > 0) {
            const dataString = {};
            dataString.ClientUserId = ClientUserId;
            console.log(JSON.stringify(dataString));
            AjaxSubmission(JSON.stringify(dataString), '/Master/User/AppLogoutUser', $('input[name=__RequestVerificationToken]').val()).done(function (result) {
                let obj = result;
                if (obj.status == true) {
                    if (obj.responsecode == '100') {
                        Toast('Logout User Successfully.', 'Message', 'success');
                        setTimeout(function () {
                            window.location.reload();
                        }, 1000);

                    }
                    else
                        Toast(RetrieveMessage(obj.responsecode), 'Message', 'error');
                }
                else
                    window.location.href = '/ClientLogin/ClientLogin';
            }).fail(function (result) {
                console.log(result.Message);
            });
        }
        else
            Toast('Please select atlest one user.', 'Message', 'error');

    }
    catch (e) {
        console.log(e.message);
    }
});

//FUNCTION FOR LOGOUT FORCEFULLY
function LogoutForcefully(e) {
    try {
        $.confirm({
            title: '',
            content: 'Are You Sure Want To Logout?',
            type: 'red',
            boxWidth: '300px',
            useBootstrap: false,
            columnClass: 'small',
            containerFluid: true,
            typeAnimated: true,
            buttons: {
                tryAgain: {
                    text: 'Confirm',
                    btnClass: 'btn-red',
                    action: function () {
                        const datastring = {};
                        datastring.UserId = e;
                        //Showloader();
                        AjaxSubmission(JSON.stringify(datastring), '/Master/User/LogoutForcefully', $('[name="__RequestVerificationToken"]').val()).done(function (data) {
                            let obj = data;
                            if (obj.status == true) {
                                if (obj.responsecode == '1026') {
                                    Toast(RetrieveMessage(obj.responsecode), 'Message', 'success');
                                    FormList(1);
                                }
                                else
                                    Toast(RetrieveMessage(obj.responsecode), 'Message', 'error');
                            }
                            else
                                window.location.href = 'ClientLogin/ClientLogin';                           
                        }).fail(function (data) {
                            console.log(data.Message);                           
                        });
                    }
                },
                close: function () {                    
                }
            }
        });

    }
    catch (e) {
        console.log(e.message);
    }
}

//FUNCTION FOR GO TO USER GROUP
function GoToUserGroup(e) {
    SetCookie('UserGroupId', $('#' + e).val(), 's', 50);
}

$('#FormReset').click(function () {
    ResetForm();
});

//FUNCTION FOR EXPORT DATA IN EXCEL
function FormExcel() {
    ShowLoader();
    let date = new Date();
    let NewDate = ("00" + date.getDate()).slice(-2) + "_" + ("00" + (date.getMonth() + 1)).slice(-2) + "_" + date.getFullYear() + "_" + ("00" + date.getHours()).slice(-2) + "_" + ("00" + date.getMinutes()).slice(-2) + "_" + ("00" + date.getSeconds()).slice(-2);
    let fileName = "User_" + NewDate + ".xlsx";

    $('#FormSearch').trigger('click');
    AjaxSubmission(null, '/Master/User/FormExcel', $('input[name=__RequestVerificationToken]').val()).done(function (result) {
        let obj = result;
        if (obj.status == true) {
            if (obj.responsecode == '100') {

                let bytes = Base64ToBytes(obj.data.FileData[0].Base64Data);
                let blob = new Blob([bytes], { type: "application/octetstream" });
                let isIE = false || !!document.documentMode;
                if (isIE) {
                    window.navigator.msSaveBlob(blob, fileName);
                } else {
                    let url = window.URL || window.webkitURL;
                    link = url.createObjectURL(blob);
                    let a = $("<a />");
                    a.attr("download", fileName);
                    a.attr("href", link);
                    $("body").append(a);
                    a[0].click();
                    $("body").remove(a);
                }
            }
            else if (obj.responsecode == '302')
                Toast('No Records found.', 'Message', 'success');
            else
                Toast(RetrieveMessage(obj.responsecode), 'Message', 'error');

        } else
            window.location.href = '/ClientLogin/ClientLogin';
        HideLoader();

    }).fail(function (result) {
        console.log(result.Message);
        HideLoader();
    });
}

document.addEventListener("keydown", function (zEvent) {
    if (zEvent.ctrlKey && zEvent.altKey && (zEvent.key == "j" || zEvent.key == "J")) {
        $('#UserList-Tab').removeClass('active ');
        $('#UserList').removeClass('active show');
        $('#User-Tab').addClass('active');
        $('#User').addClass('active show');
        $('#FormAdd').show();
        $('#FormUpdate').hide();
        $('#FormReset').hide();
        $('#User-Tab').html('Add User');
        $('#UserName').focus();
        ResetForm();
        $('#UserEmail').removeClass('error-textbox');
        RemoveAllError('User');
        $('#User_id_search').focus();
        $('#UserCompanyL').find('option').remove().end();
        $('#RightsTbl').empty();
        $('#Btn_save_changes').css('display', 'none');
        FillUserList();
    }
});
