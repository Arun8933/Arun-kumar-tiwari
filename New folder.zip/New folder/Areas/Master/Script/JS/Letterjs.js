﻿var SelectField = [];
let DrpOption = '';

if (Get_Cookie("LetterId") != null) {
    var a = setInterval(() => {
        if (Get_Cookie("LetterId") != '' && Get_Cookie("LetterId") != 0) {
            FormEdit(Get_Cookie("LetterId"));
        } else {
            $('#Letter_list-tab').removeClass('active');
            $('#Letter-tab').addClass('active');
            $('#Letter_list').removeClass('active show');
            $('#Letter').addClass('active show');
            $("#FormAdd").show();
            $("#FormUpdate").hide();
            $("#Letter-tab").html("Add Letter");
        }
        EraseCookie('LetterId');
        clearInterval(a);
    }, 1000);
}

//DOCUMENT READY 
$(document).ready(function () {

    $("#LetterNotes").css('height', $(".scrol").height() / 1.5);
    ShowLoader();
    if (Get_Cookie("LetterId") == null)
        FillPageSizeList('ddlPageSize', FormList);
    else
        FillPageSizeList('ddlPageSize');

    FillSelectFieldList();
    $("#SelectFields").select2({ width: '100%' });
    HideLoader();
});

//LETTER MASTER LIST FUNCTION
function FormList(pageindex) {
    try {
        const dataString = {};
        dataString.PageSize = $("#ddlPageSize").val();
        dataString.PageIndex = pageindex;
        dataString.LetterId = $("#LetterIdSearch").val().trim();
        dataString.LetterName = $("#LetterNameSearch").val().trim();
        dataString.OrderBy = $("#sort-column").val().trim() + " " + $("#sort-type").val().trim();
        //ShowLoader();
        AjaxSubmission(JSON.stringify(dataString), "/Master/Letter/FormList", $('input[name=__RequestVerificationToken]').val()).done(function (result) {
            let obj = result;
            if (obj.status == true) {
                if (obj.responsecode == '100') {
                    var ser = ((parseInt(obj.data.Table1[0].PageIndex) - 1) * parseInt(obj.data.Table1[0].PageSize)) + 1;
                    BindFormTable(obj.data.Table, ser);
                    if (obj.data.Table1 != undefined && obj.data.Table1.length > 0) {
                        $(".pagination").BindPaging({
                            ActiveCssClass: "current",
                            PagerCssClass: "pager",
                            PageIndex: parseInt(obj.data.Table1[0].PageIndex),
                            PageSize: parseInt(obj.data.Table1[0].PageSize),
                            RecordCount: parseInt(obj.data.Table1[0].count)
                        });
                    }
                }
                else {
                    Toast(RetrieveMessage(obj.responsecode), "Message", "error");
                }
            }
            else {
                window.location.href = '/ClientLogin/ClientLogin';
            }
            //HideLoader();
        }).fail(function (result) {
            console.log(result.Message);
            //HideLoader();
        });
    }
    catch (e) {
        console.log(e.message);
        //HideLoader();
    }
}

//FUNCTION FOR BIND LETTER LIST TABLE
function BindFormTable(Result, SerialNo) {
    $("#TblLetter tbody tr").remove();
    if (Result.length == 0) {
        tr = $('<tr/>');
        tr.append("<td class='text-center' colspan='8'>NO RESULTS FOUND</td>");
        $("#TblLetter tbody").append(tr);
    }
    else {
        for (i = 0; i < Result.length; i++) {
            if (Result[i].is_active == "Inactive") {
                tr = $(' <tr style="background-color:#fdd2d2;"/>');
            }
            else {
                tr = $('<tr/>');
                tr.append("<td class='text-center'><button type='button' onclick='FormEdit(\"" + Result[i].LetterUid + "\");' class='common-btn common-btn-sm'><i class='fa-solid fa-pen-to-square'></i></button ><button type='button' onclick='FormDelete(\"" + Result[i].LetterUid + "\");' class='common-btn common-btn-sm ms-1'> <i class='fa-regular fa-trash-can'></i></button ></td > ");
                tr.append("<td class='text-left'>" + SerialNo + "</td>");
                tr.append("<td class='text-left'>" + Result[i].LetterUid + "</td>");
                tr.append("<td class='text-center'><a href='javascript:void(0)' class='text-decoration-none ' style='color: black !important;' onclick='FormEdit(\"" + Result[i].LetterUid + "\");'>" + Result[i].LetterName + "</a></td>");


            }
            SerialNo++;
            $("#TblLetter tbody").append(tr);
        }
    }
}

//FORM SORTING LETTER MASTER
function FormSorting(obj) {
    if (Firstcolumn != "") {
        document.getElementById(Firstcolumn).innerHTML = document.getElementById(Firstcolumn).getAttribute("data-column") + " <i class='fa-solid fa-sort'></i>";
    }
    let cn = obj.id;
    Firstcolumn = cn;
    var colname = $(obj).data("column");
    $("#sort-column").val(cn.replaceAll("_", ""));
    var sorttype = $("#sort-type").val();
    if (sorttype == "ASC") {
        $("#sort-type").val("DESC");
        $(obj).html(colname + " <i style='margin-left:10px;' class='fa-solid fa-sort-up'></i>");
    } else if (sorttype == "DESC") {
        $("#sort-type").val("ASC");
        $(obj).html(colname + " <i style='margin-left:10px;' class='fa-solid fa-sort-down'></i>");
    }
    FormList(1);
}

//FUNCTION FOR PEGINATION PREVIOUS NEXT CLICK
$(document).on("click", ".pagination .page", function () {
    FormList(($(this).attr('page')));
});

//PAGE SIZE DROPDOWN ON CHANGE
$("#ddlPageSize").change(function () {
    FormList(1);
});

//SEARCH BUTTON CLICK
$("#FormSearch").click(function () {
    FormList(1);
});

//FORM ADD CLICK FOR LETTER MASTER
$("#FormAdd").click(function () {
    if ($("#LetterName").val().length == 0) {
        Toast("Please Enter Letter Name !", "message", "error");
        return;
    }
    if ($("#LetterNotes").val().length == 0) {
        Toast("Please Add Notes !", "message", "error");
        return;
    }
    FormAdd();
});

//FUNCTION FOR FORM ADD LETTER MASTER
function FormAdd() {
    try {
        const dataString = {};
        dataString.LetterName = $("#LetterName").val();
        dataString.LetterNotes = $("#LetterNotes").val();

        ShowLoader();
        AjaxSubmission(JSON.stringify(dataString), "/Master/Letter/FormAdd", $('input[name=__RequestVerificationToken]').val()).done(function (result) {
            let obj = result;
            if (obj.status == true) {
                if (obj.responsecode == '101') {
                    Toast(RetrieveMessage(obj.responsecode), "Message", "success");
                    setTimeout(FormList(1), 1000);
                    //ResetForm();
                    //TabHide();
                    $("#FormAdd").hide();
                    $("#FormUpdate").show();
                    $("#FormReset").show();
                    $("#Letter-tab").html("Edit Letter");
                    $("#LetterId").val(obj.data.Table[0].LetterId);
                    $("#Timestamp").val(obj.data.Table[0].Timestamp);
                }
                else {
                    Toast(RetrieveMessage(obj.responsecode), "Message", "error");
                }
            }
            else {
                window.location.href = '/ClientLogin/ClientLogin';
            }
            HideLoader();
        }).fail(function (result) {
            console.log(result.Message);
            HideLoader();
        });
    }
    catch (e) {
        console.log(e.message);
        HideLoader();
    }
}

//FUNCTION FOR FORM EDIT LETTER MASTER
function FormEdit(e) {
    try {
        const datastring = {};
        datastring.LetterId = e;
        ShowLoader();
        AjaxSubmission(JSON.stringify(datastring), "/Master/Letter/FormEdit", $('[name="__RequestVerificationToken"]').val()).done(function (data) {
            let obj = data;
            if (obj.status == true) {
                if (obj.responsecode == '100') {
                    TabShow();
                    $("#Timestamp").val(obj.data.Table[0].Timestamp);
                    $("#LetterId").val(obj.data.Table[0].LetterId);
                    $("#LetterName").val(obj.data.Table[0].LetterName);
                    $("#LetterNotes").val(obj.data.Table[0].LetterNotes);

                } else {
                    Toast(RetrieveMessage(obj.responsecode), "Message", "error");
                }
            }
            else {
                window.location.href = '/ClientLogin/ClientLogin';
            }
            HideLoader();
        }).fail(function (data) {
            console.log(data.Message);
            HideLoader();
        });

    }
    catch (e) {
        console.log(e.message);
        HideLoader();
    }
}

//FORM UPDATE CLICK FOR LETTER MASTER
$("#FormUpdate").click(function () {
    if ($("#LetterName").val().length == 0) {
        Toast("Please Enter Letter Name !", "message", "error");
        return;
    }
    if ($("#LetterNotes").val().length == 0) {
        Toast("Please Add Notes !", "message", "error");
        return;
    }
    FormUpdate();
});

//FUNCTION FOR FORM UPDATE LETTER MASTER
function FormUpdate() {
    try {
        const datastring = {};
        datastring.LetterName = $("#LetterName").val();
        datastring.LetterNotes = $("#LetterNotes").val();
        datastring.LetterUid = $("#LetterId").val();
        datastring.Timestamp = $("#Timestamp").val();

        ShowLoader();
        AjaxSubmission(JSON.stringify(datastring), "/Master/Letter/FormUpdate", $('input[name=__RequestVerificationToken]').val()).done(function (result) {
            let obj = result;
            if (obj.status == true) {
                if (obj.responsecode == '107') {
                    Toast(RetrieveMessage(obj.responsecode), "Message", "success");
                    setTimeout(FormList(1), 1000);
                    $("#LetterId").val(obj.data.Table[0].LetterId);
                    $("#Timestamp").val(obj.data.Table[0].Timestamp);
                    //ResetForm();
                    //TabHide();
                }
                else {
                    Toast(RetrieveMessage(obj.responsecode), "Message", "error");
                }
            }
            else {
                window.location.href = '/ClientLogin/ClientLogin';
            }
            HideLoader();
        }).fail(function (result) {
            console.log(result.Message);
            HideLoader();

        });
    }
    catch (e) {
        console.log(e.Message);
        HideLoader();
    }
}

//FUNCTION TO INSERT FIELDS IN TEXTAREA ON CURRENT CURSOR PRESENT
function InsertInTextArea(NewText, el = document.activeElement) {
    const start = el.selectionStart
    const end = el.selectionEnd
    const text = el.value
    const before = text.substring(0, start)
    const after = text.substring(end, text.length)
    el.value = (before + NewText + after)
    el.selectionStart = el.selectionEnd = start + NewText.length
    el.focus()
}

//INSERT BUTTON CLICK TO ADD COLUMN IN TEXTAREA
$("#Insert").click(function () {
    if ($("#SelectFields").val() == "0") {
        Toast('Please Select Field To Insert !', 'Message', 'error');
    }
    else {
        $("#LetterNotes").focus();
        var SelectFields = $("#SelectFields").val();
        InsertInTextArea(SelectFields);
    }

});

//FUNCTION FOR DELETE LETTER MASTER 
function FormDelete(e) {
    try {
        $.confirm({
            title: '',
            content: 'Are You Sure Want To Delete ?',
            type: 'red',
            boxWidth: '300px',
            useBootstrap: false,
            columnClass: 'small',
            containerFluid: true,
            typeAnimated: true,
            buttons: {
                tryAgain: {
                    text: 'Confirm',
                    btnClass: 'btn-red',
                    action: function () {
                        const datastring = {};
                        datastring.LetterId = parseInt(e);
                        ShowLoader();
                        AjaxSubmission(JSON.stringify(datastring), "/Master/Letter/FormDelete", $('[name="__RequestVerificationToken"]').val()).done(function (data) {
                            let obj = data;
                            if (obj.status == true) {
                                if (obj.responsecode == '102') {
                                    Toast(RetrieveMessage(obj.responsecode), "Message", "success");
                                    FormList(1);
                                }
                                else {
                                    Toast(RetrieveMessage(obj.responsecode), "Message", "error");
                                }
                            }
                            else {
                                window.location.href = 'ClientLogin/ClientLogin';
                            }
                            HideLoader();
                        }).fail(function (data) {
                            console.log(data.Message);
                            HideLoader();
                        });
                    }
                },
                close: function () {

                }
            }
        });
    }
    catch (e) {
        console.log(e.message);
        HideLoader();
    }
}

//FUNCTION FOR BIND SELECT FIELD DROPDOWN 
function FillSelectFieldList() {
    try {
        //ShowLoader();
        AjaxSubmission(null, "/Master/Letter/GetSelectFields", $('input[name=__RequestVerificationToken]').val()).done(function (result) {
            let obj = result;
            SelectField.push(obj.data[0].SelectFields.split(","));
            if (obj.status == true) {
                if (obj.responsecode == '100') {
                    DrpOption = '<option value="0">---Select---</option>';
                    for (var i = 0; i < SelectField[0].length; i++) {
                        DrpOption += '<option value="{{' + SelectField[0][i] + '}}">' + SelectField[0][i] + '</option>';
                    }
                    $('#SelectFields').append(DrpOption);
                }
                else {
                    Toast(RetrieveMessage(obj.responsecode), "Message", "error");
                }
                //setTimeout(FormList(1), 1000);
            }
            else {
                window.location.href = '/ClientLogin/ClientLogin';
            }
            //HideLoader();
        }).fail(function (result) {
            console.log(result.Message);
            //HideLoader();
        });
    }
    catch (e) {
        console.log(e.message);
        //HideLoader();
    }
}

//FUNCTION FOR TAB HIDE
function TabShow() {
    $('#Letter_list-tab').removeClass('active');
    $('#Letter-tab').addClass('active');
    $('#Letter_list').removeClass('active show');
    $('#Letter').addClass('active show');
    $("#FormAdd").hide();
    $("#FormUpdate").show();
    $("#FormReset").show();
    $("#Letter-tab").html("Edit Letter");
}

//FUNCTION FOR TAB HIDE
function TabHide() {
    $('#Letter-tab').removeClass('active');
    $('#Letter_list-tab').addClass('active ');
    $('#Letter_list').addClass('active show');
    $('#Letter').removeClass('active show');
    $("#FormAdd").show();
    $("#FormUpdate").hide();
    $("#FormReset").hide();
    $("#Letter-tab").html("Add Letter");
}

//LETTER MASTER LIST TAB ON CLICK 
$('#Letter_list-tab').click(function () {
    ResetForm();
    RemoveAllError('Letter');
});

//FUNCTION FOR RESET DATA
function ResetForm() {
    $("#LetterId").val('');
    $("#LetterName").val('');
    $("#LetterNotes").val('');
    $("#SelectFields").val('0').trigger('change');

    $("#FormAdd").show();
    $("#FormUpdate").hide();
    $("#FormReset").hide();
    $("#Letter-tab").html("Add Letter");
    $("#LetterId").val('');
    $("#Timestamp").val('');
}

$("#FormReset").click(function () {
    ResetForm();
})

document.addEventListener("keydown", function (zEvent) {
    if (zEvent.ctrlKey && zEvent.altKey && (zEvent.key == "j" || zEvent.key == "J")) {
        $('#Letter_list-tab').removeClass('active ');
        $('#Letter_list').removeClass('active show');
        $('#Letter-tab').addClass('active');
        $('#Letter').addClass('active show');
        $("#FormAdd").show();
        $("#FormUpdate").hide();
        $("#FormReset").hide();
        $("#Letter-tab").html("Add Letter ");
        $('#LetterName').focus();
        ResetForm();

    }
});