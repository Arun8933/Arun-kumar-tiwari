﻿var Firstcolumn = "";
//if (Get_Cookie("GroupId") != null) {
//    var a = setInterval(() => {
//        if ($("#GroupBehaviour").val() != null) {
//            if (Get_Cookie("GroupId") != '' && Get_Cookie("GroupId") != 0) {
//                FormEdit(Get_Cookie("GroupId"));
//            } else {
//                $('#GroupHead_list-tab').removeClass('active');
//                $('#GroupHead-tab').addClass('active');
//                $('#GroupHead_list').removeClass('active show');
//                $('#GroupHead').addClass('active show');
//                $("#FormAdd").show();
//                $("#FormUpdate").hide();
//                $("#GroupHead-tab").html("Add Group");
//            }
//            EraseCookie('GroupId');
//            clearInterval(a);
//        }
//    }, 1000);
//}
//DOCUMENT READY FUNCTION
$(document).ready(function () {
    //ShowLoader();
    //if (Get_Cookie("GroupId") == null)
    //    FillPageSizeList('ddlPageSize', FormList);
    //else
    //    FillPageSizeList('ddlPageSize');

    FillPageSizeList('ddlPageSize', FormList);
    $("#GroupBehaviour").select2({ width: '100%' });
    $("#SearchGroupId").focus();
    HideLoader();
});

//GROUP LIST FUNCTION
function FormList(pageindex) {
    try {
        const dataString = {};
        dataString.PageSize = $("#ddlPageSize").val();
        dataString.PageIndex = pageindex;
        dataString.GroupId = $("#SearchGroupId").val().trim();
        dataString.GroupName = $("#SearchGroupName").val().trim();
        dataString.OrderBy = $("#sort-column").val().trim() + " " + $("#sort-type").val().trim();
        //Showloader();
        AjaxSubmission(JSON.stringify(dataString), "/Master/GroupHeads/FormList", $('input[name=__RequestVerificationToken]').val()).done(function (result) {
            let obj = result;
            if (obj.status == true) {
                if (obj.responsecode == '100') {
                    var ser = ((parseInt(obj.data.Table1[0].PageIndex) - 1) * parseInt(obj.data.Table1[0].PageSize)) + 1;
                    BindFormTable(obj.data.Table, ser);
                    if (obj.data.Table1 != undefined && obj.data.Table1.length > 0) {
                        $(".pagination").BindPaging({
                            ActiveCssClass: "current",
                            PagerCssClass: "pager",
                            PageIndex: parseInt(obj.data.Table1[0].PageIndex),
                            PageSize: parseInt(obj.data.Table1[0].PageSize),
                            RecordCount: parseInt(obj.data.Table1[0].count)
                        });
                    }
                }
                else {
                    Toast(RetrieveMessage(obj.responsecode), "Message", "error");
                }
            }
            else {
                window.location.href = '/ClientLogin/ClientLogin';
            }
            //Hideloader();
        }).fail(function (result) {
            console.log(result.Message);
            //Hideloader();
        });
    }
    catch (e) {
        console.log(e.message);
        //Hideloader();
    }
}

//FUNCTION FOR BIND GROUP HEAD TABLE
function BindFormTable(Result, SerialNo) {
    $("#TblGroup tbody tr").remove();
    if (Result.length == 0) {
        tr = $('<tr/>');
        tr.append("<td class='text-center' colspan='8'>NO RESULTS FOUND</td>");
        $("#TblGroup tbody").append(tr);
    }
    else {
        for (i = 0; i < Result.length; i++) {
            if (Result[i].is_active == "Inactive") {
                tr = $(' <tr style="background-color:#fdd2d2;"/>');
            }
            else {
                tr = $('<tr/>');

                tr.append("<td class='text-center'><button type='button' onclick='FormEdit(\"" + Result[i].GroupHeadUid + "\");' class='common-btn common-btn-sm'><i class='fa-solid fa-pen-to-square'></i></button ><button type='button' onclick='FormDelete(\"" + Result[i].GroupHeadUid + "\");' class='common-btn common-btn-sm ms-1'> <i class='fa-regular fa-trash-can'></i></button ></td > ");
                tr.append("<td class='text-left'>" + SerialNo + "</td>");
                tr.append("<td class='text-left'>" + Result[i].GroupHeadUid + "</td>");
                tr.append("<td class='text-center'><a href='javascript:void(0)' class='text-decoration-none ' style='color: black !important;' onclick='FormEdit(\"" + Result[i].GroupHeadUid + "\");'>" + Result[i].GroupHeadName + "</a></td>");


            }
            SerialNo++;
            $("#TblGroup tbody").append(tr);
        }
    }
}

//FUNCTION FOR PEGINATION PREVIOUS NEXT CLICK
$(document).on("click", ".pagination .page", function () {
    FormList(($(this).attr('page')));
});

//PAGE SIZE DROPDOWN ON CHANGE
$("#ddlPageSize").change(function () {
    FormList(1);
});

//SEARCH BUTTON CLICK
$("#FormSearch").click(function () {
    FormList(1);
});

function FormSorting(obj) {
    if (Firstcolumn != "") {
        document.getElementById(Firstcolumn).innerHTML = document.getElementById(Firstcolumn).getAttribute("data-column") + " <i class='fa-solid fa-sort'></i>";
    }
    let cn = obj.id;
    Firstcolumn = cn;
    var colname = $(obj).data("column");
    $("#sort-column").val(cn.replaceAll("_", ""));
    var sorttype = $("#sort-type").val();
    if (sorttype == "ASC") {
        $("#sort-type").val("DESC");
        $(obj).html(colname + " <i style='margin-left:10px;' class='fa-solid fa-sort-up'></i>");
    } else if (sorttype == "DESC") {
        $("#sort-type").val("ASC");
        $(obj).html(colname + " <i style='margin-left:10px;' class='fa-solid fa-sort-down'></i>");
    }
    FormList(1);
}

//GROUP ADD BUTTON CLICK
$("#FormAdd").click(function () {
    RemoveAllError('GroupHead');
    ValidateAllFieldNewTest('GroupHead');

    if (Ercount == 0) {
        if ($("#GroupBehaviour").val() == "0") {
            Toast(RetrieveMessage(709), 'Message', 'error');
            return;
        }
        FormAdd();
    }

});

//ADD GROUP FUNCTION
function FormAdd() {
    try {
        const datastring = {};
        datastring.GroupName = $("#GroupName").val();
        datastring.GroupBehaviour = $("#GroupBehaviour").val();
        datastring.OrderPlBs = $("#OrderNo").val();
        ShowLoader();
        AjaxSubmission(JSON.stringify(datastring), "/Master/GroupHeads/FormAdd", $('input[name=__RequestVerificationToken]').val()).done(function (result) {
            let obj = result;
            if (obj.status == true) {
                if (obj.responsecode == '101') {
                    Toast(RetrieveMessage(obj.responsecode), "Message", "success");
                    setTimeout(FormList(1), 1000);
                    $("#FormAdd").hide();
                    $("#FormUpdate").show();
                    $("#FormReset").show();
                    $("#GroupHead-tab").html("Edit Group");
                    $("#GroupId").val(obj.data.Table[0].GroupHeadId);
                    $("#Timestamp").val(obj.data.Table[0].Timestamp);
                }
                else {
                    Toast(RetrieveMessage(obj.responsecode), "Message", "error");
                }
            }
            else {
                window.location.href = '/ClientLogin/ClientLogin';
            }
            HideLoader();
        }).fail(function (result) {
            console.log(result.Message);
            HideLoader();
        });
    }
    catch (e) {
        console.log(e.message);
        HideLoader();
    }
}

//EDIT GROUP FUNCTION 
function FormEdit(e) {
    try {
        ShowLoader();
        const datastring = {};
        datastring.GroupId = e;
        AjaxSubmission(JSON.stringify(datastring), "/Master/GroupHeads/FormEdit", $('[name="__RequestVerificationToken"]').val()).done(function (data) {
            let obj = data;
            if (obj.status == true) {
                if (obj.responsecode == '100') {
                    TabShow();
                    if (obj.data.Table[0].SystemAccount == true) {
                        $("#GroupName").attr("disabled", "disabled");
                    }
                    $("#GroupId").val(obj.data.Table[0].GroupHeadId);
                    $("#Timestamp").val(obj.data.Table[0].Timestamp);
                    $("#GroupName").val(obj.data.Table[0].GroupHeadName);
                    $("#GroupBehaviour").val(obj.data.Table[0].GroupBehaviour).trigger('change');
                    $("#OrderNo").val(obj.data.Table[0].OrderPLBS);
                } else {
                    Toast(RetrieveMessage(obj.responsecode), "Message", "error");
                }
            }
            else {
                window.location.href = '/ClientLogin/ClientLogin';
            }
            HideLoader();
        }).fail(function (data) {
            console.log(data.Message);
            HideLoader();
        });

    }
    catch (e) {
        console.log(e.message);
        HideLoader();
    }
}

//GROUP UPDATE BUTTON CLICK
$("#FormUpdate").click(function () {
    RemoveAllError('GroupHead');

    ValidateAllFieldNewTest('GroupHead');

    if (Ercount == 0) {
        if ($("#GroupBehaviour").val() == "0") {
            Toast(RetrieveMessage(709), 'Message', 'error');
            return;
        }
        FormUpdate();
    }
});

//UPDATE GROUP FUNCTION
function FormUpdate() {
    try {
        const datastring = {};
        datastring.GroupName = $("#GroupName").val();
        datastring.GroupBehaviour = $("#GroupBehaviour").val();
        datastring.OrderPlBs = $("#OrderNo").val();
        datastring.GroupId = $("#GroupId").val();
        datastring.Timestamp = $("#Timestamp").val();
        ShowLoader();
        AjaxSubmission(JSON.stringify(datastring), "/Master/GroupHeads/FormUpdate", $('input[name=__RequestVerificationToken]').val()).done(function (result) {
            let obj = result;
            if (obj.status == true) {
                if (obj.responsecode == '107') {
                    Toast(RetrieveMessage(obj.responsecode), "Message", "success");
                    FormList(1);
                    $("#GroupId").val(obj.data.Table[0].GroupHeadId);
                    $("#Timestamp").val(obj.data.Table[0].Timestamp);
                }
                else {
                    Toast(RetrieveMessage(obj.responsecode), "Message", "error");
                }
            }
            else {
                window.location.href = '/ClientLogin/ClientLogin';
            }
            HideLoader();
        }).fail(function (result) {
            console.log(result.Message);
            HideLoader();

        });
    }
    catch (e) {
        console.log(e.Message);
        HideLoader();
    }
}

//DELETE GROUP FUNCTION
function FormDelete(e) {
    try {
        $.confirm({
            title: '',
            content: 'Are You Sure Want To Delete ?',
            type: 'red',
            boxWidth: '300px',
            useBootstrap: false,
            columnClass: 'small',
            containerFluid: true,
            typeAnimated: true,
            buttons: {
                tryAgain: {
                    text: 'Confirm',
                    btnClass: 'btn-red',
                    action: function () {
                        const datastring = {};
                        datastring.GroupId = parseInt(e);
                        ShowLoader();
                        AjaxSubmission(JSON.stringify(datastring), "/Master/GroupHeads/FormDelete", $('[name="__RequestVerificationToken"]').val()).done(function (data) {
                            let obj = data;
                            if (obj.status == true) {
                                if (obj.responsecode == '102') {
                                    Toast(RetrieveMessage(obj.responsecode), "Message", "success");
                                    FormList(1);
                                }
                                else {
                                    Toast(RetrieveMessage(obj.responsecode), "Message", "error");
                                }
                            }
                            else {
                                window.location.href = 'ClientLogin/ClientLogin';
                            }
                            HideLoader();
                        }).fail(function (data) {
                            console.log(data.Message);
                            HideLoader();
                        });
                    }
                },
                close: function () {

                }
            }
        });
    }
    catch (e) {
        console.log(e.message);
        HideLoader();
    }
}

//FUNCTION FOR EXPORT DATA IN EXCEL
function FormExcel() {
    ShowLoader();
    let date = new Date();
    let NewDate = ("00" + date.getDate()).slice(-2) + "_" + ("00" + (date.getMonth() + 1)).slice(-2) + "_" + date.getFullYear() + "_" + ("00" + date.getHours()).slice(-2) + "_" + ("00" + date.getMinutes()).slice(-2) + "_" + ("00" + date.getSeconds()).slice(-2);
    let fileName = "GroupHeads_" + NewDate + ".xlsx";

    $('#FormSearch').trigger('click');
    AjaxSubmission(null, '/Master/GroupHeads/FormExcel', $('input[name=__RequestVerificationToken]').val()).done(function (result) {
        let obj = result;
        if (obj.status == true) {
            if (obj.responsecode == '100') {

                let bytes = Base64ToBytes(obj.data.FileData[0].Base64Data);
                let blob = new Blob([bytes], { type: "application/octetstream" });
                let isIE = false || !!document.documentMode;
                if (isIE) {
                    window.navigator.msSaveBlob(blob, fileName);
                } else {
                    let url = window.URL || window.webkitURL;
                    link = url.createObjectURL(blob);
                    let a = $("<a />");
                    a.attr("download", fileName);
                    a.attr("href", link);
                    $("body").append(a);
                    a[0].click();
                    $("body").remove(a);
                }
            }
            else if (obj.responsecode == '302')
                Toast("No Records found.", 'Message', 'success');
            else
                Toast(RetrieveMessage(obj.responsecode), 'Message', 'error');

        } else
            window.location.href = '/ClientLogin/ClientLogin';
        HideLoader();

    }).fail(function (result) {
        console.log(result.Message);
        HideLoader();
    });
}

//FUNCTION FOR TAB HIDE
function TabShow() {
    $('#GroupHead_list-tab').removeClass('active');
    $('#GroupHead-tab').addClass('active');
    $('#GroupHead_list').removeClass('active show');
    $('#GroupHead').addClass('active show');
    $("#FormAdd").hide();
    $("#FormUpdate").show();
    $("#FormReset").show();
    $("#GroupHead-tab").html("Edit Group");
}

//FUNCTION FOR TAB HIDE
function TabHide() {
    $('#GroupHead-tab').removeClass('active');
    $('#GroupHead_list-tab').addClass('active ');
    $('#GroupHead_list').addClass('active show');
    $('#GroupHead').removeClass('active show');
    $("#FormAdd").show();
    $("#FormUpdate").hide();
    $("#FormReset").hide();
    $("#GroupHead-tab").html("Add Group");
}

//GROUP HEADS LIST TAB ON CLICK 
$('#GroupHead_list-tab').click(function () {
    ResetForm();
    TabHide();
    RemoveAllError('GroupHead');
});

//FUNCTION FOR RESET DATA
function ResetForm() {
    $("#FormAdd").show();
    $("#FormUpdate").hide();
    $("#FormReset").hide();
    $("#GroupId").val('');
    $("#GroupName").val('');
    $("#GroupName").removeAttr("disabled");
    $("#GroupBehaviour").val('0').trigger('change');
    $("#OrderNo").val('');
}
$('#GroupHead-tab').click(function () {
    $("#GroupHead").find('.GroupName').click();
});
$(".GroupHead_list").click(function () {
    $("#SearchGroupId").focus();
});
$("#FormReset").click(function () {
    $("#GroupHead-tab").html("Add Group");
    ResetForm();
})


document.addEventListener("keydown", function (zEvent) {
    if (zEvent.ctrlKey && zEvent.altKey && (zEvent.key == "j" || zEvent.key == "J")) {
        $('#GroupHead_list-tab').removeClass('active ');
        $('#GroupHead_list').removeClass('active show');
        $('#GroupHead-tab').addClass('active');
        $('#GroupHead').addClass('active show');
        $("#FormAdd").show();
        $("#FormUpdate").hide();
        $("#FormReset").hide();
        $("#GroupHead-tab").html("Add Group ");
        ResetForm();
        $('#GroupName').focus();
    }
});
