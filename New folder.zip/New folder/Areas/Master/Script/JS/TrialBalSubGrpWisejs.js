﻿var Cnt;
// DOCUMENT ON READY FUNCTION
$(document).ready(function () {
    GetFinancialYearDate();
    $(".datepickerAll").datepicker({
        changeMonth: true,
        changeYear: true,
        dateFormat: 'dd/mm/yy'
    });
    FillBranchList('SelectBranchTrialSubGrp', false);
    $("#SelectBranchTrialSubGrp").select2({
        width: '100%'
    });
    //DATEPICKER FOR SEARCHJOBDATEFROM AND SEARCHJOBDATETO
    $('#DateFromTrialSubGrp,#DateToTrialSubGrp').datepicker({
        toolbarPlacement: "bottom",
        showButtonPanel: true,
        changeMonth: true,
        changeYear: true,
        dateFormat: 'dd/mm/yy',
        onClose: function () {
            if ($('#DateFromTrialSubGrp').val().length == 10 || $('#DateToTrialSubGrp').val().length == 10)
                CompareSearchDate($('#DateFromTrialSubGrp').val(), $('#DateToTrialSubGrp').val(), 'SearchDate');
        }
    });
})


//SEARCH ARROW UP/DOWN
$("#Arrow").click(function () {
    if (srbtn == 'up') {
        $("#icn").html("<i class='fa-solid fa-angle-down'></i>");
        srbtn = 'down';
    } else {
        $("#icn").html("<i class='fa-solid fa-angle-up'></i>");
        srbtn = 'up';
    }
});
//FUNCTION FOR GET FINANCIAL YEAR DATE
function GetFinancialYearDate() {
    try {
        AjaxSubmission(null, '/_Layout/GetFinancialYearDate', $('[name="__RequestVerificationToken"]').val()).done(function (result) {
            let obj = result;
            console.log(obj)
            if (obj.status == true) {
                if (obj.responsecode == '100') {
                    $("#DateFromTrialSubGrp").val(obj.data.Table[0].finyr_start_date);
                    $("#DateToTrialSubGrp").val(obj.data.Table[0].finyr_end_date);
                }
            }
            else
                window.location.href = '/ClientLogin/ClientLogin';
            HideLoader();
        }).fail(function (result) {
            HideLoader();
            console.log(result.message);
        });
        HideLoader();
    }
    catch (e) {
        HideLoader();
        console.log(e.message);
    }
}

$("#FormSearch").click(function () {

    var flag = 0;
    var FromDate = $("#DateFromTrialSubGrp").val();
    var ToDate = $("#DateToTrialSubGrp").val();
    if (FromDate == "") {
        Toast("Please Enter Date From", "Message", "error");
        flag = 1;
        return false;
    }
    if (ToDate == "") {
        Toast("Please Enter Date To", "Message", "error");
        flag = 1;
        return false;
    }
    if (FromDate > ToDate) {
        Toast("To Date Must Be Greater Than From Date!", "Message", "error");
        flag = 1;
        return false;
    }
    if (ToDate < FromDate) {
        Toast("To Date Must Be Greater Than From Date!", "Message", "error");
        flag = 1;
        return false;
    }
    if (flag == 0) {
        $("#showtrpdf").show();
        $(".ReportDNone").show();
        FormList();
    }

});
//FUNCTION FOR FILL TRIAL BALANCE LIST
function FormList() {
    try {
        const dataString = {};
        dataString.FromDate = $("#DateFromTrialSubGrp").val();
        dataString.ToDate = $("#DateToTrialSubGrp").val();
        dataString.BranchUid = $("#SelectBranchTrialSubGrp").val();
        ShowLoader();
        AjaxSubmission(JSON.stringify(dataString), "/Master/TrialBalSubGrpWise/FormList", $('input[name=__RequestVerificationToken]').val()).done(function (result) {
            let obj = result;
            console.log(obj);
            if (obj.status == true) {
                if (obj.responsecode == '100') {
                    BindFormTable(obj.data.Table);
                }
                else
                    Toast(RetrieveMessage(obj.responsecode), "Message", "error");
            }
            else
                window.location.href = '/ClientLogin/ClientLogin';
            HideLoader();
        }).fail(function (result) {
            console.log(result.Message);
            HideLoader();
        });
    }
    catch (e) {
        console.log(e.message);
        HideLoader();
    }
}


//FUNCTION FOR BIND LETTER LIST TABLE
function BindFormTable(Result) {
    $("#tbl_TrialBalanceSubGrp tbody tr").remove();
    if (Result.length == 0) {
        tr = $('<tr/>');
        tr.append("<td class='text-center' colspan='11'>NO RESULTS FOUND</td>");
        $("#tbl_TrialBalanceSubGrp tbody").append(tr);
    }
    for (i = 0; i < Result.length; i++) {
        tr = $('<tr/>');
        if (Result[i].Type == 'G') {
            tr.append("<td class='text-left'>" + HandleNullTextValue(Result[i].Particular) + "</td>");
            tr.append("<td class='text-end'>" + HandleNullTextValue(Result[i].OpBalDr) + "</td>");
            tr.append("<td class='text-end'>" + HandleNullTextValue(Result[i].OpBalCr) + "</td>");
            tr.append("<td class='text-end'>" + HandleNullTextValue(Result[i].CurrDebit) + "</td>");
            tr.append("<td class='text-end'>" + HandleNullTextValue(Result[i].CurrCredit) + "</td>");
            tr.append("<td class='text-end'>" + HandleNullTextValue(Result[i].TotalBalDr) + "</td>");
            tr.append("<td class='text-end'>" + Math.abs(HandleNullTextValue(Result[i].TotalBalCr)) + "</td>");

        }
        if (Result[i].Type == 'SG') {
            tr.append("<td  class='text-left px-3 ' style='color:#355089 !important'>" + HandleNullTextValue(Result[i].Particular) + "</td>");
            tr.append("<td class='text-end'>" + HandleNullTextValue(Result[i].OpBalDr) + "</td>");
            tr.append("<td class='text-end'>" + HandleNullTextValue(Result[i].OpBalCr) + "</td>");
            tr.append("<td class='text-end'>" + HandleNullTextValue(Result[i].CurrDebit) + "</td>");
            tr.append("<td class='text-end'>" + HandleNullTextValue(Result[i].CurrCredit) + "</td>");
            tr.append("<td class='text-end'>" + HandleNullTextValue(Result[i].TotalBalDr) + "</td>");
            tr.append("<td class='text-end'>" + Math.abs(HandleNullTextValue(Result[i].TotalBalCr)) + "</td>");
        }
        if ((Result[i].Type == 'LG') && (Result[i].DetailedPLBS == 1)) {
            tr.append("<td class='text-left px-4 '>" + HandleNullTextValue(Result[i].Particular) + "</td>");
            tr.append("<td class='text-end'>" + HandleNullTextValue(Result[i].OpBalDr) + "</td>");
            tr.append("<td class='text-end'>" + HandleNullTextValue(Result[i].OpBalCr) + "</td>");
            tr.append("<td class='text-end'>" + HandleNullTextValue(Result[i].CurrDebit) + "</td>");
            tr.append("<td class='text-end'>" + HandleNullTextValue(Result[i].CurrCredit) + "</td>");
            tr.append("<td class='text-end'>" + HandleNullTextValue(Result[i].TotalBalDr) + "</td>");
            tr.append("<td class='text-end'>" + Math.abs(HandleNullTextValue(Result[i].TotalBalCr)) + "</td>");

        }
        if (Result[i].Type == 'DF') {
            tr.append("<td class='text-left px-4 '>" + HandleNullTextValue(Result[i].Particular) + "</td>");
            tr.append("<td class='text-end'>" + HandleNullTextValue(Result[i].OpBalDr) + "</td>");
            tr.append("<td class='text-end'>" + HandleNullTextValue(Result[i].OpBalCr) + "</td>");
            tr.append("<td class='text-end'>" + HandleNullTextValue(Result[i].CurrDebit) + "</td>");
            tr.append("<td class='text-end'>" + HandleNullTextValue(Result[i].CurrCredit) + "</td>");
            tr.append("<td class='text-end'>" + HandleNullTextValue(Result[i].TotalBalDr) + "</td>");
            tr.append("<td class='text-end'>" + Math.abs(HandleNullTextValue(Result[i].TotalBalCr)) + "</td>");
        }
        if (Result[i].Type == 'TL') {
            tr.append("<td class='text-end'><b>" + HandleNullTextValue(Result[i].Particular) + " </b></td>");
            tr.append("<td class='text-end'><b>" + HandleNullTextValue(Result[i].OpBalDr) + "   </b></td>");
            tr.append("<td class='text-end'><b>" + HandleNullTextValue(Result[i].OpBalCr) + "   </b></td>");
            tr.append("<td class='text-end'><b>" + HandleNullTextValue(Result[i].CurrDebit) + " </b></td>");
            tr.append("<td class='text-end'><b>" + HandleNullTextValue(Result[i].CurrCredit) + "</b></td>");
            tr.append("<td class='text-end'><b>" + HandleNullTextValue(Result[i].TotalBalDr) + "</b></td>");
            tr.append("<td class='text-end'><b>" + HandleNullTextValue(Math.abs(Result[i].TotalBalCr)) + "</b></td>");
        }


        //tr.append("<td class='text-end'>" + HandleNullTextValue(Result[i].OpeningBalDr) + "</td>");
        //tr.append("<td class='text-end'>" + HandleNullTextValue(Result[i].OpeningBalCr) + "</td>");
        //tr.append("<td class='text-end'>" + HandleNullTextValue(Result[i].CurrDebit) + "</td>");
        //tr.append("<td class='text-end'>" + HandleNullTextValue(Result[i].CurrCredit) + "</td>");
        //tr.append("<td class='text-end'>" + HandleNullTextValue(Result[i].TotalBalDr) + "</td>");
        //tr.append("<td class='text-end'>" + Math.abs(HandleNullTextValue(Result[i].TotalBalCr)) + "</td>");
        $("#tbl_TrialBalanceSubGrp tbody").append(tr);
    }
}




//ON CLICK FUNCTION FOR PDF
$("#TrialBalanceGrpPDF").click(function () {
    try {
        const dataString = {};
        dataString.FromDate = $("#DateFromTrialSubGrp").val();
        dataString.ToDate = $("#DateToTrialSubGrp").val();
        dataString.BranchUid = $("#SelectBranchTrialSubGrp").val();
        ShowLoader();
        AjaxSubmission(JSON.stringify(dataString), "/Master/TrialBalSubGrpWise/GetGrpWiseTrialBalReport", $('input[name=__RequestVerificationToken]').val()).done(function (result) {
            let obj = result;
            console.log(obj);
            if (obj.status == true) {
                if (obj.responsecode == '100') {
                    window.open($("#MyReport").attr('href'), '_blank');
                }
                else
                    Toast(RetrieveMessage(obj.responsecode), "Message", "error");
            }
            else
                window.location.href = '/ClientLogin/ClientLogin';
            HideLoader();
        }).fail(function (result) {
            console.log(result.Message);
            HideLoader();
        });
    }
    catch (e) {
        console.log(e.message);
        HideLoader();
    }
});


//FUNCTION FOR EXPORT DATA IN EXCEL
function FormExcel() {
    debugger;
    ShowLoader();
    let date = new Date();
    let NewDate = ("00" + date.getDate()).slice(-2) + "_" + ("00" + (date.getMonth() + 1)).slice(-2) + "_" + date.getFullYear() + "_" + ("00" + date.getHours()).slice(-2) + "_" + ("00" + date.getMinutes()).slice(-2) + "_" + ("00" + date.getSeconds()).slice(-2);
    let fileName = "TrailBalGroupwise_" + NewDate + ".xlsx";

    $('#FormSearch').trigger('click');
    AjaxSubmission(null, '/Master/TrialBalSubGrpWise/FormExcel', $('input[name=__RequestVerificationToken]').val()).done(function (result) {
        let obj = result;
        if (obj.status == true) {
            if (obj.responsecode == '100') {

                let bytes = Base64ToBytes(obj.data.FileData[0].Base64Data);
                let blob = new Blob([bytes], { type: "application/octetstream" });
                let isIE = false || !!document.documentMode;
                if (isIE) {
                    window.navigator.msSaveBlob(blob, fileName);
                } else {
                    let url = window.URL || window.webkitURL;
                    link = url.createObjectURL(blob);
                    let a = $("<a />");
                    a.attr("download", fileName);
                    a.attr("href", link);
                    $("body").append(a);
                    a[0].click();
                    $("body").remove(a);
                }
            }
            else if (obj.responsecode == '302')
                Toast('No Records found.', 'Message', 'success');
            else
                Toast(RetrieveMessage(obj.responsecode), 'Message', 'error');

        } else
            window.location.href = '/ClientLogin/ClientLogin';
        HideLoader();

    }).fail(function (result) {
        console.log(result.Message);
        HideLoader();
    });
}

