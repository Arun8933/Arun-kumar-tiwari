﻿$(document).ready(function () {
    FillPageSizeList('ddlPageSize', FormList);
    $(".datepickerAll").datepicker({
        changeMonth: true,
        changeYear: true,
        dateFormat: 'dd/mm/yy',
        toolbarPlacement: "bottom",
        showButtonPanel: true,
    });
});
//PAGINATION BUTTON PREVEIOUS NEXT CLICK
$(document).on("click", ".pagination .page", function () {
    FormList(($(this).attr('page')));
});

//PAGE SIZE DROPDOWN ON CHANGE
$("#ddlPageSize").change(function () {
    FormList(1);
});

//SEARCH BUTTON CLICK
$("#FormSearch").click(function () {
    FormList(1);
});
//FUNCTION FOR FORM SORTING
function FormSorting(obj) {
    if (Firstcolumn != "") {
        document.getElementById(Firstcolumn).innerHTML = document.getElementById(Firstcolumn).getAttribute("data-column") + " <i class='fa-solid fa-sort'></i>";
    }
    let cn = obj.id;
    Firstcolumn = cn;
    var colname = $(obj).data("column");
    $("#sort-column").val(cn.replaceAll("_", ""));
    var sorttype = $("#sort-type").val();
    if (sorttype == "ASC") {
        $("#sort-type").val("DESC");
        $(obj).html(colname + " <i style='margin-left:10px;' class='fa-solid fa-sort-down'></i>");
    } else if (sorttype == "DESC") {
        $("#sort-type").val("ASC");
        $(obj).html(colname + " <i style='margin-left:10px;' class='fa-solid fa-sort-up'></i>");
    }
    FormList(1);
}
var EInvoiceLogModal = document.getElementById('EInvoiceLogModal');

window.onclick = function (event) {
    if (event.target == EInvoiceLogModal) {
        EInvoiceLogModal.style.display = "none";
    }
};
$("#EInvoiceLogModalClose").click(function () {
    EInvoiceLogModal.style.display = "none";
});
$("#EInvoiceLogModalCloseBtn").click(function () {
    EInvoiceLogModal.style.display = "none";
});
//FUNCTION FOR BILL LIST BIND
function FormList(pageindex) {
    try {

        const dataString = {};
        dataString.PageSize = $("#ddlPageSize").val();
        dataString.PageIndex = pageindex;
        dataString.RequestId = $("#RequestId").val().trim();
        dataString.FromDate = $("#FromDate").val();
        dataString.ToDate = $("#ToDate").val();
        dataString.OrderBy = $("#sort-column").val().trim() + " " + $("#sort-type").val().trim();
        ShowLoader();
        AjaxSubmission(JSON.stringify(dataString), "/Master/EInvoiceRequest/FormList", $('input[name=__RequestVerificationToken]').val()).done(function (result) {

            let obj = result;
            if (obj.status == true) {
                if (obj.responsecode == '100') {

                    var ser = ((parseInt(obj.data.Table1[0].PageIndex) - 1) * parseInt(obj.data.Table1[0].PageSize)) + 1;
                    //BindTable('tbl_group', obj.data.Table, true, true, ser, Sortcolumn, Sorttype);
                    BindFormTable(obj.data.Table, ser);
                    if (obj.data.Table1 != undefined && obj.data.Table1.length > 0) {
                        $(".pagination").BindPaging({
                            ActiveCssClass: "current",
                            PagerCssClass: "pager",
                            PageIndex: parseInt(obj.data.Table1[0].PageIndex),
                            PageSize: parseInt(obj.data.Table1[0].PageSize),
                            RecordCount: parseInt(obj.data.Table1[0].count)
                        });
                    }

                }
                else {
                    Toast(RetrieveMessage(obj.responsecode), "Message", "error");
                }
            }
            else {
                window.location.href = '/Login/Login';
            }
            HideLoader();
        }).fail(function (result) {
            console.log(result.Message);
            HideLoader();
        });
    }
    catch (e) {
        console.log(e.message);
        HideLoader();
    }
}

//BIND BILL TYPE TABLE
function BindFormTable(result, serial_no) {
    $("#tblEInvRequest tbody tr").remove();

    if (result.length == 0) {
        tr = $('<tr/>');
        tr.append("<td class='text-center' colspan='8'>NO RESULTS FOUND</td>");
        $("#tblEInvRequest tbody").append(tr);
    }
    else {
        for (i = 0; i < result.length; i++) {
            if (result[i].is_active == "Inactive")
                tr = $(' <tr style="background-color:#fdd2d2;"/>');
            else
                tr = $('<tr/>');

            tr.append("<td class='text-left'>" + serial_no + "</td>");

            tr.append("<td class='text-center'><button type='button' class='btn btn-sm btn-success me-1' onclick='OpenEInvLogModel(\"" + result[i].EInvReqUid + "\");'>  #" + result[i].EInvReqUid + "</button> <button class='btn btn-sm btn-facebook' onclick='EInvoice(\"" + result[i].BillUid + "\",\"" + result[i].EInvReqUid + "\")' style='padding: 4px;'> <i class='fa-solid fa-arrows-rotate'></i></button> </td > ");
            if (result[i].SuccessStatus == 0) {
                tr.append("<td class='text-center'><span class='Mylabel-info Mylabel'>Request Added</span></td>");
            }
            else {
                tr.append("<td class='text-center'><span class='Mylabel-success Mylabel'>Request Completed</span></td>");
            }


            tr.append("<td class='text-center'><span class='Mylabel-info Mylabel'>" + result[i].ProcessCount + "</span><span> = </span><span class='Mylabel-success Mylabel'> " + result[i].SuccessCount + "</span><span> + </span><span class='Mylabel-danger Mylabel' >" + result[i].FailureCount + "</span></td>");
            tr.append("<td class='text-center'>" + HandleNullTextValue(result[i].CreatedAt) + "</td>");
            tr.append("<td class='text-center'>" + HandleNullTextValue(result[i].LastComment) + "</td>");

            /*tr.append("<td class='text-center'><button type='button' onclick='FormEdit(\"" + result[i].BillTypeUid + "\");' class='common-btn common-btn-sm'><i class='fa-regular fa-pen-to-square'></i></button ><button type='button' onclick='FormDelete(\"" + result[i].BillTypeUid + "\");' class='common-btn common-btn-sm'> <i class='fa-regular fa-trash-can'></i></button ></td > ");*/

            serial_no++;

            $("#tblEInvRequest tbody").append(tr);

        }
    }
}

// FUNCTION TO GET IRN 
function EInvoice(BillUid, RequestId) {
    try {
        const datastring = {};
        datastring.BillUid = BillUid;
        datastring.RequestId = RequestId;
        AjaxSubmission(JSON.stringify(datastring), "/Master/EInvoiceRequest/EInvoice", $('[name="__RequestVerificationToken"]').val()).done(function (data) {
            let obj = data;

            if (obj.status == true) {
                if (obj.responsecode == '100') {
                    Toast(RetrieveMessage(obj.responsecode), "Message", "success");
                    FormList(1);
                }
                else if (obj.responsecode == '1042') {
                    Toast(obj.error, "Message", "error", 2500);
                    FormList(1);
                }
                else {
                    Toast(RetrieveMessage(obj.responsecode), "Message", "error");
                    FormList(1);
                }

            }
            else {
                window.location.href = '/ClientLogin/ClientLogin';
            }
        }).fail(function (data) {
            console.log(data.Message);
        });
    }
    catch (e) {
        console.log(e.message);
    }
}
function OpenEInvLogModel(RequestId) {
    if (RequestId.length != 0) {
        EInvoiceLogModal.style.display = "block";
        EInvReqLogFormList(RequestId);
    }
}

//FUNCTION FOR BILL LIST BIND
function EInvReqLogFormList(RequestId) {
    try {

        const dataString = {};
        dataString.RequestId = RequestId;

        ShowLoader();
        AjaxSubmission(JSON.stringify(dataString), "/Master/EInvoiceRequest/GetEInvoiceRequestLogData", $('input[name=__RequestVerificationToken]').val()).done(function (result) {

            let obj = result;
            if (obj.status == true) {
                if (obj.responsecode == '100') {

                    var ser = 1;

                    BindEInvReqLogFormTable(obj.data.Table, ser);
                }
                else {
                    Toast(RetrieveMessage(obj.responsecode), "Message", "error");
                }
            }
            else {
                window.location.href = '/Login/Login';
            }
            HideLoader();
        }).fail(function (result) {
            console.log(result.Message);
            HideLoader();
        });
    }
    catch (e) {
        console.log(e.message);
        HideLoader();
    }
}

//BIND BILL TYPE TABLE
function BindEInvReqLogFormTable(result, serial_no) {
    $("#tblEInvRequestLog tbody tr").remove();

    if (result.length == 0) {
        tr = $('<tr/>');
        tr.append("<td class='text-center' colspan='8'>NO RESULTS FOUND</td>");
        $("#tblEInvRequestLog tbody").append(tr);
    }
    else {
        for (i = 0; i < result.length; i++) {
            if (result[i].is_active == "Inactive")
                tr = $(' <tr style="background-color:#fdd2d2;"/>');
            else
                tr = $('<tr/>');
            //if (HandleNullTextValue(result[i].SuccessStatus)== 0)
            //    tr = $(' <tr style="background-color:#fdd2d2;"/>');
            //else if (HandleNullTextValue(result[i].SuccessStatus) ==1)
            //    tr = $(' <tr style="background-color:#d2fddf;"/>');

            tr.append("<td class='text-left'>" + serial_no + "</td>");
            tr.append("<td class='text-center'><span class='Mylabel Mylabel-facebook'>" + result[i].BillType + "</span></td>");

            if (HandleNullTextValue(result[i].SuccessStatus) == 0)
                tr.append("<td class='text-left' style='color:#ff0000; font-weight:bold;'>Failed</td>");
            else if (HandleNullTextValue(result[i].SuccessStatus) == 1)
                tr.append("<td class='text-left' style='color:#09c341; font-weight:bold;'>Success</td>");

            tr.append("<td class='text-center'>" + HandleNullTextValue(result[i].CreatedAt) + "</td>");
            tr.append("<td class='text-center'>" + HandleNullTextValue(result[i].Response) + "</td>");

            serial_no++;

            $("#tblEInvRequestLog tbody").append(tr);

        }
    }
}