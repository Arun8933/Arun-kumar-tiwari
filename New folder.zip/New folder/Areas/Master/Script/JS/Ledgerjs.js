﻿
let Firstcolumn = "";
let tr;
let Ldbank = 0;
let LdBranch = 0;
let BranchModal = document.getElementById('BranchModal');
let modal1 = document.getElementById('BankModal');
let modal2 = document.getElementById('SubGroupHeadModal');
let AcceptAddress = false;
let Cntry = "";


//VARIABLE FOR DOCUMENT UPLOAD
let formname = "Ledger";
let formid;
let VoucherType = '';
if (Get_Cookie("LedgerId") != null) {
    var a = setInterval(() => {        
        if (Get_Cookie("LedgerId") != '' && Get_Cookie("LedgerId") != 0) {
            FormEdit(Get_Cookie("LedgerId"));
        } else {
            $('#Ledger_list-tab').removeClass('active');
            $('#Ledger-tab').addClass('active');
            $('#Ledger_list').removeClass('active show');
            $('#Ledger').addClass('active show');
            $("#FormAdd").show();
            $("#FormUpdate").hide();
            $("#Ledger-tab").html("Add Ledger");
        }
        EraseCookie('LedgerId');
        clearInterval(a);

    }, 1000);
}

//WHEN THE USER CLICKS ANYWHERE OUTSIDE OF THE MODAL, CLOSE IT
window.onclick = function (event) {    
    if (event.target == BranchModal) {
        BranchModal.style.display = "none";
        ResetBranchData();
    }
    if (event.target == modal1) {
        modal1.style.display = 'none';
        ResetBankData();
    }
    if (event.target == modal2) {
        modal2.style.display = 'none';
        SubGroupResetForm();
    }
}

$("#LedgerStatusSearch").select2({
    width: '100%'
});

$("#Status").select2({
    width: '100%'
});

$("#BalanceType").select2({
    width: '100%'
});

$("#Agent").select2({
    width: '100%'
});

//LEDGER GROUP SEARCH TEXTBOX ON INPUT EVENT
$("#LedgerGroupSearch").on('input', function () {
    $("#HiddenLedgerGroupSearch").val('');
})

//ADD NEW BRANCH CLICKED
$("#AddNewBranch").click(function () {
    BranchModal.style.display = "block";
})

//ADD NEW BANK CLICKED
$("#AddNewBank").click(function () {
    modal1.style.display = 'block';
});

//GROUP MODAL BUTTON CLICKED
$("#GroupModalClose").click(function () {
    modal2.style.display = 'none';
    SubGroupResetForm();
    RemoveAllError('SubGroupHeadForm');
})

//CLOSE BRANCH MODAL BUTTON CLICKED
$("#Cls").click(function () {
    BranchModal.style.display = 'none';
    ResetBranchData();
    RemoveAllError('BranchModal');
})

//CLOSE BANK MODAL BUTTON CLICKED
$("#Cls1").click(function () {
    modal1.style.display = 'none';
    ResetBankData();
    RemoveAllError('BankModal');
});

//DOCUMNET READY
$(document).ready(function () {
    ShowLoader();
    if (Get_Cookie("LedgerId") == null) {
        FillPageSizeList('ddlPageSize', FormList);
    }
    else {
        FillPageSizeList('ddlPageSize');
        HideLoader();
    }


    /* FillGroup('LedgerGroup');  */
    FillUserList('Agent');
    /*FillLedgerList('AllLedger');*/
    FillTaxCategory();
    FillGroupList();
    $("#AccHead").focus();
    LoadTinyMCE();
});

// PAGINATION BUTTON CLICKED
$(document).on("click", ".pagination .page", function () {
    FormList(($(this).attr('page')));
});

//SEARCH BUTTON CLICKED
$("#FormSearch").click(function () {
    FormList(1);
});

//PAGE SIZE CLICKED
$("#ddlPageSize").change(function () {
    FormList(1);
});

//FUNCTION FOR FORM SORTING
function FormSorting(obj) {
    if (Firstcolumn != "") {
        document.getElementById(Firstcolumn).innerHTML = document.getElementById(Firstcolumn).getAttribute("data-column") + " <i style='margin-left:10px;' class='fa-solid fa-sort'></i>";
    }
    let cn = obj.id;
    Firstcolumn = cn;
    let colname = $(obj).data("column");
    $("#sort-column").val(cn.replaceAll("_", ""));
    let sorttype = $("#sort-type").val();
    if (sorttype == "ASC") {
        $("#sort-type").val("DESC");
        $(obj).html(colname + " <i style='margin-left:10px;' class='fa-solid fa-sort-up'></i>");
    } else if (sorttype == "DESC") {
        $("#sort-type").val("ASC");
        $(obj).html(colname + " <i style='margin-left:10px;' class='fa-solid fa-sort-down'></i>");
    }
    FormList(1);
}

//FUNCTION FOR BIND LEDGER TABLE
function BindFormTable(result, serial_no) {   
    var tr = "";
   
    $("#tbl_ledger tbody tr").remove();
    if (result.length == 0) {
        tr ="<tr>";
        tr+="<td class='text-center' colspan='12'>NO RESULTS FOUND</td></tr>";
        $("#tbl_ledger tbody").html(tr);
    }
    else {
        for (i = 0; i < result.length; i++) {
            if (result[i].status == "Active")
                tr += "<tr>";
            else
                tr += '<tr style="background-color:#fdd2d2;"/>';
            tr += "<td class='text-center'> <button type='button' onclick='FormEdit(\"" + result[i].LedgerUid + "\");' class='common-btn common-btn-sm' ><i class='fa-solid fa-pen-to-square'></i></button > <button type='button' onclick='FormDelete(\"" + result[i].LedgerUid + "\");' class='common-btn common-btn-sm ms-1'> <i class='fa-regular fa-trash-can'></i></button ></td > ";
            tr +="<td class='text-left'>" + serial_no + "</td>";
            tr +="<td class='text-left'>" + result[i].LedgerUid + "</td>";
            tr +="<td class='text-center'>" + result[i].SubgroupHeadName + "</td>";
            tr +="<td class='text-center'><a href='javascript:void(0)' class='text-decoration-none' style='color: black !important;' onclick='FormEdit(\"" + result[i].LedgerUid + "\");'>" + result[i].AccHeadName + "</a></td>";

            tr +="<td class='text-end'>" + result[i].OpeningBalance + "</td>";
            //if (result[i].OpeningBalance == null) 
            //    tr+="<td class='text-end'>" + HandleNullTextValue(result[i].OpeningBalance) + "</td>";
            //else 
            //    tr+="<td class='text-end'>" + HandleNullTextValueFixed(result[i].OpeningBalance,2) + "  " + HandleNullTextValue(result[i].BalanceType) + "</td>";

            //tr.append("<td class='text-center'>" + HandleNullTextValue(result[i].balance_type) + "</td>");
            tr +="<td class='text-center'>" + HandleNullTextValue(result[i].ContactPerson) + "</td>";
            tr +="<td class='text-center'>" + HandleNullTextValue(result[i].Mobile) + "</td>";
            tr +="<td class='text-center'>" + HandleNullTextValue(result[i].Email) + "</td>";
            tr += "<td class='text-center'>" + HandleNullTextValue(result[i].CreatedAt) + "</td>";
            tr +="<td class='text-center'>" + HandleNullTextValue(result[i].LastUpdatedAt) + "</td>";
            tr +="<td class='text-center'>" + result[i].status + "</td>";
            
            tr += '</tr>';

            serial_no++;
        }
        $("#tbl_ledger tbody").html(tr);
    }
}

//FUNCTION FOR FILL LEDGER LIST
function FormList(pageindex) {
    try {
        const dataString = {};
        dataString.PageSize = $("#ddlPageSize").val();
        dataString.PageIndex = pageindex;
        dataString.LedgerUid = parseInt($("#LedgerUidSearch").val().trim());
        dataString.AccHead = $("#AccHeadSearch").val();
        dataString.Email = $("#EmailSearch").val();
        dataString.Mobile = $("#MobileSearch").val();
        dataString.LedgerGroup = $("#HiddenLedgerGroupSearch").val();
        dataString.Status = $("#LedgerStatusSearch").val();
        dataString.OrderBy = $("#sort-column").val().trim() + " " + $("#sort-type").val().trim();
        ShowLoader();
        AjaxSubmission(JSON.stringify(dataString), "/Master/Ledger/FormList", $('input[name=__RequestVerificationToken]').val()).done(function (result) {
            let obj = result;
            if (obj.status == true) {
                if (obj.responsecode == '100') {
                    var ser = ((parseInt(obj.data.Table1[0].PageIndex) - 1) * parseInt(obj.data.Table1[0].PageSize)) + 1;
                    BindFormTable(obj.data.Table, ser);
                    $(".pagination").BindPaging({
                        ActiveCssClass: "current",
                        PagerCssClass: "pager",
                        PageIndex: parseInt(obj.data.Table1[0].PageIndex),
                        PageSize: parseInt(obj.data.Table1[0].PageSize),
                        RecordCount: parseInt(obj.data.Table1[0].count)
                    });
                }
                else
                    Toast(RetrieveMessage(obj.responsecode), "Message", "error");
            }
            else
                window.location.href = '/ClientLogin/ClientLogin';
            HideLoader();
        }).fail(function (result) {
            console.log(result.Message);
            HideLoader();
        });
    }
    catch (e) {
        console.log(e.message);
        HideLoader();
    }
}

//LEDGER GROUP TEXTBOX  INPUT EVENT
$("#LedgerGroup").on('input', function () {
    $("#HiddenLedgerGroup").val('');
});

//LEDGER GROUP TEXTBOX  BLUR EVENT
$("#LedgerGroup").blur(function () {
    try {
        $('#OpeningBalance').val('');
        $('#Opb').css('display', 'none');
        $("#Cont").css('display', 'none');
        $("#Docum").css('display', 'none');
        $("#Bran").css('display', 'none');
        $("#BankAd").css('display', 'none');
        $("#PT").css('display', 'none');
        $("#DD").css('display', 'none');
        $("#AG").css('display', 'none');
        $("#UN").css('display', 'none');
        $("#PD").css('display', 'none');
        $("#InviLink").css('display', 'none');
        $("#EWB").css('display', 'none');

        //Showloader();
        const dataString = {};
        dataString.GroupId = $("#HiddenLedgerGroup").val();

        AjaxSubmission(JSON.stringify(dataString), "/Ledger/GetGroupBehaviour", $('input[name=__RequestVerificationToken]').val()).done(function (data) {
            let obj = data;
            if (obj.status == true) {
                if (obj.responsecode == '100') {
                    if(obj.data.Table[0].IsOpeningBalance =='True')
                        $('#Opb').css('display', 'block');
                }
            }
            else
                window.location.href = '/ClientLogin/ClientLogin';
        }).fail(function (result) {
            console.log(result.Message);
            //Hideloader();
        });

        AjaxSubmission(JSON.stringify(dataString), "/Ledger/CheckGroupDetails", $('input[name=__RequestVerificationToken]').val()).done(function (data) {
            let obj = data;
            if (obj.status == true) {
                if (obj.responsecode == '100') {
                    
                    if (obj.data.Table[0].AcceptAddress == false) {                       
                        $("#Cont").css('display', 'none');
                        $("#Docum").css('display', 'none');
                        $("#Bran").css('display', 'none');
                        $("#BankAd").css('display', 'none');
                        $("#PT").css('display', 'none');
                        $("#DD").css('display', 'none');
                        $("#AG").css('display', 'none');
                        $("#UN").css('display', 'none');
                        $("#PD").css('display', 'none');
                        $("#InviLink").css('display', 'none');
                        $("#EWB").css('display', 'none');
                        AcceptAddress = false;
                    }
                    else {                       
                        $("#Cont").css('display', 'block');
                        $("#Docum").css('display', 'block');
                        $("#Bran").css('display', 'block');
                        $("#BankAd").css('display', 'block');
                        $("#PT").css('display', 'block');
                        $("#DD").css('display', 'block');
                        $("#AG").css('display', 'block');
                        $("#UN").css('display', 'block');
                        $("#PD").css('display', 'block');
                        $("#InviLink").css('display', 'block');
                        $("#EWB").css('display', 'block');
                        AcceptAddress = true;
                    }
                }
            }
            else
                window.location.href = '/ClientLogin/ClientLogin';
            //Hideloader();
        }).fail(function (result) {
            console.log(result.Message);
            //Hideloader();
        });
    }
    catch (e) {
        console.log(e.message);
        //Hideloader();
    }
});

//COUNTRY TEXTBOX  INPUT EVENT
$("#Country").on('input', function () {
    $("#HiddenCountry").val('');
});

//COUNTRY TEXTBOX BLUR EVENT
$("#Country").on('blur', function () {    
    if ($("#HiddenCountry").val() == '' || $("#HiddenCountry").val() != Cntry) {
        $("#HiddenState").val('');
        $("#State").val('');
    } 
    Cntry = $("#HiddenCountry").val();
})

//STATE TEXTBOX  INPUT EVENT
$("#State").on('input', function () {
    $("#HiddenState").val('');
});

// BRANCH COUNTRY TEXTBOX  INPUT EVENT
$("#BranchCountry").on('input', function () {
    $("#HiddenBranchCountry").val('');
});

// BRANCH STATE TEXTBOX  INPUT EVENT
$("#BranchState").on('input', function () {
    $("#HiddenBranchState").val('');
});

//ADD LEDGER CLICKED
$("#FormAdd").click(function () {
    let flag = 0;
    RemoveAllError('Ledger');
    
    ValidateAllFieldNewTestMandateField('Ledger');
    if (AcceptAddress == true) {
        $("#LedgerEntry_Table tbody tr").each(function (index, ele) {
            if ($(ele).find('.ContactPerson').val() != "") {
                if ($(ele).find('.Mobile').val() == "") {
                    Toast(RetrieveMessage(1007), 'Message', 'error');
                    flag = 1;
                    return false;
                }
                if ($(ele).find('.Mobile').val() != "") {
                    if ($(ele).find('.Mobile').val().length < 10) {
                        Toast("Please Input 10 Digit Mobile Number !", 'Message', 'error');
                        flag = 1;
                        return false;
                    }
                }
            }
            if ($(ele).find('.Email').val() != "") {
                if (!EMAIL_EXPR.test($(ele).find('.Email').val().trim())) {
                    Toast("Invalid Email Address !", 'Message', 'error');
                    flag = 1;
                    return false;
                }
            }
        });
        if ($("#HiddenCountry").val() == '') {
            Toast("Please Select Country !", "message", "error");
            $("#Country").focus();
            flag = 1;
            return;
        }
        if ($("#HiddenState").val() == '') {
            Toast("Please Select State !", "message", "error");
            $("#State").focus();
            flag = 1;
            return;
        }
    }

    if (flag == 0) {
        if (Ercount == 0) {
            var EnableWebLogin = $("#EnableWebLogin").is(":checked");
            var Taxable = $("#Taxable").is(":checked");
            var TaxLedger = $("#TaxLedger").is(":checked");

            if ($("#HiddenLedgerGroup").val() == '') {
                Toast(RetrieveMessage(805), 'Message', 'error');
                $("#LedgerGroup").focus();
                return;
            }

            if (EnableWebLogin == true) {
                if ($("#UserName").val().length == 0) {
                    Toast("Please Enter User Name !", "message", "error");
                    return;
                }
                else if ($("#UserName").val().length < 4 || $("#UserName").val().length > 50) {
                    Toast("Minimum 4 Charcter and Maximum 50 Charcters allow in  User Name !", "message", "error");
                    return;
                }
                if ($("#Password").val().length == 0) {
                    Toast("Please Enter Password !", "message", "error");
                    return;
                }
                else if ($("#Password").val().length < 6 || $("#Password").val().length > 12) {
                    Toast("Minimum 6 Charcter and Maximum 12 Charcters allow in  Password !", "message", "error");
                    return;
                }
                else if (!CheckPasswordPattern($("#Password").val())) {
                    Toast("Password must contain at least one number and one uppercase and lowercase letter, and at least 6  characters and maximum 12 characters !", "Message", "warning");
                    return;
                }
            }
            if (Taxable == true) {
                if ($("#TaxCategory").val() == "0") {
                    Toast("Please Select  Tax Category !", "message", "error");
                    return;
                }
            }
            if (TaxLedger == true) {
                if ($("#TaxLedgerPer").val() == "") {
                    Toast("Please Enter Tax Percentage !", "message", "error");
                    return;
                }
            }
            FormAdd();
        }
    }
});

//FUNCTION FOR ADD LEDGER
function FormAdd() {
    try {
        var ContactPerson = "";
        var Mobile = "";
        var AltMobile = "";
        var Email = "";
        var Designation = "";

        const dataString = {};
        dataString.AccHead = $("#AccHead").val().trim();
        dataString.AccHeadDisplayName = $("#AccHeadDisplayName").val().trim();
        dataString.LedgerGroup = $("#HiddenLedgerGroup").val();
        dataString.TaxCategory = $("#TaxCategory").val();
        dataString.Status = $("#Status").val();
        dataString.HSNSAC = $("#HSNSAC").val().trim();
        dataString.CCEmail = $("#CCEmail").val().trim();
        dataString.NotificationEmailId = $("#NotificationEmailId").val().trim();
        dataString.NotificationPhoneNo = $("#NotificationPhoneNo").val().trim();
        dataString.OtherEmail = $("#OtherEmail").val().trim();
        dataString.Address1 = $("#Address1").val().trim();
        dataString.Address2 = $("#Address2").val().trim();
        dataString.Country = $("#HiddenCountry").val();
        dataString.State = $("#HiddenState").val();
        dataString.City = $("#City").val().trim();
        dataString.PinCode = $("#PinCode").val().trim();
        dataString.VendorCode = $("#VendorCode").val().trim();
        dataString.PanNo = $("#PanNo").val().trim();
        dataString.GstinNo = $("#GstinNo").val().trim();
        dataString.CinNo = $("#CinNo").val().trim();
        dataString.IECCode = $("#IECCode").val().trim();
        dataString.AccHolderName = $("#AccHolderName").val().trim();
        dataString.Bank = $("#Bank").val().trim();
        dataString.AccNo = $("#AccNo").val().trim();
        dataString.BankBranch = $("#BankBranch").val().trim();
        dataString.IFSCCode = $("#IFSCCode").val().trim();
        dataString.PaymentTerm = $("#PaymentTerm").val().trim();
        dataString.DueDays = $("#DueDays").val().trim();
        dataString.Agent = $("#Agent").val();
        dataString.UserName = $("#UserName").val().trim();
        dataString.Password = $("#Password").val().trim();
        dataString.BINNo = $("#BINNo").val();
        dataString.JobExpence = $("#JobExpence").is(":checked");
        dataString.EnableWebLogin = $("#EnableWebLogin").is(":checked");
        dataString.IsService = $('#IsService').is(':checked') ? 1 : 0;
        dataString.IsSez = $('#IsSez').is(':checked') ? 1 : 0;
        if ($("#TaxLedger").is(':checked') == true)
            dataString.TaxLedgerPer = parseFloat($("#TaxLedgerPer").val());
        else
            dataString.TaxLedgerPer = null;

        if ($("#Taxable").is(':checked') == true)
            dataString.IsTaxable = 1;
        else
            dataString.IsTaxable = 0;

        if ($("#OpeningBalance").val().trim().length > 0) {

            let Opb = {};
            Opb.OpeningBalance = parseFloat($("#OpeningBalance").val().trim());
            Opb.BalanceType = $("#BalanceType").val();
            Opb.FinancialYear = $("#SetFinancialYear").val();
            dataString.ledgerOpeningBalance = Opb;
        }
        var ContactDetail = new Array();
        var f = 0;
        $("#LedgerEntry_Table tbody tr").each(function (ind, ele) {
            if ($(ele).find(".ContactPerson").val().trim().length != 0 && $(ele).find(".Mobile").val().trim().length != 0) {

                if (f == 0) {
                    ContactPerson = $(ele).find(".ContactPerson").val();
                    Mobile = $(ele).find(".Mobile").val();
                    AltMobile = $(ele).find(".AltMobile").val();
                    Email = $(ele).find(".Email").val();
                    Designation = $(ele).find(".Designation").val();
                }

                var LedgerContactDetail = {};
                LedgerContactDetail.ContactPerson = $(ele).find(".ContactPerson").val();
                LedgerContactDetail.Mobile = $(ele).find(".Mobile").val();
                LedgerContactDetail.AltMobile = $(ele).find(".AltMobile").val();
                LedgerContactDetail.Email = $(ele).find(".Email").val();
                LedgerContactDetail.Designation = $(ele).find(".Designation").val();
                ContactDetail.push(LedgerContactDetail);
                f = 1;
            }
        });
        dataString.ContactPerson = ContactPerson;
        dataString.Mobile = Mobile;
        dataString.AltMobile = AltMobile;
        dataString.Email = Email;
        dataString.Designation = Designation;
        dataString.ledgerContactDetails = ContactDetail;
        AjaxSubmission(JSON.stringify(dataString), "/Master/Ledger/FormAdd", $('input[name=__RequestVerificationToken]').val()).done(function (result) {
            let obj = result;          
            if (obj.status == true) {
                if (obj.responsecode == '101') {
                    Toast(RetrieveMessage(obj.responsecode), "Message", "success");
                    $("#FormAdd").hide();
                    $("#FormUpdate").show();
                    $("#FormReset").show();
                    $("#Ledger-tab").html("Edit Ledger");
                    $("#AddNewBranch").prop('disabled', false);
                    $("#AddNewBank").prop('disabled', false);
                    $("#Timestamp").val(obj.data.Table[0].Timestamp);
                    $("#LedgerId").val(obj.data.Table[0].LedgerUid);
                    formid = $("#LedgerId").val();

                    
                    if (obj.data.Table[0].IsOpening == 'True') {                        
                        $("#HiddenAllLedger").val((obj.data.Table[0].LedgerUid));
                        $("#AllLedger").val((obj.data.Table[0].AccHead)).trigger('blur');
                        $("#Opening_Balance-tab").removeClass('d-none');
                    }
                    else
                        $("#Opening_Balance-tab").addClass('d-none');

                    //FormList(1);
                    //TabHide();
                    //ResetForm();
                }
                else
                    Toast(RetrieveMessage(obj.responsecode), "Message", "error");
            }
            else
                window.location.href = '/ClientLogin/ClientLogin';
            HideLoader();
        }).fail(function (result) {
            console.log(result.Message);
            HideLoader();
        });
    }
    catch (e) {
        console.log(e.message);
        //Hideloader();
    }
}

//FUNCTION FOR EDIT LEDGER
function FormEdit(id) {
    try {
        $("#UploadDocument").show();
        const dataString = {};
        formid = id;
        dataString.LedgerUid = id;
        dataString.FinancialYearId = $("#SetFinancialYear").val();
        //Showloader();
        AjaxSubmission(JSON.stringify(dataString), "/Ledger/FormEdit", $('[name="__RequestVerificationToken"]').val()).done(function (data) {
            let obj = data;
            if (obj.status == true) {
                if (obj.responsecode == '100') {

                    $("#tbl_ledger_branch tbody tr").remove();
                    $("#tbl_ledger_bank tbody tr").remove();
                    TabShow();

                    if (obj.data.Table4[0].IsOpening == 'True') {
                        $("#HiddenAllLedger").val((obj.data.Table4[0].LedgerUid));
                        $("#AllLedger").val((obj.data.Table4[0].AccHead)).trigger('blur');
                        $("#Opening_Balance-tab").removeClass('d-none');
                    }
                    else
                        $("#Opening_Balance-tab").addClass('d-none');

                       
                    
                    
                    var FirstChild = $("#LedgerEntry_Table").find("tbody tr:first-child");
                    var ContDetailsData = obj.data.Table3;
                    $.each(ContDetailsData, function (index, ele) {
                        if (index == 0) {
                            FirstChild.find('.ContactPerson').val(ele.ContactPerson);
                            FirstChild.find('.Mobile').val(ele.Mobile);
                            FirstChild.find('.AltMobile').val(ele.AltMobile);
                            FirstChild.find('.Email').val(ele.Email);
                            FirstChild.find('.Designation').val(ele.Designation);
                        }
                        else {
                            var CloneChild = FirstChild.clone();

                            CloneChild.find('.ContactPerson').val('');
                            CloneChild.find('.Mobile').val('');
                            CloneChild.find('.AltMobile').val('');
                            CloneChild.find('.Email').val('');
                            CloneChild.find('.Designation').val('');

                            CloneChild.find('.ContactPerson').val(ele.ContactPerson);
                            CloneChild.find('.Mobile').val(ele.Mobile);
                            CloneChild.find('.AltMobile').val(ele.AltMobile);
                            CloneChild.find('.Email').val(ele.Email);
                            CloneChild.find('.Designation').val(ele.Designation);
                            $("#LedgerEntry_Table tbody").append(CloneChild);
                        }
                    });
                    $("#AccHead").val(obj.data.Table4[0].AccHead);
                    $("#AccHeadDisplayName").val(obj.data.Table4[0].AccHeadDisplayName);
                    $("#LedgerId").val(obj.data.Table4[0].LedgerUid);
                    $("#Timestamp").val(obj.data.Table4[0].Timestamp);

                    $("#HiddenLedgerGroup").val(obj.data.Table4[0].LedgerGroup);
                    $("#LedgerGroup").val(obj.data.Table4[0].LedgerGroupName).trigger('blur');

                    if (obj.data.Table4[0].Status == true)
                        $("#Status").val(1).trigger('change');
                    else
                        $("#Status").val(0).trigger('change');
                    $("#HSNSAC").val(obj.data.Table4[0].HSNSAC);
                    $("#CCEmail").val(obj.data.Table4[0].CCEmail);
                    $("#NotificationEmailId").val(obj.data.Table4[0].NotificationEmailId);
                    $("#NotificationPhoneNo").val(obj.data.Table4[0].NotificationPhoneNo);
                    $("#OtherEmail").val(obj.data.Table4[0].OtherEmail);
                    $("#Address1").val(obj.data.Table4[0].Address1);
                    $("#Address2").val(obj.data.Table4[0].Address2);
                    Cntry = obj.data.Table4[0].Country;
                    $("#HiddenCountry").val(obj.data.Table4[0].Country);
                    $("#Country").val(obj.data.Table4[0].CountryName);
                    $("#HiddenState").val(obj.data.Table4[0].State);
                    $("#State").val(obj.data.Table4[0].StateName);
                    $("#City").val(obj.data.Table4[0].City);
                    $("#PinCode").val(obj.data.Table4[0].PinCode);
                    $("#VendorCode").val(obj.data.Table4[0].VendorCode);
                    $("#PanNo").val(obj.data.Table4[0].PanNo);
                    $("#GstinNo").val(obj.data.Table4[0].GstinNo);
                    $("#CinNo").val(obj.data.Table4[0].CinNo);
                    $("#IECCode").val(obj.data.Table4[0].IECCode);
                    $("#BINNo").val(obj.data.Table4[0].BINNo);
                    $("#AccHolderNameError").val(obj.data.Table4[0].AccHolderName);
                    $("#Bank").val(obj.data.Table4[0].Bank);
                    $("#AccNo").val(obj.data.Table4[0].AccNo);
                    $("#BankBranch").val(obj.data.Table4[0].BankBranch);
                    $("#IFSCCode").val(obj.data.Table4[0].IFSCCode);
                    $("#PaymentTerm").val(obj.data.Table4[0].PaymentTerm);
                    $("#DueDays").val(obj.data.Table4[0].DueDays);

                    //$("#LedgerId").val(obj.data.Table[4].LedgerUid);
                    //$("#Timestamp").val(obj.data.Table[4].Timestamp);


                    if (obj.data.Table4[0].Agent != null)
                        $("#Agent").val(obj.data.Table4[0].Agent).trigger("change");

                    if (obj.data.Table4[0].EnableWebLogin == true)
                        $('#EnableWebLogin').prop('checked', true);
                    else
                        $('#EnableWebLogin').prop('checked', false);

                    $('#IsService').prop('checked', obj.data.Table4[0].IsService);
                    $('#IsSez').prop('checked', obj.data.Table4[0].IsSez);

                    $("#UserName").val(obj.data.Table4[0].UserName);
                    $("#Password").val(obj.data.Table4[0].Password);

                    if (obj.data.Table1.length > 0) {
                        $("#OpeningBalance").val(HandleNullTextValueFixed(obj.data.Table1[0].OpeningBalance, 2));
                        $("#BalanceType").val(obj.data.Table1[0].BalanceType);
                    }

                    if (obj.data.Table4[0].TaxLedgerPer != null) {
                        $("#TaxLedgerPer").val(obj.data.Table4[0].TaxLedgerPer);
                        $("#TaxLedger").prop('checked', true);
                        $("#PG").css('display', 'block');
                    }
                    if (obj.data.Table4[0].IsTaxable == true) {
                        $("#Taxable").prop('checked', true);
                        $("#TC").css('display', 'block');
                        $("#TaxCategory").val(obj.data.Table4[0].TaxCategory);
                    }
                    if (obj.data.Table4[0].JobExpense == true) {
                        $("#JobExpence").prop('checked', true);
                    }
                    else {
                        $("#JobExpence").prop('checked', false);
                    }
                    $.each(obj.data.Table, function (i, br) {
                        let tr;
                        tr = $('<tr/>');
                        tr.append("<td class='text-center d-flex flex-row justify-content-center'><button type='button' onclick='LedgerBranchFormEdit(\"" + br.BranchUid + "\");' class='common-btn common-btn-sm '><i class='fa fa-edit'></i></button><button style='margin-left: 10px;' type='button'  onclick='LedgerBranchFormDelete(\"" + br.BranchUid + "\");' class='common-btn common-btn-sm ''><i class='fa-regular fa-trash-can'></i></button></td>");
                        tr.append("<td><a href='javascript:void(0)' class='text-decoration-none' style='color: black !important;' onclick='LedgerBranchFormEdit(\"" + br.BranchUid + "\");'>" + HandleNullTextValue(br.BranchUid) + "</a></td>");
                        tr.append("<td>" + HandleNullTextValue(br.BranchCode) + "</td>");
                        tr.append("<td><a href='javascript:void(0)' class='text-decoration-none' style='color: black !important;' onclick='LedgerBranchFormEdit(\"" + br.BranchUid + "\");'>" + HandleNullTextValue(br.BranchName) + "</a></td>");
                        tr.append("<td>" + HandleNullTextValue(br.BranchContactPerson) + "</td>");
                        tr.append("<td>" + HandleNullTextValue(br.BranchEmail) + "</td>");
                        tr.append("<td>" + HandleNullTextValue(br.BranchMobile) + "</td>");
                        tr.append("<td>" + HandleNullTextValue(br.BranchAddress1) + "</td>");
                        tr.append("<td>" + HandleNullTextValue(br.BranchAddress2) + "</td>");
                        tr.append("<td class='d-none'>" + HandleNullTextValue(br.BranchCountryId) + "</td>");
                        tr.append("<td>" + HandleNullTextValue(br.BranchCountryName) + "</td>");
                        tr.append("<td class='d-none'>" + HandleNullTextValue(br.BranchStateId) + "</td>");
                        tr.append("<td>" + HandleNullTextValue(br.BranchStateName) + "</td>");
                        tr.append("<td>" + HandleNullTextValue(br.BranchCity) + "</td>");
                        tr.append("<td>" + HandleNullTextValue(br.BranchGstin) + "</td>");
                        tr.append("<td>" + HandleNullTextValue(br.BranchPinCode) + "</td>");
                        $('#tbl_ledger_branch').append(tr);
                    });

                    $.each(obj.data.Table2, function (i, ldbank) {
                        let tr;
                        tr = $('<tr/>');

                        tr.append("<td class='text-center'><button type='button' onclick='LedgerBankFormEdit(\"" + ldbank.LedgerBankUid + "\");' class='common-btn common-btn-sm '><i class='fa fa-edit'></i></button><button style='margin-left: 10px;' type='button'  onclick='LedgerBankFormDelete(\"" + ldbank.LedgerBankUid + "\");' class='common-btn common-btn-sm ''><i class='fa-regular fa-trash-can'></i></button></td>");
                        tr.append("<td>" + HandleNullTextValue(ldbank.LedgerBankUid) + "</td>");
                        tr.append("<td>" + HandleNullTextValue(ldbank.LedgerBankAccNo) + "</td>");
                        tr.append("<td>" + HandleNullTextValue(ldbank.LedgerBankName) + "</td>");
                        tr.append("<td>" + HandleNullTextValue(ldbank.LedgerBankIfscCode) + "</td>");
                        tr.append("<td>" + HandleNullTextValue(ldbank.LedgerBankAdCode) + "</td>");

                        $("#tbl_ledger_bank").append(tr);

                    });
                }
                else
                    Toast(RetrieveMessage(obj.responsecode), "Message", "error");
            }
            else
                window.location.href = '/ClientLogin/ClientLogin';
            //Hideloader();
        }).fail(function (data) {
            console.log(data.Message);
            //Hideloader();
        });
    }
    catch (e) {
        console.log(e.message);
        //Hideloader();
    }
}

//UPDATE LEDGER CLICKED
$("#FormUpdate").click(function () {
    var flag = 0;
    RemoveAllError('Ledger');
    ValidateAllFieldNewTestMandateField('Ledger');
    if (AcceptAddress == true) {
        $("#LedgerEntry_Table tbody tr").each(function (index, ele) {
            if ($(ele).find('.ContactPerson').val() != "") {
                if ($(ele).find('.Mobile').val() == "") {
                    Toast(RetrieveMessage(1007), 'Message', 'error');
                    flag = 1;
                    return false;
                }
                if ($(ele).find('.Mobile').val() != "") {
                    if ($(ele).find('.Mobile').val().length < 10) {
                        Toast("Please Input 10 Digit Mobile Number !", 'Message', 'error');
                        flag = 1;
                        return false;
                    }
                }
            }
            if ($(ele).find('.Email').val() != "") {

                if (!EMAIL_EXPR.test($(ele).find('.Email').val().trim())) {
                    Toast("Invalid Email Address !", 'Message', 'error');
                    flag = 1;
                    return false;
                }
            }
        });
        if ($("#HiddenCountry").val() == '') {
            Toast("Please Select Country !", "message", "error");
            $("#Country").focus();
            flag = 1;
            return;
        }
        if ($("#HiddenState").val() == '') {
            Toast("Please Select State !", "message", "error");
            $("#State").focus();
            flag = 1;
            return;
        }
    }

    if (flag == 0) {
        if (Ercount == 0) {
            var EnableWebLogin = $("#EnableWebLogin").is(":checked");
            var Taxable = $("#Taxable").is(":checked");
            var TaxLedger = $("#TaxLedger").is(":checked");

            if ($("#HiddenLedgerGroup").val() == '') {
                Toast(RetrieveMessage(805), 'Message', 'error');
                $("#LedgerGroup").focus();
                return;
            }
            if (EnableWebLogin == true) {
                if ($("#UserName").val().length == 0) {
                    Toast("Please Enter User Name !", "message", "error");
                    $('#UserName').focus();
                    return;
                }
                else if ($("#UserName").val().length < 4 || $("#UserName").val().length > 50) {
                    Toast("Minimum 4 Charcter and Maximum 50 Charcters allow in  User Name !", "message", "error");
                    return;
                }
                else if (!EMAIL_EXPR.test($('#UserName').val().trim())) {
                    Toast("Invalid Email Address !", 'Message', 'error');
                    $('#UserName').focus();
                    return false;
                }
                if ($('#Password').val().trim().length > 0) {
                    if ($("#Password").val().length < 6 || $("#Password").val().length > 12) {
                        Toast("Minimum 6 Charcter and Maximum 12 Charcters allow in  Password !", "message", "error");
                        $('#Password').focus();
                        return;
                    }
                    else if (!CheckPasswordPattern($("#Password").val())) {
                        Toast("Password must contain at least one number and one uppercase and lowercase letter, and at least 6  characters and maximum 12 characters !", "Message", "warning");
                        $('#Password').focus();
                        return;
                    }
                }
            }
            if (Taxable == true) {
                if ($("#TaxCategory").val() == "0") {
                    Toast("Please Select  Tax Category !", "message", "error");
                    return;
                }
            }
            if (TaxLedger == true) {
                if ($("#TaxLedgerPer").val() == "") {
                    Toast("Please Enter Tax Percentage !", "message", "error");
                    return;
                }
            }

            
            FormUpdate();
        }
    }
});

//FUNCTION FOR UPDATE LEDGER
function FormUpdate() {
    try {
        var ContactPerson = "";
        var Mobile = "";
        var AltMobile = "";
        var Email = "";
        var Designation = "";

        const dataString = {};
        dataString.AccHead = $("#AccHead").val().trim();
        dataString.AccHeadDisplayName = $("#AccHeadDisplayName").val().trim();
        dataString.LedgerGroup = $("#HiddenLedgerGroup").val();
        dataString.TaxCategory = $("#TaxCategory").val();
        dataString.Status = $("#Status").val();
        dataString.HSNSAC = $("#HSNSAC").val().trim();
        dataString.CCEmail = $("#CCEmail").val().trim();
        dataString.NotificationEmailId = $("#NotificationEmailId").val().trim();
        dataString.NotificationPhoneNo = $("#NotificationPhoneNo").val().trim();
        dataString.OtherEmail = $("#OtherEmail").val().trim();
        dataString.Address1 = $("#Address1").val().trim();
        dataString.Address2 = $("#Address2").val().trim();
        dataString.Country = $("#HiddenCountry").val();
        dataString.State = $("#HiddenState").val();
        dataString.City = $("#City").val().trim();
        dataString.PinCode = $("#PinCode").val().trim();
        dataString.VendorCode = $("#VendorCode").val().trim();
        dataString.PanNo = $("#PanNo").val().trim();
        dataString.GstinNo = $("#GstinNo").val().trim();
        dataString.CinNo = $("#CinNo").val().trim();
        dataString.IECCode = $("#IECCode").val().trim();
        dataString.AccHolderName = $("#AccHolderName").val().trim();
        dataString.Bank = $("#Bank").val().trim();
        dataString.AccNo = $("#AccNo").val().trim();
        dataString.BankBranch = $("#BankBranch").val().trim();
        dataString.IFSCCode = $("#IFSCCode").val().trim();
        dataString.BalanceType = $("#BalanceType").val();
        dataString.PaymentTerm = $("#PaymentTerm").val().trim();
        dataString.DueDays = $("#DueDays").val().trim();
        dataString.Agent = $("#Agent").val();
        dataString.UserName = $("#UserName").val().trim();
        dataString.Password = $("#Password").val().trim();
        dataString.BINNo = $("#BINNo").val();
        dataString.JobExpence = $("#JobExpence").is(":checked");
        dataString.IsService = $('#IsService').is(':checked') ? 1 : 0;
        dataString.IsSez = $('#IsSez').is(':checked') ? 1 : 0;
        dataString.EnableWebLogin = $("#EnableWebLogin").is(":checked");


        if ($("#TaxLedger").is(':checked') == true)
            dataString.TaxLedgerPer = parseFloat($("#TaxLedgerPer").val());
        else
            dataString.TaxLedgerPer = null;

        if ($("#Taxable").is(':checked') == true)
            dataString.IsTaxable = 1;
        else
            dataString.IsTaxable = 0;

        if ($("#OpeningBalance").val().trim().length > 0) {
            let Opb = {};
            Opb.OpeningBalance = parseFloat($("#OpeningBalance").val().trim());
            Opb.BalanceType = $("#BalanceType").val();
            Opb.FinancialYear = $("#SetFinancialYear").val();
            dataString.ledgerOpeningBalance = Opb;
        }
        var ContactDetail = new Array();
        var f = 0;
        $("#LedgerEntry_Table tbody tr").each(function (ind, ele) {
            if ($(ele).find(".ContactPerson").val().trim().length != 0 && $(ele).find(".Mobile").val().trim().length != 0) {

                if (f == 0) {
                    ContactPerson = $(ele).find(".ContactPerson").val();
                    Mobile = $(ele).find(".Mobile").val();
                    AltMobile = $(ele).find(".AltMobile").val();
                    Email = $(ele).find(".Email").val();
                    Designation = $(ele).find(".Designation").val();
                }

                var LedgerContactDetail = {};
                LedgerContactDetail.ContactPerson = $(ele).find(".ContactPerson").val();
                LedgerContactDetail.Mobile = $(ele).find(".Mobile").val();
                LedgerContactDetail.AltMobile = $(ele).find(".AltMobile").val();
                LedgerContactDetail.Email = $(ele).find(".Email").val();
                LedgerContactDetail.Designation = $(ele).find(".Designation").val();
                ContactDetail.push(LedgerContactDetail);
                f = 1;
            }
        });

        dataString.ContactPerson = ContactPerson;
        dataString.Mobile = Mobile;
        dataString.AltMobile = AltMobile;
        dataString.Email = Email;
        dataString.Designation = Designation;
        dataString.ledgerContactDetails = ContactDetail;
        dataString.LedgerUid = $("#LedgerId").val();
        dataString.Timestamp = $("#Timestamp").val();

        AjaxSubmission(JSON.stringify(dataString), "/Master/Ledger/FormUpdate", $('input[name=__RequestVerificationToken]').val()).done(function (result) {
            let obj = result;            
            if (obj.status == true) {
                if (obj.responsecode == '107') {
                    Toast(RetrieveMessage(obj.responsecode), 'Message', 'success');
                    setTimeout(FormList(1), 1000);
                    $("#Timestamp").val(obj.data.Table[0].Timestamp);
                    $("#LedgerId").val(obj.data.Table[0].LedgerUid);

                    if (obj.data.Table[0].IsOpening == 'True') {
                        $("#HiddenAllLedger").val((obj.data.Table[0].LedgerUid));
                        $("#AllLedger").val((obj.data.Table[0].AccHead)).trigger('blur');
                        $("#Opening_Balance-tab").removeClass('d-none');
                    }
                    else
                        $("#Opening_Balance-tab").addClass('d-none');

                }
                else
                    Toast(RetrieveMessage(obj.responsecode), "Message", "error");
            }
            else
                window.location.href = '/ClientLogin/ClientLogin';
            //Hideloader();
        }).fail(function (result) {
            console.log(result.Message);
            //Hideloader();
        });
    }
    catch (e) {
        console.log(e.message);
        //Hideloader();
    }
}

//FUNCTION FOR DELETE LEDGER
function FormDelete(id) {
    try {

        $.confirm({
            title: '',
            content: 'Are You Sure Want To Delete ?',
            type: 'red',
            boxWidth: '300px',
            useBootstrap: false,
            columnClass: 'small',
            containerFluid: true,
            typeAnimated: true,
            buttons: {
                tryAgain: {
                    text: 'Confirm',
                    btnClass: 'btn-red',
                    action: function () {
                        const dataString = {};
                        dataString.LedgerUid = id;
                        AjaxSubmission(JSON.stringify(dataString), "/Ledger/FormDelete", $('[name="__RequestVerificationToken"]').val()).done(function (data) {
                            let obj = data;
                            if (obj.status == true) {
                                if (obj.responsecode == '102') {
                                    Toast(RetrieveMessage(obj.responsecode), "Message", "success");
                                    FormList(1);
                                }
                                else
                                    Toast(RetrieveMessage(obj.responsecode), "Message", "error");
                            }
                            else
                                window.location.href = '/ClientLogin/ClientLogin';
                            //Hideloader();
                        }).fail(function (data) {
                            console.log(data.Message);
                            //Hideloader();
                        });
                    }
                },
                close: function () {

                }
            }
        });

    }
    catch (e) {
        console.log(e.message);
        //Hideloader();
    }
}

// ALL LEDGER TEXTBOX INPUT EVENT
$("#AllLedger").on('input', function () {
    $("#HiddenAllLedger").val('');
});
// ALL LEDGER TEXTBOX BLUR EVENT
$("#AllLedger").blur(function () {

    $("#tblfin").addClass("d-none");
    $("#tblbtn").addClass("d-none");
    $("#tbl_finyropeningbalance tbody").empty();
    if ($("#HiddenAllLedger").val() > 0) {
        GetFinancialYearOpeningBalance($("#HiddenAllLedger").val());
        $("#tblfin").removeClass("d-none");
        $("#tblbtn").removeClass("d-none");
    }

});

//FUNCTION FOR GET ALL FINANCIAL YEAR OPENING BALANCE
function GetFinancialYearOpeningBalance(Id) {
    try {
        const dataString = {};
        dataString.Ledgerid = Id;
        //Showloader();
        AjaxSubmission(JSON.stringify(dataString), "/Master/Ledger/GetFinancialYearOpeningBalance", $('input[name=__RequestVerificationToken]').val()).done(function (data) {
            let obj = data;
            if (obj.status == true) {
                if (obj.responsecode == '100')
                    BindFinancialYearOpeningBalance(obj.data.Table, 1);
                else
                    Toast(RetrieveMessage(obj.responsecode), "Message", "error");
            }
            else
                window.location.href = '/ClientLogin/ClientLogin';
            //Hideloader();
        }).fail(function (result) {
            console.log(result.Message);
            //Hideloader();
        });
    }
    catch (e) {
        console.log(e.message);
        //Hideloader();
    }
}

//FUNCTION FOR BIND FINANCIAL YEAR OPENING BALANCE
function BindFinancialYearOpeningBalance(result, serialno) {
    if (result.length == 0) {
        tr = $('<tr/>');
        tr.append("<td class='text-center' colspan='3'>NO RESULTS FOUND</td>");
        $("#tbl_finyropeningbalance tbody").append(tr);
    } else {

        for (i = 0; i < result.length; i++) {
            tr = $('<tr class="my"/>');
            tr.append("<td class='text-center'>" + serialno + "</td>");
            tr.append("<td class='text-center d-none'>" + result[i].finyr_id + "</td>");
            tr.append("<td class='text-center'>" + result[i].finyr_name + "</td>");

            tr.append("<td class='text-center'><select class='BalanceType form-select form-select-md mybox'><option value=''>----Select-----</option><option value='Debit'>Debit</option><option value='Credit'>Credit</option></select ></td>");

            tr.append("<td class='text-center'><input type='text' id='Ledgopenbal' name='Ledgopenbal' class='form-control input-md mybox' onblur='TrimValue(this);PriceBlur(this,2);' 'onkeypress='return IsNumberPointKey(event, this);' value=\"" + HandleNullTextValueFixed(HandleNullNumericValue(result[i].OpeningBalance), 2) + "\" maxlength = '12' style = 'text-align:right;' /></td > ");

            serialno++;
            $("#tbl_finyropeningbalance tbody").append(tr);
            tr.find(".BalanceType").val(result[i].BalanceType);
        }
    }
}

//UPDATE OPENING BALANCE CLICKED
$("#UpdateOpeningBalance").click(function () {  
    const dataString = {};
    var tmp = Array();
    var flag = 0;

    dataString.Ledgerid = $("#HiddenAllLedger").val();
    $("#tbl_finyropeningbalance .my").each(function (e, th) {
        var Root = {};
        var Btype, Opb;
        Btype = $(this).find(".form-select").val();
        if (Btype == 'Debit' || Btype == 'Credit') {
            Opb = $(this).find("td:nth-child(5) input[type='text']").val();
            if (Opb.length == 0) {
                flag = 1;
                return;
            }
            Root.FinancialYear = $(this).find("td:nth-child(2)").html();
            Root.FinancialYearName = $(this).find("td:nth-child(3)").html();
            Root.BalanceType = $(this).find(".form-select").val();
            Root.OpeningBalance = $(this).find("td:nth-child(5) input[type='text']").val();
            tmp.push(Root);
        }

    });
    if (flag == 1) {
        Toast("Please Add Balance", "Message", "error");
        return;
    }
    dataString.ledgerOpeningBalances = tmp;
  
    if (dataString.ledgerOpeningBalances.length == 0)
        return;

    AjaxSubmission(JSON.stringify(dataString), "/Master/Ledger/UpdateFinancialYearOpeningBalance", $('input[name=__RequestVerificationToken]').val()).done(function (data) {
        let obj = data;

        if (obj.status == true) {
            if (obj.responsecode == '100') {
                Toast(RetrieveMessage(obj.responsecode), "Message", "success");              
                FormList(1);
            }
            else
                Toast(RetrieveMessage(obj.responsecode), "Message", "error");
        }
        else
            window.location.href = '/ClientLogin/ClientLogin';
        //Hideloader();
    }).fail(function (result) {
        console.log(result.Message);
        //Hideloader();
    });
});

//FUNCTION FOR RESET BRANCH DATA
function ResetBranchData() {
    $("#BranchID,#BranchName,#BranchContactPerson,#BranchContactEmail,#BranchContactMobile,#BranchAddressFirst,#BranchAddressSecond,#HiddenBranchCountry,#BranchCountry,#HiddenBranchState,#BranchState,#BranchGstin,#BranchCityName,#BranchPinCode").val("");
    
    $("#AddBranch").removeClass('d-none');
    $("#UpdateBranch").addClass('d-none');
    $("#BranchID").removeAttr('disabled');
    $("#BranchName").removeAttr('disabled');

    $('#BranchIsSez').prop('checked', false);

    RemoveAllError('BranchModal');
}

//FUNCTION FOR RESET BANK DATA
function ResetBankData() {
    $("#LedgBankAccNo,#LedgBankName,#LeddgBankIFSCCode,#ADCode").val("");   
    $("#AddBank").removeClass('d-none');
    $("#UpdateBank").addClass('d-none');
    $("#ADCode").removeAttr('disabled');
    RemoveAllError('BankModal');
}
//FUNCTION FOR RESET DATA
function ResetForm() {
    Cntry = '';
    $('#Ledger-tab').html("Add Ledger");
    $('#FormAdd').show();
    $('#FormUpdate,#FormReset').hide();

    $('#AddNewBranch,#AddNewBank').prop('disabled', false);
    
    $('#AccHead,#LedgerId,#AccHeadDisplayName,#HiddenLedgerGroup,#LedgerGroup,#Status,#HSNSAC,#ContactPerson,#Mobile,#AltMobile,#Email,#CCEmail,#NotificationEmailId,#NotificationPhoneNo,#OtherEmail,#Address1,#Address2,#HiddenCountry,#Country,#HiddenState,#State,#City,#PinCode,#VendorCode,#PanNo,#GstinNo,#CinNo,#IECCode,#AccHolderNameError,#Bank,#AccNo,#BankBranch,#IFSCCode,#OpeningBalance,#PaymentTerm,#DueDays,#UserName,#Password,#BINNo').val('');
    
    
   
    $('#Agent,#TaxCategory').val(0);
    $('#TaxLedgerPer').val('0.00');
    $('#tbl_ledger_branch tbody tr,#tbl_ledger_bank tbody tr').remove();
   
    $('#Cont,#Opb,#Docum,#Bran,#BankAd,#PT,#DD,#AG,#UN,#PD,#InviLink,#EWB,#PG,#TC').css('display', 'none');
   
    $('#TaxLedger,#JobExpence,#Taxable,#EnableWebLogin,#IsService,#IsSez').prop('checked', false);
    
    RemoveAllError('Ledger');

    $('.ContactPerson,.Mobile,.AltMobile,.Email,.Designation').val('');
    
    let tbody = $('#LedgerEntry_Table').find('tbody');
    let Tr = $(tbody).find('tr');
    let rowCount = Tr.length;
    if (rowCount > 1) {
        $('#LedgerEntry_Table tbody tr').each(function (index, ele) {
            if (index > 0) {
                $(ele).remove();
            }
            else {
                $(ele).find('.ContactPerson,.Mobile,.AltMobile,.Email,.Designation').val('');
               
                $('#LedgerEntry_Table').find('tbody').append(ele);
            }
        });

    }
    else {

        Tr.find('.ContactPerson,.Mobile,.AltMobile,.Email,.Designation').val('');       
        $('#LedgerEntry_Table').find('tbody').append(Tr);
    }

    $('#AllLedger,#HiddenAllLedger').val('');
   
    $('#tbl_finyropeningbalance tbody').empty();
    $('#tblfin,#tblbtn').addClass("d-none");
   
    $('#UploadDocument').hide();
}

//FUCNTION FOR TAB SHOW
function TabShow() {   
    $('#Ledger_list-tab').removeClass('active');
    $('#Ledger-tab').addClass('active');
    $('#Ledger_list').removeClass('active show');
    $('#Ledger').addClass('active show');   
    $("#FormAdd").hide();
    $("#FormUpdate").show();
    $("#FormReset").show();
    $("#Ledger-tab").html("Edit Ledger");
    $("#AddNewBranch").prop('disabled', false);
    $("#AddNewBank").prop('disabled', false);
}

//FUNCTION FOR TAB HIDE
function TabHide() {
    $('#Ledger-tab').removeClass('active');
    $('#Ledger_list-tab').addClass('active ');
    $('#Ledger_list').addClass('active show');
    $('#Ledger').removeClass('active show');
    $("#FormAdd").show();
    $("#FormUpdate").hide();
    $("#FormReset").hide();
    $("#Ledger-tab").html("Add Ledger");
    $("#Opening_Balance-tab").addClass('d-none');
   
}

//LEDGER LIST TAB CLICKED
$("#Ledger_list-tab").click(function () {
    ResetForm();
    RemoveAllError('Ledger');
    TabHide();
});

var TTL = document.getElementById("TTL");
var chks = TTL.getElementsByTagName("INPUT");
for (var i = 0; i < chks.length; i++) {
    chks[i].onclick = function () {
        for (var i = 0; i < chks.length; i++) {
            if (chks[i] != this && this.checked) {
                chks[i].checked = false;
            }
        }
    };
}
$("#TaxLedgerPer").blur(function () {
    let Vl = $("#TaxLedgerPer").val();
    if (Vl > 100)
        $("#TaxLedgerPer").val('0.00');
})
$("#TaxLedger").click(function () {
    if ($("#TaxLedger").is(':checked') == true) {
        $("#PG").css('display', 'block');
        $("#TC").css('display', 'none');
        $("#TaxledgerPer").focus();
    }
    else
        $("#PG").css('display', 'none');
});

$("#Taxable").click(function () {
    if ($("#Taxable").is(':checked') == true) {
        $("#PG").css('display', 'none');
        $("#TC").css('display', 'block');
        $("#TaxCategory").focus();
    }

    else {
        /*$("#PG").css('display', 'block');*/
        $("#TC").css('display', 'none');
        /* $("#TaxledgerPer").focus();*/
    }

});


// TARUN JS//
// ADD MORE VOUCHER ENTRY DROPDOWN GRID 
$("#AddLegerEntry").click(function () {
    $("#RemoveLegerEntry").removeAttr('disabled');
    var tbody = $("#LedgerEntry_Table").find("tbody");
    var FirstTr = $(tbody).find("tr:first");
    //FirstTr.find('.ReceivingDate').datepicker("destroy");
    //FirstTr.find('.ReceivingDate').removeAttr("id");

    var NewRow = $(FirstTr).clone();
    NewRow.find('.ContactPerson').val('');
    NewRow.find('.Mobile').val('');
    NewRow.find('.AltMobile').val('');
    NewRow.find('.Email').val('');
    NewRow.find('.Designation').val('');
    $("#LedgerEntry_Table").find("tbody").append(NewRow);
});

function DeleteRow(obj) {
    var rowCount = $("#LedgerEntry_Table tbody tr").length;
    if (rowCount > 1) {
        $(obj).parent().parent().remove();
    }
    else {
        $("#RemoveLegerEntry").attr("disabled", "disabled");
    }
}

//ADD NEW BRANCH BUTTON CLICK EVENT
$("#AddNewBranch").click(function () {
    $("#BranchID").focus();
});

//ADD NEW BANK BUTTON CLICK EVENT
$("#AddNewBank").click(function () {
    $("#LedgBankAccNo").focus();
});

$(".Ledger_list").click(function () {
    $("#LedgerUidSearch").focus();
});

$(".Opening_Balance").click(function () {
    $("#AllLedger").focus();
});

$("#Ledger-tab").click(function () {
    $("#AddNewBranch").prop('disabled', true);
    $("#AddNewBank").prop('disabled', true);
});
$("#Ledger_list-tab").click(function () {
    $("#AddNewBranch").prop('disabled', true);
    $("#AddNewBank").prop('disabled', true);
});

$(document).keydown(function (event) {
    if (event.keyCode == 27) {
        $('#BankModal').hide();
        $('#BranchModal').hide();
        $('#SubGroupHeadModal').hide();
    }
});

//DOCUMENT UPLOAD ON CLICK FUNCTION
$("#UploadDocument").click(function () {
    DocUploadResetdata();
    CommonFormList('LedgerDocUpload LDU INNER JOIN document_type_master DTM ON DTM.doc_type_uid =LDU.DocTypeUid ', 'ldu.DocUploadUId, DTM.doc_type, LDU.FilePath,ldu.LedgerUid', 'FilePath');
});

//ALLOW NUMBER WITH POINT
$(".allownumericwithdecimal").on("keypress keyup blur", function (event) {
    $(this).val($(this).val().replace(/[^0-9\|\,]/g, ''));
    //debugger;
    if (event.which == 44) {
        return true;
    }
    if ((event.which != 46 || $(this).val().indexOf('.') != -1) && (event.which < 48 || event.which > 57)) {

        event.preventDefault();
    }
});

//FUNCTION FOR BIND LETTER NAMES FROM LETTER MASTER 
function FillTaxCategory() {
    try {
        //Showloader();
        AjaxSubmission(null, "/Master/_Layout/GetTaxCategory", $('input[name=__RequestVerificationToken]').val()).done(function (result) {
            let obj = result;
            if (obj.status == true) {
                if (obj.responsecode == '100') {
                    BindDropdown(obj.data.Table, 'TaxCategory', 'CategoryUid', 'CategoryName', '-----Select-----');
                }
                else if (obj.responsecode == '604') {
                    BindDropdown(null, 'TaxCategory', 'CategoryUid', 'CategoryName', '-----Select-----');
                }
                else {
                    Toast(RetrieveMessage(obj.responsecode), "Message", "error");
                }
                //setTimeout(FormList(1), 1000);
            }
            else {
                window.location.href = '/ClientLogin/ClientLogin';
            }
            //Hideloader();
        }).fail(function (result) {
            console.log(result.Message);
            //Hideloader();
        });
    }
    catch (e) {
        console.log(e.message);
        //Hideloader();
    }
}

//FUNCTION FOR FILL LEDGER BRANCH LIST
function FillLedgerBranchList() {
    const dataString = {};
    dataString.LedgerUid = formid;
    AjaxSubmission(JSON.stringify(dataString), "/Ledger/LedgerBranchFormList", $('input[name=__RequestVerificationToken]').val()).done(function (result) {
        let obj = result;
        if (obj.status == true) {
            if (obj.responsecode == '100') {
                $("#tbl_ledger_branch tbody tr").remove();
                $.each(obj.data.Table, function (i, br) {
                    let tr;
                    tr = $('<tr/>');                   
                    tr.append("<td class='text-center d-flex flex-row justify-content-center'><button type='button' onclick='LedgerBranchFormEdit(\"" + br.BranchUid + "\");' class='common-btn common-btn-sm '><i class='fa fa-edit'></i></button><button style='margin-left: 10px;' type='button'  onclick='LedgerBranchFormDelete(\"" + br.BranchUid + "\");' class='common-btn common-btn-sm ''><i class='fa-regular fa-trash-can'></i></button></td>");
                    tr.append("<td><a href='javascript:void(0)' class='text-decoration-none' style='color: black !important;' onclick='LedgerBranchFormEdit(\"" + br.BranchUid + "\");'>" + HandleNullTextValue(br.BranchUid) + "</a></td>");
                    tr.append("<td>" + HandleNullTextValue(br.BranchCode) + "</td>");
                    tr.append("<td><a href='javascript:void(0)' class='text-decoration-none' style='color: black !important;' onclick='LedgerBranchFormEdit(\"" + br.BranchUid + "\");'>" + HandleNullTextValue(br.BranchName) + "</a></td>");
                    tr.append("<td>" + HandleNullTextValue(br.BranchContactPerson) + "</td>");
                    tr.append("<td>" + HandleNullTextValue(br.BranchEmail) + "</td>");
                    tr.append("<td>" + HandleNullTextValue(br.BranchMobile) + "</td>");
                    tr.append("<td>" + HandleNullTextValue(br.BranchAddress1) + "</td>");
                    tr.append("<td>" + HandleNullTextValue(br.BranchAddress2) + "</td>");
                    tr.append("<td class='d-none'>" + HandleNullTextValue(br.BranchCountryId) + "</td>");
                    tr.append("<td>" + HandleNullTextValue(br.BranchCountryName) + "</td>");
                    tr.append("<td class='d-none'>" + HandleNullTextValue(br.BranchStateId) + "</td>");
                    tr.append("<td>" + HandleNullTextValue(br.BranchStateName) + "</td>");
                    tr.append("<td>" + HandleNullTextValue(br.BranchCity) + "</td>");
                    tr.append("<td>" + HandleNullTextValue(br.BranchGstin) + "</td>");
                    tr.append("<td>" + HandleNullTextValue(br.BranchPinCode) + "</td>");
                    $('#tbl_ledger_branch').append(tr);
                });
            }
            else
                Toast(RetrieveMessage(obj.responsecode), "Message", "error");
        }
        else
            window.location.href = '/ClientLogin/ClientLogin';
        //Hideloader();
    }).fail(function (result) {
        //Hideloader();
        console.log(result.Message);
    });
}

//ADD BRANCH BUTTON CLICKED
$("#AddBranch").click(function () {
    if ($("#BranchID").val() != null) {
        if ($("#BranchID").val() == '00') {
            $("#BranchID").addClass('error-textbox')
            $("#BranchID").focus();
            Toast("Branch Code Can't Be 00 !", 'message', 'error');
            return;
        }
    }
    if ($("#BranchName").val().trim().length == 0) {
        $("#BranchName").addClass('error-textbox')
        $("#BranchName").focus();
        Toast("Please Add Branch Name !", 'Message', 'error');
        return;
    }
    if ($("#BranchContactEmail").val() != "" && !EMAIL_EXPR.test($("#BranchContactEmail").val().trim())) {
        $("#BranchContactEmail").addClass('error-textbox')
        $("#BranchContactEmail").focus();
        Toast("Invalid Email Address !", 'Message', 'error');
        flag = 1;
        return;
    }
    if ($("#BranchContactMobile").val() != "" && $("#BranchContactMobile").val().length < 10) {
        $("#BranchContactMobile").addClass('error-textbox')
        $("#BranchContactMobile").focus();
        Toast("Please Input 10 Digit Mobile Number !", 'message', 'error');
        return;
    }
    if ($("#BranchAddressFirst").val().trim().length == 0) {
        $("#BranchAddressFirst").addClass('error-textbox')
        $("#BranchAddressFirst").focus();
        Toast("Please Add First Address !", 'Message', 'error');
        return;
    }
    if ($("#HiddenBranchCountry").val().trim().length == 0) {
        $("#BranchCountry").addClass('error-textbox')
        $("#BranchCountry").focus();
        Toast("Please Add Country Name !", 'Message', 'error');
        return;
    }
    if ($("#HiddenBranchState").val().trim().length == 0) {
        $("#BranchState").addClass('error-textbox')
        $("#BranchState").focus();
        Toast("Please Add State Name !", 'Message', 'error');
        return;
    }
    if ($("#BranchGstin").val() != "") {
        $("#BranchGstin").trigger("onblur");
        if ($("#BranchGstin").hasClass('error-textbox')) {
            $("#BranchGstin").focus();
            return;
        }
    }
    LedgerBranchFormAdd();
});

//FUNCTION FOR ADD LEDGER BRANCH
function LedgerBranchFormAdd() {
    try {
        const dataString = {};
        dataString.BranchCode = $("#BranchID").val();
        dataString.BranchName = $("#BranchName").val();
        dataString.BranchContactPerson = $("#BranchContactPerson").val();
        dataString.BranchEmail = $("#BranchContactEmail").val();
        dataString.BranchMobile = $("#BranchContactMobile").val();
        dataString.BranchAddress1 = $("#BranchAddressFirst").val();
        dataString.BranchAddress2 = $("#BranchAddressSecond").val();
        dataString.BranchCountryId = $("#HiddenBranchCountry").val();
        dataString.BranchstateId = $("#HiddenBranchState").val();
        dataString.BranchCity = $("#BranchCityName").val();
        dataString.BranchGstin = $("#BranchGstin").val();
        dataString.BranchPincode = $("#BranchPinCode").val();
        dataString.LedgerUid = formid;
        dataString.BranchIsSez = $('#BranchIsSez').is(':checked') ? 1 : 0;
        //Showloader();
        AjaxSubmission(JSON.stringify(dataString), "/Ledger/LedgerBranchFormAdd", $('input[name=__RequestVerificationToken]').val()).done(function (result) {
            let obj = result;
            if (obj.status == true) {
                if (obj.responsecode == '101') {
                    Toast(RetrieveMessage(obj.responsecode), "Message", "success");
                    ResetBranchData();
                    FillLedgerBranchList();
                }
                else
                    Toast(RetrieveMessage(obj.responsecode), "Message", "error");
            }
            else
                window.location.href = '/ClientLogin/ClientLogin';
            //Hideloader();
        }).fail(function (result) {
            //Hideloader();
            console.log(result.Message);
        });
    }
    catch (e) {
        //Hideloader();
        console.log(e.message);
    }
}

//FUNCTION FOR EDIT LEDGER BRANCH
function LedgerBranchFormEdit(BranchUid) {

    try {
        $("#BranchModal").show();
        $("#AddBranch").addClass('d-none');
        $("#UpdateBranch").removeClass('d-none');
        const dataString = {};
        dataString.BranchUid = parseInt(BranchUid);
        dataString.LedgerUid = formid;
        //Showloader();
        AjaxSubmission(JSON.stringify(dataString), "/Master/Ledger/LedgerBranchFormEdit", $('[name="__RequestVerificationToken"]').val()).done(function (data) {
            let obj = data;

            if (obj.status == true) {
                if (obj.responsecode == '100') {
                    TabShow();
                    $("#BranchName").val(obj.data.Table[0].BranchName);
                    $("#BranchID").val(obj.data.Table[0].BranchCode);
                    $("#BranchContactPerson").val(obj.data.Table[0].BranchContactPerson);
                    $("#BranchContactEmail").val(obj.data.Table[0].BranchEmail);
                    $("#BranchContactMobile").val(obj.data.Table[0].BranchMobile);
                    $("#BranchAddressFirst").val(obj.data.Table[0].BranchAddress1);
                    $("#BranchAddressSecond").val(obj.data.Table[0].BranchAddress2);

                    $("#HiddenBranchCountry").val(obj.data.Table[0].BranchCountryId);
                    $("#BranchCountry").val(obj.data.Table[0].BranchCountryName);

                    $("#BranchCityName").val(obj.data.Table[0].BranchCity);

                    $("#HiddenBranchState").val(obj.data.Table[0].BranchStateId);
                    $("#BranchState").val(obj.data.Table[0].BranchStateName);

                    $("#BranchGstin").val(obj.data.Table[0].BranchGstin);
                    $("#BranchPinCode").val(obj.data.Table[0].BranchPinCode);
                    $('#BranchIsSez').prop('checked', obj.data.Table[0].IsSez);

                }
                else {
                    Toast(RetrieveMessage(obj.responsecode), "Message", "error");
                }
            }
            else {
                window.location.href = '/ClientLogin/ClientLogin';
            }
            //Hideloader();
        }).fail(function (data) {
            console.log(data.Message);
            //Hideloader();
        });
    }
    catch (e) {
        console.log(e.message);
        //Hideloader();
    }
}

//UPDATE BRANCH BUTTON CLICKED
$("#UpdateBranch").click(function () {
    if ($("#BranchID").val() != null) {
        if ($("#BranchID").val() == '00') {
            $("#BranchID").addClass('error-textbox')
            $("#BranchID").focus();
            Toast("Branch Code Can't Be 00 !", 'message', 'error');
            return;
        }
    }
    if ($("#BranchName").val().trim().length == 0) {
        $("#BranchName").addClass('error-textbox')
        $("#BranchName").focus();
        Toast("Please Add Branch Name !", 'Message', 'error');
        return;
    }
    if ($("#BranchContactEmail").val() != "" && !EMAIL_EXPR.test($("#BranchContactEmail").val().trim())) {
        $("#BranchContactEmail").addClass('error-textbox')
        $("#BranchContactEmail").focus();
        Toast("Invalid Email Address !", 'Message', 'error');
        flag = 1;
        return;
    }
    if ($("#BranchContactMobile").val() != "" && $("#BranchContactMobile").val().length < 10) {
        $("#BranchContactMobile").addClass('error-textbox')
        $("#BranchContactMobile").focus();
        Toast("Please Input 10 Digit Mobile Number !", 'message', 'error');
        return;
    }
    if ($("#BranchAddressFirst").val().trim().length == 0) {
        $("#BranchAddressFirst").addClass('error-textbox')
        $("#BranchAddressFirst").focus();
        Toast("Please Add First Address !", 'Message', 'error');
        return;
    }
    if ($("#HiddenBranchCountry").val().trim().length == 0) {
        $("#BranchCountry").addClass('error-textbox')
        $("#BranchCountry").focus();
        Toast("Please Add Country Name !", 'Message', 'error');
        return;
    }
    if ($("#HiddenBranchState").val().trim().length == 0) {
        $("#BranchState").addClass('error-textbox')
        $("#BranchState").focus();
        Toast("Please Add State Name !", 'Message', 'error');
        return;
    }
    if ($("#BranchGstin").val() != "") {
        $("#BranchGstin").trigger("onblur");
        if ($("#BranchGstin").hasClass('error-textbox')) {
            $("#BranchGstin").focus();
            return;
        }
    }
    LedgerBranchFormUpdate();
});

//FUNCTION FOR UPDATE LEDGER BRANCH 
function LedgerBranchFormUpdate() {
    try {
        const dataString = {};
        var BCode = $("#BranchID").val().trim();
        dataString.BranchUid = BCode;
        dataString.BranchCode = $("#BranchID").val();
        dataString.BranchName = $("#BranchName").val();
        dataString.BranchContactPerson = $("#BranchContactPerson").val();
        dataString.BranchEmail = $("#BranchContactEmail").val();
        dataString.BranchMobile = $("#BranchContactMobile").val();
        dataString.BranchAddress1 = $("#BranchAddressFirst").val();
        dataString.BranchAddress2 = $("#BranchAddressSecond").val();
        dataString.BranchCountryId = $("#HiddenBranchCountry").val();
        dataString.BranchstateId = $("#HiddenBranchState").val();
        dataString.BranchCity = $("#BranchCityName").val();
        dataString.BranchGstin = $("#BranchGstin").val();
        dataString.BranchPincode = $("#BranchPinCode").val();
        dataString.LedgerUid = formid;
        dataString.BranchIsSez = $('#BranchIsSez').is(':checked') ? 1 : 0;
        //Showloader();
        AjaxSubmission(JSON.stringify(dataString), "/Master/Ledger/LedgerBranchFormUpdate", $('input[name=__RequestVerificationToken]').val()).done(function (result) {
            let obj = result;
            if (obj.status == true) {
                if (obj.responsecode == '107') {
                    Toast(RetrieveMessage(obj.responsecode), "Message", "success");
                    ResetBranchData();
                    FillLedgerBranchList();
                }
                else
                    Toast(RetrieveMessage(obj.responsecode), "Message", "error");
            }
            else {
                window.location.href = '/ClientLogin/ClientLogin';
            }
            //Hideloader();
        }).fail(function (result) {
            console.log(result.Message);
            //Hideloader();
        });
    }
    catch (e) {
        console.log(e.message);
        //Hideloader();
    }
}

//FUNCTION FOR DELETE CUSTOM PORT 
function LedgerBranchFormDelete(e) {
    debugger
    try {
        $.confirm({
            title: '',
            content: 'Are You Sure Want To Delete ?',
            type: 'red',
            boxWidth: '300px',
            useBootstrap: false,
            columnClass: 'small',
            containerFluid: true,
            typeAnimated: true,
            buttons: {
                tryAgain: {
                    text: 'Confirm',
                    btnClass: 'btn-red',
                    action: function () {
                        const datastring = {};
                        datastring.BranchUid = parseInt(e);
                        datastring.LedgerUid = formid;                      
                        //Showloader();
                        AjaxSubmission(JSON.stringify(datastring), "/Master/Ledger/LedgerBranchFormDelete", $('[name="__RequestVerificationToken"]').val()).done(function (data) {
                            let obj = data;
                            if (obj.status == true) {
                                if (obj.responsecode == '102') {
                                    Toast(RetrieveMessage(obj.responsecode), "Message", "success");
                                    FillLedgerBranchList();
                                }
                                else {
                                    Toast(RetrieveMessage(obj.responsecode), "Message", "error");
                                }
                            }
                            else {
                                window.location.href = 'ClientLogin/ClientLogin';
                            }
                            //Hideloader();
                        }).fail(function (data) {
                            console.log(data.Message);
                            //Hideloader();
                        });
                    }
                },
                close: function () {
                    //Hideloader();
                }
            }
        });
    }
    catch (e) {
        console.log(e.message);
        //Hideloader();
    }
}


//FUNCTION FOR FILL LEDGER BANK LIST
function FillLedgerBankList() {   
    const dataString = {};
    dataString.LedgerUid = formid;
    AjaxSubmission(JSON.stringify(dataString), "/Ledger/LedgerBankFormList", $('input[name=__RequestVerificationToken]').val()).done(function (result) {
        let obj = result;
        if (obj.status == true) {
            if (obj.responsecode == '100') {
                $("#tbl_ledger_bank tbody tr").remove();
                $.each(obj.data.Table, function (i, ldbank) {
                    var tr;
                    tr = $('<tr/>');
                    tr.append("<td class='text-center'><button type='button' onclick='LedgerBankFormEdit(\"" + ldbank.LedgerBankUid + "\");' class='common-btn common-btn-sm '><i class='fa fa-edit'></i></button><button style='margin-left: 10px;' type='button'  onclick='LedgerBankFormDelete(\"" + ldbank.LedgerBankUid + "\");' class='common-btn common-btn-sm ''><i class='fa-regular fa-trash-can'></i></button></td>");
                    tr.append("<td>" + HandleNullTextValue(ldbank.LedgerBankUid) + "</td>");
                    tr.append("<td>" + HandleNullTextValue(ldbank.LedgerBankAccNo) + "</td>");
                    tr.append("<td>" + HandleNullTextValue(ldbank.LedgerBankName) + "</td>");
                    tr.append("<td>" + HandleNullTextValue(ldbank.LedgerBankIfscCode) + "</td>");
                    tr.append("<td>" + HandleNullTextValue(ldbank.LedgerBankAdCode) + "</td>");
                   
                    $("#tbl_ledger_bank").append(tr);
                });
            }
            else
                Toast(RetrieveMessage(obj.responsecode), "Message", "error");
        }
        else
            window.location.href = '/ClientLogin/ClientLogin';
        //Hideloader();
    }).fail(function (result) {
        //Hideloader();
        console.log(result.Message);
    });
}

//ADD BANK BUTTON CLICK EVENT
$("#AddBank").click(function () {
    //if ($("#LedgBankAccNo").val() == '') {
    //    $("#LedgBankAccNo").addClass("error-textbox");
    //    $("#LedgBankAccNo").focus();
    //    Toast("Please Fill Account Number !", 'Message', 'error');
    //    return;
    //}
    //if ($("#LedgBankName").val() == '') {
    //    $("#LedgBankName").addClass("error-textbox");
    //    $("#LedgBankName").focus();
    //    Toast("Please Fill Bank Name !", 'Message', 'error');
    //    return;
    //} else if ($("#LedgBankName").val().length < 4) {
    //    $("#LedgBankName").trigger('onblur')
    //    $("#LedgBankName").focus();
    //    return;
    //}
    //if ($("#LeddgBankIFSCCode").val() == '') {
    //    $("#LeddgBankIFSCCode").addClass("error-textbox");
    //    $("#LeddgBankIFSCCode").focus();
    //    Toast("Please Fill IFSC Code !", 'Message', 'error');
    //    return;
    //}
    //LedgerBankFormAdd();


    let filledFields = 0;

    if ($("#LedgBankAccNo").val().trim() != '') {
        filledFields++;
    }
    if ($("#LedgBankName").val().trim() != '') {
        filledFields++;
    }
    if ($("#LeddgBankIFSCCode").val().trim() != '') {
        filledFields++;
    }
    if ($("#ADCode").val().trim().trim() != '') {
        filledFields++;
    }

    if (filledFields === 0) {
        Toast("Please Fill Atleast One Field !", 'Message', 'error');
        return;
    }
    LedgerBankFormAdd();
});

//FUNCTION FOR ADD LEDGER BANK
function LedgerBankFormAdd() {
    try {
        const dataString = {};
        dataString.LedgerBankAccNo = $("#LedgBankAccNo").val();
        dataString.LedgerBankName = $("#LedgBankName").val();
        dataString.LedgerBankIfscCode = $("#LeddgBankIFSCCode").val();
        dataString.LedgerBankAdCode = $("#ADCode").val();
        dataString.LedgerUid = formid;
        //Showloader();
        AjaxSubmission(JSON.stringify(dataString), "/Ledger/LedgerBankFormAdd", $('input[name=__RequestVerificationToken]').val()).done(function (result) {
            let obj = result;
            if (obj.status == true) {
                if (obj.responsecode == '101') {
                    Toast(RetrieveMessage(obj.responsecode), "Message", "success");
                    ResetBankData();
                    FillLedgerBankList();
                }
                else
                    Toast(RetrieveMessage(obj.responsecode), "Message", "error");
            }
            else
                window.location.href = '/ClientLogin/ClientLogin';
            //Hideloader();
        }).fail(function (result) {
            //Hideloader();
            console.log(result.Message);
        });
    }
    catch (e) {
        //Hideloader();
        console.log(e.message);
    }
}

//FUNCTION FOR EDIT LEDGER BANK
function LedgerBankFormEdit(LedgerBankUid) {
    try {
        $("#BankModal").show();
        $("#AddBank").addClass('d-none');
        $("#UpdateBank").removeClass('d-none');
        const dataString = {};
        dataString.LedgerBankUid = parseInt(LedgerBankUid);
        dataString.LedgerUid = formid;
        //Showloader();
        AjaxSubmission(JSON.stringify(dataString), "/Master/Ledger/LedgerBankFormEdit", $('[name="__RequestVerificationToken"]').val()).done(function (data) {
            let obj = data;

            if (obj.status == true) {
                if (obj.responsecode == '100') {
                    TabShow();
                    $("#LedgBankAccNo").val(obj.data.Table[0].LedgerBankAccNo);
                    $("#LedgBankName").val(obj.data.Table[0].LedgerBankName);
                    $("#LeddgBankIFSCCode").val(obj.data.Table[0].LedgerBankIfscCode);
                    $("#ADCode").val(obj.data.Table[0].LedgerBankAdCode);
                }
                else {
                    Toast(RetrieveMessage(obj.responsecode), "Message", "error");
                }
            }
            else {
                window.location.href = '/ClientLogin/ClientLogin';
            }
            //Hideloader();
        }).fail(function (data) {
            console.log(data.Message);
            //Hideloader();
        });
    }
    catch (e) {
        console.log(e.message);
        //Hideloader();
    }
}

//UPDATE BANK BUTTON CLICK EVENT
$("#UpdateBank").click(function () {
    //if ($("#LedgBankAccNo").val() == '') {
    //    $("#LedgBankAccNo").addClass("error-textbox");
    //    $("#LedgBankAccNo").focus();
    //    Toast("Please Fill Account Number !", 'Message', 'error');
    //    return;
    //}
    //if ($("#LedgBankName").val() == '') {
    //    $("#LedgBankName").addClass("error-textbox");
    //    $("#LedgBankName").focus();
    //    Toast("Please Fill Bank Name !", 'Message', 'error');
    //    return;
    //}
    //else if ($("#LedgBankName").val().length < 4) {
    //    $("#LedgBankName").trigger('onblur')
    //    $("#LedgBankName").focus();
    //    return;
    //}
    //if ($("#LeddgBankIFSCCode").val() == '') {
    //    $("#LeddgBankIFSCCode").addClass("error-textbox");
    //    $("#LeddgBankIFSCCode").focus();
    //    Toast("Please Fill IFSC Code !", 'Message', 'error');
    //    return;
    //}
    //LedgerBankFormUpdate();

    let filledFields = 0;

    if ($("#LedgBankAccNo").val().trim() != '') {
        filledFields++;
    }
    if ($("#LedgBankName").val().trim() != '') {
        filledFields++;
    }
    if ($("#LeddgBankIFSCCode").val().trim() != '') {
        filledFields++;
    }
    if ($("#ADCode").val().trim().trim() != '') {
        filledFields++;
    }
    if (filledFields === 0) {
        Toast("Please Fill Atleast One Field !", 'Message', 'error');
        return;
    }

    LedgerBankFormUpdate();
});


//FUNCTION FOR UPDATE LEDGER BANK 
function LedgerBankFormUpdate() {
    try {
        const dataString = {};
        //var BCode = $("#BranchID").val().trim();
        //dataString.BranchUid = BCode;
        /*  dataString.BranchCode = $("#BranchID").val();*/
        dataString.LedgerBankAccNo = $("#LedgBankAccNo").val();
        dataString.LedgerBankName = $("#LedgBankName").val();
        dataString.LedgerBankIfscCode = $("#LeddgBankIFSCCode").val();
        dataString.LedgerBankAdCode = $("#ADCode").val();
        dataString.LedgerUid = formid;
        //Showloader();
        AjaxSubmission(JSON.stringify(dataString), "/Master/Ledger/LedgerBankFormUpdate", $('input[name=__RequestVerificationToken]').val()).done(function (result) {
            let obj = result;
            if (obj.status == true) {
                if (obj.responsecode == '107') {
                    Toast(RetrieveMessage(obj.responsecode), "Message", "success");
                    ResetBankData();
                    FillLedgerBankList();
                }
                else
                    Toast(RetrieveMessage(obj.responsecode), "Message", "error");
            }
            else {
                window.location.href = '/ClientLogin/ClientLogin';
            }
            //Hideloader();
        }).fail(function (result) {
            console.log(result.Message);
            //Hideloader();
        });
    }
    catch (e) {
        console.log(e.message);
        //Hideloader();
    }
}



//FUNCTION FOR DELETE LEDGER BANK 
function LedgerBankFormDelete(e) {   
    try {
        $.confirm({
            title: '',
            content: 'Are You Sure Want To Delete ?',
            type: 'red',
            boxWidth: '300px',
            useBootstrap: false,
            columnClass: 'small',
            containerFluid: true,
            typeAnimated: true,
            buttons: {
                tryAgain: {
                    text: 'Confirm',
                    btnClass: 'btn-red',
                    action: function () {
                        const datastring = {};
                        datastring.LedgerBankUid = parseInt(e);
                        datastring.LedgerUid = formid;                      
                        //Showloader();
                        AjaxSubmission(JSON.stringify(datastring), "/Master/Ledger/LedgerBankFormDelete", $('[name="__RequestVerificationToken"]').val()).done(function (data) {
                            let obj = data;
                            if (obj.status == true) {
                                if (obj.responsecode == '102') {
                                    Toast(RetrieveMessage(obj.responsecode), "Message", "success");
                                    FillLedgerBankList();
                                }
                                else {
                                    Toast(RetrieveMessage(obj.responsecode), "Message", "error");
                                }
                            }
                            else {
                                window.location.href = 'ClientLogin/ClientLogin';
                            }
                            //Hideloader();
                        }).fail(function (data) {
                            console.log(data.Message);
                            //Hideloader();
                        });
                    }
                },
                close: function () {
                    //Hideloader();
                }
            }
        });
    }
    catch (e) {
        console.log(e.message);
        //Hideloader();
    }
}

//FORM RESET BUTTON CLICK EVENT
$("#FormReset").click(function () {
    ResetForm();
});

////FUNCTION FOR GO TO SUB GROUP HEADS
//function GoToSubGroupHeads(e) {
//    localStorage.setItem("PageName",' Sub Group Heads');
//    SetCookie('SubGroupId', $("#" + e).val(), 's', 50);
//}

/*---------------------------------------------------------add update edit subgroup modal----------------------------------------------------------------------*/


$("#OpenSubGroupModal").click(function () {
    modal2.style.display = 'block';
    if ($("#HiddenLedgerGroup").val() == 0) {


        $("#GroupModalFormAdd").show();
        $("#GroupModalFormUpdate").hide();

    }
    else {

        SubGroupFormEdit($("#HiddenLedgerGroup").val());

        $("#GroupModalFormAdd").hide();
        $("#GroupModalFormUpdate").show();


    }
});

//SUBGROUP ADD BUTTON CLICK
$("#GroupModalFormAdd").click(function () {

    RemoveAllError('SubGroupHeadForm');
    ValidateAllFieldNewTest('SubGroupHeadForm');

    if (Ercount == 0) {
        if ($("#GroupModalGroupId").val() == "0") {
            Toast(RetrieveMessage(805), 'Message', 'error');
            return;
        }
        SubGroupFormAdd();
    }
});

//ADD SUBGROUP FUNCTION
function SubGroupFormAdd() {
    try {
        const datastring = {};
        datastring.SubGroupName = $("#GroupModalSubGroupName").val();
        datastring.GroupId = $("#GroupModalGroupId").val();
        datastring.OrderPlBs = $("#GroupModalOrderNo").val();
        datastring.DetailPlBs = $("#GroupModalDetailPlBs").is(":checked");
        datastring.AcceptAddress = $("#GroupModalAcceptAddress").is(":checked");

        ShowLoader();
        AjaxSubmission(JSON.stringify(datastring), "/Master/SubGroupHeads/FormAdd", $('input[name=__RequestVerificationToken]').val()).done(function (result) {
            let obj = result;
            if (obj.status == true) {
                if (obj.responsecode == '101') {
                    Toast(RetrieveMessage(obj.responsecode), "Message", "success");


                    $("#GroupModalFormAdd").hide();
                    $("#GroupModalFormUpdate").show();
                    $("#GroupModalFormReset").show();
                    $("#GroupModalSubGroupId").val(obj.data.Table[0].SubgroupHeadUid);
                    $("#GroupModalTimestamp").val(obj.data.Table[0].Timestamp);
                }
                else {
                    Toast(RetrieveMessage(obj.responsecode), "Message", "error");
                }
            }
            else {
                window.location.href = '/ClientLogin/ClientLogin';
            }
            HideLoader();
        }).fail(function (result) {
            console.log(result.Message);
            HideLoader();
        });
    }
    catch (e) {
        console.log(e.message);
        HideLoader();
    }
}

//EDIT SUBGROUP FUNCTION
function SubGroupFormEdit(e) {
    try {
        $("#GroupModalFormAdd").addClass('d-none');
        $("#GroupModalFormUpdate").removeClass('d-none');

        const datastring = {};
        datastring.SubGroupId = e;
        ShowLoader();
        AjaxSubmission(JSON.stringify(datastring), "/Master/SubGroupHeads/FormEdit", $('[name="__RequestVerificationToken"]').val()).done(function (data) {
            let obj = data;          
            if (obj.status == true) {
                if (obj.responsecode == '100') {
                    TabShow();
                    if (obj.data.Table[0].SystemAccount == true) {
                        $("GroupModal#SubGroupName").attr("disabled", "disabled");
                    }
                    $("#GroupModalSubGroupId").val(obj.data.Table[0].SubgroupHeadUid);
                    $("#GroupModalTimestamp").val(obj.data.Table[0].Timestamp);
                    $("#GroupModalSubGroupName").val(obj.data.Table[0].SubgroupHeadName);
                    $("#GroupModalGroupId").val(obj.data.Table[0].GroupHeadUid).trigger('change');
                    $("#GroupModalOrderNo").val(obj.data.Table[0].OrderPLBS);
                    $("#GroupModalDetailPlBs").prop("checked", obj.data.Table[0].DetailedPLBS);
                    $("#GroupModalAcceptAddress").prop("checked", obj.data.Table[0].AcceptAddress);
                } else {
                    Toast(RetrieveMessage(obj.responsecode), "Message", "error");
                }
            }
            else {
                window.location.href = '/ClientLogin/ClientLogin';
            }
            HideLoader();
        }).fail(function (data) {
            console.log(data.Message);
            HideLoader();
        });
    }
    catch (e) {
        console.log(e.message);
        HideLoader();
    }
}

//SUBGROUP UPDATE BUTTON CLICK
$("#GroupModalFormUpdate").click(function () {
    RemoveAllError('SubGroupHeadForm');
    ValidateAllFieldNewTest('SubGroupHeadForm');
    if (Ercount == 0) {
        if ($("#GroupModalGroupId").val() == "0") {
            Toast(RetrieveMessage(804), 'Message', 'error');
            return;
        }
        SubGroupFormUpdate();
    }
});

//UPDATE SUBGROUP FUNCTION
function SubGroupFormUpdate() {
    try {
        const datastring = {};
        datastring.SubGroupName = $("#GroupModalSubGroupName").val();
        datastring.OrderPlBs = $("#GroupModalOrderNo").val();
        datastring.DetailPlBs = $("#GroupModalDetailPlBs").is(":checked");
        datastring.AcceptAddress = $("#GroupModalAcceptAddress").is(":checked");
        datastring.GroupId = $("#GroupModalGroupId").val();
        datastring.SubGroupId = $("#GroupModalSubGroupId").val();
        datastring.Timestamp = $("#GroupModalTimestamp").val();
        ShowLoader();
        AjaxSubmission(JSON.stringify(datastring), "/Master/SubGroupHeads/FormUpdate", $('input[name=__RequestVerificationToken]').val()).done(function (result) {
            let obj = result;
            if (obj.status == true) {
                if (obj.responsecode == '107') {
                    Toast(RetrieveMessage(obj.responsecode), "Message", "success");

                    $("#GroupModalSubGroupId").val(obj.data.Table[0].SubgroupHeadUid);
                    $("#GroupModalTimestamp").val(obj.data.Table[0].Timestamp);
                }
                else {
                    Toast(RetrieveMessage(obj.responsecode), "Message", "error");
                }
            }
            else {
                window.location.href = '/ClientLogin/ClientLogin';
            }
            HideLoader();
        }).fail(function (result) {
            console.log(result.Message);
            HideLoader();
        });
    }
    catch (e) {
        console.log(e.message);
        HideLoader();
    }
}
function SubGroupResetForm() {
    modal2.style.display = 'none';
    $("#GroupModalSubGroupId").val('');
    $("#GroupModalTimestamp").val('');
    $("#GroupModalSubGroupName").val('');
    $("#GroupModalSubGroupName").removeAttr("disabled");
    $("#GroupModalGroupId").val('0').trigger('change');
    $("#GroupModalDetailPlBs").prop("checked", false);
    $("#GroupModalAcceptAddress").prop("checked", false);
    $("#GroupModalOrderNo").val('');

    $("#GroupModalFormAdd").removeClass('d-none');
    $("#GroupModalFormUpdate").addClass('d-none');

    RemoveAllError('SubGroupHeadForm');
};
//FUNCTION FOR BIND GROUP NAME
function FillGroupList() {
    try {
        //Showloader();
        AjaxSubmission(null, "/Master/SubGroupHeads/GetGroupList", $('input[name=__RequestVerificationToken]').val()).done(function (result) {
            let obj = result;
            if (obj.status == true) {
                if (obj.responsecode == '100') {
                    BindDropdown(obj.data.Table, 'GroupModalGroupId', 'GroupHeadUid', 'GroupHeadName', '-----Select-----');
                }
                else if (obj.responsecode == '604') {
                    BindDropdown(null, 'GroupModalGroupId', 'GroupHeadUid', 'GroupHeadName', '-----Select-----');
                }
                else {
                    Toast(RetrieveMessage(obj.responsecode), "Message", "error");
                }

            }
            else {
                window.location.href = '/ClientLogin/ClientLogin';
            }
            //Hideloader();
        }).fail(function (result) {
            console.log(result.Message);
            //Hideloader();
        });
    }
    catch (e) {
        console.log(e.message);
        //Hideloader();
    }
}
$("#GroupModalClose").click(function () {
    $('#UserName')
});

//FUNCTION FOR TINYMCE EDITIOR
function LoadTinyMCE() {
    tinymce.init({
        selector: ".tinymce",
        branding: false,
        theme: "modern",
        skin: "lightgray",
        width: "100%",
        height: 250,
        statubar: true,
        plugins: [
            "advlist autolink link image lists charmap print preview hr anchor pagebreak",
            "searchreplace wordcount visualblocks visualchars code fullscreen insertdatetime media nonbreaking",
            "save table contextmenu directionality emoticons template paste textcolor"
        ],
        toolbar: "insertfile undo redo | styleselect | bold italic | alignleft aligncenter alignright alignjustify | bullist numlist outdent indent | link | fontsizeselect | fontselect | image | print preview media fullpage | forecolor backcolor emoticons ",
        style_formats: [
            {
                title: "Headers", items: [
                    { title: "Header 1", format: "h1" },
                    { title: "Header 2", format: "h2" },
                    { title: "Header 3", format: "h3" },
                    { title: "Header 4", format: "h4" },
                    { title: "Header 5", format: "h5" },
                    { title: "Header 6", format: "h6" }
                ]
            },
            {
                title: "Inline", items: [
                    { title: "Bold", icon: "bold", format: "bold" },
                    { title: "Italic", icon: "italic", format: "italic" },
                    { title: "Underline", icon: "underline", format: "underline" },
                    { title: "Strikethrough", icon: "strikethrough", format: "strikethrough" },
                    { title: "Superscript", icon: "superscript", format: "superscript" },
                    { title: "Subscript", icon: "subscript", format: "subscript" },
                    { title: "Code", icon: "code", format: "code" }
                ]
            },
            {
                title: "Blocks", items: [
                    { title: "Paragraph", format: "p" },
                    { title: "Blockquote", format: "blockquote" },
                    { title: "Div", format: "div" },
                    { title: "Pre", format: "pre" }
                ]
            },
            {
                title: "Alignment", items: [
                    { title: "Left", icon: "alignleft", format: "alignleft" },
                    { title: "Center", icon: "aligncenter", format: "aligncenter" },
                    { title: "Right", icon: "alignright", format: "alignright" },
                    { title: "Justify", icon: "alignjustify", format: "alignjustify" }
                ]
            }
        ],
    });
}

/*INVITEUSER BUUTON CLICKED EVENT*/
$('#InviteUser').click(function () {
    if ($("#UserName").val().length == 0) {
        Toast("Please Enter User Name !", "message", "error");
        $('#UserName').focus();
        return;
    }
    else if ($("#UserName").val().length < 4 || $("#UserName").val().length > 50) {
        Toast("Minimum 4 Charcter and Maximum 50 Charcters allow in  User Name !", "message", "error");
        return;
    }
    else if (!EMAIL_EXPR.test($('#UserName').val().trim())) {
        Toast("Invalid Email Address !", 'Message', 'error');
        $('#UserName').focus();
        return false;
    }
    //if ($('#Password').val().trim().length > 0) {
    //    if ($("#Password").val().length < 6 || $("#Password").val().length > 12) {
    //        Toast("Minimum 6 Charcter and Maximum 12 Charcters allow in  Password !", "message", "error");
    //        $('#Password').focus();
    //        return;
    //    }
    //    else if (!CheckPasswordPattern($("#Password").val())) {
    //        Toast("Password must contain at least one number and one uppercase and lowercase letter, and at least 6  characters and maximum 12 characters !", "Message", "warning");
    //        $('#Password').focus();
    //        return;
    //    }
    //}
   
     GetEmailData();
});

// FUNCTION TO GET EMAIL DATA AND TEMPLATE WORK 
function GetEmailData() {
    try {
        ShowLoader();
        const datastring = {};
        datastring.LedgerUid = $("#LedgerId").val();
        AjaxSubmission(JSON.stringify(datastring), "/Master/Ledger/GetEmailData", $('input[name=__RequestVerificationToken]').val()).done(function (result) {
            let obj = result;
            if (obj.status == true) {
                if (obj.responsecode == '100') {                   
                    EmailModal.style.display = "block";
                    $("#EmailTo").val(obj.data.Table[0].ClientEmail);
                    $("#EmailCC").val(obj.data.Table[0].CCEmail);
                    
                    $("#RefId").val($("#LedgerId").val());
                    $("#SendToName").val($("#AccHead").val());
                    $("#RefName").val('LedgerInvite');
                    BindTemplateName('AllTemplate', 'Email');
                    FillTemplateDataInTincyMce($('#LedgerId').val(), 'LedgerInvite', null, 'Email','LedgerInvite');

                }
                else {
                    Toast(RetrieveMessage(obj.responsecode), "Message", "error");
                }
            }
            else {
                window.location.href = '/ClientLogin/ClientLogin';
            }
            HideLoader();
        }).fail(function (result) {
            console.log(result.Message);
            HideLoader();
        });
    }
    catch (e) {
        console.log(e.message);
        HideLoader();
    }
}

//FUNCTION FOR EXPORT DATA IN EXCEL
function FormExcel() {
    ShowLoader();
    let date = new Date();
    let NewDate = ("00" + date.getDate()).slice(-2) + "_" + ("00" + (date.getMonth() + 1)).slice(-2) + "_" + date.getFullYear() + "_" + ("00" + date.getHours()).slice(-2) + "_" + ("00" + date.getMinutes()).slice(-2) + "_" + ("00" + date.getSeconds()).slice(-2);
    let fileName = "Ledger_" + NewDate + ".xlsx";

    $('#FormSearch').trigger('click');
    AjaxSubmission(null, '/Master/Ledger/FormExcel', $('input[name=__RequestVerificationToken]').val()).done(function (result) {
        let obj = result;
        if (obj.status == true) {
            if (obj.responsecode == '100') {

                let bytes = Base64ToBytes(obj.data.FileData[0].Base64Data);
                let blob = new Blob([bytes], { type: "application/octetstream" });
                let isIE = false || !!document.documentMode;
                if (isIE) {
                    window.navigator.msSaveBlob(blob, fileName);
                } else {
                    let url = window.URL || window.webkitURL;
                    link = url.createObjectURL(blob);
                    let a = $("<a />");
                    a.attr("download", fileName);
                    a.attr("href", link);
                    $("body").append(a);
                    a[0].click();
                    $("body").remove(a);
                }
            }
            else if (obj.responsecode == '302')
                Toast("No Records found.", 'Message', 'success');
            else
                Toast(RetrieveMessage(obj.responsecode), 'Message', 'error');

        } else
            window.location.href = '/ClientLogin/ClientLogin';
        HideLoader();

    }).fail(function (result) {
        console.log(result.Message);
        HideLoader();
    });
}

//FUNCTION FOR CHANGE TEMPLATE DETAILS
function TemplateChange() {   
    tinymce.get("EmailBody").setContent('');
    $('#Subject').val('');
    if ($('#AllTemplate').val() != null && $('#AllTemplate') != undefined) {
        if ($('#AllTemplate').val() != 0)
            FillTemplateDataInTincyMce($('#LedgerId').val(), 'LedgerInvite', $('#AllTemplate').val(), 'Email');
    }
}


document.addEventListener("keydown", function (zEvent) {
    if (zEvent.ctrlKey && zEvent.altKey && (zEvent.key == "j" || zEvent.key == "J")) {
        $('#Ledger_list-tab').removeClass('active ');
        $('#Ledger_list').removeClass('active show');
        $('#Ledger-tab').addClass('active');
        $('#Ledger').addClass('active show');
        $("#Opening_Balance-tab").addClass('d-none');
        $("#FormAdd").show();
        $("#FormUpdate").hide();
        $("#FormReset").hide();
        $("#Ledger-tab").html("Add Ledger ");
        ResetForm();
        $('#AccHead').focus();
    }
});
