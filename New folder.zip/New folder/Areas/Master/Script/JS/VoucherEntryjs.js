﻿var Firstcolumn = "";
var DefaultSelectedBranch = "";
// DOCUMENT READY
var ma = "";
var tblCcId = "";
var TemplateFor = "CashPayment";
var JobExp = "";

//VARIABLE FOR DOCUMENT UPLOAD
var formname = "Voucher";
var formid;
var VoucherType;
let IsNewVoucher = 0;

$(document).ready(function () {
    if (Get_Cookie("LedgerGroupName") != null) {
        FillPageSizeList('ddlPageSize');
        var RefId = Get_Cookie('LedgerGroupName');
        var firstTwoChars = RefId.slice(0, 2);
        var substring = RefId.slice(3);
        if (firstTwoChars == 'BP')
            EditBankPaymentOrReceipt(substring, firstTwoChars);
        else if (firstTwoChars == 'BR')
            EditBankPaymentOrReceipt(substring, firstTwoChars);
        else if (firstTwoChars == 'JB')
            EditJournalBook(substring, firstTwoChars);
        else if (firstTwoChars == 'CP')
            EditCashPaymentOrCashReceipt(substring, firstTwoChars);
        else if (firstTwoChars == 'CR')
            EditCashPaymentOrCashReceipt(substring, firstTwoChars);
        EraseCookie('LedgerGroupName');
    } else {
        FillPageSizeList('ddlPageSize', CashPaymentList);
        if ($('input:radio[name=type]:checked').val() == "CR")
            FillPageSizeList('ddlPageSize', CashReceiptList);
        else if ($('input:radio[name=type]:checked').val() == "CP")
            FillPageSizeList('ddlPageSize', CashPaymentList);
        else if ($('input:radio[name=type]:checked').val() == "BP")
            FillPageSizeList('ddlPageSize', BankPaymentList);
        else if ($('input:radio[name=type]:checked').val() == "BR")
            FillPageSizeList('ddlPageSize', BankReceiptList);
        else if ($('input:radio[name=type]:checked').val() == "JB")
            FillPageSizeList('ddlPageSize', JournalBookList);
    }
    LoadTinyMCE();
    $(".datepickerAll").datepicker({
        changeMonth: true,
        changeYear: true,
        dateFormat: 'dd/mm/yy'
    });
    $(".datepickerAll1").datepicker({
        changeMonth: true,
        changeYear: true,
        dateFormat: 'dd/mm/yy'
    });
    $(".datepicker").datepicker({
        changeMonth: true,
        changeYear: true,
        dateFormat: 'dd/mm/yy'
    });
    $(".datepickerAll1").datepicker('setDate', 'today');
    LedgerAccHeadautocompleteCashPaymentList();
    LedgerAccHeadautocompleteForSearchLedger();

    var BookType = $('input:radio[name=type1]:checked').val();
    //if (BookType=='CP') {


    // }
    FillBranchList("Branch");
    let vin = setInterval(() => {
        if ($('#Branch').val() != "Select") {
            GenerateVoucherNo();
            clearInterval(vin);
        }
    }, 100)
})

//FUNCTION FOR TINYMCE EDITIOR
function LoadTinyMCE() {
    tinymce.init({
        selector: ".tinymce",
        branding: false,
        theme: "modern",
        skin: "lightgray",
        width: "100%",
        height: 200,
        statubar: true,
        plugins: [
            "advlist autolink link image lists charmap print preview hr anchor pagebreak",
            "searchreplace wordcount visualblocks visualchars code fullscreen insertdatetime media nonbreaking",
            "save table contextmenu directionality emoticons template paste textcolor"
        ],
        toolbar: "insertfile undo redo | styleselect | bold italic | alignleft aligncenter alignright alignjustify | bullist numlist outdent indent | link | fontsizeselect | fontselect | image | print preview media fullpage | forecolor backcolor emoticons ",
        style_formats: [
            {
                title: "Headers", items: [
                    { title: "Header 1", format: "h1" },
                    { title: "Header 2", format: "h2" },
                    { title: "Header 3", format: "h3" },
                    { title: "Header 4", format: "h4" },
                    { title: "Header 5", format: "h5" },
                    { title: "Header 6", format: "h6" }
                ]
            },
            {
                title: "Inline", items: [
                    { title: "Bold", icon: "bold", format: "bold" },
                    { title: "Italic", icon: "italic", format: "italic" },
                    { title: "Underline", icon: "underline", format: "underline" },
                    { title: "Strikethrough", icon: "strikethrough", format: "strikethrough" },
                    { title: "Superscript", icon: "superscript", format: "superscript" },
                    { title: "Subscript", icon: "subscript", format: "subscript" },
                    { title: "Code", icon: "code", format: "code" }
                ]
            },
            {
                title: "Blocks", items: [
                    { title: "Paragraph", format: "p" },
                    { title: "Blockquote", format: "blockquote" },
                    { title: "Div", format: "div" },
                    { title: "Pre", format: "pre" }
                ]
            },
            {
                title: "Alignment", items: [
                    { title: "Left", icon: "alignleft", format: "alignleft" },
                    { title: "Center", icon: "aligncenter", format: "aligncenter" },
                    { title: "Right", icon: "alignright", format: "alignright" },
                    { title: "Justify", icon: "alignjustify", format: "alignjustify" }
                ]
            }
        ],
    });
}
$("#Branch").select2({
    width: '100%'
});

$("#ApprovedSearch").select2({
    width: '100%'
});

$(document).on("click", ".pagination .page", function () {
    if ($('input:radio[name=type]:checked').val() == "CR") {
        CashReceiptList(($(this).attr('page')));
    }
    else if ($('input:radio[name=type]:checked').val() == "CP") {
        CashPaymentList(($(this).attr('page')));
    }
    else if ($('input:radio[name=type]:checked').val() == "BP") {
        BankPaymentList(($(this).attr('page')));
    }
    else if ($('input:radio[name=type]:checked').val() == "BR") {
        BankReceiptList(($(this).attr('page')));
    }
    else if ($('input:radio[name=type]:checked').val() == "JB") {
        JournalBookList(($(this).attr('page')));
    }
});

//PAGE SIZE CLICKED
$("#ddlPageSize").change(function () {
    if ($('input:radio[name=type]:checked').val() == "CR")
        CashReceiptList(1);
    else if ($('input:radio[name=type]:checked').val() == "CP")
        CashPaymentList(1);
    else if ($('input:radio[name=type]:checked').val() == "BP")
        BankPaymentList(1);
    else if ($('input:radio[name=type]:checked').val() == "BR")
        BankReceiptList(1);
    else if ($('input:radio[name=type]:checked').val() == "JB")
        JournalBookList(1);


});

//SEARCH BUTTON CLICKED
$("#BtnSearch").click(function () {
    if ($('input:radio[name=type]:checked').val() == "CR")
        CashReceiptList(1);
    else if ($('input:radio[name=type]:checked').val() == "CP")
        CashPaymentList(1);
    else if ($('input:radio[name=type]:checked').val() == "BP")
        BankPaymentList(1);
    else if ($('input:radio[name=type]:checked').val() == "BR")
        BankReceiptList(1);
    else if ($('input:radio[name=type]:checked').val() == "JB")
        JournalBookList(1);
});

$("#VoucherCancel").click(function () {
    $('#VoucherMessage, #VoucherCancel, #VoucherMail, #VoucherPDF, #VoucherDuplicate, #VoucherDelete').hide();
    location.reload(true);

});

// ADD MORE VOUCHER ENTRY DROPDOWN GRID 
$("#AddMoreVoucher").click(function () {
    var checkval1 = $('input:radio[name=type1]:checked').val();
    $("#RemoveVoucherPayment").removeAttr('disabled');
    var tbody = $("#VoucherEntry_Table").find("tbody");
    var FirstTr = $(tbody).find("tr:first");
    FirstTr.find('.ReceivingDate').datepicker("destroy");
    FirstTr.find('.ReceivingDate').removeAttr("id");
    var NewRow = $(FirstTr).clone();

    NewRow.find('.AccDescription, .HiddenLedgerId, .HiddenGroupId, .GroupName, .AddLedger, .CurBalance, .Particular, .BillNo').val('');
    if (checkval1 === "ACP" || checkval1 === "ABP" || checkval1 === "AJB") {
        NewRow.find('.Txn').val('Dr');
    } else if (checkval1 === "ACR" || checkval1 === "ABR") {
        NewRow.find('.Txn').val('Cr');
    }
    NewRow.find('.Amount').val('0.00');
    NewRow.find('.RemoveVoucherPayment, .ReceivingDate, .ReceivingNo, .Container, .JobNo').val('');

    $("#VoucherEntry_Table").find("tbody").append(NewRow);
    var LastTr = $(tbody).find("tr:last");
    // LastTr.find('.AccDescription').focus();
    LastTr.find('.GroupName').focus();
    LedgerAccHeadautocompleteCashPaymentList();
    $(".ReceivingDate").datepicker({
        changeMonth: true,
        changeYear: true,
        dateFormat: 'dd/mm/yy'
    });
    /*  $(".ReceivingDate").datepicker('setDate', 'today');*/
});

// DELETE VOUCHER ENTRY DROPDOWN GRID ROW
function VoucherEntryDeleteRow(obj) {
    var rowCount = $("#VoucherEntry_Table tbody tr").length;
    if (rowCount > 1) {
        $(obj).parent().parent().remove();
    }
    else {
        $(obj).attr("disabled", "disabled");
    }
}

// PAYMENT MODE BUTTON ON CHANGE FUNCTION 
function ActionRadioChecked() {

    if ($('input:radio[name=type1]:checked').val() == "ACR") {
        Resetdata();
        VoucherType = "CR";
        $("#ApproveVoucher").prop('checked', false);
        $(".JobNo").attr("disabled");
        $(".paymentMethod").html('Cash Receipt');
        $('#voucherentrycolor').css("background-color", "#d28ecb");
        $('.CashPaymentSave').attr('id', 'CashReceiptSave');
        $(".Branch, .VoucherNo, .VoucherDate, .AccHead").show();
        $(".ChequeNo,.ChequeDate").hide();
        $(".Txn").val('Cr');
        $("#ACR").attr("checked", "checked");
        $(".datepickerAll1").datepicker('setDate', 'today');
        FillBranchList('Branch');
        if (IsNewVoucher == 0) {
            let vin = setInterval(() => {
                if ($('#Branch').val() != "Select") {
                    GenerateVoucherNo();
                    clearInterval(vin);
                }
            }, 100)
        }
        //GetListBranchName();
        /* BindAccHead();*/
    }
    else if ($('input:radio[name=type1]:checked').val() == "ABP") {
        Resetdata();
        VoucherType = "BP";
        $("#ApproveVoucher").prop('checked', false);
        $(".JobNo").attr("disabled");
        $(".paymentMethod").html('Bank Payment');
        $('#voucherentrycolor').css("background-color", "#84b2c7");
        $('.CashPaymentSave').attr('id', 'BankPaymentSave');
        $(".Branch, .VoucherNo, .VoucherDate, .AccHead, .ChequeNo, .ChequeDate").show();
        $(".Txn").val('Dr');
        $("#ABP").attr("checked", "checked");
        $(".datepickerAll1").datepicker('setDate', 'today');
        FillBranchList('Branch');
        if (IsNewVoucher == 0) {
            let vin = setInterval(() => {
                if ($('#Branch').val() != "Select") {
                    GenerateVoucherNo();
                    clearInterval(vin);
                }
            }, 100)
        }
        //GetListBranchName();
        /*BindAccHead();*/
    }
    else if ($('input:radio[name=type1]:checked').val() == "ABR") {
        Resetdata();
        VoucherType = "BR";
        $("#ApproveVoucher").prop('checked', false);
        $(".JobNo").attr("disabled");
        $(".paymentMethod").html('Bank Receipt');
        $('#voucherentrycolor').css("background-color", "#89c8da");
        $('.CashPaymentSave').attr('id', 'BankReceiptSave');
        $(".Branch, .VoucherNo, .VoucherDate, .AccHead, .ChequeNo, .ChequeDate").show();
        $("#ABR").attr("checked", "checked");
        $(".Txn").val('Cr');
        $(".datepickerAll1").datepicker('setDate', 'today');
        FillBranchList('Branch');
        if (IsNewVoucher == 0) {
            let vin = setInterval(() => {
                if ($('#Branch').val() != "Select") {
                    GenerateVoucherNo();
                    clearInterval(vin);
                }
            }, 100)
        }
        //GetListBranchName();
        /* BindAccHead();*/
    }
    else if ($('input:radio[name=type1]:checked').val() == "AJB") {
        Resetdata();
        VoucherType = "JB";
        $("#ApproveVoucher").prop('checked', false);
        $(".paymentMethod").html('Journal Book');
        $(".JobNo").removeAttr("disabled");
        $('#voucherentrycolor').css("background-color", "#efa46a");
        $('.CashPaymentSave').attr('id', 'JournalBookSave');
        $(".Branch, .VoucherNo, .VoucherDate").show();
        $(".AccHead, #AccHead, .ChequeNo, .ChequeDate").hide();

        $("#AJB").attr("checked", "checked");
        $(".Txn").val('Dr');
        $(".datepickerAll1").datepicker('setDate', 'today');
        FillBranchList('Branch');
        if (IsNewVoucher == 0) {
            let vin = setInterval(() => {
                if ($('#Branch').val() != "Select") {
                    GenerateVoucherNo();
                    clearInterval(vin);
                }
            }, 100)
        }
        //GetListBranchName();
    }
    else if ($('input:radio[name=type1]:checked').val() == "ACP") {
        Resetdata();
        VoucherType = "CP";
        $("#ApproveVoucher").prop('checked', false);
        $(".JobNo").attr("disabled");
        $(".paymentMethod").html('Cash Payment');
        $('#voucherentrycolor').css("background-color", "#89a9f4");
        $('.CashPaymentSave').attr('id', 'CashPaymentSave');
        $(".Branch, .VoucherNo, .VoucherDate, .AccHead").show();
        $(".ChequeNo, .ChequeDate").hide();
        $(".Txn").val('Dr');
        $("#ACP").attr("checked", "checked");
        $(".datepickerAll1").datepicker('setDate', 'today');
        FillBranchList('Branch');
        if (IsNewVoucher == 0) {
            let vin = setInterval(() => {
                if ($('#Branch').val() != "Select") {
                    GenerateVoucherNo();
                    clearInterval(vin);
                }
            }, 100)
        }
        // GetListBranchName();
        /* BindAccHead();*/
    }
    /*   BindAccHead();*/
};

function ActionRadioCheckedOnList(e) {
    $("#sort-column").val('VoucherNo');
    if (e == "CR") {
        TemplateFor = 'CashReceipt';
        $('#ApproveVoucherValueFill').html('CashReceipt');
        $("#CashReceipt").attr("checked", "checked");
        $("#ACR").attr("checked", "checked");
        $(".CR").css("background-color", "hsl(212deg 62% 49%)");
        $(".CP, .BP, .BR, .JB").css("background-color", "#4299e1");
        $("#tbl_CashPayment").hide();
        $("#tbl_CashReceipt").show();
        $("#tbl_BankPayment, #tbl_BankReceipt, #tbl_JournalBook").hide();
        CashReceiptList(1);
    }
    else if (e == "BP") {
        TemplateFor = 'BankPayment';
        $('#ApproveVoucherValueFill').html('BankPayment');
        $("#BankPayment").attr("checked", "checked");
        $(".BP").css("background-color", "hsl(212deg 62% 49%)");
        $(".CP, .CR, .BR, .JB").css("background-color", "#4299e1");
        $("#tbl_CashPayment, #tbl_CashReceipt, #tbl_BankReceipt, #tbl_JournalBook").hide();
        $("#tbl_BankPayment").show();

        BankPaymentList(1);
    }
    else if (e == "BR") {
        TemplateFor = 'BankReceipt';
        $('#ApproveVoucherValueFill').html('BankReceipt');
        $("#BankReceipt").attr("checked", "checked");
        $("#ABR").attr("checked", "checked");
        $(".BR").css("background-color", "hsl(212deg 62% 49%)");
        $(".CP, .CR, .BP, .JB").css("background-color", "#4299e1");
        $("#tbl_CashPayment, #tbl_CashReceipt, #tbl_BankPayment, #tbl_JournalBook").hide();
        $("#tbl_BankReceipt").show();
        BankReceiptList(1);
    }
    else if (e == "JB") {
        TemplateFor = 'JournalBook';
        $('#ApproveVoucherValueFill').html('JournalBook');
        $("#JournalBook").attr("checked", "checked");
        $("#AJB").attr("checked", "checked");
        $(".JB").css("background-color", "hsl(212deg 62% 49%)");
        $(".CP, .CR, .BR, .BP").css("background-color", "#4299e1");
        $("#tbl_CashPayment, #tbl_CashReceipt, #tbl_BankPayment, #tbl_BankReceipt").hide();
        $("#tbl_JournalBook").show();
        JournalBookList(1);
    }
    else if (e == "CP") {
        TemplateFor = 'CashPayment';
        $('#ApproveVoucherValueFill').html('CashPayment');
        $("#CashPayment").attr("checked", "checked");
        $("#ACP").attr("checked", "checked");
        $(".CP").css("background-color", "hsl(212deg 62% 49%)");
        $(".JB, .CR, .BR, .BP").css("background-color", "#4299e1");
        $("#tbl_CashPayment").show();
        $("#tbl_CashReceipt, #tbl_BankPayment, #tbl_BankReceipt, #tbl_JournalBook").hide();
        CashPaymentList(1);
    }
};


//===========================FUNCTION FOR BINDING ALL DROPDOWN LIST FOR VOUCHER ENTRY ===================================//
//AUTO COMPLETE DROPDOWN FOR SEARCH LEDGER NAME 
function LedgerAccHeadautocompleteForSearchLedger() {
    $("#AccHeadSearch").autocomplete({
        source: function (request, response) {
            $.ajax({
                type: 'POST',
                url: "/Master/VoucherEntry/SearchAccHeadNameList",
                dataType: "json",
                async: false,
                data: {
                    AccDescription: request.term
                },
                success: function (result) {
                    response($.map(result.data.Table, function (LedgerName) {
                        return {
                            label: LedgerName.AccHead,
                            value: LedgerName.AccHead,
                            id: LedgerName.LedgerUid,
                        }
                    }));
                },
                error: function (response) {
                    console.log(response.responseText);
                }
            });
        },
        minLength: 1,
        autoFocus: true,
        selectFirst: true,
        selectOnly: true,
        focus: function (event, ui) { }
    }).focus(function () {
        $(this).autocomplete("search");
    });
}
// AUTO COMPLETE DROPDOWN FOR LEDGER ACC HEAD NAME
function LedgerAccHeadautocompleteCashPaymentList(e) {
    var parentTr = $(e).parents('tr');
    var GroupId = parentTr.find(".HiddenGroupId").val();
    $(".AccDescription").autocomplete({
        source: function (request, response) {
            $.ajax({
                type: 'POST',
                url: "/Master/VoucherEntry/GetAccHeadName",
                dataType: "json",
                async: false,
                data: { AccDescription: request.term, GroupId: GroupId },
                success: function (result) {
                    response($.map(result.data.Table, function (LedgerName) {
                        return {
                            label: LedgerName.AccHead,
                            value: LedgerName.AccHead,
                            id: LedgerName.LedgerUid,
                            OpeningBalance: LedgerName.OpeningBalance,
                            JobExpence: LedgerName.JobExpense,
                            SubgroupHeadName: LedgerName.SubgroupHeadName
                        }
                    }));
                },
                error: function (response) {
                    console.log(response.responseText);
                }
            });
        },
        minLength: 1,
        // autoFocus: true,
        selectFirst: true,
        //    selectOnly: true,
        select: function (e, i) {
            $(this).on("mouseenter", function () {
                $(this).attr('title', i.item.value);
            });
            var parentTr = $(this).parents('tr');
            parentTr.find(".GrpDescription").val(i.item.SubgroupHeadName);
            var checkval = $('input:radio[name=type1]:checked').val();
            var jobexpence = i.item.JobExpence;
            JobExp = i.item.JobExpence;
            var OpeningBalance = i.item.OpeningBalance;
            if (jobexpence == true) {
                parentTr.find(".JobNo").removeAttr("disabled");
                parentTr.find(".JobNo").removeAttr("tabindex");
            }
            else {
                parentTr.find(".JobNo").prop('disabled', true);
                parentTr.find(".JobNo").attr("tabindex");
                parentTr.find(".JobNo").val('');
            }
            if (checkval == "ACP") {
                parentTr.find(".HiddenLedgerId ").val(i.item.id);
                if (jobexpence == true) {
                    parentTr.find(".JobExpence ").val(1);
                }
                else {
                    parentTr.find(".JobExpence ").val(0);
                }
            }
            else if (checkval == "ACR") {
                parentTr.find(".HiddenLedgerId ").val(i.item.id);
                if (jobexpence == true)
                    parentTr.find(".JobExpence ").val(1);
                else
                    parentTr.find(".JobExpence ").val(0);
            }
            else if (checkval == "ABP") {
                parentTr.find(".HiddenLedgerId ").val(i.item.id);
                if (jobexpence == true)
                    parentTr.find(".JobExpence ").val(1);
                else
                    parentTr.find(".JobExpence ").val(0);
            }
            else if (checkval == "ABR") {
                parentTr.find(".HiddenLedgerId ").val(i.item.id);
                if (jobexpence == true)
                    parentTr.find(".JobExpence ").val(1);
                else
                    parentTr.find(".JobExpence ").val(0);
            }
            else if (checkval == "AJB") {
                parentTr.find(".HiddenLedgerId ").val(i.item.id);
                if (jobexpence == true)
                    parentTr.find(".JobExpence ").val(1);
                else
                    parentTr.find(".JobExpence ").val(0);
            }
        },
        change: function (e, i) {
            //var parentTr = $(this).parents('tr');
            //var AccHead = i.item.label;
            //var AccHead1 = $(this).val();
            //if (AccHead != AccHead1) {
            //    parentTr.find(".HiddenLedgerId").val('');
            //    parentTr.find(".AccDescription").val('');
            //}
            /*if (i.item == null || i.item == undefined) {*/
            var parentTr = $(this).parents('tr');
            parentTr.find(".JobNo").val('');
            var jobexpence = i.item.JobExpence;
            if (jobexpence == true) {
                parentTr.find(".JobNo").removeAttr("disabled");
                parentTr.find(".JobNo").removeAttr("tabindex");
            }
            else {
                parentTr.find(".JobNo").attr("disabled");
                parentTr.find(".JobNo").attr("tabindex");
                parentTr.find(".JobNo").val('');
            }
            /* parentTr.find(".HiddenLedgerId").val('');*/
            //$(this).val("");
            //}
        },
        /*  focus: function (event, ui) { }*/
    });
}

// AUTO COMPLETE DROPDOWN FOR JOB NO 
function AutoCompltedropdownforJobNo(e) {
    var parentTr = $(e).parents('tr');
    var importerid = parentTr.find(".HiddenLedgerId").val();
    $(".JobNo").autocomplete({
        source: function (request, response) {
            $.ajax({
                type: 'POST',
                url: "/Master/VoucherEntry/GetJobNo",
                dataType: "json",
                async: false,
                data: { JobNo: request.term, importerid: importerid },
                success: function (result) {
                    response($.map(result.data.Table, function (ImportJobHeader) {
                        return {
                            label: ImportJobHeader.JobNo,
                            value: ImportJobHeader.JobNo,
                            id: ImportJobHeader.ImporterId,
                            ContainerType: ImportJobHeader.ContainerType,
                            ContainerTypeNo: ImportJobHeader.ContainerTypeNo,
                            jobUid: ImportJobHeader.jobUid
                        }
                    }));
                },
                error: function (response) {
                    console.log(response.responseText);
                }
            });
        },
        minLength: 1,
        autoFocus: true,
        selectFirst: true,
        selectOnly: true,
        select: function (e, i) {
            var parentTr = $(this).parents('tr');
            parentTr.find(".Container ").val(HandleNullTextValue(i.item.ContainerType));
            parentTr.find(".HiddenJobNo ").val(HandleNullTextValue(i.item.jobUid));
        },
        focus: function (event, ui) { }
    }).focus(function () {
        $(this).autocomplete("search");
    });

}

$("#AccHead").autocomplete({
    source: function (request, response) {
        $.ajax({
            type: 'POST',
            url: "/Master/VoucherEntry/GetAccHeadNameList",
            dataType: "json",
            async: false,
            data: { JobNo: request.term, checkval: $('input:radio[name=type1]:checked').val(), AccDescription: $("#AccHead").val() },
            success: function (result) {
                response($.map(result.data.Table, function (LedgerName) {
                    return {
                        label: LedgerName.AccHead,
                        value: LedgerName.AccHead,
                        id: LedgerName.LedgerUid,
                    }
                }));
            },
            error: function (response) {
                console.log(response.responseText);
            }
        });
    },
    minLength: 1,
    autoFocus: true,
    selectFirst: true,
    selectOnly: true,
    select: function (e, i) {
        var parentTr = $(this).parents('tr');
        $("#HiddenAccHeadId").val(i.item.id);
    },
    focus: function (event, ui) { }
});

$('#AccHead').on('input', function () {
    $("#HiddenAccHeadId").val('');
});

//=================================  CODE FOR BIND LIST VIEW OR TABLE VIEW  ========================================================
//#region
// BIND  CASH PAYMENT TABLE
function BindCashPaymentListTable(result, serial_no) {

    $("#tbl_CashPayment tbody tr").remove();
    if (result.length == 0) {
        tr = $('<tr/>');
        tr.append("<td class='text-center' colspan='12'>NO RESULTS FOUND</td>");
        $("#tbl_CashPayment tbody").append(tr);
    }
    else {
        let Count = 0;
        for (i = 0; i < result.length; i++) {
            if (!result[i].ApproveVoucher)
                tr = $(' <tr style="background-color:#fdd2d2;"/>');
            else
                tr = $('<tr/>');
            tr.append("<td class='text-center'><button type='button' onclick='EditCashPaymentOrCashReceipt(\"" + result[i].CashPaymentUid + "\",\"" + 'CP' + "\");' class= 'common-btn common-btn-sm'><i class='fa-solid fa-pen-to-square'></i></button ><button type='button' onclick='DeleteCashPaymentOrCashReceipt(\"" + result[i].CashPaymentUid + "\",\"" + 'CP' + "\");' class= 'common-btn common-btn-sm'> <i class='fa-regular fa-trash-can'></i></button ></td > ");

            if (result[i].ApproveVoucher) {
                Count = Count + 1;
                tr.append("<td class='text-center'> <input type='checkbox' disabled='disabled' data-ledger_id='" + result[i].CashPaymentUid + "' class=' mt-2 form-check-input' checked/></td>");
            }
            else {
                tr.append("<td class='text-center'> <input type='checkbox' data-ledger_id='" + result[i].CashPaymentUid + "' class=' mt-2 form-check-input' /></td>");
            }
            tr.append("<td class='text-center'>" + serial_no + "</td>");
            tr.append("<td class='text-center'>" + result[i].CashPaymentUid + "</td>");
            tr.append("<td  class='text-center'>" + result[i].BranchName + "</td>");
            tr.append("<td  class='text-center'><a href='javascript:void(0)' class='text-decoration-none' style='color: black !important;'onclick='EditCashPaymentOrCashReceipt(\"" + result[i].CashPaymentUid + "\",\"" + 'CP' + "\");'>" + result[i].AccHeadName + "</a></td>");
            tr.append("<td  class='text-center'>" + HandleNullTextValue(result[i].AccDesc) + "</td>");
            tr.append("<td  class='text-center'>" + HandleNullTextValue(result[i].VoucherNumber) + "</td>");
            tr.append("<td  class='text-center'>" + result[i].VoucherDt
                + "</td>");
            tr.append("<td  class='text-center'>" + result[i].JobNo
                + "</td>");
            tr.append("<td  class='text-end'>" + result[i].TAmount + "</a></td>");
            tr.append("<td  class='text-end'>" + HandleNullTextValue(result[i].AdjustedAmount) + "</a></td>");
            tr.append("<td  class='text-center'>" + result[i].created_by + "</td>");
            serial_no++;
            $("#tbl_CashPayment tbody").append(tr);
        }
        if (Count == result.length) {
            $("#ApproveAllCP").prop('checked', true);
        }
    }
}

//  CASH PAYMENT  LIST PAGE INDEX
function CashPaymentList(pageindex) {
    try {
        const dataString = {};
        dataString.PageSize = $("#ddlPageSize").val();
        dataString.PageIndex = pageindex;
        dataString.AccHead = $("#AccHeadSearch").val();
        dataString.TotalAmount = $("#TotalAmountSearch").val();
        dataString.VoucherDateFrom = $("#FromDateSearch").val();
        dataString.VoucherDateTo = $("#ToDateSearch").val();
        dataString.AmountFrom = $("#TotalAmountSearchFrom").val();
        dataString.AmountTo = $("#TotalAmountSearchTo").val();
        dataString.JobNoSearch = $("#JobNoSearch").val();
        dataString.ApprovedSearch = $("#ApprovedSearch").val();
        dataString.OrderBy = $("#sort-column").val().trim() + " " + $("#sort-type").val().trim();
        AjaxSubmission(JSON.stringify(dataString), "/Master/VoucherEntry/CashPaymentList ", $('input[name=__RequestVerificationToken]').val()).done(function (result) {
            let obj = result;
            if (obj.status == true) {
                if (obj.responsecode == '100') {
                    var ser = ((parseInt(obj.data.Table1[0].PageIndex) - 1) * parseInt(obj.data.Table1[0].PageSize)) + 1;
                    $('#CashPayment').prop('Checked', true);
                    $('#tbl_BankPayment').hide();
                    $('#tbl_BankReceipt').hide();
                    $('#tbl_JournalBook').hide();
                    $('#tbl_CashPayment').show();
                    $('#tbl_CashReceipt').hide();
                    $(".CP").css("background-color", "hsl(212deg 62% 49%)");
                    $(".JB").css("background-color", "#4299e1");
                    $(".CR").css("background-color", "#4299e1");
                    $(".BR").css("background-color", "#4299e1");
                    $(".JB").css("background-color", "#4299e1");
                    BindCashPaymentListTable(obj.data.Table, ser);
                    if (obj.data.Table1 != undefined && obj.data.Table1.length > 0) {
                        $(".pagination").BindPaging({
                            ActiveCssClass: "current",
                            PagerCssClass: "pager",
                            PageIndex: parseInt(obj.data.Table1[0].PageIndex),
                            PageSize: parseInt(obj.data.Table1[0].PageSize),
                            RecordCount: parseInt(obj.data.Table1[0].count)
                        });
                    }
                }
                else {
                    Toast(RetrieveMessage(obj.responsecode), "Message", "error");
                }
            }
            else {
                window.location.href = '/ClientLogin/ClientLogin';
            }
            //Hideloader();
        }).fail(function (result) {
            console.log(result.Message);
            //Hideloader();
        });
    }
    catch (e) {
        console.log(e.message);
        //Hideloader();
    }
}

// BIND  CASH RECEIPT TABLE
function BindCashReceiptListTable(result, serial_no) {

    $("#tbl_CashReceipt tbody tr").remove();
    if (result.length == 0) {
        tr = $('<tr/>');
        tr.append("<td class='text-center' colspan='12'>NO RESULTS FOUND</td>");
        $("#tbl_CashReceipt tbody").append(tr);
    }
    else {
        let Count = 0;
        for (i = 0; i < result.length; i++) {
            if (!result[i].ApproveVoucher)
                tr = $(' <tr style="background-color:#fdd2d2;"/>');
            else
                tr = $('<tr/>');
            tr.append("<td class='text-center'><button type='button' onclick='EditCashPaymentOrCashReceipt(\"" + result[i].CashReceiptUid + "\",\"" + 'CR' + "\");' class= 'common-btn common-btn-sm'><i class='fa-solid fa-pen-to-square'></i></button ><button type='button' onclick='DeleteCashPaymentOrCashReceipt(\"" + result[i].CashReceiptUid + "\",\"" + 'CR' + "\");' class= 'common-btn common-btn-sm'> <i class='fa-regular fa-trash-can'></i></button ></td > ");

            if (result[i].ApproveVoucher) {
                Count = Count + 1;
                tr.append("<td class='text-center'> <input type='checkbox' disabled='disabled' data-ledger_id='" + result[i].CashReceiptUid + "' class=' mt-2 form-check-input' checked/></td>");
            }
            else {
                tr.append("<td class='text-center'> <input type='checkbox' data-ledger_id='" + result[i].CashReceiptUid + "' class=' mt-2 form-check-input' /></td>");
            }
            tr.append("<td class='text-center'>" + serial_no + "</td>");
            tr.append("<td class='text-center'>" + result[i].CashReceiptUid + "</td>");
            tr.append("<td  class='text-center'>" + result[i].BranchName + "</td>");
            tr.append("<td  class='text-center'><a href='javascript:void(0)' class='text-decoration-none' style='color: black !important;' onclick='EditCashPaymentOrCashReceipt(\"" + result[i].CashReceiptUid + "\",\"" + 'CR' + "\");'>" + result[i].AccHeadName + "</a></td>");
            tr.append("<td  class='text-center'>" + HandleNullTextValue(result[i].AccDesc) + "</td>");
            tr.append("<td  class='text-center'>" + HandleNullTextValue(result[i].VoucherNumber) + "</td>");
            tr.append("<td  class='text-center'>" + result[i].VoucherDt
                + "</td>");

            tr.append("<td  class='text-center'>" + result[i].JobNo
                + "</td>");

            tr.append("<td  class='text-end'>" + result[i].TAmount + "</td>");
            tr.append("<td  class='text-end'>" + HandleNullTextValue(result[i].AdjustedAmount) + "</a></td>");
            tr.append("<td  class='text-center'>" + result[i].created_by + "</td>");

            serial_no++;
            $("#tbl_CashReceipt tbody").append(tr);
        }
        if (Count == result.length) {
            $("#ApproveAllCR").prop('checked', true);
        }
    }
}

//  CASH RECEIPT  LIST PAGE INDEX
function CashReceiptList(pageindex) {
    try {
        const dataString = {};
        dataString.PageSize = $("#ddlPageSize").val();
        dataString.PageIndex = pageindex;
        dataString.AccHead = $("#AccHeadSearch").val();
        dataString.TotalAmount = $("#TotalAmountSearch").val();
        dataString.VoucherDateFrom = $("#FromDateSearch").val();
        dataString.VoucherDateTo = $("#ToDateSearch").val();
        dataString.AmountFrom = $("#TotalAmountSearchFrom").val();
        dataString.AmountTo = $("#TotalAmountSearchTo").val();
        dataString.JobNoSearch = $("#JobNoSearch").val();
        dataString.ApprovedSearch = $("#ApprovedSearch").val();

        dataString.OrderBy = $("#sort-column").val().trim() + " " + $("#sort-type").val().trim();
        AjaxSubmission(JSON.stringify(dataString), "/Master/VoucherEntry/CashReceiptList ", $('input[name=__RequestVerificationToken]').val()).done(function (result) {
            let obj = result;
            if (obj.status == true) {
                if (obj.responsecode == '100') {
                    var ser = ((parseInt(obj.data.Table1[0].PageIndex) - 1) * parseInt(obj.data.Table1[0].PageSize)) + 1;
                    $('#CashReceipt').prop('Checked', true);
                    $('#ACR').prop('Checked', true);
                    $('#tbl_BankPayment').hide();
                    $('#tbl_BankReceipt').hide();
                    $('#tbl_JournalBook').hide();
                    $('#tbl_CashPayment').hide();
                    $('#tbl_CashReceipt').show();
                    $(".CR").css("background-color", "hsl(212deg 62% 49%)");
                    $(".CP").css("background-color", "#4299e1");
                    $(".BP").css("background-color", "#4299e1");
                    $(".BR").css("background-color", "#4299e1");
                    $(".JB").css("background-color", "#4299e1");
                    BindCashReceiptListTable(obj.data.Table, ser);
                    if (obj.data.Table1 != undefined && obj.data.Table1.length > 0) {
                        $(".pagination").BindPaging({
                            ActiveCssClass: "current",
                            PagerCssClass: "pager",
                            PageIndex: parseInt(obj.data.Table1[0].PageIndex),
                            PageSize: parseInt(obj.data.Table1[0].PageSize),
                            RecordCount: parseInt(obj.data.Table1[0].count)
                        });
                    }
                }
                else {
                    Toast(RetrieveMessage(obj.responsecode), "Message", "error");
                }
            }
            else {
                window.location.href = '/ClientLogin/ClientLogin';
            }
            //Hideloader();
        }).fail(function (result) {
            console.log(result.Message);
            //Hideloader();
        });
    }
    catch (e) {
        console.log(e.message);
        //Hideloader();
    }
}

// BIND BANK PAYMENT TABLE
function BindBankPaymentListTable(result, serial_no) {
    $("#tbl_BankPayment tbody tr").remove();
    if (result.length == 0) {
        tr = $('<tr/>');
        tr.append("<td class='text-center' colspan='12'>NO RESULTS FOUND</td>");
        $("#tbl_BankPayment tbody").append(tr);
    }
    else {
        let Count = 0;
        for (i = 0; i < result.length; i++) {
            if (!result[i].ApproveVoucher)
                tr = $(' <tr style="background-color:#fdd2d2;"/>');
            else
                tr = $('<tr/>');
            tr.append("<td class='text-center'><button type='button' onclick='EditBankPaymentOrReceipt(\"" + result[i].BankPaymentUid + "\",\"" + 'BP' + "\");' class= 'common-btn common-btn-sm'><i class='fa-solid fa-pen-to-square'></i></button ><button type='button' onclick='DeleteBankPaymentOrReceipt(\"" + result[i].BankPaymentUid + "\",\"" + 'BP' + "\");' class= 'common-btn common-btn-sm'> <i class='fa-regular fa-trash-can'></i></button ></td > ");

            if (result[i].ApproveVoucher) {
                Count = Count + 1;
                tr.append("<td class='text-center'> <input type='checkbox' disabled='disabled' data-ledger_id='" + result[i].BankPaymentUid + "' class=' mt-2 form-check-input' checked/></td>");
            }
            else {
                tr.append("<td class='text-center'> <input type='checkbox' data-ledger_id='" + result[i].BankPaymentUid + "' class=' mt-2 form-check-input' /></td>");
            }


            tr.append("<td class='text-center'>" + serial_no + "</td>");
            tr.append("<td class='text-center'>" + result[i].BankPaymentUid + "</td>");
            tr.append("<td  class='text-center'>" + result[i].BranchName + "</td>");
            tr.append("<td  class='text-center'><a href='javascript:void(0)' class='text-decoration-none' style='color: black !important;'onclick='EditBankPaymentOrReceipt(\"" + result[i].BankPaymentUid + "\",\"" + 'BP' + "\");'>" + result[i].AccHeadName + "</a></td>");
            tr.append("<td  class='text-center'>" + HandleNullTextValue(result[i].AccDesc) + "</td>");
            tr.append("<td  class='text-center'>" + HandleNullTextValue(result[i].VoucherNumber) + "</td>");
            tr.append("<td  class='text-center'>" + result[i].VoucherDt + "</td>");

            tr.append("<td  class='text-center'>" + result[i].JobNo
                + "</td>");

            tr.append("<td  class='text-end '>" + result[i].TAmount + "</td>");
            tr.append("<td  class='text-end'>" + HandleNullTextValue(result[i].AdjustedAmount) + "</a></td>");
            tr.append("<td  class='text-center'>" + HandleNullTextValue(result[i].ChequeNumber) + "</td>");

            tr.append("<td  class='text-center'>" + HandleNullTextValue(result[i].ChequeDt) + "</td>");

            tr.append("<td  class='text-center'>" + result[i].created_by + "</td>");

            serial_no++;
            $("#tbl_BankPayment tbody").append(tr);
        }
        if (Count == result.length) {
            $("#ApproveAllBP").prop('checked', true);
        }
    }
}

//  BANK PAYMENT  LIST PAGE INDEX
function BankPaymentList(pageindex) {
    try {
        const dataString = {};
        dataString.PageSize = $("#ddlPageSize").val();
        dataString.PageIndex = pageindex;
        dataString.AccHead = $("#AccHeadSearch").val();
        dataString.TotalAmount = $("#TotalAmountSearch").val();
        dataString.VoucherDateFrom = $("#FromDateSearch").val();
        dataString.VoucherDateTo = $("#ToDateSearch").val();
        dataString.AmountFrom = $("#TotalAmountSearchFrom").val();
        dataString.AmountTo = $("#TotalAmountSearchTo").val();
        dataString.JobNoSearch = $("#JobNoSearch").val();
        dataString.ApprovedSearch = $("#ApprovedSearch").val();
        dataString.OrderBy = $("#sort-column").val().trim() + " " + $("#sort-type").val().trim();
        AjaxSubmission(JSON.stringify(dataString), "/Master/VoucherEntry/BankPaymentList ", $('input[name=__RequestVerificationToken]').val()).done(function (result) {
            let obj = result;
            if (obj.status == true) {
                if (obj.responsecode == '100') {
                    var ser = ((parseInt(obj.data.Table1[0].PageIndex) - 1) * parseInt(obj.data.Table1[0].PageSize)) + 1;
                    $('#BankPayment').prop('Checked', true);
                    $('#tbl_BankPayment').show();
                    $('#tbl_BankReceipt').hide();
                    $('#tbl_JournalBook').hide();
                    $('#tbl_CashPayment').hide();
                    $('#tbl_CashReceipt').hide();
                    $(".BP").css("background-color", "hsl(212deg 62% 49%)");
                    $(".CP").css("background-color", "#4299e1");
                    $(".CR").css("background-color", "#4299e1");
                    $(".BR").css("background-color", "#4299e1");
                    $(".JB").css("background-color", "#4299e1");
                    BindBankPaymentListTable(obj.data.Table, ser);
                    if (obj.data.Table1 != undefined && obj.data.Table1.length > 0) {
                        $(".pagination").BindPaging({
                            ActiveCssClass: "current",
                            PagerCssClass: "pager",
                            PageIndex: parseInt(obj.data.Table1[0].PageIndex),
                            PageSize: parseInt(obj.data.Table1[0].PageSize),
                            RecordCount: parseInt(obj.data.Table1[0].count)
                        });
                    }
                }
                else {
                    Toast(RetrieveMessage(obj.responsecode), "Message", "error");
                }
            }
            else {
                window.location.href = '/ClientLogin/ClientLogin';
            }
            //Hideloader();
        }).fail(function (result) {
            console.log(result.Message);
            //Hideloader();
        });
    }
    catch (e) {
        console.log(e.message);
        //Hideloader();
    }
}

// BIND BANK RECEIPT TABLE
function BindBankReceiptListTable(result, serial_no) {
    $("#tbl_BankReceipt tbody tr").remove();
    if (result.length == 0) {
        tr = $('<tr/>');
        tr.append("<td class='text-center' colspan='12'>NO RESULTS FOUND</td>");
        $("#tbl_BankReceipt tbody").append(tr);
    }
    else {
        let Count = 0;
        for (i = 0; i < result.length; i++) {
            if (!result[i].ApproveVoucher)
                tr = $(' <tr style="background-color:#fdd2d2;"/>');
            else
                tr = $('<tr/>');
            tr.append("<td class='text-center'><button type='button' onclick='EditBankPaymentOrReceipt(\"" + result[i].BankReceiptUid + "\",\"" + 'BR' + "\");' class= 'common-btn common-btn-sm'><i class='fa-solid fa-pen-to-square'></i></button ><button type='button' onclick='DeleteBankPaymentOrReceipt(\"" + result[i].BankReceiptUid + "\",\"" + 'BR' + "\");' class= 'common-btn common-btn-sm'> <i class='fa-regular fa-trash-can'></i></button ></td > ");
            if (result[i].ApproveVoucher) {
                Count = Count + 1;
                tr.append("<td class='text-center'> <input type='checkbox' disabled='disabled' data-ledger_id='" + result[i].BankReceiptUid + "' class=' mt-2 form-check-input' checked/></td>");
            }
            else {
                tr.append("<td class='text-center'> <input type='checkbox' data-ledger_id='" + result[i].BankReceiptUid + "' class=' mt-2 form-check-input' /></td>");
            }
            tr.append("<td class='text-center'>" + serial_no + "</td>");
            tr.append("<td class='text-center'>" + result[i].BankReceiptUid + "</td>");
            tr.append("<td  class='text-center'>" + result[i].BranchName + "</td>");
            /* tr.append("<td  class='text-center'><a href='javascript:void(0)' class='text-decoration-none' style='color: black !important;onclick='EditBankPaymentOrReceipt(\"" + result[i].BankReceiptUid + "\",\"" + 'BR' + "\");'>" + result[i].AccHeadName + "</a></td>");*/
            tr.append("<td  class='text-center'><a href='javascript:void(0)' class='text-decoration-none' style='color: black !important;'onclick='EditBankPaymentOrReceipt(\"" + result[i].BankReceiptUid + "\",\"" + 'BR' + "\");'>" + result[i].AccHeadName + "</a></td>");
            tr.append("<td  class='text-center'>" + HandleNullTextValue(result[i].AccDesc) + "</td>");
            tr.append("<td  class='text-center'>" + HandleNullTextValue(result[i].VoucherNumber) + "</td>");
            tr.append("<td  class='text-center'>" + result[i].VoucherDt
                + "</td>");

            tr.append("<td  class='text-center'>" + result[i].JobNo
                + "</td>");

            tr.append("<td  class='text-end'>" + result[i].TAmount + "</td>");
            tr.append("<td  class='text-end'>" + HandleNullTextValue(result[i].AdjustedAmount) + "</a></td>");
            tr.append("<td  class='text-center'>" + HandleNullTextValue(result[i].ChequeNumber)
                + "</td>");
            tr.append("<td  class='text-center'>" + HandleNullTextValue(result[i].ChequeDt)
                + "</td>");
            tr.append("<td  class='text-center'>" + result[i].created_by + "</td>");

            serial_no++;
            $("#tbl_BankReceipt tbody").append(tr);
        }
        if (Count == result.length) {
            $("#ApproveAllBR").prop('checked', true);
        }
    }
}

// BANK RECEIPT  LIST PAGE INDEX
function BankReceiptList(pageindex) {
    try {
        const dataString = {};
        dataString.PageSize = $("#ddlPageSize").val();
        dataString.PageIndex = pageindex;
        dataString.AccHead = $("#AccHeadSearch").val();
        dataString.TotalAmount = $("#TotalAmountSearch").val();
        dataString.VoucherDateFrom = $("#FromDateSearch").val();
        dataString.VoucherDateTo = $("#ToDateSearch").val();
        dataString.AmountFrom = $("#TotalAmountSearchFrom").val();
        dataString.AmountTo = $("#TotalAmountSearchTo").val();
        dataString.JobNoSearch = $("#JobNoSearch").val();
        dataString.ApprovedSearch = $("#ApprovedSearch").val();
        dataString.OrderBy = $("#sort-column").val().trim() + " " + $("#sort-type").val().trim();

        AjaxSubmission(JSON.stringify(dataString), "/Master/VoucherEntry/BankReceiptList ", $('input[name=__RequestVerificationToken]').val()).done(function (result) {
            let obj = result;
            if (obj.status == true) {
                if (obj.responsecode == '100') {
                    var ser = ((parseInt(obj.data.Table1[0].PageIndex) - 1) * parseInt(obj.data.Table1[0].PageSize)) + 1;
                    $('#BankReceipt').prop('Checked', true);
                    $('#tbl_BankPayment').hide();
                    $('#tbl_BankReceipt').show();
                    $('#tbl_JournalBook').hide();
                    $('#tbl_CashPayment').hide();
                    $('#tbl_CashReceipt').hide();
                    $(".BR").css("background-color", "hsl(212deg 62% 49%)");
                    $(".CP").css("background-color", "#4299e1");
                    $(".CR").css("background-color", "#4299e1");
                    $(".BP").css("background-color", "#4299e1");
                    $(".JB").css("background-color", "#4299e1");
                    BindBankReceiptListTable(obj.data.Table, ser);
                    if (obj.data.Table1 != undefined && obj.data.Table1.length > 0) {
                        $(".pagination").BindPaging({
                            ActiveCssClass: "current",
                            PagerCssClass: "pager",
                            PageIndex: parseInt(obj.data.Table1[0].PageIndex),
                            PageSize: parseInt(obj.data.Table1[0].PageSize),
                            RecordCount: parseInt(obj.data.Table1[0].count)
                        });
                    }
                }
                else {
                    Toast(RetrieveMessage(obj.responsecode), "Message", "error");
                }
            }
            else {
                window.location.href = '/ClientLogin/ClientLogin';
            }
            //Hideloader();
        }).fail(function (result) {
            console.log(result.Message);
            //Hideloader();
        });
    }
    catch (e) {
        console.log(e.message);
        //Hideloader();
    }
}

// BIND  JOURNAL BOOK TABLE
function BindJournalBookListTable(result, serial_no) {
    $("#tbl_JournalBook tbody tr").remove();
    if (result.length == 0) {
        tr = $('<tr/>');
        tr.append("<td class='text-center' colspan='12'>NO RESULTS FOUND</td>");
        $("#tbl_JournalBook tbody").append(tr);
    }
    else {
        let Count = 0;
        for (i = 0; i < result.length; i++) {
            if (!result[i].ApproveVoucher)
                tr = $(' <tr style="background-color:#fdd2d2;"/>');
            else
                tr = $('<tr/>');
            tr.append("<td class='text-center'><button type='button' onclick='EditJournalBook(\"" + result[i].JournalBookUid + "\",\"" + 'JB' + "\");' class= 'common-btn common-btn-sm'><i class='fa-solid fa-pen-to-square'></i></button ><button type='button' onclick='DeleteJournalBook(\"" + result[i].JournalBookUid + "\",\"" + 'JB' + "\");' class= 'common-btn common-btn-sm'> <i class='fa-regular fa-trash-can'></i></button ></td > ");
            if (result[i].ApproveVoucher) {
                Count = Count + 1;
                tr.append("<td class='text-center'> <input type='checkbox' disabled='disabled' data-ledger_id='" + result[i].JournalBookUid + "' class=' mt-2 form-check-input' checked/></td>");
            }
            else {
                tr.append("<td class='text-center'> <input type='checkbox' data-ledger_id='" + result[i].JournalBookUid + "' class=' mt-2 form-check-input' /></td>");
            }
            tr.append("<td class='text-center'>" + serial_no + "</td>");
            tr.append("<td class='text-center'>" + result[i].JournalBookUid + "</td>");
            tr.append("<td  class='text-center'><a href='javascript:void(0)' class='text-decoration-none' style='color: black !important;' onclick='EditJournalBook(\"" + result[i].JournalBookUid + "\",\"" + 'JB' + "\");'>" + result[i].BranchName + "</a></td>");

            tr.append("<td  class='text-center'>" + result[i].AccDesc + "</td>");

            tr.append("<td  class='text-center'>" + HandleNullTextValue(result[i].VoucherNumber) + "</td>");
            tr.append("<td  class='text-center'>" + result[i].VoucherDt
                + "</td>");


            tr.append("<td  class='text-end'>" + result[i].TAmount + "</td>");
            /*  tr.append("<td  class='text-end'>" + HandleNullTextValue(result[i].AdjustedAmount) + "</a></td>");*/
            tr.append("<td  class='text-center'>" + result[i].created_by + "</td>");

            serial_no++;
            $("#tbl_JournalBook tbody").append(tr);
        }
        if (Count == result.length) {
            $("#ApproveAllJB").prop('checked', true);
        }
    }
}

//  JOURNAL BOOK  LIST PAGE INDEX
function JournalBookList(pageindex) {
    try {
        const dataString = {};
        dataString.PageSize = $("#ddlPageSize").val();
        dataString.PageIndex = pageindex;
        dataString.AccHead = $("#AccHeadSearch").val();
        dataString.TotalAmount = $("#TotalAmountSearch").val();
        dataString.VoucherDateFrom = $("#FromDateSearch").val();
        dataString.VoucherDateTo = $("#ToDateSearch").val();
        dataString.AmountFrom = $("#TotalAmountSearchFrom").val();
        dataString.AmountTo = $("#TotalAmountSearchTo").val();
        dataString.ApprovedSearch = $("#ApprovedSearch").val();
        dataString.OrderBy = $("#sort-column").val().trim() + " " + $("#sort-type").val().trim();

        AjaxSubmission(JSON.stringify(dataString), "/Master/VoucherEntry/JournalBookList ", $('input[name=__RequestVerificationToken]').val()).done(function (result) {
            let obj = result;
            if (obj.status == true) {
                if (obj.responsecode == '100') {
                    var ser = ((parseInt(obj.data.Table1[0].PageIndex) - 1) * parseInt(obj.data.Table1[0].PageSize)) + 1;
                    $('#JournalBook').prop('Checked', true);
                    $('#tbl_BankPayment').hide();
                    $('#tbl_BankReceipt').hide();
                    $('#tbl_JournalBook').show();
                    $('#tbl_CashPayment').hide();
                    $('#tbl_CashReceipt').hide();
                    $(".JB").css("background-color", "hsl(212deg 62% 49%)");
                    $(".CP").css("background-color", "#4299e1");
                    $(".CR").css("background-color", "#4299e1");
                    $(".BR").css("background-color", "#4299e1");
                    $(".BP").css("background-color", "#4299e1");
                    BindJournalBookListTable(obj.data.Table, ser);
                    if (obj.data.Table1 != undefined && obj.data.Table1.length > 0) {
                        $(".pagination").BindPaging({
                            ActiveCssClass: "current",
                            PagerCssClass: "pager",
                            PageIndex: parseInt(obj.data.Table1[0].PageIndex),
                            PageSize: parseInt(obj.data.Table1[0].PageSize),
                            RecordCount: parseInt(obj.data.Table1[0].count)
                        });
                    }
                }
                else {
                    Toast(RetrieveMessage(obj.responsecode), "Message", "error");
                }
            }
            else {
                window.location.href = '/ClientLogin/ClientLogin';
            }
            //Hideloader();
        }).fail(function (result) {
            console.log(result.Message);
            //Hideloader();
        });
    }
    catch (e) {
        console.log(e.message);
        //Hideloader();
    }
}


//FUNCTION FOR FORM SORTING
function FormSorting(obj) {
    if (Firstcolumn != "") {
        document.getElementById(Firstcolumn).innerHTML = document.getElementById(Firstcolumn).getAttribute("data-column") + " <i style='margin-left:10px;' class='fa-solid fa-sort'></i>";
    }
    let cn = obj.id;
    Firstcolumn = cn;
    var colname = $(obj).data("column");
    $("#sort-column").val(cn.replaceAll("_", ""));
    var sorttype = $("#sort-type").val();
    if (sorttype == "ASC") {
        $("#sort-type").val("DESC");
        $(obj).html(colname + " <i style='margin-left:10px;' class='fa-solid fa-sort-down'></i>");
    } else if (sorttype == "DESC") {
        $("#sort-type").val("ASC");
        $(obj).html(colname + " <i style='margin-left:10px;' class='fa-solid fa-sort-up'></i>");
    }
    if ($('input:radio[name=type]:checked').val() == "CR") {

        CashReceiptList(1);
    }
    else if ($('input:radio[name=type]:checked').val() == "CP") {

        CashPaymentList(1);
    }
    else if ($('input:radio[name=type]:checked').val() == "BP") {
        BankPaymentList(1);
    }
    else if ($('input:radio[name=type]:checked').val() == "BR") {
        BankReceiptList(1);
    }
    else if ($('input:radio[name=type]:checked').val() == "JB") {
        JournalBookList(1);
    }
}


//FUNCTION FOR SORTING FIELD
function Sorting(obj) {
    if (Firstcolumn != "") {
        document.getElementById(Firstcolumn).innerHTML = document.getElementById(Firstcolumn).getAttribute("data-column") + " <i class='fa-solid fa-sort'></i>";
    }
    Firstcolumn = obj.id;
    var colname = $(obj).data("column");
    $("#sort-column").val(Firstcolumn);
    var sorttype = $("#sort-type").val();
    if (sorttype == "ASC") {
        $("#sort-type").val("DESC");
        $(obj).html(colname + " <i style='margin-left:10px;' class='fa-solid fa-sort-up'></i>");
    } else if (sorttype == "DESC") {
        $("#sort-type").val("ASC");
        $(obj).html(colname + " <i style='margin-left:10px;' class='fa-solid fa-sort-down'></i>");
    }
    if ($('input:radio[name=type]:checked').val() == "CR" || $('input:radio[name=type1]:checked').val() == "ACR") {
        CashReceiptList(1);
    }
    else if ($('input:radio[name=type]:checked').val() == "CP" || $('input:radio[name=type1]:checked').val() == "ACP") {
        CashPaymentList(1);
    }
    else if ($('input:radio[name=type]:checked').val() == "BP" || $('input:radio[name=type1]:checked').val() == "ABP") {
        BankPaymentList(1);
    }
    else if ($('input:radio[name=type]:checked').val() == "BR" || $('input:radio[name=type1]:checked').val() == "ABR") {
        BankReceiptList(1);
    }
    else if ($('input:radio[name=type]:checked').val() == "JB" || $('input:radio[name=type1]:checked').val() == "AJB") {
        JournalBookList(1);
    }
}

//#endregion


function ApproveVoucherRadioChecked(e) {
    if (e === 'CP') {
        let a = $(".CheckAll").is(":checked");
        $("#tbl_CashPayment tbody tr").each(function (index, ele) {
            $(ele).find("input[type='checkbox']").prop("checked", a);

            $(ele).find("input[type='checkbox']").on("change", function () {
                if (!$(this).is(":checked")) {
                    $(".CheckAll").prop("checked", false);
                } else {
                    let allChecked = true;
                    $("#tbl_CashPayment tbody tr").each(function (i, row) {
                        if (!$(row).find("input[type='checkbox']").is(":checked")) {
                            allChecked = false;
                            return false;
                        }
                    });
                    if (allChecked) {
                        $(".CheckAll").prop("checked", true);
                    }
                }
            });
        });
    }
    else if (e === 'CR') {
        let a = $(".CheckAll").is(":checked");
        $("#tbl_CashReceipt tbody tr").each(function (index, ele) {
            $(ele).find("input[type='checkbox']").prop("checked", a);
            $(ele).find("input[type='checkbox']").on("change", function () {
                if (!$(this).is(":checked")) {
                    $(".CheckAll").prop("checked", false);
                } else {
                    let allChecked = true;
                    $("#tbl_CashReceipt tbody tr").each(function (i, row) {
                        if (!$(row).find("input[type='checkbox']").is(":checked")) {
                            allChecked = false;
                            return false;
                        }
                    });
                    if (allChecked) {
                        $(".CheckAll").prop("checked", true);
                    }
                }
            });
        });


    }
    else if (e === 'BP') {
        let a = $(".CheckAll").is(":checked");
        $("#tbl_BankPayment tbody tr").each(function (index, ele) {

            if ($(ele).find("input[type='checkbox']")[0].getAttribute('disabled') != 'disabled')
                $(ele).find("input[type='checkbox']").prop("checked", a);


            $(ele).find("input[type='checkbox']").on("change", function () {
                if (!$(this).is(":checked")) {
                    $(".CheckAll").prop("checked", false);
                } else {
                    let allChecked = true;
                    $("#tbl_BankPayment tbody tr").each(function (i, row) {
                        if (!$(row).find("input[type='checkbox']").is(":checked")) {
                            allChecked = false;
                            return false;
                        }
                    });
                    if (allChecked) {
                        $(".CheckAll").prop("checked", true);
                    }
                }
            });
        });
    }
    else if (e === 'BR') {
        let a = $(".CheckAll").is(":checked");
        $("#tbl_BankReceipt tbody tr").each(function (index, ele) {
            $(ele).find("input[type='checkbox']").prop("checked", a);

            $(ele).find("input[type='checkbox']").on("change", function () {
                if (!$(this).is(":checked")) {
                    $(".CheckAll").prop("checked", false);
                } else {
                    let allChecked = true;
                    $("#tbl_BankReceipt tbody tr").each(function (i, row) {
                        if (!$(row).find("input[type='checkbox']").is(":checked")) {
                            allChecked = false;
                            return false;
                        }
                    });
                    if (allChecked) {
                        $(".CheckAll").prop("checked", true);
                    }
                }
            });
        });
    } else {
        let a = $(".CheckAll").is(":checked");
        $("#tbl_JournalBook tbody tr").each(function (index, ele) {
            $(ele).find("input[type='checkbox']").prop("checked", a);

            $(ele).find("input[type='checkbox']").on("change", function () {
                if (!$(this).is(":checked")) {
                    $(".CheckAll").prop("checked", false);
                } else {
                    let allChecked = true;
                    $("#tbl_JournalBook tbody tr").each(function (i, row) {
                        if (!$(row).find("input[type='checkbox']").is(":checked")) {
                            allChecked = false;
                            return false;
                        }
                    });
                    if (allChecked) {
                        $(".CheckAll").prop("checked", true);
                    }
                }
            });
        });
    }
}

$('#ChkApproveVoucher').click(function () {
    try {
        $.confirm({
            title: '',
            content: 'Are You Sure Want To Approve voucher?',
            type: 'red',
            boxWidth: '300px',
            useBootstrap: false,
            columnClass: 'small',
            containerFluid: true,
            typeAnimated: true,
            buttons: {
                tryAgain: {
                    text: 'Confirm',
                    btnClass: 'btn-red',
                    action: function () {
                        let tableName = '';
                        if ($('#ApproveVoucherValueFill').html() == 'CashPayment') {
                            tableName = '#tbl_CashPayment';
                        }
                        else if ($('#ApproveVoucherValueFill').html() == 'BankPayment') {
                            tableName = '#tbl_BankPayment';
                        }
                        else if ($('#ApproveVoucherValueFill').html() == 'CashReceipt') {
                            tableName = '#tbl_CashReceipt';
                        }
                        else if ($('#ApproveVoucherValueFill').html() == 'BankReceipt') {
                            tableName = '#tbl_BankReceipt';
                        }
                        else {
                            tableName = '#tbl_JournalBook';
                        }

                        var CheckDetail = [];
                        $(tableName + ' tbody tr').each(function (ind, ele) {

                            if ($(ele).find('td:eq(1)').find('input[type=checkbox]')[0].getAttribute('disabled') != 'disabled') {
                                if ($(ele).find('td:eq(1)').find('input[type=checkbox]').is(':checked')) {
                                    var ApproveChkDetail = {
                                        Id: $(ele).find('td:eq(1)').find('input[type=checkbox]').data('ledger_id'),
                                        TableName: tableName
                                    };
                                    CheckDetail.push(ApproveChkDetail);
                                }
                            }

                        });


                        const dataString = {};
                        dataString.approveChkDetail = CheckDetail;
                        ShowLoader();
                        AjaxSubmission(JSON.stringify(dataString), "/Master/VoucherEntry/GetApproveVoucherList", $('[name="__RequestVerificationToken"]').val()).done(function (data) {
                            let obj = data;
                            if (obj.status == true) {
                                if (obj.responsecode == '101') {
                                    Toast(RetrieveMessage("Approve Voucher Successfully"), "Message", "success");
                                }
                                else {
                                    Toast(RetrieveMessage(obj.responsecode), "Message", "error");
                                }
                            }
                            else {
                                window.location.href = 'ClientLogin/ClientLogin';
                            }
                            HideLoader();
                        }).fail(function (data) {
                            console.log(data.Message);
                            HideLoader();
                        });
                    }
                },
                close: function () {
                }
            }
        });
    }
    catch (e) {
        console.log(e.message);
        HideLoader();
    }
});

//=======================================  INSERT UPDATE AND DELETE METHODS FOR CASHPAYMENT AND CASHRECEIPT  TABLE =======================================
//#region
// ADD   PAYMENT BUTTON CLICK
$(".CashPaymentSave").click(function () {
    var flag = 0;
    var debit = 0;
    var credit = 0;
    var voucherType = $(".CashPaymentSave")[0].id;
    if (voucherType == "BankPaymentSave") {
        $("#BankPayment").attr("checked", "checked");
        if ($("#Branch").val() == "0") {
            Toast(RetrieveMessage(910), 'Message', 'error');
            return;
        }
        if ($("#VoucherDate").val() == "") {
            Toast("Please Select Voucher Date !", 'Message', 'error');
            return;
        }
        if ($("#HiddenAccHeadId").val() == "") {
            Toast(RetrieveMessage(911), 'Message', 'error');
            return;
        }
        $("#VoucherEntry_Table tbody tr").each(function (index, ele) {
            if ($(ele).find('.HiddenLedgerId').val().length == 0) {
                Toast(RetrieveMessage(913), 'Message', 'error');
                flag = 1;
                return false;
            }
            if ($(ele).find('.AccDescription').val() == '') {
                Toast(RetrieveMessage(913), 'Message', 'error');
                flag = 1;
                return false;
            }
            if (($(ele).find('.JobExpence').val() > 0) && ($(ele).find('.JobNo ').val() == '') && ($(ele).find('.HiddenJobNo ').val() == '')) {
                Toast("Please Enter Job No !", 'Message', 'error');
                flag = 1;
                return false;
            }
            if ($(ele).find('.Amount').val() == '0.00') {
                Toast("Please Enter Amount !", 'Message', 'error');
                flag = 1;
                return false;
            }
            if ($(ele).find('.Txn').val() == 'Dr')  // Condition For Add Debit Value In JB
            {
                debit = debit + parseFloat($(ele).find('.Amount').val()); // Adding All Debit Amount
            }
            if ($(ele).find('.Txn').val() == 'Cr')  // Condition For Add Credit Value In JB
            {
                credit = credit + parseFloat($(ele).find('.Amount').val());  // Adding All Credit Amount
            }
        });
        var TtlAmt = $("#TotalAmount").val();
        if (debit < credit) {
            Toast("Please Enter Debit Amount Or Debit Amount Must Be Greater Than the Credit Amount !", 'Message', 'error');
            flag = 1;
            return false;
        }
        if (TtlAmt < "0") {
            Toast("The Total Amount field must contain a number greater than 0 !", 'Message', 'error');
            flag = 1;
            return false;
        }
        if (flag == 0) {
            AddBankPaymentOrRecipt();
        }

    }
    else if (voucherType == "BankReceiptSave") {
        $("#BankReceipt").attr("checked", "checked");
        if ($("#Branch").val() == "0") {
            Toast(RetrieveMessage(910), 'Message', 'error');
            return;
        }
        if ($("#VoucherDate").val() == "") {
            Toast("Please Select Voucher Date !", 'Message', 'error');
            return;
        }
        if ($("#HiddenAccHeadId").val() == "") {
            Toast(RetrieveMessage(911), 'Message', 'error');
            return;
        }
        $("#VoucherEntry_Table tbody tr").each(function (index, ele) {
            if ($(ele).find('.HiddenLedgerId').val().length == 0) {
                Toast(RetrieveMessage(913), 'Message', 'error');
                flag = 1;
                return false;
            }
            if ($(ele).find('.AccDescription').val() == '') {
                Toast(RetrieveMessage(913), 'Message', 'error');
                flag = 1;
                return false;
            }
            if (($(ele).find('.JobExpence').val() > 0) && ($(ele).find('.JobNo ').val() == '') && ($(ele).find('.HiddenJobNo ').val() == '')) {
                Toast("Please Enter Job No !", 'Message', 'error');
                flag = 1;
                return false;
            }
            if ($(ele).find('.Amount').val() == '0.00') {
                Toast("Please Enter Amount !", 'Message', 'error');
                flag = 1;
                return false;
            }
            if ($(ele).find('.Txn').val() == 'Dr')  // Condition For Add Debit Value In JB
            {
                debit = debit + parseFloat($(ele).find('.Amount').val()); // Adding All Debit Amount
            }
            if ($(ele).find('.Txn').val() == 'Cr')  // Condition For Add Credit Value In JB
            {
                credit = credit + parseFloat($(ele).find('.Amount').val());  // Adding All Credit Amount
            }

        });
        var TtlAmt = $("#TotalAmount").val();
        if (credit < debit) {
            Toast("Please Enter Credit Amount Or Credit Amount Must Be Greater Than the Debit Amount !", 'Message', 'error');
            flag = 1;
            return false;
        }
        if (TtlAmt < "0") {
            Toast("The Total Amount field must contain a number greater than 0 !", 'Message', 'error');
            flag = 1;
            return false;
        }
        if (flag == 0) {
            AddBankPaymentOrRecipt();
        }
    }

    else if (voucherType == "CashPaymentSave") {
        $("#CashPayment").attr("checked", "checked");
        if ($("#Branch").val() == "0") {
            Toast(RetrieveMessage(910), 'Message', 'error');
            return;
        }
        if ($("#VoucherDate").val() == "") {
            Toast("Please Select Voucher Date !", 'Message', 'error');
            return;
        }
        if ($("#HiddenAccHeadId").val() == "") {
            Toast(RetrieveMessage(911), 'Message', 'error');
            return;
        }
        $("#VoucherEntry_Table tbody tr").each(function (index, ele) {
            if ($(ele).find('.HiddenLedgerId').val().length == 0) {
                Toast(RetrieveMessage(913), 'Message', 'error');
                flag = 1;
                return false;
            }
            if ($(ele).find('.AccDescription').val() == '') {
                Toast(RetrieveMessage(913), 'Message', 'error');
                flag = 1;
                return false;
            }
            if (($(ele).find('.JobExpence').val() > 0) && ($(ele).find('.JobNo ').val() == '') && ($(ele).find('.HiddenJobNo ').val() == '')) {
                Toast("Please Enter Job No !", 'Message', 'error');
                flag = 1;
                return false;
            }
            if ($(ele).find('.Amount').val() == '0.00') {
                Toast("Please Enter Amount !", 'Message', 'error');
                flag = 1;
                return false;
            }
            if ($(ele).find('.Txn').val() == 'Dr') {
                debit = debit + parseFloat($(ele).find('.Amount').val());
            }
            if ($(ele).find('.Txn').val() == 'Cr') {
                credit = credit + parseFloat($(ele).find('.Amount').val());
            }

        });
        var TtlAmt = $("#TotalAmount").val();
        if (debit < credit) {
            Toast("Please Enter Debit Amount Or Debit Amount Must Be Greater Than the Credit Amount !", 'Message', 'error');
            //flag = 1;
            //return false;
            flag = 1;
            return;
        }
        if (TtlAmt < "0") {
            Toast("The Total Amount field must contain a number greater than 0 !", 'Message', 'error');
            flag = 1;
            return false;
        }
        if (flag == 0)
            AddCashPaymentOrCashReceipt();
    }
    else if (voucherType == "CashReceiptSave") {
        if ($("#Branch").val() == "0") {
            Toast(RetrieveMessage(910), 'Message', 'error');
            return;
        }
        if ($("#VoucherDate").val() == "") {
            Toast("Please Select Voucher Date !", 'Message', 'error');
            return;
        }
        if ($("#AccHead").val() == "0") {
            Toast(RetrieveMessage(911), 'Message', 'error');
            return;
        }
        $("#VoucherEntry_Table tbody tr").each(function (index, ele) {
            if ($(ele).find('.HiddenLedgerId').val().length == 0) {
                Toast(RetrieveMessage(913), 'Message', 'error');
                flag = 1;
                return false;
            }
            if ($(ele).find('.AccDescription').val() == '') {
                Toast(RetrieveMessage(913), 'Message', 'error');
                flag = 1;
                return false;
            }
            if (($(ele).find('.JobExpence').val() > 0) && ($(ele).find('.JobNo ').val() == '') && ($(ele).find('.HiddenJobNo ').val() == '')) {
                Toast("Please Enter Job No !", 'Message', 'error');
                flag = 1;
                return false;
            }
            if ($(ele).find('.Amount').val() == '0.00') {
                Toast("Please Enter Amount !", 'Message', 'error');
                flag = 1;
                return false;
            }
            if ($(ele).find('.Txn').val() == 'Dr') {
                debit = debit + parseFloat($(ele).find('.Amount').val());
            }
            if ($(ele).find('.Txn').val() == 'Cr') {
                credit = credit + parseFloat($(ele).find('.Amount').val());
            }
        });
        var TtlAmt = $("#TotalAmount").val();
        if (credit < debit) {
            Toast("Please Enter Credit Amount Or Credit Amount Must Be Greater Than the Debit Amount !", 'Message', 'error');
            flag = 1;
            return false;
        }
        if (TtlAmt < "0") {
            Toast("The Total Amount field must contain a number greater than 0 !", 'Message', 'error');
            flag = 1;
            return false;
        }
        if (flag == 0) {
            AddCashPaymentOrCashReceipt();
        }
    }
    else if (voucherType == "JournalBookSave") {
        $("#JournalBook").attr("checked", "checked");
        if ($("#Branch").val() == "0") {
            Toast(RetrieveMessage(910), 'Message', 'error');
            return;
        }
        if ($("#VoucherDate").val() == "") {
            Toast("Please Select Voucher Date !", 'Message', 'error');
            return;
        }
        var debit = 0;
        var credit = 0;
        $("#VoucherEntry_Table tbody tr").each(function (index, ele) {
            if ($(ele).find('.HiddenLedgerId').val().length == 0) {
                Toast(RetrieveMessage(913), 'Message', 'error');
                flag = 1;
                return false;
            }
            if ($(ele).find('.AccDescription').val() == '') {
                Toast(RetrieveMessage(913), 'Message', 'error');
                flag = 1;
                return false;
            }
            if (($(ele).find('.JobExpence').val() > 0) && ($(ele).find('.JobNo ').val() == '') && ($(ele).find('.HiddenJobNo ').val() == '')) {
                Toast("Please Enter Job No !", 'Message', 'error');
                flag = 1;
                return false;
            }
            if ($(ele).find('.Amount').val() == '0.00') {
                Toast("Please Enter Amount !", 'Message', 'error');
                flag = 1;
                return false;
            }
            if ($(ele).find('.Txn').val() == 'Dr') {
                debit = debit + parseFloat($(ele).find('.Amount').val());
            }
            if ($(ele).find('.Txn').val() == 'Cr') {
                credit = credit + parseFloat($(ele).find('.Amount').val());
            }
        });
        var TtlAmt = $("#TotalAmount").val(debit.toFixed(2));
        var amount1 = debit - credit;

        //if ((debit > credit) || (debit < credit)) {
        //    Toast("Debit Or Credit Amount Must Be Same !", 'Message', 'error');
        //    flag = 1;
        //    return false;
        //}

        if (flag == 0) {
            AddJournalBook();
        }
    }
});
// UPDATE  CASHPAYMENT  BUTTON CLICK
$("#CashPaymentUpdate").click(function () {
    var flag = 0;
    var debit = 0;
    var credit = 0;
    var voucherType = $("#CashPaymentUpdate")[0].id;
    if (voucherType == "CashPaymentUpdate") {
        if ($("#Branch").val() == "0") {
            Toast(RetrieveMessage(910), 'Message', 'error');
            return;
        }
        if ($("#VoucherDate").val() == "") {
            Toast("Please Select Voucher Date !", 'Message', 'error');
            return;
        }
        if ($("#HiddenAccHeadId").val() == "") {
            Toast(RetrieveMessage(911), 'Message', 'error');
            return;
        }
        $("#VoucherEntry_Table tbody tr").each(function (index, ele) {
            if ($(ele).find('.HiddenLedgerId').val().length == 0) {
                Toast(RetrieveMessage(913), 'Message', 'error');
                flag = 1;
                return false;
            }
            if ($(ele).find('.AccDescription').val() == '') {
                Toast(RetrieveMessage(913), 'Message', 'error');
                flag = 1;
                return false;
            }
            if (($(ele).find('.JobExpence').val() > 0) && ($(ele).find('.JobNo ').val() == '') && ($(ele).find('.HiddenJobNo ').val() == '')) {
                Toast("Please Enter Job No !", 'Message', 'error');
                flag = 1;
                return false;
            }
            if ($(ele).find('.Amount').val() == '0.00') {
                Toast("Please Enter Amount !", 'Message', 'error');
                flag = 1;
                return false;
            }
            if ($(ele).find('.Txn').val() == 'Dr')  // Condition For Add Debit Value In JB
            {
                debit = debit + parseFloat($(ele).find('.Amount').val()); // Adding All Debit Amount
            }
            if ($(ele).find('.Txn').val() == 'Cr')  // Condition For Add Credit Value In JB
            {
                credit = credit + parseFloat($(ele).find('.Amount').val());  // Adding All Credit Amount
            }
        });
        var TtlAmt = $("#TotalAmount").val();
        if (debit < credit) {
            Toast("Please Enter Debit Amount Or Debit Amount Must Be Greater Than the Credit Amount !", 'Message', 'error');
            //flag = 1;
            //return false;
            flag = 1;
            return;
        }
        if (TtlAmt < "0") {
            Toast("The Total Amount field must contain a number greater than 0 !", 'Message', 'error');
            flag = 1;
            return false;
        }
        if (flag == 0) {
            UpdateCashPaymentOrCashReceipt();
        }
    }

});

// UPDATE  CASH RECEIPT BUTTON CLICK
$("#CashReceiptUpdate").click(function () {
    var debit = 0;
    var credit = 0;
    var flag = 0;
    var voucherType = $("#CashReceiptUpdate")[0].id;
    if (voucherType == "CashReceiptUpdate") {
        if ($("#Branch").val() == "0") {
            Toast(RetrieveMessage(910), 'Message', 'error');
            return;
        }
        if ($("#VoucherDate").val() == "") {
            Toast("Please Select Voucher Date !", 'Message', 'error');
            return;
        }
        if ($("#HiddenAccHeadId").val() == "") {
            Toast(RetrieveMessage(911), 'Message', 'error');
            return;
        }
        $("#VoucherEntry_Table tbody tr").each(function (index, ele) {
            if ($(ele).find('.HiddenLedgerId').val().length == 0) {
                Toast(RetrieveMessage(913), 'Message', 'error');
                flag = 1;
                return false;
            }
            if ($(ele).find('.AccDescription').val() == '') {
                Toast(RetrieveMessage(913), 'Message', 'error');
                flag = 1;
                return false;
            }
            if (($(ele).find('.JobExpence').val() > 0) && ($(ele).find('.JobNo ').val() == '') && ($(ele).find('.HiddenJobNo ').val() == '')) {
                Toast("Please Enter Job No !", 'Message', 'error');
                flag = 1;
                return false;
            }
            if ($(ele).find('.Amount').val() == '0.00') {
                Toast("Please Enter Amount !", 'Message', 'error');
                flag = 1;
                return false;
            }
            if ($(ele).find('.Txn').val() == 'Dr') {
                debit = debit + parseFloat($(ele).find('.Amount').val());
            }
            if ($(ele).find('.Txn').val() == 'Cr') {
                credit = credit + parseFloat($(ele).find('.Amount').val());
            }

        });
        var TtlAmt = $("#TotalAmount").val();
        if (credit < debit) {
            Toast("Please Enter Credit Amount Or Credit Amount Must Be Greater Than the Debit Amount !", 'Message', 'error');
            flag = 1;
            return false;
        }
        if (TtlAmt < "0") {
            Toast("The Total Amount field must contain a number greater than 0 !", 'Message', 'error');
            flag = 1;
            return false;
        }
        if (flag == 0) {
            UpdateCashPaymentOrCashReceipt();
        }
    }
});

//FUNCTION FOR ADD CASHPAYMENT AND CASHRECEIPT 
function AddCashPaymentOrCashReceipt() {
    try {
        ma = $('input:radio[name=type]:checked').val();
        const dataString = {};
        dataString.BranchId = $("#Branch").val();
        dataString.VoucherNo = $("#VoucherNo").val();
        dataString.VoucherSerialNo = $("#VoucherSerialNo").val();
        //dataString.LedgerId = $("#AccHead").val();
        //dataString.AccHeadName = $("#AccHead option:selected").text();dataString.LedgerId = $("#AccHead").val();
        dataString.AccHeadName = $("#AccHead").val();
        dataString.LedgerId = $("#HiddenAccHeadId").val();
        dataString.VoucherDate = $("#VoucherDate").val();
        dataString.TotalAmount = $("#TotalAmount").val();
        dataString.chkval = $('input:radio[name=type1]:checked').val();
        dataString.Remarks = $("#Remarks").val();
        if ($("#ApproveVoucher").is(':checked') == true)
            dataString.ApproveVoucher = 1;
        else
            dataString.ApproveVoucher = 0;
        // dataString.ApproveVoucher = $("#ApproveVoucher").is(":checked") ? "1" :"0";
        var activeradio = $('input:radio[name=type1]:checked').val();
        var CPDetail = new Array();
        $("#VoucherEntry_Table tbody tr").each(function () {
            var CahPaymentDetail = {};
            CahPaymentDetail.BranchId = $("#Branch").val();
            CahPaymentDetail.VoucherNo = $("#VoucherNo").val();
            CahPaymentDetail.LedgerId = $("#AccHead").val();
            CahPaymentDetail.AccHeadName = $("#AccHead option:selected").text();
            CahPaymentDetail.VoucherDate = $("#VoucherDate").val();
            CahPaymentDetail.TotalAmount = $("#TotalAmount").val();
            CahPaymentDetail.chkval = $('input:radio[name=type1]:checked').val();
            CahPaymentDetail.LedgerId = $(this).find(".HiddenLedgerId").val();
            CahPaymentDetail.AccHead = $(this).find(".AccDescription").val();
            CahPaymentDetail.CurrentBalance = $(this).find(".CurBalance").val();
            CahPaymentDetail.JobNO = $(this).find(".HiddenJobNo").val();
            CahPaymentDetail.Container = $(this).find(".Container").val();
            CahPaymentDetail.ReceivingNo = $(this).find(".ReceivingNo").val();
            CahPaymentDetail.ReceivingDate = $(this).find(".ReceivingDate").val();
            CahPaymentDetail.Particular = $(this).find(".Particular").val();
            CahPaymentDetail.BillNO = $(this).find(".BillNo").val();
            CahPaymentDetail.TxnType = $(this).find(".Txn ").val();
            CahPaymentDetail.Amount = $(this).find(".Amount").val();
            CahPaymentDetail.JobExpense = $(this).find(".JobExpence").val();
            CPDetail.push(CahPaymentDetail);
        });

        dataString.cashPaymentGridListModals = CPDetail;
        dataString.cashReceiptGridListModals = CPDetail;

        AjaxSubmission(JSON.stringify(dataString), "/Master/VoucherEntry/AddCashPaymentOrCashReceipt", $('input[name=__RequestVerificationToken]').val()).done(function (result) {
            let obj = result;
            if (obj.status == true) {
                if (obj.responsecode == '101') {
                    if (activeradio == "ACP") {
                        Toast(RetrieveMessage(obj.responsecode), "Message", "success");
                        setTimeout(CashPaymentList(1), 500);
                        $("#CashPaymentId").val(obj.data.Table[0].CashPaymentUid);
                        $("#VocherTimestamp").val(obj.data.Table[0].Timestamp);
                        $("#Payment-tab").html("Edit Voucher");

                        $('.ACP').show();
                        $('.ACR, .ABR, .AJB, .ABP').hide();
                        $("#CashPaymentSave").hide();
                        $("#CashPaymentUpdate, #VoucherCancel, #VoucherMessage, #VoucherMail, #VoucherPDF, #VoucherDuplicate, #AdjustPayment, #UploadDocument, #FormReset").show();

                        tblCcId = obj.data.Table[0].CashPaymentUid;
                        formid = obj.data.Table[0].CashPaymentUid;
                    }
                    else if (activeradio == "ACR") {
                        Toast(RetrieveMessage(obj.responsecode), "Message", "success");
                        setTimeout(CashReceiptList(1), 500);
                        $("#CashReceiptSave").hide();
                        $("#CashReceiptUpdate, #VoucherCancel, #VoucherMessage, #VoucherMail, #VoucherPDF, #VoucherDuplicate, #AdjustPayment, #UploadDocument, #FormReset").show();
                        $("#Payment-tab").html("Edit Voucher");
                        $("#CashPaymentId").val(obj.data.Table[0].CashReceiptUid);
                        $("#VocherTimestamp").val(obj.data.Table[0].Timestamp);
                        $('.ACR').show();
                        $('.ACP, .ABR, .AJB, .ABP').hide();
                        tblCcId = obj.data.Table[0].CashReceiptUid;
                        formid = obj.data.Table[0].CashReceiptUid;
                    }
                }
                else {
                    Toast(RetrieveMessage(obj.responsecode), "Message", "error");
                }
            }
            else {
                window.location.href = '/ClientLogin/ClientLogin';
            }
            //Hideloader();
        }).fail(function (result) {
            console.log(result.Message);
            //Hideloader();
        });
    }
    catch (e) {
        console.log(e.message);
        //Hideloader();
    }
}

//FUNCTION FOR EDIT  CASHPAYMENT AND CASHRECEIPT 
function EditCashPaymentOrCashReceipt(CashPaymentUid, checkval) {
    try {
        IsNewVoucher = 1;
        FillBranchList('Branch');
        ma = checkval;
        if (checkval == 'CP') {
            $("#ACP").prop('checked', true);
            $('#CashPaymentUpdate, #VoucherMessage, #VoucherCancel, #VoucherMail, #VoucherPDF, #VoucherDuplicate, #AdjustPayment, #UploadDocument, #VoucherDelete').show();
            $('.CashPaymentSave').hide();
            $('.ACR, .ABP, .ABR, .AJB').hide();
            $(".paymentMethod").html('Cash Payment');
        }
        else if (checkval == 'CR') {
            $("#ACR").prop('checked', true);
            $('#CashReceiptUpdate, #VoucherMessage, #VoucherCancel, #VoucherMail, #VoucherPDF, #VoucherDuplicate, #AdjustPayment, #UploadDocument').show();
            $('.CashPaymentSave').hide();
            $('.ACP, .ABP, .ABR, .AJB').hide();
            $('.ACR').show();
            $(".paymentMethod").html('Cash Receipt');
        }
        ActionRadioChecked();
        const dataString = {};
        dataString.checkval = checkval;
        dataString.CashPaymentUid = parseInt(CashPaymentUid);
        ShowLoader();
        AjaxSubmission(JSON.stringify(dataString), "/Master/VoucherEntry/EditCashPaymentOrCashReceipt", $('[name="__RequestVerificationToken"]').val()).done(function (data) {
            let obj = data;
            if (obj.status == true) {
                if (obj.responsecode == '100') {
                    if (checkval == 'CR') {
                        tblCcId = obj.data.Table1[0].CashReceiptUid;
                    }
                    else {
                        tblCcId = obj.data.Table1[0].CashPaymentUid;
                    }
                    TabShow();
                    Resetdata();
                    ma = checkval;
                    if (checkval == 'CP') {
                        var FirstChild = $("#VoucherEntry_Table").find("tbody tr:first-child");
                        var CPTableData = obj.data.Table2;
                        $.each(CPTableData, function (index, ele) {
                            if (index == 0) {
                                FirstChild.find('.AccDescription').val(ele.AccHead);
                                FirstChild.find('.GroupName').val(ele.SubgroupHeadName);
                                FirstChild.find('.HiddenGroupId').val(ele.SubgroupHeadUid);
                                FirstChild.find('.HiddenLedgerId').val(ele.LedgerId);
                                FirstChild.find('.CurBalance').val(ele.CurrentBalance);
                                FirstChild.find('.Particular').val(ele.Particular);
                                FirstChild.find('.JobNo').val(ele.JobNo);
                                FirstChild.find('.HiddenJobNo').val(ele.jobuid);
                                FirstChild.find('.Container').val(ele.Container);
                                FirstChild.find('.ReceivingNo').val(ele.ReceivingNo);
                                FirstChild.find('.ReceivingDate').val(ele.ReceivingDate);
                                FirstChild.find('.BillNo').val(ele.BillNo);
                                if (ele.TxnType == 'Dr')
                                    FirstChild.find('.Txn').val('Dr').trigger('change');
                                else if (ele.TxnType == 'Cr')
                                    FirstChild.find('.Txn').val('Cr').trigger('change');
                                FirstChild.find('.Amount').val(ele.Amount);
                                FirstChild.find('.JobExpence').val(ele.JobExpense);
                            }
                            else {
                                var CloneChild = FirstChild.clone();
                                CloneChild.find('.HiddenLedgerId,.AccDescription,.HiddenGroupId,.GroupName,.CurBalance,.Particular,.JobNo,.HiddenJobNo,.Container,.ReceivingNo,.ReceivingDate,.BillNo,.Amount').val('');

                                CloneChild.find('.AccDescription').val(ele.AccHead);
                                CloneChild.find('.GroupName').val(ele.SubgroupHeadName);
                                CloneChild.find('.HiddenGroupId').val(ele.SubgroupHeadUid);
                                CloneChild.find('.HiddenLedgerId').val(ele.LedgerId);
                                CloneChild.find('.CurBalance').val(ele.CurrentBalance);
                                CloneChild.find('.Particular').val(ele.Particular);
                                CloneChild.find('.JobNo').val(ele.JobNo);
                                CloneChild.find('.HiddenJobNo').val(ele.jobuid);
                                CloneChild.find('.Container').val(ele.Container);
                                CloneChild.find('.ReceivingNo').val(ele.ReceivingNo);
                                CloneChild.find('.ReceivingDate').val(ele.ReceivingDate);
                                CloneChild.find('.BillNo').val(ele.BillNo);
                                if (ele.TxnType == 'Dr')
                                    CloneChild.find('.Txn').val('Dr');
                                else if (ele.TxnType == 'Cr')
                                    CloneChild.find('.Txn').val('Cr');
                                CloneChild.find('.Amount').val(ele.Amount);
                                CloneChild.find('.JobExpence').val(ele.JobExpense);
                                $("#VoucherEntry_Table tbody").append(CloneChild);
                            }
                        });
                        formid = obj.data.Table1[0].CashPaymentUid;
                        $("#Branch").val(obj.data.Table1[0].BranchId);
                        $("#VoucherNo").val(obj.data.Table1[0].VoucherNo);
                        $("#CashPaymentId").val(obj.data.Table1[0].CashPaymentUid);
                        $("#VocherTimestamp").val(obj.data.Table1[0].Timestamp);

                        /* $("#AccHead").val(parseInt(obj.data.Table1[0].LedgerId)).trigger('change');*/
                        $("#HiddenAccHeadId").val(parseInt(obj.data.Table1[0].LedgerId));
                        $("#AccHead").val(obj.data.Table1[0].AccHeadName);
                        $("#VoucherDate").val(obj.data.Table1[0].VoucherDate);
                        $("#TotalAmount").val(obj.data.Table1[0].TotalAmount);
                        $("#CreatedByModifiedBy").css('display', 'block');
                        $("#CreatedByModifiedBy").css('width', '100%');
                        $("#Created_UBy").text(obj.data.Table1[0].CreatedBy);
                        $("#CreatedAt").text(obj.data.Table1[0].CreatedAt);


                        $("#ModifiedBy").text(obj.data.Table1[0].LastUpdatedBy);
                        $("#ModifiedAt").text(obj.data.Table1[0].LastUpdatedAt);
                        $("#Remarks").text(obj.data.Table1[0].Remarks);

                        $("#ApproveVoucher").prop('checked', obj.data.Table1[0].ApproveVoucher);
                        $("#VoucherSerialNo").val(obj.data.Table1[0].VoucherSerialNo);

                    }
                    else if (checkval == "CR") {
                        var FirstChild = $("#VoucherEntry_Table").find("tbody tr:first-child");
                        var CPTableData = obj.data.Table2;
                        $.each(CPTableData, function (index, ele) {
                            if (index == 0) {
                                FirstChild.find('.AccDescription').val(ele.AccHead);
                                FirstChild.find('.GroupName').val(ele.SubgroupHeadName);
                                FirstChild.find('.HiddenGroupId').val(ele.SubgroupHeadUid);
                                FirstChild.find('.HiddenLedgerId').val(ele.LedgerId);
                                FirstChild.find('.CurBalance').val(ele.CurrentBalance);
                                FirstChild.find('.Particular').val(ele.Particular);
                                FirstChild.find('.JobNo').val(ele.JobNo);
                                FirstChild.find('.HiddenJobNo').val(ele.jobuid);
                                FirstChild.find('.Container').val(ele.Container);
                                FirstChild.find('.ReceivingNo').val(ele.ReceivingNo);
                                FirstChild.find('.ReceivingDate').val(ele.ReceivingDate);
                                FirstChild.find('.BillNo').val(ele.BillNo);
                                if (ele.TxnType == 'Dr')
                                    FirstChild.find('.Txn').val('Dr').trigger('change');
                                else if (ele.TxnType == 'Cr')
                                    FirstChild.find('.Txn').val('Cr').trigger('change');
                                FirstChild.find('.Amount').val(ele.Amount);
                                FirstChild.find('.JobExpence').val(ele.JobExpense);
                            }
                            else {
                                var CloneChild = FirstChild.clone();
                                CloneChild.find('.HiddenLedgerId,.AccDescription,.HiddenGroupId,.GroupName,.CurBalance,.Particular,.JobNo,.HiddenJobNo,.Container,.ReceivingNo,.ReceivingDate,.BillNo,.Amount').val('');
                                CloneChild.find('.AccDescription').val(ele.AccHead);
                                CloneChild.find('.GroupName').val(ele.SubgroupHeadName);
                                CloneChild.find('.HiddenGroupId').val(ele.SubgroupHeadUid);
                                CloneChild.find('.HiddenLedgerId').val(ele.LedgerId);
                                CloneChild.find('.CurBalance').val(ele.CurrentBalance);
                                CloneChild.find('.Particular').val(ele.Particular);
                                CloneChild.find('.JobNo').val(ele.JobNo);
                                CloneChild.find('.HiddenJobNo').val(ele.jobuid);
                                CloneChild.find('.Container').val(ele.Container);
                                CloneChild.find('.ReceivingNo').val(ele.ReceivingNo);
                                CloneChild.find('.ReceivingDate').val(ele.ReceivingDate);
                                CloneChild.find('.BillNo').val(ele.BillNo);
                                if (ele.TxnType == 'Dr')
                                    CloneChild.find('.Txn').val('Dr').trigger('change');
                                else if (ele.TxnType == 'Cr')
                                    CloneChild.find('.Txn').val('Cr').trigger('change');
                                CloneChild.find('.Amount').val(ele.Amount);
                                CloneChild.find('.JobExpence').val(ele.JobExpense);
                                $("#VoucherEntry_Table tbody").append(CloneChild);
                            }
                        });
                        formid = obj.data.Table1[0].CashReceiptUid;
                        $("#Branch").val(obj.data.Table1[0].BranchId);
                        $("#VoucherNo").val(obj.data.Table1[0].VoucherNo);
                        $("#CashPaymentId").val(obj.data.Table1[0].CashReceiptUid);
                        $("#VocherTimestamp").val(obj.data.Table1[0].Timestamp);
                        $("#HiddenAccHeadId").val(parseInt(obj.data.Table1[0].LedgerId));
                        $("#AccHead").val(obj.data.Table1[0].AccHeadName);

                        $("#VoucherDate").val(obj.data.Table1[0].VoucherDate);
                        $("#TotalAmount").val(obj.data.Table1[0].TotalAmount);
                        $("#CreatedByModifiedBy").css('display', 'block');
                        $("#CreatedByModifiedBy").css('width', '100%');
                        $("#Created_UBy").text(obj.data.Table1[0].CreatedBy);
                        $("#CreatedAt").text(obj.data.Table1[0].CreatedAt);
                        $("#ModifiedBy").text(obj.data.Table1[0].LastUpdatedBy);
                        $("#ModifiedAt").text(obj.data.Table1[0].LastUpdatedAt);
                        $("#Remarks").text(obj.data.Table1[0].Remarks);
                        $("#ApproveVoucher").prop('checked', obj.data.Table1[0].ApproveVoucher);
                        $("#VoucherSerialNo").val(obj.data.Table1[0].VoucherSerialNo);
                    }
                }
                else {
                    Toast(RetrieveMessage(obj.responsecode), "Message", "error");
                }
            }
            else {
                window.location.href = '/ClientLogin/ClientLogin';
            }
            HideLoader();
        }).fail(function (data) {
            console.log(data.Message);
            HideLoader();
        });
    }
    catch (e) {
        console.log(e.message);
        HideLoader();
    }
}

//FUNCTION FOR UPDATE CASHPAYMENT AND CASHRECEIPT  METHOD
function UpdateCashPaymentOrCashReceipt() {
    try {
        ma = $('input:radio[name=type]:checked').val();
        var checkval1 = $('input:radio[name=type1]:checked').val();
        const dataString = {};
        dataString.BranchId = $("#Branch").val();
        dataString.VoucherNo = $("#VoucherNo").val();
        dataString.AccHeadName = $("#AccHead").val();
        dataString.LedgerId = $("#HiddenAccHeadId").val();
        dataString.VoucherDate = $("#VoucherDate").val();
        dataString.TotalAmount = $("#TotalAmount").val();
        dataString.chkval = $('input:radio[name=type1]:checked').val();
        dataString.Remarks = $("#Remarks").val();
        dataString.ApproveVoucher = $("#ApproveVoucher").is(":checked");
        dataString.VoucherSerialNo = $("#VoucherSerialNo").val();
        if (checkval1 == "ACP")
            dataString.CashPaymentUid = $("#CashPaymentId").val();
        if (checkval1 == "ACR")
            dataString.CashReceiptUid = $("#CashPaymentId").val();
        dataString.timestamp = $("#VocherTimestamp").val();
        var CPDetail = new Array();
        $("#VoucherEntry_Table tbody tr").each(function () {
            var CahPaymentDetail = {};
            CahPaymentDetail.LedgerId = $(this).find(".HiddenLedgerId").val();
            CahPaymentDetail.AccHead = $(this).find(".AccDescription").val();
            CahPaymentDetail.CurrentBalance = $(this).find(".CurBalance").val();
            CahPaymentDetail.JobNO = $(this).find(".HiddenJobNo").val();
            CahPaymentDetail.Container = $(this).find(".Container").val();
            CahPaymentDetail.ReceivingNo = $(this).find(".ReceivingNo").val();
            CahPaymentDetail.ReceivingDate = $(this).find(".ReceivingDate").val();
            CahPaymentDetail.Particular = $(this).find(".Particular").val();
            CahPaymentDetail.BillNO = $(this).find(".BillNo").val();
            CahPaymentDetail.TxnType = $(this).find(".Txn ").val();
            CahPaymentDetail.Amount = $(this).find(".Amount").val();
            CPDetail.push(CahPaymentDetail);
        });
        dataString.cashPaymentGridListModals = CPDetail;
        dataString.cashReceiptGridListModals = CPDetail;
        ShowLoader();
        AjaxSubmission(JSON.stringify(dataString), "/Master/VoucherEntry/UpdateCashPaymentOrCashReceipt", $('input[name=__RequestVerificationToken]').val()).done(function (result) {
            let obj = result;
            if (obj.status == true) {

                if (obj.responsecode == '107') {
                    if (checkval1 == "ACP") {
                        Toast(RetrieveMessage(obj.responsecode), "Message", "success");
                        setTimeout(CashPaymentList(1), 500);
                        formid = obj.data.Table[0].CashPaymentUid;
                        $("#CashPaymentId").val(obj.data.Table[0].CashPaymentUid);
                        $("#VocherTimestamp").val(obj.data.Table[0].Timestamp);
                        tblCcId = obj.data.Table[0].CashPaymentUid;
                    }
                    else if (checkval1 == "ACR") {
                        Toast(RetrieveMessage(obj.responsecode), "Message", "success");
                        setTimeout(CashReceiptList(1), 500);
                        formid = obj.data.Table[0].CashReceiptUid;
                        $("#CashPaymentId").val(obj.data.Table[0].CashReceiptUid);
                        $("#VocherTimestamp").val(obj.data.Table[0].Timestamp);
                        tblCcId = obj.data.Table[0].CashReceiptUid;
                    }
                }
                else {
                    Toast(RetrieveMessage(obj.responsecode), "Message", "error");
                }
            }
            else {
                window.location.href = '/ClientLogin/ClientLogin';
            }
            HideLoader();
        }).fail(function (result) {
            console.log(result.Message);
            HideLoader();
        });
    }
    catch (e) {
        console.log(e.message);
        HideLoader();
    }
}

//FUNCTION FOR DELETE CASHPAYMENT AND CASHRECEIPT 
function DeleteCashPaymentOrCashReceipt(e, checkval) {

    try {
        $.confirm({
            title: '',
            content: 'Are You Sure Want To Delete ?',
            type: 'red',
            boxWidth: '300px',
            useBootstrap: false,
            columnClass: 'small',
            containerFluid: true,
            typeAnimated: true,
            buttons: {
                tryAgain: {
                    text: 'Confirm',
                    btnClass: 'btn-red',
                    action: function () {
                        const datastring = {};
                        datastring.CashPaymentUid = parseInt(e);
                        datastring.checkval = checkval;
                        var activeradio = $('input:radio[name=type1]:checked').val();
                        ShowLoader();
                        AjaxSubmission(JSON.stringify(datastring), "/Master/VoucherEntry/DeleteCashPaymentOrCashReceipt", $('[name="__RequestVerificationToken"]').val()).done(function (data) {
                            let obj = data;
                            if (obj.status == true) {
                                if (obj.responsecode == '102') {
                                    if (activeradio == "ACP") {
                                        Toast(RetrieveMessage(obj.responsecode), "Message", "success");
                                        CashPaymentList(1);
                                    }
                                    else if (activeradio == "ACR") {
                                        Toast(RetrieveMessage(obj.responsecode), "Message", "success");
                                        CashReceiptList(1);
                                        $("#CashReceipt").prop('Checked', true);
                                        CashReceiptList(1);
                                    }
                                }
                                else {
                                    Toast(RetrieveMessage(obj.responsecode), "Message", "error");
                                }
                            }
                            else {
                                window.location.href = 'ClientLogin/ClientLogin';
                            }
                            HideLoader();
                        }).fail(function (data) {
                            console.log(data.Message);
                            HideLoader();
                        });
                    }
                },
                close: function () {
                }
            }
        });
    }
    catch (e) {
        console.log(e.message);
        HideLoader();
    }
}
//#endregion
//*==================== INSERT UPDATE AND DELETE METHODS FOR  BANKPAYMENT AND BANKRECEIPT TABLE ==============================

//#region
// UPDATE  BANK PAYMENT BUTTON CLICK
$("#BankPaymentUpdate").click(function () {
    var debit = 0;
    var credit = 0;
    var flag = 0;

    var voucherType = $("#BankPaymentUpdate")[0].id;
    if (voucherType == "BankPaymentUpdate") {

        if ($("#Branch").val() == "0") {
            Toast(RetrieveMessage(910), 'Message', 'error');
            return;
        }
        if ($("#VoucherDate").val() == "") {
            Toast("Please Select Voucher Date !", 'Message', 'error');
            return;
        }
        if ($("#HiddenAccHeadId").val() == "") {
            Toast(RetrieveMessage(911), 'Message', 'error');
            return;
        }
        $("#VoucherEntry_Table tbody tr").each(function (index, ele) {
            if ($(ele).find('.HiddenLedgerId').val().length == 0) {
                Toast(RetrieveMessage(913), 'Message', 'error');
                flag = 1;
                return false;
            }
            if ($(ele).find('.AccDescription').val() == '') {
                Toast(RetrieveMessage(913), 'Message', 'error');
                flag = 1;
                return false;
            }
            if (($(ele).find('.JobExpence').val() > 0) && ($(ele).find('.JobNo ').val() == '') && ($(ele).find('.HiddenJobNo ').val() == '')) {
                Toast("Please Enter Job No !", 'Message', 'error');
                flag = 1;
                return false;
            }
            if ($(ele).find('.Amount').val() == '0.00') {
                Toast("Please Enter Amount !", 'Message', 'error');
                flag = 1;
                return false;
            }

            if ($(ele).find('.Txn').val() == 'Dr') {
                debit = debit + parseFloat($(ele).find('.Amount').val());
            }
            if ($(ele).find('.Txn').val() == 'Cr') {
                credit = credit + parseFloat($(ele).find('.Amount').val());
            }
        });
        var TtlAmt = $("#TotalAmount").val();
        if (debit < credit) {
            Toast("Please Enter Debit Amount Or Debit Amount Must Be Greater Than the Credit Amount !", 'Message', 'error');
            flag = 1;
            return false;
        }
        if (TtlAmt < "0") {
            Toast("The Total Amount field must contain a number greater than 0 !", 'Message', 'error');
            flag = 1;
            return false;
        }
        if (flag == 0) {
            UpdateBankPaymentOrReceipt();
        }
    }

});

// UPDATE  BANK RECEIPT BUTTON CLICK
$("#BankReceiptUpdate").click(function () {

    var flag = 0;
    var debit = 0;
    var credit = 0;
    var voucherType = $("#BankReceiptUpdate")[0].id;
    if (voucherType == "BankReceiptUpdate") {

        if ($("#Branch").val() == "0") {
            Toast(RetrieveMessage(910), 'Message', 'error');
            return;
        }
        if ($("#VoucherDate").val() == "") {
            Toast("Please Select Voucher Date !", 'Message', 'error');
            return;
        }
        if ($("#HiddenAccHeadId").val() == "") {
            Toast(RetrieveMessage(911), 'Message', 'error');
            return;
        }
        $("#VoucherEntry_Table tbody tr").each(function (index, ele) {
            if ($(ele).find('.HiddenLedgerId').val().length == 0) {
                Toast(RetrieveMessage(913), 'Message', 'error');
                flag = 1;
                return false;
            }
            if ($(ele).find('.AccDescription').val() == '') {
                Toast(RetrieveMessage(913), 'Message', 'error');
                flag = 1;
                return false;
            }
            if (($(ele).find('.JobExpence').val() > 0) && ($(ele).find('.JobNo ').val() == '') && ($(ele).find('.HiddenJobNo ').val() == '')) {
                Toast("Please Enter Job No !", 'Message', 'error');
                flag = 1;
                return false;
            }
            if ($(ele).find('.Amount').val() == '0.00') {
                Toast("Please Enter Amount !", 'Message', 'error');
                flag = 1;
                return false;
            }
            if ($(ele).find('.Txn').val() == 'Dr') {
                debit = debit + parseFloat($(ele).find('.Amount').val());
            }
            if ($(ele).find('.Txn').val() == 'Cr') {
                credit = credit + parseFloat($(ele).find('.Amount').val());
            }
            var TtlAmt = $("#TotalAmount").val();
            if (credit < debit) {
                Toast("Credit Amount Must Be Greater Than the Debit Amount !", 'Message', 'error');
                flag = 1;
                return false;
            }
            if (TtlAmt < "0") {
                Toast("The Total Amount field must contain a number greater than 0 !", 'Message', 'error');
                flag = 1;
                return false;
            }
        });

        var TtlAmt = $("#TotalAmount").val();
        if (credit < debit) {
            Toast("Please Enter Credit Amount Or Credit Amount Must Be Greater Than the Debit Amount !", 'Message', 'error');
            flag = 1;
            return false;
        }
        if (TtlAmt < "0") {
            Toast("The Total Amount field must contain a number greater than 0 !", 'Message', 'error');
            flag = 1;
            return false;
        }
        if (flag == 0) {
            UpdateBankPaymentOrReceipt();
        }
    }

});

//FUNCTION FOR ADD  BANK PAYMENT OR RECEIPT ENTRY
function AddBankPaymentOrRecipt() {
    try {
        ma = $('input:radio[name=type]:checked').val();
        var checkval1 = $('input:radio[name=type1]:checked').val();
        const dataString = {};
        dataString.BranchId = $("#Branch").val();
        dataString.VoucherNo = $("#VoucherNo").val();
        //dataString.LedgerId = $("#AccHead").val();
        //dataString.AccHeadName = $("#AccHead option:selected").text();
        dataString.AccHeadName = $("#AccHead").val();
        dataString.LedgerId = $("#HiddenAccHeadId").val();
        dataString.VoucherDate = $("#VoucherDate").val();
        dataString.TotalAmount = $("#TotalAmount").val();
        dataString.ChequeNo = $("#ChequeNo").val();
        dataString.ChequeDate = $("#ChequeDate").val();
        dataString.chkval = $('input:radio[name=type1]:checked').val();
        dataString.Remarks = $("#Remarks").val();
        dataString.ApproveVoucher = $("#ApproveVoucher").is(":checked");
        dataString.VoucherSerialNo = $("#VoucherSerialNo").val();

        var BPandBRDetail = new Array();
        $("#VoucherEntry_Table tbody tr").each(function () {
            var BankPaymentorReceiptDetail = {};
            BankPaymentorReceiptDetail.LedgerId = $(this).find(".HiddenLedgerId").val();
            BankPaymentorReceiptDetail.AccHead = $(this).find(".AccDescription").val();
            BankPaymentorReceiptDetail.CurrentBalance = $(this).find(".CurBalance").val();
            BankPaymentorReceiptDetail.JobNO = $(this).find(".HiddenJobNo").val();
            BankPaymentorReceiptDetail.Container = $(this).find(".Container").val();
            BankPaymentorReceiptDetail.ReceivingNo = $(this).find(".ReceivingNo").val();
            BankPaymentorReceiptDetail.ReceivingDate = $(this).find(".ReceivingDate").val();
            BankPaymentorReceiptDetail.Particular = $(this).find(".Particular").val();
            BankPaymentorReceiptDetail.BillNo = $(this).find(".BillNo").val();
            BankPaymentorReceiptDetail.TxnType = $(this).find(".Txn ").val();
            BankPaymentorReceiptDetail.Amount = $(this).find(".Amount").val();
            BPandBRDetail.push(BankPaymentorReceiptDetail);
        });
        dataString.bankPaymentVoucherListModals = BPandBRDetail;
        dataString.bankReceiptVoucherListModals = BPandBRDetail;
        ShowLoader();
        AjaxSubmission(JSON.stringify(dataString), "/Master/VoucherEntry/AddBankPaymentOrReceipt", $('input[name=__RequestVerificationToken]').val()).done(function (result) {
            let obj = result;
            if (obj.status == true) {
                if (obj.responsecode == '101') {
                    if (checkval1 == "ABP") {
                        Toast(RetrieveMessage(obj.responsecode), "Message", "success");
                        setTimeout(BankPaymentList(1), 500);

                        $("#BankPaymentSave").hide();
                        $('#FormReset, #BankPaymentUpdate, #VoucherCancel, #VoucherMessage, #VoucherMail, #VoucherPDF, #VoucherDuplicate, #AdjustPayment, #UploadDocument').show();
                        $("#Payment-tab").html("Edit Voucher");
                        $("#CashPaymentId").val(obj.data.Table[0].BankPaymentUid);
                        $("#VocherTimestamp").val(obj.data.Table[0].Timestamp);
                        $('.ACR, .ACP, .ABR, .AJB').hide();
                        $('.ABP').show();

                        tblCcId = obj.data.Table[0].BankPaymentUid;
                        formid = obj.data.Table[0].BankPaymentUid;
                    }
                    else if (checkval1 == "ABR") {
                        Toast(RetrieveMessage(obj.responsecode), "Message", "success");
                        setTimeout(BankReceiptList(1), 500);
                        $("#Payment-tab").html("Edit Voucher");
                        $("#CashPaymentId").val(obj.data.Table[0].BankReceiptUid);
                        $("#VocherTimestamp").val(obj.data.Table[0].Timestamp);
                        tblCcId = obj.data.Table[0].BankReceiptUid;
                        formid = obj.data.Table[0].BankReceiptUid;
                        $('#BankReceiptUpdate, #VoucherCancel, #VoucherMessage, #VoucherMail, #VoucherPDF, #VoucherDuplicate, #AdjustPayment, #FormReset').show();
                        $("#BankReceiptSave").hide();
                        $('.ACR, .ACP, .AJB, .ABP').hide();
                        $('.ABR').show();
                    }
                }
                else {
                    Toast(RetrieveMessage(obj.responsecode), "Message", "error");
                }
            }
            else {
                window.location.href = '/ClientLogin/ClientLogin';
            }
            HideLoader();
        }).fail(function (result) {
            console.log(result.Message);
            HideLoader();
        });
    }
    catch (e) {
        console.log(e.message);
        HideLoader();
    }
}
//FUNCTION FOR EDIT  BANK PAYMENT OR RECEIPT ENTRY
function EditBankPaymentOrReceipt(BankPaymentUid, checkval) {

    try {
        IsNewVoucher == 1;
        FillBranchList('Branch');
        $('.AllVoucher').show();
        if (checkval == 'BP') {
            $("#ABP").prop('checked', true);
            $('#BankPaymentUpdate, #VoucherMessage, #VoucherCancel, #VoucherMail, #VoucherPDF, #VoucherDuplicate, #AdjustPayment, #UploadDocument, #VoucherDelete').show();
            $('.CashPaymentSave, .ACR, .ACP, .ABR, .AJB').hide();
            $('.ABP').show();

            $(".paymentMethod").html('Bank Payment');
        }
        else if (checkval == 'BR') {
            $('#BankReceiptUpdate, #VoucherMessage, #VoucherCancel, #VoucherMail, #VoucherPDF, #VoucherDuplicate, #AdjustPayment, #UploadDocument').show();
            $('.CashPaymentSave, .ACR, .ABP, .ACP, .AJB').hide();
            $('.ABR').show();
            $(".paymentMethod").html('Bank Receipt');
        }
        ActionRadioChecked();
        const dataString = {};
        dataString.checkval = checkval;
        dataString.BankPaymentUid = parseInt(BankPaymentUid);
        ShowLoader();
        AjaxSubmission(JSON.stringify(dataString), "/Master/VoucherEntry/EditBankPaymentOrReceipt", $('[name="__RequestVerificationToken"]').val()).done(function (data) {
            let obj = data;
            ma = checkval;
            Resetdata();
            if (obj.status == true) {
                if (obj.responsecode == '100') {
                    if (checkval == 'BP') {
                        tblCcId = obj.data.Table1[0].BankPaymentUid;
                    }
                    else {
                        tblCcId = obj.data.Table1[0].BankReceiptUid;
                    }
                    ma = checkval;
                    TabShow();

                    if (checkval == 'BP') {

                        var FirstChild = $("#VoucherEntry_Table").find("tbody tr:first-child");
                        var CPTableData = obj.data.Table2;
                        $.each(CPTableData, function (index, ele) {
                            if (index == 0) {
                                FirstChild.find('.AccDescription').val(ele.AccHead);
                                FirstChild.find('.GroupName').val(ele.SubgroupHeadName);
                                FirstChild.find('.HiddenGroupId').val(ele.SubgroupHeadUid);
                                FirstChild.find('.HiddenLedgerId').val(ele.LedgerId);
                                FirstChild.find('.CurBalance').val(ele.CurrentBalance);
                                FirstChild.find('.Particular').val(ele.Particular);
                                FirstChild.find('.JobNo').val(ele.JobNo);
                                FirstChild.find('.HiddenJobNo').val(ele.jobuid);
                                FirstChild.find('.Container').val(ele.Container);
                                FirstChild.find('.ReceivingNo').val(ele.ReceivingNo);
                                FirstChild.find('.ReceivingDate').val(ele.ReceivingDate);
                                FirstChild.find('.BillNo').val(ele.BillNo);
                                if (ele.TxnType == 'Dr')
                                    FirstChild.find('.Txn').val('Dr').trigger('change');
                                else if (ele.TxnType == 'Cr')
                                    FirstChild.find('.Txn').val('Cr').trigger('change');
                                FirstChild.find('.Amount').val(ele.Amount);
                                FirstChild.find('.JobExpence').val(ele.JobExpense);
                            }
                            else {
                                var CloneChild = FirstChild.clone();
                                CloneChild.find('.AccDescription').val('0');
                                CloneChild.find('.HiddenLedgerId,.HiddenGroupId,.GroupName,.CurBalance,.Particular,.JobNo,.HiddenJobNo,.Container,.ReceivingNo,.ReceivingDate,.BillNo,.Amount').val('');
                                CloneChild.find('.AccDescription').val(ele.AccHead);
                                CloneChild.find('.GroupName').val(ele.SubgroupHeadName);
                                CloneChild.find('.HiddenGroupId').val(ele.SubgroupHeadUid);
                                CloneChild.find('.HiddenLedgerId').val(ele.LedgerId);
                                CloneChild.find('.CurBalance').val(ele.CurrentBalance);
                                CloneChild.find('.Particular').val(ele.Particular);
                                CloneChild.find('.JobNo').val(ele.JobNo);
                                CloneChild.find('.HiddenJobNo').val(ele.jobuid);
                                CloneChild.find('.Container').val(ele.Container);
                                CloneChild.find('.ReceivingNo').val(ele.ReceivingNo);
                                CloneChild.find('.ReceivingDate').val(ele.ReceivingDate);
                                CloneChild.find('.BillNo').val(ele.BillNo);
                                if (ele.TxnType == 'Dr')
                                    CloneChild.find('.Txn').val('Dr').trigger('change');
                                else if (ele.TxnType == 'Cr')
                                    CloneChild.find('.Txn').val('Cr').trigger('change');
                                CloneChild.find('.Amount').val(ele.Amount);
                                CloneChild.find('.JobExpence').val(ele.JobExpense);
                                $("#VoucherEntry_Table tbody").append(CloneChild);
                            }
                        });

                        formid = obj.data.Table1[0].BankPaymentUid;
                        $("#Branch").val(obj.data.Table1[0].BranchId);
                        $("#VoucherNo").val(obj.data.Table1[0].VoucherNo);
                        $("#CashPaymentId").val(obj.data.Table1[0].BankPaymentUid);
                        $("#VocherTimestamp").val(obj.data.Table1[0].Timestamp);
                        $("#HiddenAccHeadId").val(parseInt(obj.data.Table1[0].LedgerId));
                        $("#AccHead").val(obj.data.Table1[0].AccHeadName);
                        $("#VoucherDate").val(obj.data.Table1[0].VoucherDate);
                        $("#TotalAmount").val(obj.data.Table1[0].TotalAmount);
                        $("#ChequeNo").val(obj.data.Table1[0].ChequeNo);
                        $("#ChequeDate").val(obj.data.Table1[0].ChequeDate);
                        $("#CreatedByModifiedBy").css('display', 'block');
                        $("#CreatedByModifiedBy").css('width', '100%');
                        $("#Created_UBy").text(obj.data.Table1[0].CreatedBy);
                        $("#CreatedAt").text(obj.data.Table1[0].CreatedAt);
                        $("#ModifiedBy").text(obj.data.Table1[0].LastUpdatedBy);
                        $("#ModifiedAt").text(obj.data.Table1[0].LastUpdatedAt);
                        $("#Remarks").text(obj.data.Table1[0].Remarks);
                        $("#ApproveVoucher").prop('checked', obj.data.Table1[0].ApproveVoucher);
                        $("#VoucherSerialNo").val(obj.data.Table1[0].VoucherSerialNo);
                    }
                    else {
                        var FirstChild = $("#VoucherEntry_Table").find("tbody tr:first-child");
                        var CPTableData = obj.data.Table2;
                        $.each(CPTableData, function (index, ele) {
                            if (index == 0) {
                                FirstChild.find('.AccDescription').val(ele.AccHead);
                                FirstChild.find('.GroupName').val(ele.SubgroupHeadName);
                                FirstChild.find('.HiddenGroupId').val(ele.SubgroupHeadUid);
                                FirstChild.find('.HiddenLedgerId').val(ele.LedgerId);
                                FirstChild.find('.CurBalance').val(ele.CurrentBalance);
                                FirstChild.find('.Particular').val(ele.Particular);
                                FirstChild.find('.JobNo').val(ele.JobNo);
                                FirstChild.find('.HiddenJobNo').val(ele.jobuid);
                                FirstChild.find('.Container').val(ele.Container);
                                FirstChild.find('.ReceivingNo').val(ele.ReceivingNo);
                                FirstChild.find('.ReceivingDate').val(ele.ReceivingDate);
                                FirstChild.find('.BillNo').val(ele.BillNo);
                                if (ele.TxnType == 'Dr')
                                    FirstChild.find('.Txn').val('Dr').trigger('change');
                                else if (ele.TxnType == 'Cr')
                                    FirstChild.find('.Txn').val('Cr').trigger('change');
                                FirstChild.find('.Amount').val(ele.Amount);
                                FirstChild.find('.JobExpence').val(ele.JobExpense);
                            }
                            else {
                                var CloneChild = FirstChild.clone();
                                CloneChild.find('.AccDescription').val('0');
                                CloneChild.find('.HiddenLedgerId,.HiddenGroupId,.GroupName,.CurBalance,.Particular,.JobNo,.HiddenJobNo,.Container,.ReceivingNo,.ReceivingDate,.BillNo,.Amount').val('');
                                CloneChild.find('.AccDescription').val(ele.AccHead);
                                CloneChild.find('.GroupName').val(ele.SubgroupHeadName);
                                CloneChild.find('.HiddenGroupId').val(ele.SubgroupHeadUid);
                                CloneChild.find('.HiddenLedgerId').val(ele.LedgerId);
                                CloneChild.find('.CurBalance').val(ele.CurrentBalance);
                                CloneChild.find('.Particular').val(ele.Particular);
                                CloneChild.find('.JobNo').val(ele.JobNo);
                                CloneChild.find('.HiddenJobNo').val(ele.jobuid);
                                CloneChild.find('.Container').val(ele.Container);
                                CloneChild.find('.ReceivingNo').val(ele.ReceivingNo);
                                CloneChild.find('.ReceivingDate').val(ele.ReceivingDate);
                                CloneChild.find('.BillNo').val(ele.BillNo);
                                if (ele.TxnType == 'Dr')
                                    CloneChild.find('.Txn').val('Dr').trigger('change');
                                else if (ele.TxnType == 'Cr')
                                    CloneChild.find('.Txn').val('Cr').trigger('change');
                                CloneChild.find('.Amount').val(ele.Amount);
                                CloneChild.find('.JobExpence').val(ele.JobExpense);
                                $("#VoucherEntry_Table tbody").append(CloneChild);
                            }
                        });
                        formid = obj.data.Table1[0].BankReceiptUid;
                        $("#Branch").val(obj.data.Table1[0].BranchId);
                        $("#VoucherNo").val(obj.data.Table1[0].VoucherNo);
                        $("#CashPaymentId").val(obj.data.Table1[0].BankReceiptUid);
                        $("#VocherTimestamp").val(obj.data.Table1[0].Timestamp);
                        $("#HiddenAccHeadId").val(parseInt(obj.data.Table1[0].LedgerId));
                        $("#AccHead").val(obj.data.Table1[0].AccHeadName);
                        $("#VoucherDate").val(obj.data.Table1[0].VoucherDate);
                        $("#TotalAmount").val(obj.data.Table1[0].TotalAmount);
                        $("#ChequeNo").val(obj.data.Table1[0].ChequeNo);
                        $("#ChequeDate").val(obj.data.Table1[0].ChequeDate);
                        $("#CreatedByModifiedBy").css('display', 'block');
                        $("#CreatedByModifiedBy").css('width', '100%');
                        $("#Created_UBy").text(obj.data.Table1[0].CreatedBy);
                        $("#CreatedAt").text(obj.data.Table1[0].CreatedAt);
                        $("#ModifiedBy").text(obj.data.Table1[0].LastUpdatedBy);
                        $("#ModifiedAt").text(obj.data.Table1[0].LastUpdatedAt);
                        $("#Remarks").text(obj.data.Table1[0].Remarks);
                        $("#ApproveVoucher").prop('checked', obj.data.Table1[0].ApproveVoucher);
                        $("#VoucherSerialNo").val(obj.data.Table1[0].VoucherSerialNo);
                    }
                }
                else {
                    Toast(RetrieveMessage(obj.responsecode), "Message", "error");
                }
            }
            else {
                window.location.href = '/ClientLogin/ClientLogin';
            }
            HideLoader();
        }).fail(function (data) {
            console.log(data.Message);
            HideLoader();
        });
    }
    catch (e) {
        console.log(e.message);
        HideLoader();
    }
}

//FUNCTION FOR UPDATE  BANK PAYMENT OR RECEIPT  METHOD
function UpdateBankPaymentOrReceipt() {
    try {
        ma = $('input:radio[name=type]:checked').val();
        var checkval = $('input:radio[name=type1]:checked').val();
        const dataString = {};
        dataString.BranchId = $("#Branch").val();
        dataString.VoucherNo = $("#VoucherNo").val();
        dataString.VoucherSerialNo = $("#VoucherSerialNo").val();
        //dataString.LedgerId = $("#AccHead").val();
        //dataString.AccHeadName = $("#AccHead option:selected").text();
        dataString.AccHeadName = $("#AccHead").val();
        dataString.LedgerId = $("#HiddenAccHeadId").val();
        dataString.VoucherDate = $("#VoucherDate").val();
        dataString.TotalAmount = $("#TotalAmount").val();
        dataString.ChequeNo = $("#ChequeNo").val();
        dataString.ChequeDate = $("#ChequeDate").val();
        dataString.chkval = $('input:radio[name=type1]:checked').val();
        if (checkval == "ABP")
            dataString.BankPaymentUid = $("#CashPaymentId").val();

        if (checkval == "ABR")
            dataString.BankReceiptUid = $("#CashPaymentId").val();

        dataString.timestamp = $("#VocherTimestamp").val();
        dataString.Remarks = $("#Remarks").val();
        dataString.ApproveVoucher = $("#ApproveVoucher").is(":checked");
        var BPandBRDetail = new Array();
        $("#VoucherEntry_Table tbody tr").each(function () {
            var BankPaymentorReceiptDetail = {};
            BankPaymentorReceiptDetail.LedgerId = $(this).find(".HiddenLedgerId").val();
            BankPaymentorReceiptDetail.AccHead = $(this).find(".AccDescription").val();
            BankPaymentorReceiptDetail.CurrentBalance = $(this).find(".CurBalance").val();
            BankPaymentorReceiptDetail.JobNO = $(this).find(".HiddenJobNo").val();
            BankPaymentorReceiptDetail.Container = $(this).find(".Container").val();
            BankPaymentorReceiptDetail.ReceivingNo = $(this).find(".ReceivingNo").val();
            BankPaymentorReceiptDetail.ReceivingDate = $(this).find(".ReceivingDate").val();
            BankPaymentorReceiptDetail.Particular = $(this).find(".Particular").val();
            BankPaymentorReceiptDetail.BillNo = $(this).find(".BillNo").val();
            BankPaymentorReceiptDetail.TxnType = $(this).find(".Txn ").val();
            BankPaymentorReceiptDetail.Amount = $(this).find(".Amount").val();
            BPandBRDetail.push(BankPaymentorReceiptDetail);
        });
        dataString.bankPaymentVoucherListModals = BPandBRDetail;
        dataString.bankReceiptVoucherListModals = BPandBRDetail;
        ShowLoader();
        AjaxSubmission(JSON.stringify(dataString), "/Master/VoucherEntry/UpdateBankPaymentOrReceipt", $('input[name=__RequestVerificationToken]').val()).done(function (result) {
            let obj = result;
            if (obj.status == true) {
                if (obj.responsecode == '107') {
                    if (checkval == "ABP") {
                        Toast(RetrieveMessage(obj.responsecode), "Message", "success");
                        setTimeout(BankPaymentList(1), 500);
                        /*EditBankPaymentOrReceipt(obj.data.Table1[0].BankPaymentUid, "BP");*/
                        $("#CashPaymentId").val(obj.data.Table[0].BankPaymentUid);
                        $("#VocherTimestamp").val(obj.data.Table[0].Timestamp);
                        tblCcId = obj.data.Table[0].BankPaymentUid;
                        formid = obj.data.Table[0].BankPaymentUid;
                    }
                    else {
                        Toast(RetrieveMessage(obj.responsecode), "Message", "success");
                        setTimeout(BankReceiptList(1), 500);
                        /*   EditBankPaymentOrReceipt(obj.data.Table1[0].BankReceiptUid, "BR");*/
                        $("#CashPaymentId").val(obj.data.Table[0].BankReceiptUid);
                        $("#VocherTimestamp").val(obj.data.Table[0].Timestamp);
                        tblCcId = obj.data.Table[0].BankReceiptUid;
                        formid = obj.data.Table[0].BankReceiptUid;
                    }
                }
                else {
                    Toast(RetrieveMessage(obj.responsecode), "Message", "error");
                }
            }
            else {
                window.location.href = '/ClientLogin/ClientLogin';
            }
            HideLoader();
        }).fail(function (result) {
            console.log(result.Message);
            HideLoader();
        });
    }
    catch (e) {
        console.log(e.message);
        HideLoader();
    }
}

//FUNCTION FOR DELETE CASH PAYMENT
function DeleteBankPaymentOrReceipt(e, checkval) {


    try {
        var checkvall = $('input:radio[name=type1]:checked').val();
        $.confirm({
            title: '',
            content: 'Are You Sure Want To Delete ?',
            type: 'red',
            boxWidth: '300px',
            useBootstrap: false,
            columnClass: 'small',
            containerFluid: true,
            typeAnimated: true,
            buttons: {
                tryAgain: {
                    text: 'Confirm',
                    btnClass: 'btn-red',
                    action: function () {
                        const datastring = {};
                        datastring.BankPaymentUid = parseInt(e);
                        datastring.checkval = checkval;

                        var activeradio = $('input:radio[name=type1]:checked').val();
                        ShowLoader();
                        AjaxSubmission(JSON.stringify(datastring), "/Master/VoucherEntry/DeleteBankPaymentOrReceipt", $('[name="__RequestVerificationToken"]').val()).done(function (data) {
                            let obj = data;
                            if (obj.status == true) {
                                if (obj.responsecode == '102') {
                                    if (activeradio == "ABR") {
                                        Toast(RetrieveMessage(obj.responsecode), "Message", "success");
                                        BankReceiptList(1);
                                        $("#BankReceipt").prop('Checked', true);
                                    }
                                    // if (activeradio == "ABP")
                                    else {
                                        Toast(RetrieveMessage(obj.responsecode), "Message", "success");
                                        BankPaymentList(1);
                                        $("#BankPayment").prop('Checked', true);
                                    }
                                }
                                else {
                                    Toast(RetrieveMessage(obj.responsecode), "Message", "error");
                                }
                            }
                            else {
                                window.location.href = 'ClientLogin/ClientLogin';
                            }
                            HideLoader();
                        }).fail(function (data) {
                            console.log(data.Message);
                            HideLoader();
                        });
                    }
                },
                close: function () {
                }
            }
        });
    }
    catch (e) {
        console.log(e.message);
        HideLoader();
    }
}

//#endregion
//*=======================================  INSERT UPDATE AND DELETE METHODS FOR JOURNAL BOOK  TABLE =================================
//#region
//FUNCTION FOR ADD JOURNAL BOOK
function AddJournalBook() {

    try {
        ma = $('input:radio[name=type]:checked').val();
        const dataString = {};
        dataString.BranchId = $("#Branch").val();
        dataString.VoucherNo = $("#VoucherNo").val();
        dataString.VoucherDate = $("#VoucherDate").val();
        dataString.TotalAmount = $("#TotalAmount").val();
        dataString.chkval = $('input:radio[name=type1]:checked').val();
        dataString.Remarks = $("#Remarks").val();
        dataString.ApproveVoucher = $("#ApproveVoucher").is(":checked");
        dataString.VoucherSerialNo = $("#VoucherSerialNo").val();
        var JBDetail = new Array();
        $("#VoucherEntry_Table tbody tr").each(function () {
            var JournalBookDetail = {};
            JournalBookDetail.LedgerId = $(this).find(".HiddenLedgerId").val();
            JournalBookDetail.AccHead = $(this).find(".AccDescription").val();
            JournalBookDetail.CurrentBalance = $(this).find(".CurBalance").val();
            JournalBookDetail.JobNO = $(this).find(".HiddenJobNo").val();
            JournalBookDetail.Container = $(this).find(".Container").val();
            JournalBookDetail.ReceivingNo = $(this).find(".ReceivingNo").val();
            JournalBookDetail.ReceivingDate = $(this).find(".ReceivingDate").val();
            JournalBookDetail.Particular = $(this).find(".Particular").val();
            JournalBookDetail.BillNo = $(this).find(".BillNo").val();
            JournalBookDetail.TxnType = $(this).find(".Txn ").val();
            JournalBookDetail.Amount = $(this).find(".Amount").val();
            JBDetail.push(JournalBookDetail);
        });
        dataString.journalBookGridListModals = JBDetail;
        ShowLoader();
        AjaxSubmission(JSON.stringify(dataString), "/Master/VoucherEntry/AddJournalBook", $('input[name=__RequestVerificationToken]').val()).done(function (result) {
            let obj = result;
            if (obj.status == true) {
                if (obj.responsecode == '101') {
                    Toast(RetrieveMessage(obj.responsecode), "Message", "success");
                    setTimeout(JournalBookList(1), 500);
                    $("#JournalBookSave").hide();
                    $("#JournalBookUpdate, #VoucherCancel, #VoucherMessage, #VoucherMail, #VoucherPDF, #VoucherDuplicate, #AdjustPayment, #UploadDocument, #FormReset").show();
                    $("#Payment-tab").html("Edit Voucher");
                    $('.ACR, .ACP, .ABR, .ABP').hide();
                    $('.AJB').show();

                    tblCcId = obj.data.Table[0].JournalBookUid;
                    formid = obj.data.Table[0].JournalBookUid;
                    $('#CashPaymentId').val(tblCcId);
                    $("#VocherTimestamp").val(obj.data.Table[0].Timestamp);

                }
                else {
                    Toast(RetrieveMessage(obj.responsecode), "Message", "error");
                }
            }
            else {
                window.location.href = '/ClientLogin/ClientLogin';
            }
            HideLoader();
        }).fail(function (result) {
            console.log(result.Message);
            HideLoader();
        });
    }
    catch (e) {
        console.log(e.message);
        HideLoader();
    }
}

//FUNCTION FOR EDIT  JOURNAL BOOK 
function EditJournalBook(JournalBookUid, checkval) {

    try {
        IsNewVoucher = 1;
        $("#AJB").prop('checked', true);
        $('.AllVoucher').show();
        FillBranchList('Branch');
        if (checkval == 'JB') {
            $('#JournalBookUpdate, #VoucherMessage, #VoucherCancel, #VoucherMail, #VoucherPDF, #VoucherDuplicate, #AdjustPayment, #UploadDocument, #VoucherDelete').show();
            $('.CashPaymentSave').hide();
            $('.AccHead, .ACR, .ABP, .ABR, .ACP').hide();
            $('.AJB').show();

            $(".paymentMethod").html('Journal Book');
        }
        ActionRadioChecked();
        const dataString = {};
        dataString.checkval = checkval;
        dataString.JournalBookUid = parseInt(JournalBookUid);
        ShowLoader();
        AjaxSubmission(JSON.stringify(dataString), "/Master/VoucherEntry/EditJournalBook", $('[name="__RequestVerificationToken"]').val()).done(function (data) {
            let obj = data;
            tblCcId = obj.data.Table1[0].JournalBookUid;
            if (obj.status == true) {
                if (obj.responsecode == '100') {
                    ma = checkval;
                    TabShow();
                    Resetdata();
                    var FirstChild = $("#VoucherEntry_Table").find("tbody tr:first-child");
                    var CPTableData = obj.data.Table2;
                    $.each(CPTableData, function (index, ele) {
                        if (index == 0) {
                            FirstChild.find('.AccDescription').val(ele.AccHead);
                            FirstChild.find('.HiddenGroupId').val(ele.SubgroupHeadUid);
                            FirstChild.find('.GroupName').val(ele.SubgroupHeadName);
                            FirstChild.find('.HiddenLedgerId').val(ele.LedgerId);
                            FirstChild.find('.CurBalance').val(ele.CurrentBalance);
                            FirstChild.find('.Particular').val(ele.Particular);
                            FirstChild.find('.JobNo').val(ele.JobNo);
                            FirstChild.find('.HiddenJobNo').val(ele.jobuid);
                            FirstChild.find('.Container').val(ele.Container);
                            FirstChild.find('.ReceivingNo').val(ele.ReceivingNo);
                            FirstChild.find('.ReceivingDate').val(ele.ReceivingDate);
                            FirstChild.find('.BillNo').val(ele.BillNo);
                            if (ele.TxnType == 'Dr') {
                                FirstChild.find('.Txn').val('Dr').trigger('change');
                            }
                            else if (ele.TxnType == 'Cr') {
                                FirstChild.find('.Txn').val('Cr').trigger('change');
                            }
                            FirstChild.find('.Amount').val(ele.Amount);
                            FirstChild.find('.JobExpence').val(ele.JobExpense);
                        }
                        else {
                            var CloneChild = FirstChild.clone();
                            CloneChild.find('.AccDescription').val('0');
                            CloneChild.find('.HiddenLedgerId,.HiddenGroupId,.GroupName,.CurBalance,.Particular,.JobNo,.HiddenJobNo,.Container,.ReceivingNo,.ReceivingDate,.BillNo,.Amount').val('');
                            CloneChild.find('.AccDescription').val(ele.AccHead);
                            CloneChild.find('.GroupName').val(ele.SubgroupHeadName);
                            CloneChild.find('.HiddenGroupId').val(ele.SubgroupHeadUid);
                            CloneChild.find('.HiddenLedgerId').val(ele.LedgerId);
                            CloneChild.find('.CurBalance').val(ele.CurrentBalance);
                            CloneChild.find('.Particular').val(ele.Particular);
                            CloneChild.find('.JobNo').val(ele.JobNo);
                            CloneChild.find('.HiddenJobNo').val(ele.jobuid);
                            CloneChild.find('.Container').val(ele.Container);
                            CloneChild.find('.ReceivingNo').val(ele.ReceivingNo);
                            CloneChild.find('.ReceivingDate').val(ele.ReceivingDate);
                            CloneChild.find('.BillNo').val(ele.BillNo);
                            if (ele.TxnType == 'Dr') {
                                CloneChild.find('.Txn').val('Dr').trigger('change');
                            }
                            else if (ele.TxnType == 'Cr') {
                                CloneChild.find('.Txn').val('Cr').trigger('change');
                            }
                            CloneChild.find('.Amount').val(ele.Amount);
                            CloneChild.find('.JobExpence').val(ele.JobExpense);
                            $("#VoucherEntry_Table tbody").append(CloneChild);
                        }
                    });
                    formid = obj.data.Table1[0].JournalBookUid;
                    $("#CashPaymentId").val(obj.data.Table1[0].JournalBookUid);
                    $("#VocherTimestamp").val(obj.data.Table1[0].Timestamp);
                    $("#Branch").val(obj.data.Table1[0].BranchId);
                    $("#VoucherNo").val(obj.data.Table1[0].VoucherNo);
                    $("#VoucherDate").val(obj.data.Table1[0].VoucherDate);
                    $("#TotalAmount").val(obj.data.Table1[0].TotalAmount);
                    $("#CreatedByModifiedBy").css('display', 'block');
                    $("#CreatedByModifiedBy").css('width', '100%');
                    $("#Created_UBy").text(obj.data.Table1[0].CreatedBy);
                    $("#CreatedAt").text(obj.data.Table1[0].CreatedAt);
                    $("#ModifiedBy").text(obj.data.Table1[0].LastUpdatedBy);
                    $("#ModifiedAt").text(obj.data.Table1[0].LastUpdatedAt);
                    $("#Remarks").text(obj.data.Table1[0].Remarks);
                    $("#ApproveVoucher").prop('checked', obj.data.Table1[0].ApproveVoucher);
                    $("#VoucherSerialNo").val(obj.data.Table1[0].VoucherSerialNo);
                }
                else {
                    Toast(RetrieveMessage(obj.responsecode), "Message", "error");
                }
            }
            else {
                window.location.href = '/ClientLogin/ClientLogin';
            }
            HideLoader();
        }).fail(function (data) {
            console.log(data.Message);
            HideLoader();
        });
    }
    catch (e) {
        console.log(e.message);
        HideLoader();
    }
}
// UPDATE  CASH PAYMENT BUTTON CLICK
$("#JournalBookUpdate").click(function () {
    var flag = 0;
    var voucherType = $("#JournalBookUpdate")[0].id;
    if (voucherType == "JournalBookUpdate") {
        if ($("#Branch").val() == "0") {
            Toast(RetrieveMessage(910), 'Message', 'error');
            return;
        }
        if ($("#VoucherDate").val() == "") {
            Toast("Please Select Voucher Date !", 'Message', 'error');
            return;
        }

        var debit = 0;
        var credit = 0;
        $("#VoucherEntry_Table tbody tr").each(function (index, ele) {
            if ($(ele).find('.HiddenLedgerId').val().length == 0) {
                Toast(RetrieveMessage(913), 'Message', 'error');
                flag = 1;
                return false;
            }
            if ($(ele).find('.AccDescription').val() == '') {
                Toast(RetrieveMessage(913), 'Message', 'error');
                flag = 1;
                return false;
            }
            if (($(ele).find('.JobExpence').val() > 0) && ($(ele).find('.JobNo ').val() == '') && ($(ele).find('.HiddenJobNo ').val() == '')) {
                Toast("Please Enter Job No !", 'Message', 'error');
                flag = 1;
                return false;
            }
            if ($(ele).find('.Amount').val() == '0.00') {
                Toast("Please Enter Amount !", 'Message', 'error');
                flag = 1;
                return false;
            }
            if ($(ele).find('.Txn').val() == 'Dr')  // Condition For Add Debit Value In JB
            {
                debit = debit + parseFloat($(ele).find('.Amount').val());
            }
            if ($(ele).find('.Txn').val() == 'Cr')  // Condition For Add Credit Value In JB
            {
                credit = credit + parseFloat($(ele).find('.Amount').val());
            }
        });
        if ((debit > credit) || (credit > debit)) {
            Toast("Debit Or Credit Amount Must Be Same !", 'Message', 'error');
            return;
        }
        if (flag == 0) {
            UpdateJournalBook();
        }
    }
});

//FUNCTION FOR UPDATE CASH PAYMENT METHOD
function UpdateJournalBook() {
    try {
        ma = $('input:radio[name=type]:checked').val();
        const dataString = {};
        dataString.BranchId = $("#Branch").val();
        dataString.VoucherNo = $("#VoucherNo").val();
        dataString.VoucherDate = $("#VoucherDate").val();
        dataString.TotalAmount = $("#TotalAmount").val();
        dataString.chkval = $('input:radio[name=type1]:checked').val();
        dataString.JournalBookUid = $("#CashPaymentId").val();
        dataString.timestamp = $("#VocherTimestamp").val();
        dataString.Remarks = $("#Remarks").val();
        dataString.ApproveVoucher = $("#ApproveVoucher").is(":checked");
        dataString.VoucherSerialNo = $("#VoucherSerialNo").val();
        var JBDetail = new Array();
        $("#VoucherEntry_Table tbody tr").each(function () {
            var JournalBookDetail = {};
            JournalBookDetail.LedgerId = $(this).find(".HiddenLedgerId").val();
            JournalBookDetail.AccHead = $(this).find(".AccDescription").val();
            JournalBookDetail.CurrentBalance = $(this).find(".CurBalance").val();
            JournalBookDetail.JobNO = $(this).find(".HiddenJobNo").val();
            JournalBookDetail.Container = $(this).find(".Container").val();
            JournalBookDetail.ReceivingNo = $(this).find(".ReceivingNo").val();
            JournalBookDetail.ReceivingDate = $(this).find(".ReceivingDate").val();
            JournalBookDetail.Particular = $(this).find(".Particular").val();
            JournalBookDetail.BillNo = $(this).find(".BillNo").val();
            JournalBookDetail.TxnType = $(this).find(".Txn ").val();
            JournalBookDetail.Amount = $(this).find(".Amount").val();
            JBDetail.push(JournalBookDetail);
        });
        dataString.journalBookGridListModals = JBDetail;
        ShowLoader();
        AjaxSubmission(JSON.stringify(dataString), "/Master/VoucherEntry/UpdateJournalBook", $('input[name=__RequestVerificationToken]').val()).done(function (result) {
            let obj = result;
            if (obj.status == true) {
                if (obj.responsecode == '107') {
                    Toast(RetrieveMessage(obj.responsecode), "Message", "success");
                    setTimeout(JournalBookList(1), 500);
                    /*   EditJournalBook(obj.data.Table1[0].JournalBookUid, "JB");*/
                    $("#CashPaymentId").val(obj.data.Table[0].JournalBookUid);
                    $("#VocherTimestamp").val(obj.data.Table[0].Timestamp);
                    tblCcId = obj.data.Table[0].JournalBookUid;
                    formid = obj.data.Table[0].JournalBookUid;

                }
                else {
                    Toast(RetrieveMessage(obj.responsecode), "Message", "error");
                }
            }
            else {
                window.location.href = '/ClientLogin/ClientLogin';
            }
            HideLoader();
        }).fail(function (result) {
            console.log(result.Message);
            HideLoader();
        });
    }
    catch (e) {
        console.log(e.message);
        HideLoader();
    }
}

//FUNCTION FOR DELETE CASHPAYMENT AND CASHRECEIPT 
function DeleteJournalBook(e, checkval) {
    try {
        var checkval = $('input:radio[name=type]:checked').val();
        $.confirm({
            title: '',
            content: 'Are You Sure Want To Delete ?',
            type: 'red',
            boxWidth: '300px',
            useBootstrap: false,
            columnClass: 'small',
            containerFluid: true,
            typeAnimated: true,
            buttons: {
                tryAgain: {
                    text: 'Confirm',
                    btnClass: 'btn-red',
                    action: function () {
                        const datastring = {};
                        datastring.JournalBookUid = parseInt(e);
                        datastring.checkval = checkval;
                        ShowLoader();
                        AjaxSubmission(JSON.stringify(datastring), "/Master/VoucherEntry/DeleteJournalBook", $('[name="__RequestVerificationToken"]').val()).done(function (data) {
                            let obj = data;
                            if (obj.status == true) {
                                if (obj.responsecode == '102') {
                                    Toast(RetrieveMessage(obj.responsecode), "Message", "success");
                                    $("#JournalBook").prop('Checked', true);
                                    JournalBookList(1);
                                }
                                else {
                                    Toast(RetrieveMessage(obj.responsecode), "Message", "error");
                                }
                            }
                            else {
                                window.location.href = 'ClientLogin/ClientLogin';
                            }
                            HideLoader();
                        }).fail(function (data) {
                            console.log(data.Message);
                            HideLoader();
                        });
                    }
                },
                close: function () {

                }
            }
        });
    }
    catch (e) {
        console.log(e.message);
        HideLoader();
    }
}

//#endregion
// ==========================================  ALL FUNCTION FOR SENDING EMAIL FOR VOUCHER ENTRY TABLE ============================================================== //
$("#FormReset").click(function () {
    $('#CashPaymentUpdate, #CashReceiptUpdate, #BankPaymentUpdate, #BankReceiptUpdate, #JournalBookUpdate, #AdjustPayment, #UploadDocument, #VoucherCancel, #VoucherMail, #VoucherPDF, #VoucherDuplicate, #VoucherDelete, #VoucherMessage, #FormReset').hide();
    $('.CashPaymentSave').show();
    $("#Payment-tab").html("Add Voucher");
});

//FUNCTION FOR REST INPUT TYPE FIELD
function Resetdata() {
    IsNewVoucher == 0;
    $("#ACP").attr("checked", "checked");
    jQuery("#radio_1").attr('checked', false);
    // Clear individual fields by ID
    $("#Branch, #CashPaymentId, #VoucherSerialNo, #HiddenAccHeadId, #VoucherNo, #AccHead, #ChequeNo, #ChequeDate").val("");
    // Clear fields by class
    $(".AccDescription, .CurBalance, .Particular, .JobNo, .Container, .ReceivingNo, .datepickerAll, .BillNo, .Txn, .Amount, .TotalAmount").val("");
    // Reset the Txn field specifically to "Dr"
    $(".Txn").val("Dr");
    var tbody = $("#VoucherEntry_Table").find("tbody");
    var Tr = $(tbody).find("tr");
    var rowCount = Tr.length;
    if (rowCount > 1) {
        $("#VoucherEntry_Table tbody tr").each(function (index, ele) {
            if (index > 0) {
                $(ele).remove();
            }
            else {
                $(ele).find('.AccDescription, .GroupName, .HiddenGroupId, .CurBalance, .Particular, .JobNo, .Container, .ReceivingNo, .ReceivingDate, .BillNo, .Txn').val('');
                $(ele).find('.Amount').val('0.00');
                $("#VoucherEntry_Table").find("tbody").append(ele);
            }
        });
    }
    else {
        Tr.find('.GroupName, .HiddenGroupId, .AccDescription, .CurBalance, .Particular, .JobNo, .Container, .ReceivingNo, .ReceivingDate, .BillNo, .Txn').val('');
        Tr.find('.Amount').val('0.00');
        $("#VoucherEntry_Table").find("tbody").append(Tr);
    }
};

//FUCNTION FOR TAB SHOW
function TabShow() {
    $('#Payment_list-tab').removeClass('active');
    $('#Payment-tab').addClass('active');
    $('#Payment_list').removeClass('active show');
    $('#Payment').addClass('active show');
    $("#Payment-tab").html("Edit Voucher");
}

//FUNCTION FOR TAB HIDE
function TabHide() {
    $('#Payment-tab').removeClass('active');
    $('#Payment_list-tab').addClass('active ');
    $('#Payment_list').addClass('active show');
    $('#Payment').removeClass('active show');
    $(".CashPaymentSave").show();
    $("#Payment-tab").html("Add Voucher");
    $('.ACR').show();
    $('.ABP').show();
    $('.ABR').show();
    $('.ACP').show();
    $('.AJB').show();
    $("#ACP").attr("checked", "checked");
    if ($("#Payment-tab").html() == "Add Voucher") {
        $(".paymentMethod").html('Cash Payment');
        $('#voucherentrycolor').css("background-color", "#89a9f4");
        $('.CashPaymentSave').attr('id', 'CashPaymentSave');
        $(".Branch").show();
        $(".VoucherNo").show();
        $(".VoucherDate").show();
        $(".AccHead").show();
    }
}

//MENU LIST TAB CLICKED
$("#Payment_list-tab").click(function () {
    Resetdata();
    $("#CP").attr("checked", "checked");
    TabHide();
    $('#CashPaymentUpdate').hide();
    $('#CashReceiptUpdate').hide();
    $('#BankPaymentUpdate').hide();
    $('#BankReceiptUpdate').hide();
    $('#JournalBookUpdate').hide();
    $('#FormReset').hide();
})


$("#Branch").change(function () {
    GenerateVoucherNo();
});





$("#Payment-tab").click(function () {
    Resetdata();
    var tbody = $("#VoucherEntry_Table").find("tbody");
    var FirstTr = $(tbody).find("tr:first");
    FirstTr.find('.Txn').val('Dr');
    $('.AllVoucher').hide();
    IsNewVoucher = 0;
    $("#ACP").prop('checked', true).trigger('change');
    if ($("#Payment-tab").html() == "Add Voucher") {
        FillBranchList('Branch');
        // Set datepicker fields to today's date
        $(".datepickerAll1").datepicker('setDate', 'today');

        // Hide specific elements
        $('#VoucherMessage, #CashReceiptUpdate, #CashPaymentUpdate, #BankReceiptUpdate, #BankPaymentUpdate, #JournalBookUpdate, #AdjustPayment, #UploadDocument, #VoucherCancel, #VoucherMail, #VoucherPDF, #VoucherDuplicate, #VoucherDelete').hide();
        // Update HTML content and styles
        $(".paymentMethod").html('Cash Payment');
        $('#voucherentrycolor').css("background-color", "#89a9f4");

        // Set attributes and show/hide specific elements
        $('.CashPaymentSave').attr('id', 'CashPaymentSave');
        $(".Branch, .VoucherNo, .VoucherDate, .AccHead").show();
        $(".ChequeNo, .ChequeDate").hide();

        // Set specific values
        $(".Txn").val('Dr');
    }
    $("#CreatedByModifiedBy").css('display', 'None');
    $("#CreatedByModifiedBy").css('width', '100%');
    GenerateVoucherNo();
});
// FUNCTION FOR ADD NEW ROW ON BLUR IN JOURNAL BOOK 
function JournalBookVoucherValidate(e) {
    var debit = 0;
    var credit = 0;
    var flag = 0;
    var amount = $(e).val();
    var checkval = $('input:radio[name=type1]:checked').val();
    $("#VoucherEntry_Table tbody tr").each(function (index, ele) {
        if ($(ele).find('.Txn').val() == 'Dr')
            debit = debit + parseFloat($(ele).find('.Amount').val());
        if ($(ele).find('.Txn').val() == 'Cr')
            credit = credit + parseFloat($(ele).find('.Amount').val());
    });
    if ($('.Amount').val() == '0.00') {
        flag = 1;
        return false;
    }
    var tabhtml = $("#Payment-tab").html();
    var JbUpdateVal = $(".JournalBookUpdate")[0].id;
    if ((checkval == "AJB") && (debit != credit)) {
        var amount1 = debit - credit;
        var parentTr = $(e).parents('tr');
        if (checkval == "AJB") {
            var txn = parentTr.find(".Txn").val();
            $("#RemoveVoucherPayment").removeAttr('disabled');
            var tbody = $("#VoucherEntry_Table").find("tbody");
            var FirstTr = $(tbody).find("tr:first");
            FirstTr.find('.ReceivingDate').datepicker("destroy");
            FirstTr.find('.ReceivingDate').removeAttr("id");
            var NewRow = $(FirstTr).clone();
            NewRow.find('.HiddenLedgerId').val('');
            NewRow.find('.AccDescription').val('');
            NewRow.find('.GroupName').val('');
            NewRow.find('.AddLedger').val('');
            NewRow.find('.CurBalance').val('');
            NewRow.find('.Particular').val('');
            NewRow.find('.BillNo').val('');
            if (debit > credit) {
                NewRow.find('.Txn').val('Cr');
                NewRow.find('.Amount').val(amount1.toFixed(2));
            }
            else if (debit < credit) {
                NewRow.find('.Txn').val('Dr');
                NewRow.find('.Amount').val(Math.abs(amount1.toFixed(2)));
            }
            NewRow.find('.RemoveVoucherPayment').val('');
            NewRow.find('.ReceivingDate').val('');
            NewRow.find('.ReceivingNo').val('');
            NewRow.find('.Container').val('');
            NewRow.find('.JobNo').val('');
            $("#VoucherEntry_Table").find("tbody").append(NewRow);
            var LastTr = $(tbody).find("tr:last");
            //    LastTr.find('.AccDescription').focus();
            LastTr.find('.GroupName').focus();
            LedgerAccHeadautocompleteCashPaymentList();
            $(".datepickerAll1").datepicker({
                changeMonth: true,
                changeYear: true,
                dateFormat: 'dd/mm/yy'
            });
            /*  $(".datepickerAll1").datepicker('setDate', 'today');*/
        }
        $("#TotalAmount").val(debit.toFixed(2));
    }
}

function DebitCreditOnChangeFunction(e) {
    var debit = 0;
    var credit = 0;
    var flag = 0;
    var amount = $(e).val()
    $("#TotalAmount").val(amount);
    var checkval = $('input:radio[name=type1]:checked').val();
    if ((checkval == "ACP") || (checkval == "ABP")) {
        $("#VoucherEntry_Table tbody tr").each(function (index, ele) {
            if ($(ele).find('.Txn').val() == 'Dr') {
                debit = debit + parseFloat($(ele).find('.Amount').val());
            }
            if ($(ele).find('.Txn').val() == 'Cr') {
                credit = credit + parseFloat($(ele).find('.Amount').val());
            }
        });
        var amount1 = debit - credit;
        $("#TotalAmount").val(amount1);
    }
    else if ((checkval == "ACR") || (checkval == "ABR")) {
        $("#VoucherEntry_Table tbody tr").each(function (index, ele) {
            if ($(ele).find('.Txn').val() == 'Dr') {
                debit = debit + parseFloat($(ele).find('.Amount').val());
            }
            if ($(ele).find('.Txn').val() == 'Cr') {
                credit = credit + parseFloat($(ele).find('.Amount').val());
            }
        });
        var amount1 = credit - debit;
        $("#TotalAmount").val(amount1);
    }
    else if (checkval == "AJB") {
        $("#VoucherEntry_Table tbody tr").each(function (index, ele) {
            if ($(ele).find('.Txn').val() == 'Dr') {
                debit = debit + parseFloat($(ele).find('.Amount').val());
            }
            if ($(ele).find('.Txn').val() == 'Cr') {
                credit = credit + parseFloat($(ele).find('.Amount').val());
            }
        });
        var amount1 = debit - credit;
        $("#TotalAmount").val(debit);
    }
};

//*Ledger Modal open Code 
$(".AddMoreLedger").click(function () {
    FillGroup('ModalLedgerGroup');
    FillByDefaultCountry();
    FillCountryList('ModalCountry');
});


$("#VoucherDuplicate").click(function () {
    // Hide all voucher-related elements and reset specific fields
    $('.AllVoucher, #CashPaymentUpdate, #CashReceiptUpdate, #BankPaymentUpdate, #BankReceiptUpdate, #JournalBookUpdate, #VoucherMessage, #VoucherCancel, #VoucherMail, #VoucherPDF, #AdjustPayment, #UploadDocument, #VoucherDuplicate, #VoucherDelete').hide();

    $("#VoucherNo, #CashPaymentId").val("");
    $(".CashPaymentSave").show();
    $("#Payment-tab").html("Add Voucher");
    $("#CreatedByModifiedBy").css('display', 'none');

    // Set the id attribute based on the selected radio button value
    var type = $('input:radio[name=type1]:checked').val();
    switch (type) {
        case "ACR":
            $('.CashPaymentSave').attr('id', 'CashReceiptSave');
            break;
        case "ACP":
            $('.CashPaymentSave').attr('id', 'CashPaymentSave');
            break;
        case "ABP":
            $('.CashPaymentSave').attr('id', 'BankPaymentSave');
            break;
        case "ABR":
            $('.CashPaymentSave').attr('id', 'BankReceiptSave');
            break;
        case "AJB":
            $('.CashPaymentSave').attr('id', 'JournalBookSave');
            break;
    }
});
$("#VoucherDelete").click(function () {
    var checkval = $('input:radio[name=type1]:checked').val();
    if (checkval == "ACR") {
        DeleteCashPaymentOrCashReceipt($("#CashPaymentUid").val(), 'CR')
    }
    else if (checkval == "ACP") {
        DeleteCashPaymentOrCashReceipt($("#CashPaymentUid").val(), 'CP')
    }
    else if (checkval == "ABP") {
        DeleteCashPaymentOrCashReceipt($("#CashPaymentUid").val(), 'BP')
    }
    else if (checkval == "ABR") {
        DeleteCashPaymentOrCashReceipt($("#CashPaymentUid").val(), 'BR')
    }
    else if (checkval == "AJB") {
        DeleteCashPaymentOrCashReceipt($("#CashPaymentUid").val(), 'JB')
    }
});


$("#VoucherPDF").click(function () {
    if ($("#CashPaymentId").val() != '') {
        var CheckVal = ma;
        DownloadVoucherReport($("#CashPaymentId").val(), CheckVal);
    }
});

function DownloadVoucherReport(VoucherId, CheckVal) {
    try {
        const datastring = {};
        datastring.VoucherId = VoucherId;
        datastring.checkval = CheckVal;
        AjaxSubmission(JSON.stringify(datastring), "/Master/VoucherEntry/DownloadVoucherReport", $('input[name=__RequestVerificationToken]').val()).done(function (result) {
            let obj = result;
            if (obj.status == true) {
                if (obj.responsecode == '100') {
                    window.open($("#VoucherReportPdf").attr('href'), '_blank');
                }
                else {
                    Toast(RetrieveMessage(obj.responsecode), "Message", "error");
                }
            }
            else {
                window.location.href = '/ClientLogin/ClientLogin';
            }
        }).fail(function (result) {
            console.log(result.Message);
        });
    }
    catch (e) {
    }
}

function GetMailShortcut() {
    try {
        var CheckVal = ma;
        const datastring = {};
        datastring.VoucherId = tblCcId;
        datastring.CheckVal = CheckVal;
        ShowLoader();
        AjaxSubmission(JSON.stringify(datastring), "/Master/VoucherEntry/GetMailShortcut", $('[name="__RequestVerificationToken"]').val()).done(function (data) {
            let obj = data;
            if (obj.status == true) {
                if (obj.responsecode == '100') {
                    EmailModal.style.display = "block";
                    $("#EmailTo").val(obj.data.EmailData[0].EmailTo);
                    $("#AttachFileName").text(obj.data.FileDetails[0].FileName);
                    $("#AttachedFilePath").val(obj.data.FileDetails[0].AttachmentFilePath);
                    $("#AttachFileName").attr("href", obj.data.FileDetails[0].FilePath);
                    $("#RefId").val(tblCcId);
                    $("#SendToName").val(obj.data.EmailData[0].SendTo);
                    $("#RefName").val('VoucherEntry');
                    BindTemplateName('AllTemplate', 'Email');
                    FillTemplateDataInTincyMce($('#CashPaymentId').val(), TemplateFor, null, 'Email');
                }
                else if (obj.responsecode == "1046")
                    Toast(RetrieveMessage(obj.responsecode), 'Message', 'error');
            }
            else
                Toast(RetrieveMessage(obj.responsecode), "Message", "error");
            HideLoader();
        }).fail(function (result) {
            console.log(result.Message);
            HideLoader();
        });
    }
    catch (e) {
        console.log(e.message);
        HideLoader();
    }
}

var modal2 = document.getElementById("VoucherSmsModal");
var modal1 = document.getElementById("VoucherErrorModal");

// FUNCTION FOR VOUCHER EMAIL CLICK 
function VoucherEmailClick() {
    GetMailShortcut();
}

//FUNCTION FOR GO TO LEDGER
function GoToLedger(e) {
    SetCookie('LedgerId', $("#" + e).val(), 's', 50);
}

//FUNCTION FOR GO TO LEDGER FOR CLASS
function GoToLedgerForClass(e, ClsName) {
    SetCookie('LedgerId', $(e).parent().parent().find('.' + ClsName).val(), 's', 50);
}

//FUNCTION FOR CHANGE TEMPLATE DETAILS
function TemplateChange() {
    tinymce.get("EmailBody").setContent('');
    $('#Subject').val('');
    if ($('#AllTemplate').val() != null && $('#AllTemplate') != undefined) {
        if ($('#AllTemplate').val() != 0)
            FillTemplateDataInTincyMce($('#CashPaymentId').val(), TemplateFor, $('#AllTemplate').val(), 'Email');
    }
}

$("#AdjustPayment").click(function () {
    ResetDataBillAdjModal();
    AdjustPayment();
});

function AdjustPayment() {
    try {
        var CheckVal = ma;
        const datastring = {};
        datastring.LedgerId = $('#HiddenLedgerId').val();
        datastring.CheckVal = CheckVal;
        datastring.VoucherId = tblCcId;
        ShowLoader();
        AjaxSubmission(JSON.stringify(datastring), "/Master/VoucherEntry/AdjustPayment", $('[name="__RequestVerificationToken"]').val()).done(function (data) {
            let obj = data;
            if (obj.status == true) {
                if (obj.responsecode == '100') {
                    BillAdjustMentModal.style.display = "block";
                    $("#RefAccHead").val(obj.data.Table[0].RefDescription);
                    $("#MdlParticular").val(obj.data.Table[0].Particular);
                    $("#modalParty").val(obj.data.Table[0].Party);
                    $("#ModalPartyUid").val(obj.data.Table[0].LedgerUid);
                    $("#modalBillAmount").val(obj.data.Table[0].TotalAmount);
                    $("#modalUnderGroup").val(obj.data.Table[0].SubgroupHeadUid).trigger('change');
                    $("#modalVoucherDate").val(obj.data.Table[0].VoucherDate);
                    $("#modalVoucherNo").val(obj.data.Table[0].VoucherNumber);
                    $("#ModalFinancialYear").val(obj.data.Table[0].FinyrId);
                    $("#ModalTrUid").val(obj.data.Table[0].TrUid);
                    $("#ModalRefUid").val(obj.data.Table2[0].BillNoUniqueId);
                    $("#modalBalAmount").val(obj.data.Table[0].BalanceAmount.toFixed(2));

                    //var BillAmount = obj.data.Table[0].TotalAmount
                    //var BalanceAmount = obj.data.Table1[0].AdjustedAmount
                    //var modalBalAmount = (BillAmount - BalanceAmount);
                    /* $("#modalBalAmount").val(modalBalAmount.toFixed(2));*/

                    EditBillAdjustMent();
                }
                else {
                    Toast(RetrieveMessage(obj.responsecode), "Message", "error");
                }
            }
            else {
                Toast(RetrieveMessage(obj.responsecode), "Message", "error");
            }
            HideLoader();
        }).fail(function (result) {
            console.log(result.Message);
            HideLoader();
        });
    }
    catch (e) {
        console.log(e.message);
        HideLoader();
    }
}


document.addEventListener("keydown", function (zEvent) {
    if (zEvent.ctrlKey && zEvent.altKey && (zEvent.key == "c" || zEvent.key == "C")) {  // case sensitive
        // Activate the Payment tab and deactivate the Payment list tab
        $('#Payment_list-tab, #Payment_list').removeClass('active');
        $('#Payment-tab, #Payment').addClass('active show');

        // Show and hide relevant elements
        $(".CashPaymentSave").show();
        $("#Payment-tab").html("Add Voucher");
        $('.ACR, .ABP, .ABR, .ACP, .AJB').show();
        $("#ACP").prop("checked", true); // Use prop for setting checked attribute

        // Reset data and hide specific elements
        Resetdata();
        $('#CashPaymentUpdate, #CashReceiptUpdate, #BankPaymentUpdate, #BankReceiptUpdate, #JournalBookUpdate, #AdjustPayment, #UploadDocument, #VoucherCancel, #VoucherMail, #VoucherPDF, #VoucherDuplicate, #VoucherDelete, #VoucherMessage, #CreatedByModifiedBy').hide();
        ActionRadioChecked();
    }

    if (zEvent.ctrlKey && zEvent.altKey && (zEvent.key == "k" || zEvent.key == "K")) // case sensitive
    {
        // Activate the Payment tab and deactivate the Payment list tab
        $('#Payment_list-tab, #Payment_list').removeClass('active');
        $('#Payment-tab, #Payment').addClass('active show');

        // Show specific elements
        $(".CashPaymentSave").show();
        $("#Payment-tab").html("Add Voucher");
        $('.ACR, .ABP, .ABR, .ACP, .AJB').show();

        // Set the ACR radio button to checked
        $("#ACR").prop("checked", true);

        // Hide specific elements
        $('#CashPaymentUpdate, #CashReceiptUpdate, #BankPaymentUpdate, #BankReceiptUpdate, #JournalBookUpdate, #AdjustPayment, #UploadDocument, #VoucherCancel, #VoucherMail, #VoucherPDF, #VoucherDuplicate, #VoucherDelete, #VoucherMessage, #CreatedByModifiedBy').hide();

        // Reset additional data
        Resetdata();
        ActionRadioChecked();
    }

    if (zEvent.ctrlKey && zEvent.altKey && (zEvent.key == "b" || zEvent.key == "B")) // case sensitive
    {
        // Deactivate Payment list tab and activate Payment tab
        $('#Payment_list-tab, #Payment_list').removeClass('active');
        $('#Payment-tab, #Payment').addClass('active show');

        // Show specific elements
        $(".CashPaymentSave").show();
        $("#Payment-tab").html("Add Voucher");
        $('.ACR, .ABP, .ABR, .ACP, .AJB').show();

        // Set the ABP radio button to checked
        $("#ABP").prop("checked", true);

        // Hide specific elements
        $('#CashPaymentUpdate, #CashReceiptUpdate, #BankPaymentUpdate, #BankReceiptUpdate, #JournalBookUpdate, #AdjustPayment, #UploadDocument, #VoucherCancel, #VoucherMail, #VoucherPDF, #VoucherDuplicate, #VoucherDelete, #VoucherMessage, #CreatedByModifiedBy').hide();

        // Reset additional data
        Resetdata();
        ActionRadioChecked();
    }

    if (zEvent.ctrlKey && zEvent.altKey && (zEvent.key == "r" || zEvent.key == "R")) // case sensitive
    {
        // Remove active class from Payment list tab and activate Payment tab
        $('#Payment_list-tab, #Payment_list').removeClass('active');
        $('#Payment-tab, #Payment').addClass('active show');

        // Show specific elements
        $(".CashPaymentSave").show();
        $("#Payment-tab").html("Add Voucher");
        $('.ACR, .ABP, .ABR, .ACP, .AJB').show();

        // Set the ABR radio button to checked
        $("#ABR").prop("checked", true);

        // Hide specific elements
        $('#CashPaymentUpdate, #CashReceiptUpdate, #BankPaymentUpdate, #BankReceiptUpdate, #JournalBookUpdate, #AdjustPayment, #UploadDocument, #VoucherCancel, #VoucherMail, #VoucherPDF, #VoucherDuplicate, #VoucherDelete, #VoucherMessage, #CreatedByModifiedBy').hide();

        // Reset additional data
        Resetdata();
        ActionRadioChecked();
    }

    if (zEvent.ctrlKey && zEvent.altKey && (zEvent.key == "j" || zEvent.key == "J")) // case sensitive
    {
        // Activate the Payment tab and deactivate the Payment list tab
        $('#Payment_list-tab, #Payment_list').removeClass('active');
        $('#Payment-tab, #Payment').addClass('active show');

        // Show specific elements
        $(".CashPaymentSave").show();
        $("#Payment-tab").html("Add Voucher");
        $('.ACR, .ABP, .ABR, .ACP, .AJB').show();

        // Set the AJB radio button to checked
        $("#AJB").prop("checked", true);

        // Hide specific elements
        $('#CashPaymentUpdate, #CashReceiptUpdate, #BankPaymentUpdate, #BankReceiptUpdate, #JournalBookUpdate, #AdjustPayment, #UploadDocument, #VoucherCancel, #VoucherMail, #VoucherPDF, #VoucherDuplicate, #VoucherDelete, #VoucherMessage, #CreatedByModifiedBy').hide();

        // Reset additional data
        Resetdata();
        ActionRadioChecked();
    }
    if (zEvent.ctrlKey && zEvent.altKey && (zEvent.key == "f1" || zEvent.key == "F1")) {  // case sensitive
        $('#Payment-tab').removeClass('active');
        $('#Payment_list-tab').addClass('active ');
        $('#Payment_list').addClass('active show');
        $('#Payment').removeClass('active show');
        Resetdata();
        $("#CashReceipt").attr("checked", "checked");
        $("#ACR").attr("checked", "checked");
        $(".CR").css("background-color", "hsl(212deg 62% 49%)");
        $(".CP").css("background-color", "#4299e1");
        $(".BP").css("background-color", "#4299e1");
        $(".BR").css("background-color", "#4299e1");
        $(".JB").css("background-color", "#4299e1");

        $("#tbl_CashPayment").hide();
        $("#tbl_CashReceipt").show();
        $("#tbl_BankPayment").hide();
        $("#tbl_BankReceipt").hide();
        $("#tbl_JournalBook").hide();
        CashReceiptList(1);
    }

    if (zEvent.ctrlKey && zEvent.altKey && (zEvent.key == "f2" || zEvent.key == "F2")) {  // case sensitive
        $('#Payment-tab').removeClass('active');
        $('#Payment_list-tab').addClass('active ');
        $('#Payment_list').addClass('active show');
        $('#Payment').removeClass('active show');
        Resetdata();
        $("#BankPayment").attr("checked", "checked");
        /*$("#ABP").attr("checked", "checked");*/
        $(".BP").css("background-color", "hsl(212deg 62% 49%)");
        $(".CP").css("background-color", "#4299e1");
        $(".CR").css("background-color", "#4299e1");
        $(".BR").css("background-color", "#4299e1");
        $(".JB").css("background-color", "#4299e1");
        $("#tbl_CashPayment").hide();
        $("#tbl_CashReceipt").hide();
        $("#tbl_BankPayment").show();
        $("#tbl_BankReceipt").hide();
        $("#tbl_JournalBook").hide();
        BankPaymentList(1);
    }

    if (zEvent.ctrlKey && zEvent.altKey && (zEvent.key == "f3" || zEvent.key == "F3")) {  // case sensitive
        $('#Payment-tab').removeClass('active');
        $('#Payment_list-tab').addClass('active ');
        $('#Payment_list').addClass('active show');
        $('#Payment').removeClass('active show');
        Resetdata();
        $("#BankReceipt").attr("checked", "checked");
        $("#ABR").attr("checked", "checked");
        $(".BR").css("background-color", "hsl(212deg 62% 49%)");
        $(".CP").css("background-color", "#4299e1");
        $(".CR").css("background-color", "#4299e1");
        $(".BP").css("background-color", "#4299e1");
        $(".JB").css("background-color", "#4299e1");
        $("#tbl_CashPayment").hide();
        $("#tbl_CashReceipt").hide();
        $("#tbl_BankPayment").hide();
        $("#tbl_BankReceipt").show();
        $("#tbl_JournalBook").hide();
        BankReceiptList(1);
    }

    if (zEvent.ctrlKey && zEvent.altKey && (zEvent.key == "f4" || zEvent.key == "F4")) {  // case sensitive
        $('#Payment-tab').removeClass('active');
        $('#Payment_list-tab').addClass('active ');
        $('#Payment_list').addClass('active show');
        $('#Payment').removeClass('active show');
        Resetdata();
        $("#JournalBook").attr("checked", "checked");
        $("#AJB").attr("checked", "checked");
        $(".JB").css("background-color", "hsl(212deg 62% 49%)");
        $(".CP").css("background-color", "#4299e1");
        $(".CR").css("background-color", "#4299e1");
        $(".BR").css("background-color", "#4299e1");
        $(".BP").css("background-color", "#4299e1");
        $("#tbl_CashPayment").hide();
        $("#tbl_CashReceipt").hide();
        $("#tbl_BankPayment").hide();
        $("#tbl_BankReceipt").hide();
        $("#tbl_JournalBook").show();
        JournalBookList(1);
    }
    if (zEvent.ctrlKey && zEvent.altKey && (zEvent.key == "f6" || zEvent.key == "F6")) {  // case sensitive
        $('#Payment-tab').removeClass('active');
        $('#Payment_list-tab').addClass('active ');
        $('#Payment_list').addClass('active show');
        $('#Payment').removeClass('active show');
        Resetdata();
        $("#CashPayment").attr("checked", "checked");
        $("#ACP").attr("checked", "checked");
        $(".CP").css("background-color", "hsl(212deg 62% 49%)");
        $(".JB").css("background-color", "#4299e1");
        $(".CR").css("background-color", "#4299e1");
        $(".BR").css("background-color", "#4299e1");
        $(".BP").css("background-color", "#4299e1");

        $("#tbl_CashPayment").show();
        $("#tbl_CashReceipt").hide();
        $("#tbl_BankPayment").hide();
        $("#tbl_BankReceipt").hide();
        $("#tbl_JournalBook").hide();
        CashPaymentList(1);
    }
});


//DOCUMENT UPLOAD ON CLICK FUNCTION
$("#UploadDocument").click(function () {
    DocUploadResetdata();
    CommonFormList('VoucherDocUpload LDU INNER JOIN document_type_master DTM ON DTM.doc_type_uid =LDU.DocTypeUid ', 'ldu.DocUploadUId, DTM.doc_type, LDU.FilePath,ldu.VoucherID', 'FilePath');
});



function GenerateVoucherNo() {
    try {
        let a = setInterval(() => {
            if ($("#Branch").val() != "") {
                var BranchId = $("#Branch").val();
                var VoucherDate = $("#VoucherDate").val();
                var BookType = $('input:radio[name=type1]:checked').val();
                const dataString = {};
                dataString.BranchId = BranchId;
                dataString.BookType = BookType;
                dataString.VoucherDate = VoucherDate;
                AjaxSubmission(JSON.stringify(dataString), '/Master/VoucherEntry/GenerateVoucherNo', $('[name="__RequestVerificationToken"]').val()).done(function (result) {
                    let obj = result;
                    if (obj.status == true) {
                        $("#VoucherNo").val(obj.data.Table[0].Sub_Voucher_No);
                        $("#VoucherSerialNo").val(obj.data.Table[0].VoucherNo);
                    }
                    else
                        window.location.href = '/ClientLogin/ClientLogin';
                }).fail(function (result) {
                    console.log(result.message);
                });
                clearInterval(a);
            }
        }, 100);
    }
    catch (e) {
        console.log(e.message);
    }
};


//FUNCTION FOR EXPORT DATA IN EXCEL
function FormExcel() {
    ShowLoader();
    let SearchType = $('#ApproveVoucherValueFill').html();
    let date = new Date();
    let NewDate = ("00" + date.getDate()).slice(-2) + "_" + ("00" + (date.getMonth() + 1)).slice(-2) + "_" + date.getFullYear() + "_" + ("00" + date.getHours()).slice(-2) + "_" + ("00" + date.getMinutes()).slice(-2) + "_" + ("00" + date.getSeconds()).slice(-2);
    let fileName = SearchType + "_" + NewDate + ".xlsx";

    $('#FormSearch').trigger('click');
    AjaxSubmission(null, '/Master/VoucherEntry/FormExcel', $('input[name=__RequestVerificationToken]').val()).done(function (result) {
        let obj = result;
        if (obj.status == true) {
            if (obj.responsecode == '100') {

                let bytes = Base64ToBytes(obj.data.FileData[0].Base64Data);
                let blob = new Blob([bytes], { type: "application/octetstream" });
                let isIE = false || !!document.documentMode;
                if (isIE) {
                    window.navigator.msSaveBlob(blob, fileName);
                } else {
                    let url = window.URL || window.webkitURL;
                    link = url.createObjectURL(blob);
                    let a = $("<a />");
                    a.attr("download", fileName);
                    a.attr("href", link);
                    $("body").append(a);
                    a[0].click();
                    $("body").remove(a);
                }
            }
            else if (obj.responsecode == '302')
                Toast('No Records found.', 'Message', 'success');
            else
                Toast(RetrieveMessage(obj.responsecode), 'Message', 'error');

        } else
            window.location.href = '/ClientLogin/ClientLogin';
        HideLoader();

    }).fail(function (result) {
        console.log(result.Message);
        HideLoader();
    });
}

