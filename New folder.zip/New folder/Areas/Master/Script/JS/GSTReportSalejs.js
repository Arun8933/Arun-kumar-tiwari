﻿$(document).ready(function () {
    FillPageSizeList('ddlPageSize');

    //$("#BillType").select2({
    //    multiple: true,
    //    width: '100%'
    //});
    /*$(".selectpicker").selectpicker();*/
    $(".datepickerAll").datepicker({
        changeMonth: true,
        changeYear: true,
        dateFormat: 'dd/mm/yy',
        toolbarPlacement: "bottom",
        showButtonPanel: true,
    });
    //GetFinancialYearDate('BillDateFrom', 'BillDateTo');
    FillBillType();
    LoadTinyMCE();
    FillBranchList('BranchIdSearch', false);

    var now = new Date();
    var prevMonthLastDate = new Date(now.getFullYear(), now.getMonth(), 0);
    var prevMonthFirstDate = new Date(now.getFullYear() - (now.getMonth() > 0 ? 0 : 1), (now.getMonth() - 1 + 12) % 12, 1);

    var formatDateComponent = function (dateComponent) {
        return (dateComponent < 10 ? '0' : '') + dateComponent;
    };

    var formatDate = function (date) {
        return formatDateComponent(date.getDate()) + '/' + formatDateComponent(date.getMonth() + 1) + '/' + date.getFullYear();

    };

    $("#BillDateFrom").val(formatDate(prevMonthFirstDate));
    $("#BillDateTo").val(formatDate(prevMonthLastDate));
});
//FUNCTION FOR GET FINANCIAL YEAR DATE
function GetFinancialYearDate(start, end) {
    try {
        AjaxSubmission(null, '/Master/_Layout/GetFinancialYearDate', $('[name="__RequestVerificationToken"]').val()).done(function (result) {
            let obj = result;

            if (obj.status == true) {
                if (obj.responsecode == '100') {
                    $("#" + start).val(obj.data.Table[0].finyr_start_date);
                    $("#" + end).val(obj.data.Table[0].finyr_end_date);
                }
            }
            else
                window.location.href = '/ClientLogin/ClientLogin';
            //Hideloader();

        }).fail(function (result) {
            //Hideloader();
            console.log(result.message);

        });
        //Hideloader();
    }
    catch (e) {
        //Hideloader();
        console.log(e.message);
    }
}
//FUNCTION FOR TINYMCE EDITIOR
function LoadTinyMCE() {
    tinymce.init({
        selector: ".tinymce",
        branding: false,
        theme: "modern",
        skin: "lightgray",
        width: "100%",
        height: 250,
        statubar: true,
        plugins: [
            "advlist autolink link image lists charmap print preview hr anchor pagebreak",
            "searchreplace wordcount visualblocks visualchars code fullscreen insertdatetime media nonbreaking",
            "save table contextmenu directionality emoticons template paste textcolor"
        ],
        toolbar: "insertfile undo redo | styleselect | bold italic | alignleft aligncenter alignright alignjustify | bullist numlist outdent indent | link | fontsizeselect | fontselect | image | print preview media fullpage | forecolor backcolor emoticons ",
        style_formats: [
            {
                title: "Headers", items: [
                    { title: "Header 1", format: "h1" },
                    { title: "Header 2", format: "h2" },
                    { title: "Header 3", format: "h3" },
                    { title: "Header 4", format: "h4" },
                    { title: "Header 5", format: "h5" },
                    { title: "Header 6", format: "h6" }
                ]
            },
            {
                title: "Inline", items: [
                    { title: "Bold", icon: "bold", format: "bold" },
                    { title: "Italic", icon: "italic", format: "italic" },
                    { title: "Underline", icon: "underline", format: "underline" },
                    { title: "Strikethrough", icon: "strikethrough", format: "strikethrough" },
                    { title: "Superscript", icon: "superscript", format: "superscript" },
                    { title: "Subscript", icon: "subscript", format: "subscript" },
                    { title: "Code", icon: "code", format: "code" }
                ]
            },
            {
                title: "Blocks", items: [
                    { title: "Paragraph", format: "p" },
                    { title: "Blockquote", format: "blockquote" },
                    { title: "Div", format: "div" },
                    { title: "Pre", format: "pre" }
                ]
            },
            {
                title: "Alignment", items: [
                    { title: "Left", icon: "alignleft", format: "alignleft" },
                    { title: "Center", icon: "aligncenter", format: "aligncenter" },
                    { title: "Right", icon: "alignright", format: "alignright" },
                    { title: "Justify", icon: "alignjustify", format: "alignjustify" }
                ]
            }
        ],
    });
}

//FUNCTION FOR GET FORM LIST DATA
function GetGstReport(PageIndex) {
    try {

        const dataString = {};
        dataString.PageSize = $("#ddlPageSize").val();
        dataString.PageIndex = PageIndex;
        dataString.OrderBy = $("#sort-column").val().trim() + " " + $("#sort-type").val().trim();
        dataString.ImporterName = $("#HiddenImporterName").val();
        dataString.BillDateFrom = $("#BillDateFrom").val();
        dataString.BillDateTo = $("#BillDateTo").val();
        dataString.BranchIdSearch = $("#BranchIdSearch").val();
        dataString.CheckExcel = $("#CheckExcel").val();
        dataString.BillType = $("#BillType").val();

        AjaxSubmission(JSON.stringify(dataString), '/Master/GSTReportSale/FormList', $('input[name=__RequestVerificationToken]').val()).done(function (result) {
            let obj = result;
            if (obj.status == true) {
                if (obj.responsecode == '100') {
                    $("#divTblGstReportSale").show();
                    $("#TblGstReportSale").html('');
                    $("#TblGstReportSale").html(obj.data.HtmlData[0].TableHtmlData);
                    $(".pagination").BindPaging({
                        ActiveCssClass: "current",
                        PagerCssClass: "pager",
                        PageIndex: parseInt(obj.data.Table1[0].PageIndex),
                        PageSize: parseInt(obj.data.Table1[0].PageSize),
                        RecordCount: parseInt(obj.data.Table1[0].count)
                    });
                }
                else
                    Toast(RetrieveMessage(obj.responsecode), 'Message', 'error');

            } else
                window.location.href = '/ClientLogin/ClientLogin';
            //HideLoader();

        }).fail(function (result) {
            console.log(result.Message);
            //HideLoader();
        });
    }
    catch (e) {
        console.log(e.message);
        //HideLoader();
    }
}
$("#Search").click(function () {
    if ($("#BillDateFrom").val().length == 0) {
        Toast('Please Enter Bill From Date !', 'Message', 'error');
        return;
    }
    if ($("#BillDateTo").val().length == 0) {
        Toast('Please Enter Bill To Date !', 'Message', 'error');
        return;
    }
    $("#CheckExcel").val('false');
    GetGstReport(1);
})
$("#Excel").click(function () {
    if ($("#BillDateFrom").val().length == 0) {
        Toast('Please Enter Bill From Date !', 'Message', 'error');
        return;
    }
    if ($("#BillDateTo").val().length == 0) {
        Toast('Please Enter Bill To Date !', 'Message', 'error');
        return;
    }
    $("#CheckExcel").val('true');
    /*alert($("#BillDateFrom").val() + "_" + $("#BillDateTo").val());*/
    Download("SaleReport_" + $("#BillDateFrom").val().replaceAll('/', '') + "_" + $("#BillDateTo").val().replaceAll('/', '') + ".xlsx");
})
//FUNCTION FOR BIND BILL TYPE
function FillBillType() {
    try {
        //ShowLoader();
        AjaxSubmission(null, "/Master/GSTReportSale/FillBillType", $('input[name=__RequestVerificationToken]').val()).done(function (result) {
            let obj = result;
            if (obj.status == true) {
                if (obj.responsecode == '100') {
                    BindDropdown(obj.data.Table, 'BillType', 'BillTypeUid', 'BillTypeName', '0');

                }
                else if (obj.responsecode == '604') {
                    BindDropdown(null, 'BillType', 'BillTypeUid', 'BillTypeName', '0');

                }
                else {
                    Toast(RetrieveMessage(obj.responsecode), "Message", "error");
                }

            }
            else {
                window.location.href = '/ClientLogin/ClientLogin';
            }
            //HideLoader();
        }).fail(function (result) {
            console.log(result.Message);
            HideLoader();
        });
    }
    catch (e) {
        console.log(e.message);
        //HideLoader();
    }
}
function Download(fileName) {

    const dataString = {};
    dataString.ImporterName = $("#HiddenImporterName").val();
    dataString.BillDateFrom = $("#BillDateFrom").val();
    dataString.BillDateTo = $("#BillDateTo").val();
    dataString.BranchIdSearch = $("#BranchIdSearch").val();
    dataString.CheckExcel = $("#CheckExcel").val();
    dataString.BillType = $("#BillType").val();
    dataString._FileName = fileName;

    AjaxSubmission(JSON.stringify(dataString), '/Master/GSTReportSale/DownloadFile', $('input[name=__RequestVerificationToken]').val()).done(function (result) {
        let obj = result;
        console.log(obj);
        if (obj.status == true) {
            if (obj.responsecode == '100') {

                var bytes = Base64ToBytes(obj.data.FileData[0].Base64Data);

                //Convert Byte Array to BLOB.
                var blob = new Blob([bytes], { type: "application/octetstream" });

                //Check the Browser type and download the File.
                var isIE = false || !!document.documentMode;
                if (isIE) {
                    window.navigator.msSaveBlob(blob, fileName);
                } else {
                    var url = window.URL || window.webkitURL;
                    link = url.createObjectURL(blob);
                    var a = $("<a />");
                    a.attr("download", fileName);
                    a.attr("href", link);
                    $("body").append(a);
                    a[0].click();
                    $("body").remove(a);
                }
            }
            else
                Toast(RetrieveMessage(obj.responsecode), 'Message', 'error');

        } else
            window.location.href = '/ClientLogin/ClientLogin';
        //HideLoader();

    }).fail(function (result) {
        console.log(result.Message);
        //HideLoader();
    });
};

function Base64ToBytes(base64) {
    var s = window.atob(base64);
    var bytes = new Uint8Array(s.length);
    for (var i = 0; i < s.length; i++) {
        bytes[i] = s.charCodeAt(i);
    }
    return bytes;
};
$(document).on("click", ".pagination .page", function () {
    GetGstReport(($(this).attr('page')));
});

$('#ddlPageSize').change(function () {
    GetGstReport(1);
});
//function Download(fileName) {
//    alert(fileName);
//    $.ajax({
//        type: "POST",
//        url: "/Master/GSTReportSale/DownloadFile",
//        data: '{_FileName: "' + fileName + '",BranchIdSearch:"' + $("#BranchIdSearch").val() + '",BillType:"' + $("#BillType").val() + '",BillDateFrom:"' + $("#BillDateFrom").val() + '",BillDateTo:"' + $("#BillDateTo").val() + '",ImporterName:"' + $("#HiddenImporterName").val() + '"}',
//        contentType: "application/json; charset=utf-8",
//        dataType: "text",
//        success: function (r) {
//            //Convert Base64 string to Byte Array.
//            var bytes = Base64ToBytes(r);

//            //Convert Byte Array to BLOB.
//            var blob = new Blob([bytes], { type: "application/octetstream" });

//            //Check the Browser type and download the File.
//            var isIE = false || !!document.documentMode;
//            if (isIE) {
//                window.navigator.msSaveBlob(blob, fileName);
//            } else {
//                var url = window.URL || window.webkitURL;
//                link = url.createObjectURL(blob);
//                var a = $("<a />");
//                a.attr("download", fileName);
//                a.attr("href", link);
//                $("body").append(a);
//                a[0].click();
//                $("body").remove(a);
//            }
//        }
//    });
//};