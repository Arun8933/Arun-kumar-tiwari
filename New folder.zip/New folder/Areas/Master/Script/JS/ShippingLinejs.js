﻿
let Firstcolumn = "";
let a = [];
let flag = 0;
let totalDetenDemmCharge = 0;
let totalShippingAndCFSCharge = 0;
let DetenDemmAmtEdit = 0;

//DOCUMENT READY FUNCTION
$(document).ready(function () {
    Firstcolumn = 'Shipping_and_CFS_name';
    FillPageSizeList('ddlPageSize', FormList);

    BindContainerType('ContainerType');
    BindContainerType('ContType');
    FillShippingLineAndCFSName();
    FillCFSChargesTypeName();
    $("#ShippingAndCfsNameSearch").focus();
    $("#ShippingLineAndCFSName").select2({
        width: '100%'
    });
    $("#ChargesType").select2({
        width: '100%',
        dropdownParent: $('#ChargesModal')
    })
    //; $("#ContType").select2({
    //    width: '100%'
    //});
});
$(".ShippingLine_list").click(function () {
    $("#ShippingAndCfsNameSearch").focus();
})
//BIND DETENTION AND SHIPPING CHARGES TABLE
function FormList(pageindex) {
    try {
        const dataString = {};
        dataString.PageSize = $("#ddlPageSize").val();
        dataString.PageIndex = pageindex;
        dataString.Type = $("#TypeSearch").val().trim();
        dataString.ShippingAndCfsName = $("#ShippingAndCfsNameSearch").val().trim();
        dataString.OrderBy = $("#sort-column").val().trim() + " " + $("#sort-type").val().trim();
        //ShowLoader();
        AjaxSubmission(JSON.stringify(dataString), "/Master/ShippingLine/FormList", $('input[name=__RequestVerificationToken]').val()).done(function (result) {

            let obj = result;

            if (obj.status == true) {
                if (obj.responsecode == '100') {

                    var ser = ((parseInt(obj.data.Table1[0].PageIndex) - 1) * parseInt(obj.data.Table1[0].PageSize)) + 1;
                    BindFormTable(obj.data.Table, ser);
                    if (obj.data.Table1 != undefined && obj.data.Table1.length > 0) {
                        $(".pagination").BindPaging({
                            ActiveCssClass: "current",
                            PagerCssClass: "pager",
                            PageIndex: parseInt(obj.data.Table1[0].PageIndex),
                            PageSize: parseInt(obj.data.Table1[0].PageSize),
                            RecordCount: parseInt(obj.data.Table1[0].count)
                        });
                    }

                }
                else {
                    Toast(RetrieveMessage(obj.responsecode), "Message", "error");
                }
            }
            else {
                window.location.href = '/ClientLogin/ClientLogin';
            }
            //HideLoader();
        }).fail(function (result) {
            console.log(result.Message);
            //HideLoader();
        });
    }
    catch (e) {
        console.log(e.message);
        //HideLoader();
    }
}

$("#DetentionModal").on('show.bs.modal', function () {
    $("#DetentionModal").find("#From").focus();

});

//BIND TABLE FUNCTION 
function BindFormTable(Result, SerialNo) {

    $("#TblDetention tbody tr").remove();

    if (Result.length == 0) {
        tr = $('<tr/>');
        tr.append("<td class='text-center' colspan='5'>NO RESULTS FOUND</td>");
        $("#TblDetention tbody").append(tr);
    }
    else {
        for (i = 0; i < Result.length; i++) {
            if (Result[i].is_active == "Inactive")
                tr = $(' <tr style="background-color:#fdd2d2;"/>');
            else
                tr = $('<tr/>');
            tr.append("<td class='text-center'><button type='button' onclick='FormEdit(\"" + Result[i].ShipUid + "\");' class= 'common-btn common-btn-sm'><i class='fa-solid fa-pen-to-square'></i></button ><button type='button' onclick='FormDelete(\"" + Result[i].ShipUid + "\");' class= 'common-btn common-btn-sm ms-1'> <i class='fa-regular fa-trash-can'></i></button ></td > ");
            tr.append("<td class='text-left'>" + SerialNo + "</td>");

            tr.append("<td class='text-center'><a href='javascript:void(0)' class='text-decoration-none ' style='color: black !important;' onclick='FormEdit(\"" + Result[i].ShipUid + "\");'>" + Result[i].Shipping_and_CFS_name + "</a></td>");
            tr.append("<td class='text-center'>" + Result[i].Slab_Name + "</td>");
            tr.append("<td class='text-center'>" + Result[i].Type + "</td>");


            SerialNo++;

            $("#TblDetention tbody").append(tr);

        }

    }

}

//BTN SEARCH CLICK
$("#FormSearch").click(function () {
    FormList(1);
});

//DETENTION TABLE PAGINATION BUTTON CLICK
$(document).on("click", ".pagination .page", function () {
    FormList(($(this).attr('page')));
});

//PAGE SIZE ON CHANGE FUNCTION
$("#ddlPageSize").change(function () {
    FormList(1);
});

//FUNCTION FOR SORTING FIELD
function FormSorting(obj) {
    if (Firstcolumn != "") {
        document.getElementById(Firstcolumn).innerHTML = document.getElementById(Firstcolumn).getAttribute("data-column") + "<i style='margin-left:10px;' class='fa-solid fa-sort'></i>";
    }
    Firstcolumn = obj.id;
    let colname = $(obj).data("column");
    $("#sort-column").val(Firstcolumn);
    let sorttype = $("#sort-type").val();
    if (sorttype == "ASC") {
        $("#sort-type").val("DESC");
        $(obj).html(colname + "<i style='margin-left:10px;' class='fa-solid fa-sort-down'></i>");
    } else if (sorttype == "DESC") {
        $("#sort-type").val("ASC");
        $(obj).html(colname + "<i style='margin-left:10px;' class='fa-solid fa-sort-up'></i>");
    }
    FormList(1);
}

//FUNCTION FOR FILL SHIPPING AND CFS NAME LIST
function FillShippingLineAndCFSName() {
    try {
        //ShowLoader();
        AjaxSubmission(null, "/Master/ShippingLine/GetAccountHeadName", $('input[name=__RequestVerificationToken]').val()).done(function (result) {
            let obj = result;
            if (obj.status == true) {
                if (obj.responsecode == '100') {
                    BindDropdown(obj.data.Table, 'ShippingLineAndCFSName', 'LedgerUid', 'AccHead', '-----Select-----');
                }
                else if (obj.responsecode == '604') {
                    BindDropdown(null, 'ShippingLineAndCFSName', 'LedgerUid', 'AccHead', '-----Select-----');
                }
                else {
                    Toast(RetrieveMessage(obj.responsecode), "Message", "error");
                }

            }
            else {
                window.location.href = '/ClientLogin/ClientLogin';
            }
            //HideLoader();
        }).fail(function (result) {
            console.log(result.Message);
            //HideLoader();
        });
    }
    catch (e) {
        console.log(e.message);
        //HideLoader();
    }
}

//FUNCTION FOR FILL SHIPPING AND CFS CHARGES TYPE
function FillCFSChargesTypeName() {
    try {
        //ShowLoader();
        AjaxSubmission(null, "/Master/ShippingLine/GetCFSChargesTypeName", $('input[name=__RequestVerificationToken]').val()).done(function (result) {
            let obj = result;
            if (obj.status == true) {
                if (obj.responsecode == '100') {
                    BindDropdown(obj.data.Table, 'ChargesType', 'charges_type_uid', 'charges_type', '-----Select-----');
                }
                else if (obj.responsecode == '604') {
                    BindDropdown(null, 'ChargesType', 'charges_type_uid', 'charges_type', '-----Select-----');
                }
                else {
                    Toast(RetrieveMessage(obj.responsecode), "Message", "error");
                }
                //setTimeout(SubGroupList(1), 1000);
            }
            else {
                window.location.href = '/ClientLogin/ClientLogin';
            }
            //HideLoader();
        }).fail(function (result) {
            console.log(result.Message);
            //HideLoader();
        });
    }
    catch (e) {
        console.log(e.message);
        //HideLoader();
    }
}

//BIND MULTIPLE DROPDOWN FUNCTION
function BindContainerType(DrpId) {
    try {
        //ShowLoader();
        AjaxSubmission(null, "/Master/ShippingLine/GetContainerType", $('input[name=__RequestVerificationToken]').val()).done(function (result) {
            let obj = result;
            if (obj.status == true) {
                if (obj.responsecode == '100') {
                    BindDropdown(obj.data.Table, DrpId, 'container_type_uid', 'container_type', '-----Select-----');
                }
                else if (obj.responsecode == '604') {
                    BindDropdown(null, DrpId, 'container_type_uid', 'container_type', '-----Select-----');
                }
                else {
                    Toast(RetrieveMessage(obj.responsecode), "Message", "error");
                }
                //setTimeout(SubGroupList(1), 1000);
            }
            else {
                window.location.href = '/ClientLogin/ClientLogin';
            }
            //HideLoader();
        }).fail(function (result) {
            console.log(result.Message);
            //HideLoader();
        });

    }
    catch (e) {
        console.log(e.message);
    }
}

//ADD SHIPPING LINE BUTTON CLICK
$("#FormAdd").click(function () {
    if ($("#SlabName").val() == '') {
        $("#SlabName").addClass('error-textbox');
        $("#SlabName").focus();
        Toast('Please Fill Slab Name', 'Message', 'error');
        return;
    }
    $("#SlabName").removeClass('error-textbox');
    if ($("#ShippingLineAndCFSName").val() == '0') {
        $("#select2-ShippingLineAndCFSName-container").parent().addClass('error-textbox')
        $("#select2-ShippingLineAndCFSName-container").parent().focus();
        Toast(RetrieveMessage(901), 'Message', 'error');
        return;
    }
    for (let i = 0; i < a.length; i++) {
        if (a[i][0].length > 2) {
            let isEmpty = a[i][0][a[i][0].length - 1]
            if (isEmpty != 9999) {
                Toast(a[i][0][0] + ' Charges should be filled from 1 to 0 or 9999', 'Message', 'error');
                return;
            }
        }
    }
    $("#select2-ShippingLineAndCFSName-container").parent().removeClass('error-textbox')
    FormAdd();
});

//FUNCTION FOR ADD DETENTION AND SHIPPING CHARGES
function FormAdd() {

    try {
        const datastring = {};
        var detention = new Array();
        $("#TableDetensionAndDemmCharges tbody tr").each(function (index, element) {
            let g = {};
            if (index != $("#TableDetensionAndDemmCharges tbody tr").length - 1) {
                g.FromDays = $(element).find(".From").text();
                g.ToDays = $(element).find(".To").text();
                g.ContainerTypeId = $(element).find(".ContainerTypeId").val();
                g.Amount = $(element).find(".Charges").text();
                detention.push(g);
            }
        });
        var shipping = new Array();
        $("#TableShippingAndCFSCharges tbody tr").each(function (ind, ele) {
            let h = {};
            if (ind != $("#TableShippingAndCFSCharges tbody tr").length - 1) {
                h.ChargesTypeId = $(ele).find(".ChargesTypeId").val();
                h.ContainerTypeId = $(ele).find(".ContTypeId").val();
                h.Amount = $(ele).find(".Amount").text();
                shipping.push(h);
            }
        });
        datastring.detensionAndDemmModels = detention;
        datastring.shippingAndCFSModels = shipping;
        datastring.LedgerId = $("#ShippingLineAndCFSName").val();
        datastring.SlabName = $("#SlabName").val();
        datastring.ChargesInInr = $("#ChargesInINR").is(":checked");
        datastring.DemmDetenChargesInInr = $("#DemmDetenChargesInInr").is(":checked");
        datastring.ShipCfsChargesInInr = $("#ShipCfsChargesInInr").is(":checked");

        //ShowLoader();
        AjaxSubmission(JSON.stringify(datastring), "/Master/ShippingLine/FormAdd", $('input[name=__RequestVerificationToken]').val()).done(function (result) {
            let obj = result;
            if (obj.status == true) {
                if (obj.responsecode == '101') {
                    Toast(RetrieveMessage(obj.responsecode), "Message", "success");
                    setTimeout(FormList(1), 500);
                    $("#FormAdd").hide();
                    $("#FormUpdate").show();
                    $("#FormReset").show();
                    $("#ShippingLine-tab").html("Edit Shipping Line/CFS Charges");
                    $("#ShipUid").val(obj.data.Table[0].ShipUid);
                    $("#Timestamp").val(obj.data.Table[0].Timestamp);
                    //ResetForm();
                    //TabHide();
                }
                else {
                    if (obj.responsecode) {
                        $("#SlabName").addClass('error-textbox');
                        $("#SlabName").focus();
                        Toast(RetrieveMessage(obj.responsecode), "Message", "error");
                    } else
                        Toast(RetrieveMessage(obj.responsecode), "Message", "error");
                }
            }
            else {
                window.location.href = '/ClientLogin/ClientLogin';
            }
            //HideLoader();
        }).fail(function (result) {
            console.log(result.Message);
            //HideLoader();
        });
    }
    catch (e) {
        console.log(e.message);
    }

}

//FUNCTION FOR EDIT DETENTION AND SHIPPING CHARGES
function FormEdit(e) {
    try {
        const datastring = {};
        datastring.ship_id = e;
        AjaxSubmission(JSON.stringify(datastring), "/Master/ShippingLine/FormEdit", $('[name="__RequestVerificationToken"]').val()).done(function (data) {
            let obj = data;
            if (obj.status == true) {
                if (obj.responsecode == '100') {
                    TabShow();

                    var LedgerId = obj.data.Table[0].LedgerId;
                    $("#ShippingLineAndCFSName").val(LedgerId).trigger('change');

                    //$("#ShippingLineAndCFSName").attr("disabled", "disabled");
                    $("#ChargesInINR").prop("checked", obj.data.Table[0].ChargesInInr);
                    $("#ShipCfsChargesInInr").prop("checked", obj.data.Table[0].ShipCfsChargesInInr);
                    $("#DemmDetenChargesInInr").prop("checked", obj.data.Table[0].DemmDetenChargesInInr);
                    $("#SlabName").val(obj.data.Table[0].SlabName);
                    $("#ShipUid").val(obj.data.Table[0].ShipUid);
                    $("#Timestamp").val(obj.data.Table[0].Timestamp);
                    $.each(obj.data.Table2, function (index, ele) {

                        var tr;
                        tr = $('<tr/>');
                        tr.append("<td class='rn d-none RowNum'>" + index + 1 + "</td>");
                        tr.append("<td class='text-center From'>" + ele.FromDays + "</td>");
                        tr.append("<td class='text-center To'>" + ele.ToDays + "</td>");
                        tr.append("<td class='text-center ContainerType'>" + ele.container_type + "<input type='hidden' class='ContainerTypeId' value='" + ele.container_type_id + "' /></td>");
                        tr.append("<td class='Charges text-end'>" + ele.amount.toFixed(2) + "</td>");
                        tr.append('<td class="text-center"><button type="button" class="common-btn common-btn-sm btnEditDetention"><i class="fa fa-edit"></i></button><button style="margin-left: 10px;" type="button" class="common-btn common-btn-sm btndeleteDetention"><i class="fa fa-trash"></i></button></td>');
                        totalDetenDemmCharge = parseFloat((totalDetenDemmCharge - 0) + (ele.amount.toFixed(2) - 0)).toFixed(2);
                        if ($('#TableDetensionAndDemmCharges tbody').find('tr').length == 0) {
                            $('#TableDetensionAndDemmCharges tbody').append(tr);
                            tr = $('<tr id="totalDetenDemmCharges"/>')
                            tr.append("<td><td/><td class='text-capitalize text-center'><h3>Total Amount</h3></td>");
                            tr.append("<td class='text-end'><h5 id='TotalDetenDemmAmount'></h5></td><td></td>");
                            $('#TableDetensionAndDemmCharges tbody').append(tr);
                        } else {
                            $('#TableDetensionAndDemmCharges tbody tr').eq($('#TableDetensionAndDemmCharges tbody tr').length - 1).before(tr);
                        }
                        $("#TotalDetenDemmAmount").html(totalDetenDemmCharge);
                    });
                    $.each(obj.data.Table1, function (index, elee) {
                        let trr;
                        totalShippingAndCFSCharge = parseFloat((totalShippingAndCFSCharge - 0) + (elee.amount.toFixed(2) - 0)).toFixed(2);
                        trr = $('<tr/>');
                        trr.append("<td class='d-none'>" + index + 1 + "</td>")
                        trr.append("<td class='ChargesType'>" + elee.charges_type + "<input type='hidden' class='ChargesTypeId' value='" + elee.charges_type_id + "' /></td>");
                        trr.append("<td class='text-center ContType'>" + elee.container_type + "<input type='hidden' class='ContTypeId' value='" + elee.container_type_uid + "' /></td>");
                        trr.append("<td class='Amount text-end'>" + elee.amount.toFixed(2) + "</td>");
                        trr.append('<td class="text-center"><button style="margin-left: 10px;" type="button" class="common-btn common-btn-sm btndeleteShipping"><i class="fa fa-trash"></i></button></td>');
                        if ($('#TableShippingAndCFSCharges tbody').find('tr').length == 0) {
                            $('#TableShippingAndCFSCharges tbody').append(trr);
                            trr = $('<tr id="TotalShippingCfsCharges"/>')
                            trr.append("<td></td><td class='text-capitalize text-center'><h3>Total Amount</h3></td>");
                            trr.append("<td class='text-end'><h5 id='TotalShippingCfsAmount'>123123</h5></td><td></td>");
                            $('#TableShippingAndCFSCharges tbody').append(trr);
                        } else
                            $('#TableShippingAndCFSCharges tbody tr').eq($('#TableShippingAndCFSCharges tbody tr').length - 1).before(trr);
                        $("#TotalShippingCfsAmount").html(totalShippingAndCFSCharge);
                    });



                    for (d = 0; d < obj.data.Table2.length; d++) {

                        var b = [];
                        var c = [];
                        var tmp = [];
                        var i, j, k, l, m;
                        var ch = 0;
                        var ind = 0;
                        var cd = 0;

                        var CurrContVal = obj.data.Table2[d].container_type;
                        var CurrFromVal = obj.data.Table2[d].FromDays;
                        var CurrToVal = obj.data.Table2[d].ToDays;
                        if (flag == 0) {
                            b.push(CurrContVal);
                            for (i = CurrFromVal; i <= (CurrToVal == 0 ? 9999 : CurrToVal); i++) {
                                b.push(i);
                            }
                            c.push(b);
                            a.push(c);

                            flag = 1;
                        }
                        else {
                            for (j = 0; j < a.length; j++) {
                                if (a[j][0][0] == CurrContVal) {
                                    cd = 1;
                                    ind = j;
                                    for (k = CurrFromVal; k <= (CurrToVal == 0 ? 9999 : CurrToVal); k++) {
                                        tmp.push(k);
                                    }
                                    for (l = 0; l < tmp.length; l++) {
                                        for (m = 0; m < a[j][0].length; m++) {

                                            if (tmp[l] == a[j][0][m]) {
                                                ch = 1;
                                            }
                                        }
                                    }
                                    if (ch == 0) {
                                        for (x = 0; x < tmp.length; x++) {
                                            a[ind][0].push(tmp[x]);
                                        }
                                    }

                                }
                            }

                            if (cd == 0) {
                                b.push(CurrContVal);
                                for (i = CurrFromVal; i <= (CurrToVal == 0 ? 9999 : CurrToVal); i++) {
                                    b.push(i);
                                }
                                c.push(b);
                                a.push(c);
                            }
                        }
                    }
                }
                else {
                    Toast(RetrieveMessage(obj.responsecode), "Message", "error");
                }
            }
            else {
                window.location.href = '/ClientLogin/ClientLogin';
            }
        }).fail(function (data) {
            console.log(data.Message);
        });
    }
    catch (e) {
        console.log(e.message);
    }
}

//UPDATE SHIPPING LINE BUTTON CLICK
$("#FormUpdate").click(function () {

    if ($("#SlabName").val() == '') {
        Toast('Please Fill Slab Name', 'Message', 'error');
        return;
    }
    if ($("#ShippingLineAndCFSName").val() == '0') {
        Toast(RetrieveMessage(901), 'Message', 'error');
        return;
    }
    for (let i = 0; i < a.length; i++) {

        if (a[i][0].length > 2) {
            let isEmpty = a[i][0][a[i][0].length - 1]
            if (isEmpty != 9999) {
                Toast(a[i][0][0] + ' Charges should be filled from 1 to 0 or 9999', 'Message', 'error');
                return;
            }
        }
    }
    FormUpdate();
});

//FUNCTION FOR UPDATE DETENTION AND SHIPPING CHARGES
function FormUpdate() {
    try {
        const datastring = {};
        var detention = new Array();
        $("#TableDetensionAndDemmCharges tbody tr").each(function (index, element) {
            let g = {};
            if (index != $("#TableDetensionAndDemmCharges tbody tr").length - 1) {
                g.FromDays = $(element).find(".From").text();
                g.ToDays = $(element).find(".To").text();
                g.ContainerTypeId = $(element).find(".ContainerTypeId").val();
                g.Amount = $(element).find(".Charges").text();
                detention.push(g);
            }
        });
        var shipping = new Array();
        $("#TableShippingAndCFSCharges tbody tr").each(function (ind, ele) {
            let h = {};
            if (ind != $("#TableShippingAndCFSCharges tbody tr").length - 1) {
                h.ChargesTypeId = $(ele).find(".ChargesTypeId").val();
                h.ContainerTypeId = $(ele).find(".ContTypeId").val();
                h.Amount = $(ele).find(".Amount").text();
                shipping.push(h);
            }
        });
        datastring.detensionAndDemmModels = detention;
        datastring.shippingAndCFSModels = shipping;
        datastring.LedgerId = $("#ShippingLineAndCFSName").val();
        datastring.SlabName = $("#SlabName").val();
        datastring.ChargesInInr = $("#ChargesInINR").is(":checked");
        datastring.ShippingCFSId = $("#ShipUid").val();
        datastring.Timestamp = $("#Timestamp").val();
        datastring.DemmDetenChargesInInr = $("#DemmDetenChargesInInr").is(":checked");
        datastring.ShipCfsChargesInInr = $("#ShipCfsChargesInInr").is(":checked");

        //ShowLoader();
        AjaxSubmission(JSON.stringify(datastring), "/Master/ShippingLine/FormUpdate", $('input[name=__RequestVerificationToken]').val()).done(function (result) {
            let obj = result;
            if (obj.status == true) {
                if (obj.responsecode == '107') {
                    Toast(RetrieveMessage(obj.responsecode), "Message", "success");
                    setTimeout(FormList(1), 500);
                    $("#ShipUid").val(obj.data.Table[0].ShipUid);
                    $("#Timestamp").val(obj.data.Table[0].Timestamp);
                    //setTimeout(BindShippingAndCFSTable(1), 500);
                    //ResetForm();
                    //TabHide();
                }
                else {
                    if (obj.responsecode) {
                        $("#SlabName").addClass('error-textbox');
                        $("#SlabName").focus();
                        Toast(RetrieveMessage(obj.responsecode), "Message", "error");
                    } else
                        Toast(RetrieveMessage(obj.responsecode), "Message", "error");
                }
            }
            else {
                window.location.href = '/ClientLogin/ClientLogin';
            }
            //HideLoader();
        }).fail(function (result) {
            console.log(result.Message);
            //HideLoader();
        });
    }
    catch (e) {
        console.log(e.message);
    }
}

//DELETE GROUP FUNCTION
function FormDelete(e) {
    try {
        $.confirm({
            title: '',
            content: 'Are You Sure Want To Delete ?',
            type: 'red',
            boxWidth: '300px',
            useBootstrap: false,
            columnClass: 'small',
            containerFluid: true,
            typeAnimated: true,
            buttons: {
                tryAgain: {
                    text: 'Confirm',
                    btnClass: 'btn-red',
                    action: function () {

                        const datastring = {};
                        datastring.ship_id = parseInt(e);
                        //ShowLoader();
                        AjaxSubmission(JSON.stringify(datastring), "/Master/ShippingLine/FormDelete", $('[name="__RequestVerificationToken"]').val()).done(function (data) {
                            let obj = data;
                            if (obj.status == true) {
                                if (obj.responsecode == '102') {
                                    Toast(RetrieveMessage(obj.responsecode), "Message", "success");
                                    FormList(1);

                                }
                                else {
                                    Toast(RetrieveMessage(obj.responsecode), "Message", "error");
                                }
                            }
                            else {
                                window.location.href = 'ClientLogin/ClientLogin';
                            }
                            //HideLoader();
                        }).fail(function (data) {
                            console.log(data.Message);
                            //HideLoader();
                        });
                    }
                },
                close: function () {
                    //HideLoader();
                }
            }
        });
    }
    catch (e) {
        console.log(e.message);
        //HideLoader();
    }
}

//FUNCTION FOR TAB SHOW
function TabShow() {
    $('#ShippingLine_List-tab').removeClass('active');
    $('#ShippingLine-tab').addClass('active');
    $('#ShippingLine_list').removeClass('active show');
    $('#ShippingLine').addClass('active show');
    $("#FormAdd").hide();
    $("#FormUpdate").show();
    $("#FormReset").show();
    $("#ShippingLine-tab").html("Edit Shipping Line/CFS Charges");
}

//FUNCTION FOR TAB HIDE
function TabHide() {
    $('#ShippingLine-tab').removeClass('active');
    $('#ShippingLine_List-tab').addClass('active ');
    $('#ShippingLine_list').addClass('active show');
    $('#ShippingLine').removeClass('active show');
    $("#FormAdd").show();
    $("#FormUpdate").hide();
    $("#FormReset").hide();
    $("#ShippingLine-tab").html("Add Shipping Line/CFS Charges");
}

//SHIPPING LIST TAB CLICK FUNCTION
$('#ShippingLine_List-tab').click(function () {
    ResetForm();
});

//FUNCTION FOR RESET DATA
function ResetForm() {
    a = [];
    b = [];
    c = [];
    $('#ShippingLineAndCFSName').val('0').trigger('change');
    $("#ShippingLineAndCFSName").removeAttr('Disabled');

    $("#FormAdd").show();
    $("#FormUpdate").hide();
    $("#FormReset").hide();
    $("#ShippingLine-tab").html("Add Shipping Line/CFS Charges");
    $("#SlabName").val("");
    $("#ShipUid").val("");
    $("#Timestamp").val("");
    $("#ChargesInINR").prop("checked", false);
    $("#DemmDetenChargesInInr").prop("checked", false);
    $("#ShipCfsChargesInInr").prop("checked", false);
    $("#TableDetensionAndDemmCharges tbody tr").remove();
    $("#TableShippingAndCFSCharges tbody tr").remove();
    $("#SlabName").removeClass('error-textbox');
    $("#select2-ShippingLineAndCFSName-container").parent().removeClass('error-textbox')
    totalShippingAndCFSCharge = 0;
    totalDetenDemmCharge = 0;
}

function CheckVal(e) {
    var Modelto = parseInt($(e).val());
    var Modelfrom = parseInt($("#From").val());

    if (Modelto <= Modelfrom) {
        $(e).attr('style', 'border:1px solid red');
        Toast(RetrieveMessage(1003), 'Message', 'error');
        return;
    }
    else {
        $(e).attr('style', 'border:1px solid #d9dbde');
    }
}

$("#AddMoreDetensionAndDemmCharges").click(function () {
    $('#DetentionModal').modal('show');

    $("#From").trigger('focus');
});

$("#Cls").click(function () {
    $('#DetentionModal').modal('hide');
    ResetDetentionData();
});




$("#AddDetentionCharges").click(function () {

    let b = [];
    let c = [];
    let tmp = [];
    let i, j, k, l, m;
    let ch = 0;
    let ind = 0;
    let cd = 0;
    let maxLengthOfToVal = document.getElementById('To').getAttribute('maxlength');
    let CurrFromVal = parseInt($("#From").val().trim());
    let CurrToVal = parseInt($("#To").val().trim());
    let CurrContVal = $("#ContainerType option:selected").text();
    let Charges = parseInt($("#Charges").val().trim())
    if (CurrFromVal == 0 || isNaN(CurrFromVal)) {
        $("#From").focus();
        $("#From").addClass('error-textbox');
        Toast("Please Enter From Days !", 'Message', 'error');
        return;
    }
    $("#From").removeClass('error-textbox');
    if (isNaN(CurrToVal)) {
        $("#To").addClass('error-textbox');
        $("#To").focus();
        Toast("Please Enter To Days !", 'Message', 'error');
        return;
    }
    $("#To").removeClass('error-textbox');
    if (parseInt($("#ContainerType option:selected").val()) == 0) {
        $("#ContainerType").addClass('error-textbox');
        $("#ContainerType").focus();
        Toast("Please Select Container Type !", 'Message', 'error');
        return;
    }
    $("#ContainerType").removeClass('error-textbox');
    if (isNaN(Charges)) {
        $("#Charges").addClass('error-textbox');
        $("#Charges").focus();
        Toast("Please Enter Amount !", 'Message', 'error');
        return;
    }
    $("#Charges").removeClass('error-textbox');

    if (CurrToVal < CurrFromVal && CurrToVal != 0) {
        $("#To").focus();
        $("#To").addClass('error-textbox');
        Toast(RetrieveMessage(1003), 'Message', 'error');
        return;
    } else {
        if (CurrToVal == 0) {
            CurrToVal = '';
            if (maxLengthOfToVal > 0) {
                for (i = 1; i <= maxLengthOfToVal; i++) {
                    CurrToVal += '9';
                }
            }
            else {
                CurrToVal = 9999;
            }
        }
        if (flag == 0) {
            if (CurrFromVal == 1) {
                b.push(CurrContVal);
                for (i = CurrFromVal; i <= CurrToVal; i++) {
                    b.push(i);
                }
                c.push(b);
                a.push(c);

                flag = 1;
            } else {
                $("#From").focus();
                $("#From").addClass('error-textbox');
                Toast("Enter From 1 of container type " + CurrContVal + " !", 'Message', 'error');
                return;
            }
        }
        else {
            let lastVal;
            for (let i = 0; i < a.length; i++)
                if (CurrContVal == a[i][0][0]) {
                    lastVal = a[i][0][a[i][0].length - 1]
                    break;
                }
            if (lastVal == 'undefined' || lastVal < 1 || isNaN(lastVal)) {
                lastVal = 0;
            }
            if (lastVal == CurrFromVal - 1) {
                for (j = 0; j < a.length; j++) {
                    if (a[j][0][0] == CurrContVal) {
                        cd = 1;
                        ind = j;
                        for (k = CurrFromVal; k <= CurrToVal; k++) {
                            tmp.push(k);
                        }
                        let arr = [...a[ind][0]];
                        for (let x = 0; x < tmp.length; x++) {
                            arr.push(tmp[x]);
                        }
                        let newSet = new Set(arr);
                        if (newSet.size != arr.length) {
                            ch = 1;
                        } else {
                            if (ch == 0) {
                                for (let x = 0; x < tmp.length; x++) {
                                    a[ind][0].push(tmp[x]);
                                }
                            }
                        }
                    }
                }
            } else if (lastVal == 9999) {
                Toast("Maximum numbers of days has been entered of container type " + CurrContVal + "!", 'Message', 'error');
                return;
            } else if (lastVal == 0) {
                $("#From").focus();
                $("#From").addClass('error-textbox');
                Toast("Please Enter Starting Day From 1 of container type " + CurrContVal + " of container type " + CurrContVal + " !", 'Message', 'error');
                return;
            }
            else {
                $("#From").focus();
                $("#From").addClass('error-textbox');
                Toast("Day should be starts from " + (lastVal + 1) + " of container type " + CurrContVal + "!", 'Message', 'error');
                return;
            }

            if (cd == 0) {
                b.push(CurrContVal);
                for (i = CurrFromVal; i <= CurrToVal; i++) {
                    b.push(i);
                }
                c.push(b);
                a.push(c);
            }
        }
        if (ch == 0) {
            totalDetenDemmCharge = parseFloat((parseFloat(totalDetenDemmCharge) - 0) + (parseFloat($("#Charges").val()).toFixed(2) - 0)).toFixed(2);
            tr = $('<tr/>');
            tr.append("<td class='rn d-none RowNum'></td>");
            tr.append("<td class='text-center From'>" + $("#From").val() + "</td>");
            tr.append("<td class='text-center To'>" + $("#To").val() + "</td>");
            tr.append("<td class='text-center ContainerType'>" + $("#ContainerType option:selected").text() + "<input type='hidden' class='ContainerTypeId' value='" + $("#ContainerType").val() + "' /></td>");
            tr.append("<td class='Charges text-end'>" + $("#Charges").val() + "</td>");
            tr.append('<td class="text-center"><button type="button" class="common-btn common-btn-sm btnEditDetention"><i class="fa fa-edit"></i></button><button style="margin-left: 10px;" type="button" class="common-btn common-btn-sm btndeleteDetention"><i class="fa fa-trash"></i></button></td>');

            if ($('#TableDetensionAndDemmCharges tbody').find('tr').length == 0) {
                $('#TableDetensionAndDemmCharges tbody').append(tr);
                tr = $('<tr id="totalDetenDemmCharges"/>')
                tr.append("<td><td/><td class='text-capitalize text-center'><h3>Total Amount</h3></td>");
                tr.append("<td class='text-end'><h5 id='TotalDetenDemmAmount'></h5></td><td></td>");
                $('#TableDetensionAndDemmCharges tbody').append(tr);
            } else {
                $('#TableDetensionAndDemmCharges tbody tr').eq($('#TableDetensionAndDemmCharges tbody tr').length - 1).before(tr);
            }
            $("#TotalDetenDemmAmount").html(totalDetenDemmCharge);
            GenerateSerialNumberTable('TableDetensionAndDemmCharges', 'rn');
            ResetDetentionData();
            $("#From").focus();
        }
        else {
            Toast(RetrieveMessage(312), 'Message', 'error');
            return;
        }
    }
});

$("#AddShippingCharges").click(function () {
    let ContainerType = $("#ContType option:selected").text();
    let ChargesType = $("#ChargesType option:selected").text();
    let Trc = $("#TableShippingAndCFSCharges tbody tr").length;

    if ($("#ChargesType").val() == 0) {
        //$("#ChargesType").addClass('error-textbox');
        //$("#ChargesType").focus();
        $("#ChargesType").select2('open')
        Toast(RetrieveMessage(902), 'Message', 'error');
        return;
    }
    //$("#ChargesType").removeClass('error-textbox');
    if ($("#ContType").val() == 0) {
        $("#ContType").addClass('error-textbox');
        $("#ContType").focus();
        Toast(RetrieveMessage(900), 'Message', 'error');
        return;
    }
    $("#ContType").removeClass('error-textbox');
    if ($("#Amount").val() == '') {
        $("#Amount").addClass('error-textbox');
        $("#Amount").focus();
        Toast("Please Enter Amount !", 'Message', 'error');
        return;
    }
    $("#Amount").removeClass('error-textbox');
    totalShippingAndCFSCharge = parseFloat((parseFloat(totalShippingAndCFSCharge) - 0) + (parseFloat($("#Amount").val()).toFixed(2) - 0)).toFixed(2);
    if (Trc == 0) {
        tr = $('<tr/>');

        tr.append("<td class='ChargesType'>" + $("#ChargesType option:selected").text() + "<input type='hidden' class='ChargesTypeId' value='" + $("#ChargesType").val() + "' /></td>");
        tr.append("<td class='text-center ContType'>" + $("#ContType option:selected").text() + "<input type='hidden' class='ContTypeId' value='" + $("#ContType").val() + "' /></td>");
        tr.append("<td class='Amount text-end'>" + $("#Amount").val() + "</td>");
        tr.append('<td class="text-center"><button style="margin-left: 10px;" type="button" class="common-btn common-btn-sm btndeleteShipping"><i class="fa fa-trash"></i></button></td>');
        if ($('#TableShippingAndCFSCharges tbody').find('tr').length == 0) {
            $('#TableShippingAndCFSCharges tbody').append(tr);
            tr = $('<tr id="TotalShippingCfsCharges"/>')
            tr.append("<td></td><td class='text-capitalize text-center'><h3>Total Amount</h3></td>");
            tr.append("<td class='text-end'><h5 id='TotalShippingCfsAmount'>123123</h5></td><td></td>");
            $('#TableShippingAndCFSCharges tbody').append(tr);
        } else
            $('#TableShippingAndCFSCharges tbody tr').eq($('#TableShippingAndCFSCharges tbody tr').length - 1).before(tr);
        //$('#TableShippingAndCFSCharges').append(tr);
        ResetChargesData();
        $("#TotalShippingCfsAmount").html(totalShippingAndCFSCharge);
        $('#ChargesType').val('0').trigger('change');
        $("#ChargesType").select2('open')
    }
    else {

        var CurrentContType, CurrentChargesType, bool = false;

        $("#TableShippingAndCFSCharges tbody tr").each(function (index, ele) {
            CurrentContType = $(ele).find('.ContType').text();
            CurrentChargesType = $(ele).find('.ChargesType').text();
            if (ContainerType == CurrentContType) {
                if (ChargesType == CurrentChargesType) {
                    bool = true;
                    Toast(RetrieveMessage(312), 'Message', 'error');
                    return;
                }
            }
        });
        if (bool == false) {
            tr = $('<tr/>');

            tr.append("<td class='ChargesType'>" + $("#ChargesType option:selected").text() + "<input type='hidden' class='ChargesTypeId' value='" + $("#ChargesType").val() + "' /></td>");
            tr.append("<td class='text-center ContType'>" + $("#ContType option:selected").text() + "<input type='hidden' class='ContTypeId' value='" + $("#ContType").val() + "' /></td>");
            tr.append("<td class='Amount text-end'>" + $("#Amount").val() + "</td>");
            tr.append('<td class="text-center"><button style="margin-left: 10px;" type="button" class="common-btn common-btn-sm btndeleteShipping"><i class="fa fa-trash"></i></button></td>');
            if ($('#TableShippingAndCFSCharges tbody').find('tr').length == 0) {
                $('#TableShippingAndCFSCharges tbody').append(tr);
                tr = $('<tr id="TotalShippingCfsCharges"/>')
                tr.append("<td></td><td class='text-capitalize text-center'><h3>Total Amount</h3></td>");
                tr.append("<td class='text-end'><h5 id='TotalShippingCfsAmount'>123123</h5></td><td></td>");
                $('#TableShippingAndCFSCharges tbody').append(tr);
            } else {
                $('#TableShippingAndCFSCharges tbody tr').eq($('#TableShippingAndCFSCharges tbody tr').length - 1).before(tr);
            }
            //$('#TableShippingAndCFSCharges').append(tr);
            ResetChargesData();
            $("#TotalShippingCfsAmount").html(totalShippingAndCFSCharge);
            $('#ChargesType').val('0').trigger('change');
            $("#ChargesType").select2('open')
        }
    }
});

$("#AddMoreShipingChargesAndCFSCharges").click(function () {
    $('#ChargesModal').modal('show');
});

$("#AddMoreDetensionAndDemmCharges").click(function () {
    $('#DetentionModal').modal('show');
});
$("#ClsCharges").click(function () {
    $('#ChargesModal').modal('hide');
    ResetChargesData();
    $('#ChargesType').val('0').trigger('change');
});

$('#TableShippingAndCFSCharges tbody').on('click', '.btndeleteShipping', function () {
    totalShippingAndCFSCharge = parseFloat(totalShippingAndCFSCharge - $(this).parent().parent().find('.Amount').html()).toFixed(2);
    $("#TotalShippingCfsAmount").html(totalShippingAndCFSCharge);
    if ($('#TableShippingAndCFSCharges tbody tr').length === 2) {
        $('#TableShippingAndCFSCharges tbody').find('tr').remove();
    }
    else {
        $(this).parent().parent().remove();
    }
});



$('#TableDetensionAndDemmCharges tbody').on('click', '.btndeleteDetention', function () {

    let FromVal = parseInt($(this).parents('tr').find('.From').text());
    let ToVal = parseInt($(this).parents('tr').find('.To').text());
    let ContainerTypeVal = $(this).parents('tr').find('.ContainerType').text();
    let maxLengthOfToVal = document.getElementById('To').getAttribute('maxlength');
    if (ToVal == 0) {
        if (maxLengthOfToVal > 0) {
            ToVal = '';
            for (i = 1; i <= maxLengthOfToVal; i++) {
                ToVal += '9';
            }
        }
        else {
            ToVal = 9999;
        }
    }
    let isDeleting = false;
    for (let j = 0; j < a.length; j++) {

        if (a[j][0][0] == ContainerTypeVal) {
            if (a[j][0][a[j][0].length - 1] == (ToVal == 0 ? 9999 : ToVal)) {
                isDeleting = true;
                let count = ToVal - FromVal;

                let index = a[j][0].indexOf(FromVal);

                a[j][0].splice(index, (count + 1));
            }
        }
    }
    if (isDeleting) {
        totalDetenDemmCharge = parseFloat(totalDetenDemmCharge - $(this).parent().parent().find('.Charges').html()).toFixed(2);
        $("#TotalDetenDemmAmount").html(totalDetenDemmCharge);
        if ($('#TableDetensionAndDemmCharges tbody tr').length === 2) {
            $('#TableDetensionAndDemmCharges tbody').find('tr').remove();
        }
        else {
            $(this).parent().parent().remove();
        }
    }

});

$('#TableDetensionAndDemmCharges tbody').on('click', '.btnEditDetention', function () {
    $('#DetentionModal').modal('show');
    $("#From").trigger('focus');
    DetenDemmAmtEdit = $(this).parent().parent().find(".Charges").text();
    let rowNumber = parseInt($(this).parents('tr').find('.rn').text());
    let toVal = parseInt($(this).parents('tr').find('.To').text());
    let fromVal = parseInt($(this).parents('tr').find('.From').text());
    let chargesVal = $(this).parents('tr').find('.Charges').text();
    $("#From").attr('disabled', 'disabled');
    $("#ContainerType").attr('disabled', 'disabled');

    let lastVal;
    for (let i = 0; i < a.length; i++) {
        if ($(this).parents('tr').find('.ContainerType').text() == a[i][0][0]) {
            lastVal = a[i][0][a[i][0].length - 1]
            break;
        }
    }

    $("#RowNumber").val(rowNumber);
    $("#From").val(fromVal);
    $("#ContainerType").val(parseInt($(this).parents('tr').find('.ContainerTypeId').val()));
    $("#To").val(toVal);
    $("#Charges").val(chargesVal);
    $("#UpdateDetentionCharges").removeClass('d-none')
    $("#AddDetentionCharges").addClass('d-none')
    if (lastVal == 9999)
        lastVal = 0
    if (lastVal != toVal && toVal != 9999)
        $("#To").attr('disabled', 'disabled');
    else
        $("#To").addClass('changableValue')
});

function ResetDetentionData() {
    $("#RowNumber").val("");
    $("#From").val("");
    $("#From").removeClass('error-textbox');
    $("#To").val("");
    $("#To").removeClass('error-textbox');
    $("#ContainerType").val("0");
    $("#ContainerType").removeClass('error-textbox');
    $("#Charges").val("");
    $("#Charges").removeClass('error-textbox');
    $("#UpdateDetentionCharges").addClass('d-none')
    $("#AddDetentionCharges").removeClass('d-none')
    $('#From').removeAttr("disabled")
    $('#To').removeAttr("disabled")
    $('#ContainerType').removeAttr("disabled")
    $("#To").removeClass('changableValue')
}
function ResetChargesData() {
    $("#ChargesType").val("0");
    $("#ContType").val("0");
    $("#Amount").val("");
    //$("#ChargesType").removeClass('error-textbox');
    $("#ContType").removeClass('error-textbox');
    $("#Amount").removeClass('error-textbox');
}

$("#FormReset").click(function () {
    ResetForm();
})

//FUNCTION FOR GO TO LEDGER
function GoToLedger(e) {
    SetCookie('LedgerId', $("#" + e).val(), 's', 50);
}

document.addEventListener("keydown", function (zEvent) {
    if (zEvent.ctrlKey && zEvent.altKey && (zEvent.key == "j" || zEvent.key == "J")) {
        $('#ShippingLine_List-tab').removeClass('active ');
        $('#ShippingLine_list').removeClass('active show');
        $('#ShippingLine-tab').addClass('active');
        $('#ShippingLine').addClass('active show');
        $("#FormAdd").show();
        $("#FormUpdate").hide();
        $("#FormReset").hide();
        $("#ShippingLine-tab").html("Add Shipping Line/CFS Charges ");
        ResetForm();
        $('#SlabName').focus();
    }
});


function UpdateCharges(e) {
    let Charges = parseInt($("#Charges").val().trim())
    if (isNaN(Charges)) {
        $("#Charges").addClass('error-textbox');
        $("#Charges").focus();
        Toast("Please Enter Amount !", 'Message', 'error');
        return;
    }
    $("#Charges").removeClass('error-textbox');


    let detensionArr = $("#TableDetensionAndDemmCharges tbody").find('tr');
    let CurrFromVal = parseInt($("#From").val().trim());
    let CurrToVal = parseInt($("#To").val().trim());
    if (CurrToVal < CurrFromVal && CurrToVal != 0) {
        $("#To").focus();
        $("#To").addClass('error-textbox');
        Toast(RetrieveMessage(1003), 'Message', 'error');
        return;
    }

    if ($("#To").hasClass('changableValue')) {
        for (let i = 0; i < detensionArr.length; i++) {
            if (parseInt(detensionArr[i].childNodes[0].textContent) === parseInt($("#RowNumber").val())) {
                if (detensionArr[i].childNodes[1].innerText == CurrFromVal) {
                    for (let j = 0; j < a.length; j++) {
                        if (a[j][0][0] == detensionArr[i].childNodes[3].innerText) {

                            let count = (detensionArr[i].childNodes[2].innerText == 0 ? 9999 : detensionArr[i].childNodes[2].innerText) - CurrFromVal;
                            let index = a[j][0].indexOf(CurrFromVal);
                            a[j][0].splice(index, (count + 1));
                        }
                    }
                    detensionArr[i].childNodes[4].innerText = $('#Charges').val()
                    detensionArr[i].childNodes[2].innerText = CurrToVal;

                    for (let j = 0; j < a.length; j++) {
                        if (a[j][0][0] == detensionArr[i].childNodes[3].innerText) {
                            ind = j;
                            for (k = CurrFromVal; k <= (CurrToVal == 0 ? 9999 : CurrToVal); k++) {
                                a[ind][0].push(k);
                            }
                        }
                    }

                    totalDetenDemmCharge = parseFloat((totalDetenDemmCharge - DetenDemmAmtEdit) + ($('#DetentionModalContent').children().eq(4).find('#Charges').val() - 0)).toFixed(2);
                    $('#TableDetensionAndDemmCharges tbody').find('#TotalDetenDemmAmount').text(totalDetenDemmCharge);
                    Toast("Updated Successfully ", 'Message', 'success');
                    $('#DetentionModal').modal('hide');
                    ResetDetentionData();
                }
            }
        }
    } else {
        let rowNum = '';
        if ($("#RowNumber").val() === '1') {
            rowNum = '01';
        }
        else {
            rowNum = $("#RowNumber").val();
        }
        for (let i = 0; i < detensionArr.length; i++) {
            if (detensionArr[i].childNodes[0].textContent === rowNum) {
                detensionArr[i].childNodes[4].innerText = $('#Charges').val()
                totalDetenDemmCharge = parseFloat((totalDetenDemmCharge - DetenDemmAmtEdit) + ($('#DetentionModalContent').children().eq(4).find('#Charges').val() - 0)).toFixed(2);
                $('#TableDetensionAndDemmCharges tbody').find('#TotalDetenDemmAmount').text(totalDetenDemmCharge);
                Toast("Updated Successfully ", 'Message', 'success');
                $('#DetentionModal').modal('hide');
                ResetDetentionData();
                break;
            }
        }
        rowNum = '';
    }
}
