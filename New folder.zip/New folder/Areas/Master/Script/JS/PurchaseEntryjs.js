﻿
let Firstcolumn = "";
let SelectedLedgerBranch = "";
let selectedAccHead = "";
let accheads = [];
let flag = 0;
let purchaseFlag = true;
let name;
let EditPurchaseNo = true;
/*-------------------------------------------------- form list all function and click event start-------------------------------------------------------*/
// DOCUMENT READY FUNCTION 
$(document).ready(function () {
    let vin = setInterval(() => {
        if ($('#BranchId').val() > 0) {
            GeneratePurchaseNo();
            clearInterval(vin);
        }
    }, 1000)
    if (Get_Cookie('LedgerPurchaseSearch') != null) {
        $('#PartyNameSearch').val(Get_Cookie('LedgerPurchaseSearch'));
        EraseCookie('LedgerPurchaseSearch');
    }
    FillTaxCategory();
    FillBranchList('BranchId');
    AutoCompleteAjaxWithClass('GroupName', '/Master/PurchaseEntry/GetGroupName', 'HiddenGroupId');
    AutoCompleteAjax('PartyName', '/Master/PurchaseEntry/GetPartyName', 'PartyNameHiddenId', 'PuchaseGroupSearch');
    PaymentAutoCompleteAjaxAccHead('PurchaseAccHead', '/Master/PurchaseEntry/GetLedgerAutoComplete', 'LedgerUid', null, true);
    let hYu = setInterval(() => {
        if ($('#BranchId').val() != undefined && $('#BranchId').val().length > 0) {
            FillBranchState();
            clearInterval(hYu);
        }

    }, 500);
    if (Get_Cookie("LedgerGroupName") != null) {
        FillPageSizeList('ddlPageSize');
        let RefId = Get_Cookie('LedgerGroupName');
        let substring = RefId.slice(3);
        let a = setInterval(() => {
            if (Get_Cookie("LedgerGroupName") != '') {
                if ($('#BranchId').val() != null) {
                    FormEdit(substring);
                    EraseCookie('LedgerGroupName');
                    clearInterval(a);
                }
            }
        }, 1000);
    } else
        FillPageSizeList('ddlPageSize', FormList);

    $("#PartyNameSearch").focus();
    $(".datepickerAll").datepicker({
        changeMonth: true,
        changeYear: true,
        dateFormat: 'dd/mm/yy'
    });
    $(".mydate").datepicker('setDate', 'today');
    $("#BranchId").select2({
        width: '100%'
    });
    FillGroup('PuchaseGroupSearch');
    LedgerAccHeadautocompleteForSearchLedger();
});



$("#BranchId").change(function () {
    FillBranchState();
});
//FILL PURCHASE ENTRY  TABLE
function FormList(pageindex) {
    try {
        const dataString = {};
        dataString.PageSize = $("#ddlPageSize").val();
        dataString.PageIndex = pageindex;
        dataString.PartyName = $("#PartyNameSearch").val().trim();
        dataString.InvoiceNo = $("#InvoiceNoSearch").val().trim();
        dataString.Date = $("#InvoiceDateSearch").val().trim();
        dataString.JobNoSearch = $("#JobNoSearch").val().trim();
        dataString.OrderBy = $("#sort-column").val().trim() + " " + $("#sort-type").val().trim();
        AjaxSubmission(JSON.stringify(dataString), "/Master/PurchaseEntry/FormList", $('input[name=__RequestVerificationToken]').val()).done(function (result) {
            let obj = result;
            if (obj.status == true) {
                if (obj.responsecode == '100') {
                    let ser = ((parseInt(obj.data.Table1[0].PageIndex) - 1) * parseInt(obj.data.Table1[0].PageSize)) + 1;
                    BindFormList(obj.data.Table, ser);
                    if (obj.data.Table1 != undefined && obj.data.Table1.length > 0) {
                        $(".pagination").BindPaging({
                            ActiveCssClass: "current",
                            PagerCssClass: "pager",
                            PageIndex: parseInt(obj.data.Table1[0].PageIndex),
                            PageSize: parseInt(obj.data.Table1[0].PageSize),
                            RecordCount: parseInt(obj.data.Table1[0].count)
                        });
                    }
                }
                else {
                    Toast(RetrieveMessage(obj.responsecode), "Message", "error");
                }
            }
            else {
                window.location.href = '/ClientLogin/ClientLogin';
            }
        }).fail(function (result) {
            console.log(result.Message);
        });
    }
    catch (e) {
        console.log(e.message);
    }
}

//BIND PURCHASE ENTRY TABLE FUNCTION 
function BindFormList(result, serial_no) {
    $("#tbl_PurchaseEntry tbody tr").remove();

    if (result.length == 0) {
        tr = $('<tr/>');
        tr.append("<td class='text-center' colspan='15'>NO RESULTS FOUND</td>");
        $("#tbl_PurchaseEntry tbody").append(tr);
    }
    else {
        for (i = 0; i < result.length; i++) {
            if (result[i].is_active == "Inactive")
                tr = $(' <tr style="background-color:#fdd2d2;"/>');
            else
                tr = $('<tr/>');

            tr.append("<td class='text-center'><button type='button' onclick='FormEdit(\"" + result[i].PurchaseEntryUid + "\");' class= 'common-btn common-btn-sm'><i class='fa-solid fa-pen-to-square'></i></button > <button type='button' onclick='FormDelete(\"" + result[i].PurchaseEntryUid + "\");' class= 'common-btn common-btn-sm'> <i class='fa-regular fa-trash-can'></i></button ><button onclick='FormPrint(\"" + result[i].PurchaseEntryUid + "\");' class='common-btn common-btn-sm ms-1'><i class='fa-solid fa-print'></i></button></td > ");
            tr.append("<td class='text-left'>" + serial_no + "</td>");
            tr.append("<td class='text-left'>" + result[i].PurchaseEntryUid + "</td>");
            tr.append("<td class='text-center'>" + result[i].BranchName + "</td>");
            tr.append("<td class='text-center'><a href='javascript:void(0)' class='text-decoration-none ' style='color: black !important;' onclick='FormEdit(\"" + result[i].PurchaseEntryUid + "\");'>" + result[i].AccHead + "</a></td>");
            tr.append("<td class='text-center'>" + result[i].InvoiceNo + "</td>");
            tr.append("<td class='text-center'>" + result[i].InvoiceDate + "</td>");
            let multiJobNo = '';
            if (result[i].JobNo != null) {
                result[i].JobNo.split(',').forEach((ele) => { multiJobNo += "<p class='m-0 p-0'>" + ele + "</p>" });
            }
            tr.append("<td class='text-center'>" + multiJobNo + "</td>");
            tr.append("<td class='text-center'>" + parseFloat(result[i].NetAmount).toFixed(2) + "</td>");
            tr.append("<td class='text-center'>" + parseFloat(result[i].TotalAmount).toFixed(2) + "</td>");
            tr.append("<td class='text-center'>" + parseFloat(result[i].TaxAmount).toFixed(2) + "</td>");
            tr.append("<td class='text-center'>" + HandleNullTextValue(result[i].CreatedBy) + "</td>");
            tr.append("<td class='text-center'>" + HandleNullTextValue(result[i].CreatedAt) + "</td>");
            tr.append("<td class='text-center'>" + HandleNullTextValue(result[i].LastUpdatedBy) + "</td>");
            tr.append("<td class='text-center'>" + HandleNullTextValue(result[i].LastUpdatedAt) + "</td>");
            serial_no++;
            $("#tbl_PurchaseEntry tbody").append(tr);
        }

    }

}
//BTN SEARCH CLICK
$("#FormSearch").click(function () {
    FormList(1);
});
function FormSorting(obj) {
    if (Firstcolumn != "") {
        document.getElementById(Firstcolumn).innerHTML = document.getElementById(Firstcolumn).getAttribute("data-column") + " <i style='margin-left:10px;' class='fa-solid fa-sort'></i>";
    }
    let cn = obj.id;
    Firstcolumn = cn;
    let colname = $(obj).data("column");
    $("#sort-column").val(cn.replaceAll("_", ""));
    let sorttype = $("#sort-type").val();
    if (sorttype == "ASC") {
        $("#sort-type").val("DESC");
        $(obj).html(colname + " <i style='margin-left:10px;' class='fa-solid fa-sort-up'></i>");
    } else if (sorttype == "DESC") {
        $("#sort-type").val("ASC");
        $(obj).html(colname + " <i style='margin-left:10px;' class='fa-solid fa-sort-down'></i>");
    }
    FormList(1);
}

//DETENTION TABLE PAGINATION BUTTON CLICK
$(document).on("click", ".pagination .page", function () {
    FormList(($(this).attr('page')));
});

//PAGE SIZE ON CHANGE FUNCTION
$("#ddlPageSize").change(function () {
    FormList(1);
});

//FUNCTION FOR SORTING FIELD
function Sorting(obj) {
    if (Firstcolumn != "") {
        document.getElementById(Firstcolumn).innerHTML = document.getElementById(Firstcolumn).getAttribute("data-column") + " <i class='fa-solid fa-sort'></i>";
    }
    Firstcolumn = obj.id;
    let colname = $(obj).data("column");
    $("#sort-column").val(Firstcolumn);
    let sorttype = $("#sort-type").val();
    if (sorttype == "ASC") {
        $("#sort-type").val("DESC");
        $(obj).html(colname + " <i style='margin-left:10px;' class='fa-solid fa-sort-up'></i>");
    } else if (sorttype == "DESC") {
        $("#sort-type").val("ASC");
        $(obj).html(colname + " <i style='margin-left:10px;' class='fa-solid fa-sort-down'></i>");
    }
    FormList(1);
}


/*-------------------------------------------------- form list all function and click event end-------------------------------------------------------*/

/*-------------------------------------------------- form add update edit delete start-------------------------------------------------------*/

//PURCHASE ENTRY ADD CLICK 
$("#FormAdd").click(function () {
    flag = 0;
    PurchaseAddUpdateValidation();
    if (flag == 0) {
        FormAdd();
    }
});


//ADD PURCHASE ENTRY FUNCTION 
function FormAdd() {
    try {
        const datastring = {};
        let PurchaseTableData = new Array();
        let PurchaseTaxTableData = new Array();
        let PurchasePaymentTableData = new Array();
        datastring.Date = $("#CurrDate").val();
        datastring.InvoiceNo = $("#InvoiceNo").val();
        datastring.InvoiceDate = $("#InvoiceDate").val();
        datastring.PartyName = $("#PartyNameHiddenId").val();
        datastring.AccHeadName = $("#PartyName").val();
        datastring.TotalAmount = $("#TotalAmount").html();
        datastring.RoundOff = $("#RoundOff").html();
        datastring.TotalTaxAmount = $("#TotalTaxAmount").html();
        datastring.NetAmount = $("#NetAmount").html();
        datastring.BranchId = $("#BranchId").val();
        datastring.LedgerBranchId = $("#LedgerBranchAddress").val();
        datastring.GstNo = $("#GstNo").val();
        datastring.Address = $("#BranchAddress").val();
        datastring.BranchState = $("#BranchState").val();
        datastring.ClientState = $("#ClientState").val();
        datastring.PurchaseSerialNo = $("#PurchaseSerialNo").val();

        $("#Purchase_table tbody tr").each(function () {
            let g = {};
            g.SubGroupId = $(this).find(".HiddenGroupId").val();
            g.LedgerId = $(this).find(".HiddenAccountDescId").val();
            g.AccHeadName = $(this).find(".AccountDesc").val();
            g.JobUid = $(this).find(".HiddenJobNo").val();
            g.RecNo = $(this).find(".RecNo").val();
            g.RecDate = $(this).find(".RecDate").val();
            g.Amount = $(this).find(".Amount").val();
            g.TaxAmount = $(this).find(".TaxAmount").val();
            g.TaxCategory = $(this).find(".TaxCategory").val();
            g.TaxPercent = $(this).find(".HiddenTaxPer").val();
            PurchaseTableData.push(g);
        });

        $("#TaxDetails tbody tr").each(function (ind, ele) {
            let s = {};
            if (ind < $("#TaxDetails tbody tr").length - 1) {
                s.AccDesc = $(ele).find(".AccDesc").text();
                s.LedgerUid = $(ele).find(".LedgerId").text();
                s.TaxType = $(ele).find(".TaxName").text();
                s.TaxLedgerId = $(ele).find(".TaxName .TaxLedgerId").val();
                s.TaxableAmount = $(ele).find(".TaxableAmount").text();
                s.TaxAmount = $(ele).find(".TaxAmounts").text();
                PurchaseTaxTableData.push(s);
            }
        })


        $("#TblPaymentCharges tbody tr").each(function (ind, ele) {
            let t = {};
            if ($("#TblPaymentCharges tbody tr").length == 1 && $("#TblPaymentCharges tbody").find("tr:first").find('.PaymentLedgerUid').val() == '')
                return false;
            if (ind < $("#TblPaymentCharges tbody tr").length) {
                t.LedgerUid = $(ele).find(".PaymentLedgerUid").val();
                t.AccDesc = $(ele).find(".PaymentAccDesc").val();
                t.Particular = $(ele).find(".PaymentParitcular").val();
                t.GrossAmount = $(ele).find(".PaymentGrossAmount").val();
                t.PaymentPercentage = $(ele).find(".PaymentPercentage").val();
                t.PaymentAmount = $(ele).find(".PaymentAmount").val();
                PurchasePaymentTableData.push(t);
            }
        })

        datastring.purchaseEntryInvoices = PurchaseTableData;
        datastring.PurchaseTaxModel = PurchaseTaxTableData;
        datastring.PurchasePaymentModel = PurchasePaymentTableData;

        AjaxSubmission(JSON.stringify(datastring), "/Master/PurchaseEntry/FormAdd", $('input[name=__RequestVerificationToken]').val()).done(function (result) {
            let obj = result;
            if (obj.status == true) {
                if (obj.responsecode == '101') {
                    Toast(RetrieveMessage(obj.responsecode), "Message", "success");
                    setTimeout(FormList(1), 500);
                    $("#TimeStamp").val(obj.data.Table1[0]["Timestamp"]);
                    $("#PurchaseId").val(obj.data.Table1[0]["PurchaseEntryUid"]);
                    $("#FormAdd").hide();
                    $("#FormUpdate").show();
                    $("#CreatePdf").show();
                    $("#FormReset").show();
                    $("#PurchaseEntry-tab").html("Edit Purchase Entry");
                }
                else if (obj.responsecode == '1019') {
                    Toast('You Dont Have Permission For Purchase Entry', "Message", "error");
                }
                else {
                    Toast(RetrieveMessage(obj.responsecode), "Message", "error");
                }
            }
            else {
                window.location.href = '/ClientLogin/ClientLogin';
            }
        }).fail(function (result) {
            console.log(result.Message);
        });
    }
    catch (e) {
        console.log(e.message);
    }
}

//EDIT PURCHASE ENTRY FUNCTION 
function FormEdit(e) {
    try {
        const datastring = {};
        datastring.PurchaseId = e;
        AjaxSubmission(JSON.stringify(datastring), "/Master/PurchaseEntry/FormEdit", $('[name="__RequestVerificationToken"]').val()).done(function (data) {
            let obj = data;
            if (obj.status == true) {
                if (obj.responsecode == '100') {

                    TabShow();
                    $("#CreatedByModifiedBy").css('display', 'block');
                    $("#CreatedByModifiedBy").css('width', '100%');
                    $("#myid").css('display', 'block');
                    let CreateTableLength = obj.data.Table3.length;
                    if (CreateTableLength != 0) {
                        $("#CreatedBy").text(obj.data.Table3[0].user_name);
                        $("#CreatedAt").text(obj.data.Table3[0].CreatedAt);
                    }
                    let ModifiedTableLength = obj.data.Table4.length;
                    if (ModifiedTableLength != 0) {
                        $(".Modify").show();
                        $("#ModifiedBy").text(obj.data.Table4[0].user_name);
                        $("#ModifiedAt").text(obj.data.Table4[0].LastUpdatedAt);
                    }
                    else {
                        $(".Modify").hide();
                    }
                    $("#PuchaseGroupSearch").val(obj.data.Table1[0].LedgerGroup);
                    $("#PurchaseId").val(obj.data.Table1[0].PurchaseEntryUid);
                    $("#TimeStamp").val(obj.data.Table1[0].Timestamp);
                    $("#CurrDate").val(obj.data.Table1[0].Date != '1900-01-01' ? obj.data.Table1[0].Date : '');
                    $("#InvoiceNo").val(obj.data.Table1[0].InvoiceNo);
                    $("#InvoiceDate").val(obj.data.Table1[0].InvoiceDate != '1900-01-01' ? obj.data.Table1[0].InvoiceDate : '');

                    SelectedLedgerBranch = obj.data.Table1[0].LedgerBranchId;
                    $("#PartyNameHiddenId").val(obj.data.Table1[0].LedgerId);

                    $("#PartyName").val(obj.data.Table1[0].AccHead);
                    FillLedgerBranch();
                    $("#TotalAmount").html(obj.data.Table1[0].TotalAmount.toFixed(2));
                    $("#RoundOff").html(obj.data.Table1[0].RoundOff.toFixed(2));

                    $("#TotalTaxAmount").html(obj.data.Table1[0].TaxAmount.toFixed(2));
                    $("#NetAmount").html(obj.data.Table1[0].NetAmount.toFixed(2));

                    EditPurchaseNo = false;
                    $("#BranchId").val(obj.data.Table1[0].BranchId).trigger('change');
                    EditPurchaseNo = true;

                    $("#GstNo").val(obj.data.Table1[0].Gstin);
                    $("#BranchAddress").val(obj.data.Table1[0].Address);
                    $("#BranchState").val(obj.data.Table1[0].BranchState);
                    $("#ClientState").val(obj.data.Table1[0].ClientState);


                    let firstChild = $("#Purchase_table").find("tbody tr:first-child");
                    $.each(obj.data.Table2, function (index, ele) {
                        if (index == 0) {

                            let TaxPerLedger = ele.TaxLedgerPer;
                            let Taxable = ele.IsTaxable;
                            if (!TaxPerLedger && (!Taxable || Taxable == false)) {
                                firstChild.find(".Amount ").attr('disabled', 'disabled');
                            }
                            else {
                                firstChild.find(".Amount ").removeAttr("disabled");
                            }
                            selectedAccHead = ele.LedgerId;
                            firstChild.find('.HiddenGroupId').val(ele.SubgroupId);
                            firstChild.find('.GroupName').val(ele.SubgroupHeadName);
                            firstChild.find('.HiddenAccountDescId').val(ele.LedgerId);
                            firstChild.find('.AccountDesc').val(ele.AccHead);
                            firstChild.find('.Particular').val(ele.Particular);
                            firstChild.find('.HiddenJobNo').val(ele.JobUid);
                            if (!ele.JobNo)
                                firstChild.find('.JobNo').attr('disabled', 'disabled');
                            else
                                firstChild.find('.JobNo').removeAttr('disabled');
                            firstChild.find('.JobNo').val(ele.JobNo);
                            firstChild.find('.RecNo').val(ele.RecNo);
                            firstChild.find('.RecDate').val(ele.RecDate);
                            firstChild.find('.Amount').val(ele.Amount.toFixed(2));
                            firstChild.find('.TaxAmount').val(ele.TaxAmount.toFixed(2));
                            firstChild.find('.TaxCategory').val(ele.TaxCategory);
                            firstChild.find('.HiddenTaxPer').val(ele.TaxPercent);


                        }
                        else {

                            firstChild.find('.RecDate').datepicker("destroy");
                            firstChild.find('.RecDate').removeAttr("id");

                            let cloneChild = firstChild.clone();

                            let TaxPerLedger = ele.TaxLedgerPer;
                            let Taxable = ele.IsTaxable;

                            if (!TaxPerLedger && (!Taxable || Taxable == false)) {
                                cloneChild.find(".Amount ").attr('disabled', 'disabled');
                            }
                            else {
                                cloneChild.find(".Amount ").removeAttr("disabled");
                            }
                            cloneChild.find('.GroupName,.AccountDesc,.Particular,.HiddenJobNo,.JobNo,.RecNo,.RecDate,.Amount,.HiddenGroupId,.HiddenAccountDescId,.isTaxable,.TaxPerLedger,.TaxAmount,.HiddenTaxPer').val('');
                            cloneChild.find('.TaxCategory').val('0');
                            cloneChild.find('.HiddenGroupId').val(ele.SubgroupId);
                            cloneChild.find('.GroupName').val(ele.SubgroupHeadName);
                            cloneChild.find('.AccountDesc').val(ele.AccHead);
                            cloneChild.find('.HiddenAccountDescId').val(ele.LedgerId);
                            cloneChild.find('.isTaxable').val(ele.IsTaxable);
                            cloneChild.find('.TaxPerLedger').val(ele.TaxLedgerPer);
                            cloneChild.find('.Particular').val(ele.Particular);
                            cloneChild.find('.HiddenJobNo').val(ele.JobUid);
                            if (!ele.JobNo)
                                cloneChild.find('.JobNo').attr('disabled', 'disabled');
                            else
                                cloneChild.find('.JobNo').removeAttr('disabled');
                            cloneChild.find('.JobNo').val(ele.JobNo);
                            cloneChild.find('.RecNo').val(ele.RecNo);
                            cloneChild.find('.RecDate').val(ele.RecDate);
                            cloneChild.find('.Amount').val(ele.Amount.toFixed(2));
                            cloneChild.find('.TaxAmount').val(ele.TaxAmount.toFixed(2));
                            cloneChild.find('.TaxCategory').val(ele.TaxCategory);
                            cloneChild.find('.HiddenTaxPer').val(ele.TaxPercent);

                            $("#Purchase_table tbody").append(cloneChild);


                        }
                        $(".datepickerAll").datepicker({
                            changeMonth: true,
                            changeYear: true,
                            dateFormat: 'dd/mm/yy'
                        });
                    });
                    let firstChildPayment = $("#TblPaymentCharges").find("tbody tr:first-child");
                    $.each(obj.data.Table6, function (index, ele) {
                        if (index == 0) {

                            firstChildPayment.find('.LedgerUid').val(ele.LedgerUid);
                            firstChildPayment.find('.PaymentAccDesc').val(ele.AccDesc);
                            firstChildPayment.find('.PaymentParitcular').val(ele.Particular);
                            firstChildPayment.find('.PaymentGrossAmount').val(ele.GrossAmount ? formatNumber(ele.GrossAmount) : '');
                            firstChildPayment.find('.PaymentPercentage').val(ele.Paymentpercentage ? formatNumber(ele.Paymentpercentage) : '');
                            firstChildPayment.find('.PaymentAmount').val(ele.PaymentAmount ? formatNumber(ele.PaymentAmount) : '').trigger('blur');
                        }
                        else {
                            let cloneChild = firstChildPayment.clone();

                            cloneChild.find('.LedgerUid,.PaymentAccDesc,.PaymentParitcular,.PaymentGrossAmount,.PaymentPercentage,.PaymentAmount').val('');
                            cloneChild.find('.TaxCategory').val('0');

                            cloneChild.find('.LedgerUid').val(ele.LedgerUid);
                            cloneChild.find('.PaymentAccDesc').val(ele.AccDesc);
                            cloneChild.find('.PaymentParitcular').val(ele.Particular);
                            cloneChild.find('.PaymentGrossAmount').val(ele.GrossAmount ? formatNumber(ele.GrossAmount) : '');
                            cloneChild.find('.PaymentPercentage').val(ele.Paymentpercentage ? formatNumber(ele.Paymentpercentage) : '');
                            cloneChild.find('.PaymentAmount').val(ele.PaymentAmount ? formatNumber(ele.PaymentAmount) : '').trigger('blur');

                            $("#TblPaymentCharges tbody").append(cloneChild);
                        }
                    });
                    $("#PurchaseSerialNo").val(obj.data.Table1[0].PurchaseNo);
                    AddTaxDetail(obj.data.Table5);
                }
                else {
                    Toast(RetrieveMessage(obj.responsecode), "Message", "error");
                }

            }
            else {
                window.location.href = '/ClientLogin/ClientLogin';
            }
        }).fail(function (data) {
            console.log(data.Message);
        });
    }
    catch (e) {
        console.log(e.message);
    }
}

//PURCHASE ENTRY UPDATE CLICK 
$("#FormUpdate").click(function () {
    flag = 0;
    PurchaseAddUpdateValidation();
    if (flag == 0) {
        FormUpdate();
    }
});

//UPDATE PURCHASE ENTRY FUNCTION 
function FormUpdate() {
    try {

        const datastring = {};
        let PurchaseTableData = new Array();
        let PurchaseTaxTableData = new Array();
        let PurchasePaymentTableData = new Array();

        datastring.Date = $("#CurrDate").val();
        datastring.InvoiceNo = $("#InvoiceNo").val();
        datastring.InvoiceDate = $("#InvoiceDate").val();
        datastring.PartyName = $("#PartyNameHiddenId").val();
        datastring.AccHeadName = $("#PartyName").val();
        datastring.TotalAmount = $("#TotalAmount").html();
        datastring.RoundOff = $("#RoundOff").html();
        datastring.TotalTaxAmount = $("#TotalTaxAmount").html();
        datastring.NetAmount = $("#NetAmount").html();
        datastring.BranchId = $("#BranchId").val();
        datastring.LedgerBranchId = $("#LedgerBranchAddress").val();
        datastring.GstNo = $("#GstNo").val();
        datastring.Address = $("#BranchAddress").val();
        datastring.BranchState = $("#BranchState").val();
        datastring.ClientState = $("#ClientState").val();
        datastring.PurchaseSerialNo = $("#PurchaseSerialNo").val();
        datastring.timestamp = $("#TimeStamp").val();
        datastring.PurchaseId = $("#PurchaseId").val();

        $("#Purchase_table tbody tr").each(function () {
            let g = {};
            g.SubGroupId = $(this).find(".HiddenGroupId").val();
            g.LedgerId = $(this).find(".HiddenAccountDescId").val();
            g.AccHeadName = $(this).find(".AccountDesc").val();
            g.Particular = $(this).find(".Particular").val();
            g.JobUid = $(this).find(".HiddenJobNo").val();
            g.RecNo = $(this).find(".RecNo").val();
            g.RecDate = ($(this).find(".RecDate").val() == "" ? null : $(this).find(".RecDate").val());
            g.Amount = $(this).find(".Amount").val();
            g.TaxAmount = $(this).find(".TaxAmount").val();
            g.TaxCategory = $(this).find(".TaxCategory").val();
            g.TaxPercent = $(this).find(".HiddenTaxPer").val();
            PurchaseTableData.push(g);
        });
        $("#TaxDetails tbody tr").each(function (ind, ele) {
            let s = {};
            if (ind < $("#TaxDetails tbody tr").length - 1) {
                s.AccDesc = $(ele).find(".AccDesc").text();
                s.LedgerUid = $(ele).find(".LedgerId").text();
                s.TaxType = $(ele).find(".TaxName").text();
                s.TaxLedgerId = $(ele).find(".TaxName .TaxLedgerId").val();
                s.TaxableAmount = $(ele).find(".TaxableAmount").text();
                s.TaxAmount = $(ele).find(".TaxAmounts").text();

                PurchaseTaxTableData.push(s);
            }

        })
        $("#TblPaymentCharges tbody tr").each(function (ind, ele) {
            let t = {};
            if ($("#TblPaymentCharges tbody tr").length == 1 && $("#TblPaymentCharges tbody").find("tr:first").find('.PaymentLedgerUid').val() == '')
                return false;
            if (ind < $("#TblPaymentCharges tbody tr").length) {
                if (ind < $("#TblPaymentCharges tbody tr").length) {
                    t.LedgerUid = $(ele).find(".PaymentLedgerUid").val();
                    t.AccDesc = $(ele).find(".PaymentAccDesc").val();
                    t.Particular = $(ele).find(".PaymentParitcular").val();
                    t.GrossAmount = $(ele).find(".PaymentGrossAmount").val();
                    t.PaymentPercentage = $(ele).find(".PaymentPercentage").val();
                    t.PaymentAmount = $(ele).find(".PaymentAmount").val();
                    PurchasePaymentTableData.push(t);
                }
            }

        })
        datastring.purchaseEntryInvoices = PurchaseTableData;
        datastring.PurchaseTaxModel = PurchaseTaxTableData;
        datastring.PurchasePaymentModel = PurchasePaymentTableData;

        AjaxSubmission(JSON.stringify(datastring), "/Master/PurchaseEntry/FormUpdate", $('input[name=__RequestVerificationToken]').val()).done(function (result) {
            let obj = result;
            if (obj.status == true) {
                if (obj.responsecode == '107') {
                    Toast(RetrieveMessage(obj.responsecode), "Message", "success");
                    $("#TimeStamp").val(obj.data.Table1[0].Timestamp);
                    setTimeout(FormList(1), 500);
                }
                else if (obj.responsecode == '1019') {
                    Toast('You Dont Have Permission For Purchase Entry', "Message", "error");
                }
                else {
                    Toast(RetrieveMessage(obj.responsecode), "Message", "error");
                }
            }
            else {
                window.location.href = '/ClientLogin/ClientLogin';
            }
        }).fail(function (result) {
            console.log(result.Message);
        });
    }
    catch (e) {
        console.log(e.message);
    }
}

//DELETE GROUP FUNCTION
function FormDelete(e) {
    try {
        $.confirm({
            title: '',
            content: 'Are You Sure Want To Delete ?',
            type: 'red',
            boxWidth: '300px',
            useBootstrap: false,
            columnClass: 'small',
            containerFluid: true,
            typeAnimated: true,
            buttons: {
                tryAgain: {
                    text: 'Confirm',
                    btnClass: 'btn-red',
                    action: function () {

                        const datastring = {};
                        datastring.PurchaseId = parseInt(e);
                        AjaxSubmission(JSON.stringify(datastring), "/Master/PurchaseEntry/FormDelete", $('[name="__RequestVerificationToken"]').val()).done(function (data) {
                            let obj = data;
                            if (obj.status == true) {
                                if (obj.responsecode == '102') {
                                    Toast(RetrieveMessage(obj.responsecode), "Message", "success");
                                    FormList(1);
                                    GeneratePurchaseNo();
                                }
                                else {
                                    Toast(RetrieveMessage(obj.responsecode), "Message", "error");
                                }
                            }
                            else {
                                window.location.href = 'ClientLogin/ClientLogin';
                            }
                        }).fail(function (data) {
                            console.log(data.Message);
                        });
                    }
                },
                close: function () {
                    //HideLoader();
                }
            }
        });
    }
    catch (e) {
        console.log(e.message);
    }
}
/*-------------------------------------------------- form add update edit delete end-------------------------------------------------------*/

/*-------------------------------------------------- add more code and tabshow tabhide and reset form start ---------------------------------------------*/
//ADD MORE FOR PURCHASE ENTRY 
$("#AddRow").click(function () {
    $("#RemoveRow").removeAttr('disabled');

    let tbody = $("#Purchase_table").find("tbody");
    let FirstTr = $(tbody).find("tr:first");
    FirstTr.find('.RecDate').datepicker("destroy");
    FirstTr.find('.RecDate').removeAttr("id");

    let NewRow = $(FirstTr).clone();

    NewRow.find('.GroupName,.HiddenGroupId,.AccountDesc,.HiddenAccountDescId,.isTaxable,.TaxPerLedger,.Particular,.JobNo,.HiddenTaxPer').val('');
    NewRow.find('.RecNo').val($("#InvoiceNo").val());
    NewRow.find('.RecDate').val($("#InvoiceDate").val());
    NewRow.find('.Amount,.TaxAmount').val('0.00').removeAttr('disabled');
    NewRow.find('.JobNo').attr('disabled', 'disabled');

    $("#Purchase_table").append(NewRow);
    let LastTr = $(tbody).find("tr:last");
    LastTr.find('.GroupName').focus();


    $(".datepickerAll").datepicker({
        changeMonth: true,
        changeYear: true,
        dateFormat: 'dd/mm/yy'
    });
});
//ADD MORE FOR PAYMENT ENTRY
$("#AddRowPayment").click(function () {
    $("#RemovePaymentRow").removeAttr('disabled');

    let tbody = $("#TblPaymentCharges").find("tbody");
    let FirstTr = $(tbody).find("tr:first");

    let NewRow = $(FirstTr).clone();

    NewRow.find('.LedgerUid,.PurchaseAccHead,.PaymentParitcular,.PaymentGrossAmount,.PaymentPercentage,.PaymentAmount').val('');

    $("#TblPaymentCharges").append(NewRow);
    let LastTr = $(tbody).find("tr:last");
    LastTr.find('.PaymentAccDesc').focus();
});

//DELETE ROW FOR PURCHASE ENTRY 
function DeletePurchaseEntryRow(obj) {
    let rowCount = $("#Purchase_table tbody tr").length;

    if (rowCount > 1) {
        $(obj).parent().parent().remove();
    }
    else {
        $("#RemoveRow").attr("disabled", "disabled");
    }
}
//DELETE ROW FOR PURCHASE ENTRY
function DeletePaymentRow(obj) {
    let rowCount = $("#TblPaymentCharges tbody tr").length;

    if (rowCount > 1) {
        $(obj).parent().parent().remove();
    }
    else {
        //$(obj).parent().parent().find('.ClientId,.ParitcularName,.ParticularId,.ParitcularName,.GrossAmount,.Percentage').val('');
        //$(obj).parent().parent().find('.Amount').val('0.00');
        $("#RemovePaymentRow").attr("disabled", "disabled");
    }
}

//FUNCTION FOR TAB SHOW
function TabShow() {
    $('#PurchaseEntry_List-tab').removeClass('active');
    $('#PurchaseEntry-tab').addClass('active');
    $('#PurchaseEntry_List').removeClass('active show');
    $('#PurchaseEntry').addClass('active show');
    $("#FormAdd").hide();
    $("#FormUpdate").show();
    $("#CreatePdf").show();
    $("#FormReset").show();
    $("#PurchaseEntry-tab").html("Edit Purchase Entry");
}

//FUNCTION FOR TAB HIDE
function TabHide() {
    $('#PurchaseEntry-tab').removeClass('active');
    $('#PurchaseEntry_List-tab').addClass('active ');
    $('#PurchaseEntry_List').addClass('active show');
    $('#PurchaseEntry').removeClass('active show');
    $("#FormAdd").show();
    $("#FormUpdate").hide();
    $("#CreatePdf").hide();
    $("#FormReset").hide();
    $("#PurchaseEntry-tab").html("Add Purchase Entry");
    //setTimeout(() => {
    //    GeneratePurchaseNo();
    //}, 1000);
}
function ResetForm() {
    EditPurchaseNo = true;
    name = '';
    RemoveAllError('PurchaseEntry');
    $("#myid").css('display', 'none');
    $("#PurchaseId,#PurchaseSerialNo,#PartyName,#PartyNameHiddenId,#BranchAddress,#GstNo,#InvoiceNo,#TimeStamp,#HiddenIsSez").val('');
    $("#PuchaseGroupSearch").val(0);
    $("#TotalAmount,#NetAmount,#RoundOff,#TotalTaxAmount,#NetAmount,#LedgerBranchAddress,#PaymentAmt,#RoundOffPayment,#NetPaybleAmount").html('');
    FillBranchList('BranchId');

    let hYu = setInterval(() => {
        if ($('#BranchId').val() != undefined && $('#BranchId').val().length > 0) {
            FillBranchState(true);
            clearInterval(hYu);
        }

    }, 500);
    $(".mydate").datepicker('setDate', 'today');
    $("#TaxTable").css('display', 'none');
    $("#TotalTaxAmounts,#TotalTaxableAmounts,#CreatedBy,#CreatedAt,#ModifiedBy,#ModifiedBy,#ModifiedAt").text('');
    $("#CreatedByModifiedBy").css('display', 'none');
    $("#TaxDetails tbody tr").remove();
    $("#TblPaymentCharges tbody tr").not(':first').remove();
    $("#TblPaymentCharges tbody").find('tr:first').find('.LedgerUid,.PaymentAccDesc,.PaymentParitcular,.PaymentGrossAmount,.PaymentPercentage,.PaymentAmount').val('');
    $("#FormAdd").show();
    $("#FormUpdate").hide();
    $("#CreatePdf").hide();
    $("#FormReset").hide();
    $("#PurchaseEntry-tab").html("Add Purchase Entry");
    let tbody = $("#Purchase_table").find("tbody");
    let Tr = $(tbody).find("tr");

    let rowCount = Tr.length;
    if (rowCount > 1) {
        $("#Purchase_table tbody tr").each(function (index, ele) {
            if (index > 0)
                $(ele).remove();
            else {
                $(ele).find(".AccountDesc,.TaxAmount,.HiddenTaxPer,.GroupName,.HiddenAccountDescId,.Particular,.JobNo,.RecNo,.RecDate").val('');
                $(ele).find(".JobNo").attr('disabled', 'disabled');
                $(ele).find(".Amount").val('0.00');
                $(ele).find(".TaxCategory").val('0');

                $("#Purchase_table").find("tbody").append(ele);
            }
        });

    }
    else {
        Tr.find(".AccountDesc,.TaxAmount,.HiddenTaxPer,.GroupName,.HiddenAccountDescId,.Particular,.JobNo,.RecNo,.RecDate").val('');
        Tr.find(".JobNo").attr('disabled', 'disabled');
        Tr.find(".Amount").val('0.00');
        Tr.find(".TaxCategory").val('0');

        $("#Purchase_table").find("tbody").append(Tr);
    }
    setTimeout(() => {
        GeneratePurchaseNo();
    }, 100);
}

//PURCHASE LIST TAB CLICK FUNCTION 
$('#PurchaseEntry_List-tab').click(function () {
    ResetForm();
    TabHide();
});

$(".PurchaseEntry_List").click(function () {
    $("#PartyNameSearch").focus();
})

/*-------------------------------------------------- add more code  and tabshow tabhide and reset form end ---------------------------------------------*/

/*-------------------------------------------------- Autocomplete code start ---------------------------------------------*/
//AUTOCOMPLETE ACC HEAD IN ADD MORE 
function AutocompleteLedger(e) {
    let whereConditionVal = $(e).parents('tr').find('.HiddenGroupId').val();
    let CurrentId = $(e).attr('id');
    AutoCompleteAjaxWithClassWithColumn(CurrentId, "/Master/PurchaseEntry/GetAccountDesc", "HiddenAccountDescId", whereConditionVal);
}
function AutocompletePartyName(e) {
    let CurrentId = $(e).attr('id');
    AutoCompleteAjaxWithId(CurrentId, "/Master/PurchaseEntry/GetPartyName", "PartyNameHiddenId");
}

//COMMON FUNCTION FOR AUTOCOMPLETE  WITH ID
function AutoCompleteAjaxWithId(id, PageUrl, HiddenId, WhereConditionId) {
    $("#" + id).autocomplete({
        source: function (request, response) {
            $.ajax({
                type: 'POST',
                url: PageUrl,
                dataType: "json",
                async: false,
                data: { SearchField: request.term, WhereConditionId: WhereConditionId },
                success: function (result) {
                    if (result.status == true) {
                        if (result.responsecode == '100') {
                            response($.map(result.data.Table, function (item, id) {
                                return {
                                    label: item.name,
                                    value: item.name,
                                    id: item.id
                                };
                            }));
                        }
                    }
                    else {
                        window.location.href = '/ClientLogin/ClientLogin';
                    }
                },

            });
        },
        minLength: 1,
        selectFirst: true,
        selectOnly: true,
        select: function (e, i) {
            $("#" + HiddenId).val(i.item.id).trigger('change');
            $(".HiddenId").val(i.data.id);
        },
        change: function (e, i) {
            if (i.item == null || i.item == undefined) {
                $("#" + HiddenId).val('');
                $("#LedgerBranchAddress").val("");
                $("#BranchAddress").val("");
            }
        }
    });

}

// AUTOCOMPLETE WITH CLASS FOR ADD MORE WITH OTHER COLUMNS 

function AutoCompleteAjaxWithClassWithColumn(className, PageUrl, HiddenId, WhereConditionId) {
    $("." + className).autocomplete({
        source: function (request, response) {
            $.ajax({
                type: 'POST',
                url: PageUrl,
                dataType: "json",
                async: false,
                data: { SearchField: request.term, WhereConditionId: WhereConditionId },
                success: function (result) {
                    if (result.status == true) {
                        if (result.responsecode == '100') {
                            response($.map(result.data.Table, function (item, id) {
                                return {
                                    label: item.name,
                                    value: item.name,
                                    id: item.id,
                                    TaxCategory: item.TaxCategory,
                                    JobExpense: item.JobExpense,
                                };
                            }));
                        }
                    }
                    else {
                        window.location.href = '/ClientLogin/ClientLogin';
                    }
                }
            });
        },

        minLength: 1,
        selectFirst: true,
        selectOnly: true,
        select: function (e, i) {

            let parentTr = $(this).parents('tr');
            parentTr.find("." + HiddenId).val(i.item.id);
            parentTr.find(".JobExpense").val(i.item.JobExpense);

            let jobexpence = i.item.JobExpense;
            if (jobexpence == true) {
                parentTr.find(".JobNo").removeAttr("disabled");
                parentTr.find(".JobNo").removeAttr("tabindex");
            }
            else {
                parentTr.find(".JobNo").prop('disabled', true);
                parentTr.find(".JobNo").attr("tabindex");
                parentTr.find(".JobNo").val('');
            }
        },
        change: function (e, i) {
            let parentTr = $(this).parents('tr');

            let jobexpence = '';
            if (i.item == null || i.item == undefined) {
                jobexpence = false
                parentTr.find("." + HiddenId).val('');
            } else
                jobexpence = i.item.JobExpense;
            if (jobexpence == true) {
                parentTr.find(".JobNo").removeAttr("disabled");
                parentTr.find(".JobNo").removeAttr("tabindex");
            }
            else {

                parentTr.find(".JobNo").attr("disabled");
                parentTr.find(".JobNo").attr("tabindex");
                parentTr.find(".JobNo").val('');
            }
        }

    });

}

//AUTOCOMPLETE FUNCTION FOR FILL GROUP NAME 
function AutocompleteGroupName(e) {
    let CurrentId = $(e).attr('id');
    AutoCompleteAjaxWithClass(CurrentId, "/Master/PurchaseEntry/GetGroupName", "HiddenGroupId");
}

function AutoCompleteAjaxWithClassJobNo(className, PageUrl, HiddenId, WhereConditionId) {
    $("." + className).autocomplete({
        source: function (request, response) {
            $.ajax({
                type: 'POST',
                url: PageUrl,
                dataType: "json",
                async: false,
                data: { SearchField: request.term, WhereConditionId: WhereConditionId },
                success: function (result) {
                    if (result.status == true) {
                        if (result.responsecode == '100') {
                            response($.map(result.data.Table, function (item, id) {
                                return {
                                    label: item.JobNo,
                                    value: item.JobNo,
                                    id: item.JobUid,

                                };
                            }));
                        }
                    }
                    else {
                        window.location.href = '/ClientLogin/ClientLogin';
                    }
                }
            });
        },
        minLength: 1,
        selectFirst: true,
        selectOnly: true,
        select: function (e, i) {
            let parentTr = $(this).parents('tr');
            parentTr.find("." + HiddenId).val(i.item.id);
        },
        change: function (e, i) {
            if (i.item == null || i.item == undefined) {
                let parentTr = $(this).parents('tr');
                parentTr.find("." + HiddenId).val('');
            }
        }

    });
}

//AUTOCOMPLETE ACC HEAD IN ADD MORE 
function AutocompleteJobNo(e) {
    let whereConditionVal = $(e).parents('tr').find('.HiddenAccountDescId').val();
    let CurrentId = $(e).attr('id');
    AutoCompleteAjaxWithClassJobNo(CurrentId, "/Master/PurchaseEntry/GetJobNo", "HiddenJobNo", whereConditionVal);
}

/*-------------------------------------------------- Autocomplete code end ---------------------------------------------*/

/*-------------------------------------------------- Bind Dropdown and onchange and onblur and oninput start ---------------------------------------------*/

//LEDGER BRANCH ADDRESS ON CHANGE FUNCTION 
function BindAddressLedger() {
    if ($("#PartyNameHiddenId").val().length <= 0)
        $("#LedgerBranchAddress,#GstNo,#BranchAddress,#HiddenIsSez").val('');

    if ($("#LedgerBranchAddress").val() == '0')
        FillLedgerAddress(false, $("#PartyNameHiddenId").val());

    else
        FillLedgerAddress(true, $("#LedgerBranchAddress").val());
};

//FUNCTION FOR BIND DROPDOWN WITH CLASS
function BindDropdownClass(data, Dropdown_Class, Value, text, ZeroIndex) {
    if (data == null) {
        $('.' + Dropdown_Class).html('<option value="0">' + ZeroIndex + '</option>');
    } else {
        const DataCount = data.length;
        if (data != undefined && DataCount > 0) {
            let Data = '';
            if (ZeroIndex != '0')
                Data = '<option value="0">' + ZeroIndex + '</option>';
            for (let i = 0; i < data.length; i++)
                Data += '<option value="' + data[i][Value] + '">' + data[i][text] + '</option>';
            $('.' + Dropdown_Class).html(Data);
        }
        else
            $('.' + Dropdown_Class).html('<option value="0">' + ZeroIndex + '</option>');
    }
}

function FillLedgerBranch() {
    try {
        const dataString = {};
        let DropId = parseInt($('#PartyNameHiddenId').val().trim());

        if (isNaN(DropId)) {
            $('#LedgerBranchAddress').html('');
            $('#GstNo,#BranchAddress').val('');
        }
        else {
            //ShowLoader();
            dataString.Id = DropId;
            AjaxSubmission(JSON.stringify(dataString), '/Master/_Layout/FillLedgerBranch', $('input[name=__RequestVerificationToken]').val()).done(function (result) {
                let obj = result;
                if (obj.status == true) {
                    if (obj.responsecode == '100') {
                        BindDropdown(obj.data.Table, 'LedgerBranchAddress', 'BranchUid', 'BranchName', 'Default Address');

                    } else {
                        BindDropdown(null, 'LedgerBranchAddress', 'BranchUid', 'BranchName', 'Default Address');

                    }

                    if (SelectedLedgerBranch.length == 0) {
                        $("#LedgerBranchAddress").val(0).trigger('change');
                    }
                    else {
                        $("#LedgerBranchAddress").val(SelectedLedgerBranch).trigger('change');
                        SelectedLedgerBranch = "";
                    }
                    name = $("#PartyNameHiddenId").val();
                } else
                    window.location.href = '/ClientLogin/ClientLogin';
            }).fail(function (result) {
                console.log(result.Message);
            });
        }

    } catch (e) {
        console.log(e.message);
    }

}

$("#PartyName").on('input', function () {
    name = '';
    $("#PartyNameHiddenId").val('');
});

$("#PartyName").blur(function () {
    if (name != $("#PartyNameHiddenId").val()) {
        $("#BranchAddress,#GstNo,#ClientState,#HiddenIsSez").val('');
        $("#LedgerBranchAddress").html('');
        if ($("#PartyNameHiddenId").val().trim().length > 0)
            FillLedgerBranch();
    } else if ($("#PartyNameHiddenId").val() == '') {
        $("#BranchAddress,#GstNo,#ClientState,#HiddenIsSez").val('');
        $("#LedgerBranchAddress").html('');
    }
});
$(document).on('change', '.GroupName', function () {
    if ($(this).siblings(".HiddenGroupId").val() == '') {
        $(this).parent().parent().find(".isTaxable,.AccountDesc,.TaxPerLedger,.HiddenAccountDescId,.JobExpense").val('');
    }
});
$(document).on('input', '.GroupName', function () {
    $(this).parent().parent().find(".HiddenGroupId,.AccountDesc,.HiddenAccountDescId,.JobExpense").val('');
    $("#JobNo").attr('disabled', 'disabled');
});

$(document).on('input', '.AccountDesc', function () {
    $(this).parent().parent().find(".HiddenAccountDescId,.JobExpense").val('');
    $(this).parent().parent().find(".JobNo").attr('disabled', 'disabled');
});

/*-------------------------------------------------- Bind Dropdown and onchange and onblur and oninput end ---------------------------------------------*/


/*-----------------------------------------------------------  Create pdf start-------------------------------------------------------------------*/
$("#CreatePdf").click(function () {
    if ($("#PurchaseId").val() != '') {
        DownloadPurchaseReport($("#PurchaseId").val());
    }
});
function FormPrint(PurchaseId) {
    if (PurchaseId != '') {
        DownloadPurchaseReport(PurchaseId);
    }
}
function DownloadPurchaseReport(PurchaseId) {
    try {
        const datastring = {};

        datastring.PurchaseId = PurchaseId;
        AjaxSubmission(JSON.stringify(datastring), "/Master/PurchaseEntry/DownloadPurchaseReport", $('input[name=__RequestVerificationToken]').val()).done(function (result) {
            let obj = result;
            if (obj.status == true) {
                if (obj.responsecode == '100') {
                    window.open($("#PurchasePdf").attr('href'), '_blank');

                }
                else {
                    Toast(RetrieveMessage(obj.responsecode), "Message", "error");
                }
            }
            else {
                window.location.href = '/ClientLogin/ClientLogin';
            }
            //HideLoader();
        }).fail(function (result) {
            console.log(result.Message);
            //HideLoader();
        });
    }
    catch (e) {

    }

}
/*-----------------------------------------------------------  Create pdf end-------------------------------------------------------------------*/

/*-----------------------------------------------------------  Calculate Tax Start-------------------------------------------------------------------*/
function FillTaxCategory() {
    try {
        //ShowLoader();
        AjaxSubmission(null, "/Master/_Layout/GetTaxCategory", $('input[name=__RequestVerificationToken]').val()).done(function (result) {
            let obj = result;
            if (obj.status == true) {
                if (obj.responsecode == '100') {
                    BindDropdownClass(obj.data.Table, 'TaxCategory', 'CategoryUid', 'CategoryName', '-----Select-----');
                }
                else if (obj.responsecode == '604') {
                    BindDropdownClass(null, 'TaxCategory', 'CategoryUid', 'CategoryName', '-----Select-----');
                }
                else {
                    Toast(RetrieveMessage(obj.responsecode), "Message", "error");
                }
            }
            else {
                window.location.href = '/ClientLogin/ClientLogin';
            }
            //HideLoader();
        }).fail(function (result) {
            console.log(result.Message);
            //HideLoader();
        });
    }
    catch (e) {
        console.log(e.message);
        //HideLoader();
    }
}

function CalculateTax(e) {
    try {
        if ($("#PartyNameHiddenId").val() == '') {
            Toast(RetrieveMessage(911), 'Message', 'error');
            return;
        }
        else {
            let BranchState = $("#BranchState").val();
            let ClientState = $("#ClientState").val();
            let CategoryId = $(e).val();

            const dataString = {};
            dataString.CategoryId = CategoryId;
            dataString.BranchState = BranchState;
            dataString.ClientState = ClientState;
            AjaxSubmission(JSON.stringify(dataString), "/Master/PurchaseEntry/CalculateTax", $('input[name=__RequestVerificationToken]').val()).done(function (result) {
                let obj = result;
                if (obj.status == true) {
                    if (obj.responsecode == '100') {
                        let parentTr = $(e).parents('tr');

                        $(parentTr).find('.HiddenTaxPer').val(obj.data.Table[0].TotalTax);
                        $(parentTr).find(".Amount").trigger("change");
                    }
                    else {
                        Toast(RetrieveMessage(obj.responsecode), "Message", "error");
                    }
                }
                else {
                    window.location.href = '/ClientLogin/ClientLogin';
                }
            }).fail(function (result) {
                console.log(result.Message);
            });

        }

    }
    catch (e) {
        console.log(e.message);
    }
}

function CalculateTaxAmount(e) {
    let Amount = 0;
    let Tax = 0;
    let ParentTr = $(e).parent().parent();
    let TaxValue = $(ParentTr).find(".HiddenTaxPer").val();
    if ($(ParentTr).find(".Amount").val() != "0.00") {

        Amount = $(ParentTr).find(".Amount").val();
        Tax = (Amount * TaxValue) / 100;

        $(ParentTr).find(".TaxAmount").val(parseFloat(Tax).toFixed(2));
    }
    TotalPaymetAmount();
}

function GetTotal() {

    let grandTotal = 0;
    let TaxAmount = 0;

    $.each($('#Purchase_table').find('.total'), function (index, ele) {
        if ($(ele).val() != '' && !isNaN($(ele).val())) {
            grandTotal += parseFloat($(ele).val());

        }
    });
    $.each($('#Purchase_table').find('.TaxAmount'), function (index, ele) {
        if ($(ele).val() != '' && !isNaN($(ele).val())) {
            TaxAmount += parseFloat($(ele).val());
        }
    });

    $("#TotalAmount").html(parseFloat(grandTotal).toFixed(2));
    $("#TotalTaxAmount").html(parseFloat(TaxAmount).toFixed(2));
    let TotalWithTax = parseFloat(grandTotal) + parseFloat(TaxAmount);
    let RoundOffAmount = Math.round(parseFloat(TotalWithTax).toFixed(2));
    let RoundOff = parseFloat(TotalWithTax) - parseFloat(RoundOffAmount);
    $("#RoundOff").html(Math.abs(parseFloat(RoundOff.toFixed(2))));
    $("#NetAmount").html(parseFloat(RoundOffAmount).toFixed(2));
    TotalPaymetAmount();
}

function AddTaxDetail(Result) {
    let TaxAmounts = 0;
    let TaxableAmmounts = 0;

    if (Result != null) {
        $("#TaxDetails tbody tr").remove();
        for (i = 0; i < Result.length; i++) {


            tr = $('<tr/>');
            tr.append("<td class='AccDesc'>" + Result[i].AccDesc + "</td>");
            tr.append("<td class='LedgerId d-none'>" + Result[i].LedgerId + "</td>");
            tr.append("<td class='TaxName'>" + Result[i].TaxName + "<input type='hidden' class='TaxLedgerId' value='" + Result[i].TaxLedgerId + "'  /></td>");
            tr.append("<td class='text-end TaxableAmount'>" + parseFloat(Result[i].TaxableAmount).toFixed(2) + "</td>");
            tr.append("<td class='text-end TaxAmounts'>" + parseFloat(Result[i].TaxAmount).toFixed(2) + "</td>");
            $("#TaxDetails tbody").append(tr);

        }


        let RowCount = $("#TaxDetails tbody tr").length;
        if (RowCount != 0) {
            tr = $('<tr/>');
            tr.append('<td></td>');
            tr.append('<td></td>');
            tr.append('<td class="Tabletdwidth text-end" style="color: #1f242a; font-weight: 600;"><span id="TotalTaxableAmounts">' + parseFloat($("#TotalAmount").text()).toFixed(2) + '</span></td>');
            tr.append('<td class="Tabletdwidth text-end" style="color: #1f242a; font-weight: 600;"><span id="TotalTaxAmounts">' + parseFloat($("#TotalTaxAmount").text()).toFixed(2) + '</span></td>')
            $("#TaxDetails tbody").append(tr);

        }
    }
}

function BindTaxDetailsTable(e) {
    try {
        let flag = 0;
        let CategoryId = 0;

        let HiddenId = 0;
        let PurchaseTableData = new Array();
        $("#Purchase_table tbody tr").each(function (ind, ele) {
            if ($(ele).find(".HiddenGroupId").val().length != 0) {
                if ($(ele).find(".HiddenAccountDescId").val().length > 0) {
                    let g = {};
                    CategoryId = $(this).find(".TaxCategory").val();

                    g.CategoryId = $(this).find(".TaxCategory").val();
                    g.TaxableAmount = $(this).find('.Amount').val();
                    g.AccDescHiddenId = $(this).find(".HiddenAccountDescId").val();
                    g.AccDesc = $(this).find(".AccountDesc").val();

                    PurchaseTableData.push(g);
                }
            }
            else {
                flag = 1;
            }
        });

        if (flag == 0) {
            if ($("#PartyNameHiddenId").val() == '') {
                Toast(RetrieveMessage(911), 'Message', 'error');
                return;
            }
            else {
                let BranchState = $("#BranchState").val();
                let ClientState = $("#ClientState").val();
                let IsSez = $("#HiddenIsSez").val();

                const dataString = {};
                dataString.purchaseTaxTable = PurchaseTableData;
                dataString.BranchState = BranchState;
                dataString.ClientState = ClientState;
                dataString.IsSez = IsSez;
                AjaxSubmission(JSON.stringify(dataString), "/Master/PurchaseEntry/BindTaxTable", $('input[name=__RequestVerificationToken]').val()).done(function (result) {

                    let obj = result;
                    if (obj.status == true) {
                        if (obj.responsecode == '100') {
                            AddTaxDetail(obj.data);
                        }
                        else {
                            Toast(RetrieveMessage(obj.responsecode), "Message", "error");
                        }
                    }
                    else {
                        window.location.href = '/ClientLogin/ClientLogin';
                    }
                }).fail(function (result) {
                    console.log(result.Message);
                });
            }
        }
    }
    catch (e) {
        console.log(e.message);
    }

}
/*-----------------------------------------------------------  Calculate Tax End-------------------------------------------------------------------*/
function GoToLedger() {
    if ($("#PartyNameHiddenId").val() == '') {
        if (sessionStorage.getItem("LedgerId") != 0) {
            sessionStorage.setItem("LedgerId", 0);
        }
        sessionStorage.setItem("LedgerId", 0);

    }
    else {
        if (sessionStorage.getItem("LedgerId") != 0) {
            sessionStorage.setItem("LedgerId", 0);
        }
        sessionStorage.setItem("LedgerId", $("#PartyNameHiddenId").val());
    }

}

$("#FormReset").click(function () {
    ResetForm();
});


//FUNCTION FOR GO TO LEDGER
function GoToLedger(e) {
    SetCookie('LedgerId', $("#" + e).val(), 's', 50);
}

//FUNCTION FOR GO TO LEDGER FOR CLASS
function GoToLedgerForClass(e, ClsName) {
    SetCookie('LedgerId', $(e).parent().parent().find('.' + ClsName).val(), 's', 50);
}

function FillLedgerAddress(FromLedgerBranch, Id) {
    try {
        const datastring = {};
        datastring.Id = Id;
        datastring.BranchId = $("#BranchId").val();
        datastring.FromLedgerBranch = FromLedgerBranch;
        AjaxSubmission(JSON.stringify(datastring), "/Master/PurchaseEntry/FillLedgerAddress", $('input[name=__RequestVerificationToken]').val()).done(function (result) {
            let obj = result;

            if (obj.status == true) {
                if (obj.responsecode == '100') {

                    $("#GstNo").val(obj.data[0].GstNo);
                    $("#BranchAddress").val(obj.data[0].Address);
                    $("#ClientState").val(obj.data[0].ClientState);
                    $("#HiddenIsSez").val(obj.data[0].IsSez);
                    BindTaxDetailsTable();
                }
                else if (obj.responsecode == '604') {
                    $("#GstNo,#BranchAddress,#ClientState,#HiddenIsSez").val('');
                }
                else {
                    Toast(RetrieveMessage(obj.responsecode), "Message", "error");
                }
            }
            else {
                window.location.href = '/ClientLogin/ClientLogin';
            }
        }).fail(function (result) {
            console.log(result.Message);
        });
    }
    catch (e) {
        console.log(e.message);
    }
}

function FillBranchState(val) {
    try {
        const datastring = {};
        datastring.BranchId = $("#BranchId").val();

        AjaxSubmission(JSON.stringify(datastring), "/Master/PurchaseEntry/FillBranchState", $('input[name=__RequestVerificationToken]').val()).done(function (result) {
            let obj = result;

            if (obj.status == true) {
                if (obj.responsecode == '100') {
                    $("#BranchState").val(obj.data[0].StateCode);
                    if (val != true) {
                        BindTaxDetailsTable();
                    }
                }
                else if (obj.responsecode == '604') {
                    $("#BranchState").val('');
                }
                else {
                    Toast(RetrieveMessage(obj.responsecode), "Message", "error");
                }
            }
            else {
                window.location.href = '/ClientLogin/ClientLogin';
            }
        }).fail(function (result) {
            console.log(result.Message);
        });
    }
    catch (e) {
        console.log(e.message);
    }
}

document.addEventListener("keydown", function (zEvent) {
    if (zEvent.ctrlKey && zEvent.altKey && (zEvent.key == "j" || zEvent.key == "J")) {  // case sensitive      
        $('#PurchaseEntry_List-tab').removeClass('active ');
        $('#PurchaseEntry_List').removeClass('active show');
        $('#PurchaseEntry-tab').addClass('active');
        $('#PurchaseEntry').addClass('active show');
        $("#FormAdd").show();
        $("#FormUpdate").hide();
        $("#FormReset").hide();
        $("#PurchaseEntry-tab").html("Add Purchase Entry ");
        ResetForm();
        $('#InvoiceNo').focus();
    }
});

$("#BranchId").change(function () {
    if (EditPurchaseNo)
        GeneratePurchaseNo();
});



function GeneratePurchaseNo() {
    try {
        let BranchId = $("#BranchId").val();
        let InvoiceDate = $("#InvoiceDate").val();
        const dataString = {};
        dataString.BranchId = BranchId;
        dataString.BookType = 'PU';
        dataString.InvoiceDate = InvoiceDate;
        AjaxSubmission(JSON.stringify(dataString), '/Master/PurchaseEntry/GeneratePurchaseNo', $('[name="__RequestVerificationToken"]').val()).done(function (result) {
            let obj = result;
            if (obj.status == true) {
                $("#PurchaseSerialNo").val(obj.data.Table[0].PurchaseNo);
            }
            else
                window.location.href = '/ClientLogin/ClientLogin';
        }).fail(function (result) {
            console.log(result.message);
        });
    }
    catch (e) {
        console.log(e.message);
    }
};

$("#PuchaseGroupSearch").on('change', AccHeadReset)

function AccHeadReset() {
    $("#PartyName,#PartyNameHiddenId").val('');
    $("#PartyName").trigger('blur');
}

$("#InvoiceNo,#InvoiceDate").on('change', function () {
    $("#Purchase_table tbody tr").each(function (index, ele) {
        let recNo = $(ele).children().eq(5).children().eq(0)
        let recDate = $(ele).children().eq(6).children().eq(0)
        recNo.val($("#InvoiceNo").val());
        recDate.val($("#InvoiceDate").val());
    });
});


//FUNCTION FOR EXPORT DATA IN EXCEL
function FormExcel() {
    ShowLoader();
    let date = new Date();
    let NewDate = ("00" + date.getDate()).slice(-2) + "_" + ("00" + (date.getMonth() + 1)).slice(-2) + "_" + date.getFullYear() + "_" + ("00" + date.getHours()).slice(-2) + "_" + ("00" + date.getMinutes()).slice(-2) + "_" + ("00" + date.getSeconds()).slice(-2);
    let fileName = "PurchaseEntry_" + NewDate + ".xlsx";

    $('#FormSearch').trigger('click');
    AjaxSubmission(null, '/Master/PurchaseEntry/FormExcel', $('input[name=__RequestVerificationToken]').val()).done(function (result) {
        let obj = result;
        if (obj.status == true) {
            if (obj.responsecode == '100') {

                let bytes = Base64ToBytes(obj.data.FileData[0].Base64Data);
                let blob = new Blob([bytes], { type: "application/octetstream" });
                let isIE = false || !!document.documentMode;
                if (isIE) {
                    window.navigator.msSaveBlob(blob, fileName);
                } else {
                    let url = window.URL || window.webkitURL;
                    link = url.createObjectURL(blob);
                    let a = $("<a />");
                    a.attr("download", fileName);
                    a.attr("href", link);
                    $("body").append(a);
                    a[0].click();
                    $("body").remove(a);
                }
            }
            else if (obj.responsecode == '302')
                Toast("No Records found.", 'Message', 'success');
            else
                Toast(RetrieveMessage(obj.responsecode), 'Message', 'error');

        } else
            window.location.href = '/ClientLogin/ClientLogin';
        HideLoader();

    }).fail(function (result) {
        console.log(result.Message);
        HideLoader();
    });
}

//VALIDATION FOR ADD OR UPDATE THE PURCHASE ENTRY
function PurchaseAddUpdateValidation() {
    if ($("#BranchId").val() == 0) {
        $("#BranchId").focus();
        Toast("Please Select Branch !", 'Message', 'error');
        flag = 1;
        return;
    }
    if ($("#PurchaseSerialNo").val() == "") {
        Toast("Please Fill Purchase No. !", 'Message', 'error');
        flag = 1;
        return;
    }
    if ($("#BranchId").val() == '0') {
        Toast(RetrieveMessage(910), 'Message', 'error');
        flag = 1;
        return;
    }
    if ($("#CurrDate").val() == "") {
        $("#CurrDate").focus();
        Toast("Please Select Date !", 'Message', 'error');
        flag = 1;
        return;
    }
    if ($("#InvoiceNo").val() == "") {
        $("#InvoiceNo").focus();
        Toast("Please Select Invoice Number !", 'Message', 'error');
        flag = 1;
        return;
    }
    if ($("#InvoiceDate").val() == "") {
        $("#InvoiceDate").focus();
        Toast("Please Select Invoice Date !", 'Message', 'error');
        flag = 1;
        return;
    }
    if ($("#PuchaseGroupSearch").val() == 0) {
        $("#PuchaseGroupSearch").focus();
        Toast("Please Select Group Head !", 'Message', 'error');
        flag = 1;
        return;
    }
    if ($("#PartyNameHiddenId").val() == '') {
        $("#PartyName").focus();
        Toast(RetrieveMessage(911), 'Message', 'error');
        flag = 1;
        return;
    }

    $("#Purchase_table tbody tr").each(function (index, ele) {
        if ($(ele).find('.HiddenGroupId').val().length == 0) {
            $(ele).find('.GroupName').focus();
            Toast(RetrieveMessage(805), 'Message', 'error');
            flag = 1;
            return false;
        }
        if ($(ele).find('.HiddenAccountDescId').val().length == 0) {
            $(ele).find('.AccountDesc').focus();
            Toast(RetrieveMessage(913), 'Message', 'error');
            flag = 1;
            return false;
        }
        if ($(ele).find('.Amount').val() == '0.00') {
            $(ele).find('.Amount').focus();
            Toast("Please Fill Amount !", 'Message', 'error');
            flag = 1;
            return false;
        }
        if ($(ele).find('.TaxCategory').val() == "0") {
            $(ele).find('.TaxCategory').focus();
            Toast('Please Select Tax Category', 'Message', 'error');
            flag = 1;
            return false;
        }
        if ($(ele).find('.JobNo').prop('disabled') == false && $(ele).find('.HiddenJobNo').val() == "") {
            $(ele).find('.JobNo').focus();
            Toast('Please Fill Job Number !', 'Message', 'error');
            flag = 1;
            return false;
        }

    });
    let checkPaymentRows = 0;
    $("#TblPaymentCharges tbody tr").each(function (index, ele) {
        if (index == 0) {
            checkPaymentRows = 0;
        }
        else {
            checkPaymentRows = 1;
        }
        if ($(ele).find('.PaymentLedgerUid').val().length != 0) {
            if ($(ele).find('.PaymentGrossAmount').val() > 0) {
                if (!$(ele).find('.PaymentPercentage').val()) {
                    $(ele).find('.PaymentPercentage').focus();
                    Toast('Please Fill Payment Percentage', 'Message', 'error');
                    flag = 1;
                    return false;
                }
            }
            if ($(ele).find('.PaymentPercentage').val() > 0) {
                if (!$(ele).find('.PaymentGrossAmount').val()) {
                    $(ele).find('.PaymentGrossAmount').focus();
                    Toast('Please Fill Gross Amount', 'Message', 'error');
                    flag = 1;
                    return false;
                }
            }
            if (!$(ele).find('.PaymentAmount').val()) {
                $(ele).find('.PaymentAmount').focus();
                Toast('Please Fill Payment Amount', 'Message', 'error');
                flag = 1;
                return false;
            }
        } else if ($(ele).find('.PaymentAmount').val().length != "" || $(ele).find('.PaymentPercentage').val().length != "" || $(ele).find('.PaymentGrossAmount').val().length != "") {
            $(ele).find('.PaymentAccDesc').focus();
            Toast('Please Fill Account Description', 'Message', 'error');
            flag = 1;
            return false;
        } else if (checkPaymentRows == 1) {
            $(ele).find(".PaymentLedgerUid").focus();
            Toast('Please Fill Acc Description', 'Message', 'error');
            flag = 1;
            return false;
        }
    });
}


//AUTO COMPLETE DROPDOWN FOR SEARCH LEDGER NAME 
function LedgerAccHeadautocompleteForSearchLedger() {
    $("#PartyNameSearch").autocomplete({
        source: function (request, response) {
            $.ajax({
                type: 'POST',
                url: "/Master/PurchaseEntry/SearchAccHeadNameList",
                dataType: "json",
                async: false,
                data: {
                    AccDescription: request.term
                },
                success: function (result) {
                    response($.map(result.data.Table, function (LedgerName) {
                        return {
                            label: LedgerName.AccHead,
                            value: LedgerName.AccHead,
                            id: LedgerName.LedgerUid,
                        }
                    }));
                },
                error: function (response) {
                    console.log(response.responseText);
                }
            });
        },
        minLength: 1,
        autoFocus: true,
        selectFirst: true,
        selectOnly: true,
        focus: function (event, ui) { }
    }).focus(function () {
        $(this).autocomplete("search");
    });
}


//FUNCTION FOR AUTOCOMPLETE AJAX WITH CLASS
function PaymentAutoCompleteAjaxAccHead(id, Url, HiddenClass, Custom, IsAdd) {
    if (id == undefined)
        return false;
    WhereCondition = '';
    $('.' + id).autocomplete({
        source: function (request, response) {
            AjaxSubmissionAutocomplete(JSON.stringify({ SearchField: request.term, WhereCondition: WhereCondition, IsAdd: IsAdd, "Custom": $('#' + Custom).val() }), Url, $('input[name=__RequestVerificationToken]').val()).done(function (result) {
                let obj = result;
                if (obj.status == true) {
                    if (obj.responsecode == '100') {
                        response($.map(result.data.Table, function (item, id) {
                            return {
                                label: item.name,
                                value: item.name,
                                id: item.id,
                                taxPercentage: item.TaxPercentage
                            };
                        }));
                    } else {
                        $('.ui-menu').html('');
                        $('.ui-menu').hide();
                    }
                }
                else
                    window.location.href = '/ClientLogin/ClientLogin';
            }).fail(function (result) {
                console.log(result.Message);
            });
        },
        showHeader: true,
        autoFocus: true,
        minLength: 1,
        selectOnly: true,
        select: function (e, i) {
            if (i.item != undefined) {
                $(this).siblings("." + HiddenClass).val(i.item.id);
                if (!i.item.TaxPercentage)
                    $(this).parent().parent().find(".PaymentPercentage").val(formatNumber(i.item.taxPercentage));
            }
        },
        change: function (e, i) {
            $(this).parent().parent().find(".PaymentGrossAmount,.PaymentAmount").val('');
            if (Custom != "1") {
                if (i.item == null || i.item == undefined) {
                    $(this).val('');
                    $(this).siblings("." + HiddenClass).val('');
                    $(this).parent().parent().find(".PaymentPercentage").val('');
                }
            }
        }
        , open: function () {
            $("ul.ui-menu").css({
                'overflow-y': 'scroll',
                'overflow-x': 'hidden',
                'max-height': '200px'
            });
        }
    })
}

////FUNCTION FOR AUTOCOMPLETE AJAX WITH CLASS
//function PaymentAutoCompleteAjaxAccHead(id, Url, HiddenClass, Custom, IsAdd) {
//    if (id == undefined)
//        return false;
//    WhereCondition = '';
//    $('.' + id).autocomplete({
//        source: function (request, response) {
//            AjaxSubmissionAutocomplete(JSON.stringify({ SearchField: request.term, WhereCondition: WhereCondition, IsAdd: IsAdd, "Custom": $('#' + Custom).val() }), Url, $('input[name=__RequestVerificationToken]').val()).done(function (result) {
//                let obj = result;
//                if (obj.status == true) {
//                    if (obj.responsecode == '100') {
//                        response($.map(result.data.Table, function (item, id) {
//                            return {
//                                label: item.name,
//                                value: item.name,
//                                id: item.id
//                            };
//                        }));
//                    } else {
//                        $('.ui-menu').html('');
//                        $('.ui-menu').hide();
//                    }
//                }
//                else
//                    window.location.href = '/ClientLogin/ClientLogin';
//            }).fail(function (result) {
//                console.log(result.Message);
//            });
//        },
//        showHeader: true,
//        autoFocus: true,
//        minLength: 1,
//        selectOnly: true,
//        select: function (e, i) {
//            if (i.item != undefined) {
//                $(this).siblings("." + HiddenClass).val(i.item.id);
//            }
//        },
//        change: function (e, i) {
//            if (Custom != "1") {
//                if (i.item == null || i.item == undefined) {
//                    $(this).val('');
//                    $(this).siblings("." + HiddenClass).val('');
//                }
//            }
//        }
//        , open: function () {
//            $("ul.ui-menu").css({
//                'overflow-y': 'scroll',
//                'overflow-x': 'hidden',
//                'max-height': '200px'
//            });
//        }
//    })
//}


$(document).on("change", ".PaymentGrossAmount", function () {
    let tr = $(this).parent().parent();
    tr.find(".PaymentAmount").val('');
});
$(document).on("blur", ".PaymentGrossAmount", function () {
    let tr = $(this).parent().parent();
    if ($(this).val() != "") {
        $(this).val(formatNumber(parseFloat($(this).val())));
        if (tr.find(".PaymentPercentage").val() > 0.01) {
            tr.find(".PaymentAmount").val(formatNumber($(this).val() * tr.find('.PaymentPercentage').val() / 100));
        }
    }
    TotalPaymetAmount();
});
$(document).on("blur", ".PaymentPercentage", function () {
    let tr = $(this).parent().parent();
    if ($(this).val() != "") {
        $(this).val(formatNumber(parseFloat($(this).val())));
        if (tr.find(".PaymentGrossAmount").val() > 0.01) {
            tr.find(".PaymentAmount").val(formatNumber($(this).val() * tr.find('.PaymentGrossAmount').val() / 100));
        }
    }
    TotalPaymetAmount();
});
$(document).on("blur", ".PaymentAmount", function () {
    let tr = $(this).parent().parent();
    if ($(this).val() != "") {
        $(this).val(formatNumber(parseFloat($(this).val())));
    }
    if (tr.find('.PaymentGrossAmount,.PaymentPercentage').val() != "") {
        $(this).val(formatNumber(tr.find('.PaymentPercentage').val() * tr.find('.PaymentGrossAmount').val() / 100));
    };
    TotalPaymetAmount();
});

function formatNumber(number) {
    if (!number)
        return;
    let roundedNumber = number.toFixed(2);

    if (roundedNumber.indexOf('.') === -1) {
        roundedNumber += '.00';
    }

    return roundedNumber;
}

$(document).on('blur', '.TaxCategory', function () {
    if ($(this).find(":selected") != 0) {
        let tax = $(this).find(":selected").text().split(" ")[1].split("@")[1];
        $(this).parent().parent().find(".HiddenTaxPer").val(tax);
        CalculateTaxAmount(this);
        GetTotal();
    }
})

function TotalPaymetAmount() {
    let PaymentAmount;
    let IsAmountFilled = $("#TblPaymentCharges tbody tr").length;
    $("#TblPaymentCharges tbody tr").each((i, e) => {
        if (!$(e).find($(".PaymentAmount")).val())
            IsAmountFilled -= 1;
    })
    if (IsAmountFilled > 0) {
        $("#TblPaymentCharges tbody tr").each((i, e) => {
            if (!PaymentAmount)
                PaymentAmount = parseFloat($(e).find('.PaymentAmount').val());
            else
                PaymentAmount += parseFloat($(e).find('.PaymentAmount').val());
        })
        $("#PaymentAmt").text(formatNumber(PaymentAmount));
        if ($("#NetAmount").text() != "") {
            $("#RoundOffPayment").html("0." + $("#PaymentAmt").html().split(".")[1]);
            $("#NetPaybleAmount").text(Math.round(formatNumber(parseFloat($("#NetAmount").text()) - $("#PaymentAmt").text())).toFixed(2));
        }
    } else {
        $("#RoundOffPayment,#NetPaybleAmount,#PaymentAmt").html('');
    }
}