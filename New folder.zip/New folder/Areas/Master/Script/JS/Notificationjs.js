﻿
$(document).ready(function () {
    GetAllNotification();
})

$('#FormRefresh').click(function () {
    GetAllNotification();
})

//FUNCTION FOR GET ALL NOTIFICATION
function GetAllNotification() {
    try {

        AjaxSubmission(null, "/Master/Notification/GetAllNotification", $('input[name=__RequestVerificationToken]').val()).done(function (result) {
            let obj = result;
            if (obj.status == true) {
                if (obj.responsecode == '100') {                    
                    let html = '';                    
                    if (obj.data.Table.length > 0)
                        $('#TblNotificationDetails').removeClass('d-none');
                    else
                        $('#TblNotificationDetails').addClass('d-none');

                    $.each(obj.data.Table, function (ind, ele) {
                        html += "<tr>";
                        html += "<td class='text-center'>" + (ind+1) + "</td>";
                        html += "<td class='text-center'>" + ele.NotificationDate + "</td>";
                        html += "<td class='text-left'>" + ele.Details + "</td>";
                       
                    });
                    $('#TblNotificationDetails tbody').html(html);
                }
            }
            else 
                window.location.href = '/ClientLogin/ClientLogin';
        }).fail(function (result) {
            console.log(result.Message);
        });
    }
    catch (e) {
        console.log(e.message);
    }
}