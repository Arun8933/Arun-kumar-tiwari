﻿var Firstcolumn = "";
// DOCUMENT READY
$(document).ready(function () {
    Firstcolumn = "finyr_name";
    localStorage.setItem('PageName', 'Financial Year');
    FillPageSizeList('ddlPageSize', FinancialYearList);
    InvoiceSeriesList();
    VoucherTypeList();
    PurchaseTypeList();
    $(".datepickerAll").datepicker({
        changeMonth: true,
        changeYear: true,
        dateFormat: 'dd/mm/yy'
    });
    $("#YearId").focus();
});

// FUNCTION FOR VALIDATE FROM DATE 
$("#FromDate").keyup(function () {
    if ($("#FromDate").val().length == 4) {
        $("#ToDate").val(parseInt($("#FromDate").val()) + 1);
    } else {
        $("#ToDate").val("");
    }
});

// FUNCTION FOR VALIDATE TO DATE
$("#ToDate").keyup(function () {
    if ($("#ToDate").val().length == 4) {
        $("#FromDate").val(parseInt($("#ToDate").val()) - 1);
    } else {
        $("#FromDate").val("");
    }
});

$(document).on("click", ".pagination .page", function () {
    FinancialYearList(($(this).attr('page')));
});
//PAGE SIZE CLICKED
$("#ddlPageSize").change(function () {
    FinancialYearList(1);
});

//SEARCH BUTTON CLICKED
$("#Btn_search").click(function () {
    FinancialYearList(1);
});

// BIND FINANCIAL YEAR LIST

function BindFinancialYearTable(result, serial_no) {
    $("#tbl_financial_year tbody tr").remove();
    if (result.length == 0) {
        tr = $('<tr/>');
        tr.append("<td class='text-center' colspan='9'>NO RESULTS FOUND</td>");
        $("#tbl_financial_year tbody").append(tr);
    }
    else {
        for (i = 0; i < result.length; i++) {
            if (result[i].is_active == "Inactive")
                tr = $(' <tr style="background-color:#fdd2d2;"/>');
            else
                tr = $('<tr/>');
            tr.append("<td class='text-center'><button type='button' onclick='EditFinancialYear(\"" + result[i].finyr_id + "\");' class='common-btn common-btn-sm'><i class='fa-solid fa-pen-to-square'></i></button ><button type='button' onclick='DeleteFinancialYear(\"" + result[i].finyr_id + "\");' class='common-btn common-btn-sm'> <i class='fa-regular fa-trash-can'></i></button ></td > ");
            tr.append("<td class='text-left'>" + serial_no + "</td>");
            tr.append("<td class='text-left'>" + result[i].finyr_id + "</td>");
            tr.append("<td class='text-center'><a href='javascript:void(0)' class='text-decoration-none' style='color: black !important;' onclick='EditFinancialYear(\"" + result[i].finyr_id + "\");'>" + result[i].finyr_name + "</a></td>");
            tr.append("<td class='text-center'>" + result[i].finyr_start_date + "</td>");
            tr.append("<td class='text-center'>" + result[i].finyr_end_date + "</td>");
            serial_no++;
            $("#tbl_financial_year tbody").append(tr);
        }
    }
}

// FUNCTION FOR FINANCIAL YEAR LIST
function FinancialYearList(pageindex) {
    try {
        const dataString = {};
        dataString.PageSize = $("#ddlPageSize").val();
        dataString.PageIndex = pageindex;
        dataString.Id = $("#YearId").val().trim();
        dataString.FinancialYearName = $("#FinancialYear").val();
        dataString.OrderBy = $("#sort-column").val().trim() + " " + $("#sort-type").val().trim();
        ShowLoader();
        AjaxSubmission(JSON.stringify(dataString), "/Master/FinancialYear/FinancialYearList", $('input[name=__RequestVerificationToken]').val()).done(function (result) {
            let obj = result;
            if (obj.status == true) {
                if (obj.responsecode == '100') {
                    var ser = ((parseInt(obj.data.Table1[0].PageIndex) - 1) * parseInt(obj.data.Table1[0].PageSize)) + 1;
                    BindFinancialYearTable(obj.data.Table, ser);
                    if (obj.data.Table1 != undefined && obj.data.Table1.length > 0) {
                        $(".pagination").BindPaging({
                            ActiveCssClass: "current",
                            PagerCssClass: "pager",
                            PageIndex: parseInt(obj.data.Table1[0].PageIndex),
                            PageSize: parseInt(obj.data.Table1[0].PageSize),
                            RecordCount: parseInt(obj.data.Table1[0].count)
                        });
                    }
                }
                else {

                    Toast(RetrieveMessage(obj.responsecode), "Message", "error");
                }
            }
            else {
                window.location.href = '/ClientLogin/ClientLogin';
            }
            HideLoader();
        }).fail(function (result) {
            console.log(result.Message);
            HideLoader();
        });
    }
    catch (e) {
        console.log(e.message);
        HideLoader();
    }
}

//FUNCTION FOR SORTING FIELD
function Sorting(obj) {
    if (Firstcolumn != "") {
        document.getElementById(Firstcolumn).innerHTML = document.getElementById(Firstcolumn).getAttribute("data-column") + " <i class='fa-solid fa-sort'></i>";
    }
    Firstcolumn = obj.id;
    var colname = $(obj).data("column");
    $("#sort-column").val(Firstcolumn);
    var sorttype = $("#sort-type").val();
    alert(sorttype);
    if (sorttype == "ASC") {
        $("#sort-type").val("DESC");
        $(obj).html(colname + " <i style='margin-left:10px;' class='fa-solid fa-sort-down'></i>");
    } else if (sorttype == "DESC") {
        $("#sort-type").val("ASC");
        $(obj).html(colname + " <i style='margin-left:10px;' class='fa-solid fa-sort-up'></i>");
    }
    FinancialYearList(1);
}


$("#Year_add").click(function () {
    var flag = 0;
    var FromDate = $("#FromDate").val();
    var ToDate = $("#ToDate").val();
    var StartDate = $("#StartDate").val();
    var EndDate = $("#EndDate").val();
    var InvoiceSeries = ""; var InvBillNoFormat = ""; var InvInvoiceType = ""; var InvBranchCode = ""; var InvBookType = ""; var BillNoCount = 0; var InvoiceTypeCount = 0; var BranchCount = 0; var BookTypeCount = 0;
    var PurchaseSeries = ""; var VoucherSeries = ""; var VoucherBranchCode = ""; var PurchaseBranchCode = ""; var VoucherBookType = ""; var PurchaseBookType = ""; var VoucherNoCount = 0; var PurchaseNoCount = 0;
    $('#tbl_InvoiceSeries .my').each(function (e, th) {

        InvoiceSeries = $(this).find("td:nth-child(6) input[type='text']").val().trim();
        if (InvoiceSeries.length > 0) {

            InvBillNoFormat = InvoiceSeries.includes("{sub_bill_no}");
            InvInvoiceType = InvoiceSeries.includes("{invoice_type}");
            InvBranchCode = InvoiceSeries.includes("{branch_code}");
            InvBookType = InvoiceSeries.includes("{book_type}");

            BillNoCount = (InvoiceSeries.match(/{sub_bill_no}/g) || []).length;
            InvoiceTypeCount = (InvoiceSeries.match(/{invoice_type}/g) || []).length;
            BranchCount = (InvoiceSeries.match(/{branch_code}/g) || []).length;
            BookTypeCount = (InvoiceSeries.match(/{book_type}/g) || []).length;

            if (InvBillNoFormat == true) {
                if (BillNoCount > 1) {
                    Toast("{sub_bill_no}  must be enter only single time  !", 'Message', 'error');
                    flag = 1;
                    return false;
                }
                if (InvInvoiceType == true) {
                    if (InvoiceTypeCount > 1) {
                        Toast("{invoice_type}  must be enter only single time  !", 'Message', 'error');
                        flag = 1;
                        return false;
                    }
                    if (InvBranchCode == true) {
                        if (BranchCount > 1) {
                            Toast("{branch_code}  must be enter only single time  !", 'Message', 'error');
                            flag = 1;
                            return false;
                        }
                        if (InvBookType == true) {
                            if (BookTypeCount > 1) {
                                Toast("{book_type}  must be enter only single time  !", 'Message', 'error');
                                flag = 1;
                                return false;
                            }
                        }
                        else {
                            Toast("Please Enter {book_type} !", 'Message', 'error');
                            flag = 1;
                            return false;
                        }
                    }
                    else {
                        Toast("Please Enter {branch_code} !", 'Message', 'error');
                        flag = 1;
                        return false;
                    }
                }
                else {
                    Toast("Please Enter {invoice_type} !", 'Message', 'error');
                    flag = 1;
                    return false;
                }
            }
            else {
                Toast("Please Enter {sub_bill_no} !", 'Message', 'error');
                flag = 1;
                return false;
            }
        }
    });

    $('#tbl_VoucherSeries .my').each(function (e, th) {

        VoucherSeries = $(this).find("td:nth-child(6) input[type='text']").val().trim();
        if (VoucherSeries.length > 0) {

            SubVoucherNoFormat = VoucherSeries.includes("{sub_Voucher_no}");
            VoucherBranchCode = VoucherSeries.includes("{branch_code}");
            VoucherBookType = VoucherSeries.includes("{book_type}");

            VoucherNoCount = (VoucherSeries.match(/{sub_Voucher_no}/g) || []).length;
            BranchCount = (VoucherSeries.match(/{branch_code}/g) || []).length;
            BookTypeCount = (VoucherSeries.match(/{book_type}/g) || []).length;
            if (SubVoucherNoFormat == true) {
                if (VoucherNoCount > 1) {
                    Toast("{sub_Voucher_no}  must be enter only single time  !", 'Message', 'error');
                    flag = 1;
                    return false;
                }
                if (VoucherBranchCode == true) {
                    if (BranchCount > 1) {
                        Toast("{branch_code}  must be enter only single time  !", 'Message', 'error');
                        flag = 1;
                        return false;
                    }
                    if (VoucherBookType == true) {
                        if (BookTypeCount > 1) {
                            Toast("{book_type}  must be enter only single time  !", 'Message', 'error');
                            flag = 1;
                            return false;
                        }
                    }
                    else {
                        Toast("Please Enter {book_type} !", 'Message', 'error');
                        flag = 1;
                        return false;
                    }
                }
                else {
                    Toast("Please Enter {branch_code} !", 'Message', 'error');
                    flag = 1;
                    return false;
                }
            }
            else {
                Toast("Please Enter {sub_Voucher_no} !", 'Message', 'error');
                flag = 1;
                return false;
            }
        }
    });

    $('#tbl_PurchaseSeries .my').each(function (e, th) {

        PurchaseSeries = $(this).find("td:nth-child(6) input[type='text']").val().trim();
        if (PurchaseSeries.length > 0) {

            SubPurchaseNoFormat = PurchaseSeries.includes("{sub_Purchase_no}");
            PurchaseBranchCode = PurchaseSeries.includes("{branch_code}");
            PurchaseBookType = PurchaseSeries.includes("{book_type}");

            PurchaseNoCount = (PurchaseSeries.match(/{sub_Purchase_no}/g) || []).length;
            BranchCount = (PurchaseSeries.match(/{branch_code}/g) || []).length;
            BookTypeCount = (PurchaseSeries.match(/{book_type}/g) || []).length;
            if (SubPurchaseNoFormat == true) {
                if (PurchaseNoCount > 1) {
                    Toast("{sub_Purchase_no}  must be enter only single time  !", 'Message', 'error');
                    flag = 1;
                    return false;
                }
                if (PurchaseBranchCode == true) {
                    if (BranchCount > 1) {
                        Toast("{branch_code}  must be enter only single time  !", 'Message', 'error');
                        flag = 1;
                        return false;
                    }
                    if (PurchaseBookType == true) {
                        if (BookTypeCount > 1) {
                            Toast("{book_type}  must be enter only single time  !", 'Message', 'error');
                            flag = 1;
                            return false;
                        }
                    }
                    else {
                        Toast("Please Enter {book_type} !", 'Message', 'error');
                        flag = 1;
                        return false;
                    }
                }
                else {
                    Toast("Please Enter {branch_code} !", 'Message', 'error');
                    flag = 1;
                    return false;
                }
            }
            else {
                Toast("Please Enter {sub_Purchase_no} !", 'Message', 'error');
                flag = 1;
                return false;
            }
        }
    });

    ValidateAllFieldNewTest('AddFinancialYear');
    if (Ercount == 0) {
        if (FromDate >= ToDate) {
            Toast("To Date Must Be Greater Than From Date*", "Message", "error");
        }
        if (StartDate >= EndDate) {
            Toast("End Date Must Be Greater Than Start Date*", "Message", "error");
        }
        if (flag == 0) {
            AddFinancialYear();
        }
    }
});

//FUNCTION FOR ADD FINANCIAL YEAR
function AddFinancialYear() {
    var count = 0, count2 = 0;
    var JobNoFormat = $("#JobNoFormat").val().trim();
    var incJobNoFormat = JobNoFormat.includes("{sub_job_no}");
    var incljobtype = JobNoFormat.includes("{JobType}");
    count = (JobNoFormat.match(/{sub_job_no}/g) || []).length;
    count2 = (JobNoFormat.match(/{JobType}/g) || []).length;
    if (incljobtype == true) {
        if (count2 > 1) {
            Toast("{JobType}  must be enter only single time  !", 'Message', 'error');
            return false;
        }
        if (incJobNoFormat == true) {
            if (count > 1) {
                Toast("{sub_job_no} must be enter only single time  !", 'Message', 'error');
            }
            else {
                try {
                    const dataString = {};
                    dataString.FromDate = $("#FromDate").val().trim();
                    dataString.ToDate = $("#ToDate").val().trim();
                    dataString.StartDate = $("#StartDate").val().trim();
                    dataString.EndDate = $("#EndDate").val().trim();
                    dataString.JobNoFormat = $("#JobNoFormat").val().trim();
                    dataString.JobNoLength = $("#JobNoLength").val().trim();
                    dataString.IsDefault = $("#IsDefault").is(":checked");
                    ShowLoader();
                    AjaxSubmission(JSON.stringify(dataString), "/Master/FinancialYear/AddFinancialYear", $('input[name=__RequestVerificationToken]').val()).done(function (result) {
                        let obj = result;
                        if (obj.status == true) {
                            if (obj.responsecode == '101') {
                                /*window.location.reload();*/
                                setTimeout(FinancialYearList(1), 1000);

                                /*  TabHide();*/
                                AddInvoiceSeries();
                                AddVoucherSeries();
                                AddPurchaseSeries();

                                /*  ResetData();*/
                                Toast(RetrieveMessage(obj.responsecode), "Message", "success");
                            }
                            else {
                                Toast(RetrieveMessage(obj.responsecode), "Message", "error");
                            }
                        }
                        else {
                            window.location.href = '/ClientLogin/ClientLogin';
                        }
                        HideLoader();
                    }).fail(function (result) {
                        console.log(result.Message);
                        HideLoader();
                    });
                }
                catch (e) {
                    console.log(e.message);
                    HideLoader();
                }
            }
        }

        else {
            Toast("Please Enter {sub_job_no} !", 'Message', 'error');
        }
    }
    else {
        Toast('Please Enter {JobType}', 'Message', 'error');
        return false;
    }

}


//FUNCTION FOR UPDATE FINANCIAL YEAR
function UpdateFinancialYear() {
    var count = 0, count2 = 0;
    var JobNoFormat = $("#JobNoFormat").val().trim();
    var incJobNoFormat = JobNoFormat.includes("{sub_job_no}");
    var incljobtype = JobNoFormat.includes("{JobType}");
    count = (JobNoFormat.match(/{sub_job_no}/g) || []).length;
    count2 = (JobNoFormat.match(/{JobType}/g) || []).length;
    if (incljobtype == true) {
        if (count2 > 1) {
            Toast("{JobType}  must be enter only single time  !", 'Message', 'error');
            return false;
        }
        if (incJobNoFormat == true) {
            if (count > 1) {
                Toast("{sub_job_no} must be enter only single time  !", 'Message', 'error');
            }
            else {
                try {
                    const dataString = {};
                    dataString.FromDate = $("#FromDate").val().trim();
                    dataString.ToDate = $("#ToDate").val().trim();
                    dataString.StartDate = $("#StartDate").val();
                    dataString.EndDate = $("#EndDate").val().trim();
                    dataString.JobNoFormat = $("#JobNoFormat").val().trim();
                    dataString.JobNoLength = $("#JobNoLength").val().trim();
                    dataString.IsDefault = $("#IsDefault").is(":checked");
                    ShowLoader();
                    AjaxSubmission(JSON.stringify(dataString), "/Master/FinancialYear/UpdateFinancialYear", $('input[name=__RequestVerificationToken]').val()).done(function (result) {
                        let obj = result;
                        if (obj.status == true) {
                            if (obj.responsecode == '107') {
                                UpdateInvoiceSeries();
                                UpdateVoucherSeries();
                                UpdatePurchaseSeries();
                                /* window.location.reload();*/
                                setTimeout(FinancialYearList(1), 500);
                                Toast(RetrieveMessage(obj.responsecode), "Message", "success");
                            }
                            else {
                                Toast(RetrieveMessage(obj.responsecode), "Message", "error");
                            }
                        }
                        else {
                            window.location.href = '/ClientLogin/ClientLogin';
                        }
                        HideLoader();
                    }).fail(function (result) {
                        console.log(result.Message);
                        HideLoader();
                    });
                }
                catch (e) {
                    console.log(e.message);
                    HideLoader();
                }
            }
        }

        else {
            Toast("Please Enter {sub_job_no} !", 'Message', 'error');
        }
    }
    else {
        Toast('Please Enter {JobType}', 'Message', 'error');
        return false;
    }

}

//FUNCTION FOR EDIT FINANCIAL YEAR
function EditFinancialYear(YearId) {
    try {
        const dataString = {};
        dataString.YearId = parseInt(YearId);
        ShowLoader();
        AjaxSubmission(JSON.stringify(dataString), "/Master/FinancialYear/EditFinancialYear", $('[name="__RequestVerificationToken"]').val()).done(function (data) {
            let obj = data;
            if (obj.status == true) {
                if (obj.responsecode == '100') {
                    BindInvoiceSeriesTableOnEdit(obj.data.Table1, 1);
                    BindVoucherSeriesTableOnEdit(obj.data.Table2, 1);
                    BindPurchaseSeriesTableOnEdit(obj.data.Table3, 1);
                    TabShow();
                    $("#FromDate").val(obj.data.Table[0].finyr_from);
                    $("#ToDate").val(obj.data.Table[0].finyr_to);
                    $("#StartDate").val(obj.data.Table[0].finyr_start_date);
                    $("#EndDate").val(obj.data.Table[0].finyr_end_date);
                    $("#JobNoFormat").val(obj.data.Table[0].job_no_format);
                    $("#JobNoLength").val(obj.data.Table[0].job_no_length);
                    if (obj.data.Table[0].is_default == true)
                        $("#IsDefault").prop("checked", true);
                    else
                        $("#IsDefault").prop("checked", false);
                }
                else {
                    Toast(RetrieveMessage(obj.responsecode), "Message", "error");
                }
            }
            else {
                window.location.href = '/ClientLogin/ClientLogin';
            }
            HideLoader();
        }).fail(function (data) {
            console.log(data.Message);
            HideLoader();
        });
    }
    catch (e) {
        console.log(e.message);
        HideLoader();
    }
}

$("#Year_update").click(function () {
    var flag = 0;
    var FromDate = $("#FromDate").val();
    var ToDate = $("#ToDate").val();
    var StartDate = $("#StartDate").val();
    var EndDate = $("#EndDate").val();
    var InvoiceSeries = "";
    var InvBillNoFormat = "";
    var InvInvoiceType = "";
    var InvBranchCode = "";
    var InvBookType = "";
    var BillNoCount = 0;
    var InvoiceTypeCount = 0;
    var BranchCount = 0;
    var BookTypeCount = 0;

    var PurchaseSeries = ""; var VoucherSeries = ""; var VoucherBranchCode = ""; var PurchaseBranchCode = ""; var VoucherBookType = ""; var PurchaseBookType = ""; var VoucherNoCount = 0; var PurchaseNoCount = 0;

    $('#tbl_InvoiceSeries .my').each(function (e, th) {

        InvoiceSeries = $(this).find("td:nth-child(6) input[type='text']").val().trim();
        if (InvoiceSeries.length > 0) {

            InvBillNoFormat = InvoiceSeries.includes("{sub_bill_no}");
            InvInvoiceType = InvoiceSeries.includes("{invoice_type}");
            InvBranchCode = InvoiceSeries.includes("{branch_code}");
            InvBookType = InvoiceSeries.includes("{book_type}");

            BillNoCount = (InvoiceSeries.match(/{sub_bill_no}/g) || []).length;
            InvoiceTypeCount = (InvoiceSeries.match(/{invoice_type}/g) || []).length;
            BranchCount = (InvoiceSeries.match(/{branch_code}/g) || []).length;
            BookTypeCount = (InvoiceSeries.match(/{book_type}/g) || []).length;

            if (InvBillNoFormat == true) {
                if (BillNoCount > 1) {
                    Toast("{sub_bill_no}  must be enter only single time  !", 'Message', 'error');
                    flag = 1;
                    return false;
                }
                //  if (InvInvoiceType == true)
                //  {
                //if (InvoiceTypeCount > 1) {
                //    Toast("{invoice_type}  must be enter only single time  !", 'Message', 'error');
                //    flag = 1;
                //    return false;
                //}
                if (InvBranchCode == true) {
                    if (BranchCount > 1) {
                        Toast("{branch_code}  must be enter only single time  !", 'Message', 'error');
                        flag = 1;
                        return false;
                    }
                    if (InvBookType == true) {
                        if (BookTypeCount > 1) {
                            Toast("{book_type}  must be enter only single time  !", 'Message', 'error');
                            flag = 1;
                            return false;
                        }
                    }
                    else {
                        Toast("Please Enter {book_type} !", 'Message', 'error');
                        flag = 1;
                        return false;
                    }
                }
                else {
                    Toast("Please Enter {branch_code} !", 'Message', 'error');
                    flag = 1;
                    return false;
                }
                // }
                // else {
                //     Toast("Please Enter {invoice_type} !", 'Message', 'error');
                //     flag = 1;
                //     return false;
                // }
            }
            else {
                Toast("Please Enter {sub_bill_no} !", 'Message', 'error');
                flag = 1;
                return false;
            }
        }

    });
    $('#tbl_VoucherSeries .my').each(function (e, th) {
        VoucherSeries = $(this).find("td:nth-child(6) input[type='text']").val().trim();
        if (VoucherSeries.length > 0) {
            SubVoucherNoFormat = VoucherSeries.includes("{sub_Voucher_no}");
            VoucherBranchCode = VoucherSeries.includes("{branch_code}");
            VoucherBookType = VoucherSeries.includes("{book_type}");

            VoucherNoCount = (VoucherSeries.match(/{sub_Voucher_no}/g) || []).length;
            BranchCount = (VoucherSeries.match(/{branch_code}/g) || []).length;
            BookTypeCount = (VoucherSeries.match(/{book_type}/g) || []).length;
            if (SubVoucherNoFormat == true) {
                if (VoucherNoCount > 1) {
                    Toast("{sub_Voucher_no}  must be enter only single time  !", 'Message', 'error');
                    flag = 1;
                    return false;
                }
                if (VoucherBranchCode == true) {
                    if (BranchCount > 1) {
                        Toast("{branch_code}  must be enter only single time  !", 'Message', 'error');
                        flag = 1;
                        return false;
                    }
                    if (VoucherBookType == true) {
                        if (BookTypeCount > 1) {
                            Toast("{book_type}  must be enter only single time  !", 'Message', 'error');
                            flag = 1;
                            return false;
                        }
                    }
                    else {
                        Toast("Please Enter {book_type} !", 'Message', 'error');
                        flag = 1;
                        return false;
                    }
                }
                else {
                    Toast("Please Enter {branch_code} !", 'Message', 'error');
                    flag = 1;
                    return false;
                }
            }
            else {
                Toast("Please Enter {sub_Voucher_no} !", 'Message', 'error');
                flag = 1;
                return false;
            }
        }
    });

    $('#tbl_PurchaseSeries .my').each(function (e, th) {

        PurchaseSeries = $(this).find("td:nth-child(6) input[type='text']").val().trim();
        if (PurchaseSeries.length > 0) {

            SubPurchaseNoFormat = PurchaseSeries.includes("{sub_Purchase_no}");
            PurchaseBranchCode = PurchaseSeries.includes("{branch_code}");
            PurchaseBookType = PurchaseSeries.includes("{book_type}");

            PurchaseNoCount = (PurchaseSeries.match(/{sub_Purchase_no}/g) || []).length;
            BranchCount = (PurchaseSeries.match(/{branch_code}/g) || []).length;
            BookTypeCount = (PurchaseSeries.match(/{book_type}/g) || []).length;
            if (SubPurchaseNoFormat == true) {
                if (PurchaseNoCount > 1) {
                    Toast("{sub_Purchase_no}  must be enter only single time  !", 'Message', 'error');
                    flag = 1;
                    return false;
                }
                if (PurchaseBranchCode == true) {
                    if (BranchCount > 1) {
                        Toast("{branch_code}  must be enter only single time  !", 'Message', 'error');
                        flag = 1;
                        return false;
                    }
                    if (PurchaseBookType == true) {
                        if (BookTypeCount > 1) {
                            Toast("{book_type}  must be enter only single time  !", 'Message', 'error');
                            flag = 1;
                            return false;
                        }
                    }
                    else {
                        Toast("Please Enter {book_type} !", 'Message', 'error');
                        flag = 1;
                        return false;
                    }
                }
                else {
                    Toast("Please Enter {branch_code} !", 'Message', 'error');
                    flag = 1;
                    return false;
                }
            }
            else {
                Toast("Please Enter {sub_Purchase_no} !", 'Message', 'error');
                flag = 1;
                return false;
            }
        }
    });
    ValidateAllFieldNewTest('AddFinancialYear');
    if (Ercount == 0) {
        if (FromDate >= ToDate) {
            Toast("To Date Must Be Greater Than From Date*", "Message", "error");
        }
        if (StartDate >= EndDate) {
            Toast("End Date Must Be Greater Than Start Date*", "Message", "error");
        }
        if (flag == 0) {
            UpdateFinancialYear();
        }
    }
});


//FUNCTION FOR DELETE FINANCIAL YEAR
function DeleteFinancialYear(e) {
    try {
        $.confirm({
            title: '',
            content: 'Are You Sure Want To Delete ?',
            type: 'red',
            boxWidth: '300px',
            useBootstrap: false,
            columnClass: 'small',
            containerFluid: true,
            typeAnimated: true,
            buttons: {
                tryAgain: {
                    text: 'Confirm',
                    btnClass: 'btn-red',
                    action: function () {
                        const datastring = {};
                        datastring.YearId = parseInt(e);
                        ShowLoader();
                        AjaxSubmission(JSON.stringify(datastring), "/Master/FinancialYear/DeleteFinancialYear", $('[name="__RequestVerificationToken"]').val()).done(function (data) {
                            let obj = data;
                            if (obj.status == true) {
                                if (obj.responsecode == '102') {
                                    Toast(RetrieveMessage(obj.responsecode), "Message", "success");
                                    FinancialYearList(1);
                                }
                                else {
                                    Toast(RetrieveMessage(obj.responsecode), "Message", "error");
                                }
                            }
                            else {
                                window.location.href = 'ClientLogin/ClientLogin';
                            }
                            HideLoader();
                        }).fail(function (data) {
                            console.log(data.Message);
                            HideLoader();
                        });
                    }
                },
                close: function () {
                    HideLoader();
                }
            }
        });
    }
    catch (e) {
        console.log(e.message);
        HideLoader();
    }
}

//FUNCTION FOR RESET FINANCIAL YEAR DATA FIELD
function ResetData() {
    $("#FromDate").val("");
    $("#ToDate").val("");
    $("#StartDate").val("");
    $("#EndDate").val("");
    $("#JobNoFormat").val("");
    $("#JobNoLength").val("");
    $("#IsDefault").val("");
    $("#FromDateError").html("");
    $("#ToDateError").html("");
    $("#StartDateError").html("");
    $("#EndDateError").html("");
    $('#tbl_InvoiceSeries').find('input:text')
        .each(function () {
            $(this).val('');
        });
    $('#tbl_VoucherSeries').find('input:text')
        .each(function () {
            $(this).val('');
        });
    $('#tbl_PurchaseSeries').find('input:text')
        .each(function () {
            $(this).val('');

        });
}

//FUCNTION FOR TAB SHOW
function TabShow() {
    $('#AllFinancialYearTab').removeClass('active');
    $('#AddFinancialYearTab').addClass('active');
    $('#AllFinancialYear').removeClass('active show');
    $('#AddFinancialYear').addClass('active show');
    $("#Year_add").hide();
    $("#Year_update").show();
    $("#AddFinancialYearTab").html("Edit Financial Year");
}

//FUNCTION FOR TAB HIDE
function TabHide() {
    $('#AddFinancialYearTab').removeClass('active');
    $('#AllFinancialYearTab').addClass('active ');
    $('#AllFinancialYear').addClass('active show');
    $('#AddFinancialYear').removeClass('active show');
    $("#Year_add").show();
    $("#Year_update").hide();
    $("#AddFinancialYearTab").html("Add Financial Year");
}

//FINANCIAL YEAR LIST TAB CLICKED
$("#AllFinancialYearTab").click(function () {
    RemoveAllError('AddFinancialYear');
    ResetData();
    TabHide();

});


//BINDING INVOICE SERIES LIST TABLE
function BindInvoiceSeriesTable(result, serial_no) {
    $("#tbl_InvoiceSeries tbody tr").remove();

    if (result.length == 0) {
        tr = $('<tr/>');
        tr.append("<td class='text-center' colspan='9'>NO RESULTS FOUND</td>");
        $("#tbl_InvoiceSeries tbody").append(tr);
    }
    else {
        tr = $('<tr/>');
        tr.append("<td align='Right' colspan='4'>{branch_code}/{book_type}/{invoice_type}/{sub_bill_no},{M} - JUN, {m} - 06, {Y} - 2017, {y} - 17,{Y+1} - 2018, {y+1} - 18</td>");
        $("#tbl_InvoiceSeries tbody").append(tr);

        for (i = 0; i < result.length; i++) {
            if (result[i].is_active == "Inactive")
                tr = $(' <tr class="my" style="background-color:#fdd2d2;"/>');
            else
                tr = $('<tr class="my" />');
            tr.append("<td class='text-center'>" + serial_no + "</td>");
            tr.append("<td class='text-center'>" + result[i].BranchName + "</td>");
            tr.append("<td class='text-center'>" + result[i].invoice_type + "</td>");
            tr.append("<td class='text-center d-none'>" + result[i].BranchUid + "</td>");
            tr.append("<td class='text-center d-none'>" + result[i].invoicetype_id + "</td>");
            tr.append("<td class='text-center col-md-5'><input id='InvoiceSeries' name='InvoiceSeries' type='text' onblur='TrimValue(this);' data-minlength='5' maxlength='100'  class='form-control form-control-sm ' autocomplete='off' /></td>")

            //tr.append("<td class='text-center'><button type='button' onclick='EditFinancialYear(\"" + result[i].finyr_id + "\");' class= 'round-btn round-btn-outline-primary round-btn-sm'><i class='fa-solid fa-pen-to-square'></i></button ><button type='button' onclick='DeleteFinancialYear(\"" + result[i].finyr_id + "\");' class= 'round-btn round-btn-outline-danger round-btn-sm ms-1 '> <i class='fa-regular fa-trash-can'></i></button ></td > ");

            serial_no++;
            $("#tbl_InvoiceSeries tbody").append(tr);

        }

    }
}
//FUNCTION FOR INVOICE SERIES LIST
function InvoiceSeriesList() {
    try {
        ShowLoader();
        AjaxSubmission(null, "/Master/FinancialYear/GetInvoiceSeriesList", $('input[name=__RequestVerificationToken]').val()).done(function (data) {
            let obj = data;
            if (obj.status == true) {
                if (obj.responsecode == '100') {
                    BindInvoiceSeriesTable(obj.data.Table, 1);

                }
                //else {
                //    Toast(RetrieveMessage(obj.responsecode), "Message", "error");
                //}

                FinancialYearList(1);
            }
            else {
                window.location.href = '/ClientLogin/ClientLogin';
            }
            HideLoader();
        }).fail(function (result) {
            console.log(result.Message);
            HideLoader();
        });
    }
    catch (e) {
        console.log(e.message);
        HideLoader();
    }
}



//FUNCTION FOR ADD INVOICE SERIES
function AddInvoiceSeries() {
    try {
        debugger;
        const dataString = {};
        var tmp = new Array();
        $('#tbl_InvoiceSeries .my').each(function (e, th) {
            var Root = {};
            Root.YearId = parseInt(YearId);
            Root.BranchId = $(this).find("td:nth-child(4)").html();
            Root.InvoiceTypeId = $(this).find("td:nth-child(5)").html();
            Root.InvoiceSeries = $(this).find("td:nth-child(6) input[type='text']").val();
            tmp.push(Root);
        });
        dataString.invoiceSeriesdatas = tmp;
        if (tmp.length == 0) {
            window.location.reload();
        } else {
            AjaxSubmission(JSON.stringify(dataString), "/Master/FinancialYear/AddInvoiceSeries", $('input[name=__RequestVerificationToken]').val()).done(function (result) {
                let obj = result;
                if (obj.status == true) {
                    debugger
                    if (obj.responsecode == '101') {
                        setTimeout(FinancialYearList(1), 500);
                        //ResetData();
                        //TabHide();
                        $("#Year_add").hide();
                        $("#Year_update").show();
                        $("#FormReset").show();
                        $("#AddFinancialYearTab").html("Edit Financial Year");
                    }
                    else {
                        Toast(RetrieveMessage(obj.responsecode), "Message", "error");
                    }
                    window.location.reload();
                }
                else {
                    window.location.href = '/ClientLogin/ClientLogin';
                }
                HideLoader();
            }).fail(function (result) {
                console.log(result.Message);
                HideLoader();
            });
        }
    }
    catch (e) {
        console.log(e.message);
        HideLoader();
    }
}

// BIND INVOICE SERIES TABLE ON EDIT
function BindInvoiceSeriesTableOnEdit(result, serial_no) {
    $("#tbl_InvoiceSeries tbody tr").remove();
    if (result.length == 0) {
        tr = $('<tr/>');
        tr.append("<td class='text-center' colspan='9'>NO RESULTS FOUND</td>");
        $("#tbl_InvoiceSeries tbody").append(tr);
    }
    else {
        tr = $('<tr/>');
        tr.append("<td align='Right' colspan='4'>{branch_code}/{book_type}/{invoice_type}/{sub_bill_no},{M} - JUN, {m} - 06, {Y} - 2017, {y} - 17,{Y+1} - 2018, {y+1} - 18</td>");
        $("#tbl_InvoiceSeries tbody").append(tr);
        for (i = 0; i < result.length; i++) {
            if (result[i].is_active == "Inactive")
                tr = $(' <tr class="my" style="background-color:#fdd2d2;"/>');
            else
                tr = $('<tr class="my" />');
            tr.append("<td class='text-center'>" + serial_no + "</td>");
            tr.append("<td class='text-center'>" + result[i].BranchName + "</td>");
            tr.append("<td class='text-center'>" + result[i].invoice_type + "</td>");
            tr.append("<td class='text-center d-none'>" + result[i].BranchUid + "</td>");
            tr.append("<td class='text-center d-none'>" + result[i].invoicetype_id + "</td>");
            tr.append("<td class='text-center col-md-5'><input id='InvoiceSeries' value='" + HandleNullTextValue(result[i].invoice_series) +
                "' name='InvoiceSeries' type='text' onblur='TrimValue(this);' maxlength='100'  class='form-control form-control-sm ' autocomplete='off' /></td>")
            serial_no++;
            $("#tbl_InvoiceSeries tbody").append(tr);
        }
    }
}

//FUNCTION FOR ADD UPDATE SERIES
function UpdateInvoiceSeries() {
    try {
        const dataString = {};
        var tmp = new Array();
        $('#tbl_InvoiceSeries .my').each(function (e, th) {
            var Root = {};
            Root.YearId = parseInt(YearId);
            Root.BranchId = $(this).find("td:nth-child(4)").html();
            Root.InvoiceTypeId = $(this).find("td:nth-child(5)").html();
            Root.InvoiceSeries = $(this).find("td:nth-child(6) input[type='text']").val();
            tmp.push(Root);
        });
        dataString.invoiceSeriesdatas = tmp;
        AjaxSubmission(JSON.stringify(dataString), "/Master/FinancialYear/UpdateInvoiceSeries", $('input[name=__RequestVerificationToken]').val()).done(function (result) {
            let obj = result;
            if (obj.status == true) {
                if (obj.responsecode == '100') {
                    setTimeout(FinancialYearList(1), 500);
                }
                else {
                    Toast(RetrieveMessage(obj.responsecode), "Message", "error");
                }
            }
            else {
                window.location.href = '/ClientLogin/ClientLogin';
            }
            HideLoader();
        }).fail(function (result) {
            console.log(result.Message);
            HideLoader();
        });
    }
    catch (e) {
        console.log(e.message);
        HideLoader();
    }
}
$(".AllFinancialYear").click(function () {
    $("#YearId").focus();
})

$("#FormReset").click(function () {
    $("#FormReset").hide();
    $("#Year_update").hide();
    $("#Year_add").show();
    ResetData();
})

document.addEventListener("keydown", function (zEvent) {
    if (zEvent.ctrlKey && zEvent.altKey && (zEvent.key == "j" || zEvent.key == "J")) {
        $('#AllFinancialYearTab').removeClass('active ');
        $('#AllFinancialYear').removeClass('active show');
        $('#AddFinancialYearTab').addClass('active');
        $('#AddFinancialYear').addClass('active show');
        $("#Year_add").show();
        $("#Year_update").hide();
        $("#AddFinancialYearTab").html("Add Financial Year");
        ResetData();
        $('#FromDate').focus();
    }
});


//BINDING VOUCHER SERIES LIST TABLE
function BindVoucherSeriesTable(result, serial_no) {
    $("#tbl_VoucherSeries tbody tr").remove();
    if (result.length == 0) {
        tr = $('<tr/>');
        tr.append("<td class='text-center' colspan='9'>NO RESULTS FOUND</td>");
        $("#tbl_VoucherSeries tbody").append(tr);
    }
    else {
        tr = $('<tr/>');
        tr.append("<td align='Right' colspan='4'>{branch_code}/{book_type}/{sub_Voucher_no},{M} - JUN, {m} - 06, {Y} - 2017, {y} - 17,{Y+1} - 2018, {y+1} - 18</td>");
        $("#tbl_VoucherSeries tbody").append(tr);
        for (i = 0; i < result.length; i++) {
            if (result[i].is_active == "Inactive")
                tr = $(' <tr class="my" style="background-color:#fdd2d2;"/>');
            else
                tr = $('<tr class="my" />');
            tr.append("<td class='text-center'>" + serial_no + "</td>");
            tr.append("<td class='text-center'>" + result[i].BranchName + "</td>");
            tr.append("<td class='text-center'>" + result[i].Book_Type + "</td>");
            tr.append("<td class='text-center d-none'>" + result[i].BranchUid + "</td>");
            tr.append("<td class='text-center d-none'>" + result[i].vouchertype_id + "</td>");
            tr.append("<td class='text-center col-md-5'><input id='VoucherSeries' name='VoucherSeries' type='text' onblur='TrimValue(this);' data-minlength='5' maxlength='100'  class='form-control form-control-sm ' autocomplete='off' /></td>")
            serial_no++;
            $("#tbl_VoucherSeries tbody").append(tr);
        }
    }
}
//FUNCTION FOR VOUCHER SERIES LIST
function VoucherTypeList() {
    try {
        ShowLoader();
        AjaxSubmission(null, "/Master/FinancialYear/GetVoucherTypeList", $('input[name=__RequestVerificationToken]').val()).done(function (data) {
            let obj = data;
            if (obj.status == true) {
                if (obj.responsecode == '100') {
                    BindVoucherSeriesTable(obj.data.Table, 1);
                }
                FinancialYearList(1);
            }
            else {
                window.location.href = '/ClientLogin/ClientLogin';
            }
            HideLoader();
        }).fail(function (result) {
            console.log(result.Message);
            HideLoader();
        });
    }
    catch (e) {
        console.log(e.message);
        HideLoader();
    }
}


//BINDING PUCHASE SERIES LIST TABLE
function BindPurchaseSeriesTable(result, serial_no) {
    $("#tbl_PurchaseSeries tbody tr").remove();
    if (result.length == 0) {
        tr = $('<tr/>');
        tr.append("<td class='text-center' colspan='9'>NO RESULTS FOUND</td>");
        $("#tbl_PurchaseSeries tbody").append(tr);
    }
    else {
        tr = $('<tr/>');
        tr.append("<td align='Right' colspan='4'>{branch_code}/{book_type}/{sub_Purchase_no},{M} - JUN, {m} - 06, {Y} - 2017, {y} - 17,{Y+1} - 2018, {y+1} - 18</td>");
        $("#tbl_PurchaseSeries tbody").append(tr);

        for (i = 0; i < result.length; i++) {
            if (result[i].is_active == "Inactive")
                tr = $(' <tr class="my" style="background-color:#fdd2d2;"/>');
            else
                tr = $('<tr class="my" />');
            tr.append("<td class='text-center'>" + serial_no + "</td>");
            tr.append("<td class='text-center'>" + result[i].BranchName + "</td>");
            tr.append("<td class='text-center'>" + result[i].Book_Type + "</td>");
            tr.append("<td class='text-center d-none'>" + result[i].BranchUid + "</td>");
            tr.append("<td class='text-center d-none'>" + result[i].Purchasetype_id + "</td>");
            tr.append("<td class='text-center col-md-5'><input id='PurchaseSeries' name='PurchaseSeries' type='text' onblur='TrimValue(this);' data-minlength='5' maxlength='100'  class='form-control form-control-sm ' autocomplete='off' /></td>")
            serial_no++;
            $("#tbl_PurchaseSeries tbody").append(tr);
        }
    }
}

//FUNCTION FOR PURCHASE SERIES LIST
function PurchaseTypeList() {
    try {
        ShowLoader();
        AjaxSubmission(null, "/Master/FinancialYear/GetPurchaseTypeList", $('input[name=__RequestVerificationToken]').val()).done(function (data) {
            let obj = data;
            if (obj.status == true) {
                if (obj.responsecode == '100') {
                    BindPurchaseSeriesTable(obj.data.Table, 1);
                }
                else {
                    Toast(RetrieveMessage(obj.responsecode), "Message", "error");
                }
                FinancialYearList(1);
            }
            else {
                window.location.href = '/ClientLogin/ClientLogin';
            }
            HideLoader();
        }).fail(function (result) {
            console.log(result.Message);
            HideLoader();
        });
    }
    catch (e) {
        console.log(e.message);
        HideLoader();
    }
}



//FUNCTION FOR ADD INVOICE SERIES
function AddVoucherSeries() {
    try {
        const dataString = {};
        var tmp = new Array();
        $('#tbl_VoucherSeries .my').each(function (e, th) {
            var Root = {};
            Root.YearId = parseInt(YearId);
            Root.BranchId = $(this).find("td:nth-child(4)").html();
            Root.BookType = $(this).find("td:nth-child(3)").html();
            Root.VoucherSeries = $(this).find("td:nth-child(6) input[type='text']").val();
            tmp.push(Root);
        });
        dataString.voucherSeriesdatas = tmp;
        if (tmp.length == 0) {
            window.location.reload();
        } else {
            AjaxSubmission(JSON.stringify(dataString), "/Master/FinancialYear/AddVoucherSeries", $('input[name=__RequestVerificationToken]').val()).done(function (result) {
                let obj = result;
                if (obj.status == true) {
                    debugger
                    if (obj.responsecode == '101') {
                        setTimeout(FinancialYearList(1), 500);
                        //ResetData();
                        //TabHide();
                        $("#Year_add").hide();
                        $("#Year_update").show();
                        $("#FormReset").show();
                        $("#AddFinancialYearTab").html("Edit Financial Year");
                    }
                    else {
                        Toast(RetrieveMessage(obj.responsecode), "Message", "error");
                    }
                    window.location.reload();
                }
                else {
                    window.location.href = '/ClientLogin/ClientLogin';
                }
                HideLoader();
            }).fail(function (result) {
                console.log(result.Message);
                HideLoader();
            });
        }
    }
    catch (e) {
        console.log(e.message);
        HideLoader();
    }
}


// BIND VOUCHER SERIES TABLE ON EDIT
function BindVoucherSeriesTableOnEdit(result, serial_no) {
    $("#tbl_VoucherSeries tbody tr").remove();
    if (result.length == 0) {
        tr = $('<tr/>');
        tr.append("<td class='text-center' colspan='9'>NO RESULTS FOUND</td>");
        $("#tbl_VoucherSeries tbody").append(tr);
    }
    else {
        tr = $('<tr/>');
        tr.append("<td align='Right' colspan='4'>{branch_code}/{book_type}/{sub_bill_no},{M} - JUN, {m} - 06, {Y} - 2017, {y} - 17,{Y+1} - 2018, {y+1} - 18</td>");
        $("#tbl_VoucherSeries tbody").append(tr);
        for (i = 0; i < result.length; i++) {
            if (result[i].is_active == "Inactive")
                tr = $(' <tr class="my" style="background-color:#fdd2d2;"/>');
            else
                tr = $('<tr class="my" />');
            tr.append("<td class='text-center'>" + serial_no + "</td>");
            tr.append("<td class='text-center'>" + result[i].BranchName + "</td>");
            tr.append("<td class='text-center'>" + result[i].Book_Type + "</td>");
            tr.append("<td class='text-center d-none'>" + result[i].BranchUid + "</td>");
            tr.append("<td class='text-center d-none'>" + result[i].Voucher_series_id + "</td>");
            tr.append("<td class='text-center col-md-5'><input id='VoucherSeries' value='" + HandleNullTextValue(result[i].Voucher_series) +
                "' name='VoucherSeries' type='text' onblur='TrimValue(this);' maxlength='100'  class='form-control form-control-sm ' autocomplete='off' /></td>")
            serial_no++;
            $("#tbl_VoucherSeries tbody").append(tr);
        }
    }
}


//FUNCTION FOR ADD UPDATE SERIES
function UpdateVoucherSeries() {
    try {
        const dataString = {};
        var tmp = new Array();
        $('#tbl_VoucherSeries .my').each(function (e, th) {
            var Root = {};
            Root.YearId = parseInt(YearId);
            Root.BranchId = $(this).find("td:nth-child(4)").html();
            Root.BookType = $(this).find("td:nth-child(3)").html();
            Root.VoucherSeries = $(this).find("td:nth-child(6) input[type='text']").val();
            tmp.push(Root);
        });
        dataString.voucherSeriesdatas = tmp;
        AjaxSubmission(JSON.stringify(dataString), "/Master/FinancialYear/UpdateVoucherSeries", $('input[name=__RequestVerificationToken]').val()).done(function (result) {
            let obj = result;
            if (obj.status == true) {
                if (obj.responsecode == '100') {
                    setTimeout(FinancialYearList(1), 500);
                }
                else {
                    Toast(RetrieveMessage(obj.responsecode), "Message", "error");
                }
            }
            else {
                window.location.href = '/ClientLogin/ClientLogin';
            }
            HideLoader();
        }).fail(function (result) {
            console.log(result.Message);
            HideLoader();
        });
    }
    catch (e) {
        console.log(e.message);
        HideLoader();
    }
}



//FUNCTION FOR ADD INVOICE SERIES
function AddPurchaseSeries() {
    try {
        const dataString = {};
        var tmp = new Array();
        $('#tbl_PurchaseSeries .my').each(function (e, th) {
            var Root = {};
            Root.YearId = parseInt(YearId);
            Root.BranchId = $(this).find("td:nth-child(4)").html();
            Root.BookType = $(this).find("td:nth-child(3)").html();
            Root.PurchaseSeries = $(this).find("td:nth-child(6) input[type='text']").val();
            tmp.push(Root);
        });
        dataString.purchaseSeriesdatas = tmp;
        if (tmp.length == 0) {
            window.location.reload();
        } else {
            AjaxSubmission(JSON.stringify(dataString), "/Master/FinancialYear/AddPurchaseSeries", $('input[name=__RequestVerificationToken]').val()).done(function (result) {
                let obj = result;
                if (obj.status == true) {
                    debugger
                    if (obj.responsecode == '101') {
                        setTimeout(FinancialYearList(1), 500);
                        //ResetData();
                        //TabHide();
                        $("#Year_add").hide();
                        $("#Year_update").show();
                        $("#FormReset").show();
                        $("#AddFinancialYearTab").html("Edit Financial Year");
                    }
                    else {
                        Toast(RetrieveMessage(obj.responsecode), "Message", "error");
                    }
                    window.location.reload();
                }
                else {
                    window.location.href = '/ClientLogin/ClientLogin';
                }
                HideLoader();
            }).fail(function (result) {
                console.log(result.Message);
                HideLoader();
            });
        }
    }
    catch (e) {
        console.log(e.message);
        HideLoader();
    }
}


// BIND PURCHASE SERIES TABLE ON EDIT
function BindPurchaseSeriesTableOnEdit(result, serial_no) {
    $("#tbl_PurchaseSeries tbody tr").remove();
    if (result.length == 0) {
        tr = $('<tr/>');
        tr.append("<td class='text-center' colspan='9'>NO RESULTS FOUND</td>");
        $("#tbl_PurchaseSeries tbody").append(tr);
    }
    else {
        tr = $('<tr/>');
        tr.append("<td align='Right' colspan='4'>{branch_code}/{book_type}/{sub_bill_no},{M} - JUN, {m} - 06, {Y} - 2017, {y} - 17,{Y+1} - 2018, {y+1} - 18</td>");
        $("#tbl_PurchaseSeries tbody").append(tr);
        for (i = 0; i < result.length; i++) {
            if (result[i].is_active == "Inactive")
                tr = $(' <tr class="my" style="background-color:#fdd2d2;"/>');
            else
                tr = $('<tr class="my" />');
            tr.append("<td class='text-center'>" + serial_no + "</td>");
            tr.append("<td class='text-center'>" + result[i].BranchName + "</td>");
            tr.append("<td class='text-center'>" + result[i].Book_Type + "</td>");
            tr.append("<td class='text-center d-none'>" + result[i].BranchUid + "</td>");
            tr.append("<td class='text-center d-none'>" + result[i].Purchase_series_id + "</td>");
            tr.append("<td class='text-center col-md-5'><input id='PurchaseSeries' value='" + HandleNullTextValue(result[i].Purchase_series) +
                "' name='PurchaseSeries' type='text' onblur='TrimValue(this);' maxlength='100'  class='form-control form-control-sm ' autocomplete='off' /></td>")
            serial_no++;
            $("#tbl_PurchaseSeries tbody").append(tr);
        }
    }
}



//FUNCTION FOR ADD UPDATE SERIES
function UpdatePurchaseSeries() {
    try {
        const dataString = {};
        var tmp = new Array();
        $('#tbl_PurchaseSeries .my').each(function (e, th) {
            var Root = {};
            Root.YearId = parseInt(YearId);
            Root.BranchId = $(this).find("td:nth-child(4)").html();
            Root.BookType = $(this).find("td:nth-child(3)").html();
            Root.PurchaseSeries = $(this).find("td:nth-child(6) input[type='text']").val();
            tmp.push(Root);
        });
        dataString.purchaseSeriesdatas = tmp;
        AjaxSubmission(JSON.stringify(dataString), "/Master/FinancialYear/UpdatePurchaseSeries", $('input[name=__RequestVerificationToken]').val()).done(function (result) {
            let obj = result;
            if (obj.status == true) {
                if (obj.responsecode == '100') {
                    setTimeout(FinancialYearList(1), 500);
                }
                else {
                    Toast(RetrieveMessage(obj.responsecode), "Message", "error");
                }
            }
            else {
                window.location.href = '/ClientLogin/ClientLogin';
            }
            HideLoader();
        }).fail(function (result) {
            console.log(result.Message);
            HideLoader();
        });
    }
    catch (e) {
        console.log(e.message);
        HideLoader();
    }
}

//FUNCTION FOR EXPORT DATA IN EXCEL
function FormExcel() {
    ShowLoader();
    let date = new Date();
    let NewDate = ("00" + date.getDate()).slice(-2) + "_" + ("00" + (date.getMonth() + 1)).slice(-2) + "_" + date.getFullYear() + "_" + ("00" + date.getHours()).slice(-2) + "_" + ("00" + date.getMinutes()).slice(-2) + "_" + ("00" + date.getSeconds()).slice(-2);
    let fileName = "FinancialYear_" + NewDate + ".xlsx";

    $('#FormSearch').trigger('click');
    AjaxSubmission(null, '/Master/FinancialYear/FormExcel', $('input[name=__RequestVerificationToken]').val()).done(function (result) {
        let obj = result;
        if (obj.status == true) {
            if (obj.responsecode == '100') {

                let bytes = Base64ToBytes(obj.data.FileData[0].Base64Data);
                let blob = new Blob([bytes], { type: "application/octetstream" });
                let isIE = false || !!document.documentMode;
                if (isIE) {
                    window.navigator.msSaveBlob(blob, fileName);
                } else {
                    let url = window.URL || window.webkitURL;
                    link = url.createObjectURL(blob);
                    let a = $("<a />");
                    a.attr("download", fileName);
                    a.attr("href", link);
                    $("body").append(a);
                    a[0].click();
                    $("body").remove(a);
                }
            }
            else if (obj.responsecode == '302')
                Toast("No Records found.", 'Message', 'success');
            else
                Toast(RetrieveMessage(obj.responsecode), 'Message', 'error');

        } else
            window.location.href = '/ClientLogin/ClientLogin';
        HideLoader();

    }).fail(function (result) {
        console.log(result.Message);
        HideLoader();
    });
}