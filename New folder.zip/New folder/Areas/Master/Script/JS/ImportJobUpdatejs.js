﻿var Detslab = "";
// DOCUMENT READY
$(document).ready(function () {  
    $(".datepickerAll").datepicker({
        changeMonth: true,
        changeYear: true,
        dateFormat: 'dd/mm/yy',

    });
   /* $('#FormSearch').trigger('click');*/
    $("#SearchSubJobNo").focus();

    $("#SearchJobNo").autocomplete({
        source: function (request, response) {
            AjaxSubmissionAutocomplete(JSON.stringify({
                SearchField: request.term, SubJobNo: $("#SearchSubJobNo").val()
            }), '/Master/_Layout/GetJobNumberAutoComplete', $('input[name=__RequestVerificationToken]').val()).done(function (result) {
                let obj = result;
                if (obj.status == true) {
                    if (obj.responsecode == '100') {
                        response($.map(result.data.Table, function (item, id) {
                            return {
                                label: item.name,
                                value: item.name,
                                id: item.id
                            };
                        }));
                    }
                }
                else
                    window.location.href = '/ClientLogin/ClientLogin';               
            }).fail(function (result) {
                console.log(result.Message);
            });
        },
        minLength: 1,
        selectOnly: true,
        select: function (e, i) {
            /*$("#" + HiddenId).val(i.item.id);*/
            $("#SearchJobNo").val(i.item.id);
        },
        change: function (e, i) {
            if (i.item == null || i.item == undefined) {
                //$("#" + id).val('');
                //$("#" + HiddenId).val('');

                $("#SearchJobNo").val('');
                $("#SearchJobNo").val('');
            }
        }
    }).on("focus", function () {
        $(this).autocomplete("search", $("#SearchSubJobNo").val());
    });

})

//SEARCHSUBJOBNO BLUR EVENT
$("#SearchSubJobNo").blur(function () {
    $("#SearchJobNo").val('');
})

//SEARCHSUBJOBNO KEYPRESS EVENT
$("#SearchSubJobNo").bind('keypress', function (e) {
    if (e.keyCode == 13) {
        $("#SearchJobNo").val('');        
        $("#SearchJobNo").focus();
    }
});

//SEARCHJOBNO KEYPRESS EVENT
$("#SearchJobNo").bind('keypress', function (e) {
    if (e.keyCode == 13) {
        $("#FormSearch").trigger('click');
    }
});

//FORMSEARCH BUTTON CLICK 
$("#FormSearch").click(function () {
    ResetForm(1);
    if ($("#SearchJobNo").val().trim().length == 0) {
        Toast('Job Number Required', 'Message', 'error');
        $("#SearchJobNo").focus();
    } else {
        FormEdit($("#SearchJobNo").val().trim());
    }
})

//FUNCTION FOR GET IMPORT JOB DATA
function FormEdit(e) {
    try {
        const dataString = {};
        dataString.JobNo = e;
        AjaxSubmission(JSON.stringify(dataString), '/Master/ImportJobUpdate/FormEdit', $('input[name=__RequestVerificationToken]').val()).done(function (result) {          
            let obj = result;
          
            if (obj.status == true) {
                if (obj.responsecode == '100') {                   
                    $("#CreatedByModifiedBy").css('display', 'block');
                    $("#CreatedByModifiedBy").css('width', '100%');

                    $("#ImporterName").val(obj.data.Table2[0].ClientName);
                    $("#CFSType").val(obj.data.Table2[0].CFSName);
                    $("#Shipper").val(obj.data.Table2[0].ShipperName);
                    Detslab = obj.data.Table2[0].DetentionSlab;
                   
                    if (obj.data.Table2[0].ShippingLineName !=null)
                        $("#ShippingLine").val(obj.data.Table2[0].ShippingLineName);                    
                    FillDetentionSlab(obj.data.Table2[0].ShippingLine);
                   
                    $("#NewBENo ").val(obj.data.Table2[0].NewBENo);
                    $("#NewBEDate").val(obj.data.Table2[0].NewBEDate);

                    $("#BENo").val(obj.data.Table2[0].BENo);
                    $("#BEDate").val(obj.data.Table2[0].BEDate);
                    $("#IGMNo").val(obj.data.Table2[0].IGMNo);
                    $("#IGMItem").val(obj.data.Table2[0].IGMItem);
                    $("#IGMDate").val(obj.data.Table2[0].IGMDate);
                    $("#IGMFinalDate").val(obj.data.Table2[0].IGMFinalDate);
                    $("#ExpectedDate").val(obj.data.Table2[0].ExpectedDate);
                    if (obj.data.Table2[0].RMSGRType!=null)
                        $("#RMSGRType").val(obj.data.Table2[0].RMSGRType);
                    $("#RMSGR").val(obj.data.Table2[0].RMSGR);
                    $("#SSOId").val(obj.data.Table2[0].SSOId);
                    $("#SSOLocation").val(obj.data.Table2[0].SSOLocation);

                    //$("#BondNumber").val(obj.data.Table2[0].BondNumber);
                    //$("#BondCode").val(obj.data.Table2[0].BondCode == null ? 0 : obj.data.Table2[0].BondCode);
                    //$("#BondPort").val(obj.data.Table2[0].BondPort);                  
                    //$("#BondPortName").val(obj.data.Table2[0].BondPortName);
                    //$("#CertificateNumber").val(obj.data.Table2[0].CertificateNumber);
                    //$("#CertificateDate").val(obj.data.Table2[0].CertificateDate);
                    //$("#CertificateType").val(obj.data.Table2[0].CertificateType == null ? 0 : obj.data.Table2[0].CertificateType);

                    $("#APDate").val(obj.data.Table2[0].APDate);

                    $("#FCPPDate").val(obj.data.Table2[0].FCPPDate);
                    $("#FCFPDate").val(obj.data.Table2[0].FCFPDate);

                    $("#PPDate").val(obj.data.Table2[0].PPDate);
                    $("#FPDate").val(obj.data.Table2[0].FPDate);
                    $("#DeclPrintDate").val(obj.data.Table2[0].DeclPrintDate);
                    $("#DECLRecDate").val(obj.data.Table2[0].DECLRecDate);
                    $("#NoteDate").val(obj.data.Table2[0].NoteDate);
                    $("#PassDate").val(obj.data.Table2[0].PassDate);
                    /*$("#AuditDate").val(obj.data.Table2[0].AuditDate);*/
                    $("#AccSignDate").val(obj.data.Table2[0].AccSignDate);
                    $("#IntRate").val(HandleNullTextValueFixed(obj.data.Table2[0].InterestRate, 2));
                    $("#DutyFreeDays").val(HandleNullTextValue(obj.data.Table2[0].DutyFreeDays));
                    $("#IntAmount").val(HandleNullTextValueFixed(obj.data.Table2[0].InterestAmount,2));
                    //$("#HiddenEmptyYard").val(obj.data.Table2[0].EmptyYard);
                    //$("#EmptyYard").val(obj.data.Table2[0].EmptyYardName);

                                     
                    $("#OBLRecDate").val(obj.data.Table2[0].OBLRecDate);
                   /* $("#DocExpDate").val(obj.data.Table2[0].DocExpDate);*/
                    $("#SwblRecDate").val(obj.data.Table2[0].SwblRecDate);
                    $("#TelexRecDate").val(obj.data.Table2[0].TelexRecDate);
                    $("#DocShipLineDate").val(obj.data.Table2[0].DocShipLineDate);
                    $("#StampDutyDate").val(obj.data.Table2[0].StampDutyDate);
                    $("#DutyRecDate").val(obj.data.Table2[0].DutyRecDate);
                    /*$("#DutyExpiryDate").val(obj.data.Table2[0].DutyExpiryDate);*/
                    $("#DutyCashNo").val(obj.data.Table2[0].DutyCashNo);
                    $("#DutyPaidDate").val(obj.data.Table2[0].DutyPaidDate);

                    $("#ShipLPmtAmt").val(obj.data.Table2[0].ShipLPmtAmt);
                    $("#ShipLPmtDate").val(obj.data.Table2[0].ShipLPmtDate);
                    $("#ShipLPmtMode").val(obj.data.Table2[0].ShipLPmtMode);  
                    $("#HseasNo").val(obj.data.Table2[0].HseasNo);
                    /*$("#HseasCDate").val(obj.data.Table2[0].HseasCDate);*/
                    $("#AmdNo").val(obj.data.Table2[0].AmdNo);
                    $("#AmdDate").val(obj.data.Table2[0].AmdDate);

                    $("#DoRecDate").val(obj.data.Table2[0].DoRecDate);
                    if (obj.data.Table2[0].DeliveryType !=null)
                        $("#DeliveryType").val(obj.data.Table2[0].DeliveryType);
                    $("#ContainerLastFreeDate").val(obj.data.Table2[0].ContainerLastFreeDate);
                    $("#CLfdVd").val(obj.data.Table2[0].CLfdVd);
                    $("#FreeDays").val(obj.data.Table2[0].FreeDays);
                    $("#BPTLFDDate").val(obj.data.Table2[0].BPTLFDDate);
                    $("#FreeDaysGR").val(obj.data.Table2[0].FreeDaysGR); 

                    $("#CreatedBy").text(HandleNullTextValue(obj.data.Table2[0].CreatedByName));
                    $("#CreatedAt").text(HandleNullTextValue(obj.data.Table2[0].CreatedAt));

                    $("#ModifiedBy").text(HandleNullTextValue(obj.data.Table2[0].LastUpdatedByName));
                    $("#ModifiedAt").text(HandleNullTextValue(obj.data.Table2[0].LastUpdatedAt));

                    let ContainerFirstChild = $("#TblContainerDetails").find('tbody tr:first-child');

                    $.each(obj.data.Table, function (ind, ele) {
                        if (ind == 0) {                         
                            ContainerFirstChild.find('.ContainerNo').val(ele.ContainerNo);
                            ContainerFirstChild.find('.SealNo').val(ele.SealNo);
                            ContainerFirstChild.find('.OurSealNo').val(ele.OurSealNo);

                            ContainerFirstChild.find('.ContType').val(ele.ContType);
                            ContainerFirstChild.find('.HiddenContCFSType').val(ele.ContCFSType);
                            ContainerFirstChild.find('.ContCFSType').val(ele.ContCFSTypeName);

                            ContainerFirstChild.find('.ContainerWeight').val(HandleNullTextValueFixed(ele.ContainerWeight, 3));
                            ContainerFirstChild.find('.ContainerArrivalDate').val(ele.ContainerArrivalDate);
                            

                            ContainerFirstChild.find('.ContainerExamineDate').val(ele.ContainerExamineDate);
                            ContainerFirstChild.find('.OutChargeDate').val(ele.OutChargeDate);
                            ContainerFirstChild.find('.GatePassDate').val(ele.GatePassDate);

                            ContainerFirstChild.find('.ContainerDeliveryDate').val(ele.ContainerDeliveryDate);
                            ContainerFirstChild.find('.ContainerDestuffingDate').val(ele.ContainerDestuffingDate);
                            ContainerFirstChild.find('.ContainerDeliverToParty').val(ele.ContainerDeliverToParty);

                            ContainerFirstChild.find('.ContainerEmptyDate').val(ele.ContainerEmptyDate);
                            ContainerFirstChild.find('.HiddenEmptyYard').val(ele.EmptyYard);
                            ContainerFirstChild.find('.EmptyYard').val(ele.EmptyYardName);

                            ContainerFirstChild.find('.ReUseDate').val(ele.ReUseDate);
                            ContainerFirstChild.find('.ReUseBy').val(ele.ReUseBy);
                            ContainerFirstChild.find('.ContainerGroundRentLFDDate').val(ele.ContainerGroundRentLFDDate);

                            ContainerFirstChild.find('.GRAmount').val(HandleNullTextValueFixed(ele.GRAmount, 2));
                            ContainerFirstChild.find('.LRNo').val(ele.LRNo);
                            ContainerFirstChild.find('.TruckNo').val(ele.TruckNo);

                            ContainerFirstChild.find('.Loaded').val(ele.Loaded);
                            ContainerFirstChild.find('.HiddenPrivateYard').val(ele.PrivateYard);
                            ContainerFirstChild.find('.PrivateYard').val(ele.PrivateYardName);

                            ContainerFirstChild.find('.GrossWeight').val(HandleNullTextValueFixed(ele.GrossWeight, 3));
                            ContainerFirstChild.find('.TareWeight').val(HandleNullTextValueFixed(ele.TareWeight, 3));
                            ContainerFirstChild.find('.NetWeight').val(HandleNullTextValueFixed(ele.NetWeight, 3));

                            ContainerFirstChild.find('.HiddenTransporter').val(ele.Transporter);
                            ContainerFirstChild.find('.Transporter').val(ele.TransporterName);
                            ContainerFirstChild.find('.Destination').val(ele.Destination);

                            ContainerFirstChild.find('.ExchangeRate').val(HandleNullTextValueFixed(ele.ExchangeRate, 2));
                            ContainerFirstChild.find('.DemmAmount').val(HandleNullTextValueFixed(ele.DemmAmount, 2));
                            ContainerFirstChild.find('.DetentionAmount').val(HandleNullTextValueFixed(ele.DetentionAmount, 2));

                            if (ele.ForScan != null)
                                ContainerFirstChild.find('.ForScan').prop('checked', ele.ForScan);
                            if (ele.ScanPending != null)
                                ContainerFirstChild.find('.ScanPending').prop('checked', ele.ScanPending);
                            if (ele.NotScan != null)
                                ContainerFirstChild.find('.NotScan').prop('checked', ele.NotScan);
                            if (ele.Examine100 != null)
                                ContainerFirstChild.find('.Examine100').prop('checked', ele.Examine100);
                            if (ele.MScan != null)
                                ContainerFirstChild.find('.MScan').prop('checked', ele.MScan);
                            if (ele.RScan != null)
                                ContainerFirstChild.find('.RScan').prop('checked', ele.RScan);
                            if (ele.ScanImage != null)
                                ContainerFirstChild.find('.ScanImage').prop('checked', ele.ScanImage);

                            ContainerFirstChild.find('.ScanOkDate').val(ele.ScanOkDate);
                            ContainerFirstChild.find('.ContainerRemarks').val(ele.ContainerRemarks);
                        }
                        else {

                            ContainerFirstChild.find('.ContainerArrivalDate,.ContainerExamineDate,.OutChargeDate,.GatePassDate,.ContainerDeliveryDate,.ContainerDestuffingDate,.ContainerDeliverToParty,.ContainerEmptyDate,.ReUseDate,.ContainerGroundRentLFDDate,.ScanOkDate').datepicker("destroy");
                            
                            ContainerFirstChild.find('.ContainerArrivalDate,.ContainerExamineDate,.OutChargeDate,.GatePassDate,.ContainerDeliveryDate,.ContainerDestuffingDate,.ContainerDeliverToParty,.ContainerEmptyDate,.ReUseDate,.ContainerGroundRentLFDDate,.ScanOkDate').removeAttr("id");
                           
                            let ConatinerCloneChild = ContainerFirstChild.clone();

                            ConatinerCloneChild.find('.ContainerNo').val(ele.ContainerNo);
                            ConatinerCloneChild.find('.SealNo').val(ele.SealNo);
                            ConatinerCloneChild.find('.OurSealNo').val(ele.OurSealNo);

                            ConatinerCloneChild.find('.ContType').val(ele.ContType);
                            ConatinerCloneChild.find('.HiddenContCFSType').val(ele.ContCFSType);
                            ConatinerCloneChild.find('.ContCFSType').val(ele.ContCFSTypeName);

                            ConatinerCloneChild.find('.ContainerWeight').val(HandleNullTextValueFixed(ele.ContainerWeight, 3));
                            ConatinerCloneChild.find('.ContainerArrivalDate').val(ele.ContainerArrivalDate);
                          

                            ConatinerCloneChild.find('.ContainerExamineDate').val(ele.ContainerExamineDate);
                            ConatinerCloneChild.find('.ContainerDeliveryDate').val(ele.ContainerDeliveryDate);
                            ConatinerCloneChild.find('.ContainerDestuffingDate').val(ele.ContainerDestuffingDate);

                            ConatinerCloneChild.find('.ContainerDeliverToParty').val(ele.ContainerDeliverToParty);
                            ConatinerCloneChild.find('.ContainerEmptyDate').val(ele.ContainerEmptyDate);
                            ConatinerCloneChild.find('.ContainerGroundRentLFDDate').val(ele.ContainerGroundRentLFDDate);

                            ConatinerCloneChild.find('.GRAmount').val(HandleNullTextValueFixed(ele.GRAmount, 2));
                            ConatinerCloneChild.find('.LRNo').val(ele.LRNo);
                            ConatinerCloneChild.find('.TruckNo').val(ele.TruckNo);

                            ConatinerCloneChild.find('.Loaded').val(ele.Loaded);
                            ConatinerCloneChild.find('.HiddenPrivateYard').val(ele.PrivateYard);
                            ConatinerCloneChild.find('.PrivateYard').val(ele.PrivateYardName);

                            ConatinerCloneChild.find('.GrossWeight').val(HandleNullTextValueFixed(ele.GrossWeight, 3));
                            ConatinerCloneChild.find('.TareWeight').val(HandleNullTextValueFixed(ele.TareWeight, 3));
                            ConatinerCloneChild.find('.NetWeight').val(HandleNullTextValueFixed(ele.NetWeight, 3));

                            ConatinerCloneChild.find('.HiddenTransporter').val(ele.Transporter);
                            ConatinerCloneChild.find('.Transporter').val(ele.TransporterName);
                            ConatinerCloneChild.find('.Destination').val(ele.Destination);

                            ConatinerCloneChild.find('.ExchangeRate').val(HandleNullTextValueFixed(ele.ExchangeRate, 2));
                            ConatinerCloneChild.find('.DemmAmount').val(HandleNullTextValueFixed(ele.DemmAmount, 2));
                            ConatinerCloneChild.find('.DetentionAmount').val(HandleNullTextValueFixed(ele.DetentionAmount, 2));

                            if (ele.ForScan != null)
                                ConatinerCloneChild.find('.ForScan').prop('checked', ele.ForScan);
                            else
                                ConatinerCloneChild.find('.ForScan').prop('checked', false);

                            if (ele.ScanPending != null)
                                ConatinerCloneChild.find('.ScanPending').prop('checked', ele.ScanPending);
                            else
                                ConatinerCloneChild.find('.ScanPending').prop('checked', false);

                            if (ele.NotScan != null)
                                ConatinerCloneChild.find('.NotScan').prop('checked', ele.NotScan);
                            else
                                ConatinerCloneChild.find('.NotScan').prop('checked', false);

                            if (ele.Examine100 != null)
                                ConatinerCloneChild.find('.Examine100').prop('checked', ele.Examine100);
                            else
                                ConatinerCloneChild.find('.Examine100').prop('checked', false);

                            if (ele.MScan != null)
                                ConatinerCloneChild.find('.MScan').prop('checked', ele.MScan);
                            else
                                ConatinerCloneChild.find('.MScan').prop('checked', false);

                            if (ele.RScan != null)
                                ConatinerCloneChild.find('.RScan').prop('checked', ele.RScan);
                            else
                                ConatinerCloneChild.find('.RScan').prop('checked', false);

                            if (ele.ScanImage != null)
                                ConatinerCloneChild.find('.ScanImage').prop('checked', ele.ScanImage);
                            else
                                ConatinerCloneChild.find('.ScanImage').prop('checked', false);

                         
                            ConatinerCloneChild.find('.ScanOkDate').val(ele.ScanOkDate);
                            ConatinerCloneChild.find('.ContainerRemarks').val(ele.ContainerRemarks);


                            $("#TblContainerDetails tbody").append(ConatinerCloneChild);

                            $(".datepickerAll").datepicker({
                                changeMonth: true,
                                changeYear: true,
                                dateFormat: 'dd/mm/yy'
                            });
                        }
                    });

                    let DocumentFirstChild = $("#TblDocumentDetails").find('tbody tr:first-child');

                    $.each(obj.data.Table1, function (ind, ele) {
                        if (ind == 0) {

                            DocumentFirstChild.find('.rn').text(ind + 1);
                            DocumentFirstChild.find('.DocType').val(ele.DocType);
                            DocumentFirstChild.find('.DocumentName').val(ele.DocumentName);
                            DocumentFirstChild.find('.DocumentDate').val(ele.DocumentDate);
                            DocumentFirstChild.find('.CategoryName').val(ele.CategoryName);
                        }
                        else {
                           
                            DocumentFirstChild.find('.DocumentDate').datepicker("destroy");
                            DocumentFirstChild.find('.DocumentDate').removeAttr("id");

                            let DocumentCloneChild = DocumentFirstChild.clone();

                            DocumentCloneChild.find('.rn').text(ind + 1);
                            DocumentCloneChild.find('.DocType').val(ele.DocType);
                            DocumentCloneChild.find('.DocumentName').val(ele.DocumentName);
                            DocumentCloneChild.find('.DocumentDate').val(ele.DocumentDate);
                            DocumentCloneChild.find('.CategoryName').val(ele.CategoryName);

                            $("#TblDocumentDetails tbody").append(DocumentCloneChild);

                            $(".datepickerAll").datepicker({
                                changeMonth: true,
                                changeYear: true,
                                dateFormat: 'dd/mm/yy'
                            });
                        }
                    })
                }               
                else
                    Toast(RetrieveMessage(obj.responsecode), 'Message', 'error');

            } else
                window.location.href = '/ClientLogin/ClientLogin';           

        }).fail(function (result) {
            console.log(result.Message);            
        });
    }
    catch (e) {
        console.log(e.message);
    }
}

//FORMRESET BUTTON CLICK
$("#FormReset").click(function () {
    ResetForm();
});
//FORMUPDATE BUTTON CLICK
$("#FormUpdate").click(function () {   
    if ($("#SearchJobNo").val().trim().length == 0) {
        Toast('Job Number Required', 'Message', 'error');
        $("#SearchJobNo").focus();
    } else {
        FormUpdate();
    }
});

//FUNCTION FOR UPDATE IMPORT JOB DATA
function FormUpdate() {
    try {      
        //Showloader();
        const dataString = {};
        debugger;
        dataString.SubJobNo = $("#SearchSubJobNo").val();
        dataString.JobNo = $("#SearchJobNo").val().trim();

        /*alert($("#DetentionSlabType").val());*/
        if ($("#DetentionSlabType").val() != 0)
            dataString.DetentionSlabType = $("#DetentionSlabType").val();
        

        dataString.NewBENo = $("#NewBENo").val().trim();
        dataString.NewBEDate = $("#NewBEDate").val().trim();

        dataString.BENo = $("#BENo").val().trim();
        dataString.BEDate = $("#BEDate").val().trim();
        dataString.IGMNo = $("#IGMNo").val().trim();
        dataString.IGMItem = $("#IGMItem").val().trim();
        dataString.IGMDate = $("#IGMDate").val().trim();
        dataString.IGMFinalDate = $("#IGMFinalDate").val().trim();
        dataString.ExpectedDate = $("#ExpectedDate").val().trim();
        dataString.RMSGRType = $("#RMSGRType").val();
        dataString.RMSGR = $("#RMSGR").val().trim();
        dataString.SSOId = $("#SSOId").val().trim();
        dataString.SSOLocation = $("#SSOLocation").val().trim();

        //dataString.BondNumber = $("#BondNumber").val().trim();
        //dataString.BondCode = $("#BondCode").val();
        //dataString.BondPort = $("#BondPort").val().trim();
        //dataString.BondPortName = $("#BondPortName").val().trim();
        //dataString.CertificateNumber = $("#CertificateNumber").val().trim();
        //dataString.CertificateDate = $("#CertificateDate").val().trim();
        //dataString.CertificateType = $("#CertificateType").val();
        
        dataString.APDate = $("#APDate").val().trim();
        dataString.FCPPDate = $("#FCPPDate").val().trim();
        dataString.FCFPDate = $("#FCFPDate").val().trim();

        dataString.PPDate = $("#PPDate").val().trim();
        dataString.FPDate = $("#FPDate").val().trim();
        dataString.DeclPrintDate = $("#DeclPrintDate").val().trim();
        dataString.DECLRecDate = $("#DECLRecDate").val().trim();
        dataString.NoteDate = $("#NoteDate").val().trim();
        dataString.PassDate = $("#PassDate").val().trim();
        /*dataString.AuditDate = $("#AuditDate").val().trim();*/
        dataString.AccSignDate = $("#AccSignDate").val().trim();
        dataString.IntRate = $("#IntRate").val().trim();
        dataString.DutyFreeDays = $("#DutyFreeDays").val().trim();
        dataString.IntAmount = $("#IntAmount").val().trim();
       /* dataString.EmptyYard = $("#HiddenEmptyYard").val().trim();*/
             
        dataString.OBLRecDate = $("#OBLRecDate").val().trim();
        /*dataString.DocExpDate = $("#DocExpDate").val().trim();*/
        dataString.SwblRecDate = $("#SwblRecDate").val().trim();
        dataString.TelexRecDate = $("#TelexRecDate").val().trim();
        dataString.DocShipLineDate = $("#DocShipLineDate").val().trim();
        dataString.StampDutyDate = $("#StampDutyDate").val().trim();
        dataString.DutyRecDate = $("#DutyRecDate").val().trim();
       /* dataString.DutyExpiryDate = $("#DutyExpiryDate").val().trim();*/
        dataString.DutyCashNo = $("#DutyCashNo").val().trim();
        dataString.DutyPaidDate = $("#DutyPaidDate").val().trim();

        dataString.ShipLPmtAmt = $("#ShipLPmtAmt").val().trim();
        dataString.ShipLPmtDate = $("#ShipLPmtDate").val().trim();
        dataString.ShipLPmtMode = $("#ShipLPmtMode").val().trim(); 
        dataString.HseasNo = $("#HseasNo").val().trim();
        /*dataString.HseasCDate = $("#HseasCDate").val().trim();*/
        dataString.AmdNo = $("#AmdNo").val().trim();
        dataString.AmdDate = $("#AmdDate").val().trim();
       
        dataString.DoRecDate = $("#DoRecDate").val().trim();
        dataString.DeliveryType = $("#DeliveryType").val().trim();
        dataString.ContainerLastFreeDate = $("#ContainerLastFreeDate").val().trim();
        dataString.CLfdVd = $("#CLfdVd").val().trim();
        dataString.FreeDays = $("#FreeDays").val().trim();
        dataString.BPTLFDDate = $("#BPTLFDDate").val().trim();
        dataString.FreeDaysGR = $("#FreeDaysGR").val().trim();  

        let ContainerDetails = new Array();

        $("#TblContainerDetails tbody tr").each(function (ind, ele) {

            if ($(ele).find('.ContainerNo').val().trim().length > 0) {

                let ContDet = {};

                ContDet.ContainerNo = $(ele).find('.ContainerNo').val().trim();
                ContDet.SealNo = $(ele).find('.SealNo').val().trim();
                ContDet.OurSealNo = $(ele).find('.OurSealNo').val().trim();

                ContDet.ContType = $(ele).find('.ContType').val().trim();
                ContDet.ContCFSType = parseInt($(ele).find('.HiddenContCFSType').val().trim());
                ContDet.ContainerWeight = parseFloat($(ele).find('.ContainerWeight').val().trim());

                ContDet.ContainerArrivalDate = $(ele).find('.ContainerArrivalDate').val().trim();
               
                ContDet.ContainerExamineDate = $(ele).find('.ContainerExamineDate').val().trim();

                ContDet.OutChargeDate = $(ele).find('.OutChargeDate').val().trim();
                ContDet.GatePassDate = $(ele).find('.GatePassDate').val().trim();
                ContDet.ContainerDeliveryDate = $(ele).find('.ContainerDeliveryDate').val().trim();

                ContDet.ContainerDestuffingDate = $(ele).find('.ContainerDestuffingDate').val().trim();
                ContDet.ContainerDeliverToParty = $(ele).find('.ContainerDeliverToParty').val().trim();
                ContDet.ContainerEmptyDate = $(ele).find('.ContainerEmptyDate').val().trim();

                ContDet.EmptyYard = $(ele).find('.HiddenEmptyYard').val().trim();
                ContDet.ReUseDate = $(ele).find('.ReUseDate').val().trim();
                ContDet.ReUseBy = $(ele).find('.ReUseBy').val().trim();

                ContDet.ContainerGroundRentLFDDate = $(ele).find('.ContainerGroundRentLFDDate').val().trim();
                ContDet.GRAmount = parseFloat($(ele).find('.GRAmount').val().trim());
                ContDet.LRNo = $(ele).find('.LRNo').val().trim();

                ContDet.TruckNo = $(ele).find('.TruckNo').val().trim();
                ContDet.Loaded = $(ele).find('.Loaded').val();
                ContDet.PrivateYard = parseInt($(ele).find('.HiddenPrivateYard').val().trim());

                ContDet.GrossWeight = parseFloat($(ele).find('.GrossWeight').val().trim());
                ContDet.TareWeight = parseFloat($(ele).find('.TareWeight').val().trim());
                ContDet.NetWeight = parseFloat($(ele).find('.NetWeight').val().trim());

                ContDet.Transporter = parseInt($(ele).find('.HiddenTransporter').val().trim());
                ContDet.Destination = $(ele).find('.Destination').val().trim();
                ContDet.ExchangeRate = parseFloat($(ele).find('.ExchangeRate').val().trim());

                ContDet.DemmAmount = parseFloat($(ele).find('.DemmAmount').val().trim());
                ContDet.DetentionAmount = parseFloat($(ele).find('.DetentionAmount').val().trim());

                ContDet.ForScan = $(ele).find('.ForScan').is(':checked');
                ContDet.ScanPending = $(ele).find('.ScanPending').is(':checked');
                ContDet.NotScan = $(ele).find('.NotScan').is(':checked');

                ContDet.Examine100 = $(ele).find('.Examine100').is(':checked');
                ContDet.MScan = $(ele).find('.MScan').is(':checked');
                ContDet.RScan = $(ele).find('.RScan').is(':checked');

                ContDet.ScanImage = $(ele).find('.ScanImage').is(':checked');
                ContDet.ScanOkDate = $(ele).find('.ScanOkDate').val().trim();
                ContDet.ContainerRemarks = $(ele).find('.ContainerRemarks').val().trim();

                ContainerDetails.push(ContDet);
            }
        });

        let DocDetails = new Array();

        let dtype = new Array();
        let ch = 0;
        $("#TblDocumentDetails tbody tr").each(function (ind, ele) {
          
            let DocDet = {};
            if ($(ele).find('.DocType').val().trim().length > 0) {
               
                if (dtype.includes($(ele).find('.DocType').val().trim())) {
                    Toast('Duplicate Documnet Found.','message','error');
                    ch = 1;
                    return false;
                } else {
                    dtype.push($(ele).find('.DocType').val().trim());
                    DocDet.DocType = $(ele).find('.DocType').val().trim();
                    DocDet.DocumentDate = $(ele).find('.DocumentDate').val();
                    DocDetails.push(DocDet);
                }
                
            }
        });

        dataString.importJobUpdateContainerDetails = ContainerDetails;
        dataString.importJobDocumentDetails = DocDetails;

        if (ch == 0) {
            AjaxSubmission(JSON.stringify(dataString), "/Master/ImportJobUpdate/FormUpdate", $('[name="__RequestVerificationToken"]').val()).done(function (result) {
                let obj = result;

                if (obj.status == true) {
                    if (obj.responsecode == '107') {
                        Toast(RetrieveMessage(obj.responsecode), "Message", "success");
                    }
                    else if (obj.responsecode == '703')
                        Toast(obj.error, "Message", "error");
                    else
                        Toast(RetrieveMessage(obj.responsecode), "Message", "error");

                } else
                    window.location.href = '/ClientLogin/ClientLogin';
               
            }).fail(function (result) {
               
                console.log(result.message);
            });
        }
       
    }
    catch (e) {
       
        console.log(e.message);
    }
}

//FUNCTION FOR RESET FORM DATA
function ResetForm(Ch) {
    if(Ch != 1){
        $('#SearchSubJobNo,#SearchJobNo,#SearchSubJobNo').val('');
    }
    const blankId = ['ImporterName', 'CFSType', 'Shipper', 'ShippingLine', 'NewBENo', 'NewBEDate', 'BENo', 'BEDate', 'IGMNo', 'IGMItem', 'IGMDate', 'IGMFinalDate', 'ExpectedDate', 'RMSGR', 'SSOId', 'SSOLocation', 'APDate', 'FCPPDate', 'FCFPDate', 'PPDate', 'FPDate', 'DeclPrintDate', 'DECLRecDate', 'NoteDate', 'PassDate', 'AuditDate', 'AccSignDate', 'IntRate', 'DutyFreeDays', 'IntAmount', 'HiddenEmptyYard', 'EmptyYard', 'OBLRecDate', 'SwblRecDate', 'TelexRecDate', 'DocShipLineDate', 'StampDutyDate', 'DutyRecDate', 'DutyCashNo', 'DutyPaidDate', 'ShipLPmtDate', 'ShipLPmtMode', 'HseasNo', 'HseasCDate', 'AmdNo', 'AmdDate', 'DoRecDate', 'ContainerLastFreeDate', 'CLfdVd', 'FreeDays', 'BPTLFDDate', 'FreeDaysGR'];

    blankId.forEach((ele) => {
        $('#' + ele).val('');
    });
    
    $('#DetentionSlabType').html('');
    $('#RMSGRType').val('1');
    $('#ShipLPmtAmt').val('0.00');
    $('#DeliveryType').val('1');   
    $('#CreatedBy,#CreatedAt,#ModifiedBy,#ModifiedAt').text('');   
    $('#CreatedByModifiedBy').css('display', 'none');

    //CONTAINER DETAILS RESET START
    $("#TblContainerDetails tbody tr").each(function (ind, ele) {
        if (ind == 0) {

            $(ele).find('.ContainerNo,.SealNo,.OurSealNo,.HiddenContType,.ContType,.HiddenContCFSType,.ContCFSType,.ContainerArrivalDate,.ContainerExamineDate,.OutChargeDate,.GatePassDate,.ContainerDeliveryDate,.ContainerDestuffingDate,.ContainerDeliverToParty,.ContainerEmptyDate,.HiddenEmptyYard,.EmptyYard,.ReUseDate,.ReUseBy,.ContainerGroundRentLFDDate,.LRNo,.TruckNo,.HiddenPrivateYard,.PrivateYard,.HiddenTransporter,.Transporter,.Destination,.ScanOkDate,.ContainerRemarks').val('');

            $(ele).find('.Loaded').val('Loaded');
            
            $(ele).find('.ContainerWeight,.GrossWeight,.TareWeight,.NetWeight').val('0.000');
           
            $(ele).find('.GRAmount,.ExchangeRate,.DemmAmount,.DetentionAmount').val('0.00');
            
           
            $(ele).find('.ForScan,.ScanPending,.NotScan,.Examine100,.MScan,.RScan,.ScanImage').prop('checked', false);
            
        }
        else
            $(ele).remove();
    });
    //CONTAINER DETAILS RESET END

    //DOCUMENT DETAILS RESET START
    $("#TblDocumentDetails tbody tr").each(function (ind, ele) {
        if (ind == 0) {
            $(ele).find('.DocType,.DocumentName,.DocumentDate').val('');
        } else
            $(ele).remove();
    })
    //DOCUMENT DETAILS RESET END
}

//FILL PORT NAME IN LICENSE DETAILS TAB
function FillPortNameLicense(Hid,Id) {
    try {
        //Showloader();
        const dataString = {};
        $("#" + Id).val('');
        dataString.PortUid = $("#"+Hid).val();
        AjaxSubmission(JSON.stringify(dataString), '/Master/_Layout/GetPortName', $('input[name=__RequestVerificationToken]').val()).done(function (result) {
            let obj = result;
            if (obj.status == true) {
                if (obj.responsecode == '100')
                    $("#"+Id).val(obj.data.Table[0].PortName);
            }
            else
                window.location.href = '/ClientLogin/ClientLogin';
            //Hideloader();
        }).fail(function (result) {
            console.log(result.Message);
            //Hideloader();
        });
    }
    catch (e) {
        //Hideloader();
        console.log(e.message);
    }
}
function FillDetentionSlab(e) {
    try {
        const dataString = {};
        dataString.LedgerId = e;
        AjaxSubmission(JSON.stringify(dataString), '/Master/_Layout/GetDetentionSlab', $('input[name=__RequestVerificationToken]').val()).done(function (result) {
            let obj = result;
            if (obj.status == true) {
               
                if (obj.responsecode == '100')
                    BindDropdown(obj.data.Table, 'DetentionSlabType', 'ShipUid', 'SlabName', '----Select----');
                if (Detslab != '' && Detslab !=null) {
                    $("#DetentionSlabType").val(Detslab);
                    Detslab = '';
                }
            }
            else
                window.location.href = '/ClientLogin/ClientLogin';
            //Hideloader();

        }).fail(function (result) {
            console.log(result.message);
            //Hideloader();
        });
    }
    catch (e) {
        //Hideloader();
        console.log(e.message);
    }
}

// ADD MORE  DOCUMENT TYPE DROPDOWN GRID 
$(".AddMoreDocument").click(function () {
    $("#RemoveDocument").removeAttr('disabled');
    let tbody = $("#TblDocumentDetails").find("tbody");
    let FirstTr = $(tbody).find("tr:first");

    FirstTr.find('.DocumentDate').datepicker("destroy");
    FirstTr.find('.DocumentDate').removeAttr("id");

    let NewRow = $(FirstTr).clone();

    NewRow.find('.DocType').val('');
    NewRow.find('.DocumentName').val('');
    NewRow.find('.DocumentDate').val('');
    
    $("#TblDocumentDetails").find("tbody").append(NewRow);

    $(".datepickerAll").datepicker({
        changeMonth: true,
        changeYear: true,
        dateFormat: 'dd/mm/yy'
    });

    GenerateSerialNumberTable('TblDocumentDetails', 'rn');
});

// DELETE  DOCUMENT TYPE DROPDOWN GRID ROW
function DeleteDocRowEntry(obj) {
    let DocCount = $("#TblDocumentDetails tbody tr").length;
  
    if (DocCount > 1) {
        $(obj).parent().parent().remove();
    }
    else {       
        $(obj).parent().parent().find('.DocType').val('');
        $(obj).parent().parent().find('.DocumentName').val('');
        $(obj).parent().parent().find('.DocumentDate').val('');
        $("#RemoveDocument").attr("disabled", "disabled");
    }
    GenerateSerialNumberTable('TblDocumentDetails', 'rn');
}

$("#GenDelChallan").click(function () {
    let subjobno = $("#SearchSubJobNo").val();
    let jobno = $("#SearchJobNo").val();
    GenerateDeliveryChallan(subjobno, jobno);

});


function GenerateDeliveryChallan(SubJobNo, JobNo) {
    debugger
    try {
        const datastring = {};
        datastring.SubJobNo = SubJobNo;
        datastring.JobNo = JobNo;
        AjaxSubmission(JSON.stringify(datastring), "/Master/ImportJobUpdate/DownloadDeliveryChallan", $('input[name=__RequestVerificationToken]').val()).done(function (result) {
            let obj = result;
            if (obj.status == true) {
                if (obj.responsecode == '100')
                    window.open($('#DeliveryChallanPdf').attr('href'), '_blank');
                else
                    Toast(RetrieveMessage(obj.responsecode), 'Message', 'error');
            }
            else
                window.location.href = '/ClientLogin/ClientLogin';
        }).fail(function (result) {
            console.log(result.Message);
        });
    }
    catch (e) {
        console.log(e.message);
    }
}
