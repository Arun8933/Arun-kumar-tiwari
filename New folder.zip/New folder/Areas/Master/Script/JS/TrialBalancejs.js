﻿var Count;
// DOCUMENT ON READY FUNCTION
$(document).ready(function () {
    GetFinancialYearDate();
    $(".datepickerAll").datepicker({
        changeMonth: true,
        changeYear: true,
        dateFormat: 'dd/mm/yy'
    });
    FillBranchList('SelectBranchTrial', false);
    FillPageSizeList('ddlPageSize');
    $("#SelectBranchTrial").select2({
        width: '100%'
    });
    //DATEPICKER FOR SEARCHJOBDATEFROM AND SEARCHJOBDATETO
    $('#SearchDateFromTrial,#SearchDateToTrial').datepicker({
        toolbarPlacement: "bottom",
        showButtonPanel: true,
        changeMonth: true,
        changeYear: true,
        dateFormat: 'dd/mm/yy',
        onClose: function () {
            if ($('#SearchDateFromTrial').val().length == 10 || $('#SearchDateToTrial').val().length == 10)
                CompareSearchDate($('#SearchDateFromTrial').val(), $('#SearchDateToTrial').val(), 'SearchDate');
        }
    });
})

// PAGINATION BUTTON CLICKED
$(document).on("click", ".pagination .page", function () {
    FormList(($(this).attr('page')));
});
//PAGE SIZE CLICKED
$("#ddlPageSize").change(function () {
    FormList(1);
});

//FUNCTION FOR FORM SORTING
function FormSorting(obj) {
    if (Firstcolumn != "") {
        document.getElementById(Firstcolumn).innerHTML = document.getElementById(Firstcolumn).getAttribute("data-column") + " <i class='fa-solid fa-sort'></i>";
    }
    let cn = obj.id;
    Firstcolumn = cn;
    var colname = $(obj).data("column");
    $("#sort-column").val(cn.replaceAll("_", ""));
    var sorttype = $("#sort-type").val();
    if (sorttype == "ASC") {
        $("#sort-type").val("DESC");
        $(obj).html(colname + " <i style='margin-left:10px;' class='fa-solid fa-sort-up'></i>");
    } else if (sorttype == "DESC") {
        $("#sort-type").val("ASC");
        $(obj).html(colname + " <i style='margin-left:10px;' class='fa-solid fa-sort-down'></i>");
    }
    FormList(1);
}

//FUNCTION FOR GET FINANCIAL YEAR DATE
function GetFinancialYearDate() {
    try {
        AjaxSubmission(null, '/_Layout/GetFinancialYearDate', $('[name="__RequestVerificationToken"]').val()).done(function (result) {
            let obj = result;
            console.log(obj)
            if (obj.status == true) {
                if (obj.responsecode == '100') {
                    $("#SearchDateFromTrial").val(obj.data.Table[0].finyr_start_date);
                    $("#SearchDateToTrial").val(obj.data.Table[0].finyr_end_date);
                }
            }
            else
                window.location.href = '/ClientLogin/ClientLogin';
            HideLoader();
        }).fail(function (result) {
            HideLoader();
            console.log(result.message);
        });
        HideLoader();
    }
    catch (e) {
        HideLoader();
        console.log(e.message);
    }
}



$("#FormSearch").click(function () {
    $("#ShowPdf").show();
    var flag = 0;
    var FromDate = $("#SearchDateFromTrial").val();
    var ToDate = $("#SearchDateToTrial").val();
    if (FromDate == "") {
        Toast("Please Enter Date From", "Message", "error");
        flag = 1;
        return false;
    }
    if (ToDate == "") {
        Toast("Please Enter Date To", "Message", "error");
        flag = 1;
        return false;
    }
    if (FromDate > ToDate) {
        Toast("To Date Must Be Greater Than From Date!", "Message", "error");
        flag = 1;
        return false;
    }
    if (ToDate < FromDate) {
        Toast("To Date Must Be Greater Than From Date!", "Message", "error");
        flag = 1;
        return false;
    }
    if (flag == 0) {
        $(".ReportDNone").show();
        FormList();
    }
});


//FUNCTION FOR EXPORT DATA IN EXCEL
function FormExcel() {
    debugger;
    ShowLoader();
    let date = new Date();
    let NewDate = ("00" + date.getDate()).slice(-2) + "_" + ("00" + (date.getMonth() + 1)).slice(-2) + "_" + date.getFullYear() + "_" + ("00" + date.getHours()).slice(-2) + "_" + ("00" + date.getMinutes()).slice(-2) + "_" + ("00" + date.getSeconds()).slice(-2);
    let fileName = "TrialBalance_" + NewDate + ".xlsx";

    $('#FormSearch').trigger('click');
    AjaxSubmission(null, '/Master/TrialBalance/FormExcel', $('input[name=__RequestVerificationToken]').val()).done(function (result) {
        let obj = result;
        if (obj.status == true) {
            if (obj.responsecode == '100') {

                let bytes = Base64ToBytes(obj.data.FileData[0].Base64Data);
                let blob = new Blob([bytes], { type: "application/octetstream" });
                let isIE = false || !!document.documentMode;
                if (isIE) {
                    window.navigator.msSaveBlob(blob, fileName);
                } else {
                    let url = window.URL || window.webkitURL;
                    link = url.createObjectURL(blob);
                    let a = $("<a />");
                    a.attr("download", fileName);
                    a.attr("href", link);
                    $("body").append(a);
                    a[0].click();
                    $("body").remove(a);
                }
            }
            else if (obj.responsecode == '302')
                Toast('No Records found.', 'Message', 'success');
            else
                Toast(RetrieveMessage(obj.responsecode), 'Message', 'error');

        } else
            window.location.href = '/ClientLogin/ClientLogin';
        HideLoader();

    }).fail(function (result) {
        console.log(result.Message);
        HideLoader();
    });
}


//FUNCTION FOR FILL TRIAL BALANCE LIST
function FormList(pageindex) {
    try {
        const dataString = {};
        dataString.PageSize = $("#ddlPageSize").val();
        dataString.PageIndex = pageindex;
        dataString.OrderBy = $("#sort-column").val().trim() + " " + $("#sort-type").val().trim();
        dataString.FromDate = $("#SearchDateFromTrial").val();
        dataString.ToDate = $("#SearchDateToTrial").val();
        dataString.BranchUid = $("#SelectBranchTrial").val();
        ShowLoader();
        AjaxSubmission(JSON.stringify(dataString), "/Master/TrialBalance/FormList", $('input[name=__RequestVerificationToken]').val()).done(function (result) {
            let obj = result;
            if (obj.status == true) {
                if (obj.responsecode == '100') {

                    var ser = ((parseInt(obj.data.Table1[0].PageIndex) - 1) * parseInt(obj.data.Table1[0].PageSize)) + 1;

                    BindFormTable(obj.data.Table, ser);

                    if (obj.data.Table != undefined && obj.data.Table.length > 0) {
                        $(".pagination").BindPaging({
                            ActiveCssClass: "current",
                            PagerCssClass: "pager",
                            PageIndex: parseInt(obj.data.Table1[0].PageIndex),
                            PageSize: parseInt(obj.data.Table1[0].PageSize),
                            RecordCount: parseInt(obj.data.Table1[0].count)
                        });
                    }

                }
                else
                    Toast(RetrieveMessage(obj.responsecode), "Message", "error");
            }
            else
                window.location.href = '/ClientLogin/ClientLogin';

            HideLoader();
        }).fail(function (result) {
            console.log(result.Message);
            HideLoader();
        });
    }
    catch (e) {
        console.log(e.message);
        HideLoader();
    }
}


//SEARCH ARROW UP/DOWN
$("#Arrow").click(function () {
    if (srbtn == 'up') {
        $("#icn").html("<i class='fa-solid fa-angle-down'></i>");
        srbtn = 'down';
    } else {
        $("#icn").html("<i class='fa-solid fa-angle-up'></i>");
        srbtn = 'up';
    }
});

//ON CLICK FUNCTION FOR PDF
$("#TrialBalancePDF").click(function () {
    try {
        const dataString = {};
        dataString.PageSize = $("#ddlPageSize").val();
        dataString.PageIndex = 1;
        dataString.OrderBy = $("#sort-column").val().trim() + " " + $("#sort-type").val().trim();
        dataString.FromDate = $("#SearchDateFromTrial").val();
        dataString.ToDate = $("#SearchDateToTrial").val();
        dataString.BranchUid = $("#SelectBranchTrial").val();
        ShowLoader();
        AjaxSubmission(JSON.stringify(dataString), "/Master/TrialBalance/GetTrialBalanceReport", $('input[name=__RequestVerificationToken]').val()).done(function (result) {
            let obj = result;
            console.log(obj);
            if (obj.status == true) {
                if (obj.responsecode == '100') {
                    window.open($("#MyReport").attr('href'), '_blank');
                }
                else
                    Toast(RetrieveMessage(obj.responsecode), "Message", "error");
            }
            else
                window.location.href = '/ClientLogin/ClientLogin';
            HideLoader();
        }).fail(function (result) {
            console.log(result.Message);
            HideLoader();
        });
    }
    catch (e) {
        console.log(e.message);
        HideLoader();
    }
});





//FUNCTION FOR BIND LETTER LIST TABLE
function BindFormTable(Result, SerialNo) {
    console.log(Result);
    $("#tbl_TrialBalance tbody tr").remove();
    if (Result.length == 0) {
        tr = $('<tr/>');
        tr.append("<td class='text-center' colspan='11'>NO RESULTS FOUND</td>");
        $("#tbl_TrialBalance tbody").append(tr);
    }
    else {

        for (i = 0; i < Result.length; i++) {
            tr = $('<tr/>');
            if (Result[i].GroupName == 'Total') {
                tr.append("<td class='text-center'>" + SerialNo + "</td>");
                tr.append("<td class='text-center'>" + Result[i].AccHead + "</td>");
                tr.append("<td class='text-center'><b>" + Result[i].GroupName + "</b></td>");
                tr.append("<td class='text-end'><b>" + HandleNullTextValue(Result[i].OpBalDr) + "     </b></td>");
                tr.append("<td class='text-end'><b>" + HandleNullTextValue(Result[i].OpBalCr) + "     </b></td>");
                tr.append("<td class='text-end'><b>" + HandleNullTextValue(Result[i].CurrDebit) + "   </b></td>");
                tr.append("<td class='text-end'><b>" + HandleNullTextValue(Result[i].CurrCredit) + "  </b></td>");
                tr.append("<td class='text-end'><b>" + HandleNullTextValue(Result[i].TotalBalDr) + "  </b></td>");
                tr.append("<td class='text-end'><b>" + HandleNullTextValue((Result[i].TotalBalCr)) + "</b></td>");
            }

            else {
                tr.append("<td class='text-center'>" + SerialNo + "</td>");
                tr.append("<td class='text-center'>" + Result[i].AccHead + "</td>");
                tr.append("<td class='text-center'>" + Result[i].GroupName + "</td>");
                tr.append("<td class='text-end'>" + HandleNullTextValue(Result[i].OpBalDr) + "</td>");
                tr.append("<td class='text-end'>" + HandleNullTextValue(Result[i].OpBalCr) + "</td>");
                tr.append("<td class='text-end'>" + HandleNullTextValue(Result[i].CurrDebit) + "</td>");
                tr.append("<td class='text-end'>" + HandleNullTextValue(Result[i].CurrCredit) + "</td>");
                tr.append("<td class='text-end'>" + HandleNullTextValue(Result[i].TotalBalDr) + "</td>");
                tr.append("<td class='text-end'>" + HandleNullTextValue((Result[i].TotalBalCr)) + "</td>");
            }

            SerialNo++;
            $("#tbl_TrialBalance tbody").append(tr);
        }
    }
}
