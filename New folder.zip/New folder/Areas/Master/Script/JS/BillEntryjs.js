﻿

var Firstcolumn = "";
var billflag = 0;
var SelectedLedgerBranch = "";
var srbtn = 'up';
var flag = 0;
var BillAc = 0;
var Hclid = '';
let hiddenInvoiceId = '';
let hiddenJobNo = '';
let HiddenClientId = '';

jQuery.datepicker._gotoToday = function (id) {
    var today = new Date();
    var dateRef = jQuery("<td><a>" + today.getDate() + "</a></td>");
    this._selectDay(id, today.getMonth(), today.getFullYear(), dateRef);
};
var date = new Date();
var NewDate = date.getDate().toString().padStart(2, 0) + "/" + (date.getMonth() + 1).toString().padStart(2, 0) + "/" + date.getFullYear().toString();


// DOCUMENT READY FUNCTION 
$(document).ready(function () {


    Firstcolumn = "Bill_No";
    DynamicBillTypeButton();
    FillBranchList('BranchIdSearch', false);
    FillInvoiceType('InvoiceTypeSearch', false);
    FillBranchList('BranchId');
    FillInvoiceType('InvoiceType', true);

    JobNoAutoCompleteAjax('JobNo', '/Master/BillEntry/GetJobNumberAutoComplete', 'HiddenJobNo');
    BillNoAutoCompleteAjax('RefInvoiceNo', '/Master/BillEntry/GetBillNumberAutoComplete', 'HiddenRefInvoiceNo', null, null, null, 'BranchId', '1');
    if (Get_Cookie("BillType") != null) {
        var thu = setInterval(() => {
            if ($('#DynamicButtonDiv').html() != '' && $('#DynamicButtonDiv').find("[value='" + Get_Cookie("BillType") + "']")[0].value == Get_Cookie("BillType")) {
                $('input[name="btnradio"]').each(function () {
                    $(this).checked = false;
                    $(this).next().removeClass('btn-primary');
                    $(this).removeAttr('checked');
                });
                $('input[name="btnradio"]').each(function () {
                    if ($(this).val() == Get_Cookie("BillType")) {
                        $(this).attr('checked', true);
                        $(this).next().addClass('btn-primary');
                        /* $('#FormSearch').trigger('click');*/
                        EraseCookie('BillType');
                    }
                });
                clearInterval(thu);
            } else {
                console.log('Fail');
            }
        }, 500);
    }

    if (Get_Cookie("LId") != null && Get_Cookie("LName") != null && Get_Cookie("BillType") != null) {

        var thu = setInterval(() => {
            if ($('#DynamicButtonDiv').html() != '' && $('#DynamicButtonDiv').find("[value='" + Get_Cookie("BillType") + "']")[0].value == Get_Cookie("BillType")) {
                $('input[name="btnradio"]').each(function () {
                    $(this).checked = false;
                    $(this).next().removeClass('btn-primary');
                    $(this).removeAttr('checked');
                });
                $('input[name="btnradio"]').each(function () {
                    if ($(this).val() == Get_Cookie("BillType")) {
                        $(this).attr('checked', true);
                        $(this).next().addClass('btn-primary');
                        $("#HiddenClientIdSearch").val(Get_Cookie("LId"));
                        $("#ClientNameSearch").val(Get_Cookie("LName"));
                        EraseCookie('LId');
                        EraseCookie('LName');
                        EraseCookie('BillType');
                    }
                });
                clearInterval(thu);
            }
        }, 500);
    }



    $(".datepickerAll").datepicker({
        changeMonth: true,
        changeYear: true,
        dateFormat: 'dd/mm/yy',
        toolbarPlacement: "bottom",
        showButtonPanel: true,
    });
    $("#BillDate").datepicker({
        changeMonth: true,
        changeYear: true,
        dateFormat: 'dd/mm/yy',
        onClose: function (e) {
            GetBillNo();
        }
    });

    $("#BillDate").val(NewDate);

    GetFinancialYearDate('SearchBillDateFrom', 'SearchBillDateTo');

    var LIS = setInterval(() => {
        if ($('#DynamicButtonDiv').html() != '') {
            if ($("#BranchIdSearch").val != null) {
                if (Get_Cookie("BillEntryUid") != null)
                    FillPageSizeList('ddlPageSize');
                else {
                    $('#DynamicButtonDiv').find('input[name="btnradio"]').each(function () {
                        if (this.checked == true) {
                            FillPageSizeList('ddlPageSize', BillEntryList);
                            clearInterval(LIS);
                            return;
                        }
                    });
                }
            }
        }
    }, 1000);

    var bill = setInterval(() => {
        if ($("#BranchId").val() > 0) {
            FillBranchState();
            GetBillNo();
            clearInterval(bill);
        }
    }, 100);

    var GSTFill = setInterval(() => {
        if ($("#BillType").val() > 0) {
            FillBillGstType();
            clearInterval(GSTFill);
        }
    }, 100);

    FillBillType();
    FillTaxCategory();
    LoadTinyMCE();

    var RedirectLedger = setInterval(() => {
        if (Get_Cookie("BillEntryUid") != null) {
            if ($("#BranchId").val() > 0 && $("#BillType").val() > 0 && $("#InvoiceType").val() > 0) {
                FormEdit(Get_Cookie('BillEntryUid'));
                EraseCookie('BillEntryUid');
                clearInterval(RedirectLedger);
            }
        }
    }, 100);

    //if (Get_Cookie("LedgerGroupName") != null) {
    //    //var RefId = Get_Cookie('LedgerGroupName');
    //    //var substring = RefId.slice(3);
    //    FormEdit(Get_Cookie('LedgerGroupName'));
    //    EraseCookie('LedgerGroupName');
    //}

});
//BILL DATE INPUT EVENT
$("#BillDate").on('input', function () {
    GetBillNo();
});
//SELECT BRANCH DROPDOWN CHANGE EVENT
$("#BranchId").change(function () {
    FillBranchState();
    GetBillNo();
});
// INVOICE TYPE ON CHANGE
$("#InvoiceType").change(function () {
    GetBillNo();
});
//SUB BILL NUMBER TEXT BLUR EVENT
$("#SubBillNo").blur(function () {
    GetBillNo();
})

//SEARCH SUBBILLNO BLUR EVENT
$("#SearchSubBillNo").blur(function () {
    $("#SearchBillNo").val('');
})
//SEARCH SUBBILLNO KEYPRESS EVENT
$("#SearchSubBillNo").bind('keypress', function (e) {
    if (e.keyCode == 13) {
        $("#SearchBillNo").val('');
        $("#SearchBillNo").focus();
    }
});
//SUBBILLNO KEYPRESS EVENT
$("#SearchBillNo").bind('keypress', function (e) {
    if (e.keyCode == 13) {
        $("#FormSearch").trigger('click');
    }
});
//FILL BILL ENTRY  TABLE
function BillEntryList(pageindex) {
    try {
        const dataString = {};
        dataString.PageSize = $("#ddlPageSize").val();
        dataString.PageIndex = pageindex;
        dataString.ClientName = $("#HiddenClientIdSearch").val();
        dataString.BillNo = $("#HiddenSearchBillNo").val();
        dataString.JobNo = $("#HiddenSearchJobNo").val();
        dataString.SubBillNo = $("#SearchSubBillNo").val();
        dataString.BillDateFrom = $("#SearchBillDateFrom").val();
        dataString.BillDateTo = $("#SearchBillDateTo").val();
        dataString.BillUid = $("#BillIdSearch").val();
        dataString.BranchUid = $("#BranchIdSearch").val();
        dataString.InvoiceType = $("#InvoiceTypeSearch").val();
        dataString.TransactionCategory = $("#TransactionCategorySearch").val();
        dataString.BillTypeUid = $('input:radio[name=btnradio]:checked').val();
        dataString.OrderBy = $("#sort-column").val().trim() + " " + $("#sort-type").val().trim();

        //ShowLoader();
        AjaxSubmission(JSON.stringify(dataString), "/Master/BillEntry/BillEntryList", $('input[name=__RequestVerificationToken]').val()).done(function (result) {

            let obj = result;

            if (obj.status == true) {
                if (obj.responsecode == '100') {

                    var ser = ((parseInt(obj.data.Table1[0].PageIndex) - 1) * parseInt(obj.data.Table1[0].PageSize)) + 1;
                    BindBillEntryFormList(obj.data.Table, ser);
                    if (obj.data.Table1 != undefined && obj.data.Table1.length > 0) {
                        $(".pagination").BindPaging({
                            ActiveCssClass: "current",
                            PagerCssClass: "pager",
                            PageIndex: parseInt(obj.data.Table1[0].PageIndex),
                            PageSize: parseInt(obj.data.Table1[0].PageSize),
                            RecordCount: parseInt(obj.data.Table1[0].count)
                        });
                    }
                }
                else {
                    Toast(RetrieveMessage(obj.responsecode), "Message", "error");
                }
            }
            else {
                window.location.href = '/ClientLogin/ClientLogin';
            }
            //HideLoader();
        }).fail(function (result) {
            console.log(result.Message);
            //HideLoader();
        });
    }
    catch (e) {
        console.log(e.message);
        //HideLoader();
    }
}

//BIND BILL ENTRY TABLE FUNCTION 
function BindBillEntryFormList(result, serial_no) {
    $("#tbl_BillEntry tbody tr").remove();

    if (result.length == 0) {
        tr = $('<tr/>');
        tr.append("<td class='text-center' colspan='14'>NO RESULTS FOUND</td>");
        $("#tbl_BillEntry tbody").append(tr);
    }
    else {
        for (i = 0; i < result.length; i++) {
            if (result[i].CancelBill == true)
                tr = $(' <tr style="background-color:#fdd2d2;"/>');
            else
                tr = $('<tr/>');

            tr.append("<td class='text-center'><button type='button' onclick='FormEdit(\"" + result[i].BillUid + "\");' class= 'common-btn common-btn-sm'><i class='fa-solid fa-pen-to-square'></i></button > <button type='button' onclick='FormDelete(\"" + result[i].BillUid + "\",\"" + result[i].BillTypeUid + "\");' class= 'common-btn common-btn-sm ms-1'> <i class='fa-regular fa-trash-can'></i></button ></td > ");
            tr.append("<td class='text-left'>" + serial_no + "</td>");
            tr.append("<td class='text-left'>" + result[i].BillUid + "</td>");
            tr.append("<td class='text-center'>" + result[i].BranchName + "</td>");
            /*tr.append("<td class='text-center fw-bold'><a href='javascript:void(0)' class='text-decoration-none ' style='color: black !important;' onclick='FormEdit(\"" + result[i].BillUid + "\");'>" + result[i].SubBillNo + "</a></td>");*/
            tr.append("<td class='text-center'><a href='javascript:void(0)' class='text-decoration-none ' style='color: black !important;' onclick='FormEdit(\"" + result[i].BillUid + "\");'>" + result[i].BillNo + "</a></td>");
            tr.append("<td class='text-center'>" + result[i].BillDate + "</td>");
            tr.append("<td class='text-center'>" + result[i].ClientName + "</td>");
            tr.append("<td class='text-center'>" + HandleNullTextValue(result[i].JobNo) + "</td>");
            tr.append("<td class='text-center'>" + HandleNullTextValue(result[i].JobDate) + "</td>");
            tr.append("<td class='text-end'>" + parseFloat(result[i].TotalAmount).toFixed(2) + "</td>");
            tr.append("<td class='text-end'>" + parseFloat(result[i].TaxAmount).toFixed(2) + "</td>");
            tr.append("<td class='text-end'>" + parseFloat(result[i].NetAmount).toFixed(2) + "</td>");
            if (result[i].IRNNo != '')
                tr.append("<td class='text-center'><i class='fa-solid fa-check'></i></td>");
            else
                tr.append("<td class='text-center'></td>");

            tr.append("<td class='text-center'>" + result[i].RefInvoiceNo + "</td>");
            tr.append("<td class='text-center'>" + HandleNullTextValue(result[i].RefInvoiceDate) + "</td>");

            serial_no++;

            $("#tbl_BillEntry tbody").append(tr);
        }
    }
}
//BILL ENTRY FORM SEARCH CLICK
$("#FormSearch").click(function () {
    BillEntryList(1);
});

// FORM SORTING FUNCTION BILL ENTRY
function FormSorting(obj) {
    if (Firstcolumn != "") {
        document.getElementById(Firstcolumn).innerHTML = document.getElementById(Firstcolumn).getAttribute("data-column") + " <i style='margin-left:10px;' class='fa-solid fa-sort'></i>";
    }
    let cn = obj.id;
    Firstcolumn = cn;
    var colname = $(obj).data("column");
    $("#sort-column").val(cn.replaceAll("_", ""));
    var sorttype = $("#sort-type").val();
    if (sorttype == "ASC") {
        $("#sort-type").val("DESC");
        $(obj).html(colname + " <i style='margin-left:10px;' class='fa-solid fa-sort-down'></i>");
    } else if (sorttype == "DESC") {
        $("#sort-type").val("ASC");
        $(obj).html(colname + " <i style='margin-left:10px;' class='fa-solid fa-sort-up'></i>");
    }
    BillEntryList(1);
}

//BILL ENTRY TABLE PAGINATION BUTTON CLICK
$(document).on("click", ".pagination .page", function () {
    BillEntryList(($(this).attr('page')));
});

//PAGE SIZE ON CHANGE FUNCTION
$("#ddlPageSize").change(function () {
    BillEntryList(1);
});
// BILL ENTRY FORM ADD BUTTON CLICK
$("#FormAdd").click(function () {
    flag = 0;
    BillAddUpdateValidation();
    if (flag == 0) {
        FormAdd();
    }
});

// BILL ENTRY FORM ADD FUNCTION
function FormAdd() {
    try {
        const datastring = {};
        var BillTableData = new Array();
        var BillTaxTableData = new Array();
        var BillUniqueId = "";

        datastring.BranchId = $("#BranchId").val();
        datastring.InvoiceType = $("#InvoiceType").val();
        datastring.SubBillNo = $("#SubBillNo").val();
        datastring.BillNo = $("#BillNo").val();
        datastring.BillDate = $("#BillDate").val();
        datastring.BillType = $("#BillType").val();
        datastring.JobUid = $("#HiddenJobNo").val();

        datastring.BranchState = $("#BranchState").val();
        datastring.ClientState = $("#ClientState").val();
        datastring.ClientId = $("#HiddenClientId").val();
        datastring.AccHeadName = $("#ClientName").val();
        datastring.LedgerBranch = $("#LedgerBranchAddress").val();

        datastring.City = $("#City").val();
        datastring.Address = $("#Address").val();
        datastring.State = $("#State").val();
        datastring.IRNNo = $("#IRNNo").val();
        datastring.CancelDate = $("#CancelDate").val();
        datastring.GSTNo = $("#GSTNo").val();


        datastring.CancelBill = $("#CancelBill").is(":checked");
        datastring.NoGst = $("#NoGst").is(":checked");
        datastring.TotalAmount = $("#TotalAmount").html();
        datastring.RoundOff = $("#RoundOff").html();
        datastring.TotalTaxAmount = $("#TotalTaxAmount").html();
        datastring.NetAmount = $("#NetAmount").html();
        datastring.GstCategory = $("#GstInvoiceCategory").val();
        if ($("#GstInvoiceCategory").val().length == 0) {
            datastring.TransactionCategory = null;
        }
        else {
            datastring.TransactionCategory = $("#TransactionCategory").val();
        }
        if ($("#GstInvoiceCategory").val() == "DBN") {
            datastring.RefInvoiceNo = $("#RefInvoiceNo").val();
            datastring.PurchaseUid = $("#HiddenRefInvoiceNo").val();
        }
        else {
            datastring.RefInvoiceNo = $("#HiddenRefInvoiceNo").val();
        }

        datastring.RefInvoiceDate = $("#RefInvoiceDate").val();

        $("#Bill_table tbody tr").each(function () {
            var g = {};
            g.SubGroupId = $(this).find(".HiddenGroupId").val();
            g.LedgerId = $(this).find(".HiddenAccountDescId").val();
            g.AccHeadName = $(this).find(".AccountDesc").val();
            g.Particular = $("#BillNo").val().trim() + " " + $(this).find(".Particular").val().trim();
            g.RecNo = $(this).find(".RecNo").val();
            g.RecDate = $(this).find(".RecDate").val();
            g.Amount = $(this).find(".Amount").val();
            g.TaxAmount = $(this).find(".TaxAmount").val();
            g.TaxCategory = $(this).find(".TaxCategory").val();
            g.TaxPercent = $(this).find(".HiddenTaxPer").val();

            if ($(this).find(".BillNoUniqueId").val().length != 0)
                BillUniqueId += "'" + $(this).find(".BillNoUniqueId").val() + "',";

            BillTableData.push(g);
        });

        $("#TaxDetails tbody tr").each(function (ind, ele) {
            var s = {};
            if (ind < $("#TaxDetails tbody tr").length - 1) {
                s.AccDesc = $(ele).find(".AccDesc").text();
                s.LedgerUid = $(ele).find(".LedgerId").text();
                s.TaxType = $(ele).find(".TaxName").text();
                s.TaxableAmount = $(ele).find(".TaxableAmount").text();
                s.TaxAmount = $(ele).find(".TaxAmounts").text();
                s.TaxLedgerId = $(ele).find(".TaxName .TaxLedgerId").val();
                BillTaxTableData.push(s);
            }

        })
        datastring.billEntryList = BillTableData;
        datastring.BillTaxModel = BillTaxTableData;
        datastring.BillNoUniqueId = BillUniqueId;
        datastring.Remarks = $("#Remarks").val();
        //ShowLoader();

        AjaxSubmission(JSON.stringify(datastring), "/Master/BillEntry/FormAdd", $('input[name=__RequestVerificationToken]').val()).done(function (result) {
            let obj = result;

            if (obj.status == true) {
                if (obj.responsecode == '101') {
                    Toast(RetrieveMessage(obj.responsecode), "Message", "success");
                    BillEntryList(1);
                    //ResetForm();
                    //TabHide();
                    $("#FormAdd").hide();
                    $("#OpenEmailModal").show();
                    $("#FormUpdate").show();
                    $("#CreatePdf").show();
                    $("#FormReset").show();
                    $("#BillEntry-tab").html("Edit Bill Entry");
                    $(".EditField").show();
                    $(".IRNSHOW").show();
                    if ($("#GstInvoiceCategory").val().length == 0) {
                        $("#EBillRow").hide();
                    }
                    else {
                        $("#EBillRow").show();
                    }
                    $("#BillIdDiv").css("display", "block");
                    $("#BillId").val(obj.data.Table1[0].BillUid);
                }
                else if (obj.responsecode == '703')
                    Toast(RetrieveMessage(703), "Message", "error");
                else if (obj.responsecode == '1013') {
                    BillAc = 1;
                    NewBillNoConfirmation();
                }
                else if (obj.responsecode == '1019') {
                    Toast('You Dont Have Permission For This Bill Entry', "Message", "error");
                }
                else {
                    Toast(RetrieveMessage(obj.responsecode), "Message", "error");
                }
            }
            else {
                window.location.href = '/ClientLogin/ClientLogin';
            }
            //HideLoader();
        }).fail(function (result) {
            console.log(result.Message);
            //HideLoader();
        });
    }
    catch (e) {
        console.log(e.message);
    }
}

// BILL ENTRY FORM EDIT FUNCTION
function FormEdit(e) {
    try {

        const datastring = {};
        datastring.BillUid = e;

        AjaxSubmission(JSON.stringify(datastring), "/Master/BillEntry/FormEdit", $('[name="__RequestVerificationToken"]').val()).done(function (data) {
            let obj = data;
            if (obj.status == true) {
                if (obj.responsecode == '100') {
                    TabShow();
                    CanChangeTaxInInvoice();
                    $("#BillType").attr("disabled", "disabled");
                    if (obj.data.Table1[0].RefInvoiceNo != "") {
                        //$("#JobNo").attr("disabled", true);
                        $("#ClientName").attr("disabled", true);
                        $("#LedgerBranchAddress").attr("disabled", true);
                        $("#NoGst").attr("disabled", true);
                        $("#Address").attr("disabled", true);

                        $(".CNDN").show();
                        if (obj.data.Table6[0].GstInvoiceCategory == "DBN") {

                            $("#RefInvoiceNo").val(obj.data.Table1[0].RefInvoiceNo);
                            $("#HiddenRefInvoiceNo").val(obj.data.Table1[0].PurchaseEntryId);

                        }
                        else {
                            $("#RefInvoiceNo").val(obj.data.Table1[0].RefInvoiceNo);
                            $("#HiddenRefInvoiceNo").val(obj.data.Table1[0].RefInvoiceNo);
                        }
                        $("#RefInvoiceDate").val(obj.data.Table1[0].RefInvoiceDate);
                    }
                    if (obj.data.Table6[0].GstInvoiceCategory == null) {
                        $(".TN").hide();
                        $("#EBillRow").hide();
                        $(".EditField").hide();
                        $(".IRNSHOW").hide();
                        $("#GstInvoiceCategory").val(obj.data.Table6[0].GstInvoiceCategory);
                        $("#AddRow").show();
                    }
                    else if (obj.data.Table6[0].GstInvoiceCategory == "DBN") {
                        $("#AddRow").show();
                        $("#EBillRow").show();
                        $(".EditField").show();
                        $(".IRNSHOW").show();
                        $("#GstInvoiceCategory").val(obj.data.Table6[0].GstInvoiceCategory);
                    }
                    else if (obj.data.Table6[0].GstInvoiceCategory == "CRN") {
                        $("#AddRow").hide();
                        $("#EBillRow").show();
                        $(".EditField").show();
                        $(".IRNSHOW").show();
                        $("#GstInvoiceCategory").val(obj.data.Table6[0].GstInvoiceCategory);
                    }
                    else {
                        $("#EBillRow").show();
                        $(".EditField").show();
                        $(".IRNSHOW").show();
                        $("#GstInvoiceCategory").val(obj.data.Table6[0].GstInvoiceCategory);
                    }
                    $("#BillIdDiv").css("display", "block");

                    $("#CreatedByModifiedBy").css('display', 'block');
                    $("#CreatedByModifiedBy").css('width', '100%');
                    /* $("#myid").css('display', 'block');*/
                    var CreateTableLength = obj.data.Table3.length;
                    if (CreateTableLength != 0) {
                        $("#CreatedBy").text(obj.data.Table3[0].user_name);
                        $("#CreatedAt").text(obj.data.Table3[0].CreatedAt);
                    }
                    var ModifiedTableLength = obj.data.Table4.length;
                    if (ModifiedTableLength != 0) {
                        $(".Modify").show();
                        $("#ModifiedBy").text(obj.data.Table4[0].user_name);
                        $("#ModifiedAt").text(obj.data.Table4[0].LastUpdatedAt);
                    }
                    else {
                        $(".Modify").hide();
                    }
                    $("#BillId").val(obj.data.Table1[0].BillUid);
                    $("#BranchId").val(obj.data.Table1[0].BranchId);
                    $("#BillType").val(obj.data.Table1[0].BillTypeUid);
                    $("#InvoiceType").val(obj.data.Table1[0].InvoiceType);
                    $("#TransactionCategory").val(obj.data.Table1[0].TransactionCategory);
                    $("#SubBillNo").val(obj.data.Table1[0].SubBillNo);
                    $("#BillNo").val(obj.data.Table1[0].BillNo);
                    $("#BillDate").val(obj.data.Table1[0].BillDate);
                    $("#HiddenJobNo").val(obj.data.Table1[0].JobUid);
                    $("#JobNo").val(obj.data.Table1[0].JobNo);
                    $("#JobDate").val(obj.data.Table1[0].JobDate);
                    //let EditJobNo = setInterval(() => {
                    if ($("#JobDate").val() != '' || obj.data.Table1[0].JobNo == null) {
                        $("#HiddenClientId").val(obj.data.Table1[0].ClientId);
                        $("#ClientName").val(obj.data.Table1[0].AccHead).trigger('blur');
                        SelectedLedgerBranch = obj.data.Table1[0].LedgerBranch;

                        let branchAddress = setInterval(() => {
                            if ($("#LedgerBranchAddress").val() < 1) {
                                $("#BENo").val(obj.data.Table1[0].BENo);
                                $("#BEDate").val(obj.data.Table1[0].BEDate);
                                $("#IRNNo").val(obj.data.Table1[0].IRNNo);
                                $("#AckNo").val(obj.data.Table1[0].AckNo);
                                $("#AckDate").val(obj.data.Table1[0].AckDate);
                                $("#QrCode").val(obj.data.Table1[0].QrCode);
                                $("#VesselName").val(obj.data.Table1[0].VesselName);
                                $("#PortLoading").val(obj.data.Table1[0].PortLoading);
                                $("#PortLoading").val(obj.data.Table1[0].PortLoading);
                                $("#ContainerTypeNo").val(obj.data.Table1[0].ContainerTypeNo);
                                $("#ContainerType").val(obj.data.Table1[0].ContainerType);
                                $("#TotalNetWeight").val(obj.data.Table1[0].TotalNetWeight);
                                $("#PortDischarge").val(obj.data.Table1[0].PortDischarge);
                                $("#Remarks").val(obj.data.Table1[0].Remarks);

                                $("#LedgerBranchAddress").val(SelectedLedgerBranch);
                                $("#City").val(obj.data.Table1[0].City);
                                $("#State").val(obj.data.Table1[0].State);
                                $("#GSTNo").val(obj.data.Table1[0].GstNo);
                                $("#Address").val(obj.data.Table1[0].Address);
                                $("#ClientState").val(obj.data.Table1[0].ClientState);
                                $("#BranchState").val(obj.data.Table1[0].BranchState);
                                $("#CancelBill").prop("checked", obj.data.Table1[0].CancelBill);
                                $("#CancelDate").val(obj.data.Table1[0].CancelDt);
                                clearInterval(branchAddress);
                            }
                        }, 100);
                        if (obj.data.Table1[0].IRNNo != '') {
                            $("#BranchId,#InvoiceType,#TransactionCategory,#SubBillNo,#BillDate,#JobNo,#ClientName,#LedgerBranchAddress,#Address,#NoGst,#AddRow").attr('disabled', 'disabled');
                            $("#IRNNo").addClass('text-info');
                        }
                        $("#TotalAmount").html(obj.data.Table1[0].TotalAmount.toFixed(2));
                        $("#RoundOff").html(obj.data.Table1[0].RoundOff.toFixed(2));

                        $("#TotalTaxAmount").html(obj.data.Table1[0].TaxAmount.toFixed(2));
                        $("#NetAmount").html(obj.data.Table1[0].NetAmount.toFixed(2));
                        var BillList = obj.data.Table2;
                        var firstChild = $("#Bill_table").find("tbody tr:first-child");
                        $.each(BillList, function (index, ele) {
                            if (index == 0) {

                                var TaxPerLedger = ele.TaxLedgerPer;
                                var Taxable = ele.IsTaxable;

                                if (TaxPerLedger != null && Taxable == false) {
                                    firstChild.find(".Amount ").prop('disabled', true);
                                }
                                else {
                                    firstChild.find(".Amount ").removeAttr("disabled");
                                }
                                selectedAccHead = ele.LedgerId;
                                if (ele.SubgroupId == null) {
                                    firstChild.find('.GroupName').val('');
                                }
                                else {
                                    firstChild.find('.HiddenGroupId').val(ele.SubgroupId);
                                    firstChild.find('.GroupName').val(ele.SubgroupHeadName);
                                }

                                firstChild.find('.AccountDesc').val(ele.AccHead);
                                firstChild.find('.HiddenAccountDescId').val(ele.LedgerId);
                                firstChild.find('.Particular').val(ele.Particular);
                                firstChild.find('.JobNo').val(ele.JobNo);
                                firstChild.find('.RecNo').val(ele.RecNo);
                                firstChild.find('.RecDate').val(ele.RecDate == '01/01/1900' ? '' : ele.RecDate);
                                firstChild.find('.Amount').val(ele.Amount.toFixed(2));
                                //firstChild.find('.Amount').trigger('blur');
                                firstChild.find('.TaxAmount').val(ele.TaxAmount.toFixed(2));
                                firstChild.find('.TaxCategory').val(ele.TaxCategory).trigger('change');
                                firstChild.find('.HiddenTaxPer').val(ele.TaxPercent);
                                if (obj.data.Table1[0].IRNNo != '') {
                                    firstChild.find(".GroupName,.AccountDesc,.RecNo,.RecDate,.Amount,.TaxCategory,.Particular").attr('disabled', 'disabled');
                                }
                            }
                            else {

                                firstChild.find('.RecDate').datepicker("destroy");
                                firstChild.find('.RecDate').removeAttr("id");

                                var cloneChild = firstChild.clone();

                                var TaxPerLedger = ele.TaxLedgerPer;
                                var Taxable = ele.IsTaxable;

                                if (TaxPerLedger != null && Taxable == false) {
                                    cloneChild.find(".Amount ").prop('disabled', true);
                                }
                                else {
                                    cloneChild.find(".Amount ").removeAttr("disabled");
                                }
                                cloneChild.find('.GroupName,.AccountDesc,.Particular,.JobNo,.RecNo,.RecDate,.Amount,.HiddenGroupId,.HiddenAccountDescId,.isTaxable,.TaxPerLedger,.TaxAmount,.HiddenTaxPer').val('');
                                cloneChild.find('.TaxCategory').val('0');

                                if (ele.SubgroupId == null) {
                                    cloneChild.find('.GroupName').val('');
                                }
                                else {
                                    cloneChild.find('.HiddenGroupId').val(ele.SubgroupId);
                                    cloneChild.find('.GroupName').val(ele.SubgroupHeadName);
                                }

                                cloneChild.find('.AccountDesc').val(ele.AccHead);
                                cloneChild.find('.HiddenAccountDescId').val(ele.LedgerId);
                                cloneChild.find('.isTaxable').val(ele.IsTaxable);
                                cloneChild.find('.TaxPerLedger').val(ele.TaxLedgerPer);
                                cloneChild.find('.Particular').val(ele.Particular);
                                cloneChild.find('.JobNo').val(ele.JobNo);
                                cloneChild.find('.RecNo').val(ele.RecNo);
                                cloneChild.find('.RecDate').val(ele.RecDate == '01/01/1900' ? '' : ele.RecDate);
                                cloneChild.find('.Amount').val(ele.Amount.toFixed(2));
                                //cloneChild.find('.Amount').trigger('blur');
                                cloneChild.find('.TaxAmount').val(ele.TaxAmount.toFixed(2));
                                cloneChild.find('.TaxCategory').val(ele.TaxCategory).trigger('change');
                                cloneChild.find('.HiddenTaxPer').val(ele.TaxPercent);
                                if (obj.data.Table1[0].IRNNo != '') {
                                    cloneChild.find(".GroupName,.AccountDesc,.RecNo,.RecDate,.Amount,.TaxCategory,.Particular").attr('disabled', 'disabled');
                                }
                                $("#Bill_table tbody").append(cloneChild);
                            }
                            $(".datepickerAll").datepicker({
                                changeMonth: true,
                                changeYear: true,
                                dateFormat: 'dd/mm/yy'
                            });
                        });

                        $("#NoGst").prop("checked", obj.data.Table1[0].NoGST);
                        $("#NoGst").trigger('change');
                        if ($("#NoGst").is(":checked") == false) {
                            AddTaxDetail(obj.data.Table5);
                        }
                        //clearInterval(EditJobNo);
                    }
                    //}, 100);
                }
                else {
                    Toast(RetrieveMessage(obj.responsecode), "Message", "error");
                }

            }
            else {
                window.location.href = '/ClientLogin/ClientLogin';
            }
        }).fail(function (data) {
            console.log(data.Message);
        });
    }
    catch (e) {
        console.log(e.message);
    }
}

// BILL ENTRY FORM UPDATE BUTTON CLICK
$("#FormUpdate").click(function () {
    flag = 0;
    BillAddUpdateValidation();
    if (flag == 0) {
        FormUpdate();
    }
});

// BILL ENTRY FORM UPDATE FUNCTION
function FormUpdate() {
    try {
        const datastring = {};
        var BillTableData = new Array();
        var BillTaxTableData = new Array();
        var BillUniqueId = "";

        datastring.BranchId = $("#BranchId").val();
        datastring.InvoiceType = $("#InvoiceType").val();
        datastring.SubBillNo = $("#SubBillNo").val();
        datastring.BillNo = $("#BillNo").val();
        datastring.BillDate = $("#BillDate").val();
        datastring.BillType = $("#BillType").val();
        datastring.JobUid = $("#HiddenJobNo").val();

        datastring.BranchState = $("#BranchState").val();
        datastring.ClientState = $("#ClientState").val();
        datastring.ClientId = $("#HiddenClientId").val();
        datastring.AccHeadName = $("#ClientName").val();
        datastring.LedgerBranch = $("#LedgerBranchAddress").val();

        datastring.City = $("#City").val();
        datastring.Address = $("#Address").val();
        datastring.State = $("#State").val();
        datastring.IRNNo = $("#IRNNo").val();
        datastring.CancelDate = $("#CancelDate").val();
        datastring.GSTNo = $("#GSTNo").val();


        datastring.CancelBill = $("#CancelBill").is(":checked");
        datastring.NoGst = $("#NoGst").is(":checked");
        datastring.TotalAmount = $("#TotalAmount").html();
        datastring.RoundOff = $("#RoundOff").html();
        datastring.TotalTaxAmount = $("#TotalTaxAmount").html();
        datastring.NetAmount = $("#NetAmount").html();
        datastring.GstCategory = $("#GstInvoiceCategory").val();
        if ($("#GstInvoiceCategory").val().length == 0) {
            datastring.TransactionCategory = null;
        }
        else {
            datastring.TransactionCategory = $("#TransactionCategory").val();
        }
        if ($("#GstInvoiceCategory").val() == "DBN") {
            datastring.RefInvoiceNo = $("#RefInvoiceNo").val();
            datastring.PurchaseUid = $("#HiddenRefInvoiceNo").val();
        }
        else {
            datastring.RefInvoiceNo = $("#HiddenRefInvoiceNo").val();
        }

        datastring.RefInvoiceDate = $("#RefInvoiceDate").val();

        $("#Bill_table tbody tr").each(function () {
            var g = {};
            var Particular = $(this).find(".Particular").val().includes($("#BillNo").val());
            g.SubGroupId = $(this).find(".HiddenGroupId").val();
            g.LedgerId = $(this).find(".HiddenAccountDescId").val();
            g.AccHeadName = $(this).find(".AccountDesc").val();
            if (Particular != true) {
                g.Particular = $("#BillNo").val().trim() + " " + $(this).find(".Particular").val().trim();
            }
            else {
                g.Particular = $(this).find(".Particular").val();
            }

            g.RecNo = $(this).find(".RecNo").val();
            g.RecDate = $(this).find(".RecDate").val();
            g.Amount = $(this).find(".Amount").val();
            g.TaxAmount = $(this).find(".TaxAmount").val();
            g.TaxCategory = $(this).find(".TaxCategory").val();
            g.TaxPercent = $(this).find(".HiddenTaxPer").val();

            if ($(this).find(".BillNoUniqueId").val().length != 0)
                BillUniqueId += "'" + $(this).find(".BillNoUniqueId").val() + "',";

            BillTableData.push(g);
        });

        $("#TaxDetails tbody tr").each(function (ind, ele) {
            var s = {};
            if (ind < $("#TaxDetails tbody tr").length - 1) {
                s.AccDesc = $(ele).find(".AccDesc").text();
                s.LedgerUid = $(ele).find(".LedgerId").text();
                s.TaxType = $(ele).find(".TaxName").text();
                s.TaxableAmount = $(ele).find(".TaxableAmount").text();
                s.TaxAmount = $(ele).find(".TaxAmounts").text();
                s.TaxLedgerId = $(ele).find(".TaxName .TaxLedgerId").val();
                BillTaxTableData.push(s);
            }

        })
        datastring.billEntryList = BillTableData;
        datastring.BillTaxModel = BillTaxTableData;
        datastring.BillNoUniqueId = BillUniqueId;
        datastring.Remarks = $("#Remarks").val();
        //ShowLoader();

        AjaxSubmission(JSON.stringify(datastring), "/Master/BillEntry/FormUpdate", $('input[name=__RequestVerificationToken]').val()).done(function (result) {
            let obj = result;

            if (obj.status == true) {
                if (obj.responsecode == '107') {
                    Toast(RetrieveMessage(obj.responsecode), "Message", "success");
                    BillEntryList(1);
                    //ResetForm();
                    //TabHide();

                }
                else if (obj.responsecode == '703')
                    Toast(RetrieveMessage(703), "Message", "error");
                else if (obj.responsecode == '1013') {
                    BillAc = 1;
                    NewBillNoConfirmation();
                }
                else if (obj.responsecode == '1019') {
                    Toast('You Dont Have Permission For This Bill Entry', "Message", "error");
                } else if (obj.responsecode == '1035') {
                    Toast('Record Updated Successfully', "Message", "success");
                } else if (obj.responsecode == '1044') {
                    Toast('Record Updated Successfully', "Message", "success");
                }
                else {
                    Toast(RetrieveMessage(obj.responsecode), "Message", "error");
                }
            }
            else {
                window.location.href = '/ClientLogin/ClientLogin';
            }
            //HideLoader();
        }).fail(function (result) {
            console.log(result.Message);
            //HideLoader();
        });
    }
    catch (e) {
        console.log(e.message);
    }
}

// BILL ENTRY FORM DELETE FUNCTION
function FormDelete(BillUid, BillTypeUid) {
    try {
        $.confirm({
            title: '',
            content: 'Are You Sure Want To Delete ?',
            type: 'red',
            boxWidth: '300px',
            useBootstrap: false,
            columnClass: 'small',
            containerFluid: true,
            typeAnimated: true,
            buttons: {
                tryAgain: {
                    text: 'Confirm',
                    btnClass: 'btn-red',
                    action: function () {
                        const datastring = {};

                        datastring.BillUid = BillUid;
                        datastring.BillTypeUid = BillTypeUid;

                        //ShowLoader();
                        AjaxSubmission(JSON.stringify(datastring), "/Master/BillEntry/FormDelete", $('[name="__RequestVerificationToken"]').val()).done(function (data) {
                            let obj = data;
                            if (obj.status == true) {
                                if (obj.responsecode == '102') {
                                    Toast(RetrieveMessage(obj.responsecode), "Message", "success");
                                    BillEntryList(1);
                                }
                                else {
                                    Toast(RetrieveMessage(obj.responsecode), "Message", "error");
                                }
                            }
                            else {
                                window.location.href = 'ClientLogin/ClientLogin';
                            }
                            //HideLoader();
                        }).fail(function (data) {
                            console.log(data.Message);
                            //HideLoader();
                        });
                    }
                },
                close: function () {
                    //HideLoader();
                }
            }
        });
    }
    catch (e) {
        console.log(e.message);
        //HideLoader();
    }
}


//FUNCTION FOR TAB SHOW
function TabShow() {
    $('#BillEntry_List-tab').removeClass('active');
    $('#BillEntry-tab').addClass('active');
    $('#BillEntry_List').removeClass('active show');
    $('#BillEntry').addClass('active show');
    $("#FormAdd").hide();
    $("#OpenEmailModal").show();
    $("#FormUpdate").show();
    $("#FormReset").show();
    $("#CreatePdf").show();
    $("#BillEntry-tab").html("Edit Bill Entry");
}

//FUNCTION FOR TAB HIDE
function TabHide() {
    $('#BillEntry-tab').removeClass('active');
    $('#BillEntry_List-tab').addClass('active ');
    $('#BillEntry_List').addClass('active show');
    $('#BillEntry').removeClass('active show');
    $("#FormAdd").show();
    $("#OpenEmailModal").hide();
    $("#FormUpdate").hide();
    $("#BillEntry-tab").html("Add Bill Entry");
}

////BILL LIST TAB CLICK FUNCTION 
//$('#BillEntry_List-tab').click(function () {
//    ResetForm();
//    TabHide();
//});
//FUNCTION FOR BIND INVOICE TYPE 
function FillInvoiceType(DrpId, isdefault) {
    try {
        //ShowLoader();
        AjaxSubmission(null, "/Master/BillEntry/FillInvoiceType", $('input[name=__RequestVerificationToken]').val()).done(function (result) {
            let obj = result;

            if (obj.status == true) {
                if (obj.responsecode == '100') {
                    BindDropdown(obj.data.Table, DrpId, 'invoicetype_id', 'invoice_type', '---Select---');
                }
                else if (obj.responsecode == '604') {
                    BindDropdown(null, DrpId, 'invoicetype_id', 'invoice_type', '---Select---');
                }
                else {
                    Toast(RetrieveMessage(obj.responsecode), "Message", "error");
                }
                if (isdefault == true) {
                    if (obj.data.Table1.length <= 0)
                        $("#" + DrpId).val(obj.data.Table[0].invoicetype_id).trigger('change');
                    else
                        $("#" + DrpId).val(obj.data.Table1[0].invoicetype_id).trigger('change');
                }


            }
            else {
                window.location.href = '/ClientLogin/ClientLogin';
            }
            HideLoader();
        }).fail(function (result) {
            console.log(result.Message);
            //HideLoader();
        });
    }
    catch (e) {
        console.log(e.message);
        //HideLoader();
    }
}
//FUNCTION FOR BIND BILL TYPE
function FillBillType() {
    try {
        //ShowLoader();
        AjaxSubmission(null, "/Master/BillEntry/FillBillType", $('input[name=__RequestVerificationToken]').val()).done(function (result) {
            let obj = result;
            if (obj.status == true) {
                if (obj.responsecode == '100') {
                    BindDropdown(obj.data.Table, 'BillType', 'BillTypeUid', 'BillTypeName', '0');
                }
                else if (obj.responsecode == '604') {
                    BindDropdown(null, 'BillType', 'BillTypeUid', 'BillTypeName', '0');
                }
                else {
                    Toast(RetrieveMessage(obj.responsecode), "Message", "error");
                }

            }
            else {
                window.location.href = '/ClientLogin/ClientLogin';
            }
            //HideLoader();
        }).fail(function (result) {
            console.log(result.Message);
            HideLoader();
        });
    }
    catch (e) {
        console.log(e.message);
        //HideLoader();
    }
}
// FUNCTION FOR BIND BILL GST TYPE
function FillBillGstType() {
    try {
        const dataString = {};
        dataString.BillTypeUid = $("#BillType").val();
        AjaxSubmission(JSON.stringify(dataString), "/Master/BillEntry/GetBillGstType", $('input[name=__RequestVerificationToken]').val()).done(function (result) {
            let obj = result;

            if (obj.status == true) {
                if (obj.responsecode == '100') {
                    $("#GstInvoiceCategory").val(obj.data.Table[0].GstInvoiceCategory);
                    $('#SubBillNo,#BillNo').val('');
                    if (obj.data.Table[0].GstInvoiceCategory == "INV") {
                        $("#BillEntryHeader").text('Bill Entry');
                        $("#BillDate").val(NewDate);
                        $(".TN").show();
                        $("#AddRow").show();
                        $(".NoGst").show();
                        $(".CNDN").hide();

                        $("#HiddenRefInvoiceNo,#RefInvoiceDate").val('');

                        $("#JobNo").removeAttr("disabled");
                        $("#ClientName").removeAttr("disabled");
                        $("#LedgerBranchAddress").removeAttr("disabled");
                        $("#NoGst").removeAttr("disabled");
                        $("#Address").removeAttr("disabled");

                        $("#Bill_table").each(function (ind, ele) {
                            $(ele).find(".TaxCategory").removeAttr("disabled");
                        });
                    }
                    if (obj.data.Table[0].GstInvoiceCategory == "DBN") {
                        $("#BillEntryHeader").text('Debit Note');
                        $("#AddRow").show();
                        $(".NoGst").show();
                        $(".TN").show();
                        //$(".CNDN").show();
                        $(".CNDN").hide();
                        $("#HiddenRefInvoiceNo,#RefInvoiceDate").val('');
                        //$("#HiddenRefInvoiceNo").val('');
                        //$("#RefInvoiceNo").val('').trigger('blur');
                        //$("#RefInvoiceDate").removeAttr('disabled');

                        $("#JobNo").removeAttr("disabled");
                        $("#ClientName").removeAttr("disabled");
                        $("#LedgerBranchAddress").removeAttr("disabled");
                        $("#NoGst").removeAttr("disabled");
                        $("#Address").removeAttr("disabled");
                    }
                    if (obj.data.Table[0].GstInvoiceCategory == "CRN") {
                        $("#BillEntryHeader").text('Credit Note');
                        $("#AddRow").hide();
                        $(".NoGst").show();

                        $(".TN").show();
                        $(".CNDN").show();

                        $("#HiddenRefInvoiceNo").val('');
                        $("#RefInvoiceNo").val('').trigger('blur');
                    }
                    if (obj.data.Table[0].GstInvoiceCategory == null) {
                        $("#BillEntryHeader").text('Reimbursement Entry');
                        $(".NoGst").hide();
                        $(".TN").hide();
                        $(".CNDN").hide();

                        $("#HiddenRefInvoiceNo,#RefInvoiceDate").val('');
                        $("#JobNo").removeAttr("disabled");
                        $("#ClientName").removeAttr("disabled");
                        $("#LedgerBranchAddress").removeAttr("disabled");
                        $("#NoGst").removeAttr("disabled");
                        $("#Address").removeAttr("disabled");

                        $("#Bill_table").each(function (ind, ele) {
                            $(ele).find(".TaxCategory").removeAttr("disabled");
                        });
                    }
                    GetBillNo();
                }
                else {
                    Toast(RetrieveMessage(obj.responsecode), "Message", "error");
                }
            }
            else {
                window.location.href = '/ClientLogin/ClientLogin';
            }
            //HideLoader();
        }).fail(function (result) {
            console.log(result.Message);
            HideLoader();
        });
    }
    catch (e) {
        console.log(e.message);
        //HideLoader();
    }
}

// JOB NO KEY PRESS EVENT
$("#JobNo").bind('keypress', function (e) {
    if (e.keyCode == 13) {
        $("#JobNo").trigger('change');
    }
});
// JOB NO ONINPUT EVENT
$("#JobNo").on('input', function () {
    $('#HiddenJobNo').val('');
});
// JOB NO ON BLUR EVENT
$("#JobNo").on('blur', function () {
    //if ($("#GstInvoiceCategory").val() == "DBN" || $("#GstInvoiceCategory").val() == "CRN") {
    if ($("#GstInvoiceCategory").val() == "CRN") {
        if ($("#HiddenJobNo").val().trim().length > 0) {
            if (hiddenJobNo != $("#HiddenJobNo").val().trim()) {
                hiddenJobNo = $("#HiddenJobNo").val().trim();
                FillJobData($("#JobNo").val().trim());
            }
        }
        else if (hiddenJobNo != '') {
            $("#JobNo,#JobDate").val('');
            hiddenJobNo = '';
            //ResetJobData();
        }
    }
    else {
        if ($("#HiddenJobNo").val().trim().length > 0) {
            if (hiddenJobNo != $("#HiddenJobNo").val().trim()) {
                hiddenJobNo = $("#HiddenJobNo").val().trim();
                FillJobData($("#JobNo").val().trim());
            }
        }
        else if (hiddenJobNo != '') {
            $("#RefInvoiceNo,#RefInvoiceDate").val('');
            ResetJobData();
        }
    }



});
//FUNCTION FOR GET DATA OF JOB NUMBER
function FillJobData(e) {
    try {
        const dataString = {};
        dataString.JobNo = e;
        dataString.BillType = $("#BillType").val();
        AjaxSubmission(JSON.stringify(dataString), '/Master/BillEntry/FillJobData', $('input[name=__RequestVerificationToken]').val()).done(function (result) {
            let obj = result;
            if (obj.status == true) {
                if (obj.responsecode == '100') {
                    //if ($("#GstInvoiceCategory").val() == "DBN") {
                    //    $("#JobDate").val(obj.data.Table[0].JobDate);
                    //}
                    if ($("#GstInvoiceCategory").val() == "CRN") {
                        $("#JobDate").val(obj.data.Table[0].JobDate);
                    }
                    else {
                        ResetJobData();
                        $("#JobDate").val(obj.data.Table[0].JobDate);

                        if (Object.getOwnPropertyNames(obj.data).length >= 1) {
                            $("#ClientName").attr('disabled', 'disabled');
                            $("#HiddenClientId").val(obj.data.Table[0].ClientId);
                            SelectedLedgerBranch = obj.data.Table[0].ClientBranchUid;
                            $("#ClientName").val(obj.data.Table[0].ClientName);
                            FillLedgerBranch();
                            let JobNoBlur = setInterval(() => {
                                if ($("#LedgerBranchAddress").html() != '') {
                                    $("#BENo").val(obj.data.Table[0].BENo);
                                    $("#BEDate").val(obj.data.Table[0].BEDate);
                                    $("#VesselName").val(obj.data.Table[0].VesselName);
                                    $("#PortLoading").val(obj.data.Table[0].PortLoading);
                                    $("#ContainerTypeNo").val(obj.data.Table[0].NoOfCont);
                                    $("#ContainerType").val(obj.data.Table[0].ContainerType);
                                    $("#TotalNetWeight").val(parseFloat(obj.data.Table[0].TotalNetWeight).toFixed(3));
                                    $("#PortDischarge").val(obj.data.Table[0].PortDischarge);

                                    if (obj.data.Table1 != undefined) {
                                        var BillList = obj.data.Table1;
                                        var firstChild = $("#Bill_table").find("tbody tr:first-child");
                                        $.each(BillList, function (index, ele) {
                                            if (index == 0) {
                                                firstChild.find('.GroupName').val(ele.SubgroupHeadName);
                                                firstChild.find('.HiddenGroupId').val(ele.LedgerId);
                                                firstChild.find('.AccountDesc').val(ele.AccHeadName);
                                                firstChild.find('.HiddenAccountDescId').val(ele.LedgerId);
                                                firstChild.find('.Particular').val(ele.Particular);
                                                firstChild.find('.RecNo').val(ele.ReceivingNo);
                                                firstChild.find('.RecDate').val(ele.ReceivingDate == '01/01/1900' ? '' : ele.ReceivingDate);
                                                firstChild.find('.BillNoUniqueId').val(ele.BillNoUniqueId);
                                                firstChild.find('.Amount').val(ele.Amount.toFixed(2));

                                            }
                                            else {

                                                firstChild.find('.RecDate').datepicker("destroy");
                                                firstChild.find('.RecDate').removeAttr("id");

                                                var cloneChild = firstChild.clone();


                                                cloneChild.find('.AccountDesc,.Particular,.RecNo,.RecDate,.BillNoUniqueId,.HiddenAccountDescId').val('');
                                                cloneChild.find('.Amount').val('0.00');


                                                cloneChild.find('.GroupName').val(ele.SubgroupHeadName);
                                                cloneChild.find('.HiddenGroupId').val(ele.LedgerId);
                                                cloneChild.find('.AccountDesc').val(ele.AccHeadName);
                                                cloneChild.find('.HiddenAccountDescId').val(ele.LedgerId);
                                                cloneChild.find('.Particular').val(ele.Particular);
                                                cloneChild.find('.RecNo').val(ele.ReceivingNo);
                                                cloneChild.find('.RecDate').val(ele.ReceivingDate == '01/01/1900' ? '' : ele.ReceivingDate);
                                                cloneChild.find('.BillNoUniqueId').val(ele.BillNoUniqueId);
                                                cloneChild.find('.Amount').val(ele.Amount.toFixed(2));

                                                $("#Bill_table tbody").append(cloneChild);


                                            }
                                            $(".datepickerAll").datepicker({
                                                changeMonth: true,
                                                changeYear: true,
                                                dateFormat: 'dd/mm/yy'
                                            });
                                        });
                                    }
                                    hiddenJobNo = $("#HiddenJobNo").val().trim();
                                    HiddenClientId = $("#HiddenClientId").val().trim();
                                    hiddenInvoiceId = $("#HiddenRefInvoiceNo").val().trim();
                                    $("#ClientName").removeAttr('disabled');
                                    clearInterval(JobNoBlur);
                                }
                            }, 100);

                        }
                    }
                }
                else
                    Toast(RetrieveMessage(obj.responsecode), 'Message', 'error');
            } else
                window.location.href = '/ClientLogin/ClientLogin';
            //HideLoader();

        }).fail(function (result) {
            console.log(result.Message);
            //HideLoader();
        });
    }
    catch (e) {
        console.log(e.message);
    }
}
//FUNCTION FOR FILL TAX CATEGORY
function FillTaxCategory() {
    try {
        //ShowLoader();
        AjaxSubmission(null, "/Master/_Layout/GetTaxCategory", $('input[name=__RequestVerificationToken]').val()).done(function (result) {
            let obj = result;
            if (obj.status == true) {
                if (obj.responsecode == '100') {
                    BindDropdownClass(obj.data.Table, 'TaxCategory', 'CategoryUid', 'CategoryName', '---Select---');
                }
                else if (obj.responsecode == '604') {
                    BindDropdownClass(null, 'TaxCategory', 'CategoryUid', 'CategoryName', '---Select---');
                }
                else {
                    Toast(RetrieveMessage(obj.responsecode), "Message", "error");
                }
            }
            else {
                window.location.href = '/ClientLogin/ClientLogin';
            }
            //HideLoader();
        }).fail(function (result) {
            console.log(result.Message);
            //HideLoader();
        });
    }
    catch (e) {
        console.log(e.message);
        //HideLoader();
    }
}
//FUNCTION FOR BIND DROPDOWN WITH CLASS
function BindDropdownClass(data, Dropdown_Class, Value, text, ZeroIndex) {
    if (data == null) {
        $('.' + Dropdown_Class).html('<option value="0">' + ZeroIndex + '</option>');
    } else {
        const DataCount = data.length;
        if (data != undefined && DataCount > 0) {
            var Data = '';
            if (ZeroIndex != '0')
                Data = '<option value="0">' + ZeroIndex + '</option>';
            for (var i = 0; i < data.length; i++)
                Data += '<option value="' + data[i][Value] + '">' + data[i][text] + '</option>';
            $('.' + Dropdown_Class).html(Data);
        }
        else
            $('.' + Dropdown_Class).html('<option value="0">' + ZeroIndex + '</option>');
    }
}
//CLIENT NAME ON INPUT  EVENT
$("#ClientName").on('input', function () {
    $("#HiddenClientId").val('');
})

//CLIENT NAME BUTTON BLUR EVENT
$("#ClientName").blur(function () {
    if ($("#HiddenClientId").val().trim().length > 0) {
        if (HiddenClientId != $("#HiddenClientId").val().trim() || hiddenInvoiceId != $("#HiddenRefInvoiceNo").val().trim()) {
            ResetBillDate();
            FillLedgerBranch();
            //if ($("#HiddenClientId").val().trim() != Hclid) {
            //    if ($("#GstInvoiceCategory").val() == "DBN" && $("#HiddenRefInvoiceNo").val().length > 0) {
            //        $("#HiddenRefInvoiceNo,#RefInvoiceNo,#RefInvoiceDate").val('');
            //        $("#TaxDetails tbody tr").remove();
            //        var tbody = $("#Bill_table").find("tbody");
            //        var Tr = $(tbody).find("tr");

            //        var rowCount = Tr.length;
            //        if (rowCount > 1) {
            //            $("#Bill_table tbody tr").each(function (index, ele) {
            //                if (index > 0) {
            //                    $(ele).remove();
            //                }
            //                else {
            //                    $(ele).find(".HiddenGroupId,.GroupName,.AccountDesc,.TaxAmount,.HiddenTaxPer,.HiddenAccountDescId,.Particular,.RecNo,.BillNoUniqueId").val('');
            //                    //$(ele).find(".RecDate").val('');
            //                    $(ele).find(".Amount").val('0.00');
            //                    $(ele).find(".TaxCategory").val('0');
            //                    $(ele).find(".TaxCategory").removeAttr("disabled");
            //                    $("#Bill_table").find("tbody").append(ele);
            //                }
            //            });

            //        }
            //        else {
            //            Tr.find(".HiddenGroupId,.GroupName,.AccountDesc,.TaxAmount,.HiddenTaxPer,.HiddenAccountDescId,.Particular,.RecNo,.BillNoUniqueId").val('');

            //            Tr.find(".Amount").val('0.00');
            //            Tr.find(".TaxCategory").val('0');
            //            Tr.find(".TaxCategory").removeAttr("disabled");
            //            $("#Bill_table").find("tbody").append(Tr);
            //        }

            //    }
            //}
        }
    } else {
        ResetBillDate();
        hiddenJobNo = $("#HiddenJobNo").val().trim();
        HiddenClientId = $("#HiddenClientId").val().trim();
        hiddenInvoiceId = $("#HiddenRefInvoiceNo").val().trim();
        $("#LedgerBranchAddress").html('');
        //if ($("#GstInvoiceCategory").val() == "DBN" && $("#HiddenRefInvoiceNo").val().length > 0) {
        //    $("#TaxDetails tbody tr").remove();
        //    var tbody = $("#Bill_table").find("tbody");
        //    var Tr = $(tbody).find("tr");

        //    var rowCount = Tr.length;
        //    if (rowCount > 1) {
        //        $("#Bill_table tbody tr").each(function (index, ele) {
        //            if (index > 0) {
        //                $(ele).remove();
        //            }
        //            else {
        //                $(ele).find(".HiddenGroupId").val('');
        //                $(ele).find(".GroupName").val('');
        //                $(ele).find(".AccountDesc").val('');

        //                $(ele).find(".TaxAmount").val('');
        //                $(ele).find(".HiddenTaxPer").val('');

        //                $(ele).find(".HiddenAccountDescId").val('');

        //                $(ele).find(".Particular").val('');

        //                $(ele).find(".RecNo").val('');
        //                $(ele).find(".BillNoUniqueId").val('');
        //                //$(ele).find(".RecDate").val('');
        //                $(ele).find(".Amount").val('0.00');
        //                $(ele).find(".TaxCategory").val('0');
        //                $(ele).find(".TaxCategory").removeAttr("disabled");
        //                $("#Bill_table").find("tbody").append(ele);
        //            }
        //        }); RefInvoiceNo

        //    }
        //    else {
        //        Tr.find(".HiddenGroupId").val('');
        //        Tr.find(".GroupName").val('');
        //        Tr.find(".AccountDesc").val('');

        //        Tr.find(".TaxAmount").val('');
        //        Tr.find(".HiddenTaxPer").val('');

        //        Tr.find(".HiddenAccountDescId").val('');
        //        Tr.find(".Particular").val('');

        //        Tr.find(".RecNo").val('');
        //        Tr.find(".BillNoUniqueId").val('');

        //        Tr.find(".Amount").val('0.00');
        //        Tr.find(".TaxCategory").val('0');
        //        Tr.find(".TaxCategory").removeAttr("disabled");
        //        $("#Bill_table").find("tbody").append(Tr);
        //    }

        //}
    }
});

// FUNCTION FOR RESET JOB DATA
function ResetBillDate() {
    $("#City,#Address,#State,#GSTNo,#BENo,#BEDate,#VesselName,#PortLoading,#ContainerTypeNo,#ContainerType,#TotalNetWeight,#PortDischarge,#GSTNo,#ClientState").val('');
}
// FUNCTION FOR RESET JOB DATA
function ResetJobData() {
    hiddenInvoiceId = '';
    hiddenJobNo = '';
    HiddenClientId = '';
    $("#JobDate,#HiddenClientId,#ClientName,#BENo,#BEDate,#City,#Address,#State,#GSTNo,#VesselName,#PortLoading,#ContainerTypeNo,#ContainerType,#TotalNetWeight,#PortDischarge,#ClientState,#LedgerBranchAddress").val('');
    let tbody = $("#Bill_table").find("tbody");
    let Tr = $(tbody).find("tr");

    let rowCount = Tr.length;
    if (rowCount > 1) {
        $("#Bill_table tbody tr").each(function (index, ele) {
            if (index > 0) {
                $(ele).remove();
            }
            else {
                $(ele).find(".HiddenGroupId,.GroupName,.AccountDesc,.TaxAmount,.HiddenTaxPer,.HiddenAccountDescId,.Particular,.RecNo,.BillNoUniqueId").val('');
                $(ele).find(".RecDate").val(NewDate);
                $(ele).find(".Amount").val('0.00');
                $(ele).find(".TaxCategory").val('0');
                $(ele).find(".TaxCategory").removeAttr("disabled");
                $("#Bill_table").find("tbody").append(ele);
            }
        });

    }
    else {
        Tr.find(".HiddenGroupId,.GroupName,.AccountDesc,.TaxAmount,.HiddenTaxPer,.HiddenAccountDescId,.Particular,.RecNo,.BillNoUniqueId").val('');
        Tr.find(".RecDate").val(NewDate);

        Tr.find(".Amount").val('0.00');
        Tr.find(".TaxCategory").val('0');
        Tr.find(".TaxCategory").removeAttr("disabled");
        $("#Bill_table").find("tbody").append(Tr);
    }
}

// AUTOCOMPLETE WITH CLASS FOR ADD MORE WITH OTHER COLUMNS 
function AutoCompleteAjaxWithClassWithColumn(className, PageUrl, HiddenId, WhereCondition) {
    $("." + className).autocomplete({
        source: function (request, response) {
            $.ajax({
                type: 'POST',
                url: PageUrl,
                dataType: "json",
                async: false,
                data: { SearchField: request.term, WhereCondition: WhereCondition },
                success: function (result) {
                    if (result.status == true) {
                        if (result.responsecode == '100') {
                            response($.map(result.data.Table, function (item, id) {
                                return {
                                    label: item.name,
                                    value: item.name,
                                    id: item.id,
                                    TaxCategory: item.TaxCategory,

                                };
                            }));
                        }
                    }
                    else {
                        window.location.href = '/ClientLogin/ClientLogin';
                    }
                }
            });
        },

        minLength: 1,
        selectFirst: true,
        selectOnly: true,
        autoFocus: true,
        select: function (e, i) {

            var parentTr = $(this).parents('tr');
            parentTr.find("." + HiddenId).val(i.item.id);

            if ($("#HiddenClientId").val().length != 0) {
                parentTr.find(".TaxCategory").val(i.item.TaxCategory).trigger('change');
                if (i.item.TaxCategory > 0) {
                    let tax = parentTr.find(".TaxCategory option:selected").text().split(' ')[1];
                    parentTr.find(".HiddenTaxPer").val(tax.split("@")[1]);
                }
            }
            else {
                parentTr.find(".TaxCategory").val("0").trigger('change');
                parentTr.find(".HiddenTaxPer").val("0");
            }
        },
        change: function (e, i) {
            var parentTr = $(this).parents('tr');

            if (i.item == null || i.item == undefined) {

                parentTr.find("." + HiddenId).val('');
                parentTr.find(".TaxCategory").val('0').trigger('change');

            }
        }

    });

}
// FUNCTION FOR BIND TAX DETAILS TABLE 
function BindTaxDetailsTable(val) {
    try {
        if ($("#Bill_table tbody tr").length > 0) {
            var CheckGst = $("#NoGst").is(":checked");
            if (CheckGst == false) {
                var flag = 0;
                var CategoryId = 0;

                var HiddenId = 0;
                var PurchaseTableData = new Array();
                $("#Bill_table tbody tr").each(function (ind, ele) {

                    if ($(ele).find(".HiddenAccountDescId").val().length > 0) {
                        var g = {};
                        CategoryId = $(this).find(".TaxCategory").val();

                        g.CategoryId = $(this).find(".TaxCategory").val();
                        g.TaxableAmount = $(this).find('.Amount').val();
                        g.AccDescHiddenId = $(this).find(".HiddenAccountDescId").val();
                        g.AccDesc = $(this).find(".AccountDesc").val();

                        PurchaseTableData.push(g);
                    }


                    else if ($(ele).find(".HiddenAccountDescId").val().length == 0 && val == undefined)
                        flag = 1;

                    //Toast(RetrieveMessage(913)f, 'messege', 'error');
                    //$("#TaxDetails tbody tr").remove();
                    //flag = 1;
                    //return;
                });

                if (flag == 0) {
                    if ($("#HiddenClientId").val() == '') {
                        Toast('Please Select Client Name !', 'Message', 'error');
                        return;
                    }
                    else {
                        var BranchState = $("#BranchState").val();
                        var ClientState = $("#ClientState").val();
                        const dataString = {};
                        dataString.BillTaxTable = PurchaseTableData;
                        dataString.BranchState = BranchState;
                        dataString.ClientState = ClientState;
                        AjaxSubmission(JSON.stringify(dataString), "/Master/BillEntry/BindTaxTable", $('input[name=__RequestVerificationToken]').val()).done(function (result) {
                            let obj = result;

                            if (obj.status == true) {
                                if (obj.responsecode == '100') {
                                    AddTaxDetail(obj.data);
                                }
                                else {
                                    Toast(RetrieveMessage(obj.responsecode), "Message", "error");
                                }
                            }
                            else {
                                window.location.href = '/ClientLogin/ClientLogin';
                            }
                            //HideLoader();
                        }).fail(function (result) {
                            console.log(result.Message);
                            //HideLoader();
                        });
                    }
                }
            }
        }


    }
    catch (e) {
        console.log(e.message);
    }

}
// FUNCTION TO CALCULATE TAX 
function CalculateTax(e) {
    var flag = 0;
    try {
        if ($("#HiddenClientId").val() == '') {
            flag = 1;
        }
        if (flag == 0) {


            var BranchState = $("#BranchState").val();
            var ClientState = $("#ClientState").val();
            var CategoryId = $(e).val();

            const dataString = {};
            dataString.CategoryId = CategoryId;
            dataString.BranchState = BranchState;
            dataString.ClientState = ClientState;
            //ShowLoader();
            AjaxSubmission(JSON.stringify(dataString), "/Master/BillEntry/CalculateTax", $('input[name=__RequestVerificationToken]').val()).done(function (result) {
                let obj = result;

                if (obj.status == true) {
                    if (obj.responsecode == '100') {
                        var parentTr = $(e).parents('tr');

                        $(parentTr).find('.HiddenTaxPer').val(obj.data.Table[0].TotalTax);
                        $(parentTr).find(".Amount").trigger("change");
                    }
                    else {
                        Toast(RetrieveMessage(obj.responsecode), "Message", "error");
                    }
                }
                else {
                    window.location.href = '/ClientLogin/ClientLogin';
                }
                //HideLoader();
            }).fail(function (result) {
                console.log(result.Message);
                //HideLoader();
            });
        }



    }
    catch (e) {
        console.log(e.message);
    }
}

// FUNCTION TO CALCULATE TAX AMOUNT
function CalculateTaxAmount(e) {
    var CheckGst = $("#NoGst").is(":checked");
    if (CheckGst == false) {


        var Amount = 0;
        var Tax = 0;
        var ParentTr = $(e).parents('tr');
        var TaxValue = $(ParentTr).find(".HiddenTaxPer").val();

        if ($(e).val() != "0.00") {

            Amount = $(e).val();
            Tax = (Amount * TaxValue) / 100;

            $(ParentTr).find(".TaxAmount").val(parseFloat(Tax).toFixed(2));

        }
    }
}

// FUNCTION TO GET TOTAL 
function GetTotal() {

    var grandTotal = 0;
    var TaxAmount = 0;

    $.each($('#Bill_table').find('.total'), function (index, ele) {
        if ($(ele).val() != '' && !isNaN($(ele).val())) {
            grandTotal += parseFloat($(ele).val());

        }
    });
    $.each($('#Bill_table').find('.TaxAmount'), function (index, ele) {
        if ($(ele).val() != '' && !isNaN($(ele).val())) {
            TaxAmount += parseFloat($(ele).val());
        }
    });

    $("#TotalAmount").html(parseFloat(grandTotal).toFixed(2));
    $("#TotalTaxAmount").html(parseFloat(TaxAmount).toFixed(2));
    var TotalWithTax = parseFloat(grandTotal) + parseFloat(TaxAmount);
    var RoundOffAmount = Math.round(parseFloat(TotalWithTax).toFixed(2));
    var RoundOff = parseFloat(TotalWithTax) - parseFloat(RoundOffAmount);
    $("#RoundOff").html(Math.abs(parseFloat(RoundOff.toFixed(2))));
    $("#NetAmount").html(parseFloat(RoundOffAmount).toFixed(2));

}

// FUNCTION TO ADD TAX DETAILS
function AddTaxDetail(Result) {
    $("#TaxDetails tbody tr").remove();

    for (i = 0; i < Result.length; i++) {
        tr = $('<tr/>');
        tr.append("<td class='AccDesc'>" + Result[i].AccDesc + "</td>");
        tr.append("<td class='LedgerId d-none'>" + Result[i].LedgerId + "</td>");
        tr.append("<td class='TaxName'>" + Result[i].TaxName + "<input type='hidden' class='TaxLedgerId' value='" + Result[i].TaxLedgerId + "'  /></td>");
        tr.append("<td class='text-end TaxableAmount'>" + parseFloat(Result[i].TaxableAmount).toFixed(2) + "</td>");
        tr.append("<td class='text-end TaxAmounts'>" + parseFloat(Result[i].TaxAmount).toFixed(2) + "</td>");
        $("#TaxDetails tbody").append(tr);

    }



    var RowCount = $("#TaxDetails tbody tr").length;
    if (RowCount != 0) {
        tr = $('<tr/>');
        tr.append('<td></td>');
        tr.append('<td></td>');
        tr.append('<td class="Tabletdwidth text-end" style="color: #1f242a; font-weight: 600;"><span id="TotalTaxableAmounts">' + ($("#TotalAmount").text() != "" ? parseFloat($("#TotalAmount").text()).toFixed(2) : "0.00") + '</span></td>');
        tr.append('<td class="Tabletdwidth text-end" style="color: #1f242a; font-weight: 600;"><span id="TotalTaxAmounts">' + ($("#TotalTaxAmount").text() != "" ? parseFloat($("#TotalTaxAmount").text()).toFixed(2) : "0.00") + '</span></td>')
        $("#TaxDetails tbody").append(tr);

    }
}
//FILL LEDGER BRANCH
function FillLedgerBranch() {
    try {

        const dataString = {};
        var DropId = parseInt($('#HiddenClientId').val().trim());
        if (isNaN(DropId)) {
            $('#LedgerBranchAddress').html('');
            $('#GstNo,#BranchAddress').val('');
        }
        else {
            //ShowLoader();
            dataString.Id = DropId;
            AjaxSubmission(JSON.stringify(dataString), '/Master/_Layout/FillLedgerBranch', $('input[name=__RequestVerificationToken]').val()).done(function (result) {

                let obj = result;
                if (obj.status == true) {

                    if (obj.responsecode == '100') {
                        BindDropdown(obj.data.Table, 'LedgerBranchAddress', 'BranchUid', 'BranchName', 'Default Address');


                    } else {
                        BindDropdown(null, 'LedgerBranchAddress', 'BranchUid', 'BranchName', 'Default Address');
                    }

                    //if (SelectedLedgerBranch == '' || SelectedLedgerBranch == undefined || SelectedLedgerBranch == null)
                    //    $("#LedgerBranchAddress").val(0).trigger('change');
                    //else {
                    //    $("#LedgerBranchAddress").val(SelectedLedgerBranch).trigger('change');
                    //    SelectedLedgerBranch = '';
                    //}
                    hiddenJobNo = $("#HiddenJobNo").val().trim();
                    HiddenClientId = $("#HiddenClientId").val().trim();
                    hiddenInvoiceId = $("#HiddenRefInvoiceNo").val().trim();
                    //if (SelectedLedgerBranch.length == 0) {
                    //    $("#LedgerBranchAddress").val(0).trigger('change');
                    //}                    
                    //else {
                    //    $("#LedgerBranchAddress").val(SelectedLedgerBranch).trigger('change');
                    //    SelectedLedgerBranch = "";
                    //}
                } else
                    window.location.href = '/ClientLogin/ClientLogin';
                //HideLoader();
            }).fail(function (result) {
                console.log(result.Message);
                //HideLoader();
            });
        }

    } catch (e) {
        console.log(e.message);
    }

}
// FUNCTION TO FILL LEDGER BRANCH ADDRESS
function FillLedgerAddress(FromLedgerBranch, Id) {
    try {
        const datastring = {};
        datastring.Id = Id;
        datastring.BranchId = $("#BranchId").val();
        datastring.FromLedgerBranch = FromLedgerBranch;
        AjaxSubmission(JSON.stringify(datastring), "/Master/BillEntry/FillLedgerAddress", $('input[name=__RequestVerificationToken]').val()).done(function (result) {
            let obj = result;

            if (obj.status == true) {
                if (obj.responsecode == '100') {
                    $("#GSTNo").val(obj.data[0].GstNo);
                    $("#Address").val(obj.data[0].Address);
                    $("#ClientState").val(obj.data[0].ClientState);
                    $("#City").val(obj.data[0].City);
                    $("#State").val(obj.data[0].StateName);
                    BindTaxDetailsTable();
                }
                else if (obj.responsecode == '604')
                    $("#GSTNo,#Address,#ClientState,#City,#State").val('');
                else
                    Toast(RetrieveMessage(obj.responsecode), "Message", "error");
            }
            else
                window.location.href = '/ClientLogin/ClientLogin';
            //HideLoader();
        }).fail(function (result) {
            console.log(result.Message);
            //HideLoader();
        });
    }
    catch (e) {
        console.log(e.message);
    }
}
// FUNCTION TO FILL BRANCH STATE
function FillBranchState() {
    try {
        const datastring = {};
        datastring.BranchId = $("#BranchId").val();

        AjaxSubmission(JSON.stringify(datastring), "/Master/BillEntry/FillBranchState", $('input[name=__RequestVerificationToken]').val()).done(function (result) {
            let obj = result;

            if (obj.status == true) {
                if (obj.responsecode == '100') {
                    $("#BranchState").val(obj.data[0].StateCode);
                    BindTaxDetailsTable();
                }
                else if (obj.responsecode == '604') {
                    $("#BranchState").val('');
                }
                else {
                    Toast(RetrieveMessage(obj.responsecode), "Message", "error");
                }
            }
            else {
                window.location.href = '/ClientLogin/ClientLogin';
            }
            //HideLoader();
        }).fail(function (result) {
            console.log(result.Message);
            //HideLoader();
        });
    }
    catch (e) {
        console.log(e.message);
    }
}
// FUNCTION TO BIND LEDGER ADDRESS DEFAULT OR OTHER  LEDGER BRANCH
function BindAddressLedger() {

    if ($("#HiddenClientId").val().length <= 0) {
        $("#LedgerBranchAddress,#GSTNo").val('');
        $("#Address").val();
    }

    if ($("#LedgerBranchAddress").val() == '0') {
        if ($("#HiddenClientId").val().length <= 0) {
            $("#LedgerBranchAddress,#GSTNo").val('');
            $("#Address").val();
        }

        FillLedgerAddress(false, $("#HiddenClientId").val());
    }
    else {
        FillLedgerAddress(true, $("#LedgerBranchAddress").val());
    }

};
// FUNCTION TO GENERATE BILL NO 
function GetBillNo() {
    try {

        if ($("#BranchId").val() > 0 && $("#BillDate").val().trim().length == 10 && $("#BillType").val() > 0 && $("#InvoiceType").val() > 0) {
            const dataString = {};

            dataString.BranchId = $("#BranchId").val();
            dataString.BillDate = $("#BillDate").val();
            dataString.InvoiceType = $("#InvoiceType").val();
            dataString.BillTypeUid = $("#BillType").val();

            if (billflag != 1) {
                dataString.SubBillNo = $("#SubBillNo").val();
            }
            dataString.BillUid = $("#BillId").val();
            //Showloader();
            AjaxSubmission(JSON.stringify(dataString), '/Master/BillEntry/GetBillNo', $('[name="__RequestVerificationToken"]').val()).done(function (result) {
                let obj = result;
                if (obj.status == true) {
                    if (obj.responsecode == '100') {
                        if (obj.data.Table[0].InvalidValid_Bill_No == false) {
                            $("#BillNo,#SubBillNo").val('');
                            $("#BillNo").val(obj.data.Table[0].BillNo);
                            $("#SubBillNo").val(obj.data.Table[0].Sub_Bill_No);
                            if (billflag == 1) {
                                if (BillAc == 1) {
                                    billflag = 0;
                                    BillAc = 0;
                                    //FormAdd();
                                }
                                else if (BillAc == 2) {
                                    billflag = 0;
                                    BillAc = 0;
                                    // FormUpdate();
                                }

                            }
                        } else {
                            Toast('Bill Number Already Exist', 'Message', 'error');
                        }
                    }
                    else if (obj.responsecode == '703')
                        Toast(RetrieveMessage(obj.responsecode), 'Message', 'error');
                    else if (obj.responsecode == '1012')
                        Toast('Bill Date Not Exist In Financial Year', 'Message', 'error');

                }
                else
                    window.location.href = '/ClientLogin/ClientLogin';
                //Hideloader();

            }).fail(function (result) {
                //Hideloader();
                console.log(result.message);

            });
            //Hideloader();
        }
    }
    catch (e) {
        console.log(e.message);
    }
}
// FUNCTION FOR NEW BILL NUMBER CONFIRMATION
function NewBillNoConfirmation() {
    try {
        $.confirm({
            title: '',
            content: 'This Bill Number has been used.',
            type: 'green',
            boxWidth: '300px',
            useBootstrap: false,
            typeAnimated: true,
            columnClass: 'small',
            containerFluid: true,
            buttons: {
                tryAgain: {
                    text: 'Confirm',
                    btnClass: 'btn-green',
                    action: function () {
                        billflag = 1;
                        GetBillNo();
                    }
                },
                cancel: function () {
                    $("#BillDate").focus();
                    //Hideloader();
                }
            }
        });
    }
    catch (e) {
        console.log(e.message);
        //Hideloader();
    }
};
// FUNCTION TO GET DYNAMIC BILL TYPE BUTTON 
function DynamicBillTypeButton() {
    try {
        var DivHtml = "";
        var SrNo = 1;
        ShowLoader();
        AjaxSubmission(null, "/Master/BillEntry/FillBillType", $('input[name=__RequestVerificationToken]').val()).done(function (result) {
            let obj = result;
            if (obj.status == true) {

                if (obj.responsecode == '100') {

                    DivHtml = "<div class='btn-group' role='group' aria-label='Basic radio toggle button group'>";
                    for (i = 0; i < obj.data.Table.length; i++) {
                        if (i == 0) {
                            DivHtml += "<input type='radio' class='btn-check ' checked name='btnradio' id='btnradio" + SrNo + "' value='" + obj.data.Table[i].BillTypeUid + "' autocomplete='off' onclick='GetCheckRadioVal(this,\"" + obj.data.Table[i].BillTypeName + "\")'><label class='btn btn-primary ' for='btnradio" + SrNo + "'>" + obj.data.Table[i].BillTypeName + "</label>";
                        }
                        else {
                            DivHtml += "<input type='radio' class='btn-check' name='btnradio' id='btnradio" + SrNo + "' value='" + obj.data.Table[i].BillTypeUid + "' autocomplete='off' onclick='GetCheckRadioVal(this,\"" + obj.data.Table[i].BillTypeName + "\")'><label class='btn ' for='btnradio" + SrNo + "'>" + obj.data.Table[i].BillTypeName + "</label>";
                        }
                        SrNo++;
                    }
                    DivHtml += "</div>";
                    $("#DynamicButtonDiv").html(DivHtml);
                }
            }
            else {
                window.location.href = '/ClientLogin/ClientLogin';
            }
            HideLoader();
        }).fail(function (result) {
            console.log(result.Message);
            HideLoader();
        });
    }
    catch (e) {
        console.log(e.message);
        HideLoader();
    }
}

// FUNCTION FOR ON CHANGE OF BILL TYPE DYNAMIC BUTTONS
function GetCheckRadioVal(e, l) {

    $('input[name="btnradio"]').each(function () {
        $(this).checked = false;
        $(this).next().removeClass('btn-primary');
        $(this).removeAttr('checked');
    });
    $('#' + $(e).attr('id')).next().addClass('btn-primary');
    $('#' + $(e).attr('id')).next().attr('checked', true);
    $("#BillEntryHeader").text($('#' + $(e).attr('id')).next().text());
    BillEntryList();
}
// FUNCTION TO RESET FORM 
function ResetForm(val) {
    $("#CanChangeTax").val('');
    hiddenJobNo = '';
    HiddenClientId = '';
    hiddenInvoiceId = '';
    $("#RemoveRow").removeAttr("disabled");
    $("#EBillRow").hide();
    $('input[name="btnradio"]').each(function (ind, ele) {
        if ($('#' + $(ele).attr('id')).is(':checked') == true)
            $('#BillEntryHeader').text($('#' + $(ele).attr('id')).next().text());
    });
    srbtn = 'up';
    $("#BillId").val('');
    if (val == undefined) {
        $("#BillType").removeAttr("disabled");
        FillBillType();
    }
    var date = new Date();
    var NewDate = date.getDate().toString().padStart(2, 0) + "/" + (date.getMonth() + 1).toString().padStart(2, 0) + "/" + date.getFullYear().toString();
    $("#BillDate").val(NewDate);
    $(".BE").show();
    $(".BEI").show();
    $(".TN").show();
    $(".CNDN").hide();
    $(".NoGst").show();


    $("#HiddenRefInvoiceNo,#RefInvoiceDate").val('');
    $("#AddRow").show();

    if (val == undefined)
        FillBranchList('BranchId');

    FillInvoiceType('InvoiceType', true);
    $("#CreatedByModifiedBy").css('display', 'none');
    $("#TransactionCategory").val('R');
    $("#SubBillNo").val('');
    //GetBillNo();
    //$("#BillNo").val('');

    $("#JobNo,#HiddenJobNo ,#JobDate,#BENo,#BEDate,#City,#State,#Address,#VesselName,#PortLoading,#PortLoading,#ContainerTypeNo,#ContainerType,#TotalNetWeight,#PortDischarge,#ClientState,#BranchState,#GSTNo,#HiddenClientId,#ClientName,#CancelDate,#IRNNo,#RefInvoiceDate").val('');

    $("#TaxDetails tbody tr").remove();
    $(".EditField").hide();
    $(".IRNSHOW").hide();
    $("#NoGst").prop("checked", false);
    $("#JobNo").removeAttr("disabled");
    $("#ClientName").removeAttr("disabled");
    $("#LedgerBranchAddress").removeAttr("disabled");
    $("#NoGst").removeAttr("disabled");
    $("#Address").removeAttr("disabled");
    $("#CancelBill").prop("checked", false);
    $("#TotalAmount,#RoundOff,#LedgerBranchAddress,#TotalTaxAmount,#NetAmount").html('');
    $("#CreatedBy,#CreatedAt,#ModifiedBy,#ModifiedAt").text('');
    $("#FormAdd").show();
    $("#OpenEmailModal").hide();
    $("#BillIdDiv").css("display", "none");
    $("#FormUpdate,#CreatePdf,#FormReset").hide();
    $("#BillEntry-tab").html("Add Bill Entry");
    $("#GstInvoiceCategory").val('INV');

    var tbody = $("#Bill_table").find("tbody");
    var Tr = $(tbody).find("tr");

    var rowCount = Tr.length;
    if (rowCount > 1) {
        $("#Bill_table tbody tr").each(function (index, ele) {
            if (index > 0) {
                $(ele).remove();
            }
            else {
                $(ele).find(".HiddenGroupId,.GroupName,.AccountDesc,.TaxAmount,.HiddenTaxPer,.HiddenAccountDescId,.Particular,.RecNo,.RecDate,.BillNoUniqueId").val('');
                $(ele).find(".Amount").val('0.00');
                $(ele).find(".TaxCategory").val('0');
                $(ele).find(".TaxCategory").removeAttr("disabled");
                $("#Bill_table").find("tbody").append(ele);
            }
        });

    }
    else {
        Tr.find(".HiddenGroupId,.GroupName,.AccountDesc,.TaxAmount,.HiddenTaxPer,.HiddenAccountDescId,.Particular,.RecNo,.RecDate,.BillNoUniqueId").val('');

        Tr.find(".Amount").val('0.00');
        Tr.find(".TaxCategory").val('0');
        Tr.find(".TaxCategory").removeAttr("disabled");
        $("#Bill_table").find("tbody").append(Tr);
    }

    $('#Bill_table tbody tr').find(".GroupName,.AccountDesc,.RecNo,.RecDate,.Amount,.Particular").removeAttr('disabled');
    $("#BranchId,#InvoiceType,#TransactionCategory,#SubBillNo,#BillDate,#JobNo,#ClientName,#LedgerBranchAddress,#Address,#NoGst,#AddRow").removeAttr('disabled');
}
// FUNCTION FOR SHOW HIDE FIELDS 
function ShowHideFields() {
    FillBillGstType();
    ResetForm(true);
}


//ADD MORE FOR BILL ENTRY 
$("#AddRow").click(function () {
    $("#RemoveRow").removeAttr('disabled');

    var tbody = $("#Bill_table").find("tbody");
    var FirstTr = $(tbody).find("tr:first");
    FirstTr.find('.RecDate').datepicker("destroy");
    FirstTr.find('.RecDate').removeAttr("id");

    var NewRow = $(FirstTr).clone();
    NewRow.find(".HiddenGroupId,.GroupName,.AccountDesc,.HiddenAccountDescId,.isTaxable,.TaxPerLedger,.Particular,.RecNo,.BillNoUniqueId,.RecDate,.HiddenTaxPer").val('');
    NewRow.find('.Amount,.TaxAmount').val('0.00');

    $("#Bill_table").append(NewRow);
    var LastTr = $(tbody).find("tr:last");
    LastTr.find('.GroupName').focus();

    $(".datepickerAll").datepicker({
        changeMonth: true,
        changeYear: true,
        dateFormat: 'dd/mm/yy'
    });
    $(".mydate").datepicker('setDate', 'today');
});

//DELETE ROW FOR BILL ENTRY 
function DeleteBillEntryRow(obj) {
    var rowCount = $("#Bill_table tbody tr").length;

    if (rowCount > 1) {
        $(obj).parent().parent().remove();
    }
    else {
        $("#RemoveRow").attr("disabled", "disabled");
        //$("#HiddenGroupId").val('');
        //$("#GroupName").val('');
        //$("#HiddenAccountDescId").val('');
        //$("#AccountDesc").val('');
        //$("#Particular").val('');
        //$("#RecNo").val('');
        //$("#RecDate").val('');
        //$("#Amount").val('0.00');
        //$("#TaxCategory").val(0);
        //$("#TaxAmount").val('0.00');
    }
    BindTaxDetailsTable(true);
}
//$(document).ready(() => {
//    BillNoAutoCompleteAjax('RefInvoiceNo', '/Master/BillEntry/GetBillNumberAutoComplete', 'HiddenRefInvoiceNo', null, null, null, 'BranchId', '1', '0');

//})
//FUNCTION FOR AUTOCOMPLETE AJAX WITH ID
function BillNoAutoCompleteAjax(id, Url, HiddenId, SubBill, BillFrm, BillTo, BranchId, Custom, PageLoad) {
    try {
        if (PageLoad == 1) {
            return;
        }

        $("#" + id).autocomplete({
            source: function (request, response) {
                AjaxSubmissionAutocomplete(JSON.stringify({ SearchField: request.term, SubBillNo: $("#" + SubBill).val(), BillDateFrom: $("#" + BillFrm).val(), BillDateTo: $("#" + BillTo).val(), BranchId: $("#" + BranchId).val(), BillType: $("#BillType").val(), RadioBillType: $('input:radio[name=btnradio]:checked').val(), ClientId: $("#HiddenClientId").val(), JobUid: $("#HiddenJobNo").val().trim() }), Url, $('input[name=__RequestVerificationToken]').val()).done(function (result) {
                    let obj = result;
                    if (obj.status == true) {
                        if (obj.responsecode == '100') {
                            $("#ui-id-3").removeClass("d-none");
                            response($.map(result.data.Table, function (item, id) {
                                return {
                                    label: item.name,
                                    value: item.name,
                                    id: item.id
                                };
                            }));
                        } else {
                            $("#ui-id-3").addClass("d-none");
                        }
                    }
                    else
                        window.location.href = '/ClientLogin/ClientLogin';
                    //Hideloader();
                }).fail(function (result) {
                    //Hideloader();
                    console.log(result.Message);
                });
            },
            minLength: 1,
            selectOnly: true,
            select: function (e, i) {
                $("#" + HiddenId).val(i.item.id);
            },
            change: function (e, i) {
                if (Custom != "1") {
                    if (i.item == null || i.item == undefined) {
                        $("#" + id).val('');
                        $("#" + HiddenId).val('');
                    }
                }
            }, open: function () {
                $("ul.ui-menu").css({
                    'overflow-y': 'scroll',
                    'overflow-x': 'hidden',
                    'max-height': '200px'
                });
            }
        })
    }
    catch (e) {
        console.log(e);
    }
}


// LIST TAB ON CLICK EVENT
$('#BillEntry_List-tab').click(function () {
    ResetForm();
});
// FORM RESET BUTTON CLICK EVENT
$("#FormReset").click(function () {
    ResetForm();
})
// FUNCTION TO CANCULATE NO GST 
function CalculateNoGst() {
    let CheckGst = $("#NoGst").is(":checked");
    let CheckTax = $("#CanChangeTax").val();

    if (CheckTax && !CheckGst) {
        $('#Bill_table tbody tr').each((i, ele) => {

            $("#NoGst").attr('disabled', 'disabled');
            $(ele).find(".Amount").trigger('blur');
            $(ele).find(".TaxCategory").blur();
            if (i == $('#Bill_table tbody tr').length - 1) {
                setTimeout(() => { $("#NoGst").removeAttr('disabled'); }, 2000);
            };
            $(ele).find(".TaxCategory").removeAttr("disabled");
        });
    }
    if (CheckTax != '') {
        if (CheckTax == 'false') {
            $("#Bill_table tbody tr").each(function (index, ele) {
                $(ele).find(".TaxCategory").prop('disabled', 'disabled');
                $(ele).find(".TaxAmount").val('0.00');
                $(ele).find(".HiddenTaxPer").val('');
            });
        }
        else if (CheckTax == 'true') {
            if (CheckGst == true) {
                $("#Bill_table tbody tr").each(function (index, ele) {
                    $(ele).find(".TaxCategory").prop('disabled', 'disabled');
                    $(ele).find(".TaxAmount").val('0.00');
                    $(ele).find(".HiddenTaxPer").val('');
                });
                GetTotal();
                var RowCount = $("#TaxDetails tbody tr").length;
                if (RowCount > 0) {
                    $("#TaxDetails tbody tr").remove();
                }
            }
            //else if (CheckGst == false) {
            //    $("#Bill_table tbody tr").each(function (index, ele) {
            //        $(ele).find(".TaxCategory").removeAttr("disabled");
            //        //$(ele).find(".TaxCategory").trigger('change');

            //    });

            //}
        }
    }

};

// FUNCTION TO FILL CANCEL DATE 
function FillCancelDate() {
    var CheckCancel = $("#CancelBill").is(":checked");
    if (CheckCancel == true) {
        var date = new Date();
        var datestring = date.getDate().toString().padStart(2, 0) + "/" + (date.getMonth() + 1).toString().padStart(2, 0) + "/" + date.getFullYear().toString();
        $("#CancelDate").val(datestring);

    }
    else {
        $("#CancelDate").val('');
    }
}

//FUNCTION FOR GET FINANCIAL YEAR DATE
function GetFinancialYearDate(start, end) {
    try {
        AjaxSubmission(null, '/Master/_Layout/GetFinancialYearDate', $('[name="__RequestVerificationToken"]').val()).done(function (result) {
            let obj = result;

            if (obj.status == true) {
                if (obj.responsecode == '100') {
                    $("#" + start).val(obj.data.Table[0].finyr_start_date);
                    $("#" + end).val(obj.data.Table[0].finyr_end_date);
                }
            }
            else
                window.location.href = '/ClientLogin/ClientLogin';
            //Hideloader();

        }).fail(function (result) {
            //Hideloader();
            console.log(result.message);

        });
        //Hideloader();
    }
    catch (e) {
        //Hideloader();
        console.log(e.message);
    }
}
// CREATE PDF BUTTON CLICK 
$("#CreatePdf").click(function () {
    if ($("#BillId").val() != '') {
        DownloadBillReport($("#BillId").val());
    }
});

// DOWNLOAD BILL REPORT FUNCTION
function DownloadBillReport(BillId) {
    try {
        const datastring = {};

        datastring.BillId = BillId;
        datastring.BranchId = $("#BranchId").val();
        datastring.BillType = $("#BillType").val();
        AjaxSubmission(JSON.stringify(datastring), "/Master/BillEntry/DownloadBillReport", $('input[name=__RequestVerificationToken]').val()).done(function (result) {
            let obj = result;

            if (obj.status == true) {
                if (obj.responsecode == '100') {
                    window.open($("#BillPdf").attr('href'), '_blank');

                }
                else {
                    Toast(RetrieveMessage(obj.responsecode), "Message", "error");
                }
            }
            else {
                window.location.href = '/ClientLogin/ClientLogin';
            }
            //HideLoader();
        }).fail(function (result) {
            console.log(result.Message);
            //HideLoader();
        });
    }
    catch (e) {

    }

}

// FUNCTION FOR ON CHANGE OF TRANSACTION CATEGORY TO CHANGE GST CALCULATION
function ChangeTransactionCategory() {
    if ($("#TransactionCategory").val() == "SEWOP") {
        $("#NoGst").prop("checked", true);
        $("#NoGst").trigger('change');

    }
    else if ($("#TransactionCategory").val() == "WOPAY") {
        $("#NoGst").prop("checked", true);
        $("#NoGst").trigger('change');
    }
    else {
        $("#NoGst").prop("checked", false);
        $("#NoGst").trigger('change');
    }
}

// FUNCTION TO GET EMAIL DATA AND TEMPLATE WORK 
function GetEmailData() {
    try {
        ShowLoader();
        const datastring = {};
        datastring.BillId = $("#BillId").val();
        datastring.BranchId = $("#BranchId").val();
        datastring.BillType = $("#BillType").val();
        datastring.BillNo = $("#BillNo").val();
        datastring.ClientName = $("#ClientName").val();
        AjaxSubmission(JSON.stringify(datastring), "/Master/BillEntry/GetEmailData", $('input[name=__RequestVerificationToken]').val()).done(function (result) {
            let obj = result;
            if (obj.status == true) {
                if (obj.responsecode == '100') {
                    EmailModal.style.display = "block";
                    $("#EmailTo").val(obj.data.Table1[0].ClientEmail);
                    $("#EmailCC").val(obj.data.Table1[0].CCEmail);
                    $("#AttachFileName").text(obj.data.Table2[0].FileName);
                    $("#AttachFileName").attr("href", obj.data.Table2[0].FilePath);
                    $("#AttachedFilePath").val(obj.data.Table2[0].AttachmentFilePath);

                    $("#RefId").val($("#BillId").val());
                    $("#SendToName").val($("#ClientName").val());
                    $("#RefName").val('BillEntryReport');
                    BindTemplateName('AllTemplate', 'Email');
                    FillTemplateDataInTincyMce($('#BillId').val(), 'BillEntry', null, 'Email');

                }
                else {
                    Toast(RetrieveMessage(obj.responsecode), "Message", "error");
                }
            }
            else {
                window.location.href = '/ClientLogin/ClientLogin';
            }
            HideLoader();
        }).fail(function (result) {
            console.log(result.Message);
            HideLoader();
        });
    }
    catch (e) {
        console.log(e.message);
        HideLoader();
    }
}

//FUNCTION FOR CHANGE TEMPLATE DETAILS
function TemplateChange() {
    tinymce.get("EmailBody").setContent('');
    $('#Subject').val('');
    if ($('#AllTemplate').val() != null && $('#AllTemplate') != undefined) {
        if ($('#AllTemplate').val() != 0)
            FillTemplateDataInTincyMce($('#BillId').val(), 'BillEntry', $('#AllTemplate').val(), 'Email');
    }
}
//MODAL SEND EMAIL CLICK TO GET EMAIL DATA AND OPEN MODEL
$("#OpenEmailModal").click(function () {
    GetEmailData();
});

//FUNCTION FOR TINYMCE EDITIOR
function LoadTinyMCE() {
    tinymce.init({
        selector: ".tinymce",
        branding: false,
        theme: "modern",
        skin: "lightgray",
        width: "100%",
        height: 250,
        statubar: true,
        plugins: [
            "advlist autolink link image lists charmap print preview hr anchor pagebreak",
            "searchreplace wordcount visualblocks visualchars code fullscreen insertdatetime media nonbreaking",
            "save table contextmenu directionality emoticons template paste textcolor"
        ],
        toolbar: "insertfile undo redo | styleselect | bold italic | alignleft aligncenter alignright alignjustify | bullist numlist outdent indent | link | fontsizeselect | fontselect | image | print preview media fullpage | forecolor backcolor emoticons ",
        style_formats: [
            {
                title: "Headers", items: [
                    { title: "Header 1", format: "h1" },
                    { title: "Header 2", format: "h2" },
                    { title: "Header 3", format: "h3" },
                    { title: "Header 4", format: "h4" },
                    { title: "Header 5", format: "h5" },
                    { title: "Header 6", format: "h6" }
                ]
            },
            {
                title: "Inline", items: [
                    { title: "Bold", icon: "bold", format: "bold" },
                    { title: "Italic", icon: "italic", format: "italic" },
                    { title: "Underline", icon: "underline", format: "underline" },
                    { title: "Strikethrough", icon: "strikethrough", format: "strikethrough" },
                    { title: "Superscript", icon: "superscript", format: "superscript" },
                    { title: "Subscript", icon: "subscript", format: "subscript" },
                    { title: "Code", icon: "code", format: "code" }
                ]
            },
            {
                title: "Blocks", items: [
                    { title: "Paragraph", format: "p" },
                    { title: "Blockquote", format: "blockquote" },
                    { title: "Div", format: "div" },
                    { title: "Pre", format: "pre" }
                ]
            },
            {
                title: "Alignment", items: [
                    { title: "Left", icon: "alignleft", format: "alignleft" },
                    { title: "Center", icon: "aligncenter", format: "aligncenter" },
                    { title: "Right", icon: "alignright", format: "alignright" },
                    { title: "Justify", icon: "alignjustify", format: "alignjustify" }
                ]
            }
        ],
    });
}
// FUNCTION TO GET REFERENCE INVOICE DATA 
function GetInvoiceData(IsJobNoExist) {
    try {
        const datastring = {};
        datastring.BillNo = $("#HiddenRefInvoiceNo").val();
        datastring.BillType = $("#BillType").val();
        AjaxSubmission(JSON.stringify(datastring), "/Master/BillEntry/GetReferenceInvoiceData", $('input[name=__RequestVerificationToken]').val()).done(function (result) {
            let obj = result;

            if (obj.status == true) {
                if (obj.responsecode == '100') {

                    var GstCategory = $("#GstInvoiceCategory").val();
                    ResetInvoiceData(GstCategory);
                    if (GstCategory == "CRN") {
                        //$("#ClientName").attr("disabled", true);
                        //$("#LedgerBranchAddress").attr("disabled", true);
                        //$("#NoGst").attr("disabled", true);
                        //$("#Address").attr("disabled", true);
                        //$("#JobNo").attr("disabled", true);
                        $("#RefInvoiceDate").val(obj.data.Table[0].BillDate);
                        $("#BranchId").val(obj.data.Table[0].BranchId);
                        $("#InvoiceType").val(obj.data.Table[0].InvoiceType);
                        $("#TransactionCategory").val(obj.data.Table[0].TransactionCategory);
                        $("#HiddenJobNo").val(obj.data.Table[0].JobUid);
                        $("#JobNo").val(obj.data.Table[0].JobNo);

                        $("#JobDate").val(obj.data.Table[0].JobDate);
                        $("#HiddenClientId").val(obj.data.Table[0].ClientId);
                        //if (HiddenClientId == '') {
                        $("#ClientName").val(obj.data.Table[0].AccHead);
                        SelectedLedgerBranch = obj.data.Table[0].LedgerBranch;
                        FillLedgerBranch();
                        //$("#ClientName").trigger('blur');
                        let FillClientInfo = setTimeout(() => {
                            if ($("#HiddenClientId").val().length > 0) {
                                $("#LedgerBranchAddress").val(SelectedLedgerBranch);
                                $("#BENo").val(obj.data.Table[0].BENo);
                                $("#BEDate").val(obj.data.Table[0].BEDate);
                                Address
                                $("#VesselName").val(obj.data.Table[0].VesselName);
                                $("#PortLoading").val(obj.data.Table[0].PortLoading);
                                $("#ContainerTypeNo").val(obj.data.Table[0].ContainerTypeNo);
                                $("#ContainerType").val(obj.data.Table[0].ContainerType);
                                $("#TotalNetWeight").val(parseFloat(obj.data.Table[0].TotalNetWeight).toFixed(2));
                                $("#PortDischarge").val(obj.data.Table[0].PortDischarge);
                                $("#City").val(obj.data.Table[0].City);
                                $("#State").val(obj.data.Table[0].State);
                                $("#GSTNo").val(obj.data.Table[0].GSTNo);
                                $("#Address").val(obj.data.Table[0].Address);
                                $("#ClientState").val(obj.data.Table[0].ClientState);
                                $("#BranchState").val(obj.data.Table[0].BranchState);
                                $("#CancelBill").prop("checked", obj.data.Table[0].CancelBill);


                                $("#TotalAmount").html(obj.data.Table[0].TotalAmount.toFixed(2));
                                $("#RoundOff").html(obj.data.Table[0].RoundOff.toFixed(2));

                                $("#TotalTaxAmount").html(obj.data.Table[0].TaxAmount.toFixed(2));
                                $("#NetAmount").html(obj.data.Table[0].NetAmount.toFixed(2));

                                var BillList = obj.data.Table1;
                                var firstChild = $("#Bill_table").find("tbody tr:first-child");
                                $.each(BillList, function (index, ele) {
                                    if (index == 0) {
                                        selectedAccHead = ele.LedgerId;
                                        if (ele.SubgroupId == null) {
                                            firstChild.find('.GroupName').val('');
                                        }
                                        else {
                                            firstChild.find('.HiddenGroupId').val(ele.SubgroupId);
                                            firstChild.find('.GroupName').val(ele.SubgroupHeadName);
                                        }
                                        //firstChild.find(".TaxCategory").prop('disabled', 'disabled');
                                        firstChild.find('.AccountDesc').val(ele.AccHead);
                                        firstChild.find('.HiddenAccountDescId').val(ele.LedgerId);
                                        firstChild.find('.Particular').val(ele.Particular);
                                        firstChild.find('.JobNo').val(ele.JobNo);
                                        firstChild.find('.RecNo').val(ele.RecNo);
                                        firstChild.find('.RecDate').val(ele.RecDate == '01/01/1900' ? '' : ele.RecDate);
                                        firstChild.find('.Amount').val(ele.Amount.toFixed(2));
                                        firstChild.find('.TaxAmount').val(ele.TaxAmount.toFixed(2));
                                        firstChild.find('.TaxCategory').val(ele.TaxCategory);
                                        firstChild.find('.HiddenTaxPer').val(ele.TaxPercent);


                                    }
                                    else {
                                        firstChild.find('.RecDate').datepicker("destroy");
                                        firstChild.find('.RecDate').removeAttr("id");

                                        var cloneChild = firstChild.clone();
                                        cloneChild.find('.GroupName,.AccountDesc,.Particular,.JobNo,.RecNo,.RecDate,.HiddenGroupId,.HiddenAccountDescId,.isTaxable,.TaxPerLedger,.TaxAmount,.HiddenTaxPer').val('');
                                        cloneChild.find('.Amount').val('0.00');
                                        cloneChild.find('.TaxCategory').val('0');
                                        //cloneChild.find(".TaxCategory").prop('disabled', 'disabled');
                                        if (ele.SubgroupId == null) {
                                            cloneChild.find('.GroupName').val('');
                                        }
                                        else {
                                            cloneChild.find('.HiddenGroupId').val(ele.SubgroupId);
                                            cloneChild.find('.GroupName').val(ele.SubgroupHeadName);
                                        }

                                        cloneChild.find('.AccountDesc').val(ele.AccHead);
                                        cloneChild.find('.HiddenAccountDescId').val(ele.LedgerId);
                                        cloneChild.find('.isTaxable').val(ele.IsTaxable);
                                        cloneChild.find('.TaxPerLedger').val(ele.TaxLedgerPer);
                                        cloneChild.find('.Particular').val(ele.Particular);
                                        cloneChild.find('.JobNo').val(ele.JobNo);
                                        cloneChild.find('.RecNo').val(ele.RecNo);
                                        cloneChild.find('.RecDate').val(ele.RecDate == '01/01/1900' ? '' : ele.RecDate);
                                        cloneChild.find('.Amount').val(ele.Amount.toFixed(2));
                                        cloneChild.find('.TaxAmount').val(ele.TaxAmount.toFixed(2));
                                        cloneChild.find('.TaxCategory').val(ele.TaxCategory);
                                        cloneChild.find('.HiddenTaxPer').val(ele.TaxPercent);
                                        $("#Bill_table tbody").append(cloneChild);
                                    }
                                    $(".datepickerAll").datepicker({
                                        changeMonth: true,
                                        changeYear: true,
                                        dateFormat: 'dd/mm/yy'
                                    });
                                });


                                $("#NoGst").prop("checked", obj.data.Table[0].NoGST);
                                $("#NoGst").trigger('change');
                                $("#Bill_table tbody tr").each(function (index, ele) {
                                    //$(ele).find(".TaxCategory").attr("disabled", "disabled");
                                    $(ele).find(".TaxCategory").trigger('change');
                                });
                                if ($("#NoGst").is(":checked") == false) {
                                    AddTaxDetail(obj.data.Table2);
                                }
                                clearInterval(FillClientInfo);
                            }
                        }, 500);
                    }
                    if (GstCategory == "DBN") {
                        $("#RefInvoiceDate").val(obj.data.Table[0].BillDate);
                        $("#BranchId").val(obj.data.Table[0].BranchId);
                        Hclid = obj.data.Table[0].ClientId;
                        $("#JobNo").val(obj.data.Table[0].JobNo);
                        $("#JobDate").val(obj.data.Table[0].JobDate);
                        $("#HiddenClientId").val(obj.data.Table[0].ClientId);
                        SelectedLedgerBranch = obj.data.Table[0].LedgerBranch;
                        $("#ClientName").val(obj.data.Table[0].AccHead);
                        FillLedgerBranch();
                        let FillClientInfo = setTimeout(() => {
                            $("#LedgerBranchAddress").val(SelectedLedgerBranch);
                            $("#City").val(obj.data.Table[0].City);
                            $("#State").val(obj.data.Table[0].State);
                            $("#GSTNo").val(obj.data.Table[0].GSTNo);
                            $("#Address").val(obj.data.Table[0].Address);
                            $("#ClientState").val(obj.data.Table[0].ClientState);
                            $("#BranchState").val(obj.data.Table[0].BranchState);
                            var BillList = obj.data.Table1;
                            var firstChild = $("#Bill_table").find("tbody tr:first-child");
                            $.each(BillList, function (index, ele) {
                                if (index == 0) {
                                    selectedAccHead = ele.LedgerId;
                                    if (ele.SubgroupId == null) {
                                        firstChild.find('.GroupName').val('');
                                    }
                                    else {
                                        firstChild.find('.HiddenGroupId').val(ele.SubgroupId);
                                        firstChild.find('.GroupName').val(ele.SubgroupHeadName);
                                    }
                                    //firstChild.find(".TaxCategory").prop('disabled', 'disabled');
                                    firstChild.find('.AccountDesc').val(ele.AccHead);
                                    firstChild.find('.HiddenAccountDescId').val(ele.LedgerId);
                                    firstChild.find('.Particular').val(ele.Particular);
                                    //firstChild.find('.JobNo').val(ele.JobNo);
                                    firstChild.find('.RecNo').val(ele.RecNo);
                                    firstChild.find('.RecDate').val(ele.RecDate == '01/01/1900' ? '' : ele.RecDate);
                                    //firstChild.find('.Amount').val(ele.Amount.toFixed(2));
                                    //firstChild.find('.TaxAmount').val(ele.TaxAmount.toFixed(2));
                                    firstChild.find('.TaxCategory').val(ele.TaxCategory).trigger('change');
                                    firstChild.find('.HiddenTaxPer').val(ele.TaxPercent);


                                }
                                else {
                                    firstChild.find('.RecDate').datepicker("destroy");
                                    firstChild.find('.RecDate').removeAttr("id");

                                    var cloneChild = firstChild.clone();
                                    cloneChild.find('.GroupName,.AccountDesc,.Particular,.RecNo,.RecDate,.HiddenGroupId,.HiddenAccountDescId,.isTaxable,.TaxPerLedger,.TaxAmount,.HiddenTaxPer').val('');
                                    //cloneChild.find('.JobNo').val('');
                                    cloneChild.find('.Amount').val('0.00');
                                    cloneChild.find('.TaxCategory').val('0');
                                    //cloneChild.find(".TaxCategory").prop('disabled', 'disabled');
                                    if (ele.SubgroupId == null) {
                                        cloneChild.find('.GroupName').val('');
                                    }
                                    else {
                                        cloneChild.find('.HiddenGroupId').val(ele.SubgroupId);
                                        cloneChild.find('.GroupName').val(ele.SubgroupHeadName);
                                    }

                                    cloneChild.find('.AccountDesc').val(ele.AccHead);
                                    cloneChild.find('.HiddenAccountDescId').val(ele.LedgerId);
                                    cloneChild.find('.isTaxable').val(ele.IsTaxable);
                                    cloneChild.find('.TaxPerLedger').val(ele.TaxLedgerPer);
                                    cloneChild.find('.Particular').val(ele.Particular);
                                    //cloneChild.find('.JobNo').val(ele.JobNo);
                                    cloneChild.find('.RecNo').val(ele.RecNo);
                                    cloneChild.find('.RecDate').val(ele.RecDate == '01/01/1900' ? '' : ele.RecDate);
                                    //cloneChild.find('.Amount').val(ele.Amount.toFixed(2));
                                    //cloneChild.find('.TaxAmount').val(ele.TaxAmount.toFixed(2));
                                    cloneChild.find('.TaxCategory').val(ele.TaxCategory).trigger('change');
                                    cloneChild.find('.HiddenTaxPer').val(ele.TaxPercent);
                                    $("#Bill_table tbody").append(cloneChild);
                                }
                                $("#Bill_table tbody tr").each(function (index, ele) {
                                    //$(ele).find(".TaxCategory").attr("disabled", "disabled");
                                    $(ele).find(".TaxCategory").trigger('change');
                                });
                                $(".datepickerAll").datepicker({
                                    changeMonth: true,
                                    changeYear: true,
                                    dateFormat: 'dd/mm/yy'
                                });
                            });
                        }, 500);
                    }
                    hiddenJobNo = $("#HiddenJobNo").val().trim();
                    HiddenClientId = $("#HiddenClientId").val().trim();
                    hiddenInvoiceId = $("#HiddenRefInvoiceNo").val().trim();
                    //hiddenInvoiceId = $("#HiddenRefInvoiceNo").val().trim();
                }
                else {
                    Toast(RetrieveMessage(obj.responsecode), "Message", "error");
                }
            }
            else {
                window.location.href = '/ClientLogin/ClientLogin';
            }
            //Hideloader();
        }).fail(function (result) {
            console.log(result.Message);
            //Hideloader();
        });
    }
    catch (e) {
        console.log(e.message);
    }
}

// REFERENCE INVOICE NO ON INPUT EVENT
$("#RefInvoiceNo").on('input', function () {
    $("#HiddenRefInvoiceNo").val('');
})

// REFERENCE INVOICE NO ON BLUR EVENT
$("#RefInvoiceNo").blur(function () {
    if (hiddenInvoiceId != $("#HiddenRefInvoiceNo").val().trim()) {
        if ($("#HiddenRefInvoiceNo").val().trim().length > 0) {
            GetInvoiceData();
        }
        else {
            $("#RefInvoiceNo").val('');
            ResetInvoiceData();
            hiddenJobNo = '';
            HiddenClientId = '';
            hiddenInvoiceId = '';
        }
    }
});
// FUNCTION TO RESET REFERENCE INVOICE DATA
function ResetInvoiceData(GstCategory) {
    //hiddenJobNo = '';
    //HiddenClientId = '';
    //hiddenInvoiceId = '';
    $("#RefInvoiceDate").val('');
    if (GstCategory != 'DBN') {
        $("#JobNo,#HiddenJobNo,#JobDate").val('');
    }
    $("#BENo,#BEDate,#VesselName,#PortLoading,#ContainerTypeNo,#ContainerType,#TotalNetWeight,#PortDischarge,#HiddenClientId,#ClientName,#City,#State,#GSTNo,#Address,#ClientState,#BranchState").val('');
    $("#LedgerBranchAddress,#TotalAmount,#RoundOff,#TotalTaxAmount,#NetAmount").html('');
    $("#CancelBill").prop("checked", false);
    $("#TaxDetails tbody tr").remove();
    var tbody = $("#Bill_table").find("tbody");
    var Tr = $(tbody).find("tr");

    var rowCount = Tr.length;
    if (rowCount > 1) {
        $("#Bill_table tbody tr").each(function (index, ele) {
            if (index > 0) {
                $(ele).remove();
            }
            else {
                $(ele).find(".HiddenGroupId,.GroupName,.AccountDesc,.TaxAmount,.HiddenTaxPer,.HiddenAccountDescId,.Particular,.RecNo,.BillNoUniqueId").val('');
                $(ele).find(".RecDate").val(NewDate);
                $(ele).find(".Amount").val('0.00');
                $(ele).find(".TaxCategory").val('0');
                $(ele).find(".TaxCategory").removeAttr("disabled");
                $("#Bill_table").find("tbody").append(ele);
            }
        });

    }
    else {
        Tr.find(".HiddenGroupId,.GroupName,.AccountDesc,.TaxAmount,.HiddenTaxPer,.HiddenAccountDescId,.Particular,.RecNo,.BillNoUniqueId").val('');
        Tr.find(".RecDate").val(NewDate);

        Tr.find(".Amount").val('0.00');
        Tr.find(".TaxCategory").val('0');
        Tr.find(".TaxCategory").removeAttr("disabled");
        $("#Bill_table").find("tbody").append(Tr);
    }
}
//AUTOCOMPLETE ACC HEAD IN ADD MORE 
function AutocompleteLedger(e) {

    var whereConditionVal = $(e).parents('tr').find('.HiddenGroupId').val();
    var CurrentId = $(e).attr('id');
    AutoCompleteAjaxWithClassWithColumn(CurrentId, "/Master/BillEntry/GetAccountDesc", "HiddenAccountDescId", whereConditionVal);
}

function AutoCompleteGroupName(e) {
    var CurrentId = $(e).attr('id');
    AutocompleteForGroupName(CurrentId, '/Master/BillEntry/GetGroupName', 'HiddenGroupId', 'AccountDesc', 'HiddenAccountDescId');

}

function ResetHiddenGroup(e) {
    /* var CurrentId = $(e).attr('id');*/
    var parentTr = $(e).parents('tr');
    parentTr.find('.HiddenGroupId').val('');
}

function AutocompleteForGroupName(className, PageUrl, HiddenId, CheckId, HiddenCheckId) {
    $("." + className).autocomplete({
        source: function (request, response) {
            $.ajax({
                type: 'POST',
                url: PageUrl,
                dataType: "json",
                async: false,
                data: { SearchField: request.term },
                success: function (result) {
                    if (result.status == true) {
                        if (result.responsecode == '100') {
                            response($.map(result.data.Table, function (item, id) {
                                return {
                                    label: item.name,
                                    value: item.name,
                                    id: item.id,
                                };
                            }));
                        }
                    }
                    else {
                        window.location.href = '/ClientLogin/ClientLogin';
                    }
                }
            });
        },
        minLength: 1,
        selectFirst: true,
        selectOnly: true,
        autoFocus: true,
        select: function (e, i) {
            var parentTr = $(this).parents('tr');
            parentTr.find("." + HiddenId).val(i.item.id);
        },
        change: function (e, i) {
            var parentTr = $(this).parents('tr');

            if (i.item == null || i.item == undefined) {

                if (parentTr.find("." + HiddenCheckId).val().trim().length <= 0) {
                    parentTr.find("." + HiddenId).val('');
                }

            } else {
                parentTr.find("." + HiddenCheckId).val('');
                parentTr.find("." + CheckId).val('');
            }

        }

    });
}
//FUNCTION FOR JOB NUMBER AUTOCOMPLETE AJAX WITH ID
function JobNoAutoCompleteAjax(id, Url, HiddenId, SubJob, JobFrm, JobTo) {

    $("#" + id).autocomplete({
        source: function (request, response) {
            AjaxSubmissionAutocomplete(JSON.stringify({ SearchField: request.term, SubJobNo: $("#" + SubJob).val(), JobDateFrom: $("#" + JobFrm).val(), JobDateTo: $("#" + JobTo).val(), BillType: $("#BillType").val() }), Url, $('input[name=__RequestVerificationToken]').val()).done(function (result) {
                let obj = result;
                if (obj.status == true) {
                    if (obj.responsecode == '100') {
                        response($.map(result.data.Table, function (item, id) {
                            return {
                                label: item.name,
                                value: item.name,
                                id: item.id
                            };
                        }));
                    }
                }
                else
                    window.location.href = '/ClientLogin/ClientLogin';
                //Hideloader();
            }).fail(function (result) {
                //Hideloader();
                console.log(result.Message);
            });
        },

        autoFocus: true,
        minLength: 1,
        selectFirst: true,
        selectOnly: true,
        select: function (e, i) {
            $("#" + HiddenId).val(i.item.id);

        },
        change: function (e, i) {
            if (i.item == null || i.item == undefined) {
                $("#" + id).val('');
                $("#" + HiddenId).val('');
            }
        }, open: function () {
            $("ul.ui-menu").css({
                'overflow-y': 'scroll',
                'overflow-x': 'hidden',
                'max-height': '200px'
            });
        }
    });
}
//$(".GroupName").blur(function () {

//    console.log($(".HiddenGroupId").val());
//    if ($(".HiddenGroupId").val() == '') {

//        $(".AccountDesc").val('');        
//        $(".HiddenAccountDescId").val('');

//    }
//});
//$(".GroupName").on('input', function () {
//    $(".HiddenGroupId").val('');
//});

document.addEventListener("keydown", function (zEvent) {
    if (zEvent.ctrlKey && zEvent.altKey && (zEvent.key == "j" || zEvent.key == "J")) {  // case sensitive      
        $('#BillEntry_List-tab').removeClass('active ');
        $('#BillEntry_List').removeClass('active show');
        $('#BillEntry-tab').addClass('active');
        $('#BillEntry').addClass('active show');
        $("#FormAdd").show();
        $("#FormUpdate").hide();
        $("#FormReset").hide();
        $("#BillEntry-tab").html("Add Bill Entry");
        ResetForm();
        $('#BillType').focus();
    }
});
$("#BillEntry-tab").click(function () {
    $("#BillEntryHeader").text('Bill Entry');
    CanChangeTaxInInvoice();
})
// FUNCTION TO CANCEL IRN 
function CancelIRN() {
    try {
        const datastring = {};
        datastring.BillUid = $("#BillId").val();
        AjaxSubmission(JSON.stringify(datastring), "/Master/BillEntry/CancelIRN", $('[name="__RequestVerificationToken"]').val()).done(function (data) {
            let obj = data;

            if (obj.status == true) {
                if (obj.responsecode == '100') {
                    Toast(RetrieveMessage(obj.responsecode), "Message", "success");
                }
                else if (obj.responsecode == '1042') {
                    Toast(obj.error, "Message", "error", 2500);
                }
                else {
                    Toast(RetrieveMessage(obj.responsecode), "Message", "error");
                }

            }
            else {
                window.location.href = '/ClientLogin/ClientLogin';
            }
        }).fail(function (data) {
            console.log(data.Message);
        });
    }
    catch (e) {
        console.log(e.message);
    }
}

// FUNCTION TO GET IRN 
function GetIRN() {
    try {
        const datastring = {};
        datastring.BillUid = $("#BillId").val();
        AjaxSubmission(JSON.stringify(datastring), "/Master/BillEntry/GetIRN", $('[name="__RequestVerificationToken"]').val()).done(function (data) {
            let obj = data;

            if (obj.status == true) {
                if (obj.responsecode == '100') {
                    Toast(RetrieveMessage(obj.responsecode), "Message", "success");
                }
                else if (obj.responsecode == '1042') {
                    Toast(obj.error, "Message", "error", 2500);
                }
                else {
                    Toast(RetrieveMessage(obj.responsecode), "Message", "error");
                }

            }
            else {
                window.location.href = '/ClientLogin/ClientLogin';
            }
        }).fail(function (data) {
            console.log(data.Message);
        });
    }
    catch (e) {
        console.log(e.message);
    }
}
// FUNCTION TO GET E INVOICE
function EInvoice() {
    try {
        const datastring = {};
        datastring.BillUid = $("#BillId").val();

        AjaxSubmission(JSON.stringify(datastring), "/Master/BillEntry/EInvoice", $('[name="__RequestVerificationToken"]').val()).done(function (data) {
            let obj = data;

            if (obj.status == true) {
                if (obj.responsecode == '100') {
                    Toast(RetrieveMessage(obj.responsecode), "Message", "success");
                }
                else if (obj.responsecode == '1042') {
                    Toast(obj.error, "Message", "error", 2500);
                }
                else {
                    Toast(RetrieveMessage(obj.responsecode), "Message", "error");
                }

            }
            else {
                window.location.href = '/ClientLogin/ClientLogin';
            }
        }).fail(function (data) {
            console.log(data.Message);
        });
    }
    catch (e) {
        console.log(e.message);
    }
}
// FUNCTION TO GET JSON FILE 
function GetJSONFile() {
    try {
        const datastring = {};
        datastring.BillUid = $("#BillId").val();

        AjaxSubmission(JSON.stringify(datastring), "/Master/BillEntry/GetJSONFile", $('[name="__RequestVerificationToken"]').val()).done(function (data) {
            let obj = data;

            if (obj.status == true) {
                if (obj.responsecode == '100') {
                    Toast('Json File Saved Successfully.', "Message", "success");
                    setTimeout(() => {
                        DownLoadJSONFile($("#BillId").val());
                    }, 1000);
                }
                else if (obj.responsecode == '1042') {
                    Toast(obj.error, "Message", "error", 2500);
                }
                else {
                    Toast(RetrieveMessage(obj.responsecode), "Message", "error");
                }

            }
            else {
                window.location.href = '/ClientLogin/ClientLogin';
            }
        }).fail(function (data) {
            console.log(data.Message);
        });
    }
    catch (e) {
        console.log(e.message);
    }
}
//POPUP FOR JSON FILE DOWNLOAD
function DownLoadJSONFile(FileName) {
    try {

        $.confirm({
            title: '',
            content: 'Download Json File ?',
            type: 'green',
            boxWidth: '300px',
            useBootstrap: false,
            typeAnimated: true,
            columnClass: 'small',
            containerFluid: true,
            draggable: true,
            buttons: {
                tryAgain: {
                    text: 'Confirm',
                    btnClass: 'btn-green',
                    action: function () {

                        const dataString = {};
                        dataString.FileName = FileName;

                        AjaxSubmission(JSON.stringify(dataString), "/BillEntry/DownLoadJSONFile", $('[name="__RequestVerificationToken"]').val()).done(function (data) {
                            let obj = data;
                            if (obj.status == true) {
                                if (obj.responsecode == '100') {
                                    var bytes = Base64ToBytes(obj.data[0].RawData);
                                    var Ext = obj.data[0].FileExt;

                                    //Convert Byte Array to BLOB.
                                    var blob = new Blob([bytes], { type: "application/octetstream" });

                                    //Check the Browser type and download the File.
                                    var isIE = false || !!document.documentMode;
                                    if (isIE) {
                                        window.navigator.msSaveBlob(blob, FileName + Ext);
                                    } else {
                                        var url = window.URL || window.webkitURL;
                                        link = url.createObjectURL(blob);
                                        var a = $("<a />");
                                        a.attr("download", FileName + Ext);
                                        a.attr("href", link);
                                        $("body").append(a);
                                        a[0].click();
                                        $("body").remove(a);
                                    }
                                }
                            }
                            else
                                window.location.href = '/ClientLogin/ClientLogin';
                            //Hideloader();
                        }).fail(function (data) {
                            console.log(data.Message);
                            //Hideloader();
                        });
                    }
                },
                close: function () {

                }
            }
        });

    }
    catch (e) {
        console.log(e.message);
        //Hideloader();
    }
}

//FUNCTION FOR CONVERT BASE64 TO BYTES
function Base64ToBytes(base64) {
    var s = window.atob(base64);
    var bytes = new Uint8Array(s.length);
    for (var i = 0; i < s.length; i++) {
        bytes[i] = s.charCodeAt(i);
    }
    return bytes;
};

//FUNCTION FOR BIND INVOICE TYPE 
function CanChangeTaxInInvoice() {
    try {
        AjaxSubmission(null, "/Master/BillEntry/CanChangeTaxInInvoice", $('input[name=__RequestVerificationToken]').val()).done(function (result) {
            let obj = result;

            if (obj.status == true) {
                if (obj.responsecode == '100') {
                    $("#CanChangeTax").val(obj.data[0].allow_change_in_tax);
                    if ($("#CanChangeTax").val() == "false") {
                        $("#Bill_table tbody tr").each(function (index, ele) {
                            //$(ele).find(".TaxCategory").attr('disabled', 'disabled');
                        });
                    }
                }
                else {
                    Toast(RetrieveMessage(obj.responsecode), "Message", "error");
                }
            }
            else {
                window.location.href = '/ClientLogin/ClientLogin';
            }
            HideLoader();
        }).fail(function (result) {
            console.log(result.Message);
            //HideLoader();
        });
    }
    catch (e) {
        console.log(e.message);
        //HideLoader();
    }
}

//VALIDATION FOR ADD OR UPDATE THE Bill ENTRY
function BillAddUpdateValidation() {

    if ($("#BranchId").val() == "0") {
        Toast(RetrieveMessage(910), 'Message', 'error');
        $("#BranchId").focus();
        flag = 1;
        return;
    }
    if ($("#InvoiceType").val() == "0") {
        Toast('Please Select Invoice Type !', 'Message', 'error');
        $("#InvoiceType").focus();
        flag = 1;
        return;
    }
    if ($("#SubBillNo").val().length == 0) {
        $("#SubBillNo").focus();
        Toast("Sub Bill No Can't  Be Blank !", 'Message', 'error');
        flag = 1;
        return;
    }

    if ($("#BillNo").val().length == 0) {
        Toast("Bill No Can't  Be Blank !", 'Message', 'error');
        flag = 1;
        return;
    }
    if ($("#BillNo").val().length > 16) {
        Toast("Bill No Max Length Is 16 Digits !", 'Message', 'error');
        flag = 1;
        return;
    }
    if ($("#BillDate").val() == "") {
        $("#BillDate").focus();
        Toast("Please Select Bill Date !", 'Message', 'error');
        flag = 1;
        return;
    }
    //if ($("#GstInvoiceCategory").val() == "CRN" || $("#GstInvoiceCategory").val() == "DBN") {
    if ($("#GstInvoiceCategory").val() == "CRN") {
        if ($("#RefInvoiceNo").val().length == 0) {
            $("#RefInvoiceNo").focus();
            Toast("Please Enter Reference No !", 'Message', 'error');
            flag = 1;
            return;
        }
        if ($("#RefInvoiceDate").val().length == 0) {
            $("#RefInvoiceDate").focus();
            Toast("Please Enter Reference Date !", 'Message', 'error');
            flag = 1;
            return;
        }
    }
    if ($("#GstInvoiceCategory").val().length == 0) {
        if ($("#HiddenJobNo").val().length == 0) {
            $("#JobNo").focus();
            Toast("Job No Can't  Be Blank !", 'Message', 'error');
            flag = 1;
            return;
        }
    }
    if ($("#HiddenClientId").val().length == 0) {
        Toast("Please Enter Client Name !", 'Message', 'error');
        $("#ClientName").focus();
        flag = 1;
        return;
    }
    if ($("#ClientName").val().length == 0) {
        $("#ClientName").focus();
        Toast("Please Enter Client Name !", 'Message', 'error');
        flag = 1;
        return;
    }
    //if ($("#LedgerBranchAddress").val() == "0") {
    //    Toast(RetrieveMessage(912), 'Message', 'error');
    //    return;
    //}
    if ($("#Address").val().length == 0) {
        $("#Address").focus();
        Toast("Please Enter Address !", 'Message', 'error');
        flag = 1;
        return;
    }
    $("#Bill_table tbody tr").each(function (index, ele) {
        //if ($(ele).find('.HiddenGroupId').val().length == 0) {
        //    $(ele).find('.GroupName').focus();
        //    Toast(RetrieveMessage(805), 'Message', 'error');
        //    flag = 1;
        //    return false;
        //}
        if ($(ele).find('.HiddenAccountDescId').val().length == 0) {
            $(ele).find('.AccountDesc').focus();
            Toast(RetrieveMessage(913), 'Message', 'error');
            flag = 1;
            return false;
        }
        if ($(ele).find('.Amount').val() == '0.00') {
            $(ele).find('.Amount').focus();
            Toast("Please Fill Amount !", 'Message', 'error');
            flag = 1;
            return false;
        }
    });
}

