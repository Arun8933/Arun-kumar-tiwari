﻿var srbtn = 'up';
var DateFrom = "";
var DateTo = "";
var LedgerId = "";
var sel = "";
//DOCUMNET READY


$(document).ready(function () {
    GetFinancialYearDate();
    FillBankNameLedger('BankName');

    //DATEPICKER FOR SEARCHJOBDATEFROM AND SEARCHJOBDATETO
    $('#FromDate,#ToDate').datepicker({
        toolbarPlacement: "bottom",
        showButtonPanel: true,
        changeMonth: true,
        changeYear: true,
        dateFormat: 'dd/mm/yy',
        onClose: function () {
            if ($('#FromDate').val().length == 10 || $('#ToDate').val().length == 10)
                CompareSearchDate($('#FromDate').val(), $('#ToDate').val(), '');
        }
    });

    $(".datepickerAll").datepicker({
        changeMonth: true,
        changeYear: true,
        dateFormat: 'dd/mm/yy'
    });
});
$("#BankName").select2({
    width: '100%'
});

//FUNCTION FOR GET FINANCIAL YEAR DATE
function GetFinancialYearDate() {
    try {
        AjaxSubmission(null, '/_Layout/GetFinancialYearDate', $('[name="__RequestVerificationToken"]').val()).done(function (result) {
            let obj = result;
            if (obj.status == true) {
                if (obj.responsecode == '100') {
                    $("#FromDate").val(obj.data.Table[0].finyr_start_date);
                    $("#ToDate").val(obj.data.Table[0].finyr_end_date);
                }
            }
            else
                window.location.href = '/ClientLogin/ClientLogin';
            HideLoader();
        }).fail(function (result) {
            HideLoader();
            console.log(result.message);
        });
        HideLoader();
    }
    catch (e) {
        HideLoader();
        console.log(e.message);
    }
}


function FillBankNameLedger(DrpID) {
    try {
        //Showloader();
        AjaxSubmission(null, "/BankReconciliation/FillBankNameLedger", $('input[name=__RequestVerificationToken]').val()).done(function (data) {
            let obj = data;
            if (obj.status == true) {
                if (obj.responsecode == '100')
                    BindDropdown(obj.data.Table, DrpID, 'LedgerUid', 'AccHead', '---Select---');
                else if (obj.responsecode == '100')
                    BindDropdown(obj.data.Table, DrpID, 'LedgerUid', 'AccHead', '---Select---');
                else
                    Toast(RetrieveMessage(obj.responsecode), "Message", "error");
            }
            else
                window.location.href = '/ClientLogin/ClientLogin';
        }).fail(function (result) {
            console.log(result.Message);
        });
    }
    catch (e) {
        console.log(e.message);
    }
}


$("#FormSearch").click(function () {
    var FromDate = $("#FromDate").val();
    var ToDate = $("#ToDate").val();
    var flag = 0;
    if ($("#BankName").val() == "0") {
        Toast("Please Select BankName !", 'Message', 'error');
        flag = 1;
        return false;
    }
    if (FromDate == "") {
        Toast("Please Enter Date From", "Message", "error");
        flag = 1;
        return false;
    }
    if (ToDate == "") {
        Toast("Please Enter Date To", "Message", "error");
        flag = 1;
        return false;
    }
    if (FromDate >= ToDate) {
        Toast("To Date Must Be Greater Than From Date*", "Message", "error");
        flag = 1;
        return false;
    }
    else {
        $(".ReportDNone").show();
        FormList();
        $("#ReconsileDate").val('');
    }
});

//BANK RECONCILIATION MASTER LIST FUNCTION
function FormList() {
    try {
        const dataString = {};
        dataString.BankName = parseInt($("#BankName").val());
        dataString.ChqNo = $("#ChqNo").val();
        dataString.FromDate = $("#FromDate").val();
        dataString.ToDate = $("#ToDate").val();
        ShowLoader();
        AjaxSubmission(JSON.stringify(dataString), "/Master/BankReconciliation/FormList", $('input[name=__RequestVerificationToken]').val()).done(function (result) {
            let obj = result;
            console.log(obj);
            if (obj.status == true) {
                if (obj.responsecode == '100') {
                    BindFormTable(obj.data.Table);
                }
                else
                    Toast(RetrieveMessage(obj.responsecode), "Message", "error");
            }
            else
                window.location.href = '/ClientLogin/ClientLogin';
            HideLoader();
        }).fail(function (result) {
            console.log(result.Message);
            HideLoader();
        });
    }
    catch (e) {
        console.log(e.message);
        HideLoader();
    }
}

//FUNCTION FOR BIND BANK RECONCILIATION LIST TABLE
function BindFormTable(Result) {
    $("#tbl_BankReconciliation tbody tr").remove();
    if (Result.length == 0) {
        tr = $('<tr/>');
        tr.append("<td class='text-center' colspan='8'>NO RESULTS FOUND</td>");
        $("#tbl_BankReconciliation tbody").append(tr);
    }
    else {
        for (i = 0; i < Result.length; i++) {
            tr = $('<tr/>');
            tr.append("<td class='text-center'>" + (i + 1) + " </td>")
            tr.append("<td class='text-center '><span class='DocNo'>" + Result[i].DocNo + "</span></td>")
            tr.append("<td class='text-center '><span class='Date'>" + Result[i].Date + "</span></td>")
            tr.append("<td class='text-center'> " + Result[i].ChequeNo + "</td>")
            tr.append("<td class='text-center'> " + Result[i].AccDescription + "</td>")
            tr.append("<td class='text-center'> " + Result[i].RefDescription + "</td>")
            tr.append("<td class='text-end'> " + Result[i].Amount.toFixed(2) + "</td>")
            tr.append("<td class='text-center'> " + Result[i].Type + "</td>")
            tr.append("<td class='text-end ' > <input type='text' id='ReconDate' name='ReconDate' class='ReconDate datepickerAll1 form-control form-control-md textbox-height mybox' placeholder='dd/mm/yyyy' maxlength='10' /></td>")
            $("#tbl_BankReconciliation tbody").append(tr);
        }
        $(".datepickerAll1").datepicker({
            changeMonth: true,
            changeYear: true,
            dateFormat: 'dd/mm/yy'
        });
    }
}

// ON CHANGE FUNCTION FOR CHANGE RECONSILE DATE
function AutoFillReconsileDate() {
    var inputField = $("#ReconsileDate").val();

    $('#tbl_BankReconciliation tbody tr').each(function (index, ele) {
        $(ele).find('.ReconDate').val(inputField);
    });
}

//FUNCTION FOR UPDATE RECONSILE DATE BY VOUCHER DATE
function UpdateReconsileDateByVoucherDate() {
    $('#tbl_BankReconciliation tbody tr').each(function (index, ele) {
        var inputField = $(ele).find('.Date').html();
        $(ele).find('.ReconDate').val(inputField);
    });
}

//FUNCTION FOR UPDATE RECONSILE DATE IN TRANSACTION
function UpdateReconsileDate() {
    try {
        const dataString = {};
        var BankReconciliationData = new Array();
        $('#tbl_BankReconciliation tbody tr').each(function (index, ele) {
            var BankReconciliation = {};
            var DocNo = $(ele).find('.DocNo').html();
            var Date = $(ele).find('.ReconDate').val();
            if ((DocNo.length > 0) && (Date.length == 10)) {
                BankReconciliation.DocNo = DocNo
                BankReconciliation.Date = Date;
                BankReconciliationData.push(BankReconciliation);
            }
        });
        dataString.BankReconciliationModels = BankReconciliationData;
        console.log(JSON.stringify(dataString));
        AjaxSubmission(JSON.stringify(dataString), "/BankReconciliation/UpdateReconsileDate", $('[name="__RequestVerificationToken"]').val()).done(function (data) {
            let obj = data;
            if (obj.status == true) {
                if (obj.responsecode == '107') {
                    Toast(RetrieveMessage(107), 'message', 'success');
                }
                else {
                    Toast(RetrieveMessage(obj.responsecode), "Message", "error");
                }
            }
            else
                window.location.href = '/ClientLogin/ClientLogin';
        }).fail(function (data) {
            console.log(data.Message);
        });
    }
    catch (e) {
        console.log(e.message);
    }
}
