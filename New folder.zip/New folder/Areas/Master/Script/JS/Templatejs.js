﻿var Firstcolumn = "";
var newtempid = "";


// DOCUMENT READY
$(document).ready(function () {
    Firstcolumn = "Template_Name";
    FillTemplateShortcut();
    FillPageSizeList('ddlPageSize', FormList);
    LoadTinyMCE();   
});
// PAGINATION BUTTON CLICKED
$(document).on("click", ".pagination .page", function () {
    FormList(($(this).attr('page')));
});

//PAGE SIZE CHANGE
$("#ddlPageSize").change(function () {
    FormList(1);
});

//TEMPLATE TYPE SEARCH SELECT 2
$("#TemplateTypeSearch").select2({
    width: '100%'
});

//TEMPLATE STATUS SEARCH SELECT 2
$("#TemplateStatusSearch").select2({
    width: '100%'
});

//TEMPLATE STATUS  SELECT 2
$("#TemplateStatus").select2({
    width: '100%'
});


//TEMPLATETYPE SELECT 2
$("#TemplateType").select2({
    width: '100%'
});


//FORMSEARCH BUTTON CLICK 
$("#FormSearch").click(function () {
    FormList(1);
});

//FUNCTION FOR GET TEMPLATE SHORTCUT IN SMS/EMAIL
function GrabValue(e) {
    if ($("#TemplateType").val() != null) {
        var fgkrt = $("#TemplateType").val();
        var columnname = $(e).html();
        var discolname = [];
        if (columnname.includes("{{")) {
            discolname = columnname.split("{{");
            discolname[1] = "{{" + discolname[1];
        }
        else {
            discolname = columnname.split("##");
            discolname[1] = "##" + discolname[1] + "##";
        }
        if (fgkrt == 1) {
            var curPos = document.getElementById("TemplateSMSBody").selectionStart;
            let x = $("#TemplateSMSBody").val();
            $("#TemplateSMSBody").val(x.slice(0, curPos) + discolname[1] + x.slice(curPos));
        }
        else {
            tinyMCE.get('TemplateEmailBody').execCommand('mceInsertContent', true, discolname[1])
        }
    }

}

//FUNCTION FOR FILL TEMPLATE SHORTCUT
function FillTemplateShortcut() {
    try {
        AjaxSubmissionformdata(null, "/Template/GetTemplateShortcut", $('[name="__RequestVerificationToken"]').val()).done(function (result) {
            let obj = result;           
            if (obj.status == true) {
                let divac = "";
                let head = "";
                let btn = "";
                let dv = "";
                let p = "";
                if (obj.responsecode == '100') {
                    for (i = 0; i < obj.data.Table.length; i++) {
                        divac += "<div class='accordion-item'>";
                        head += "<h2 class='accordion-header' id='head" + obj.data.Table[i].TableName.replaceAll(" ","") + "' style='background-color:#86aedf !important'>";
                        btn += "<button class='accordion-button collapsed' type='button' data-bs-toggle='collapse' data-bs-target='#coll" + obj.data.Table[i].TableName.replaceAll(" ", "") + "' aria-expanded='true' aria-controls='Coll" + obj.data.Table[i].TableName.replaceAll(" ", "") + "' style='font - size: 18px!important; font - style: inherit!important'>" + obj.data.Table[i].TableName.replaceAll(" ", "") + "</button ></h2>";
                        dv += "<div id='coll" + obj.data.Table[i].TableName.replaceAll(" ", "") + "' class='accordion-collapse collapse ' aria-labelledby='head" + obj.data.Table[i].TableName.replaceAll(" ", "") + "' data-bs-parent='#accordionExample'>";
                        p += "";
                        for (j = 0; j < obj.data.Table1.length; j++) {
                            if (obj.data.Table[i].AssignTableUid == obj.data.Table1[j].AssignTableUid) {
                                p += "<p class='accordion-body' style='cursor:pointer;font - size: 8px!important; font - style: inherit!important' onclick='GrabValue(this)'>" + obj.data.Table1[j].ParameterName + ' ' + '  -  ' + ' ' + HandleNullTextValue(obj.data.Table1[j].ParameterDisplayName) + "</p>";
                            }
                        }
                        $("#accordionExample").html($("#accordionExample").html() + divac + head + btn + dv + p + "</div></div>");
                        divac = "";
                        head = "";
                        btn = "";
                        dv = "";
                        p = "";
                    }
                }
                else
                    Toast(RetrieveMessage(obj.responsecode), "Message", "error");
            }
            else
                window.location.href = '/ClientLogin/ClientLogin';          
        }).fail(function (result) {
            console.log(result.Message);           
        });
    }
    catch (ex) {
        console.log(ex.message);       
    }
}
alert('Prince');
//FUNCTION FOR EXPORT DATA IN EXCEL
function FormExcel() {
    ShowLoader();
    let date = new Date();
    let NewDate = ("00" + date.getDate()).slice(-2) + "_" + ("00" + (date.getMonth() + 1)).slice(-2) + "_" + date.getFullYear() + "_" + ("00" + date.getHours()).slice(-2) + "_" + ("00" + date.getMinutes()).slice(-2) + "_" + ("00" + date.getSeconds()).slice(-2);
    let fileName = "Template_" + NewDate + ".xlsx";

    $('#FormSearch').trigger('click');
    AjaxSubmission(null, '/Master/Template/FormExcel', $('input[name=__RequestVerificationToken]').val()).done(function (result) {
        let obj = result;
        if (obj.status == true) {
            if (obj.responsecode == '100') {

                let bytes = Base64ToBytes(obj.data.FileData[0].Base64Data);
                let blob = new Blob([bytes], { type: "application/octetstream" });
                let isIE = false || !!document.documentMode;
                if (isIE) {
                    window.navigator.msSaveBlob(blob, fileName);
                } else {
                    let url = window.URL || window.webkitURL;
                    link = url.createObjectURL(blob);
                    let a = $("<a />");
                    a.attr("download", fileName);
                    a.attr("href", link);
                    $("body").append(a);
                    a[0].click();
                    $("body").remove(a);
                }
            }
            else if (obj.responsecode == '302')
                Toast("No Records found.", 'Message', 'success');
            else
                Toast(RetrieveMessage(obj.responsecode), 'Message', 'error');

        } else
            window.location.href = '/ClientLogin/ClientLogin';
        HideLoader();

    }).fail(function (result) {
        console.log(result.Message);
        HideLoader();
    });
}

//FUNCTION FOR GET FORM LIST DATA
function FormList(pageindex) {
    try {
        const dataString = {};
        dataString.PageSize = $("#ddlPageSize").val();
        dataString.PageIndex = pageindex;
        dataString.TemplateUid = $("#TemplateUidSearch").val().trim();
        dataString.TemplateName = $("#TemplateNameSearch").val().trim();
        dataString.TemplateType = $("#TemplateTypeSearch").val();
        dataString.Status = $("#TemplateStatusSearch").val();
        dataString.OrderBy = $("#sort-column").val().trim() + " " + $("#sort-type").val().trim();        
        AjaxSubmission(JSON.stringify(dataString), "/Master/Template/FormList", $('input[name=__RequestVerificationToken]').val()).done(function (result) {
            let obj = result;
            if (obj.status == true) {
                if (obj.responsecode == '100') {                   
                    var ser = ((parseInt(obj.data.Table1[0].PageIndex) - 1) * parseInt(obj.data.Table1[0].PageSize)) + 1;
                    BindFormTable(obj.data.Table, ser);
                    if (obj.data.Table1 != undefined && obj.data.Table1.length > 0) {
                        $(".pagination").BindPaging({
                            ActiveCssClass: "current",
                            PagerCssClass: "pager",
                            PageIndex: parseInt(obj.data.Table1[0].PageIndex),
                            PageSize: parseInt(obj.data.Table1[0].PageSize),
                            RecordCount: parseInt(obj.data.Table1[0].count)
                        });
                    }
                }
                else 
                    Toast(RetrieveMessage(obj.responsecode), "Message", "error");
            }
            else
                window.location.href = '/ClientLogin/ClientLogin';
           
        }).fail(function (result) {
            console.log(result.Message);         
        });
    }
    catch (e) {
        console.log(e.message);       
    }
};

//FUNCTION FOR FORM SORTING
function FormSorting(obj) {
    if (Firstcolumn != "") {
        document.getElementById(Firstcolumn).innerHTML = document.getElementById(Firstcolumn).getAttribute("data-column") + " <i class='fa-solid fa-sort'></i>";
    }
    let cn = obj.id;
    Firstcolumn = cn;
    var colname = $(obj).data("column");
    $("#sort-column").val(cn.replaceAll("_", ""));
    var sorttype = $("#sort-type").val();
    if (sorttype == "ASC") {
        $("#sort-type").val("DESC");
        $(obj).html(colname + " <i style='margin-left:10px;' class='fa-solid fa-sort-down'></i>");
    } else if (sorttype == "DESC") {
        $("#sort-type").val("ASC");
        $(obj).html(colname + " <i style='margin-left:10px;' class='fa-solid fa-sort-up'></i>");
    }
    FormList(1);
}

//FUNCTION  FOR BIND FORM TABLE
function BindFormTable(Result, SerialNo) {
    $("#TblTemplate tbody tr").remove();
    if (Result.length == 0) {
        tr = $('<tr/>');
        tr.append("<td class='text-center' colspan='8'>NO RESULTS FOUND</td>");
        $("#TblTemplate tbody").append(tr);
    }
    else {
        for (i = 0; i < Result.length; i++) {
            if (Result[i].Status == "Active")
                tr = $('<tr/>');
            else
                tr = $(' <tr style="background-color:#fdd2d2;"/>');
            tr.append("<td class='text-center'><button type='button' onclick='FormEdit(\"" + Result[i].TemplateUid + "\");' class= 'common-btn common-btn-sm'><i class='fa-solid fa-pen-to-square'></i></button ><button type='button' onclick='FormDelete(\"" + Result[i].TemplateUid + "\");' class= 'common-btn common-btn-sm '> <i class='fa-regular fa-trash-can'></i></button ></td > ");
           
            tr.append("<td class='text-left no-cursor'>" + SerialNo + "</td>");
            tr.append("<td class='text-left no-cursor'>" + Result[i].TemplateUid + "</td>");
            tr.append("<td class='text-center edit-cursor'><a href='javascript:void(0)' class='text-decoration-none ' style='color: black !important;' onclick='FormEdit(\"" + Result[i].TemplateUid + "\");'>" + Result[i].TemplateName + "</a></td>");
            tr.append("<td class='text-center no-cursor'>" + HandleNullTextValue(Result[i].EmailSubject) + "</td>");
            tr.append("<td class='text-center no-cursor'>" + HandleNullTextValue(Result[i].TemplateType) + "</td>");
            tr.append("<td class='text-center no-cursor'>" + HandleNullTextValue(Result[i].Status) + "</td>");           
            SerialNo++;

            $("#TblTemplate tbody").append(tr);
        }
    }
};

// FORM ADD BUTTON CLICK EVENT
$("#FormAdd").click(function () {
    RemoveAllError('Template');
    ValidateAllFieldNewTest('Template');
    if (Ercount == 0) {
        if ($("#TemplateName").val().length <= 0) {
            $("#TemplateName").addClass('error-textbox');
            Toast(RetrieveMessage(1000), "Message", "error");
            $("#TemplateName").focus();
        }
        else {
            if ($("#TemplateType").val() == 0) {
                var editorContent_templateadd = tinyMCE.get('TemplateEmailBody').getContent();
                if (editorContent_templateadd.length == 0) {
                    Toast('Email Body Required !', "Message", 'error');
                    tinyMCE.get('TemplateEmailBody').focus();
                }
                else
                    FormAdd();                
            }
            else if ($("#TemplateType").val() == 1) {
                if ($("#TemplateSMSBody").val().length == 0) {
                    $("#TemplateSMSBody").addClass('error-textbox');
                    Toast(RetrieveMessage(1000), "Message", "error");
                } else {
                    $("#TemplateSMSBody").removeClass('error-textbox');
                    FormAdd();
                }
            }
        }


    }
});
//FUNCTION FOR FORM ADD
function FormAdd() {
    try {
        var editorContent_templateadd = tinyMCE.get('TemplateEmailBody').getContent();
        var msgcontent = window.btoa(editorContent_templateadd);
        $('[name="TemplateEmailBody"]').val(msgcontent);
        var form = $('#MyForm')[0];
        var mydata = new FormData(form);       
        AjaxSubmissionformdata(mydata, "/Master/Template/FormAdd", $('[name="__RequestVerificationToken"]').val()).done(function (result) {
            let obj = result;
            if (obj.status == true) {
                if (obj.responsecode == '101') {                  
                    Toast(RetrieveMessage(obj.responsecode), "Message", "success");
                    $("#TemplateUid").val(obj.data.Table[0].TemplateUid);
                    $("#TimeStamp").val(obj.data.Table[0].TimeStamp);
                    $("#FormAdd").hide();
                    $("#FormUpdate").show();
                    $("#FormReset").show();                  
                    $("#Template-tab").html("Edit Template");                    
                }
                else 
                    Toast(RetrieveMessage(obj.responsecode), "Message", "error");               
            }
            else 
                window.location.href = '/ClientLogin/ClientLogin';          
        }).fail(function (result) {
            console.log(result.Message);           
        });
    }
    catch (ex) {       
        console.log(ex.message);
    }
}

//FUNCTION FOR FORM EDIT
function FormEdit(e) {
    try {
        const dataString = {};
        dataString.TemplateUid = e;
        AjaxSubmission(JSON.stringify(dataString), "/Master/Template/FormEdit", $('[name="__RequestVerificationToken"]').val()).done(function (data) {
            let obj = data;
            if (obj.status == true) {
                if (obj.responsecode == '100') {
                    TabShow();                    
                    $("#TemplateName").val(obj.data.Table[0].TemplateName);
                    $("#TemplateType").val(obj.data.Table[0].TemplateType).trigger('change');
                    $("#AdditionalParameter").val(obj.data.Table[0].AdditionalParameter);
                    $("#TemplateSMSBody").val(obj.data.Table[0].SMSBody);
                    $("#TimeStamp").val(obj.data.Table[0].TimeStamp);
                    $("#TemplateUid").val(obj.data.Table[0].TemplateUid);
                    $("#EmailSubject").val(obj.data.Table[0].EmailSubject);                    
                    if (obj.data.Table[0].EmailBody != null) 
                        tinymce.get("TemplateEmailBody").setContent(obj.data.Table[0].EmailBody);                   
                    if (obj.data.Table[0].Status == true)
                        $("#TemplateStatus").val("1").trigger('change');
                    else
                        $("#TemplateStatus").val("0").trigger('change');

                } else
                    Toast(RetrieveMessage(obj.responsecode), "Message", "error");                
            }
            else 
                window.location.href = '/ClientLogin/ClientLogin';            
        }).fail(function (data) {
            console.log(data.Message);
        });
    }
    catch (e) {
        console.log(e.message);
    }
}

// FORM UPDATE BUTTON CLICK EVENT
$("#FormUpdate").click(function () {
    RemoveAllError('Template');
    ValidateAllFieldNewTest('Template');
    if (Ercount == 0) {
        if ($("#TemplateName").val().length <= 0) {
            $("#TemplateName").addClass('error-textbox');
            Toast(RetrieveMessage(1000), "Message", "error");
            $("#TemplateName").focus();
        }
        else {
            if ($("#TemplateType").val() == 0) {
                var editorContent_templateadd = tinyMCE.get('TemplateEmailBody').getContent();
                if (editorContent_templateadd.length == 0) {
                    Toast('Email Body Required !', "Message", 'error');
                    tinyMCE.get('TemplateEmailBody').focus();
                }
                else
                    FormUpdate();
            }
            else if ($("#TemplateType").val() == 1) {
                if ($("#TemplateSMSBody").val().length == 0) {
                    $("#TemplateSMSBody").addClass('error-textbox');
                    Toast(RetrieveMessage(1000), "Message", "error");
                } else {
                    $("#TemplateSMSBody").removeClass('error-textbox');
                    FormUpdate();
                }
            }
        }


    }
});

//FUNCTION FORM FORM UPDATE
function FormUpdate() {
    try {
        var editorContent_templateadd = tinyMCE.get('TemplateEmailBody').getContent();
        var msgcontent = window.btoa(editorContent_templateadd);
        $('[name="TemplateEmailBody"]').val(msgcontent);
        var form = $('#MyForm')[0];
        var mydata = new FormData(form);

        AjaxSubmissionformdata(mydata, "/Template/FormUpdate", $('[name="__RequestVerificationToken"]').val()).done(function (result) {
            let obj = result;          
            if (obj.status == true) {
                if (obj.responsecode == '107') {
                    Toast(RetrieveMessage(obj.responsecode), "Message", "success");
                    setTimeout(FormList(1), 1000);
                    $("#TemplateUid").val(obj.data.Table[0].TemplateUid);
                    $("#TimeStamp").val(obj.data.Table[0].TimeStamp);
                }
                else
                    Toast(RetrieveMessage(obj.responsecode), "Message", "error");
            }
            else 
                window.location.href = '/ClientLogin/ClientLogin';
            
        }).fail(function (result) {
            console.log(result.Message);     
        });
    }
    catch (ex) {
        console.log(ex.message); 
    }
}




//FUNCTION FORM DELETE
function FormDelete(e) {
    try {
        $.confirm({
            title: '',
            content: 'Are You Sure Want To Delete ?',
            type: 'red',
            boxWidth: '300px',
            useBootstrap: false,
            columnClass: 'small',
            containerFluid: true,
            typeAnimated: true,
            buttons: {
                tryAgain: {
                    text: 'Confirm',
                    btnClass: 'btn-red',
                    action: function () {
                        const dataString = {};
                        dataString.TemplateUid = e;
                        AjaxSubmission(JSON.stringify(dataString), "/Template/FormDelete", $('[name="__RequestVerificationToken"]').val()).done(function (data) {
                            let obj = data;
                            if (obj.status == true) {
                                if (obj.responsecode == '102') {
                                    Toast(RetrieveMessage(obj.responsecode), "Message", "success");
                                    setTimeout(FormList(1), 1000);
                                }
                                else 
                                    Toast(RetrieveMessage(obj.responsecode), "Message", "error");
                            }
                            else
                                window.location.href = 'ClientLogin/ClientLogin';                           
                        }).fail(function (data) {
                            console.log(data.Message);
                        });
                    }
                },
                close: function () {

                }
            }
        });
    }
    catch (e) {
        console.log(e.message);
    }
}

//TEMPLATETYPE CHANGE EVENT
$("#TemplateType").change(function () {
    if ($("#TemplateType").val() == 0) {
        $("#SMSDiv").css('display', 'none');
        $("#EmailDiv").css('display', 'block');
        $("#TemplateSMSBody").siblings('label').find('span').html("");
        $("#TemplateEmailBody").siblings('label').find('span').html("*");
        $("#EmailSubject").siblings('label').find('span').html("*");
    }
    else {
        $("#SMSDiv").css('display', 'block');
        $("#EmailDiv").css('display', 'none');
        $("#TemplateSMSBody").siblings('label').find('span').html("*");
        $("#TemplateEmailBody").siblings('label').find('span').html("");
        $("#EmailSubject").siblings('label').find('span').html("");
    }
});

//FUNCTION FOR LOAD TINY MCE
function LoadTinyMCE() {
    tinymce.init({
        /* replace textarea having class .tinymce with tinymce editor */
        selector: ".tinymce",
        branding: false,
        /* theme of the editor */
        theme: "modern",
        skin: "lightgray",
        /* width and height of the editor */
        width: "100%",
        height: 200,
        /* display statusbar */
        statubar: true,
        /* plugin */

        plugins: [
            "advlist autolink link image lists charmap print preview hr anchor pagebreak",
            "searchreplace wordcount visualblocks visualchars code fullscreen insertdatetime media nonbreaking",
            "save table contextmenu directionality emoticons template paste textcolor"
        ],
        /* toolbar */
        toolbar: "insertfile undo redo | styleselect | bold italic | alignleft aligncenter alignright alignjustify | bullist numlist outdent indent | link | fontsizeselect | fontselect | image | print preview media fullpage | forecolor backcolor emoticons ",
        /* style */
        style_formats: [
            {
                title: "Headers", items: [
                    { title: "Header 1", format: "h1" },
                    { title: "Header 2", format: "h2" },
                    { title: "Header 3", format: "h3" },
                    { title: "Header 4", format: "h4" },
                    { title: "Header 5", format: "h5" },
                    { title: "Header 6", format: "h6" }
                ]
            },
            {
                title: "Inline", items: [
                    { title: "Bold", icon: "bold", format: "bold" },
                    { title: "Italic", icon: "italic", format: "italic" },
                    { title: "Underline", icon: "underline", format: "underline" },
                    { title: "Strikethrough", icon: "strikethrough", format: "strikethrough" },
                    { title: "Superscript", icon: "superscript", format: "superscript" },
                    { title: "Subscript", icon: "subscript", format: "subscript" },
                    { title: "Code", icon: "code", format: "code" }
                ]
            },
            {
                title: "Blocks", items: [
                    { title: "Paragraph", format: "p" },
                    { title: "Blockquote", format: "blockquote" },
                    { title: "Div", format: "div" },
                    { title: "Pre", format: "pre" }
                ]
            },
            {
                title: "Alignment", items: [
                    { title: "Left", icon: "alignleft", format: "alignleft" },
                    { title: "Center", icon: "aligncenter", format: "aligncenter" },
                    { title: "Right", icon: "alignright", format: "alignright" },
                    { title: "Justify", icon: "alignjustify", format: "alignjustify" }
                ]
            }
        ],
    });
}


// FUNCTION FOR TAB SHOW
function TabShow() {
    $('#Template_list-tab').removeClass('active');
    $('#Template-tab').addClass('active');
    $('#Template_list').removeClass('active show');
    $('#Template').addClass('active show');
    $("#FormAdd").hide();
    $("#FormUpdate").show();
    $("#FormReset").show();
    $("#Template-tab").html("Edit Template");
}

//FUNCTION FOR TAB HIDE
function TabHide() {
    $("#FormAdd").hide();
    $("#FormUpdate").show();
    // $("#Template-tab").html("Edit Template");
}

//TEMPLATE - TAB CLICKED
$("#Template-tab").click(function () {
    $("#FormAdd").show();
    $("#FormUpdate").hide();
    $("#FormReset").hide();
    ResetForm();
})

//FORM RESET CLICKED
$("#FormReset").click(function () {
    ResetForm();
    $("#FormAdd").show();
    $("#FormReset").hide();
    $("#FormUpdate").hide();
})

//TEMPLATE_LIST - TAB CLICKED
$("#Template_list-tab").click(function () {
    RemoveAllError('Template');
    $("#Template-tab").html("Add template");
    $("#TemplateSMSBody").removeClass('error-textbox');
    FormList();
    ResetForm();

});

//FUNCTION FOR FORM RESET
function ResetForm() {
    $("#TimeStamp").val('');
    $("#TemplateUid").val('');
    $("#TemplateName").val("");   
    $("#Template-tab").html("Add template");
    $("#AdditionalParameter").val("");
    $("#AdditionalParameter").val("");
    $("#TemplateSMSBody").val("");
    $("#EmailSubject").val("");
    $("#TemplateEmailBody").val("");
    $("#TemplateStatus").val("1").trigger('change');
    tinymce.get("TemplateEmailBody").setContent("");
}

document.addEventListener("keydown", function (zEvent) {
    if (zEvent.ctrlKey && zEvent.altKey && (zEvent.key == "j" || zEvent.key == "J")) {      
        $('#Template_list-tab').removeClass('active ');
        $('#Template_list').removeClass('active show');
        $('#Template-tab').addClass('active');
        $('#Template').addClass('active show');
        $("#FormAdd").show();
        $("#FormUpdate").hide();
        $("#FormReset").hide();
        $("#Template-tab").html("Add template ");
        $('#TemplateName').focus();
        ResetForm();

    }
});
