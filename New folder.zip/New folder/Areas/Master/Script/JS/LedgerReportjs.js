﻿var srbtn = 'up';
var DateFrom = "";
var DateTo = "";
var LedgerId = "";
var sel = "";
//DOCUMNET READY
$(document).ready(function () {
    if (Get_Cookie("LedgerGroupName") != null && Get_Cookie("LedgerGroupId") != null) {
        var a = setInterval(() => {
            if (Get_Cookie("LedgerGroupName") != '') {
                if ($("#LedgerReportGroupSearch").val() != null) {
                    $("#HiddenLedgerId").val(Get_Cookie("LedgerGroupId"));
                    $("#AccHeadSearch").val(Get_Cookie("LedgerGroupName")).trigger('blur');
                    EraseCookie('LedgerGroupName');
                    EraseCookie('LedgerGroupId');
                    clearInterval(a);
                    $("#FormSearch").trigger('click');
                }
            }
        }, 1000);
    }
    if (Get_Cookie("Date1") != null && Get_Cookie("Date2") != null) {
        $("#SearchDateFrom").val(Get_Cookie("Date1"));
        $("#SearchDateTo").val(Get_Cookie("Date2"));
        EraseCookie('Date1');
        EraseCookie('Date2');
        /*  $("#FormSearch").trigger('click');*/
    }
    else {
        GetFinancialYearDate();
    }

    ShowLoader();
    FillPageSizeList('ddlPageSize');
    FillBranchList('SelectBranch', false);
    FillGroup('LedgerReportGroupSearch');
    //DATEPICKER FOR SEARCHJOBDATEFROM AND SEARCHJOBDATETO
    $('#SearchDateFrom,#SearchDateTo').datepicker({
        toolbarPlacement: "bottom",
        showButtonPanel: true,
        changeMonth: true,
        changeYear: true,
        dateFormat: 'dd/mm/yy',
        onClose: function () {
            if ($('#SearchDateFrom').val().length == 10 || $('#SearchDateTo').val().length == 10)
                CompareSearchDate($('#SearchDateFrom').val(), $('#SearchDateTo').val(), '');
        }
    });

    //FOR TODAY DATE
    jQuery.datepicker._gotoToday = function (id) {
        var today = new Date();
        var dateRef = jQuery("<td><a>" + today.getDate() + "</a></td>");
        this._selectDay(id, today.getMonth(), today.getFullYear(), dateRef);
    };
    LoadTinyMCE();
    $("#AccHeadSearch").focus();
});
// PAGINATION BUTTON CLICKED
$(document).on("click", ".pagination .page", function () {
    FormList(($(this).attr('page')));
});
//PAGE SIZE CLICKED
$("#ddlPageSize").change(function () {
    FormList(1);
});
$("#SelectBranch").select2({
    width: '100%'
});
$("#BalanceTypeSearch").select2({
    width: '100%'
});

$("#TypeSearch").select2({
    width: '100%'
});
$("#TypeBalanceSearch").select2({
    width: '100%'
});
$("#PaymentSearch").select2({
    width: '100%'
});
$("#LedgerReportGroupSearch").select2({
    width: '100%'
});

//SEARCH ARROW UP/DOWN
$("#Arrow").click(function () {
    if (srbtn == 'up') {
        $("#icn").html("<i class='fa-solid fa-angle-down'></i>");
        srbtn = 'down';
    } else {
        $("#icn").html("<i class='fa-solid fa-angle-up'></i>");
        srbtn = 'up';
    }
});
$('#LedgerReportGroupSearch').on('change', function () {
    /*   $("#HiddenLedgerId").val('');*/
    $("#AccHeadSearch").val('');
    LedgerAccHeadautocompleteForSearchLedger();
});
$("#AccHeadSearch").keyup(function () {
    LedgerAccHeadautocompleteForSearchLedger();
    /* FillPageSizeList('ddlPageSize', FormList);*/
});
//FUNCTION FOR TINYMCE EDITIOR
function LoadTinyMCE() {
    tinymce.init({
        selector: ".tinymce",
        branding: false,
        theme: "modern",
        skin: "lightgray",
        width: "100%",
        height: 200,
        statubar: true,
        plugins: [
            "advlist autolink link image lists charmap print preview hr anchor pagebreak",
            "searchreplace wordcount visualblocks visualchars code fullscreen insertdatetime media nonbreaking",
            "save table contextmenu directionality emoticons template paste textcolor"
        ],
        toolbar: "insertfile undo redo | styleselect | bold italic | alignleft aligncenter alignright alignjustify | bullist numlist outdent indent | link | fontsizeselect | fontselect | image | print preview media fullpage | forecolor backcolor emoticons ",
        style_formats: [
            {
                title: "Headers", items: [
                    { title: "Header 1", format: "h1" },
                    { title: "Header 2", format: "h2" },
                    { title: "Header 3", format: "h3" },
                    { title: "Header 4", format: "h4" },
                    { title: "Header 5", format: "h5" },
                    { title: "Header 6", format: "h6" }
                ]
            },
            {
                title: "Inline", items: [
                    { title: "Bold", icon: "bold", format: "bold" },
                    { title: "Italic", icon: "italic", format: "italic" },
                    { title: "Underline", icon: "underline", format: "underline" },
                    { title: "Strikethrough", icon: "strikethrough", format: "strikethrough" },
                    { title: "Superscript", icon: "superscript", format: "superscript" },
                    { title: "Subscript", icon: "subscript", format: "subscript" },
                    { title: "Code", icon: "code", format: "code" }
                ]
            },
            {
                title: "Blocks", items: [
                    { title: "Paragraph", format: "p" },
                    { title: "Blockquote", format: "blockquote" },
                    { title: "Div", format: "div" },
                    { title: "Pre", format: "pre" }
                ]
            },
            {
                title: "Alignment", items: [
                    { title: "Left", icon: "alignleft", format: "alignleft" },
                    { title: "Center", icon: "aligncenter", format: "aligncenter" },
                    { title: "Right", icon: "alignright", format: "alignright" },
                    { title: "Justify", icon: "alignjustify", format: "alignjustify" }
                ]
            }
        ],
    });
}
//AUTO COMPLETE DROPDOWN FOR SEARCH LEDGER NAME 
function LedgerAccHeadautocompleteForSearchLedger() {
    var GroupUid = $("#LedgerReportGroupSearch").val();
}

$("#AccHeadSearch").autocomplete({
    source: function (request, response) {
        $.ajax({
            type: 'POST',
            url: "/Master/LedgerReport/SearchAccHeadNameList",
            dataType: "json",
            async: false,
            data: {
                AccDescription: request.term, GroupUid: $("#LedgerReportGroupSearch").val()
            },
            success: function (result) {
                response($.map(result.data.Table, function (LedgerName) {
                    return {
                        label: LedgerName.AccHead,
                        value: LedgerName.AccHead,
                        id: LedgerName.ledgeruid,
                        LedgerGroup: LedgerName.LedgerGroup,
                    }
                }));
            },
            error: function (response) {
                console.log(response.responseText);
            }
        });
    },
    autoFocus: true,
    minLength: 1,
    selectFirst: true,
    selectOnly: true,
    select: function (e, i) {
        $("#HiddenLedgerId").val(i.item.id);
        /*   $("#LedgerReportGroupSearch").val(i.item.LedgerGroup).trigger('change');*/
    },

});


//FUNCTION FOR GET FINANCIAL YEAR DATE
function GetFinancialYearDate() {
    try {
        AjaxSubmission(null, '/_Layout/GetFinancialYearDate', $('[name="__RequestVerificationToken"]').val()).done(function (result) {
            let obj = result;
            if (obj.status == true) {
                if (obj.responsecode == '100') {
                    $("#SearchDateFrom").val(obj.data.Table[0].finyr_start_date);
                    $("#SearchDateTo").val(obj.data.Table[0].finyr_end_date);
                }
            }
            else
                window.location.href = '/ClientLogin/ClientLogin';
            HideLoader();
        }).fail(function (result) {
            HideLoader();
            console.log(result.message);
        });
        HideLoader();
    }
    catch (e) {
        HideLoader();
        console.log(e.message);
    }
}

$("#FormSearch").click(function () {
    var FromDate = $("#SearchDateFrom").val();
    var ToDate = $("#SearchDateTo").val();
    var flag = 0;
    if ($("#HiddenLedgerId").val() == "") {
        Toast("Please Select Account Head !", 'Message', 'error');
        flag = 1;
        return false;
    }
    if (FromDate == "") {
        Toast("Please Enter Date From", "Message", "error");
        flag = 1;
        return false;
    }
    if (ToDate == "") {
        Toast("Please Enter Date To", "Message", "error");
        flag = 1;
        return false;
    }
    if (FromDate >= ToDate) {
        Toast("To Date Must Be Greater Than From Date*", "Message", "error");
        flag = 1;
        return false;
    }
    else {

        var type = $("#TypeSearch").val();
        if (type == "0") {
            $(".ReportDNone").show();
            $("#tbl_LedgerReport").show();
            $("#tbl_LedgerReportMonthWise").hide();
            $("#tbl_LedgerReportDetailedMonthWise").hide();
        }
        else if (type == "1") {
            $(".ReportDNone").show();
            $("#tbl_LedgerReport").hide();
            $("#tbl_LedgerReportDetailedMonthWise").hide();
            $("#tbl_LedgerReportMonthWise").show();
        }
        else if (type == "2") {
            $(".ReportDNone").show();
            $("#tbl_LedgerReport").hide();
            $("#tbl_LedgerReportMonthWise").hide();
            $("#tbl_LedgerReportDetailedMonthWise").show();
        }
        FormList();
    }
});


function FormSorting(obj) {
    if (Firstcolumn != "") {
        document.getElementById(Firstcolumn).innerHTML = document.getElementById(Firstcolumn).getAttribute("data-column") + " <i class='fa-solid fa-sort'></i>";
    }
    let cn = obj.id;
    Firstcolumn = cn;
    var colname = $(obj).data("column");
    $("#sort-column").val(cn.replaceAll("_", ""));
    var sorttype = $("#sort-type").val();
    if (sorttype == "ASC") {
        $("#sort-type").val("DESC");
        $(obj).html(colname + " <i style='margin-left:10px;' class='fa-solid fa-sort-up'></i>");
    } else if (sorttype == "DESC") {
        $("#sort-type").val("ASC");
        $(obj).html(colname + " <i style='margin-left:10px;' class='fa-solid fa-sort-down'></i>");
    }
    FormList(1);
}


//LETTER MASTER LIST FUNCTION
function FormList(pageindex) {

    try {
        LedgerId = parseInt($("#HiddenLedgerId").val());
        DateFrom = $("#SearchDateFrom").val();
        DateTo = $("#SearchDateTo").val();
        const dataString = {};
        dataString.PageSize = $("#ddlPageSize").val();
        dataString.PageIndex = pageindex;
        dataString.LedgerUid = LedgerId;
        dataString.GroupUid = parseInt($("#LedgerReportGroupSearch").val());
        dataString.DateFrom = DateFrom;
        dataString.DateTo = DateTo;
        dataString.ChequeNo = $("#ChequeNoSearch").val();
        dataString.Paricular = $("#ParticularSearch").val();
        dataString.BalanceType = $("#BalanceTypeSearch").val();
        dataString.TypeSearch = $("#TypeSearch").val();
        dataString.AccDesc = $("#AccHead").val();
        dataString.BranchUid = parseInt($("#SelectBranch").val());
        dataString.OrderBy = $("#sort-column").val().trim() + " " + $("#sort-type").val().trim();
        dataString.HiddenSearchJobNo = $("#HiddenSearchJobNo").val();
        dataString.PaymentSearch = $("#PaymentSearch").val();
        ShowLoader();
        AjaxSubmission(JSON.stringify(dataString), "/Master/LedgerReport/FormList", $('input[name=__RequestVerificationToken]').val()).done(function (result) {
            let obj = result;

            if (obj.status == true) {
                if (obj.responsecode == '100') {

                    var ser = ((parseInt(obj.data.Table1[0].PageIndex) - 1) * parseInt(obj.data.Table1[0].PageSize)) + 1;
                    BindFormTable(obj.data.Table, ser, obj.data.Table3[0].CurrentBalance, obj.data.Table4, obj.data.Table2[0].ReportType, obj.data.Table5);
                    if (obj.data.Table1 != undefined && obj.data.Table1.length > 0) {

                        $(".pagination").BindPaging({
                            ActiveCssClass: "current",
                            PagerCssClass: "pager",
                            PageIndex: parseInt(obj.data.Table1[0].PageIndex),
                            PageSize: parseInt(obj.data.Table1[0].PageSize),
                            RecordCount: parseInt(obj.data.Table1[0].count)
                        });

                        if (obj.data.Table2[0].ReportType == 1) {
                            $(".LedgerMonthGraph").show();
                            ShowCurrentBalanceByChart();
                        }
                        else {
                            $(".LedgerMonthGraph").hide();
                        }
                    }
                }
                else {
                    Toast(RetrieveMessage(obj.responsecode), "Message", "error");
                }
            }
            else {
                window.location.href = '/ClientLogin/ClientLogin';
            }
            HideLoader();
        }).fail(function (result) {
            console.log(result.Message);
            HideLoader();
        });
    }
    catch (e) {
        console.log(e.message);
        HideLoader();
    }
}
//FUNCTION FOR BIND LETTER LIST TABLE
function BindFormTable(Result, SerialNo, CurrentBalance, AccDescResult, ReportType, DetailsMonthsLedger) {
    if (ReportType == '0') {
        $('#AccHead').removeAttr('disabled');
        $("#tbl_LedgerReport tbody tr").remove();
        if (Result.length == 0) {
            tr = $('<tr/>');
            tr.append("<td class='text-center' colspan='13'>NO RESULTS FOUND</td>");
            $("#tbl_LedgerReport tbody").append(tr);
        }
        else {
            var debit = 0;
            var credit = 0;
            var RunningBalance = 0;
            $('#AccHead').html('<option selected value="0">Select Ledger</option>');
            for (i = 0; i < AccDescResult.length; i++) {
                if (sel == AccDescResult[i].RefId)
                    $('#AccHead').append("<option selected value='" + AccDescResult[i].RefId + "'>" + AccDescResult[i].AccHead + "</option>")
                else
                    $('#AccHead').append("<option value='" + AccDescResult[i].RefId + "'>" + AccDescResult[i].AccHead + "</option>")
            }
            tr = $('<tr/>');
            tr.append("<td align='Right' colspan='12'> <span style='font-weight:bold;'>Opening Balance :</span></td>");
            tr.append("<td class='text-end'>" + HandleNullTextValue(CurrentBalance) + "</td>")
            $("#tbl_LedgerReport tbody").append(tr);
            let sumofbalance = 0;

            for (i = 0; i < Result.length; i++) {
                if (Result[i].Status == "Inactive") {
                    tr = $(' <tr style="background-color:#fdd2d2;"/>');
                }
                else {
                    tr = $('<tr/>');
                    tr.append("<td class='text-left'>" + SerialNo + "</td>");


                    // tr.append("<td class='text-left'  onclick='GoToRedirectView(\"" + Result[i].RefNo + "\");'>" + Result[i].RefNo + "</td>");


                    tr.append("<td class='text-center'><a href='javascript:void(0)' class='text-decoration-none' style='color: black !important;' onclick='GoToRedirectView(\"" + Result[i].RefNo + "\");'>" + Result[i].RefNo + "</a></td>");



                    tr.append("<td class='text-center'>" + Result[i].VoucherDate + "</td>");
                    tr.append("<td class='text-center'><a href='javascript:void(0)' class='text-decoration-none' style='color: black !important;' onclick='GoToLedgerReport(\"" + Result[i].AccHead + "\",\"" + Result
                    [i].RefId + "\");'>" + Result[i].AccHead + "</a></td>");
                    tr.append("<td class='text-center'>" + Result[i].Particular + "</td>");
                    tr.append("<td class='text-center'>" + HandleNullTextValue(Result[i].JobNo) + "</td>");
                    tr.append("<td class='text-center'>" + Result[i].BranchCode + "</td>");
                    tr.append("<td class='text-center'>" + HandleNullTextValue(Result[i].ChequeDetails) + "</td>");


                    if ((Result[i].AdjustedAmount != null) && (Result[i].AdjustedAmount != '0.00') && (Result[i].AdjustedAmount == Result[i].Debit) || ((Result[i].AdjustedAmount == Result[i].Credit))) {
                        tr.append("<td class='text-center'><label style ='padding:3px;background-color:#2aa13d;color:white;font-weight:bold;' class='mybox rounded'>" + HandleNullTextValue(Result[i].AdjustedAmount) + "</label></td>");
                    }


                    else if ((Result[i].AdjustedAmount !== null) && ((Result[i].AdjustedAmount < Result[i].Debit) || (Result[i].AdjustedAmount < Result[i].Credit))) {

                        tr.append("<td class='text-center'><label style ='padding:3px;background-color:#355089;color:white;font-weight:bold;' class='mybox rounded'>" + HandleNullTextValue(Result[i].AdjustedAmount) + "</label></td>");

                    }
                    else {
                        tr.append("<td class='text-center'>" + HandleNullTextValue(Result[i].AdjustedAmount) + "</td>");
                    }

                    if ((Result[i].OverDueDays == null) || (Result[i].OverDueDays == '0 Days')) {
                        tr.append("<td class='text-center'></td>");
                    }
                    else {
                        tr.append("<td class='text-center'><label style ='padding:3px;background-color: #d9534f;color:white;font-weight:bold;' class='mybox rounded'>" + HandleNullTextValue(Result[i].OverDueDays) + "</label></td>");
                    }
                    if ((Result[i].Debit != null) && (Result[i].Debit > 0)) {
                        tr.append("<td class='text-end'>" + HandleNullTextValue(Result[i].Debit) + "</td>");
                    }
                    else {
                        tr.append("<td class='text-end'></td>");
                    }

                    if ((Result[i].Credit != null) && (Result[i].Credit > 0)) {
                        tr.append("<td class='text-end'>" + HandleNullTextValue(Result[i].Credit) + "</td>");
                    }
                    else {
                        tr.append("<td class='text-end'></td>");
                    }
                  //  tr.append("<td class='text-end'>" + Result[i].Balance + " </td>");
                    sumofbalance += parseFloat(Result[i].Credit).toFixed(2) - parseFloat(Result[i].Debit).toFixed(2);
                    if (sumofbalance < 0)
                        tr.append("<td class='text-end'>" + Math.abs(sumofbalance) + " Dr </td>");
                    else {
                        tr.append("<td class='text-end'>" + Math.abs(sumofbalance) + " Cr </td>");
                    }

                    if (Result[i].Debit != null) {
                        debit = debit + parseFloat(HandleNullNumericValue((Result[i].Debit))); //Adding All Debit Amount
                    }
                    if (Result[i].Credit != null) {
                        credit = credit + parseFloat(HandleNullNumericValue((Result[i].Credit)));  // Adding All Credit Amount*/
                    }
                    if (Result[i].RunningBalance != null) {
                        RunningBalance = RunningBalance + parseFloat(Result[i].RunningBalance);   // Adding All RunningBalance Amount*/
                    }
                }
                SerialNo++;
                $("#tbl_LedgerReport tbody").append(tr);
            }

            if (CurrentBalance.length > 0) {
                tr = $('<tr/>');
                tr.append("<td align='Right' colspan='10'> <span style='font-weight:bold;'>Total :</span></td>");
                tr.append("<td class='text-end ' ><b>" + parseFloat(debit).toFixed(2) + "</b></td>")
                tr.append("<td class='text-end ' ><b>" + parseFloat(credit).toFixed(2) + "</b></td>")
                tr.append("<td class='text-end'><b>" + Result[Result.length - 1].Balance + "</b></td>")
                $("#tbl_LedgerReport tbody").append(tr);
                tr = $('<tr/>');
                tr.append("<td align='Right' colspan='9'> <span style='font-weight:bold;'>Balance Below 0 Days :</span></td>");
                tr.append("<td class='text-end'></td>")
                tr.append("<td class='text-end'></td>")
                tr.append("<td class='text-end'></td>")
                $("#tbl_LedgerReport tbody").append(tr);
                tr = $('<tr/>');
                tr.append("<td align='Right' colspan='9'> <span style='font-weight:bold;'>Balance Above 0 Days :</span></td>");
                tr.append("<td class='text-end'></td>")
                tr.append("<td class='text-end'></td>")
                tr.append("<td class='text-end'></td>")
                $("#tbl_LedgerReport tbody").append(tr);
            }
        }
    }
    else if (ReportType == '1') {
        $('#AccHead').attr('disabled', 'disabled');
        $('#AccHead').html("<option value=A selected>Filter Not Allowed</option>")
        $("#tbl_LedgerReportMonthWise tbody tr").remove();
        if (Result.length == 0) {
            tr = $('<tr/>');
            tr.append("<td class='text-center' colspan='8'>NO RESULTS FOUND</td>");
            $("#tbl_LedgerReportMonthWise tbody").append(tr);
        }
        else {
            var debit = 0;
            var credit = 0;
            var RunningBalance = 0;

            tr = $('<tr/>');
            tr.append("<td align='Right' colspan='4'> <span style='font-weight:bold;'>Opening Balance :</span></td>");
            //tr.append("<td class='text-end'>" + HandleNullTextValue(Result[0].RunningBalance) + "</td>")
            tr.append("<td class='text-end'>" + HandleNullTextValue(CurrentBalance) + "</td>")
            $("#tbl_LedgerReportMonthWise tbody").append(tr);
            for (i = 1; i < Result.length; i++) {
                //if (i == 0) {
                //    tr = $('<tr/>');
                //    tr.append("<td align='Right' colspan='4'> <span style='font-weight:bold;'>Opening Balance :</span></td>");
                //    tr.append("<td class='text-end'>" + HandleNullTextValue(CustomResult[0].OpeningBalance) + "</td>")
                //    $("#tbl_LedgerReportMonthWise tbody").append(tr);
                //}
                if (Result[i].Status == "Inactive") {
                    tr = $(' <tr style="background-color:#fdd2d2;"/>');
                }
                else {
                    tr = $('<tr/>');
                    tr.append("<td class='text-left'>" + (i) + "</td>");
                    tr.append("<td class='text-left'>" + Result[i].VoucherMonth + "  </td>");
                    if ((Result[i].Debit != null) && (Result[i].Debit > 0)) {
                        tr.append("<td class='text-end'>" + HandleNullTextValue(Result[i].Debit) + "</td>");
                    }
                    else {
                        tr.append("<td class='text-end'></td>");
                    }
                    if ((Result[i].Credit != null) && (Result[i].Credit > 0)) {
                        tr.append("<td class='text-end'>" + HandleNullTextValue(Result[i].Credit) + "</td>");
                    }
                    else {
                        tr.append("<td class='text-end'></td>");
                    }
                    tr.append("<td class='text-end'>" + Result[i].RunningBalance + " </td>");

                }
                SerialNo++;
                $("#tbl_LedgerReportMonthWise tbody").append(tr);
            }
        }
    }
    else if (ReportType == '2') {

        $('#AccHead').attr('disabled', 'disabled');
        $('#AccHead').html("<option value=A selected>Filter Not Allowed</option>")
        $("#tbl_LedgerReportDetailedMonthWise tbody tr").remove();
        if (Result.length == 0) {
            tr = $('<tr/>');
            tr.append("<td class='text-center' colspan='8'>NO RESULTS FOUND</td>");
            $("#tbl_LedgerReportDetailedMonthWise tbody").append(tr);
        }
        else {
            var debit = "";
            var credit = "";
            var RunningBalance = "";
            tr = $('<tr/>');
            tr.append("<td align='Right' colspan='4'> <span style='font-weight:bold;'>Opening Balance :</span></td>");
            /*   tr.append("<td class='text-end'>" + HandleNullTextValue(Result[0].RunningBalance) + "</td>")*/
            tr.append("<td class='text-end'>" + HandleNullTextValue(CurrentBalance) + "</td>")
            $("#tbl_LedgerReportDetailedMonthWise tbody").append(tr);

            for (i = 1; i < Result.length; i++) {
                //if (i == 0) {
                //    tr = $('<tr/>');
                //    tr.append("<td align='Right' colspan='4'> <span style='font-weight:bold;'>Opening Balance :</span></td>");
                //    tr.append("<td class='text-end'>" + HandleNullTextValue(CustomResult[0].OpeningBalance) + "</td>")
                //    $("#tbl_LedgerReportDetailedMonthWise tbody").append(tr);
                //}
                if (Result[i].Status == "Inactive") {
                    tr = $(' <tr style="background-color:#fdd2d2;"/>');
                }


                else {
                    tr = $('<tr/>');
                    tr.append("<td class='text-left'>" + (i) + "</td>");
                    var dem = "<td  id='" + Result[i].VoucherMonth + "' class='text-left'>" + Result[i].VoucherMonth + "  <button type='button' title='Monthly Details' onclick='LedgerDebitOrCreditWise(this);' class= 'MonthlyLedger common-btn common-btn-sm btn-primary'><i class='fa-solid fa-angle-down'></i></button>";

                    // CREATE TABLE ACCHEAD DEBIT WISE 
                    var newtable = "<table id='" + Result[i].VoucherMonth + "debit' class='DetailedMonthWise table table-bordered  table-sm d-none'  >";
                    // CREATE TABLE ACCHEAD CREDIT WISE 
                    var newtable1 = "<table id='" + Result[i].VoucherMonth + "credit' class='DetailedMonthWise table table-bordered  table-sm d-none'   >";

                    // CONCATE HEADER WITH TABLE DATA ACCHEAD DEBIT WISE
                    newtable += '<thead> <tr><th class="text-center text- capitalize" style="color:#1f242a;">AccHead</th><th class="text-center text-capitalize" style="color:#1f242a;">Debit</th></tr> </thead>';
                    var debit = 0.00;
                    for (var k = 0; k < DetailsMonthsLedger.length; k++) {
                        if ((Result[i].VoucherMonth == DetailsMonthsLedger[k].VoucherMonth) && (DetailsMonthsLedger[k].Debit > '0.00')) {
                            debit = debit + parseFloat(HandleNullNumericValue((DetailsMonthsLedger[k].Debit)));
                            newtable += "<tr>";
                            newtable += "<td>" + DetailsMonthsLedger[k].AccHead + "</td>";
                            newtable += "<td align='Right'>" + DetailsMonthsLedger[k].Debit + "</td>";
                            newtable += "</tr>";
                        }
                    }
                    // FILL TOTAL ACCHEAD DEBIT WISE DATA
                    newtable += "<tr>";
                    newtable += "<td class='text-center'> <span style='font-weight:bold;'>Total :</span></td>";
                    newtable += "<td class='text-end'>" + debit + "</td>";
                    newtable += "</tr>";
                    newtable += '</table>';


                    // CONCATE HEADER WITH TABLE DATA ACCHEAD DEBIT WISE
                    newtable1 += '<thead> <tr><th class="text-center text-capitalize" style="color:#1f242a;">AccHead</th><th class="text-center text-capitalize" style="color:#1f242a;">Credit</th></tr> </thead>';
                    var credit = 0.00;
                    for (var l = 0; l < DetailsMonthsLedger.length; l++) {

                        if ((Result[i].VoucherMonth == DetailsMonthsLedger[l].VoucherMonth) && (DetailsMonthsLedger[l].Credit > '0.00')) {
                            credit = credit + parseFloat(HandleNullNumericValue((DetailsMonthsLedger[l].Credit)));   // Adding All Credit Amount*
                            newtable1 += "<tr>";
                            newtable1 += "<td>" + DetailsMonthsLedger[l].AccHead + "</td>";
                            newtable1 += "<td align='Right'>" + DetailsMonthsLedger[l].Credit + "</td>";
                            newtable1 += "</tr>";
                        }
                    }
                    //// FILL TOTAL ACCHEAD CREDIT WISE DATA
                    newtable1 += "<tr>";
                    newtable1 += "<td class='text-center' > <span style='font-weight:bold;'>Total :</span></td>";
                    newtable1 += "<td class='text-end'>" + credit + "</td>";
                    newtable1 += "</tr>";
                    newtable1 += '</table>';

                    tr.append(dem + '</td>');
                    if ((Result[i].Debit != null) && (Result[i].Debit > 0))
                        tr.append("<td class='text-end'>" + HandleNullTextValue(Result[i].Debit) + "</td>");
                    else
                        tr.append("<td class='text-end'></td>");
                    if ((Result[i].Credit != null) && (Result[i].Credit > 0))
                        tr.append("<td class='text-end'>" + HandleNullTextValue(Result[i].Credit) + "</td>");
                    else
                        tr.append("<td class='text-end'></td>");
                    tr.append("<td  class='text-end'>" + Result[i].RunningBalance + " </td>");
                    if (DetailsMonthsLedger.length > 0) {
                        tr1 = $('<tr/>');
                        tr1.append("<td  colspan='3'>" + newtable + "</td>");
                        tr1.append("<td  colspan='2'>" + newtable1 + "</td>");
                    }
                }
                $("#tbl_LedgerReportDetailedMonthWise").append(tr);
                $("#tbl_LedgerReportDetailedMonthWise").append(tr1);
                SerialNo++;
            }
        }
    }
}


$("#LedgerReportPDF").click(function (pageindex) {
    try {
        var RadioChecked = $('input:radio[name=type1]:checked').val()
        const dataString = {};
        dataString.PageSize = $("#ddlPageSize").val();
        dataString.PageIndex = 1;
        dataString.RadioChecked = RadioChecked;
        dataString.LedgerUid = parseInt($("#HiddenLedgerId").val());
        dataString.GroupUid = parseInt($("#LedgerReportGroupSearch").val());
        dataString.DateFrom = $("#SearchDateFrom").val();
        dataString.DateTo = $("#SearchDateTo").val();
        dataString.ChequeNo = $("#ChequeNoSearch").val();
        dataString.Paricular = $("#ParticularSearch").val();
        dataString.BalanceType = $("#BalanceTypeSearch").val();
        dataString.TypeSearch = $("#TypeSearch").val();
        dataString.AccDesc = $("#AccHead").val();
        dataString.OrderBy = $("#sort-column").val().trim() + " " + $("#sort-type").val().trim();
        AjaxSubmission(JSON.stringify(dataString), '/Master/LedgerReport/FormList', $('input[name=__RequestVerificationToken]').val()).done(function (result) {
            let obj = result;
            if (obj.status == true) {
                if (obj.responsecode == '100') {
                    window.open($("#MyReport").attr('href'), '_blank');
                }
                else if (obj.responsecode == '703') {
                    Toast(obj.error, "Message", "error");
                }
                else {
                    Toast(RetrieveMessage(obj.responsecode), "Message", "error");
                }

            } else
                window.location.href = '/ClientLogin/ClientLogin';
            HideLoader();
        }).fail(function (result) {
            console.log(result.Message);
            HideLoader();
        });
    }
    catch (e) {
        console.log(e.message);
    }
});

function LedgerDebitOrCreditWise(e) {
    $(e).parent().parent().next('tr').find('.DetailedMonthWise').toggleClass('d-none');
};

function GoToLedgerReport(e, E1) {
    window.open('/Master/LedgerReport/LedgerReport', '_blank');
    SetCookie('LedgerGroupName', e, 's', 50);
    SetCookie('LedgerGroupId', E1, 's', 50);
}

function SearchTrigger() {
    $("#FormSearch").trigger('click');
}

var Assignledtbltype = "";
var templedtimestamp = "";
var Assignledtbllength = "";

function LedgerReportEmailClick() {
    try {
        ShowLoader();
        LedgerId = parseInt($("#HiddenLedgerId").val());
        DateFrom = $("#SearchDateFrom").val();
        DateTo = $("#SearchDateTo").val();
        const dataString = {};
        dataString.PageSize = $("#ddlPageSize").val();
        /*        dataString.PageIndex = pageindex;*/
        dataString.PageIndex = 1;
        dataString.LedgerUid = LedgerId;
        dataString.GroupUid = parseInt($("#LedgerReportGroupSearch").val());
        dataString.DateFrom = DateFrom;
        dataString.DateTo = DateTo;
        dataString.ChequeNo = $("#ChequeNoSearch").val();
        dataString.Paricular = $("#ParticularSearch").val();
        dataString.BalanceType = $("#BalanceTypeSearch").val();
        dataString.TypeSearch = $("#TypeSearch").val();
        dataString.AccDesc = $("#AccHead").val();
        dataString.OrderBy = $("#sort-column").val().trim() + " " + $("#sort-type").val().trim();
        dataString.SendEmail = true;
        AjaxSubmission(JSON.stringify(dataString), '/Master/LedgerReport/FormList', $('input[name=__RequestVerificationToken]').val()).done(function (result) {
            let obj = result;
            if (obj.status == true) {
                if (obj.responsecode == '100') {
                    EmailModal.style.display = "block";
                    $("#EmailTo").val(obj.data.Table1[0].ClientEmail);
                    $("#EmailCC").val(obj.data.Table1[0].CCEmail);
                    $("#EmailLetterName").val(obj.data.Table1[0].LetterName);
                    $("#AttachFileName").text(obj.data.Table2[0].FileName);
                    $("#AttachFileName").attr("href", obj.data.Table2[0].FilePath);
                    $("#AttachedFilePath").val(obj.data.Table2[0].AttachmentFilePath);

                    $("#RefId").val(obj.data.Table1[0].LedgerId);
                    $("#SendToName").val(obj.data.Table1[0].SendTo);
                    $("#RefName").val('LedgerSummaryReport');

                    BindTemplateName('AllTemplate', 'Email');
                    FillTemplateDataInTincyMce(parseInt($("#HiddenLedgerId").val()), 'LedgerReminder', null, 'Email', 'Ledger');

                }
                else if (obj.responsecode == '703') {
                    Toast(obj.error, "Message", "error");
                }
                else {
                    Toast(RetrieveMessage(obj.responsecode), "Message", "error");
                }

            } else
                window.location.href = '/ClientLogin/ClientLogin';
            HideLoader();
        }).fail(function (result) {
            console.log(result.Message);
            HideLoader();
        });
    }
    catch (e) {
        HideLoader();
        console.log(e.message);
    }
}

//FUNCTION FOR CHANGE TEMPLATE DETAILS
function TemplateChange() {
    tinymce.get("EmailBody").setContent('');
    $('#Subject').val('');
    if ($('#AllTemplate').val() != null && $('#AllTemplate') != undefined) {
        if ($('#AllTemplate').val() != 0)
            FillTemplateDataInTincyMce(parseInt($("#HiddenLedgerId").val()), 'LedgerReminder', $('#AllTemplate').val(), 'Email', 'Ledger');
    }
}


function ShowCurrentBalanceByChart() {
    try {
        var dmy = $("#SearchDateFrom").val();
        var arrDate = dmy.split('/');
        var mdy = arrDate[2] + "-" + arrDate[1] + "-" + arrDate[0];
        var dmy = $("#SearchDateTo").val();
        var arrDate = dmy.split('/');
        var mdy1 = arrDate[2] + "-" + arrDate[1] + "-" + arrDate[0];
        const dataString = {};
        dataString.DateFrom = mdy;
        dataString.DateTo = mdy1;
        dataString.LedgerId = parseInt($("#HiddenLedgerId").val()),
            dataString.BranchUid = parseInt($("#SelectBranch").val())
        AjaxSubmission(JSON.stringify(dataString), "/Master/LedgerReport/NewChart", $('[name="__RequestVerificationToken"]').val()).done(function (data) {
            let obj = data;
            console.log(obj);
            if (obj.success == true) {
                if (obj.series.length > 0) {
                    var options = {
                        series: [{
                            name: "Monthly Balance",
                            data: data.labels
                        }],
                        chart: {
                            type: 'bar',
                            height: 430
                        },
                        plotOptions: {
                            bar: {
                                horizontal: true,
                                borderRadius: 4,
                                barHeight: '100%',
                                columnWidth: '100%',
                                hideZeroBarsWhenGrouped: false,
                                dataLabels: {
                                    position: 'top',

                                },
                            }
                        },
                        dataLabels: {
                            enabled: true,
                            offsetX: -6,
                            style: {
                                fontSize: '12px',
                                colors: ['#fff']
                            }
                        },
                        stroke: {
                            show: true,
                            width: 1,
                            colors: ['#fff']
                        },
                        tooltip: {
                            shared: true,
                            intersect: false
                        },
                        xaxis: {
                            categories: data.series,
                        }
                        , legend: {
                            position: 'top'
                        },
                        title: {
                            text: "Ledger Summary Month Wise Graph",
                            align: 'center',
                            margin: 10,
                            offsetX: 0,
                            offsetY: 0,
                            floating: false,
                            style:
                            {
                                fontSize: '14px',
                                fontWeight: 'bold',
                                fontFamily: 'Arial,Helvetica,sans-serif'
                                //color: '#263238'
                            }
                        },
                    };
                    var chart = new ApexCharts(document.querySelector("#LedgerMonthGraph"), options);
                    chart.render();
                }
                else {
                    Toast(RetrieveMessage(obj.responsecode), "Message", "error");
                }

            }
            else {
                window.location.href = '/ClientLogin/ClientLogin';
            }
        }).fail(function (data) {
            console.log(data.Message);
        });
    }
    catch (e) {
        console.log(e.message);
    }
}

// FUNCTION FOR GO TO REDIRECT VIEW
function GoToRedirectView(e, E1) {
    var RefId = e;
    var substring = RefId.slice(3);

    var firstTwoChars = RefId.slice(0, 2);
    if (firstTwoChars == 'PU') {
        window.open('/Master/PurchaseEntry/PurchaseEntry', '_blank');
        SetCookie('LedgerGroupName', e, 's', 50);

    }
    else if (firstTwoChars == 'BP') {
        window.open('/Master/VoucherEntry/VoucherEntry', '_blank');
        SetCookie('LedgerGroupName', e, 's', 50);
    }
    else if (firstTwoChars == 'CP') {
        window.open('/Master/VoucherEntry/VoucherEntry', '_blank');
        SetCookie('LedgerGroupName', e, 's', 50);
    }
    else if (firstTwoChars == 'CR') {
        window.open('/Master/VoucherEntry/VoucherEntry', '_blank');
        SetCookie('LedgerGroupName', e, 's', 50);
    }
    else if (firstTwoChars == 'BR') {
        window.open('/Master/VoucherEntry/VoucherEntry', '_blank');
        SetCookie('LedgerGroupName', e, 's', 50);
    }
    else if (firstTwoChars == 'JB') {
        window.open('/Master/VoucherEntry/VoucherEntry', '_blank');
        SetCookie('LedgerGroupName', e, 's', 50);
    }
    else if (firstTwoChars == 'BL') {
        window.open('/Master/BillEntry/BillEntry', '_blank');
        SetCookie('BillEntryUid', substring, 's', 50);
    }
    else if (firstTwoChars == 'RM') {
        window.open('/Master/BillEntry/BillEntry', '_blank');
        SetCookie('BillEntryUid', substring, 's', 50);
    }
    else if (firstTwoChars == 'CN') {
        window.open('/Master/BillEntry/BillEntry', '_blank');
        SetCookie('BillEntryUid', substring, 's', 50);
    }
    else if (firstTwoChars == 'DN') {
        window.open('/Master/BillEntry/BillEntry', '_blank');
        SetCookie('BillEntryUid', substring, 's', 50);

    }
}

//FUNCTION FOR EXPORT DATA IN EXCEL
function FormExcel() {
    debugger;
    ShowLoader();
    let date = new Date();
    let NewDate = ("00" + date.getDate()).slice(-2) + "_" + ("00" + (date.getMonth() + 1)).slice(-2) + "_" + date.getFullYear() + "_" + ("00" + date.getHours()).slice(-2) + "_" + ("00" + date.getMinutes()).slice(-2) + "_" + ("00" + date.getSeconds()).slice(-2);
    let fileName = "LedgerReport_" + NewDate + ".xlsx";

    $('#FormSearch').trigger('click');
    AjaxSubmission(null, '/Master/LedgerReport/FormExcel', $('input[name=__RequestVerificationToken]').val()).done(function (result) {
        let obj = result;
        if (obj.status == true) {
            if (obj.responsecode == '100') {

                let bytes = Base64ToBytes(obj.data.FileData[0].Base64Data);
                let blob = new Blob([bytes], { type: "application/octetstream" });
                let isIE = false || !!document.documentMode;
                if (isIE) {
                    window.navigator.msSaveBlob(blob, fileName);
                } else {
                    let url = window.URL || window.webkitURL;
                    link = url.createObjectURL(blob);
                    let a = $("<a />");
                    a.attr("download", fileName);
                    a.attr("href", link);
                    $("body").append(a);
                    a[0].click();
                    $("body").remove(a);
                }
            }
            else if (obj.responsecode == '302')
                Toast('No Records found.', 'Message', 'success');
            else
                Toast(RetrieveMessage(obj.responsecode), 'Message', 'error');

        } else
            window.location.href = '/ClientLogin/ClientLogin';
        HideLoader();

    }).fail(function (result) {
        console.log(result.Message);
        HideLoader();
    });
}

