﻿var Firstcolumn = "";

if (Get_Cookie("ItemId") != null) {
    var a = setInterval(() => {
        if (Get_Cookie("ItemId") != '' && Get_Cookie("ItemId") != 0) {
            FormEdit(Get_Cookie("ItemId"));
        } else {
            $('#Item_list-tab').removeClass('active');
            $('#Item-tab').addClass('active');
            $('#Item_list').removeClass('active show');
            $('#Item').addClass('active show');
            $("#FormAdd").show();
            $("#FormUpdate").hide();
            $("#Item-tab").html("Add Item ");
        }
        EraseCookie('ItemId');
        clearInterval(a);
    }, 100);
}

//DOCUMENT READY FUNCTION
$(document).ready(function () {
    ShowLoader();
    if (Get_Cookie("ItemId") == null)
        FillPageSizeList('ddlPageSize', FormList);
    else
        FillPageSizeList('ddlPageSize');
    HideLoader();
    $("#SearchItemId").focus();
});

//GROUP LIST FUNCTION
function FormList(pageindex) {
    try {
        const dataString = {};
        dataString.PageSize = $("#ddlPageSize").val();
        dataString.PageIndex = pageindex;
        dataString.ItemId = $("#SearchItemId").val().trim();
        dataString.ItemCode = $("#SearchItemCode").val().trim();
        dataString.OrderBy = $("#sort-column").val().trim() + " " + $("#sort-type").val().trim();
        //ShowLoader();
        AjaxSubmission(JSON.stringify(dataString), "/Master/Item/FormList", $('input[name=__RequestVerificationToken]').val()).done(function (result) {
            let obj = result;
            if (obj.status == true) {
                if (obj.responsecode == '100') {

                    var ser = ((parseInt(obj.data.Table1[0].PageIndex) - 1) * parseInt(obj.data.Table1[0].PageSize)) + 1;
                    BindFormTable(obj.data.Table, ser);
                    if (obj.data.Table1 != undefined && obj.data.Table1.length > 0) {
                        $(".pagination").BindPaging({
                            ActiveCssClass: "current",
                            PagerCssClass: "pager",
                            PageIndex: parseInt(obj.data.Table1[0].PageIndex),
                            PageSize: parseInt(obj.data.Table1[0].PageSize),
                            RecordCount: parseInt(obj.data.Table1[0].count)
                        });
                    }
                }
                else {
                    Toast(RetrieveMessage(obj.responsecode), "Message", "error");
                }
            }
            else {
                window.location.href = '/ClientLogin/ClientLogin';
            }
            //HideLoader();
        }).fail(function (result) {
            console.log(result.Message);
            //HideLoader();
        });
    }
    catch (e) {
        console.log(e.message);
        //HideLoader();
    }
}

//FUNCTION FOR BIND GROUP HEAD TABLE
function BindFormTable(result, serial_no) {
    $("#tbl_item tbody tr").remove();
    if (result.length == 0) {
        tr = $('<tr/>');
        tr.append("<td class='text-center' colspan='8'>NO RESULTS FOUND</td>");
        $("#tbl_item tbody").append(tr);
    }
    else {
        for (i = 0; i < result.length; i++) {
            if (result[i].is_active == "Inactive")
                tr = $(' <tr style="background-color:#fdd2d2;"/>');
            else
                tr = $('<tr/>');
            tr.append("<td class='text-center'><button type='button' onclick='FormEdit(\"" + result[i].ItemUid + "\");' class='common-btn common-btn-sm'><i class='fa-solid fa-pen-to-square'></i></button ><button type='button' onclick='FormDelete(\"" + result[i].ItemUid + "\");' class='common-btn common-btn-sm ms-1'> <i class='fa-regular fa-trash-can'></i></button ></td > ");
            tr.append("<td class='text-left'>" + serial_no + "</td>");
            tr.append("<td class='text-left'>" + result[i].ItemUid + "</td>");
            tr.append("<td class='text-center'><a href='javascript:void(0)' class='text-decoration-none ' style='color: black !important;' onclick='FormEdit(\"" + result[i].ItemUid + "\");'>" + result[i].ItemCode + "</a></td>");
            tr.append("<td class='text-center'>" + result[i].category_desc + "</td>");

            serial_no++;
            $("#tbl_item tbody").append(tr);
        }
    }
}

//FUNCTION FOR PEGINATION PREVIOUS NEXT CLICK
$(document).on("click", ".pagination .page", function () {
    FormList(($(this).attr('page')));
});

$("#ddlPageSize").change(function () {
    FormList(1);
});

//SEARCH BUTTON CLICK
$("#FormSearch").click(function () {
    FormList(1);
});

//FUNCTION FOR SORTING
function Sorting(obj) {

    if (Firstcolumn != "") {
        document.getElementById(Firstcolumn).innerHTML = document.getElementById(Firstcolumn).getAttribute("data-column") + " <i class='fa-solid fa-sort'></i>";
    }
    Firstcolumn = obj.id;
    var colname = $(obj).data("column");
    $("#sort-column").val(Firstcolumn);
    var sorttype = $("#sort-type").val();
    if (sorttype == "ASC") {
        $("#sort-type").val("DESC");
        $(obj).html(colname + " <i  style='margin-left:10px;' class='fa-solid fa-sort-up'></i>");
    } else if (sorttype == "DESC") {
        $("#sort-type").val("ASC");
        $(obj).html(colname + " <i  style='margin-left:10px;' class='fa-solid fa-sort-down'></i>");
    }
    FormList(1);
}

//FUNCTION FOR BIND GROUP NAME
function FillCategoryDescription() {
    try {
        //ShowLoader();
        AjaxSubmission(null, "/Master/Item/GetCategoryDescName", $('input[name=__RequestVerificationToken]').val()).done(function (result) {
            let obj = result;
            if (obj.status == true) {
                if (obj.responsecode == '100') {
                    BindDropdown(obj.data.Table, 'CategoryCode', 'category_uid', 'category_desc', '-----Select-----');
                }
                else if (obj.responsecode == '604') {
                    BindDropdown(null, 'CategoryCode', 'category_uid', 'category_desc', '-----Select-----');
                }
                else {
                    Toast(RetrieveMessage(obj.responsecode), "Message", "error");
                }
                setTimeout(FormList(1), 500);
            }
            else {
                window.location.href = '/ClientLogin/ClientLogin';
            }
            //HideLoader();
        }).fail(function (result) {
            console.log(result.Message);
            //HideLoader();
        });
    }
    catch (e) {
        console.log(e.message);
        //HideLoader();
    }
}

//GROUP ADD BUTTON CLICK
$("#FormAdd").click(function () {
    RemoveAllError('Item');
    ValidateAllFieldNewTest('Item');

    if (Ercount == 0) {
        if ($("#HiddenCategoryCode").val() == '') {
            Toast(RetrieveMessage(1001), "Message", "error");
            return;
        }
        if ($("#ItemDesc").val() == '') {
            Toast("Please Enter Item Description ! ", "Message", "error");
            return;
        }
        FormAdd();
    }
});

//ADD GROUP FUNCTION
function FormAdd() {
    try {
        const datastring = {};
        datastring.ItemCode = $("#ItemCode").val();
        datastring.ItemDesc = $("#ItemDesc").val();
        datastring.CategoryCode = $("#HiddenCategoryCode").val();
        datastring.HSCode = $("#HSCode").val();
        datastring.BrandName = $("#BrandName").val();
        datastring.EndUseOfItem = $("#EndUseCode").val();
        datastring.EndUseDesc = $("#EndUseDesc").val();
        datastring.RSPApplicability = $("#RSPApplicability").val();
        datastring.PreferentialStandard = $("#PreferentialStandard").val();
        datastring.AccessoryStatus = $("#AccessoryStatus").val();
        datastring.ModelName = $("#ModelName").val();

        //ShowLoader();
        AjaxSubmission(JSON.stringify(datastring), "/Master/Item/FormAdd", $('input[name=__RequestVerificationToken]').val()).done(function (result) {
            let obj = result;
            if (obj.status == true) {
                if (obj.responsecode == '101') {
                    Toast(RetrieveMessage(obj.responsecode), "Message", "success");
                    $("#FormAdd").hide();
                    $("#FormUpdate").show();
                    $("#FormReset").show();
                    $("#Item-tab").html("Edit Item");
                    setTimeout(FormList(1), 500);
                    $("#Timestamp").val(obj.data.Table[0].timestamp);
                    $("#ItemId").val(obj.data.Table[0].ItemId);

                    //ResetForm();
                    //TabHide();
                }
                else {
                    Toast(RetrieveMessage(obj.responsecode), "Message", "error");
                }
            }
            else {
                window.location.href = '/ClientLogin/ClientLogin';
            }
            //HideLoader();
        }).fail(function (result) {
            console.log(result.Message);
            //HideLoader();
        });
    }
    catch (e) {
        console.log(e.message);
    }
}

//EDIT GROUP FUNCTION 
function FormEdit(e) {
    try {
        //console.log(e);
        const datastring = {};
        datastring.ItemId = e;
        AjaxSubmission(JSON.stringify(datastring), "/Master/Item/FormEdit", $('[name="__RequestVerificationToken"]').val()).done(function (data) {
            let obj = data;
            console.log(obj);
            if (obj.status == true) {
                if (obj.responsecode == '100') {

                    TabShow();
                    $("#ItemId").val(obj.data.Table[0].ItemId);
                    $("#ItemCode").val(obj.data.Table[0].ItemCode);
                    $("#ItemDesc").val(obj.data.Table[0].ItemDesc);
                    $("#HiddenCategoryCode").val(obj.data.Table[0].CategoryCode);
                    $("#CategoryCode").val(obj.data.Table[0].CategoryDesc);
                    $("#HSCode").val(obj.data.Table[0].HSCode);
                    $("#BrandName").val(obj.data.Table[0].BrandName);
                    $("#ModelName").val(obj.data.Table[0].ModelName);
                    $("#HiddenEndUseCode").val(obj.data.Table[0].EndUseOfItem);
                    $("#EndUseCode").val(obj.data.Table[0].EndUseOfItem);
                    $("#EndUseDesc").val(obj.data.Table[0].EndUseDesc);
                    $("#RSPApplicability").val(obj.data.Table[0].RSPApplicability);
                    $("#PreferentialStandard").val(obj.data.Table[0].PreferentialStandard);
                    $("#AccessoryStatus").val(obj.data.Table[0].AccessoryStatus);
                    $("#Timestamp").val(obj.data.Table[0].timestamp);
                    $("#ItemId").val(obj.data.Table[0].ItemId);

                } else {
                    Toast(RetrieveMessage(obj.responsecode), "Message", "error");
                }
            }
            else {
                window.location.href = '/ClientLogin/ClientLogin';
            }
        }).fail(function (data) {
            console.log(data.Message);
        });

    }
    catch (e) {
        console.log(e.message);
    }
}

//GROUP UPDATE BUTTON CLICK
$("#FormUpdate").click(function () {
    RemoveAllError('Item');

    ValidateAllFieldNewTest('Item');
    if (Ercount == 0) {
        if ($("#HiddenCategoryCode").val() == '') {
            Toast(RetrieveMessage(1001), "Message", "error");
            return;
        }
        if ($("#ItemDesc").val() == '') {
            Toast("Please Enter Item Description ! ", "Message", "error");
            return;
        }
        FormUpdate();
    }

});

//UPDATE GROUP FUNCTION
function FormUpdate() {
    try {
        const datastring = {};
        datastring.ItemCode = $("#ItemCode").val();
        datastring.ItemDesc = $("#ItemDesc").val();
        datastring.CategoryCode = $("#HiddenCategoryCode").val();
        datastring.HSCode = $("#HSCode").val();
        datastring.BrandName = $("#BrandName").val();
        datastring.ModelName = $("#ModelName").val();
        datastring.EndUseOfItem = $("#EndUseCode").val();
        datastring.EndUseDesc = $("#EndUseDesc").val();
        datastring.RSPApplicability = $("#RSPApplicability").val();
        datastring.PreferentialStandard = $("#PreferentialStandard").val();
        datastring.AccessoryStatus = $("#AccessoryStatus").val();
        datastring.ItemId = $("#ItemId").val();
        datastring.timestamp = $("#Timestamp").val();

        AjaxSubmission(JSON.stringify(datastring), "/Master/Item/FormUpdate", $('input[name=__RequestVerificationToken]').val()).done(function (result) {
            let obj = result;
            if (obj.status == true) {
                if (obj.responsecode == '107') {
                    Toast(RetrieveMessage(obj.responsecode), "Message", "success");
                    setTimeout(FormList(1), 500);
                    $("#Timestamp").val(obj.data.Table[0].timestamp);
                    $("#ItemId").val(obj.data.Table[0].ItemId);
                    //ResetForm();
                    //TabHide();
                }
                else {
                    Toast(RetrieveMessage(obj.responsecode), "Message", "error");
                }
            }
            else {
                window.location.href = '/ClientLogin/ClientLogin';
            }
            //HideLoader();
        }).fail(function (result) {
            console.log(result.Message);
            //HideLoader();

        });
    }
    catch (e) {
        console.log(e.Message);
    }
}

//DELETE GROUP FUNCTION
function FormDelete(e) {
    try {
        $.confirm({
            title: '',
            content: 'Are You Sure Want To Delete ?',
            type: 'red',
            boxWidth: '300px',
            useBootstrap: false,
            columnClass: 'small',
            containerFluid: true,
            typeAnimated: true,
            buttons: {
                tryAgain: {
                    text: 'Confirm',
                    btnClass: 'btn-red',
                    action: function () {

                        const datastring = {};
                        datastring.ItemId = parseInt(e);
                        //ShowLoader();
                        AjaxSubmission(JSON.stringify(datastring), "/Master/Item/FormDelete", $('[name="__RequestVerificationToken"]').val()).done(function (data) {
                            let obj = data;
                            if (obj.status == true) {
                                if (obj.responsecode == '102') {
                                    Toast(RetrieveMessage(obj.responsecode), "Message", "success");
                                    FormList(1);

                                }
                                else {
                                    Toast(RetrieveMessage(obj.responsecode), "Message", "error");
                                }
                            }
                            else {
                                window.location.href = 'ClientLogin/ClientLogin';
                            }
                            //HideLoader();
                        }).fail(function (data) {
                            console.log(data.Message);
                            //HideLoader();
                        });
                    }
                },
                close: function () {
                    //HideLoader();
                }
            }
        });
    }
    catch (e) {
        console.log(e.message);
        //HideLoader();
    }
}
//FUNCTION FOR TAB HIDE
function TabShow() {
    $('#Item_list-tab').removeClass('active');
    $('#Item-tab').addClass('active');
    $('#Item_list').removeClass('active show');
    $('#Item').addClass('active show');
    $("#FormAdd").hide();
    $("#FormUpdate").show();
    $("#FormReset").show();
    $("#Item-tab").html("Edit Item");
}

//FUNCTION FOR TAB HIDE
function TabHide() {
    $('#Item-tab').removeClass('active');
    $('#Item_list-tab').addClass('active ');
    $('#Item_list').addClass('active show');
    $('#Item').removeClass('active show');
    $("#FormAdd").show();
    $("#FormUpdate").hide();
    $("#FormReset").hide();
    $("#Item-tab").html("Add Item");
}

$("#CategoryCode").on('input', function () {
    $("#HiddenCategoryCode").val('');
});
//GROUP HEADS LIST TAB ON CLICK 
$('#Item_list-tab').click(function () {
    ResetForm();
    RemoveAllError('Item');
});

//FUNCTION FOR RESET DATA
function ResetForm() {
    $("#ItemId").val('');
    $("#ItemCode").val('');
    $("#ItemDesc").val('');
    $("#HiddenCategoryCode").val('');
    $("#CategoryCode").val('');
    $("#HSCode").val('');
    $("#BrandName").val('NA');
    $("#ModelName").val('NA');
    $("#EndUseCode").val('');
    $("#HiddenEndUseCode").val('');
    $("#EndUseDesc").val('');
    $("#RSPApplicability").val('Y');
    $("#PreferentialStandard").val('P');
    $("#AccessoryStatus").val('0');

    $("#FormAdd").show();
    $("#FormUpdate").hide();
    $("#FormReset").hide();
    $("#Item-tab").html("Add Item");
    $("#Timestamp").val('');
    $("#ItemId").val('');
}
//FUNCTION FOR GET DEFAULT PAGE
function FillDefaultPage() {
    try {

        //ShowLoader();
        AjaxSubmission(null, "/Master/GroupHeads/GetDefaultPageSize", $('input[name=__RequestVerificationToken]').val()).done(function (data) {
            let obj = data;
            if (obj.status == true) {
                $("#ddlPageSize").val(obj.data.Table[0].DefaultPageSize);
                setTimeout(FormList(1), 2000);

            }
            else {
                window.location.href = '/ClientLogin/ClientLogin';
            }
            //HideLoader();

        }).fail(function (result) {
            console.log(result.Message);
            //HideLoader();
        });
    }

    catch (e) {
        console.log(e.message);
        //HideLoader();
    }
}

function FillEndUseDesc() {
    try {
        if ($("#HiddenEndUseCode").val().length <= 0) {
            $("#EndUseDesc").val('');
        }
        else {
            //ShowLoader();
            const dataString = {};

            var LId = $("#HiddenEndUseCode").val();

            dataString.EndUseCode = LId;
            console.log(JSON.stringify(dataString));
            AjaxSubmission(JSON.stringify(dataString), '/Master/_Layout/GetEndUseDescription', $('input[name=__RequestVerificationToken]').val()).done(function (result) {
                let obj = result;
                console.log(obj);
                if (obj.status == true) {
                    if (obj.responsecode == '100') {
                        $("#EndUseDesc").val(obj.data.Table[0].EndUseDesc);
                    }
                } else
                    window.location.href = '/ClientLogin/ClientLogin';
                //HideLoader();
            }).fail(function (result) {
                console.log(result.Message);
                //HideLoader();
            });
        }
    }
    catch (e) {
        //HideLoader();
        console.log(e.message);
    }
}
$(".Item_list").click(function () {
    $("#SearchItemId").focus();
});

$("#EndUseCode").on('input', function () {
    $("#HiddenEndUseCode").val('');
});

$("#FormReset").click(function () {
    ResetForm();
})

function GoToItemCategory(e) {
    SetCookie('ItemCategoryId', $("#" + e).val(), 's', 50);
}

//FUNCTION FOR EXPORT DATA IN EXCEL
function FormExcel() {
    ShowLoader();
    let date = new Date();
    let NewDate = ("00" + date.getDate()).slice(-2) + "_" + ("00" + (date.getMonth() + 1)).slice(-2) + "_" + date.getFullYear() + "_" + ("00" + date.getHours()).slice(-2) + "_" + ("00" + date.getMinutes()).slice(-2) + "_" + ("00" + date.getSeconds()).slice(-2);
    let fileName = "Item_" + NewDate + ".xlsx";

    $('#FormSearch').trigger('click');
    AjaxSubmission(null, '/Master/Item/FormExcel', $('input[name=__RequestVerificationToken]').val()).done(function (result) {
        let obj = result;
        if (obj.status == true) {
            if (obj.responsecode == '100') {

                let bytes = Base64ToBytes(obj.data.FileData[0].Base64Data);
                let blob = new Blob([bytes], { type: "application/octetstream" });
                let isIE = false || !!document.documentMode;
                if (isIE) {
                    window.navigator.msSaveBlob(blob, fileName);
                } else {
                    let url = window.URL || window.webkitURL;
                    link = url.createObjectURL(blob);
                    let a = $("<a />");
                    a.attr("download", fileName);
                    a.attr("href", link);
                    $("body").append(a);
                    a[0].click();
                    $("body").remove(a);
                }
            }
            else if (obj.responsecode == '302')
                Toast("No Records found.", 'Message', 'success');
            else
                Toast(RetrieveMessage(obj.responsecode), 'Message', 'error');

        } else
            window.location.href = '/ClientLogin/ClientLogin';
        HideLoader();

    }).fail(function (result) {
        console.log(result.Message);
        HideLoader();
    });
}
document.addEventListener("keydown", function (zEvent) {
    if (zEvent.ctrlKey && zEvent.altKey && (zEvent.key == "j" || zEvent.key == "J")) {
        $('#Item_list-tab').removeClass('active ');
        $('#Item_list').removeClass('active show');
        $('#Item-tab').addClass('active');
        $('#Item').addClass('active show');
        $("#FormAdd").show();
        $("#FormUpdate").hide();
        $("#FormReset").hide();
        $("#Item-tab").html("Add Item ");
        $('#ItemCode').focus();
        ResetForm();

    }
});
