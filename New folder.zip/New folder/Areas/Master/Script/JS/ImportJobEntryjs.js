﻿
let ImpoSelecBranc = '', ShSelecBranc = '', HSSelecBranc = '', Detslab = '', ManuFactBranch = '';
let jobflag = 0, srbtn = 'up';
Firstcolumn = '';
let dupInv = 0, firssr = 0, JobAc = 0;
var TemplateFor = 'Shipping Line Charges';

//VARIABLE FOR DOCUMENT UPLOAD
let formname = 'Job';
let formid;
let VoucherType = '';

//DATE PICKER
$('.dateTimepickerAll').datetimepicker({
    format: 'd/m/Y H:i',
});

$('.card-body').css({ 'overflow': '', 'height': '' });

// DOCUMENT READY
$(document).ready(function () {
    LoadTinyMCE();
    Firstcolumn = 'sub_job_no';
    firssr = 0;

    let date = new Date();
    let NewDate = date.getDate().toString().padStart(2, 0) + '/' + (date.getMonth() + 1).toString().padStart(2, 0) + '/' + date.getFullYear().toString();
    $('#JobDate').val(NewDate);

    if (Get_Cookie('ClientId') != null || Get_Cookie('JobUid') != null) {
        FillPageSizeList('ddlPageSize');
        $('#SearchJobDateFrom,#SearchJobDateTo').val('');
    }
    else {
        GetFinancialYearDateJob();
        let iju = setInterval(() => {
            if ($('#SearchSelectBranch').val() != null && $('#SearchJobDateFrom').val() != null && $('#SearchJobDateFrom').val() != undefined && $('#SearchJobDateFrom').val().trim().length == 10 && $('#SearchJobDateTo').val() != null && $('#SearchJobDateTo').val() != undefined && $('#SearchJobDateTo').val().trim().length == 10) {
                FillPageSizeList('ddlPageSize', FormList);
                clearInterval(iju);
            }
        }, 100);
    }

    if (Get_Cookie('ClientId') != null) {
        let avf = setInterval(() => {
            if (Get_Cookie('ClientId') != '' && Get_Cookie('ClientId') != 0) {
                $('#HiddenSearchClient').val(Get_Cookie('ClientId'));
                if (Get_Cookie('HiddenSrchLedgName') != null)
                    $('#SearchClient').val(Get_Cookie('HiddenSrchLedgName'));
                if (Get_Cookie('Type') != null) {
                    if (Get_Cookie('Type') == 'PendingJob')
                        $('#PendingJob').prop('checked', true);
                    else if (Get_Cookie('Type') == 'BilledJob')
                        $('#BilledJob').prop('checked', true);
                    else if (Get_Cookie('Type') == 'UnBilledJob')
                        $('#UnBilledJob').prop('checked', true);
                }
                $('#FormSearch').trigger('click');
            }
            EraseCookie('ClientId');
            EraseCookie('HiddenSrchLedgName');
            EraseCookie('Type');
            clearInterval(avf);

        }, 1000);
    }

    if (Get_Cookie('JobType') != null) {
        let JbType = Get_Cookie('JobType');
        if (JbType == 'PendingJob')
            $('#PendingJob').prop('checked', true);
        else if (JbType == 'BilledJob')
            $('#BilledJob').prop('checked', true);
        else if (JbType == 'UnBilledJob')
            $('#UnBilledJob').prop('checked', true);

        let poli = setInterval(() => {
            if ($('#SearchSelectBranch').val() != null && $('#SearchJobDateFrom').val() != null && $('#SearchJobDateTo').val() != null) {
                $('#SearchSelectBranch').val(Get_Cookie('SearchBranch'));
                $('#SearchJobDateFrom').val(Get_Cookie('SearchFrmDate'));
                $('#SearchJobDateTo').val(Get_Cookie('SearchToDate'));

                EraseCookie('JobType');
                clearInterval(poli);
            }
        }, 100);
    }
    FillBranchList('SearchSelectBranch', false);
    FillBranchList('SelectBranch');

    let oio = setInterval(() => {
        if ($('#SelectBranch').val() > 0 && $('#JobDate').val().trim().length == 10) {
            const dataString = {};
            dataString.BranchId = $('#SelectBranch').val();
            dataString.JobDate = $('#JobDate').val();
            GetBranchIceGateUserId();
            AjaxSubmission(JSON.stringify(dataString), '/ImportJobEntry/GetJobno', $('[name="__RequestVerificationToken"]').val()).done(function (result) {
                let obj = result;
                if (obj.status == true) {
                    if (obj.responsecode == '100') {
                        if (obj.data.Table[0].In_Valid_Job_No == false) {
                            $('#JobNo,#SubJobNo').val('');
                            $('#JobNo').val(obj.data.Table[0].job_no);
                            $('#SubJobNo').val(obj.data.Table[0].sub_job_no);

                            if (Get_Cookie('JobUid') != null) {
                                let bvgb = setInterval(() => {
                                    if (Get_Cookie('JobUid') != '' && Get_Cookie('JobUid') != 0) {
                                        FormEdit(Get_Cookie('JobUid'));
                                    }
                                    EraseCookie('JobUid');
                                    clearInterval(bvgb);
                                }, 100);
                            }
                        }
                    }
                }
                else
                    window.location.href = '/ClientLogin/ClientLogin';
            }).fail(function (result) {
                console.log(result.message);
            });
            clearInterval(oio);
        }
    }, 100);

    GetInvoiceTerm('InvoiceTerms');
    GetInvoiceTerm('NewInvoiceTerms');

    FillSchemeCode('NewItemCategorySchemeCode', 'Import');
    FillSchemeCode('TblItemCategorySchemeCode', 'Import');

    FillIceGateId('TblIceGate', '----Select----', '.');
    FillIceGateId('TblNewItemIceGate', '----Select----', '.');
    FillIceGateId('FlatFileModalICEGATEUserId', '----Select----');

    FillItemMode('NewItemMode');
    FillItemMode('TblItemMode');

    if (Get_Cookie('JobUid') == null)
        HideLoader();

    $('#SearchJobNo').autocomplete({
        source: function (request, response) {
            AjaxSubmissionAutocomplete(JSON.stringify({
                SearchField: request.term, SubJobNo: $('#SearchSubJobNo').val(), JobDateFrom: $('#SearchJobDateFrom').val(), JobDateTo: $('#SearchJobDateTo').val(), Type: null, JobType: 'Import/Amendment'
            }), '/Master/_Layout/GetJobNumberAutoComplete', $('input[name=__RequestVerificationToken]').val()).done(function (result) {
                let obj = result;
                if (obj.status == true) {
                    if (obj.responsecode == '100') {
                        response($.map(result.data.Table, function (item, id) {
                            return {
                                label: item.name,
                                value: item.name,
                                id: item.id
                            };
                        }));
                    }
                }
                else
                    window.location.href = '/ClientLogin/ClientLogin';
            }).fail(function (result) {
                console.log(result.Message);
            });
        },
        autoFocus: true,
        minLength: 1,
        selectFirst: true,
        selectOnly: true,
        select: function (e, i) {
            //$('#' + HiddenId).val(i.item.id);
            $('#HiddenSearchJobNo').val(i.item.id);

        },
        change: function (e, i) {
            if (i.item == null || i.item == undefined) {
                //$('#' + id).val('');
                //$('#' + HiddenId).val('');

                $('#SearchJobNo').val('');
                $('#HiddenSearchJobNo').val('');
            }
        }
    }).on('focus', function () {
        $(this).autocomplete('search', $('#SearchSubJobNo').val());
    });
});


//#region /****************************MAIN START**********************/

let hidImport = '';
//IMPORTER NAME ON INPUT  EVENT
$('#ImporterName').on('input', function () {
    $('#HiddenImporterName').val('');
    hidImport = '';
})

//IMPORTER NAME BUTTON BLUR EVENT
$('#ImporterName').blur(function () {
    if (hidImport != $('#HiddenImporterName').val().trim()) {
        $('#AdCode,#BranchCode').val('');
        $('#Address,#AuthorizedDealerCodeList').html('');
        if ($('#HiddenImporterName').val().trim().length > 0) {
            hidImport = $('#HiddenImporterName').val().trim();
            FillImporterAddress();
            FillImporterAdCode();
        }
    }
    else if ($('#HiddenImporterName').val() == '') {
        $('#AdCode,#BranchCode').val('');
        $('#Address,#AuthorizedDealerCodeList').html('');       
    }
});

//FUNCTION FOR FILL IMPORTER AUTHORIZED DEALER CODE
function FillImporterAdCode() {
    try {
        const dataString = {};
        let Lid = parseInt($('#HiddenImporterName').val().trim());
        dataString.LedgerId = Lid;
        AjaxSubmission(JSON.stringify(dataString), '/Master/_Layout/GetLedgerAdCode', $('input[name=__RequestVerificationToken]').val()).done(function (result) {
            let obj = result;
            if (obj.status == true) {
                if (obj.responsecode == '100') {                    
                    $.each(obj.data.Table, function (ind, ele) {
                        $('#AuthorizedDealerCodeList').append(`<option value=${ele.AdCode}>${ele.AdCode}</option>`);
                    });
                }                

            } else
                window.location.href = '/ClientLogin/ClientLogin';
        }).fail(function (result) {
            console.log(result.Message);
        });
    }
    catch (e) {
        console.log(e.message);
    }
}

//FUNCTION FOR FILL IMPORTER ADDRESS
function FillImporterAddress() {
    try {        
        const dataString = {};
        let Lid = parseInt($('#HiddenImporterName').val().trim());
        dataString.LedgerId = Lid;
        AjaxSubmission(JSON.stringify(dataString), '/Master/_Layout/GetLedgerAddressWithBranch', $('input[name=__RequestVerificationToken]').val()).done(function (result) {
            let obj = result;
            if (obj.status == true) {
                if (obj.responsecode == '100') {
                    BindDropdownNew(obj.data.Table, 'Address', 'BranchUid', 'BranchAddress', '--Select--');
                    if (ImpoSelecBranc == '' || ImpoSelecBranc == undefined || ImpoSelecBranc == null)
                        $("#Address").val(obj.data.Table[0].BranchUid).trigger('change');
                    else {
                        $("#Address").val(ImpoSelecBranc).trigger('change');
                        ImpoSelecBranc = '';
                    }
                }
                else
                    BindDropdownNew(null, 'Address', 'BranchUid', 'BranchAddress', '--Select--');

            } else
                window.location.href = '/ClientLogin/ClientLogin';
        }).fail(function (result) {
            console.log(result.Message);
        });
    }
    catch (e) {
        console.log(e.message);
    }
}

//ADDRESS DROPDOWN CHANGE EVENT
$('#Address').change(function () {
    if ($('#Address').val() == "00")
        $('#BranchCode').val('')
    else
        FillBranchCode($('#Address').val());
});

// FUNCTION FOR FILL BRANCH CODE
function FillBranchCode(e) {
    try {
        if (e <= 0) {
            Toast('Please Choose Client Address', 'Message', 'error');
            $('#BranchCode').val('');
        } else {
            const dataString = {};
            dataString.BranchUid = e;
            AjaxSubmission(JSON.stringify(dataString), '/Master/_Layout/GetBranchCode', $('input[name=__RequestVerificationToken]').val()).done(function (result) {
                let obj = result;
                if (obj.status == true) {
                    if (obj.responsecode == '100')
                        $('#BranchCode').val(obj.data.Table[0].BranchCode);
                    else
                        Toast(RetrieveMessage(obj.responsecode), 'Message', 'error');
                } else
                    window.location.href = '/ClientLogin/ClientLogin';
            }).fail(function (result) {
                console.log(result.message);
            });
        }
    }
    catch (e) {
        console.log(e.message);
    }
}

//SHIPPER NAME ON INPUT EVENT
$("#Shipper").on('input', function () {
    $("#HiddenShipper").val('');
});

//SHIPPER BLUR EVENT
$("#Shipper").blur(function () {
    $("#ShipperAddress").html('');
    if ($("#HiddenShipper").val().trim().length > 0)
        FillShipperAddress();
})

//FUNCTION FOR FILL SHIPPER ADDRESS
function FillShipperAddress() {
    try {
        const dataString = {};
        let LId = parseInt($("#HiddenShipper").val().trim());
        dataString.LedgerId = LId;
        AjaxSubmission(JSON.stringify(dataString), '/Master/_Layout/GetLedgerAddressWithBranch', $('input[name=__RequestVerificationToken]').val()).done(function (result) {
            let obj = result;
            if (obj.status == true) {
                if (obj.responsecode == '100') {
                    BindDropdownNew(obj.data.Table, 'ShipperAddress', 'BranchUid', 'BranchAddress', '--Select--');                   
                    $('#HiddenNewItemManufacturerProducerGrowerName').val($('#HiddenShipper').val());
                    $('#NewItemManufacturerProducerGrowerName').val($('#Shipper').val());
                    BindDropdownNew(obj.data.Table, 'NewItemManufacturerProducerGrowerAddress', 'BranchUid', 'BranchAddress', '--Select--');
                    if (ShSelecBranc == '' || ShSelecBranc == undefined || ShSelecBranc == null)
                        $("#ShipperAddress").val(obj.data.Table[0].BranchUid).trigger('change');
                    else {
                        $("#ShipperAddress").val(ShSelecBranc).trigger('change');
                        ShSelecBranc = '';
                    }
                }
                else {
                    BindDropdownNew(null, 'ShipperAddress', 'BranchUid', 'BranchAddress', '--Select--');
                    BindDropdownNew(null, 'NewItemManufacturerProducerGrowerAddress', 'BranchUid', 'BranchAddress', '--Select--');
                }


            } else
                window.location.href = '/ClientLogin/ClientLogin';
        }).fail(function (result) {
            console.log(result.Message);
        });
    }
    catch (e) {
        console.log(e.message);
    }
}

let hidShip = '';
//SHIPPING LINE ON INPUT EVENT
$("#ShippingLine").on('input', function () {
    $("#HiddenShippingLine").val('');
    hidShip = '';
});

//SHIPPINGLINE BUTTON BLUR FUNCTION
$("#ShippingLine").blur(function () {

    if (hidShip != $("#HiddenShippingLine").val()) {
        $("#DetentionSlab").html('');
        if ($("#HiddenShippingLine").val().length > 0)
            hidShip = $("#HiddenShippingLine").val();
            FillDetentionSlab($("#HiddenShippingLine").val());
    }
    else if ($("#HiddenShippingLine").val() == '') {
        $("#DetentionSlab").html('');
    }
});

// FUNCTION FOR FILL DETENTION SLAB 
function FillDetentionSlab(e) {
    try {
        if (e != null && e != undefined && e.length > 0) {
            const dataString = {};
            dataString.LedgerId = e;
            AjaxSubmission(JSON.stringify(dataString), '/Master/_Layout/GetDetentionSlab', $('input[name=__RequestVerificationToken]').val()).done(function (result) {
                let obj = result;
                if (obj.status == true) {
                    if (obj.responsecode == '100')
                        BindDropdown(obj.data.Table, 'DetentionSlab', 'ShipUid', 'SlabName', '----Select----');
                    if (Detslab != '') {
                        $("#DetentionSlab").val(Detslab);
                        Detslab = '';
                    }
                }
                else
                    window.location.href = '/ClientLogin/ClientLogin';
            }).fail(function (result) {
                console.log(result.message);
            });
        }
    }
    catch (e) {
        console.log(e.message);
    }
}

//#endregion

//#region /****************************FORM ADD START**********************/

// FORM ADD BUTTON CLICK EVENT
$("#FormAdd").click(function () {
    if ($('#SelectBranch').val() == 0) {
        Toast('Please Select Branch', 'Message', 'error');
        $("#SelectBranch").focus();
    }
    else if ($('#JobNo').val().trim().length <= 0) {
        Toast('Job Number Error!', 'Message', 'error');
        $('#SubJobNo').focus();
    }
    else if ($("#JobDate").val().trim().length < 10) {
        Toast('Please Select Job Date', 'Message', 'error');
        $("#JobDate").focus();
    }
    else if ($("#HiddenImporterName").val().trim().length <= 0) {
        Toast('Please Add Client', 'Message', 'error');
        $("#ImporterName").focus();
    }
    else if ($("#BranchCode").val().trim().length <= 0) {
        Toast('Please Choose Client Address', 'Message', 'error');
        $("#Address").focus();
    }
    else if ($('#BEType').val() == 'X') {
        if ($('#HiddenWareHouseJobNo').val() == '' || $('#HiddenWareHouseJobNo').val() == null) {
            Toast('Please Enter Job Number.', 'Message', 'error');
            $('#WareHouseJobNo').focus();
        }
        else
            FormAdd();
    }
    else if ($('#JobType').val() == 'A') {
        if ($('#HiddenOldJobNo').val() == '' || $('#HiddenOldJobNo').val() == null) {
            Toast('Please Enter Amendment Job Number.', 'Message', 'error');
            $('#OldJobNo').focus();
        }
        else if ($('#AmendmentCode').val().trim().length <= 0) {
            ActiveAmendmentTab();
            Toast('Please Enter Amendment Code.', 'Message', 'error');
            $('#AmendmentCode').focus();
        }
        else if ($('#RequestLetterNumber').val().trim().length <= 0) {
            ActiveAmendmentTab();
            Toast('Please Request Letter Number.', 'Message', 'error');
            $('#RequestLetterNumber').focus();
        }
        else if ($('#RequestDate').val().length < 10) {
            ActiveAmendmentTab();
            Toast('Please Request Request Date.', 'Message', 'error');
            $('#RequestDate').focus();
        }
        else if ($('#AmendmentReason').val().trim().length <= 0) {
            ActiveAmendmentTab();
            Toast('Please Amemdment Reason.', 'Message', 'error');
            $('#AmendmentReason').focus();
        }
        else if ($('#BEType').val() == 'X') {
            if ($('#HiddenWareHouseJobNo').val() == '' || $('#HiddenWareHouseJobNo').val() == null) {
                Toast('Please Enter Job Number.', 'Message', 'error');
                $('#WareHouseJobNo').focus();
            }
        }
        else
            FormAdd();
    }
    else
        FormAdd();

});

// FUNCTION FOR FORM ADD
function FormAdd() {
    try {

        const dataString = GetJobHeaderData();
        if (dataString == false)
            return;
        let Vflag = 0;

        let ContainerDetails = new Array();
        let InvoiceDetails = new Array();
        let ItemDetails = new Array();
        let LicenseDetails = new Array();
        let DestuffDetails = new Array();
        let BondDetails = new Array();
        let CertificateDetails = new Array();
        let JobSupportDocsDetails = new Array();

        Vflag = ValidateContainerDetailsData(); //VALIDATE CONTAINER DETAILS DATA

        if (Vflag == 0) {
            ContainerDetails = GetContainerDetailsData(); //RETURN CONTAINER DETAILS DATA
            dataString.containerDetails = ContainerDetails;
            Vflag = ValidateInvoiceDetailsData(); //VALIDATE INVOICE DETAILS DATA
            if (Vflag == 0) {
                InvoiceDetails = GetInvoiceDetailsData(); //RETURN INVOICE DETAILS DATA
                dataString.invoiceDetails = InvoiceDetails;

                Vflag = ValidateNtWtGrWtInVl(); //VALIDATE NET WEIGHT,GROSS WEIGHT AND INVOICE VALUE

                if (Vflag == 0) {
                    Vflag = ValidateAllInvVlWtAllItem();  //VALIDATE ALL INVOICE WITH VALUE WITH ALL ITEM

                    if (Vflag == 0) {
                        Vflag = ValidateItemDetailsData();  //VALIDATE ITEM DETAILS DATA
                        if (Vflag == 0) {

                            ItemDetails = GetItemDetailsData(); //RETURN ITEM DETAILS DATA
                            dataString.itemDetails = ItemDetails;

                            Vflag = ValidateLicenseDetailsData();  //VALIDATE LICENSE DETAILS DATA

                            if (Vflag == 0) {
                                Vflag = ValidateLicenseDataItemDetailsData()  //VALIDATE ALL ITEM WITH ALL LICENSE                               
                                if (Vflag == 0) {
                                    LicenseDetails = GetLicenseDetailsData(); //RETURN LICENSE DETAILS DATA
                                    dataString.licenseDetails = LicenseDetails;

                                    Vflag = ValidateDestuffDetailsData();  //VALIDATE DESTUFF DETAILS DATA
                                    if (Vflag == 0) {
                                        DestuffDetails = GetDestuffDetailsData() //RETURN DESTUFF DETAILS DATA
                                        dataString.destuffDetails = DestuffDetails;

                                        BondDetails = GetBondDetailsData(); //RETURN BOND DETAILS DATA
                                        dataString.bondDetails = BondDetails;

                                        CertificateDetails = GetCertificateDetailsData(); //RETURN CERTIFICATE DETAILS DATA
                                        dataString.certificateDetails = CertificateDetails;

                                        JobSupportDocsDetails = GetJobSupportDocsDetailsData();  //RETURN JOB SUPPORT DOCS DETAILS DATA
                                        dataString.jobSupportDocsDetails = JobSupportDocsDetails;

                                        AjaxSubmission(JSON.stringify(dataString), "/Master/ImportJobEntry/FormAdd", $('[name="__RequestVerificationToken"]').val()).done(function (result) {
                                            let obj = result;
                                            if (obj.status == true) {
                                                if (obj.responsecode == '101') {
                                                    Toast(RetrieveMessage(obj.responsecode), "Message", "success");
                                                    $("#JobUid").val(obj.data.Table[0].JobUid);
                                                    formid = obj.data.Table[0].JobUid;
                                                    $('#TimeStamp').val(obj.data.Table[0].timestamp);
                                                    $('#FormAdd').hide();
                                                    $('#FormUpdate,#GenCheckList,#CFSCharges,#ShipLineCharges,#UploadDocument,#GenFlatFile,#FormReset').show();
                                                    $('#ImportJob-tab').html('Edit Job');
                                                    $('#AddNewJobESanchit').removeClass('d-none');
                                                    FormList(1);
                                                }
                                                else if (obj.responsecode == '703')
                                                    Toast(obj.error, "Message", "error");

                                                else if (obj.responsecode == '1013') {
                                                    JobAc = 1;
                                                    NewJobNoConfirmation();
                                                }
                                                else
                                                    Toast(RetrieveMessage(obj.responsecode), "Message", "error");

                                            } else
                                                window.location.href = '/ClientLogin/ClientLogin';
                                            HideLoader();
                                        }).fail(function (result) {
                                            HideLoader();
                                            console.log(result.message);
                                        });
                                    }
                                }
                            }

                        }
                    }
                }
            }
        }
    }
    catch (e) {
        HideLoader();
        console.log(e.message);
    }
}

//#endregion

//#region /****************************FORM EDIT START**********************/

// FUNCTION FOR FORM EDIT
function FormEdit(e) {
    try {
        ShowLoader();
        $("#UploadDocument").show();
        const dataString = {};
        dataString.JobId = e;
        formid = e;
        AjaxSubmission(JSON.stringify(dataString), "/ImportJobEntry/FormEdit", $('[name="__RequestVerificationToken"]').val()).done(function (data) {
            let obj = data;
            if (obj.status == true) {
                if (obj.responsecode == '100') {
                    TabShow();
                    $('#JobType').attr('disabled', 'disabled');
                    $('#AddNewJobESanchit').removeClass('d-none');

                    $("#CreatedByModifiedBy").css('display', 'block');
                    $("#CreatedByModifiedBy").css('width', '100%');

                    FillLetters(obj.data.Table8[0].JobNo);  //FILL LETTER DETAILS
                    FillBillDetails(obj.data.Table8[0].JobUid);  //FILL BILL DETAILS
                    FillMainDetailsData(obj.data.Table8[0]);  //FILL MAIN DETAILS                    
                    FillContainerDetailsData(obj.data.Table);  //FILL CONTAINER DETAILS
                    FillInvoiceDetailsData(obj.data.Table1);  //FILL INVOICE DETAILS  
                    FillItemDetailsData(obj.data.Table2);  //FILL ITEM DETAILS DATA
                    FillLicenseDetailsData(obj.data.Table3);  //FILL LICENSE DETAILS DATA
                    FillDestuffDetailsData(obj.data.Table4);  //FILL DESTUFF DETAILS DATA
                    FillJobSupportDocDetailsData(obj.data.Table5); //FILL JOB SUPPORT DOCUMENT DETAILS DATA
                    FillBondDetailsData(obj.data.Table6);  //FILL BOND DETAILS DATA
                    FillCertificateDetailsData(obj.data.Table7);  //FILL CERTIFICATE DETAILS DATA

                }
                else
                    Toast(RetrieveMessage(obj.responsecode), "Message", "error");
            }
            else
                window.location.href = '/ClientLogin/ClientLogin';

            HideLoader();
        }).fail(function (data) {
            console.log(data.Message);
            HideLoader();
        });
    }
    catch (e) {
        console.log(e.message);
        HideLoader();
    }
}

//#endregion

//#region /****************************FORM UPDATE START**********************/

// FORM UPDATE BUTTON CLICK EVENT
$("#FormUpdate").click(function () {
    if ($("#JobUid").val().trim().length == 0)
        Toast('JobUid Not Found', 'Message', 'error');
    else if ($('#SelectBranch').val() == 0) {
        Toast('Please Select Branch', 'Message', 'error');
        $("#SelectBranch").focus();
    }
    else if ($('#JobNo').val().trim().length <= 0) {
        Toast('Job Number Error!', 'Message', 'error');
        $('#SubJobNo').focus();
    }
    else if ($("#JobDate").val().trim().length < 10) {
        Toast('Please Select Job Date', 'Message', 'error');
        $("#JobDate").focus();
    }
    else if ($("#HiddenImporterName").val().trim().length <= 0) {
        Toast('Please Add Client', 'Message', 'error');
        $("#ImporterName").focus();
    }
    else if ($("#BranchCode").val().trim().length <= 0) {
        Toast('Please Choose Client Address', 'Message', 'error');
        $("#Address").focus();
    }
    else
        FormUpdate();
});

//FUNCTION FOR FORM UPDATE
function FormUpdate() {
    try {
        const dataString = GetJobHeaderData();
        if (dataString == false)
            return;
        let Vflag = 0;

        let ContainerDetails = new Array();
        let InvoiceDetails = new Array();
        let ItemDetails = new Array();
        let LicenseDetails = new Array();
        let DestuffDetails = new Array();
        let BondDetails = new Array();
        let CertificateDetails = new Array();
        let JobSupportDocsDetails = new Array();

        Vflag = ValidateContainerDetailsData(); //VALIDATE CONTAINER DETAILS DATA

        if (Vflag == 0) {
            ContainerDetails = GetContainerDetailsData(); //RETURN CONTAINER DETAILS DATA
            dataString.containerDetails = ContainerDetails;
            Vflag = ValidateInvoiceDetailsData(); //VALIDATE INVOICE DETAILS DATA
            if (Vflag == 0) {
                InvoiceDetails = GetInvoiceDetailsData(); //RETURN INVOICE DETAILS DATA
                dataString.invoiceDetails = InvoiceDetails;

                Vflag = ValidateNtWtGrWtInVl(); //VALIDATE NET WEIGHT,GROSS WEIGHT AND INVOICE VALUE
                if (Vflag == 0) {
                    Vflag = ValidateAllInvVlWtAllItem();  //VALIDATE ALL INVOICE WITH VALUE WITH ALL ITEM
                    if (Vflag == 0) {
                        Vflag = ValidateItemDetailsData();  //VALIDATE ITEM DETAILS DATA
                        if (Vflag == 0) {
                            ItemDetails = GetItemDetailsData(); //RETURN ITEM DETAILS DATA
                            dataString.itemDetails = ItemDetails;

                            Vflag = ValidateLicenseDetailsData();  //VALIDATE LICENSE DETAILS DATA
                            if (Vflag == 0) {
                                Vflag = ValidateLicenseDataItemDetailsData()  //VALIDATE ALL ITEM WITH ALL LICENSE
                                if (Vflag == 0) {
                                    LicenseDetails = GetLicenseDetailsData(); //RETURN LICENSE DETAILS DATA
                                    dataString.licenseDetails = LicenseDetails;
                                    Vflag = ValidateDestuffDetailsData();  //VALIDATE DESTUFF DETAILS DATA
                                    if (Vflag == 0) {

                                        DestuffDetails = GetDestuffDetailsData() //RETURN DESTUFF DETAILS DATA
                                        dataString.destuffDetails = DestuffDetails;

                                        BondDetails = GetBondDetailsData(); //RETURN BOND DETAILS DATA
                                        dataString.bondDetails = BondDetails;

                                        CertificateDetails = GetCertificateDetailsData(); //RETURN CERTIFICATE DETAILS DATA
                                        dataString.certificateDetails = CertificateDetails;

                                        JobSupportDocsDetails = GetJobSupportDocsDetailsData();  //RETURN JOB SUPPORT DOCS DETAILS DATA
                                        dataString.jobSupportDocsDetails = JobSupportDocsDetails;

                                        AjaxSubmission(JSON.stringify(dataString), "/Master/ImportJobEntry/FormUpdate", $('[name="__RequestVerificationToken"]').val()).done(function (result) {
                                            let obj = result;
                                            if (obj.status == true) {
                                                if (obj.responsecode == '107') {
                                                    Toast(RetrieveMessage(obj.responsecode), "Message", "success");
                                                    $("#JobUid").val(obj.data.Table[0].JobUid);
                                                    $("#TimeStamp").val(obj.data.Table[0].timestamp);
                                                    FormList(1);
                                                }
                                                else if (obj.responsecode == '703')
                                                    Toast(obj.error, "Message", "error");
                                                else if (obj.responsecode == '1013')
                                                    Toast('Job Number Already Exist', 'Message', 'error');
                                                else
                                                    Toast(RetrieveMessage(obj.responsecode), "Message", "error", 2500);
                                            } else
                                                window.location.href = '/ClientLogin/ClientLogin';
                                            HideLoader();
                                        }).fail(function (result) {
                                            HideLoader();
                                            console.log(result.message);
                                        });
                                    }
                                }
                            }

                        }
                    }
                }

            }
        }

    }
    catch (e) {
        HideLoader();
        console.log(e.message);
    }

}

//#endregion

//#region /****************************FORM DELETE START**********************/

function FormDelete(id) {
    try {
        $.confirm({
            title: '',
            content: 'Are You Sure Want To Delete ?',
            type: 'red',
            boxWidth: '300px',
            useBootstrap: false,
            typeAnimated: true,
            columnClass: 'small',
            containerFluid: true,
            draggable: true,
            buttons: {
                tryAgain: {
                    text: 'Confirm',
                    btnClass: 'btn-red',
                    action: function () {
                        const dataString = {};
                        dataString.JobUid = id;
                        AjaxSubmission(JSON.stringify(dataString), "/ImportJobEntry/FormDelete", $('[name="__RequestVerificationToken"]').val()).done(function (data) {
                            let obj = data;
                            if (obj.status == true) {
                                if (obj.responsecode == '102') {
                                    Toast(RetrieveMessage(obj.responsecode), "Message", "success");
                                    FormList(1);
                                }
                                else
                                    Toast(RetrieveMessage(obj.responsecode), "Message", "error");
                            }
                            else
                                window.location.href = '/ClientLogin/ClientLogin';
                        }).fail(function (data) {
                            console.log(data.Message);
                        });
                    }
                },
                close: function () {
                }
            }
        });
    }
    catch (e) {
        console.log(e.message);
    }
}

//#endregion

//#region /****************************COMMON FUNCTION START**********************/

//FUNCTION FOR EXPORT DATA IN EXCEL
function FormExcel() {
    ShowLoader();
    let date = new Date();
    let NewDate = ("00" + date.getDate()).slice(-2) + "_" + ("00" + (date.getMonth() + 1)).slice(-2) + "_" + date.getFullYear() + "_" + ("00" + date.getHours()).slice(-2) + "_" + ("00" + date.getMinutes()).slice(-2) + "_" + ("00" + date.getSeconds()).slice(-2);
    let fileName = "ImportJob_" + NewDate + ".xlsx";

    $('#FormSearch').trigger('click');
    AjaxSubmission(null, '/Master/ImportJobEntry/FormExcel', $('input[name=__RequestVerificationToken]').val()).done(function (result) {
        let obj = result;
        if (obj.status == true) {
            if (obj.responsecode == '100') {

                let bytes = Base64ToBytes(obj.data.FileData[0].Base64Data);
                let blob = new Blob([bytes], { type: "application/octetstream" });
                let isIE = false || !!document.documentMode;
                if (isIE) {
                    window.navigator.msSaveBlob(blob, fileName);
                } else {
                    let url = window.URL || window.webkitURL;
                    link = url.createObjectURL(blob);
                    let a = $("<a />");
                    a.attr("download", fileName);
                    a.attr("href", link);
                    $("body").append(a);
                    a[0].click();
                    $("body").remove(a);
                }
            }
            else if (obj.responsecode == '302')
                Toast("No Records found.",'Message','success');
            else
                Toast(RetrieveMessage(obj.responsecode), 'Message', 'error');

        } else
            window.location.href = '/ClientLogin/ClientLogin';
        HideLoader();

    }).fail(function (result) {
        console.log(result.Message);
        HideLoader();
    });
}

//JOB DATE INPUT EVENT
$('#JobDate').on('input', function () {
    GetJobNo($('#JobType').val());
});

//COUNTRYORIGIN TEXTBOX BLUR EVENT
$('#CountryOrigin').blur(function () {
    $('#HiddenNewItemCountryOrigin').val($('#HiddenCountryOrigin').val());
    $('#NewItemCountryOrigin').val($('#CountryOrigin').val());
    if ($('#NewPlaceOfIssue').val() == '')
        $('#NewPlaceOfIssue').val($('#CountryOrigin').val());
});

//ADD DATEPICKER IN ALL TEXTBOX HAVING CLASS DATEPICKERALL
$(".datepickerAll").datepicker({
    toolbarPlacement: "bottom",
    showButtonPanel: true,
    changeMonth: true,
    changeYear: true,
    dateFormat: 'dd/mm/yy',
});

//FOR TODAY DATE
jQuery.datepicker._gotoToday = function (id) {
    let today = new Date();
    let dateRef = jQuery("<td><a>" + today.getDate() + "</a></td>");
    this._selectDay(id, today.getMonth(), today.getFullYear(), dateRef);
};

//ADD DATEPICKER FOR JOBDATE
$("#JobDate").datepicker({
    toolbarPlacement: "bottom",
    showButtonPanel: true,
    changeMonth: true,
    changeYear: true,
    dateFormat: 'dd/mm/yy',
    onClose: function (e) {
        GetJobNo($('#JobType').val());
    }
});

//ADD DATEPICKER FOR SEARCHJOBDATEFROM AND SEARCHJOBDATETO
$('#SearchJobDateFrom,#SearchJobDateTo').datepicker({
    toolbarPlacement: "bottom",
    showButtonPanel: true,
    changeMonth: true,
    changeYear: true,
    dateFormat: 'dd/mm/yy',
    onClose: function () {
        if ($('#SearchJobDateFrom').val().length == 10 || $('#SearchJobDateTo').val().length == 10)
            CompareSearchDate($('#SearchJobDateFrom').val(), $('#SearchJobDateTo').val(), 'JobDate');
    }
});

//SEARCHJOBDATEFROM ON INPUT EVENT
$('#SearchJobDateFrom').on('input', function () {
    if ($('#SearchJobDateFrom').val().length == 10)
        CompareSearchDate($('#SearchJobDateFrom').val(), $('#SearchJobDateTo').val(), 'JobDate');
});

//SEARCHJOBDATETO ON INPUT EVENT
$('#SearchJobDateTo').on('input', function () {
    if ($('#SearchJobDateTo').val().length == 10)
        CompareSearchDate($('#SearchJobDateFrom').val(), $('#SearchJobDateTo').val(), 'JobDate');
});

//ADD DATEPICKER FOR SEARCHBEDATEFROM AND SEARCHBEDATETO
$('#SearchBEDateFrom,#SearchBEDateTo').datepicker({
    toolbarPlacement: "bottom",
    showButtonPanel: true,
    changeMonth: true,
    changeYear: true,
    dateFormat: 'dd/mm/yy',
    onClose: function () {
        if ($('#SearchBEDateFrom').val().length == 10 || $('#SearchBEDateTo').val().length == 10)
            CompareSearchDate($('#SearchBEDateFrom').val(), $('#SearchBEDateTo').val(), 'BE Date');
    }
});

//SEARCHBEDATEFROM ON INPUT EVENT
$('#SearchBEDateFrom').on('input', function () {
    if ($('#SearchBEDateFrom').val().length == 10)
        CompareSearchDate($('#SearchBEDateFrom').val(), $('#SearchBEDateTo').val(), 'BE Date');
});

//SEARCHBEDATETO ON INPUT EVENT
$('#SearchBEDateTo').on('input', function () {
    if ($('#SearchBEDateTo').val().length == 10)
        CompareSearchDate($('#SearchBEDateFrom').val(), $('#SearchBEDateTo').val(), 'BE Date');
});

//ADD DATEPICKER FOR SEARCHEXPECTEDDATEFROM AND SEARCHEXPECTEDDATETO
$('#SearchExpectedDateFrom,#SearchExpectedDateTo').datepicker({
    toolbarPlacement: "bottom",
    showButtonPanel: true,
    changeMonth: true,
    changeYear: true,
    dateFormat: 'dd/mm/yy',
    onClose: function () {
        if ($('#SearchExpectedDateFrom').val().length == 10 || $('#SearchExpectedDateTo').val().length == 10)
            CompareSearchDate($('#SearchExpectedDateFrom').val(), $('#SearchExpectedDateTo').val(), 'Expected Date');
    }
});

//SEARCHEXPECTEDDATEFROM ON INPUT EVENT
$('#SearchExpectedDateFrom').on('input', function () {
    if ($('#SearchExpectedDateFrom').val().length == 10)
        CompareSearchDate($('#SearchExpectedDateFrom').val(), $('#SearchExpectedDateTo').val(), 'Expected Date');
});

//SEARCHEXPECTEDDATETO ON INPUT EVENT
$('#SearchExpectedDateTo').on('input', function () {
    if ($('#SearchExpectedDateTo').val().length == 10)
        CompareSearchDate($('#SearchExpectedDateFrom').val(), $('#SearchExpectedDateTo').val(), 'Expected Date');
});

//HIGHSEASALEFLAG CHECKBOX CLICKED EVENT
$("#HighSeaSaleFlag").click(function () {
    $('#HiddenHSSeller,#HSSeller,#HSSellerIECCode').val('');
    $('#HSSellerAddress').html('');
    $('#HSSLoadRate,#HSSLoadAmount').val('0.00');
    if ($('#HighSeaSaleFlag').is(':checked') == true) {
        $("#HSSeller").focus();
        $('#HssDiv').removeClass('d-none');
    }
    else
        $('#HssDiv').addClass('d-none');

});

//NEWSVBLOADCH CHECKBOX CLICKED EVENT
$('#NewSVBLoadCh').click(function () {
    $('#NewSVBNo,#NewSVBDate,#HiddenNewSVBCustomHouse,#NewSVBCustomHouse').val('');
    $('#NewSVBAssessableValue,#NewSVBDuty').val('0.00');

    if ($('#NewSVBLoadCh').is(':checked') == true)
        $('#SvbDiv').removeClass('d-none');
    else
        $('#SvbDiv').addClass('d-none');
});

//NEWSVBLOADTYPE DROPDOWN CHANGE EVENT
$('#NewSVBLoadType').change(function () {

    $('#NewSVBAssessableValue').attr('disabled', true);
    $('#NewSVBDuty').attr('disabled', true);

    if ($('#NewSVBLoadType').val() == "A") {
        $('#NewSVBAssessableValue').removeAttr('disabled');
        $('#NewSVBDuty').val('0.00');
    }
    else if ($('#NewSVBLoadType').val() == "D") {
        $('#NewSVBDuty').removeAttr('disabled');
        $('#NewSVBAssessableValue').val('0.00');
    }
    else
        $('#NewSVBAssessableValue,#NewSVBDuty').removeAttr('disabled');
});

//MODEOFTRANSPORT DROPDOWN CHANGE EVENT
$("#ModeOfTransport").change(function () {
    $("#CustomPortCode,#CustomPortName").val('');
});


//FUNCTION FOR GET FINANCIAL YEAR DATE
function GetFinancialYearDateJob() {
    try {
        AjaxSubmission(null, '/_Layout/GetFinancialYearDate', $('[name="__RequestVerificationToken"]').val()).done(function (result) {
            let obj = result;
            if (obj.status == true) {
                if (obj.responsecode == '100') {
                    $("#SearchJobDateFrom").val(obj.data.Table[0].finyr_start_date);
                    $("#SearchJobDateTo").val(obj.data.Table[0].finyr_end_date);
                }
            }
            else
                window.location.href = '/ClientLogin/ClientLogin';

        }).fail(function (result) {
            console.log(result.message);
        });
    }
    catch (e) {
        console.log(e.message);
    }
}

//SEARCH ARROW UP/DOWN
$('#oko').click(function () {
    if (srbtn == 'up') {
        $('#icn').html("<i class='fa-solid fa-angle-down'></i>");
        srbtn = 'down';
    } else {
        $('#icn').html("<i class='fa-solid fa-angle-up'></i>");
        srbtn = 'up';
    }
});

//JOB  ARROW UP/DOWN
$("#nko").click(function () {
    if (srbtn == 'up') {
        $("#icn1").html("<i class='fa-solid fa-angle-down'></i>");
        srbtn = 'down';
    } else {
        $("#icn1").html("<i class='fa-solid fa-angle-up'></i>");
        srbtn = 'up';
    }
});

// GOTOCONTAINERDETAILSTAB BUTTON CLICK EVENT
$('#GoToContainerDetailsTab').click(function () {
    $('#ShipmentDetails-tab').removeClass('active');
    $('#ContainerDetails-tab').addClass('active');
    $('#ShipmentDetails').removeClass('active show');
    $('#ContainerDetails').addClass('active show');
});

// BACKTOSHIPMENTDETAILSTAB BUTTON CLICK EVENT
$('#BackToShipmentDetailsTab').click(function () {
    $('#ContainerDetails-tab').removeClass('active');
    $('#ShipmentDetails-tab').addClass('active');
    $('#ContainerDetails').removeClass('active show');
    $('#ShipmentDetails').addClass('active show');
});

// GOTOINVOICEDETAILSTAB BUTTON CLICK EVENT
$('#GoToInvoiceDetailsTab').click(function () {
    $('#ContainerDetails-tab').removeClass('active');
    $('#InvoiceDetails-tab').addClass('active');
    $('#ContainerDetails').removeClass('active show');
    $('#InvoiceDetails').addClass('active show');
});

// BACKTOCONTAINERDETAILSTAB BUTTON CLICK EVENT
$('#BackToContainerDetailsTab').click(function () {
    $('#InvoiceDetails-tab').removeClass('active');
    $('#ContainerDetails-tab').addClass('active');
    $('#InvoiceDetails').removeClass('active show');
    $('#ContainerDetails').addClass('active show');
});

// GOTOEDIDETAILSTAB BUTTON CLICK EVENT
$('#GoToEDIDetailsTab').click(function () {
    $('#InvoiceDetails-tab').removeClass('active');
    $('#EDIDetails-tab').addClass('active');
    $('#InvoiceDetails').removeClass('active show');
    $('#EDIDetails').addClass('active show');
});

// BACKTOINVOICEDETAILSTAB BUTTON CLICK EVENT
$('#BackToInvoiceDetailsTab').click(function () {
    $('#EDIDetails-tab').removeClass('active');
    $('#InvoiceDetails-tab').addClass('active');
    $('#EDIDetails').removeClass('active show');
    $('#InvoiceDetails').addClass('active show');
});

// GOTOITEMDETAILSTAB BUTTON CLICK EVENT
$('#GoToItemDetailsTab').click(function () {
    $('#EDIDetails-tab').removeClass('active');
    $('#ItemDetails-tab').addClass('active');
    $('#EDIDetails').removeClass('active show');
    $('#ItemDetails').addClass('active show');
});

// BACKTOEDIDETAILSTAB BUTTON CLICK
$('#BackToEDIDetailsTab').click(function () {
    $('#EDIDetails-tab').addClass('active');
    $('#ItemDetails-tab').removeClass('active');
    $('#EDIDetails').addClass('active show');
    $('#ItemDetails').removeClass('active show');
});

// GOTOLICENSEDETAILSTAB BUTTON CLICK EVENT
$('#GoToLicenseDetailsTab').click(function () {
    $('#LicenseDetails-tab').addClass('active');
    $('#ItemDetails-tab').removeClass('active');
    $('#LicenseDetails').addClass('active show');
    $('#ItemDetails').removeClass('active show');
});

// BACKTOITEMDETAILSTAB BUTTON CLICK EVENT
$('#BackToItemDetailsTab').click(function () {
    $('#ItemDetails-tab').addClass('active');
    $('#LicenseDetails-tab').removeClass('active');
    $('#ItemDetails').addClass('active show');
    $('#LicenseDetails').removeClass('active show');
});

// GOTODESTUFFDETAILSTAB BUTTON CLICK EVENT
$('#GoToDestuffDetailsTab').click(function () {
    $('#DestuffDetails-tab').addClass('active');
    $('#LicenseDetails-tab').removeClass('active');
    $('#DestuffDetails').addClass('active show');
    $('#LicenseDetails').removeClass('active show');
});

// BACKTOLICENSEDETAILSTAB BUTTON CLICK EVENT
$('#BackToLicenseDetailsTab').click(function () {
    $('#LicenseDetails-tab').addClass('active');
    $('#DestuffDetails-tab').removeClass('active');
    $('#LicenseDetails').addClass('active show');
    $('#DestuffDetails').removeClass('active show');
});

// GOTOCFSCHARGEDETAILSTAB BUTTON CLICK EVENT
$('#GoToCFSChargeDetailsTab').click(function () {
    $('#CFSChargeDetails-tab').addClass('active');
    $('#DestuffDetails-tab').removeClass('active');
    $('#CFSChargeDetails').addClass('active show');
    $('#DestuffDetails').removeClass('active show');
});

// BACKTODESTUFFDETAILSTAB BUTTON CLICK EVENT
$('#BackToDestuffDetailsTab').click(function () {
    $('#DestuffDetails-tab').addClass('active');
    $('#CFSChargeDetails-tab').removeClass('active');
    $('#DestuffDetails').addClass('active show');
    $('#CFSChargeDetails').removeClass('active show');
});

// GOTOESANCHITDETAILSTAB BUTTON CLICK EVENT
$('#GoToESanchitDetails').click(function () {
    $('#ESanchitDetails-tab').addClass('active');
    $('#CFSChargeDetails-tab').removeClass('active');
    $('#ESanchitDetails').addClass('active show');
    $('#CFSChargeDetails').removeClass('active show');
});

// BACKTOCFSCHARGEDETAILSTAB BUTTON CLICK EVENT
$('#BackToCFSChargeDetailsTab').click(function () {
    $('#CFSChargeDetails-tab').addClass('active');
    $('#ESanchitDetails-tab').removeClass('active');
    $('#CFSChargeDetails').addClass('active show');
    $('#ESanchitDetails').removeClass('active show');
});

// GOTOBONDDETAILSTAB BUTTON CLICK EVENT
$('#GoToBondDetailsTab').click(function () {
    $('#BondDetails-tab').addClass('active');
    $('#ESanchitDetails-tab').removeClass('active');
    $('#BondDetails').addClass('active show');
    $('#ESanchitDetails').removeClass('active show');
});

// BACKTOBONDDETAILSTAB BUTTON CLICK EVENT
$('#BackToESanchitDetailsTab').click(function () {
    $('#ESanchitDetails-tab').addClass('active');
    $('#BondDetails-tab').removeClass('active');
    $('#ESanchitDetails').addClass('active show');
    $('#BondDetails').removeClass('active show');
});

// GOTOCERTIFICATEDETAILSTAB BUTTON CLICK EVENT
$('#GoToCertificateDetailsTab').click(function () {
    $('#CertificateDetails-tab').addClass('active');
    $('#BondDetails-tab').removeClass('active');
    $('#CertificateDetails').addClass('active show');
    $('#BondDetails').removeClass('active show');
});

// BACKTOBONDDETAILSTAB BUTTON CLICK EVENT
$('#BackToBondDetailsTab').click(function () {
    $('#BondDetails-tab').addClass('active');
    $('#CertificateDetails-tab').removeClass('active');
    $('#BondDetails').addClass('active show');
    $('#CertificateDetails').removeClass('active show');
});

//SUB JOB NUMBER TEXT BLUR EVENT
$('#SubJobNo').blur(function () {
    GetJobNo($('#JobType').val());
})

//SELECT BRANCH DROPDOWN CHANGE EVENT
$('#SelectBranch').change(function () {
    GetJobNo($('#JobType').val());
    GetBranchIceGateUserId();
});

//FUNCTION FOR GET ICE GATE USER ID
function GetBranchIceGateUserId() {
    try {
        const dataString = {};
        dataString.BranchId = $("#SelectBranch").val();
        AjaxSubmission(JSON.stringify(dataString), '/_Layout/GetBranchIceGateUserId', $('[name="__RequestVerificationToken"]').val()).done(function (result) {
            let obj = result;
            if (obj.status == true) {
                if (obj.responsecode == '100') {
                    if (obj.data.Table[0].ICEGATEUserId == null)
                        $('#IceGateUserId').val(0);
                    else if ($("#IceGateUserId option[value='" + obj.data.Table[0].ICEGATEUserId + "']").length > 0)
                        $('#IceGateUserId').val(obj.data.Table[0].ICEGATEUserId);
                } else
                    $('#IceGateUserId').val(0);
            }
            else
                window.location.href = '/ClientLogin/ClientLogin';
        }).fail(function (result) {
            console.log(result.message);
        });
    }
    catch (e) {
        console.log(e.message);
    }
}

//FUNCTION FOR GET JOB NUMBER
function GetJobNo(JobType) {
    try {
        if ($('#SelectBranch').val() > 0 && $('#JobDate').val().trim().length == 10) {
            const dataString = {};
            dataString.BranchId = $('#SelectBranch').val();
            dataString.JobDate = $('#JobDate').val();
            if (jobflag != 1)
                dataString.SubJobNo = $('#SubJobNo').val();
            dataString.JobUid = $('#JobUid').val();
            dataString.JobType = JobType;
            AjaxSubmission(JSON.stringify(dataString), '/ImportJobEntry/GetJobno', $('[name="__RequestVerificationToken"]').val()).done(function (result) {
                let obj = result;
                if (obj.status == true) {
                    if (obj.responsecode == '100') {
                        if (obj.data.Table[0].In_Valid_Job_No == false) {
                            $('#JobNo,#SubJobNo').val('');
                            $('#JobNo').val(obj.data.Table[0].job_no);
                            $('#SubJobNo').val(obj.data.Table[0].sub_job_no);
                            if (jobflag == 1) {
                                if (JobAc == 1) {
                                    jobflag = 0;
                                    JobAc = 0;
                                    FormAdd();
                                }
                                else if (JobAc == 2) {
                                    jobflag = 0;
                                    JobAc = 0;
                                    FormUpdate();
                                }
                            }
                        }
                        else
                            Toast('Job Number Already Exist', 'Message', 'error');
                    }
                    else
                        Toast(RetrieveMessage(obj.responsecode), 'Message', 'error');

                }
                else
                    window.location.href = '/ClientLogin/ClientLogin';

            }).fail(function (result) {
                console.log(result.message);
            });
        } else
            $('#JobNo,#SubJobNo').val('');
    }
    catch (e) {
        console.log(e.message);
    }
}

// FUNCTION FOR NEW JOB NUMBER CONFIRMATION
function NewJobNoConfirmation() {
    try {
        $.confirm({
            title: '',
            content: 'This Job Number has been used.',
            type: 'green',
            boxWidth: '300px',
            useBootstrap: false,
            typeAnimated: true,
            columnClass: 'small',
            containerFluid: true,
            draggable: true,
            buttons: {
                tryAgain: {
                    text: 'Confirm',
                    btnClass: 'btn-green',
                    action: function () {
                        jobflag = 1;
                        GetJobNo($('#JobType').val());
                    }
                },
                cancel: function () {
                    $('#JobDate').focus();
                }
            }
        });
    }
    catch (e) {
        console.log(e.message);
    }
};

//PAGE SIZE CHANGE
$('#ddlPageSize').change(function () {
    FormList(1);
});

//PAGINATION BUTTON CLICKED
$(document).on('click', '.pagination .page', function () {
    FormList(($(this).attr('page')));
});

//FORMSEARCH BUTTON CLICK 
$('#FormSearch').click(function () {
    FormList(1);
});

//FUNCTION FOR GET FORM LIST DATA
function FormList(PageIndex) {
    try {
        const dataString = {};
        dataString.PageSize = $('#ddlPageSize').val();
        dataString.PageIndex = PageIndex;
        dataString.OrderBy = $('#sort-column').val().trim() + ' ' + $('#sort-type').val().trim();
        dataString.SearchJobDateFrom = $('#SearchJobDateFrom').val();
        dataString.SearchJobDateTo = $('#SearchJobDateTo').val();
        dataString.SearchCustomPortCode = $('#SearchCustomPortCode').val();
        dataString.SearchSubJobNo = $('#SearchSubJobNo').val().trim();
        dataString.SearchJobNo = $('#SearchJobNo').val();
        dataString.SearchClient = $('#HiddenSearchClient').val().trim();
        dataString.SearchBENo = $('#SearchBENo').val().trim();
        dataString.SearchBEDateFrom = $('#SearchBEDateFrom').val();
        dataString.SearchBEDateTo = $('#SearchBEDateTo').val();
        dataString.SearchShipper = $('#HiddenSearchShipper').val().trim();
        dataString.SearchShippingLine = $('#HiddenSearchShippingLine').val().trim();
        dataString.SearchPortLoading = $('#SearchPortLoading').val();
        dataString.SearchPortDischarge = $('#SearchPortDischarge').val().trim();
        dataString.SearchDeliveryPlace = $('#SearchDeliveryPlace').val().trim();
        dataString.SearchExpectedDateFrom = $('#SearchExpectedDateFrom').val();
        dataString.SearchExpectedDateTo = $('#SearchExpectedDateTo').val();
        dataString.SearchContainerNo = $('#SearchContainerNo').val().trim();
        dataString.PendingJob = $('#PendingJob').is(':checked');
        dataString.ClearedJob = $('#ClearedJob').is(':checked');
        dataString.CancelJob = $('#CancelJob').is(':checked');
        dataString.BilledJob = $('#BilledJob').is(':checked');
        dataString.UnBilledJob = $('#UnBilledJob').is(':checked');
        dataString.SearchNetWeight = HandleNullNumericValue($('#SearchNetWeight').val().trim());
        dataString.SearchSelectBranch = $('#SearchSelectBranch').val();
        dataString.SearchJobType = $('#SearchJobType').val();
        dataString.SearchBEType = $('#SearchBEType').val();
        dataString.SearchIGMNo = $('#SearchIGMNo').val().trim();
        dataString.SearchBLNo = $('#SearchBLNo').val().trim();

        AjaxSubmission(JSON.stringify(dataString), '/Master/ImportJobEntry/FormList', $('input[name=__RequestVerificationToken]').val()).done(function (result) {
            let obj = result;

            if (obj.status == true) {
                if (obj.responsecode == '100') {
                    let Ser = ((parseInt(obj.data.Table1[0].PageIndex) - 1) * parseInt(obj.data.Table1[0].PageSize)) + 1;

                    BindFormTable(obj.data.Table, Ser);

                    $('.pagination').BindPaging({
                        ActiveCssClass: 'current',
                        PagerCssClass: 'pager',
                        PageIndex: parseInt(obj.data.Table1[0].PageIndex),
                        PageSize: parseInt(obj.data.Table1[0].PageSize),
                        RecordCount: parseInt(obj.data.Table1[0].count)
                    });                  
                    if (firssr == 1) {

                        $('#TblImport tbody tr:eq(0)').find('.Edit').focus();
                        //$('#TblImport tbody tr').each(function (ind, ele) {
                        //    if (ind == 0)
                        //        $(ele).find('.Edit').focus();
                        //});
                    }
                    else
                        $('#SearchSubJobNo').focus();
                    firssr = 1;
                }
                else if (obj.responsecode == '703')
                    Toast(obj.error, 'Message', 'error');
                else
                    Toast(RetrieveMessage(obj.responsecode), 'Message', 'error');
            } else
                window.location.href = '/ClientLogin/ClientLogin';
        }).fail(function (result) {
            console.log(result.Message);
        });
    }
    catch (e) {
        console.log(e.message);
    }
}

//FUNCTION  FOR BIND FORM TABLE
function BindFormTable(Result, SerialNo) {
    let tr = "";
    $("#TblImport tbody tr").remove();

    if (Result.length == 0) {
        tr = "<tr>";
        tr += "<td class='text-center' colspan='17'>NO RECORDS FOUND</td></tr>";
        $("#TblImport tbody").html(tr);

    } else {
        for (i = 0; i < Result.length; i++) {
            if (HandleNullTextValue(Result[i].BENo) == '')
                tr += '<tr style="background-color:#fdd2d2;"/>';
            else if (HandleNullTextValue(Result[i].BENo) != '')
                tr += "<tr>";
            else
                tr += "<tr>";

            tr += "<td class='text-left'><button type='button' title='Edit Job' onclick='FormEdit(\"" + Result[i].JobUid + "\");' class= 'Edit common-btn common-btn-sm ' ><i class='fa-regular fa-pen-to-square'></i></button > <button type='button' title='Delete Job' onclick='FormDelete(\"" + Result[i].JobUid + "\");' class= 'Delete common-btn common-btn-sm ' > <i class='fa-regular fa-trash-can'></i></button> <button type='button' title='Check List' onclick='ImportCheckList(\"" + Result[i].JobUid + "\");' class= ' common-btn common-btn-sm ' > <i class='fa-solid fa-list-check'></i></button> <button type='button' title='Generate Flat File' onclick='GenerateFlatFile(\"" + Result[i].JobUid + "\");' class= ' common-btn common-btn-sm '><i class='fa-regular fa-file'></i></button> <button type='button' title='Bill Of Entry' onclick='GetBillOfEntryFile(\"" + Result[i].JobUid + "\");' class= ' common-btn common-btn-sm '><i class='fa-regular fa-file-pdf'></i></button> <button type='button' title='Job Attachments' onclick='JobAttachment(\"" + Result[i].JobUid + "\",\"" + Result[i].JobNo+"\");' class='common-btn common-btn-sm'><i class='fa-solid fa-paperclip'></i></button></td>";

            tr += "<td class='text-left'>" + SerialNo + "</td>";
            tr += "<td class='text-left'>" + Result[i].BranchName + "</td>";
            tr += "<td class='text-left'>" + HandleNullTextValue(Result[i].CustomPortName) + "</td>";
            tr += "<td class='text-left fw-bold'>" + Result[i].SubJobNo + "</td>";
            tr += "<td><a href='javascript:void(0)' class='text-decoration-none fw-bold' style='color: black !important;' onclick='FormEdit(\"" + Result[i].JobUid + "\");'>" + Result[i].JobNo + "</a></td>";
            tr += "<td class='text-center'>" + Result[i].JobDate + "</td>";
            tr += "<td class='text-left'>" + HandleNullTextValue(Result[i].BENo) + "</td>";
            tr += "<td class='text-center'>" + HandleNullTextValue(Result[i].BEDate) + "</td>";
            tr += "<td class='text-center'>" + HandleNullTextValue(Result[i].BEType) + "</td>";
            tr += "<td class='text-left'>" + HandleNullTextValue(Result[i].ClientName) + "</td>";
            tr += "<td class='text-left'>" + HandleNullTextValue(Result[i].ItemCode) + "</td>";
            tr += "<td class='text-left'>" + HandleNullTextValue(Result[i].NoOfPkgs) + "</td>";
            tr += "<td class='text-left'>" + HandleNullTextValue(Result[i].NoOfContainer) + "</td>";
            tr += "<td class='text-end'>" + (Result[i].TotalNetWeight == null ? ' ' : Result[i].TotalNetWeight.toFixed(3)) + "</td>";
            tr += "<td class='text-end'>" + (Result[i].DutyAmount == null ? ' ' : Result[i].DutyAmount.toFixed(2)) + "</td>";
            tr += "<td class='text-center'>" + HandleNullTextValue(Result[i].CreatedBy) + "</td>";
            tr += "<td class='text-center'>" + HandleNullTextValue(Result[i].CreatedAt) + "</td>";
            tr += "<td class='text-center'>" + HandleNullTextValue(Result[i].LastUpdatedBy) + "</td>";
            tr += "<td class='text-center'>" + HandleNullTextValue(Result[i].LastUpdatedAt) + "</td>";


            let Finyr = Result[i].FinYr;

            let GenLink = "";
            if (Result[i].AllBillUid != null) {
                let AllBillUid = Result[i].AllBillUid.split(",");
                let AllBillNo = Result[i].AllBillNo.split(",");
                let AllFinyrId = Result[i].AllFinYrId.split(",");
                $.each(AllBillUid, function (ind, ele) {
                    if (AllFinyrId[ind] == Finyr)
                        GenLink += "<a href='javascript:void(0)' class='text-break text-decoration-none fw-bold BillLink' onclick='EditBillDetails(\"" + ele + "\");'>" + AllBillNo[ind] + "</a> ";
                    else
                        GenLink += AllBillNo[ind] + " ";
                });
                tr += "<td class='text-end'>" + GenLink + "</td>";
            }
            else
                tr += "<td class='text-end'>" + GenLink + "</td>";

            tr += "<td class='text-end'>" + (Result[i].TotalBillAmount == null ? '0.00' : Result[i].TotalBillAmount.toFixed(2)) + "</td>";

            SerialNo++;

        }

        $("#TblImport tbody").html(tr);

    }

}

//FUNCTION FOR FORM SORTING
function FormSorting(obj) {

    if (Firstcolumn != "") {
        document.getElementById(Firstcolumn).innerHTML = document.getElementById(Firstcolumn).getAttribute("data-column") + " <i style='margin-left:10px;' class='fa-solid fa-sort'></i>";
    }
    let cn = obj.id;
    Firstcolumn = cn;
    let colname = $(obj).data('column');
    $('#sort-column').val(cn.replaceAll('_', ''));
    let sorttype = $('#sort-type').val();
    if (sorttype == 'ASC') {
        $('#sort-type').val('DESC');
        $(obj).html(colname + " <i style='margin-left:10px;' class='fa-solid fa-sort-down'></i>");
    } else if (sorttype == 'DESC') {
        $('#sort-type').val('ASC');
        $(obj).html(colname + " <i style='margin-left:10px;' class='fa-solid fa-sort-up'></i>");
    }
    FormList(1);
}

//FUNCTIO FOR CALCULATE ASSESSABLE VALUE CIF VALUE AND DUTY AMOUNT
function CalcAssCifDuty() {
    let T_Cif = 0, T_Dty = 0;
    $('#TblItemDetails tbody tr').each(function (ind, ele) {
        T_Cif += parseFloat(HandleNullNumericValue($(ele).find('.TblItemCIFValue').val()));
        T_Dty += parseFloat(HandleNullNumericValue($(ele).find('.TblItemDutyAmount').val()));
    });
    $('#CIFValue').val(T_Cif.toFixed(2));
    $('#DutyAmount').val(T_Dty.toFixed(2));
}

//FUNCTION FOR VALID  ASSESSABLE VALUE,CIF VALUE AND DUTY AMOUNT
function ValidateAssCifDuty() {
    let T_Ass = 0, T_Cif = 0, T_Dty = 0;
    $('#TblItemDetails tbody tr').each(function (ind, ele) {
        /* T_Ass += parseFloat(HandleNullNumericValue($(ele).find('.ItemAssessableValue').val()));*/
        T_Cif += parseFloat(HandleNullNumericValue($(ele).find('.TblItemCIFValue').val()));
        T_Dty += parseFloat(HandleNullNumericValue($(ele).find('.TblItemDutyAmount').val()));

    });

    T_Ass = T_Ass.toFixed(2);
    T_Cif = T_Cif.toFixed(2);
    T_Dty = T_Dty.toFixed(2);

    let F_Ass = 0, F_Cif = 0, F_Dty = 0;

    F_Ass = parseFloat(HandleNullNumericValue($('#AssessableValue').val()));
    F_Cif = parseFloat(HandleNullNumericValue($('#CIFValue').val()));
    F_Dty = parseFloat(HandleNullNumericValue($('#DutyAmount').val()));

    if (T_Ass != F_Ass) {
        Toast('Total Assessable Value Not Matched.', 'Message', 'error');
        return 1;
    }
    if (T_Cif != F_Cif) {
        Toast('Total CIF Value Not Matched.', 'Message', 'error');
        return 1
    }
    if (T_Dty != F_Dty) {
        Toast('Total Duty Amount Not Matched.', 'Message', 'error');
        return 1
    }
    return 0;
}

//FUNCTION FOR CALCULATE DUTY
function DutyCalculation() {
    $("#TblInvoiceDetails tbody tr").each(function (InvInd, InvEle) {
        let Inv_Ser, Inv_Amt, Inv_Exch_Rate, Inv_Misc_Chrg, Inv_Misc_Chrg_Inr, Inv_Fr_Inr, Inv_Ins_Inr, Inv_Load_Inr, Hss_Load, _Amt = 0;
        let It_Inv;

        Inv_Ser = InvInd + 1;

        Inv_Amt = HandleNullNumericValue($(InvEle).find('.InvoiceValue').val());
        Inv_Exch_Rate = HandleNullNumericValue($(InvEle).find('.InvoiceCurrencyExchangeRate').val());
        Inv_Misc_Chrg = HandleNullNumericValue($(InvEle).find('.MiscCharges').val());
        Inv_Misc_Chrg_Inr = HandleNullNumericValue($(InvEle).find('.MiscChargesINR').val());
        Inv_Fr_Inr = HandleNullNumericValue($(InvEle).find('.FreightINR').val());
        Inv_Ins_Inr = HandleNullNumericValue($(InvEle).find('.InsuranceINR').val());
        Inv_Load_Inr = HandleNullNumericValue($(InvEle).find('.LoadingINR').val());
        Hss_Load = HandleNullNumericValue($(InvEle).find('.TblHSSLoadAmount').val());
        It_Inv = $('#NewItemInvoiceNo option:selected').val();

        if (Inv_Amt > 0 && Inv_Exch_Rate > 0) {
            if (It_Inv == Inv_Ser) {
                let It_Amt = 0, It_Wt = 0, It_Un_Pr = 0, It_Frt = 0, It_Insu = 0, It_Misc_Chrg = 0, It_Load = 0, It_HSS = 0, It_Bcd_Per = 0, It_Bcd_Duty = 0, It_Cvd_Per, It_Cvd_Duty = 0, It_Sw_Per = 0, It_Sw_Duty = 0, It_Anti_Per = 0, It_Anti_Duty = 0, It_Safe_Per = 0, It_Safe_Duty = 0, It_Health_Per = 0, It_Health_Duty = 0;
                let It_Cif_Amt = 0, Igst_Per = 0, Igst_Amt = 0, It_Duty_Amt = 0, Exem_Igst_Per = 0, Exem_Igst_Amt = 0, Compen_Per = 0, Compen_Amt = 0, Exem_Compen_Per = 0, Exem_Compen_Amt = 0;

                if ($('#NewItemName').val().trim().length > 0 &&
                    HandleNullNumericValue($('#NewItemAmount').val()) > 0 &&
                    HandleNullNumericValue($('#NewItemQuantity').val()) > 0) {

                    //FOR UNIT PRICE
                    It_Amt = HandleNullNumericValue($('#NewItemAmount').val());
                    It_Wt = HandleNullNumericValue($('#NewItemQuantity').val());

                    _Amt = It_Amt * Inv_Exch_Rate;

                    It_Un_Pr = It_Amt / It_Wt;
                    $('#NewItemUnitPrice').val(It_Un_Pr.toFixed(6));

                    //FOR FREIGHT(INR)
                    if (Inv_Fr_Inr > 0) {
                        It_Frt = (Inv_Fr_Inr * It_Amt) / Inv_Amt;
                        $('#NewItemFreight').val(It_Frt.toFixed(2));
                        _Amt = _Amt + It_Frt;
                    }

                    //FOR INSURANCE(INR)
                    if (Inv_Ins_Inr > 0) {
                        It_Insu = (Inv_Ins_Inr * It_Amt) / Inv_Amt;
                        $('#NewItemInsurance').val(It_Insu.toFixed(2));
                        _Amt = _Amt + It_Insu;
                    }

                    //FOR MISCELLANEOUS CHARGE
                    if (Inv_Misc_Chrg > 0) {
                        It_Misc_Chrg = (Inv_Misc_Chrg * It_Amt) / Inv_Amt;
                        $('#NewItemMiscCharge').val(It_Misc_Chrg.toFixed(2));
                    }

                    //FOR MISCELLANEOUS CHARGES(INR)
                    if (Inv_Misc_Chrg_Inr > 0) {
                        It_Misc_Chrg = (Inv_Misc_Chrg_Inr * It_Amt) / Inv_Amt;
                        $('#NewItemMiscCharge').val(It_Misc_Chrg.toFixed(2));
                    }

                    _Amt = _Amt + It_Misc_Chrg;

                    //FOR LOADING
                    if (Inv_Load_Inr > 0) {
                        It_Load = (Inv_Load_Inr * It_Amt) / Inv_Amt;
                        $('#NewItemLoading').val(It_Load.toFixed(2));
                    }

                    _Amt = _Amt + It_Load;

                    //FOR HSS LOAD AMOUNT
                    if (Hss_Load > 0) {
                        It_HSS = (Hss_Load * It_Amt) / Inv_Amt;
                        $('#NewHSSLoadAmount').val(It_HSS.toFixed(2));
                    }

                    _Amt = _Amt + It_HSS;

                    It_Cif_Amt = _Amt;

                    $('#NewItemCIFValue').val(It_Cif_Amt.toFixed(2));

                    //FOR BASIC CUSTOMS DUTY (BCD)

                    It_Bcd_Per = HandleNullNumericValue($('#NewItemBCDRate').val());
                    $('#NewItemBCDAmount').val('0.00');

                    if (It_Bcd_Per > 0) {
                        It_Bcd_Duty = (It_Cif_Amt * It_Bcd_Per) / 100;
                        _Amt = It_Bcd_Duty;
                        $('#NewItemBCDAmount').val(It_Bcd_Duty.toFixed(2));
                    }

                    //FOR COUNTERVAILING DUTY (CVD)

                    It_Cvd_Per = HandleNullNumericValue($('#NewItemCVDRate').val());
                    $('#NewItemCVDAmount').val('0.00');

                    if (It_Cvd_Per > 0) {
                        It_Cvd_Duty = (It_Bcd_Duty * It_Cvd_Per) / 100;
                        _Amt = _Amt + It_Cvd_Duty;
                        $('#NewItemCVDAmount').val(It_Cvd_Duty.toFixed(2));
                    }

                    //FOR SOCIAL WELFARE 

                    It_Sw_Per = HandleNullNumericValue($('#NewSocialWelfareRate').val());
                    $('#NewSocialWelfareAmount').val('0.00');

                    if (It_Sw_Per > 0) {
                        It_Sw_Duty = (It_Bcd_Duty * It_Sw_Per) / 100;
                        _Amt = _Amt + It_Sw_Duty;
                        $('#NewSocialWelfareAmount').val(It_Sw_Duty.toFixed(2));
                    }

                    //FOR ANTIDUMPING DUTY

                    It_Anti_Per = HandleNullNumericValue($('#NewAntiDumpingDutyNotificationRate').val());
                    $('#NewAntiDumpingDutyNotificationAmount').val('0.00');

                    if (It_Anti_Per > 0) {
                        It_Anti_Duty = (It_Cif_Amt * It_Anti_Per) / 100;
                        _Amt = _Amt + It_Anti_Duty;
                        $('#NewAntiDumpingDutyNotificationAmount').val(It_Anti_Duty.toFixed(2));
                    }

                    //FOR SAFEGUARD DUTY

                    It_Safe_Per = HandleNullNumericValue($('#NewSafeguardDutyNotificationRate').val());
                    $('#NewSafeguardDutyNotificationAmount').val('0.00');

                    if (It_Safe_Per > 0) {
                        It_Safe_Duty = (It_Cif_Amt * It_Safe_Per) / 100;
                        _Amt = _Amt + It_Sw_Duty;
                        $('#NewSafeguardDutyNotificationAmount').val(It_Safe_Duty.toFixed(2));
                    }

                    //FOR HEALTH CESS

                    It_Health_Per = HandleNullNumericValue($().val());
                    $('#NewHealthNotificationAmount').val('0.00');

                    if (It_Health_Per > 0) {
                        It_Health_Duty = (It_Cif_Amt * It_Health_Per) / 100;
                        _Amt = _Amt + It_Health_Duty;
                        $('#NewHealthNotificationAmount').val(It_Health_Duty.toFixed(2));
                    }

                    //FOR IGST

                    Igst_Per = HandleNullNumericValue($('#NewIGSTNotificationRate').val());
                    $('#NewIGSTNotificationAmount').val('0.00');

                    if (Igst_Per > 0) {
                        Igst_Amt = ((It_Cif_Amt + It_Bcd_Duty + It_Sw_Duty + It_Health_Duty + It_Anti_Duty + It_Safe_Duty) * Igst_Per) / 100;
                        $('#NewIGSTNotificationAmount').val(Igst_Amt.toFixed(2));
                    }

                    //FOR EXEMPTION IGST

                    //Exem_Igst_Per = HandleNullNumericValue($('#NewIGSTExemNotificationRate').val());

                    //if (Exem_Igst_Per > 0 && Igst_Per > 0 && Exem_Igst_Per <= Igst_Per) {
                    //    Exem_Igst_Amt = ((It_Cif_Amt + It_Bcd_Duty + It_Sw_Duty + It_Health_Duty + It_Anti_Duty + It_Safe_Duty) * Exem_Igst_Per) / 100;
                    //    $('#NewIGSTExemNotificationAmount').val(Exem_Igst_Amt.toFixed(2));
                    //}
                    //else {
                    //    $('#NewIGSTExemNotificationRate').val('0.00');
                    //    $('#NewIGSTExemNotificationAmount').val('0.00');
                    //}

                    //FOR COMPENSATION  CESS

                    Compen_Per = HandleNullNumericValue($('#NewIGSTComCessNotificationRate').val());
                    $('#NewIGSTComCessNotificationAmount').val('0.00');

                    if (Compen_Per > 0) {
                        Compen_Amt = ((It_Cif_Amt + It_Bcd_Duty + It_Sw_Duty + It_Health_Duty + It_Anti_Duty + It_Safe_Duty + Igst_Amt) * Compen_Per) / 100;
                        $('#NewIGSTComCessNotificationAmount').val(Compen_Amt.toFixed(2));
                    }

                    //FOR EXEMPTION COMPENSATION CESS

                    //Exem_Compen_Per = HandleNullNumericValue($('#NewIGSTComCessExemNotificationRate').val());

                    //if (Exem_Compen_Per > 0 && Compen_Per > 0 && Exem_Compen_Per <= Compen_Per) {
                    //    Exem_Compen_Amt = ((It_Cif_Amt + It_Bcd_Duty + It_Sw_Duty + It_Health_Duty + It_Anti_Duty + It_Safe_Duty + Igst_Amt) * Exem_Compen_Per) / 100;
                    //    $('#NewIGSTComCessExemNotificationAmount').val(Exem_Compen_Amt.toFixed(2));
                    //}
                    //else {
                    //    $('#NewIGSTComCessExemNotificationRate').val('0.00');
                    //    $('#NewIGSTComCessExemNotificationAmount').val('0.00');
                    //}

                    //FOR DUTY AMOUNT

                    It_Duty_Amt = It_Bcd_Duty + It_Sw_Duty + It_Health_Duty + It_Anti_Duty + It_Safe_Duty + Igst_Amt - Exem_Igst_Amt + Compen_Amt - Exem_Compen_Amt;

                    $('#NewItemDutyAmount').val(It_Duty_Amt.toFixed(2));
                }
            }
        }
    });
}

//FUNCTION FOR CALCULATE NEW HSS LOAD AMOUNT
function NewCalcHSSLoadAmount(key) {
    let InvCif = 0, Inv = 0, Frt = 0, Ins = 0, Misc = 0, Load = 0, HssRate = 0, HssAmount = 0, InvRate = 0;
    if ($('#HighSeaSaleFlag').is(':checked') == true) {
        Inv = HandleNullNumericValue($('#NewInvoiceValue').val());
        InvRate = HandleNullNumericValue($('#NewInvoiceCurrencyExchangeRate').val());
        Frt = HandleNullNumericValue($('#NewFreightINRInvoice').val());
        Ins = HandleNullNumericValue($('#NewInsuranceINRInvoice').val());
        Misc = HandleNullNumericValue($('#NewMiscChargesINRInvoice').val());
        Load = HandleNullNumericValue($('#NewLoadingINRInvoice').val());
        HssRate = HandleNullNumericValue($('#HSSLoadRate').val());
        HssAmount = HandleNullNumericValue($('#HSSLoadAmount').val());

        if (key == 'HSSLoadRate') {
            InvCif = (((InvRate * Inv) + Frt + Ins + Misc + Load) * HssRate) / 100;
            $('#HSSLoadAmount').val(isNaN(InvCif) ? '0.00' : InvCif.toFixed(2));
        }
        else if (key == 'HSSLoadAmount') {
            InvCif = (HssAmount / ((InvRate * Inv) + Frt + Ins + Misc + Load)) * 100;
            $('#HSSLoadRate').val(isNaN(InvCif) ? '0.00' : InvCif.toFixed(2));
        }
        else if (HssRate > 0 && Inv > 0 && InvRate > 0) {
            InvCif = (((InvRate * Inv) + Frt + Ins + Misc + Load) * HssRate) / 100;
            $('#HSSLoadAmount').val(isNaN(InvCif) ? '0.00' : InvCif.toFixed(2));
        }

        //if (HssRate > 0 && Inv > 0 && InvRate > 0) {
        //    InvCif = (((InvRate * Inv) + Frt + Ins + Misc + Load) * HssRate) / 100;
        //    $('#HSSLoadAmount').val(isNaN(InvCif) ? '0.00' : InvCif.toFixed(2));
        //}
        //else if (HssAmount > 0 && Inv > 0 && InvRate > 0) {
        //    InvCif = (HssAmount / ((InvRate * Inv) + Frt + Ins + Misc + Load)) * 100;
        //    $('#HSSLoadRate').val(isNaN(InvCif) ? '0.00' : InvCif.toFixed(2));
        //}
    }
    else
        $('#HSSLoadRate,#HSSLoadAmount').val('0.00');

}

//FUNCTION FOR FILL LETTER DETAILS
function FillLetters(e) {
    try {
        const dataString = {};
        dataString.JobNo = e;
        AjaxSubmission(JSON.stringify(dataString), "/ImportJobEntry/GetLetters", $('[name="__RequestVerificationToken"]').val()).done(function (data) {
            let obj = data;
            if (obj.status == true) {
                if (obj.responsecode == '100')
                    BindLetters(obj.data.Table);
            }
            else
                window.location.href = '/ClientLogin/ClientLogin';
        }).fail(function (data) {
            console.log(data.Message);
        });
    }
    catch (e) {
        console.log(e.message);
    }
}

//FUNCTION FOR BIND ALL LETTER AGAINST JOB
function BindLetters(Result) {
    $('#TblLetters tbody tr').remove();
    if (Result.length == 0) {
        tr = $('<tr/>');
        tr.append("<td class='text-center' colspan='6'>NO RECORDS FOUND</td>");
        $('#TblLetters tbody').append(tr);
    } else {
        for (i = 0; i < Result.length; i++) {
            tr = $('<tr/>');
            tr.append("<td class='text-left'><button type='button' title='Edit Letter' onclick='EditLetters(\"" + Result[i].LetterAssignUid + "\");' class= 'Edit common-btn common-btn-sm ms-4 me-2'><i class='fa-solid fa-pen-to-square'></i></button>" + (i + 1) + "</td>");

            tr.append("<td><a href='javascript:void(0)' class='text-decoration-none' style='color: black !important;' onclick='EditLetters(\"" + Result[i].LetterAssignUid + "\");'>" + HandleNullTextValue(Result[i].LetterName) + "</a></td>");
            tr.append("<td class='text-center'>" + HandleNullTextValue(Result[i].CreatedBy) + "</td>");
            tr.append("<td class='text-center'>" + HandleNullTextValue(Result[i].CreatedAt) + "</td>");
            tr.append("<td class='text-center'>" + HandleNullTextValue(Result[i].LastUpdatedBy) + "</td>");
            tr.append("<td class='text-center'>" + HandleNullTextValue(Result[i].LastUpdatedAt) + "</td>");

            $('#TblLetters tbody').append(tr);
        }
    }
}

//FUNCTION FOR EDIT LETTERS
function EditLetters(e) {
    SetCookie('LettersId', e, 's', 50);
    window.open('/Master/Letters/Letters', '_blank');
}

//FUNCTION FOR FILL JOB DETAILS
function FillBillDetails(e) {
    try {
        const dataString = {};
        dataString.JobUid = e;
        AjaxSubmission(JSON.stringify(dataString), "/ImportJobEntry/GetBillDetails", $('[name="__RequestVerificationToken"]').val()).done(function (data) {
            let obj = data;
            if (obj.status == true) {
                if (obj.responsecode == '100')
                    BindBillDetails(obj.data.Table);
            }
            else
                window.location.href = '/ClientLogin/ClientLogin';
        }).fail(function (data) {
            console.log(data.Message);
        });
    }
    catch (e) {
        console.log(e.message);
    }
}

//FUNCTION FOR BIND ALL BILL JOB
function BindBillDetails(Result) {
    $('#TblBillDetails tbody tr').remove();
    if (Result.length == 0) {
        tr = $('<tr/>');
        tr.append("<td class='text-center' colspan='8'>NO RECORDS FOUND</td>");
        $('#TblBillDetails tbody').append(tr);
    } else {
        for (i = 0; i < Result.length; i++) {
            tr = $('<tr/>');
            tr.append("<td class='text-left'><button type='button' title='Edit Bill' onclick='EditBillDetails(\"" + Result[i].BillUid + "\");' class= 'Edit common-btn common-btn-sm ms-4 me-2'><i class='fa-solid fa-pen-to-square'></i></button>" + (i + 1) + "</td>");
            tr.append("<td class='text-center'>" + HandleNullTextValue(Result[i].BillTypeName) + "</td>");

            tr.append("<td><a href='javascript:void(0)' class='text-decoration-none' style='color: black !important;' onclick='EditBillDetails(\"" + Result[i].BillUid + "\");'>" + HandleNullTextValue(Result[i].BillNo) + "</a></td>");

            tr.append("<td class='text-center'>" + HandleNullTextValue(Result[i].BillDate) + "</td>");
            tr.append("<td class='text-center'>" + HandleNullTextValue(Result[i].AccHead) + "</td>");


            tr.append("<td class='text-end'>" + HandleNullTextValueFixed(Result[i].TotalAmount, 2) + "</td>");
            tr.append("<td class='text-end'>" + HandleNullTextValueFixed(Result[i].TaxAmount, 2) + "</td>");
            tr.append("<td class='text-end'>" + HandleNullTextValueFixed(Result[i].NetAmount, 2) + "</td>");

            $('#TblBillDetails tbody').append(tr);
        }
    }
}

//FUNCTION FOR EDIT BILL DETAILS
function EditBillDetails(e) {
    SetCookie('BillEntryUid', e, 's', 50);
    window.open('/Master/BillEntry/BillEntry', '_blank');
}

//IMPORT JOB TAB CLCIKED
$("#ImportJob-tab").click(function () {
    $('#uju').removeAttr('style');
    $("#SubJobNo").focus();
});

//IMPORT JOB LIST TAB CLICKED
$("#ImportJob_list-tab").click(function () {
    $("#SearchSubJobNo").focus();
    ResetForm();
    TabHide();
    $('#uju').removeAttr('style');
});



//LETTERS DETAILS,BILL DETAILS,DOCUMENT DETAILS TAB CLICKED
$("#LettersDetails-tab,#BillDetails-tab,#DocumentDetails-tab").click(function () {
    $('#uju').css({ 'overflow': 'scroll', 'height': parseInt(screen.height) - 335 });
});

//FUCNTION FOR TAB SHOW
function TabShow() {
    $('#ImportJob_list-tab').removeClass('active');
    $('#ImportJob-tab').addClass('active');
    $('#ImportJob_list').removeClass('active show');
    $('#ImportJob').addClass('active show');

    $('#FormAdd').hide();
    $('#FormUpdate,#FormReset,#GenFlatFile,#GenCheckList,#ShipLineCharges,#CFSCharges').show();
    $('#ImportJob-tab').html('Edit Job');

    $('#LettersDetails-tab,#BillDetails-tab,#DocumentDetails-tab').removeClass('d-none');
}

//FUNCTION FOR TAB HIDE
function TabHide() {
    $('#ImportJob-tab').removeClass('active');
    $('#ImportJob_list-tab').addClass('active ');
    $('#ImportJob_list').addClass('active show');
    $('#ImportJob').removeClass('active show');

    $('#FormAdd').show();
    $('#FormUpdate,#FormReset,#GenFlatFile,#GenCheckList,#ShipLineCharges,#CFSCharges').hide();
    $('#ImportJob-tab').html('Add Job');

    $('#LettersDetails-tab,#BillDetails-taB,#DocumentDetails-tab').addClass('d-none');
    $('#TblLetters tbody').html('');
    $('#BillDetails tbody').html('');
    $('#DocumentDetails tbody').html('');

}

//FORM RESET BUTTON CLICKED
$('#FormReset').click(function () {
    $('#FormAdd').show();
    $('#FormUpdate,#FormReset,#GenFlatFile,#GenCheckList,#ShipLineCharges,#CFSCharges').hide();
    $('#ImportJob-tab').html('Add Job');
    ResetForm();
});

//GENCHECKLIST BUTTON CLICKED
$('#GenCheckList').click(function () {
    ImportCheckList($('#JobUid').val());
});

//FUNCTION FOR IMPORT JOB CHECK LIST
function ImportCheckList(JobUid) {
    try {
        const datastring = {};
        datastring.JobUid = JobUid;
        AjaxSubmission(JSON.stringify(datastring), "/Master/ImportJobEntry/DownloadCheckList", $('input[name=__RequestVerificationToken]').val()).done(function (result) {
            let obj = result;
            if (obj.status == true) {
                if (obj.responsecode == '100')
                    window.open($('#CheckListPdf').attr('href'), '_blank');
                else
                    Toast(RetrieveMessage(obj.responsecode), 'Message', 'error');
            }
            else
                window.location.href = '/ClientLogin/ClientLogin';
        }).fail(function (result) {
            console.log(result.Message);
        });
    }
    catch (e) {
        console.log(e.message);
    }
}

//GENFLATFILE BUTTON CLICKED
$('#GenFlatFile').click(function () {
    try {
        $('#FlatFileJobUid').val($('#JobUid').val());
        FlatFileModal.style.display = 'block';
    }
    catch (e) {
        console.log(e.message);
    }
});

//FUNCTION FOR GENERATE FLAT FILE
function GenerateFlatFile(e) {
    try {
        $('#FlatFileJobUid').val(e);
        FlatFileModal.style.display = 'block';
    }
    catch (e) {
        console.log(e.message);
    }
}

//POPUP FOR FLAT FILE DOWNLOAD
function DownLoadFlatFile(FileName) {
    try {
        $.confirm({
            title: '',
            content: 'Download Flat File ?',
            type: 'green',
            boxWidth: '300px',
            useBootstrap: false,
            typeAnimated: true,
            columnClass: 'small',
            containerFluid: true,
            draggable: true,
            buttons: {
                tryAgain: {
                    text: 'Confirm',
                    btnClass: 'btn-green',
                    action: function () {

                        const dataString = {};
                        dataString.FileName = FileName;

                        AjaxSubmission(JSON.stringify(dataString), '/ImportJobEntry/DownloadFlatfile', $('[name="__RequestVerificationToken"]').val()).done(function (data) {
                            let obj = data;
                            if (obj.status == true) {
                                if (obj.responsecode == '100') {
                                    let bytes = Base64ToBytes(obj.data[0].RawData);
                                    let Ext = obj.data[0].FileExt;

                                    //Convert Byte Array to BLOB.
                                    let blob = new Blob([bytes], { type: 'application/octetstream' });

                                    //Check the Browser type and download the File.
                                    let isIE = false || !!document.documentMode;
                                    if (isIE) {
                                        window.navigator.msSaveBlob(blob, FileName + Ext);
                                    } else {
                                        let url = window.URL || window.webkitURL;
                                        link = url.createObjectURL(blob);
                                        let a = $('<a />');
                                        a.attr('download', FileName + Ext);
                                        a.attr('href', link);
                                        $('body').append(a);
                                        a[0].click();
                                        $('body').remove(a);
                                    }
                                }
                            }
                            else
                                window.location.href = '/ClientLogin/ClientLogin';
                        }).fail(function (data) {
                            console.log(data.Message);
                        });
                    }
                },
                close: function () {
                },
            }, onContentReady: function () {
                $(".btn-green").focus();
            }
        });

    }
    catch (e) {
        console.log(e.message);
    }
}

//SHIPLINECHARGES BUTTON CLICKED
$('#ShipLineCharges').click(function () {
    let JobUid = $('#JobUid').val();
    let ImporterName = $('#HiddenImporterName').val();
    GetShipLineCFSCharges(JobUid, "ShipLineCharges", ImporterName);

});

//CFSCHARGES BUTTON CLICKED
$('#CFSCharges').click(function () {
    let JobUid = $('#JobUid').val();
    let ImporterName = $('#HiddenImporterName').val();
    GetShipLineCFSCharges(JobUid, "CFSCharges", ImporterName);
});

//FUNCTION FOR GET SHIPPING LINE CFS CHARGES
function GetShipLineCFSCharges(JobUid, ChargesType, ImporterName) {
    try {
        const dataString = {};
        dataString.JobUid = JobUid;
        dataString.ChargesType = ChargesType;
        dataString.ImporterName = ImporterName;
        ShowLoader();
        AjaxSubmission(JSON.stringify(dataString), '/ImportJobEntry/GetShipLineCFSCharges', $('[name="__RequestVerificationToken"]').val()).done(function (result) {
            let obj = result;
            if (obj.status == true) {
                if (obj.responsecode == '100') {
                    EmailModal.style.display = "block";
                    $("#EmailTo").val(obj.data.EmailData[0].Email);
                    $("#EmailCC").val(obj.data.EmailData[0].CCEmail);
                    $("#AttachFileName").text(obj.data.Table1[0].FileName);
                    $("#AttachedFilePath").val(obj.data.Table1[0].AttachmentFilePath);
                    $("#AttachFileName").attr("href", obj.data.Table1[0].FilePath);
                    $("#RefId").val($('#JobUid').val());
                    $("#SendToName").val(obj.data.EmailData[0].CCEmail);
                    $("#RefName").val('ChargesReport(ShippingOrCfs)');
                    BindTemplateName('AllTemplate', 'Email');
                    if (obj.data.Table1[0]["ReportName"] == "ShipLineCharges")
                        TemplateFor = "Shipping Line Charges";
                    else
                        TemplateFor = "CFS Charges"
                    FillTemplateDataInTincyMce($('#JobUid').val(), TemplateFor, null, 'Email', 'Shipping Charges');
                    HideLoader();
                }
                else if (obj.responsecode == '1042') {
                    HideLoader();
                    Toast(obj.error, 'Message', 'error');
                }
            } else
                window.location.href = '/ClientLogin/ClientLogin';
        }).fail(function (data) {
            HideLoader();
            console.log(data.Message);
        });
    }
    catch (e) {
        console.log(e.message);
    }
}

// FUNCTION FOR RESET IMPORT JOB DATA
function ResetForm() {

    hidImport = hidShip = hidItemMenu = '';
    $('#BEType').val('H');
    $('#WareHouseJD,#WareHouseDetails,#BondN,#BondD').addClass('d-none');

    $('#AmdJob').addClass('d-none');
    $('#JobType').val('I');

    $('#JobType').removeAttr('disabled');

    $('#collapseExample').addClass('show');
    $('#icn').html("<i class='fa-solid fa-angle-up'></i>");
    srbtn = 'up';

    const blankId = ['JobDate', 'JobUid', 'TimeStamp', 'JobNo', 'SubJobNo', 'BillNo', 'BillDate', 'HiddenImporterName', 'ImporterName', 'BranchCode', 'AdCode', 'BENo', 'BEDate', 'IGMNo', 'IGMItem', 'IGMDate', 'IGMFinalDate', 'FreeDays', 'ExpectedDate', 'OBLRecDate', 'DutyCashNo', 'DutyRecDate', 'DutyPaidDate', 'DECLRecDate', 'HighSeasRecDate', 'DeliveryExpectedDate', 'ContainerLastFreeDate', 'BPTLFDDate', 'HiddenCFSType', 'CFSType', 'AdvanceRecDate', 'PaymentNo', 'PartyRefNo', 'RefPartyName', 'HiddenPortLoading', 'PortLoading', 'HiddenConsignment', 'Consignment', 'HiddenOrigin', 'Origin', 'HiddenCountryOrigin', 'CountryOrigin', 'HiddenCountryConsignment', 'CountryConsignment', 'HiddenPortShipment', 'PortShipment', 'VslName', 'VoyageNo', 'FederVsl', 'FederVoyageNo', 'HiddenPortDischarge', 'PortDischarge', 'HiddenDeliveryPlace', 'DeliveryPlace', 'BillofLading', 'BLDate', 'HiddenSoldTo', 'SoldTo', 'HiddenShipper', 'Shipper', 'HiddenIndentor', 'Indentor', 'HiddenShippingLine', 'ShippingLine', 'BoxTypeNo', 'HiddenBoxType', 'BoxType', 'ContainerTypeNo', 'HiddenContainerType', 'ContainerType', 'BalesTypeNo', 'HiddenBalesType', 'BalesType', 'CustomPortCode', 'CustomPortName', 'ImporterRemarks', 'Remarks', 'MarksNo', 'PortIGMNo', 'PortIGMDate', 'LocalIGMNo', 'LocalIGMDate', 'SMTPNo', 'SMTPDate', 'HBLNo', 'HBLDate', 'MBLNo', 'MBLDate', 'KachchaDetails', 'GreenChDetails', 'Section48Details', 'FirstChDetails', 'NewRownNumBond', 'BondNumber', 'HiddenBondPort', 'BondPort', 'BondPortName', 'NewRownNumCertificate', 'CertificateNumber', 'CertificateDate', 'HiddenOldJobNo', 'OldJobNo', 'HiddenAmendmentCode', 'AmendmentCode', 'RequestLetterNumber', 'RequestDate', 'AmendmentReason', 'HiddenWareHouseJobNo', 'WareHouseJobNo', 'HiddenWareHouseCode', 'WareHouseCode', 'BondNo', 'BondDate', 'HiddenNewChargesCurrency', 'NewChargesCurrency',];

    blankId.forEach((ele) => {
        $('#' + ele).val('');
    });

    $('#BillOfEntry').val('N');
    $('#SelectBranch').val(0);
    $('#JobCancel,#KachchaBE,#HighSeaSaleFlag,#GreenChReq,#Section48Requested,#WhetherPriorBE,#FirstChReq').prop('checked', false);
    $('#Address,#ShipperAddress,#DetentionSlab').html('');
    $('#Advance,#TotalInvoiceValue,#AssessableValue,#CIFValue,#DutyAmount,#NewChargesCurrencyExchangeRate').val('0.00');
    $('#TotalNetWeight,#TotalGrossWeight').val('0.000');
    $('#ValuationMethod').val('Rule 4-Transaction Value');
    $('#ModeOfTransport').val('L');

    $('#BondCode').val('0');
    $('#CertificateType').val('0');

    $('#CreatedBy,#CreatedAt,#ModifiedBy,#ModifiedAt').text('');
    $('#CreatedByModifiedBy').css('display', 'none');
    $('#CrBy,#CrDt,#MoBy,#MoDt').addClass('d-none');
    $('#TblLetters tbody,#BillDetails tbody,#DocumentDetails tbody').html('');
    $('#LettersDetails-tab,#BillDetails-tab,#DocumentDetails-tab').addClass('d-none');
    $('#PaymentMethodCode').val('T');
    $('#FileWeight').val('KGS');
    $('#HssDiv,#SvbDiv').addClass('d-none');

    $('#UploadDocument').hide();

    $('#AuthorizedDealerCodeList').html('');

    formid = '';

    //CONTAINER DETAILS RESET START

    $('#TblContainerDetails tbody tr').each(function (ind, ele) {
        if (ind == 0) {
            $(ele).find('.ContainerNo,.SealNo,.OurSealNo,.HiddenContType,.ContType,.HiddenContCFSType,.ContCFSType,.ContainerArrivalDate,.ContainerExamineDate,.OutChargeDate,.GatePassDate,.ContainerDeliveryDate,.ContainerDestuffingDate,.ContainerDeliverToParty,.ContainerEmptyDate,.HiddenEmptyYard,.EmptyYard,.ReUseDate,.ReUseBy,.ContainerGroundRentLFDDate,.LRNo,.TruckNo,.HiddenPrivateYard,.PrivateYard,.HiddenTransporter,.Transporter,.Destination,.ScanOkDate,.ContainerRemarks').val('');

            $(ele).find('.Loaded').val('Loaded');

            $(ele).find('.ContainerWeight,.GrossWeight,.TareWeight,.NetWeight').val('0.000');
            $(ele).find('.GRAmount,.ExchangeRate,.DemmAmount,.DetentionAmount').val('0.00');

            $(ele).find('.ForScan,.ScanPending,.NotScan,.Examine100,.MScan,.RScan,.ScanImage').prop('checked', false);
        }
        else
            $(ele).remove();
    });

    //CONTAINER DETAILS RESET END

    //INVOICE DETAILS RESET START

    ResetNewInvoice();
    $('#TblInvoiceDetails tbody tr').each(function (ind, ele) {
        if (ind == 0) {
            $(ele).find('.Relation').val('N');
            $(ele).find('.InvoiceNo,.InvoiceDate,.HiddenInvoiceCurrency,.InvoiceCurrency,.HiddenFreightCurrency,.FreightCurrency,.HiddenInsuranceCurrency,.InsuranceCurrency,.HiddenLoadingCurrency,.LoadingCurrency,.HSSFlag,.HiddenTblHSSeller,.TblHSSeller,.HiddenTblHSSAddress,.TblHSSAddress,.TblHSSellerIECCode,.TblSVBNo,.TblSVBDate,.TblSVBLoadCh,.TblSVBFlag,.TblSVBAssLoadFinal,.TblSVBDutyLoadFinal,.TblSVBCustomHouse,.PONumber,.PODate,.ContractNumber,.ContractDate,.LCNumber,.LCDate,.AuthorizedEconomicOperatorCode,.AuthorizedEconomicOperatorCountry,.AuthorizedEconomicOperatorCountryName,.AuthorizedEconomicOperatorRole').val('');

            $(ele).find('.NatureOfTransaction').val('S');
            $(ele).find('.InvoiceTerms').val(0);

            $(ele).find('.InvoiceCurrencyExchangeRate,.InvoiceValue,.ActualFreight,.FreightExchangeRate,.FreightINR,.ActualInsurance,.InsuranceExchangeRate,.InsuranceINR,.MiscCharges,.MiscChargesINR,.ActualLoading,.LoadingExchangeRate,.LoadingINR,.TblHSSLoadRate,.TblHSSLoadAmount,.TblSVBAssessableValue,.TblSVBDuty').val('0.00');

            $(ele).find('.NetWeightMetric,.GrossWeightKg').val('0.000');

            $(ele).find('.FreightPer,.InsurancePer,.LoadingPer').val('0.0000');
        }
        else
            $(ele).remove();

    });

    //INVOICE DETAILS RESET END

    //ITEM DETAILS RESET START

    ResetNewItem();
    ResetNewItemManufactureDetails();
    $('#NewItemInvoiceNo').html('');
    $('#TblItemDetails tbody tr').each(function (ind, ele) {
        if (ind == 0) {
            $(ele).find('.TblItemInvoiceNo').html('');
            $(ele).find('.HiddenTblItemName,.TblItemName,.TblItemDescription,.TblItemGenericDescription,.HiddenTblItemEndUse,.TblItemEndUse,.TblItemEndUseDesc,.HiddenTblItemCountryOrigin,.TblItemCountryOrigin,.HiddenTblUnitQuantityCode,.TblUnitQuantityCode,.TblRITCCode,.TblItemCTH,.TblItemCTEH,.TblItemBCDNotification,.TblItemBCDNotificationSrNo,.TblItemCVDNotification,.TblItemCVDNotificationSrNo,.TblAdditionalNotification1,.TblAdditionalNotification1SrNo,.TblAdditionalNotification2,.TblAdditionalNotification2SrNo,.TblOtherNotification,.TblOtherNotificationSrNo,.TblSocialWelfareNotification,.TblSocialWelfareNotificationSrNo,.TblNCDNotification,.TblNCDNotificationSrNo,.TblAntiDumpingDutyNotification,.TblAntiDumpingDutyNotificationSrNo,.TblHealthNotification,.TblHealthNotificationSrNo,.TblAdditionalCVDNotification,.TblAdditionalCVDNotificationSrNo,.TblAggregateDutyNotification,.TblAggregateDutyNotificationSrNo,.TblSafeguardDutyNotification,.TblSafeguardDutyNotificationSrNoTblIGSTNotification,.TblIGSTNotificationSrNo,.TblIGSTExemNotification,.TblIGSTExemNotificationSrNo,.TblIGSTComCessNotification,.TblIGSTComCessNotificationSrNo,.HiddenTblItemManufacturerProducerGrowerName,.TblItemManufacturerProducerGrowerName,.TblItemManufacturerProducerCodeType,.TblItemManufacturerProducerGrowerCode,.TblItemManufacturerProducerGrowerAddress1,.TblItemManufacturerProducerGrowerAddress2,.TblItemManufacturerProducerGrowerCity,.TblItemManufacturerProducerGrowerCountrySubDivision,.TblItemManufacturerProducerGrowerPin,.HiddenTblItemManufacturerCountry,.TblItemManufacturerCountryName,.HiddenTblSourceCountryName,.TblSourceCountryName,.HiddenTblTransitCountry,.TblTransitCountryName,.TblItemBrandName,.TblItemModel,.TblCTHSerialNumber,.TblSupplierSerialNumber,.TblTarrifValueNotification,.TblTarrifValueItemSrNo,.TblSAPTANotification,.TblSAPTANotificationSrNo,.TblPolicyParaNo,.TblPolicyYear,.TblPreviousBENo,.TblPreviousBEDate,.HiddenTblPreviousCurrencyCode,.TblPreviousCurrency,.HiddenTblPreviousCustomSite,.TblPreviousCustomSiteName,.TblCustomNotnExemptingCentralExciseFlag,.TblItemAccessoriesOfItem,.TblDEPBNotification,.TblDEPBNotificationSrNo').val('');

            $(ele).find('.TblReImport').val('N');
            $(ele).find('.TblPreferentialStandard').val('P');
            $(ele).find('.TblRSPApplicability').val('N');
            $(ele).find('.HiddenTblLicCheck').val('false');
            $(ele).find('.TblItemMode').val(0);
            $(ele).find('.TblItemCategorySchemeCode').val(0);
            $(ele).find('.TblAccessoryStatus').val(0);
            $(ele).find('.TblExempted').val('No');

            $(ele).find('.TblItemAmount,.TblItemFreight,.TblItemInsurance,.TblItemMiscCharge,.TblItemLoading,.TblHSSLoadAmount,.TblItemCIFValue,.TblItemDutyAmount,.TblItemDutyGone,.TblItemBCDRate,.TblItemBCDAmount,.TblItemCVDRate,.TblItemCVDAmount,.TblAdditionalNotification1Rate,.TblAdditionalNotification1Amount,.TblAdditionalNotification2Rate,.TblAdditionalNotification2Amount,.TblOtherNotificationRate,.TblOtherNotificationAmount,.TblSocialWelfareRate,.TblSocialWelfareAmount,.TblNCDNotificationRate,.TblNCDNotificationAmount,.TblAntiDumpingDutyNotificationRate,.TblAntiDumpingDutyNotificationAmount,.TblHealthNotificationRate,.TblHealthNotificationAmount,.TblAdditionalCVDNotificationRate,.TblAdditionalCVDNotificationAmount,.TblAggregateDutyNotificationRate,.TblAggregateDutyNotificationAmount,.TblSafeguardDutyNotificationRate,.TblSafeguardDutyNotificationAmount,.TblIGSTNotificationRate,.TblIGSTNotificationAmount,.TblIGSTExemNotificationRate,.TblIGSTExemNotificationAmount,.TblIGSTComCessNotificationRate,.TblIGSTComCessNotificationAmount,.TblQuantityAsPerAntiDumpingNotification,.TblQuantityAsPerTarrifValueNotification,.TblQtyAsPerCTH,.TblQuantityAsPerCTH,.TblPreviousUnitPrice').val('0.00');

            $(ele).find('.NetWeightMetric,.GrossWeightKg').val('0.000');

            $(ele).find('.TblItemQuantity,.TblItemUnitPrice').val('0.000000');
        }
        else
            $(ele).remove();
    });

    //LICENSE DETAILS RESET START

    ResetNewLicense();
    $('#NewItemLicense').html('');
    $("#TblLicenceDetails tbody tr").each(function (ind, ele) {
        if (ind == 0) {
            $(ele).find('.TblLicenseItemSr').html('');
            $(ele).find('.TblLicenseNumber,.TblLicenseDate,.TblLicenseRegisNumber,.TblLicenseRegisDate,.HiddenTblLicenseDebitQtyUnit,.TblLicenseDebitQtyUnit,.HiddenTblLicensePortCode,.TblLicensePortCode,.TblLicensePortName').val('');
            $(ele).find('.TblLicenseDebitQty').val('0.00');
            $(ele).find('.TblLicenseItemCIFValue,.TblLicenseDebitBCDAmount,.TblLicenseDebitSWAmount,.TblLicenseDebitIGSTAmount,.TblLicenseDebitAmount').val('0.00');
        }
        else
            $(ele).remove();
    });

    //LICENSE DETAILS RESET END

    //DESTUFF DETAILS RESET START

    ResetNewDestuff();
    $('#NewItemDestuff').html('');
    $('#TblDestuffDetails tbody tr').each(function (ind, ele) {
        if (ind == 0) {
            $(ele).find('.TblDestuffItemSr').html('');
            $(ele).find('.TblDeDeliveryDate,.TblDeLRNo,.TblDeTruckNo').val('');
            $(ele).find('.TblDeGrossWeight,.TblDeTareWeight,.TblDeNetWeight').val('0.000');
            $(ele).find('.TblDeBales,.TblDeLoose').val('');
        } else
            $(ele).remove();
    });

    //DESTUFF DETAILS RESET END

    //ESANCHITDETAILS RESET START

    $("#TblJobSupportDocs tbody tr").each(function (ind, ele) {
        if (ind == 0) {
            $(ele).parent().parent().find('.TblUniqueItemSrNo,.TblFileName,.TblInvoiceSrNo,.TblItemSrNo,.TblImgRefNo,.HiddenTblDocType,.TblDocType,.TblDocUploadDate,.TblPlaceOfIssue,.TblDocIssueDate,.TblDocExpiryDate,.HiddenTblDocIssueParty,.TblDocIssuingParty,.TblDocIssuingPartyCode,.HiddenTblDocBeneficiaryParty,.TblDocBeneficiaryParty,.TblDocBeneficiaryPartyCode').val('');
            $(ele).parent().parent().find('.TblDocLevel').val('JOB');
            $(ele).parent().parent().find('.TblIceGate').val(0);
        }
        else
            $(ele).remove();
    });

    //ESANCHITDETAILS RESET END

    //BOND DETAILS RESET START

    ResetNewBond();
    $('#TblBondDetails tbody tr').each(function (ind, ele) {
        if (ind == 0)
            $(ele).find('.TblBondNo,.TblBondCode,.TblBondPort,.TblBondPortName').val('');
        else
            $(ele).remove();
    });

    //CERTIFICATE DETAILS RESET START

    ResetNewCertificate();
    $('#TblCertificateDetails tbody tr').each(function (ind, ele) {
        if (ind == 0)
            $(ele).find('.TblCertificateNo,.TblCertificateDate,.TblCertificateCode').val('');
        else
            $(ele).remove();
    });

    //BOND DETAILS RESET END

    //SHIPMENT DETAILS TAB 

    $("#ShipmentDetails-tab").addClass('active');
    $("#ShipmentDetails").addClass('active show');

    $("#ContainerDetails,#InvoiceDetails,#EDIDetails,#ItemDetails,#DestuffDetails,#LicenseDetails,#CFSChargeDetails,#ESanchitDetails,#BondDetails,#CertificateDetails,#AmendmentDetails").removeClass('active show');

    $("#ContainerDetails-tab,#InvoiceDetails-tab,#EDIDetails-tab,#ItemDetails-tab,#DestuffDetails-tab,#LicenseDetails-tab,#CFSChargeDetails-tab,#ESanchitDetails-tab,#BondDetails-tab,#CertificateDetails-tab,#AmendmentDetails-tab").removeClass('active');

    $('#AmendmentDetails-tab').addClass('d-none');

    $('#SelectBranch').focus();
}

//FUNCTION FOR FILL PORT NAME USING PORT UID
function FillPortNameUsingUId(Hid, Id) {
    try {
        const dataString = {};
        $('#' + Id).val('');
        dataString.PortUid = $('#' + Hid).val();
        AjaxSubmission(JSON.stringify(dataString), '/Master/_Layout/GetPortName', $('input[name=__RequestVerificationToken]').val()).done(function (result) {
            let obj = result;
            if (obj.status == true) {
                if (obj.responsecode == '100')
                    $('#' + Id).val(obj.data.Table[0].PortName);
            }
            else
                window.location.href = '/ClientLogin/ClientLogin';
        }).fail(function (result) {
            console.log(result.Message);
        });
    }
    catch (e) {
        console.log(e.message);
    }
}

//ALL INPUT TYPE SEARCH TEXT BOX WHEN ENTER KEY PRESS
$("#SearchJobDateFrom,#SearchJobDateTo,#SearchCustomPortName,#SearchSubJobNo,#SearchJobNo,#SearchClient,#SearchBENo,#SearchBEDateFrom,#SearchBEDateTo,#SearchShipper,#SearchShippingLine,#SearchPortLoading,#SearchPortDischarge,#SearchDeliveryPlace,#SearchExpectedDateFrom,#SearchExpectedDateTo,#SearchContainerNo,#SearchNetWeight").bind('keypress', function (e) {
    if (e.keyCode == 13) {
        $("#FormSearch").trigger('click');
    }
});

//SEARCHPORT NAME TEXTBOX ON INPUT EVENT
$("#SearchCustomPortName").on('input', function () {
    $("#SearchCustomPortCode").val('');
});

//SEARCHCLIENT NAME TEXTBOX ON INPUT EVENT
$("#SearchClient").on('input', function () {
    $("#HiddenSearchClient").val('');
});

//IMPORTER NAME TEXTBOX ON INPUT EVENT
$("#ImporterName").on('input', function () {
    $("#HiddenImporterName").val('');
});

//CFSTYPE TEXTBOX ON INPUT EVENT
$("#CFSType").on('input', function () {
    $("#HiddenCFSType").val('');
});

//PORTLOADING TEXTBOX ON INPUT EVENT
$("#PortLoading").on('input', function () {
    $("#HiddenPortLoading").val('');
});

//ORIGIN TEXTBOX ON INPUT EVENT
$("#Origin").on('input', function () {
    $("#HiddenOrigin").val('');
});

//COUNTRYORIGIN TEXTBOX ON INPUT EVENT
$("#CountryOrigin").on('input', function () {
    $("#HiddenCountryOrigin").val('');
});

//COUNTRYCONSIGNMENT ON INPUT EVENT
$("#CountryConsignment").on('input', function () {
    $("#HiddenCountryConsignment").val('');
});

//PORTSHIPMENT TEXTBOX ON INPUT EVENT
$("#PortShipment").on('input', function () {
    $("#HiddenPortShipment").val('');
});

//PORTDISCHARGE TEXTBOX ON INPUT EVENT
$("#PortDischarge").on('input', function () {
    $("#HiddenPortDischarge").val('');
});

//DELIVERYPLACE TEXTBOX ON INPUT EVENT
$("#DeliveryPlace").on('input', function () {
    $("#HiddenDeliveryPlace").val('');
});

//SOLDTO TEXTBOX ON INPUT EVENT
$("#SoldTo").on('input', function () {
    $("#HiddenSoldTo").val('');
});

//INDENTOR TEXTBOX ON INPUT EVENT
$("#Indentor").on('input', function () {
    $("#HiddenIndentor").val('');
});

//SHIPPINGLINE TEXTBOX ON INPUT EVENT
$("#ShippingLine").on('input', function () {
    $("#HiddenShippingLine").val('');
});

//CUSTOMPORTNAME TEXTBOX ON INPUT EVENT
$("#CustomPortName").on('input', function () {
    $("#CustomPortCode").val('');
});

//HSSELLER TEXTBOX ON INPUT EVENT
$("#HSSeller").on('input', function () {
    $("#HiddenHSSeller").val('');
});

//FUNCTION FOR GET CURRENCY EXCHANGE RATE AND SET IN EXCHANGE RATE FIELD
function GetCurrencyExchangeRate(Hid, Id, JobDate, JobType) {
    try {
        const dataString = {};
        dataString.CurrencyUid = $('#' + Hid).val();
        dataString.JobDate = $('#' + JobDate).val().trim();
        dataString.JobType = JobType;
        AjaxSubmission(JSON.stringify(dataString), '/Master/_Layout/GetCurrencyExchangeRate', $('input[name=__RequestVerificationToken]').val()).done(function (result) {
            let obj = result;
            if (obj.status == true) {
                if (obj.responsecode == '100')
                    $('#' + Id).val(HandleNullNumericValue(obj.data.Table[0].currency_ie_rate).toFixed(2));
                else if (obj.responsecode == '604')
                    $('#' + Id).val('0.00');
                else
                    Toast(RetrieveMessage(obj.responsecode), 'Message', 'error');
            } else
                window.location.href = '/ClientLogin/ClientLogin';

        }).fail(function (result) {
            console.log(result.message);
        });
    }
    catch (e) {
        console.log(e.message);
    }
}

//FUNCTION FOR GET MAIN TABLE DATA 
function GetJobHeaderData() {
    DutyCalculation();
    const dataString = {};

    dataString.JobType = $('#JobType').val();
    dataString.ImportJobUid = $('#JobUid').val();
    dataString.TimeStamp = $('#TimeStamp').val();
    dataString.BranchId = $('#SelectBranch').val();
    dataString.JobDate = $('#JobDate').val().trim();
    dataString.SubJobNo = $('#SubJobNo').val().trim();
    dataString.JobNo = $('#JobNo').val().trim();
    dataString.JobCancel = $('#JobCancel').is(':checked');

    dataString.BillOfEntry = $('#BillOfEntry').val();

    dataString.ImporterId = parseInt($('#HiddenImporterName').val().trim());
    dataString.ImporterBranchUid = $('#Address').val().trim();
    dataString.AdCode = $('#AdCode').val().trim();
    dataString.BENo = $('#BENo').val().trim();
    dataString.BEDate = $('#BEDate').val().trim();

    dataString.IGMNo = $('#IGMNo').val().trim();
    dataString.IGMItem = $('#IGMItem').val().trim();
    dataString.IGMDate = $('#IGMDate').val().trim();
    dataString.IGMFinalDate = $('#IGMFinalDate').val().trim();
    dataString.FreeDays = parseInt($('#FreeDays').val().trim());
    dataString.ExpectedDate = $('#ExpectedDate').val().trim();
    dataString.OBLRecDate = $('#OBLRecDate').val().trim();
    dataString.DutyCashNo = $('#DutyCashNo').val().trim();
    dataString.DutyRecDate = $('#DutyRecDate').val().trim();
    dataString.DutyPaidDate = $('#DutyPaidDate').val().trim();
    dataString.DECLRecDate = $('#DECLRecDate').val().trim();
    dataString.HighSeasRecDate = $('#HighSeasRecDate').val().trim();

    dataString.DeliveryExpectedDate = $('#DeliveryExpectedDate').val().trim();
    dataString.ContainerLastFreeDate = $('#ContainerLastFreeDate').val().trim();
    dataString.BPTLFDDate = $('#BPTLFDDate').val().trim();
    dataString.CFSType = parseInt($('#HiddenCFSType').val().trim());
    dataString.AdvanceRecDate = $('#AdvanceRecDate').val().trim();
    dataString.Advance = parseFloat($('#Advance').val().trim());
    dataString.PaymentNo = $('#PaymentNo').val().trim();
    dataString.PartyRefNo = $('#PartyRefNo').val().trim();
    dataString.RefPartyName = $('#RefPartyName').val().trim();

    dataString.TotalNetWeight = parseFloat($('#TotalNetWeight').val().trim());
    dataString.TotalGrossWeight = parseFloat($('#TotalGrossWeight').val().trim());
    dataString.TotalInvoiceValue = parseFloat($('#TotalInvoiceValue').val().trim());
    dataString.AssessableValue = parseFloat($('#AssessableValue').val().trim());
    dataString.CIFValue = parseFloat($('#CIFValue').val().trim());
    dataString.DutyAmount = parseFloat($('#DutyAmount').val().trim());
    dataString.ClientRemarks = $('#ClientRemarks').val().trim();
    dataString.Remarks = $('#Remarks').val().trim();
    dataString.MarksNo = $('#MarksNo').val().trim();

    dataString.ChargesCurrency = $('#NewChargesCurrency').val().trim();
    dataString.ChargesCurrencyExchangeRate = $('#NewChargesCurrencyExchangeRate').val().trim();

    let InvDesc = '', InvDate = '', InvCur = '', InvExRat = '', InvTerms = '', InvRate = '', HSSeller = '', HSSellerBranchUid = '';

    $('#TblInvoiceDetails tbody tr').each(function (ind, ele) {
        if ($(ele).find('.InvoiceNo').val().trim().length > 0) {
            InvDesc += $(ele).find('.InvoiceNo').val() + '@';
            InvDesc += $(ele).find('.InvoiceDate').val() + ',';
            InvRate += $(ele).find('.InvoiceValue').val() + ',';

            if (InvCur == '')
                InvCur = $(ele).find('.InvoiceCurrency').val();
            if (InvExRat == '')
                InvExRat = $(ele).find('.InvoiceCurrencyExchangeRate').val();
            if (InvTerms == '')
                InvTerms = $(ele).find('.InvoiceTerms').val();

            if (ind == 0) {
                dataString.HSSeller = $(ele).find('.HiddenTblHSSeller').val();
                dataString.HSSellerBranchUid = $(ele).find('.HiddenTblHSSAddress').val();
            }
        }
    });


    dataString.InvoiceDescriptions = InvDesc.substring(0, InvDesc.length - 1);
    dataString.InvoiceDate = InvDate;
    dataString.InvoiceCurrency = InvCur;
    dataString.InvoiceCurrenyExchRate = InvExRat;
    dataString.InvoiceTerms = InvTerms;
    dataString.InvoiceRate = InvRate.substring(0, InvRate.length - 1);

    let ItemDesc = '';

    $('#TblItemDetails tbody tr').each(function (ind, ele) {

        if ($(ele).find('.TblItemName').val().trim().length > 0) {
            ItemDesc += $(ele).find('.TblItemName').val() + ',';
        }
    });

    dataString.ItemDescriptions = ItemDesc.substring(0, ItemDesc.length - 1);

    dataString.PortLoadingCode = $('#HiddenPortLoading').val();
    dataString.PortLoading = $('#PortLoading').val().trim();

    dataString.ConsignmentCode = $('#HiddenConsignment').val();
    dataString.Consignment = $('#Consignment').val().trim();

    dataString.OriginCode = $('#HiddenOrigin').val();
    dataString.Origin = $('#Origin').val().trim();

    dataString.CountryOriginCode = $('#HiddenCountryOrigin').val();
    dataString.CountryOrigin = $('#CountryOrigin').val().trim();

    dataString.CountryConsignmentCode = $('#HiddenCountryConsignment').val();
    dataString.CountryConsignment = $('#CountryConsignment').val().trim();

    dataString.PortShipmentCode = $('#HiddenPortShipment').val();
    dataString.PortShipment = $('#PortShipment').val().trim();

    dataString.PortDischargeCode = $('#HiddenPortDischarge').val();
    dataString.PortDischarge = $('#PortDischarge').val().trim();

    dataString.DeliveryPlaceCode = $('#HiddenDeliveryPlace').val().trim();
    dataString.DeliveryPlace = $('#DeliveryPlace').val().trim();

    dataString.VslName = $('#VslName').val().trim();
    dataString.VoyageNo = $('#VoyageNo').val().trim();

    dataString.FederVsl = $('#FederVsl').val().trim();
    dataString.FederVoyageNo = $('#FederVoyageNo').val().trim();


    dataString.BillofLading = $('#BillofLading').val().trim();
    dataString.BLDate = $('#BLDate').val().trim();
    dataString.SoldTo = $('#HiddenSoldTo').val();
    dataString.ValuationMethod = $('#ValuationMethod').val();
    dataString.Shipper = parseInt($('#HiddenShipper').val().trim());
    dataString.ShipperBranchUid = $('#ShipperAddress').val();
    dataString.ShipperBranchAddress = $('#ShipperAddress option:selected').text().trim();
    dataString.Indentor = parseInt($('#HiddenIndentor').val().trim());
    dataString.ShippingLine = parseInt($('#HiddenShippingLine').val().trim());

    if ($('#DetentionSlab').val() != 0)
        dataString.DetentionSlab = parseInt($('#DetentionSlab').val());

    if ($('#BoxTypeNo').val().trim().length > 0) {
        if ($('#BoxType').val().trim().length <= 0) {
            $('#BoxType').focus();
            Toast('Please Add Box Type', 'Message', 'error');
            return false;
        }
    }

    if ($('#BoxType').val().trim().length > 0) {
        if ($('#BoxTypeNo').val().trim().length <= 0) {
            $('#BoxTypeNo').focus();
            Toast('Please Add Number Of Boxes.', 'Message', 'error');
            return false;
        }
    }

    dataString.BoxTypeNo = parseInt($('#BoxTypeNo').val().trim());
    dataString.BoxType = $('#BoxType').val().trim();


    if ($('#ContainerTypeNo').val().trim().length > 0) {
        if ($('#ContainerType').val().trim().length <= 0) {
            $('#ContainerType').focus();
            Toast('Please Add Container Type.', 'Message', 'error');
            return false;
        }
    }

    if ($('#ContainerType').val().trim().length > 0) {
        if ($('#ContainerTypeNo').val().trim().length <= 0) {
            $('#ContainerTypeNo').focus();
            Toast('Please Add Number Of Container.', 'Message', 'error');
            return false;
        }
    }

    dataString.ContainerTypeNo = parseInt($('#ContainerTypeNo').val().trim());
    dataString.ContainerType = $('#ContainerType').val().trim();

    if ($('#BalesTypeNo').val().trim().length > 0) {
        if ($('#BalesType').val().trim().length <= 0) {
            $('#BalesType').focus();
            Toast('Please Add Bales Type.', 'Message', 'error');
            return false;
        }
    }

    if ($('#BalesType').val().trim.length > 0) {
        if ($('#BalesTypeNo').val().trim().length <= 0) {
            $('#BalesTypeNo').focus();
            Toast('Please Add Number Of Bales.', 'Message', 'error');
            return false;
        }
    }

    dataString.BalesNo = parseInt($('#BalesTypeNo').val().trim());
    dataString.BalesType = $('#BalesType').val().trim();
    dataString.ModeOfTransport = $('#ModeOfTransport').val().trim();
    dataString.CustomPortCode = $('#CustomPortCode').val();
    dataString.CustomPortName = $('#CustomPortName').val();
    dataString.ContainerLoadType = $('#ContainerLoadType').val().trim();

    dataString.PaymentTerms = $('#PaymentTerms').val().trim();
    dataString.PortIGMNo = $('#PortIGMNo').val().trim();
    dataString.PortIGMDate = $('#PortIGMDate').val().trim();
    dataString.LocalIGMNo = $('#LocalIGMNo').val().trim();
    dataString.LocalIGMDate = $('#LocalIGMDate').val().trim();
    dataString.SMTPNo = $('#SMTPNo').val().trim();
    dataString.SMTPDate = $('#SMTPDate').val().trim();
    dataString.HBLNo = $('#HBLNo').val().trim();
    dataString.HBLDate = $('#HBLDate').val().trim();
    dataString.MBLNo = $('#MBLNo').val().trim();
    dataString.MBLDate = $('#MBLDate').val().trim();
    dataString.BEType = $('#BEType').val().trim();

    if ($('#BEType').val() == 'W') {
        dataString.WarehouseCode = $('#HiddenWareHouseCode').val();
        dataString.BondNo = $('#BondNo').val();
        dataString.BondDate = $('#BondDate').val();
    }
    else if ($('#BEType').val() == 'X') {
        dataString.WareHouseJobUid = $('#HiddenWareHouseJobNo').val();
        dataString.WarehouseCode = $('#HiddenWareHouseCode').val();
        dataString.BondNo = $('#BondNo').val();
        dataString.BondDate = $('#BondDate').val();
    }


    dataString.ClientType = $('#ImporterType').val().trim();
    dataString.PaymentMethodCode = $('#PaymentMethodCode').val();
    dataString.FileWeight = $('#FileWeight').val();

    dataString.KachchaBE = $('#KachchaBE').is(':checked');
    dataString.KachchaDetails = $('#KachchaDetails').val().trim();
    dataString.HighSeaSaleFlag = $('#HSSFlag').val() == 'true' ? true : false;
    dataString.GreenChReq = $('#GreenChReq').is(':checked');
    dataString.GreenChDetails = $('#GreenChDetails').val().trim();
    dataString.Section48Requested = $('#Section48Requested').is(':checked');
    dataString.Section48Details = $('#Section48Details').val().trim();
    dataString.WhetherPriorBE = $('#WhetherPriorBE').is(':checked');
    dataString.FirstChReq = $('#FirstChReq').is(':checked');
    dataString.FirstChDetails = $('#FirstChDetails').val().trim();


    dataString.AmendmentCode = $('#AmendmentCode').val();
    dataString.AmendmentReason = $('#AmendmentReason').val();
    dataString.RequestLetterNumber = $('#RequestLetterNumber').val();
    dataString.OldJobUid = $('#HiddenOldJobNo').val();
    dataString.RequestDate = $('#RequestDate').val();

    return dataString;
}

//FUNCTION FOR GET CONTAINER DETAILS DATA 
function GetContainerDetailsData() {
    let ContainerDetails = new Array();

    $("#TblContainerDetails tbody tr").each(function (ind, ele) {
        if ($(ele).find('.ContainerNo').val().trim().length > 0) {
            let ContDet = {};

            ContDet.ContainerNo = $(ele).find('.ContainerNo').val().trim();
            ContDet.SealNo = $(ele).find('.SealNo').val().trim();
            ContDet.OurSealNo = $(ele).find('.OurSealNo').val().trim();

            ContDet.ContType = $(ele).find('.ContType').val().trim();
            ContDet.ContCFSType = parseInt($(ele).find('.HiddenContCFSType').val().trim());
            ContDet.ContainerWeight = parseFloat($(ele).find('.ContainerWeight').val().trim());

            ContDet.ContainerArrivalDate = $(ele).find('.ContainerArrivalDate').val().trim();
            ContDet.ContainerExamineDate = $(ele).find('.ContainerExamineDate').val().trim();
            ContDet.OutChargeDate = $(ele).find('.OutChargeDate').val().trim();

            ContDet.GatePassDate = $(ele).find('.GatePassDate').val().trim();
            ContDet.ContainerDeliveryDate = $(ele).find('.ContainerDeliveryDate').val().trim();
            ContDet.ContainerDestuffingDate = $(ele).find('.ContainerDestuffingDate').val().trim();

            ContDet.ContainerDeliverToParty = $(ele).find('.ContainerDeliverToParty').val().trim();
            ContDet.ContainerEmptyDate = $(ele).find('.ContainerEmptyDate').val().trim();
            ContDet.EmptyYard = $(ele).find('.HiddenEmptyYard').val().trim();

            ContDet.ReUseDate = $(ele).find('.ReUseDate').val().trim();
            ContDet.ReUseBy = $(ele).find('.ReUseBy').val().trim();
            ContDet.ContainerGroundRentLFDDate = $(ele).find('.ContainerGroundRentLFDDate').val().trim();

            ContDet.GRAmount = parseFloat($(ele).find('.GRAmount').val().trim());
            ContDet.LRNo = $(ele).find('.LRNo').val().trim();
            ContDet.TruckNo = $(ele).find('.TruckNo').val().trim();

            ContDet.Loaded = $(ele).find('.Loaded').val();
            ContDet.PrivateYard = parseInt($(ele).find('.HiddenPrivateYard').val().trim());
            ContDet.GrossWeight = parseFloat($(ele).find('.GrossWeight').val().trim());

            ContDet.TareWeight = parseFloat($(ele).find('.TareWeight').val().trim());
            ContDet.NetWeight = parseFloat($(ele).find('.NetWeight').val().trim());
            ContDet.Transporter = parseInt($(ele).find('.HiddenTransporter').val().trim());

            ContDet.Destination = $(ele).find('.Destination').val().trim();
            ContDet.ExchangeRate = parseFloat($(ele).find('.ExchangeRate').val().trim());
            ContDet.DemmAmount = parseFloat($(ele).find('.DemmAmount').val().trim());

            ContDet.DetentionAmount = parseFloat($(ele).find('.DetentionAmount').val().trim());
            ContDet.ForScan = $(ele).find('.ForScan').is(':checked');
            ContDet.ScanPending = $(ele).find('.ScanPending').is(':checked');

            ContDet.NotScan = $(ele).find('.NotScan').is(':checked');
            ContDet.Examine100 = $(ele).find('.Examine100').is(':checked');
            ContDet.MScan = $(ele).find('.MScan').is(':checked');

            ContDet.RScan = $(ele).find('.RScan').is(':checked');
            ContDet.ScanImage = $(ele).find('.ScanImage').is(':checked');
            ContDet.ScanOkDate = $(ele).find('.ScanOkDate').val().trim();

            ContDet.ContainerRemarks = $(ele).find('.ContainerRemarks').val().trim();

            ContainerDetails.push(ContDet);
        }
    });
    return ContainerDetails;
}

//FUNCTION FOR VALID NET WEIGHT,GROSS WEIGHT AND INVOICE VALUE
function ValidateNtWtGrWtInVl() {
    let T_NtWt = 0, T_GrWt = 0, T_Invl = 0;

    $('#TblInvoiceDetails tbody tr').each(function (ind, ele) {

        if ($(ele).find('.InvoiceNo').val().trim().length > 0) {
            T_NtWt += parseFloat(HandleNullNumericValue($(ele).find('.NetWeightMetric').val()));
            T_GrWt += parseFloat(HandleNullNumericValue($(ele).find('.GrossWeightKg').val()));
            T_Invl += parseFloat(HandleNullNumericValue($(ele).find('.InvoiceValue').val()));
        }

    });

    T_NtWt = T_NtWt.toFixed(3);
    T_GrWt = T_GrWt.toFixed(3);
    T_Invl = T_Invl.toFixed(2);

    let F_NtWt = 0, F_GrWt = 0, F_Invl = 0;

    F_NtWt = HandleNullNumericValue($('#TotalNetWeight').val());
    F_GrWt = HandleNullNumericValue($('#TotalGrossWeight').val());
    F_Invl = HandleNullNumericValue($('#TotalInvoiceValue').val());


    if (T_NtWt != F_NtWt) {
        Toast('Total Net Weight Not Matched.', 'Message', 'error');
        return 1;
    }

    if (T_GrWt != F_GrWt) {
        Toast('Total Gross Weight Not Matched.', 'Message', 'error');
        return 1;
    }

    if (T_Invl != F_Invl) {
        Toast('Total Invoice Value Not Matched.', 'Message', 'error');
        return 1;
    }
    return 0;
}

//FUNCTION FOR GET INVOICE DETAILS DATA
function GetInvoiceDetailsData() {
    let InvoiceDetails = new Array();

    $('#TblInvoiceDetails tbody tr').each(function (ind, ele) {
        if ($(ele).find('.InvoiceNo').val().trim().length > 0) {

            let InvDet = {};

            InvDet.InvoiceSrNo = ind + 1;
            InvDet.Relation = $(ele).find('.Relation').val();
            InvDet.InvoiceNo = $(ele).find('.InvoiceNo').val().trim();
            InvDet.InvoiceDate = $(ele).find('.InvoiceDate').val().trim();
            InvDet.NatureOfTransaction = $(ele).find('.NatureOfTransaction').val().trim();
            InvDet.InvoiceTerms = $(ele).find('.InvoiceTerms').val().trim();

            InvDet.InvoiceCurrencyUid = $(ele).find('.HiddenInvoiceCurrency').val().trim();
            InvDet.InvoiceCurrency = $(ele).find('.InvoiceCurrency').val().trim();
            InvDet.InvoiceCurrencyExchangeRate = SetNullNumericField($(ele).find('.InvoiceCurrencyExchangeRate').val().trim());
            InvDet.InvoiceValue = SetNullNumericField($(ele).find('.InvoiceValue').val().trim());

            InvDet.NetWeightMetric = SetNullNumericField($(ele).find('.NetWeightMetric').val().trim());
            InvDet.GrossWeightKg = SetNullNumericField($(ele).find('.GrossWeightKg').val().trim());

            InvDet.FreightPer = SetNullNumericField($(ele).find('.FreightPer').val().trim());
            InvDet.ActualFreight = SetNullNumericField($(ele).find('.ActualFreight').val().trim());
            InvDet.FreightCurrencyUid = $(ele).find('.HiddenFreightCurrency').val().trim();
            InvDet.FreightCurrency = $(ele).find('.FreightCurrency').val().trim();
            InvDet.FreightExchangeRate = SetNullNumericField($(ele).find('.FreightExchangeRate').val().trim());
            InvDet.FreightINR = SetNullNumericField($(ele).find('.FreightINR').val().trim());

            InvDet.InsurancePer = SetNullNumericField($(ele).find('.InsurancePer').val().trim());
            InvDet.ActualInsurance = SetNullNumericField($(ele).find('.ActualInsurance').val().trim());
            InvDet.InsuranceCurrencyUid = $(ele).find('.HiddenInsuranceCurrency').val().trim();
            InvDet.InsuranceCurrency = $(ele).find('.InsuranceCurrency').val().trim();
            InvDet.InsuranceExchangeRate = SetNullNumericField($(ele).find('.InsuranceExchangeRate').val().trim());
            InvDet.InsuranceINR = SetNullNumericField($(ele).find('.InsuranceINR').val().trim());

            InvDet.MiscCharges = SetNullNumericField($(ele).find('.MiscCharges').val().trim());
            InvDet.MiscChargesINR = SetNullNumericField($(ele).find('.MiscChargesINR').val().trim());

            InvDet.LoadingPer = SetNullNumericField($(ele).find('.LoadingPer').val().trim());
            InvDet.ActualLoading = SetNullNumericField($(ele).find('.ActualLoading').val().trim());
            InvDet.LoadingCurrencyUid = $(ele).find('.HiddenLoadingCurrency').val().trim();
            InvDet.LoadingCurrency = $(ele).find('.LoadingCurrency').val().trim();
            InvDet.LoadingExchangeRate = SetNullNumericField($(ele).find('.LoadingExchangeRate').val().trim());
            InvDet.LoadingINR = SetNullNumericField($(ele).find('.LoadingINR').val().trim());

            InvDet.PONumber = $(ele).find('.PONumber').val().trim();
            InvDet.PODate = $(ele).find('.PODate').val().trim();
            InvDet.ContractNumber = $(ele).find('.ContractNumber').val().trim();
            InvDet.ContractDate = $(ele).find('.ContractDate').val().trim();
            InvDet.LCNumber = $(ele).find('.LCNumber').val().trim();
            InvDet.LCDate = $(ele).find('.LCDate').val().trim();

            InvDet.AuthorizedEconomicOperatorCode = $(ele).find('.AuthorizedEconomicOperatorCode').val().trim();
            InvDet.AuthorizedEconomicOperatorCountry = $(ele).find('.AuthorizedEconomicOperatorCountry').val().trim();
            InvDet.AuthorizedEconomicOperatorCountryName = $(ele).find('.AuthorizedEconomicOperatorCountryName').val().trim();
            InvDet.AuthorizedEconomicOperatorRole = $(ele).find('.AuthorizedEconomicOperatorRole').val().trim();

            InvDet.HighSeaSaleFlag = $(ele).find('.HSSFlag').val() == "true" ? true : false;

            InvDet.HSSLoadRate = SetNullNumericField($(ele).find('.TblHSSLoadRate').val().trim());
            InvDet.HSSLoadAmount = SetNullNumericField($(ele).find('.TblHSSLoadAmount').val().trim());
            InvDet.HSSeller = $(ele).find('.HiddenTblHSSeller').val().trim();
            InvDet.HSSellerBranchUid = $(ele).find('.HiddenTblHSSAddress').val().trim();
            InvDet.HSSellerIECCode = $(ele).find('.TblHSSellerIECCode').val().trim();

            InvDet.SVBLoadCh = $(ele).find('.TblSVBLoadCh').val() == "true" ? true : false;

            InvDet.SVBNo = $(ele).find('.TblSVBNo').val().trim();
            InvDet.SVBDate = $(ele).find('.TblSVBDate').val().trim();
            InvDet.SVBCustomHouse = $(ele).find('.TblSVBCustomHouse').val().trim();
            InvDet.SVBAssLoadFinal = $(ele).find('.TblSVBAssLoadFinal').val().trim();
            InvDet.SVBAssessableValue = SetNullNumericField($(ele).find('.TblSVBAssessableValue').val().trim());
            InvDet.SVBDutyLoadFinal = $(ele).find('.TblSVBDutyLoadFinal').val().trim();
            InvDet.SVBDuty = SetNullNumericField($(ele).find('.TblSVBDuty').val().trim());
            InvDet.SVBFlag = $(ele).find('.TblSVBFlag').val().trim();

            InvoiceDetails.push(InvDet);
        }
    });

    return InvoiceDetails;
}

//FUNCTION FOR MATCH ALL INVOICE AMOUNT WITH ALL ITEM AMOUNT
function ValidateAllInvVlWtAllItem() {
    let fl = 0;
    $("#TblInvoiceDetails tbody tr").each(function (InvInd, InvEle) {

        let Inv_Ser, Inv_Amt = 0, It_Amt = 0, It_Inv = 0;

        Inv_Ser = InvInd + 1;
        Inv_Amt = parseFloat(HandleNullNumericValue($(InvEle).find('.InvoiceValue').val()));
        Inv_Amt = Inv_Amt.toFixed(2);

        $("#TblItemDetails tbody tr").each(function (ItInd, ItEle) {
            if (Inv_Ser == $(ItEle).find('.TblItemInvoiceNo').val()) {
                It_Inv = $(ItEle).find('.TblItemInvoiceNo').val();
                It_Amt += parseFloat(HandleNullNumericValue($(ItEle).find('.TblItemAmount').val()));
            }
        });

        It_Amt = It_Amt.toFixed(2);
        if (Inv_Ser == It_Inv) {
            if (Inv_Amt != It_Amt) {
                Toast('Invoice Value Not Matched In Item Details Against Invoice :-' + $(InvEle).find('.InvoiceNo').val() + '', 'Message', 'error');
                fl = 1;
                return;
            }
        }
    });
    return fl;
}

//FUNCTION FOR GET ITEM DETAILS DATA
function GetItemDetailsData() {
    let ItemDetails = new Array();

    $('#TblItemDetails tbody tr').each(function (ind, ele) {

        let ItInv = $(ele).find('.TblItemInvoiceNo').val();

        if (ItInv != null && ItInv != undefined && ItInv != 0 && ItInv != '') {
            let ItDet = {};

            ItDet.InvoiceNumber = $(ele).find('.TblItemInvoiceNo option:selected').text();
            ItDet.InvoiceSrNo = $(ele).find('.TblItemInvoiceNo').val();
            ItDet.ItemSrNo = ind + 1;
            ItDet.ItemAmount = SetNullNumericField($(ele).find('.TblItemAmount').val().trim());
            ItDet.Quantity = SetNullNumericField($(ele).find('.TblItemQuantity').val().trim());
            ItDet.ItemUnitPrice = SetNullNumericField($(ele).find('.TblItemUnitPrice').val().trim());
            ItDet.UnitQuantityCode = $(ele).find('.TblUnitQuantityCode').val().trim();

            ItDet.ItemFreight = SetNullNumericField($(ele).find('.TblItemFreight').val().trim());
            ItDet.ItemInsurance = SetNullNumericField($(ele).find('.TblItemInsurance').val().trim());
            ItDet.ItemMiscCharge = SetNullNumericField($(ele).find('.TblItemMiscCharge').val().trim());
            ItDet.ItemLoading = SetNullNumericField($(ele).find('.TblItemLoading').val().trim());
            ItDet.ItemHSSAmount = SetNullNumericField($(ele).find('.TblHSSLoadAmount').val().trim());
            ItDet.ItemAssessableValue = SetNullNumericField($(ele).find('.TblItemCIFValue').val().trim());
            ItDet.ItemCIFValue = SetNullNumericField($(ele).find('.TblItemCIFValue').val().trim());

            //ItDet.DutyType = $(ele).find('.').val();

            //ItDet.ItemRemarks = $(ele).find('.').val();


            ItDet.RITCCode = $(ele).find('.TblRITCCode').val().trim();
            ItDet.ItemName = $(ele).find('.TblItemName').val().trim();

            ItDet.ItemDescription1 = $(ele).find('.TblItemDescription').val().substring(0, 60);
            ItDet.ItemDescription2 = $(ele).find('.TblItemDescription').val().trim().length > 60 ? $(ele).find('.TblItemDescription').val().substring(60, 120) : '';

            ItDet.DEPBNotification = $(ele).find('.TblDEPBNotification').val();
            ItDet.DEPBNotificationSrNo = $(ele).find('.TblDEPBNotificationSrNo').val();
            ItDet.DEPBExempted = $(ele).find('.TblExempted').val();
            ItDet.SQCQuantity = $(ele).find('.TblSQCQuantity').val();
            ItDet.SQCUnit = $(ele).find('.TblSQCQuantityCode').val();

            ItDet.LicenseCheck = $(ele).find('.HiddenTblLicCheck').val();
            ItDet.ItemMode = $(ele).find('.TblItemMode').val();
            ItDet.ItemCategorySchemeCode = $(ele).find('.TblItemCategorySchemeCode').val();
            ItDet.ItemGenericDescription = $(ele).find('.TblItemGenericDescription').val().trim();
            ItDet.AccessoriesOfItem = $(ele).find('.TblItemAccessoriesOfItem').val().trim();
            ItDet.ManufacturerProducerGrower = $(ele).find('.HiddenTblItemManufacturerProducerGrowerName').val().trim();
            ItDet.ManufacturerProducerGrowerName = $(ele).find('.TblItemManufacturerProducerGrowerName').val().trim();
            ItDet.BrandName = $(ele).find('.TblItemBrandName').val().trim();
            ItDet.Model = $(ele).find('.TblItemModel').val().trim();
            ItDet.EndUse = $(ele).find('.TblItemEndUse').val().trim();
            ItDet.EndUseDesc = $(ele).find('.TblItemEndUseDesc').val().trim();
            ItDet.CountryOriginName = $(ele).find('.TblItemCountryOrigin').val().trim();
            ItDet.CountryOrigin = $(ele).find('.HiddenTblItemCountryOrigin').val();
            ItDet.CTH = $(ele).find('.TblItemCTH').val().trim();
            ItDet.PreferentialStandard = $(ele).find('.TblPreferentialStandard').val();
            ItDet.CETH = $(ele).find('.TblItemCTEH').val().trim();


            ItDet.BCDNotification = $(ele).find('.TblItemBCDNotification').val().trim();
            ItDet.BCDNotificationSrNo = $(ele).find('.TblItemBCDNotificationSrNo').val().trim();
            ItDet.BCDRate = SetNullNumericField($(ele).find('.TblItemBCDRate').val().trim());
            ItDet.BCDAmount = SetNullNumericField($(ele).find('.TblItemBCDAmount').val().trim());

            ItDet.CVDNotification = $(ele).find('.TblItemCVDNotification').val().trim();
            ItDet.CVDNotificationSrNo = $(ele).find('.TblItemCVDNotificationSrNo').val().trim();
            ItDet.CVDRate = SetNullNumericField($(ele).find('.TblItemCVDRate').val().trim());
            ItDet.CVDAmount = SetNullNumericField($(ele).find('.TblItemCVDAmount').val().trim());

            ItDet.AdditionalNotification1 = $(ele).find('.TblAdditionalNotification1').val().trim();
            ItDet.AdditionalNotification1SrNo = $(ele).find('.TblAdditionalNotification1SrNo').val().trim();
            ItDet.AdditionalNotification1Rate = SetNullNumericField($(ele).find('.TblAdditionalNotification1Rate').val().trim());
            ItDet.AdditionalNotification1Amount = SetNullNumericField($(ele).find('.TblAdditionalNotification1Amount').val().trim());

            ItDet.AdditionalNotification2 = $(ele).find('.TblAdditionalNotification2').val().trim();
            ItDet.AdditionalNotification2SrNo = $(ele).find('.TblAdditionalNotification2SrNo').val().trim();
            ItDet.AdditionalNotification2Rate = SetNullNumericField($(ele).find('.TblAdditionalNotification2Rate').val().trim());
            ItDet.AdditionalNotification2Amount = SetNullNumericField($(ele).find('.TblAdditionalNotification2Amount').val().trim());

            ItDet.OtherNotification = $(ele).find('.TblOtherNotification').val().trim();
            ItDet.OtherNotificationSrNo = $(ele).find('.TblOtherNotificationSrNo').val().trim();
            ItDet.OtherNotificationRate = SetNullNumericField($(ele).find('.TblOtherNotificationRate').val().trim());
            ItDet.OtherNotificationAmount = SetNullNumericField($(ele).find('.TblOtherNotificationAmount').val().trim());

            //ItDet.CusEducessNotification = $(ele).find('.').val().trim();
            //ItDet.CusEducessNotificationSrNo = $(ele).find('.').val().trim();
            //ItDet.CusEducessNotificationRate = SetNullNumericField($(ele).find('.').val());
            //ItDet.CusEducessNotificationAmount = SetNullNumericField($(ele).find('.').val());

            ItDet.SocialWelfareNotification = $(ele).find('.TblSocialWelfareNotification').val().trim();
            ItDet.SocialWelfareNotificationSrNo = $(ele).find('.TblSocialWelfareNotificationSrNo').val().trim();
            ItDet.SocialWelfareNotificationRate = SetNullNumericField($(ele).find('.TblSocialWelfareRate').val().trim());
            ItDet.SocialWelfareNotificationAmount = SetNullNumericField($(ele).find('.TblSocialWelfareAmount').val().trim());

            ItDet.NCDNotification = $(ele).find('.TblNCDNotification').val().trim();
            ItDet.NCDNotificationSrNo = $(ele).find('.TblNCDNotificationSrNo').val().trim();
            ItDet.NCDNotificationRate = SetNullNumericField($(ele).find('.TblNCDNotificationRate').val().trim());
            ItDet.NCDNotificationAmount = SetNullNumericField($(ele).find('.TblNCDNotificationAmount').val().trim());

            ItDet.AntiDumpingDutyNotification = $(ele).find('.TblAntiDumpingDutyNotification').val().trim();
            ItDet.AntiDumpingDutyNotificationSrNo = $(ele).find('.TblAntiDumpingDutyNotificationSrNo').val().trim();
            ItDet.AntiDumpingDutyNotificationRate = SetNullNumericField($(ele).find('.TblAntiDumpingDutyNotificationRate').val().trim());
            ItDet.AntiDumpingDutyNotificationAmount = SetNullNumericField($(ele).find('.TblAntiDumpingDutyNotificationAmount').val().trim());

            ItDet.CTHSerialNumber = $(ele).find('.TblCTHSerialNumber').val().trim();
            ItDet.SupplierSerialNumber = $(ele).find('.TblSupplierSerialNumber').val().trim();
            ItDet.QuantityAsPerAntiDumpingNotification = SetNullNumericField($(ele).find('.TblQuantityAsPerAntiDumpingNotification').val().trim());
            ItDet.TarrifValueNotification = $(ele).find('.TblTarrifValueNotification').val().trim();
            ItDet.TarrifValueItemSrNo = $(ele).find('.TblTarrifValueItemSrNo').val().trim();
            ItDet.QuantityAsPerTarrifValueNotification = SetNullNumericField($(ele).find('.TblQuantityAsPerTarrifValueNotification').val().trim());
            ItDet.SAPTANotification = $(ele).find('.TblSAPTANotification').val().trim();
            ItDet.SAPTANotificationSrNo = $(ele).find('.TblSAPTANotificationSrNo').val().trim();

            ItDet.HealthNotification = $(ele).find('.TblHealthNotification').val().trim();
            ItDet.HealthNotificationSrNo = $(ele).find('.TblHealthNotificationSrNo').val().trim();
            ItDet.HealthNotificationRate = SetNullNumericField($(ele).find('.TblHealthNotificationRate').val().trim());
            ItDet.HealthNotificationAmount = SetNullNumericField($(ele).find('.TblHealthNotificationAmount').val().trim());

            ItDet.AdditionalCVDNotification = $(ele).find('.TblAdditionalCVDNotification').val().trim();
            ItDet.AdditionalCVDNotificationSrNo = $(ele).find('.TblAdditionalCVDNotificationSrNo').val().trim();
            ItDet.AdditionalCVDNotificationRate = SetNullNumericField($(ele).find('.TblAdditionalCVDNotificationRate').val().trim());
            ItDet.AdditionalCVDNotificationAmount = SetNullNumericField($(ele).find('.TblAdditionalCVDNotificationAmount').val().trim());

            ItDet.AggregateDutyNotification = $(ele).find('.TblAggregateDutyNotification').val().trim();
            ItDet.AggregateDutyNotificationSrNo = $(ele).find('.TblAggregateDutyNotificationSrNo').val().trim();
            ItDet.AggregateDutyNotificationRate = SetNullNumericField($(ele).find('.TblAggregateDutyNotificationRate').val().trim());
            ItDet.AggregateDutyNotificationAmount = SetNullNumericField($(ele).find('.TblAggregateDutyNotificationAmount').val().trim());

            ItDet.SafeguardDutyNotification = $(ele).find('.TblSafeguardDutyNotification').val().trim();
            ItDet.SafeguardDutyNotificationSrNo = $(ele).find('.TblSafeguardDutyNotificationSrNo').val().trim();
            ItDet.SafeguardDutyNotificationRate = SetNullNumericField($(ele).find('.TblSafeguardDutyNotificationRate').val().trim());
            ItDet.SafeguardDutyNotificationAmount = SetNullNumericField($(ele).find('.TblSafeguardDutyNotificationAmount').val().trim());


            ItDet.QtyAsPerCTH = SetNullNumericField($(ele).find('.TblQtyAsPerCTH').val().trim());
            ItDet.QuantityAsPerCTH = SetNullNumericField($(ele).find('.TblQuantityAsPerCTH').val().trim());
            ItDet.PolicyParaNo = $(ele).find('.TblPolicyParaNo').val().trim();
            ItDet.PolicyYear = $(ele).find('.TblPolicyYear').val().trim();
            ItDet.RSPApplicability = $(ele).find('.TblRSPApplicability').val();
            ItDet.ReImport = $(ele).find('.TblReImport').val();
            ItDet.PreviousBENo = $(ele).find('.TblPreviousBENo').val().trim();
            ItDet.PreviousBEDate = $(ele).find('.TblPreviousBEDate').val().trim();
            ItDet.PreviousUnitPrice = SetNullNumericField($(ele).find('.TblPreviousUnitPrice').val().trim());
            ItDet.PreviousCurrencyCode = $(ele).find('.HiddenTblPreviousCurrencyCode').val().trim();
            ItDet.PreviousCurrency = $(ele).find('.TblPreviousCurrency').val().trim();
            ItDet.PreviousCustomSite = $(ele).find('.HiddenTblPreviousCustomSite').val().trim();
            ItDet.PreviousCustomSiteName = $(ele).find('.TblPreviousCustomSiteName').val().trim();
            ItDet.CustomNotnExemptingCentralExciseFlag = $(ele).find('.TblCustomNotnExemptingCentralExciseFlag').val().trim();
            ItDet.ItemManufacturerProducerCodeType = $(ele).find('.TblItemManufacturerProducerCodeType').val().trim();
            ItDet.ItemManufacturerProducerGrowerCode = $(ele).find('.TblItemManufacturerProducerGrowerCode').val().trim();
            ItDet.ItemManufacturerProducerGrowerAddress1 = $(ele).find('.TblItemManufacturerProducerGrowerAddress1').val().trim();
            ItDet.ItemManufacturerProducerGrowerAddress2 = $(ele).find('.TblItemManufacturerProducerGrowerAddress2').val().trim();
            ItDet.ItemManufacturerProducerGrowerCity = $(ele).find('.TblItemManufacturerProducerGrowerCity').val().trim();
            ItDet.ItemManufacturerProducerGrowerCountrySubDivision = $(ele).find('.TblItemManufacturerProducerGrowerCountrySubDivision').val().trim();
            ItDet.ItemManufacturerProducerGrowerPin = $(ele).find('.TblItemManufacturerProducerGrowerPin').val().trim();
            ItDet.ItemManufacturerCountry = $(ele).find('.HiddenTblItemManufacturerCountry').val().trim();
            ItDet.ItemManufacturerCountryName = $(ele).find('.TblItemManufacturerCountryName').val().trim();
            ItDet.SourceCountry = $(ele).find('.HiddenTblSourceCountryName').val().trim();
            ItDet.SourceCountryName = $(ele).find('.TblSourceCountryName').val().trim();
            ItDet.TransitCountry = $(ele).find('.HiddenTblTransitCountry').val().trim();
            ItDet.TransitCountryName = $(ele).find('.TblTransitCountryName').val().trim();
            ItDet.AccessoryStatus = $(ele).find('.TblAccessoryStatus').val().trim();

            ItDet.IGSTNotification = $(ele).find('.TblIGSTNotification').val().trim();
            ItDet.IGSTNotificationSrNo = $(ele).find('.TblIGSTNotificationSrNo').val().trim();
            ItDet.IGSTNotificationRate = SetNullNumericField($(ele).find('.TblIGSTNotificationRate').val().trim());
            ItDet.IGSTNotificationAmount = SetNullNumericField($(ele).find('.TblIGSTNotificationAmount').val().trim());

            ItDet.IGSTComCessNotification = $(ele).find('.TblIGSTComCessNotification').val().trim();
            ItDet.IGSTComCessNotificationSrNo = $(ele).find('.TblIGSTComCessNotificationSrNo').val().trim();
            ItDet.IGSTComCessNotificationRate = SetNullNumericField($(ele).find('.TblIGSTComCessNotificationRate').val().trim());
            ItDet.IGSTComCessNotificationAmount = SetNullNumericField($(ele).find('.TblIGSTComCessNotificationAmount').val().trim());

            ItDet.IGSTExemNotification = $(ele).find('.TblIGSTExemNotification').val().trim();
            ItDet.IGSTExemNotificationSrNo = $(ele).find('.TblIGSTExemNotificationSrNo').val().trim();
            ItDet.IGSTExemNotificationRate = SetNullNumericField($(ele).find('.TblIGSTExemNotificationRate').val().trim());
            ItDet.IGSTExemNotificationAmount = SetNullNumericField($(ele).find('.TblIGSTExemNotificationAmount').val().trim());

            ItDet.IGSTComCessExemNotification = $(ele).find('.TblIGSTComCessExemNotification').val().trim();
            ItDet.IGSTComCessExemNotificationSrNo = $(ele).find('.TblIGSTComCessExemNotificationSrNo').val().trim();
            ItDet.IGSTComCessExemNotificationRate = SetNullNumericField($(ele).find('.TblIGSTComCessExemNotificationRate').val().trim());
            ItDet.IGSTComCessExemNotificationAmount = SetNullNumericField($(ele).find('.TblIGSTComCessExemNotificationAmount').val().trim());

            ItDet.ItemDutyAmount = SetNullNumericField($(ele).find('.TblItemDutyAmount ').val().trim());
            ItDet.ItemDutyGone = SetNullNumericField($(ele).find('.TblItemDutyGone ').val().trim());

            ItemDetails.push(ItDet);
        }
    });
    return ItemDetails;
}

//FUNCTION FOR GET LICENSE DETAILS DATA
function GetLicenseDetailsData() {
    let LicenseDetails = new Array();
    $('#TblLicenceDetails tbody tr').each(function (ind, ele) {

        let ItemRowNum = $(ele).find('.TblLicenseItemSr').val();
        let LiCode = $(ele).find('.TblLicenseType').val();

        if ($(ele).find('.TblLicenseRegisNumber').val().trim().length > 5 && (ItemRowNum != null && ItemRowNum != undefined && ItemRowNum != 0 && ItemRowNum != '' && (LiCode != null && LiCode != undefined && LiCode != 0 && LiCode != ''))) {

            let LiDet = {};

            let InvoiceRowNum = $('#TblItemDetails tbody tr').eq(ItemRowNum - 1).find('.TblItemInvoiceNo').val();

            LiDet.LicenseSerialNo = ind + 1;
            LiDet.InvoiceSerialNo = InvoiceRowNum;
            LiDet.ItemSerialNo = ItemRowNum;
            LiDet.LicenseCode = LiCode;
            LiDet.LicenseRegisNumber = $(ele).find('.TblLicenseRegisNumber').val().trim();
            LiDet.LicenseRegisDate = $(ele).find('.TblLicenseRegisDate').val().trim();
            LiDet.DebitQuantity = SetNullNumericField($(ele).find('.TblLicenseDebitQty').val().trim());
            LiDet.LicenseDebitQtyUnit = $(ele).find('.TblLicenseDebitQtyUnit').val().trim();
            LiDet.LicenseItemCIFValue = SetNullNumericField($(ele).find('.TblLicenseItemCIFValue').val().trim());
            LiDet.DebitBCDValue = SetNullNumericField($(ele).find('.TblLicenseDebitBCDAmount').val().trim());
            LiDet.DebitSWValue = SetNullNumericField($(ele).find('.TblLicenseDebitSWAmount').val().trim());
            LiDet.DebitIGSTValue = SetNullNumericField($(ele).find('.TblLicenseDebitIGSTAmount').val().trim());
            LiDet.DebitValue = SetNullNumericField($(ele).find('.TblLicenseDebitAmount').val().trim());
            LiDet.LicensePortCode = $(ele).find('.TblLicensePortCode').val().trim();
            LiDet.LicensePortName = $(ele).find('.TblLicensePortName').val().trim();

            LicenseDetails.push(LiDet);
        }

    });
    return LicenseDetails;
}

//FUNCTION FOR GET DESTUFF DETAIL DATA
function GetDestuffDetailsData() {
    let DestuffDetails = new Array();
    $('#TblDestuffDetails tbody tr').each(function (ind, ele) {

        let ItDe = $(ele).find('.TblDestuffItemSr').val();
        if ((ItDe != undefined && ItDe != null && ItDe != '' && ItDe != 0) && ($(ele).find('.TblDeDeliveryDate').val().trim().length == 10)) {
            let DesDet = {};
            DesDet.DeSrNo = ind + 1;
            DesDet.DeDeliveryDate = $(ele).find('.TblDeDeliveryDate').val().trim();
            DesDet.ItemSrNo = ItDe
            DesDet.DeLRNo = $(ele).find('.TblDeLRNo').val().trim();
            DesDet.DeTruckNo = $(ele).find('.TblDeTruckNo').val().trim();
            DesDet.DeGrossWeight = SetNullNumericField($(ele).find('.TblDeGrossWeight').val().trim());
            DesDet.DeTareWeight = SetNullNumericField($(ele).find('.TblDeTareWeight').val().trim());
            DesDet.DeNetWeight = SetNullNumericField($(ele).find('.TblDeNetWeight').val().trim());
            DesDet.DeBales = $(ele).find('.TblDeBales').val().trim();
            DesDet.DeLoose = $(ele).find('.TblDeLoose').val().trim();

            DestuffDetails.push(DesDet);
        }

    });
    return DestuffDetails;
}

//FUNCTION FOR GET JOB SUPPORT DOCS DETAILS DATA
function GetJobSupportDocsDetailsData() {
    let JobSupportDocsDetails = new Array();
    $('#TblJobSupportDocs tbody tr').each(function (ind, ele) {
        let ImgRefNo = $(ele).find('.TblImgRefNo').val();
        if (ImgRefNo != undefined && ImgRefNo != null && ImgRefNo != '') {
            let JobSupportDocsDet = {};
            JobSupportDocsDet.ESanchitSrNo = ind + 1;
            JobSupportDocsDet.JobNo = $('#JobNo').val().trim();
            JobSupportDocsDet.DeclarationType = 'E';
            JobSupportDocsDet.DocumentLevel = $(ele).find('.TblDocLevel').val().trim();
            JobSupportDocsDet.InvoiceSrNo = $(ele).find('.TblInvoiceSrNo').val().trim();
            JobSupportDocsDet.ItemSrNo = $(ele).find('.TblItemSrNo').val().trim();
            JobSupportDocsDet.ICEGATEUserId = $(ele).find('.TblIceGate').val().trim();
            JobSupportDocsDet.ImageReferenceNo = $(ele).find('.TblImgRefNo').val().trim();
            JobSupportDocsDet.DocumentTypeCode = $(ele).find('.HiddenTblDocType').val().trim();
            JobSupportDocsDet.UploadDateTime = $(ele).find('.TblDocUploadDate').val().trim();
            JobSupportDocsDet.DocumentIssuingPartyCode = $(ele).find('.TblDocIssuingPartyCode').val().trim();
            JobSupportDocsDet.DocumentIssuingParty = $(ele).find('.HiddenTblDocIssuingParty').val().trim();
            /* JobSupportDocsDet.DocumentReferenceNo = $(ele).find('.TblDocRefNo').val().trim();*/
            JobSupportDocsDet.PlaceOfIssue = $(ele).find('.TblPlaceOfIssue').val().trim();
            JobSupportDocsDet.DocumentIssueDate = $(ele).find('.TblDocIssueDate').val().trim();
            JobSupportDocsDet.DocumentExpiryDate = $(ele).find('.TblDocExpiryDate').val().trim();
            JobSupportDocsDet.DocumentBeneficiaryPartyCode = $(ele).find('.TblDocBeneficiaryPartyCode').val().trim();
            JobSupportDocsDet.DocumentBeneficiaryParty = $(ele).find('.HiddenTblDocBeneficiaryParty').val().trim();
            JobSupportDocsDet.FileType = $(ele).find('.TblFileType').val().trim();
            JobSupportDocsDet.DocumentTypeCodeDescriptions = $(ele).find('.TblDocType').val().trim();
            JobSupportDocsDet.FileName = $(ele).find('.TblFileName').val().trim();
            JobSupportDocsDet.UniqueSerialNo = $(ele).find('.TblUniqueItemSrNo').val().trim();
            JobSupportDocsDetails.push(JobSupportDocsDet);
        }
    });
    return JobSupportDocsDetails;
}

//FUNCTION FOR GET BOND DETAILS DATA FROM INPUT
function GetBondDetailsData() {
    let BondDetails = new Array();

    $('#TblBondDetails tbody tr').each(function (ind, ele) {
        if ($(ele).find('.TblBondNo').val().trim().length > 0 && $(ele).find('.TblBondCode').val().trim().length > 0 && $(ele).find('.TblBondPort').val().trim().length > 0) {
            let BondDet = {};

            BondDet.BondNumber = $(ele).find('.TblBondNo').val().trim();
            BondDet.BondCode = $(ele).find('.TblBondCode').val().trim();
            BondDet.BondPort = $(ele).find('.TblBondPort').val().trim();
            BondDet.BondPortName = $(ele).find('.TblBondPortName').val().trim();

            BondDetails.push(BondDet);
        }
    });
    return BondDetails;
}

//FUNCTION FOR GET CERTIFICATE DETAILS DATA
function GetCertificateDetailsData() {
    let CertificateDetails = new Array();

    $('#TblCertificateDetails tbody tr').each(function (ind, ele) {
        if ($(ele).find('.TblCertificateNo').val().trim().length > 0 && $(ele).find('.TblCertificateCode').val().trim().length > 0) {
            let CertificateDet = {};

            CertificateDet.CertificateNumber = $(ele).find('.TblCertificateNo').val().trim();
            CertificateDet.CertificateDate = $(ele).find('.TblCertificateDate').val().trim();
            CertificateDet.CertificateType = $(ele).find('.TblCertificateCode').val().trim();


            CertificateDetails.push(CertificateDet);
        }
    });
    return CertificateDetails;
}

//FUNCTION FOR FILL MAIN TABLE DATA FOR EDIT
function FillMainDetailsData(obj, OldJob = true) {
    if (OldJob == true) {
        $('#JobUid').val(obj.JobUid);
        $('#HiddenOldJobNo').val(obj.OldJobUid);
        $('#OldJobNo').val(obj.OldJobNo);
        $('#TimeStamp').val(obj.timestamp);
        $('#SelectBranch').val(obj.BranchId);

        $('#JobDate').val(obj.JobDate);
        $('#SubJobNo').val(obj.SubJobNo);
        $('#JobNo').val(obj.JobNo);

        $('#JobCancel').prop('checked', obj.JobCancel == true ? true : false);

        $('#JobType').val(obj.JobType == 'IA' ? 'A' : 'I');
        if (obj.JobType == 'IA')
            $('#AmdJob,#AmendmentDetails-tab').removeClass('d-none');
        else
            $('#AmdJob,#AmendmentDetails-tab').addClass('d-none');

        $('#HiddenWareHouseJobNo').val(obj.WareHouseJobUid);
        $('#WareHouseJobNo').val(obj.WareHouseJobNo);
    }
    else
        $('#HiddenOldJobNo').val(obj.JobUid);

    $('#HiddenImporterName').val(obj.ClientId);
    ImpoSelecBranc = obj.ClientBranchUid;
    $('#ImporterName').val(obj.ClientName).trigger('blur');
    $('#AdCode').val(obj.AdCode);

    $('#BillOfEntry').val(obj.BillOfEntry);
    $('#BENo').val(obj.BENo);
    $('#BEDate').val(obj.BEDate);
    $('#IGMNo').val(obj.IGMNo);
    $('#IGMItem').val(obj.IGMItem);
    $('#IGMDate').val(obj.IGMDate);
    $('#IGMFinalDate').val(obj.IGMFinalDate);
    $('#FreeDays').val(obj.FreeDays);
    $('#ExpectedDate').val(obj.ExpectedDate);
    $('#OBLRecDate').val(obj.OBLRecDate);
    $('#DutyCashNo').val(obj.DutyCashNo);
    $('#DutyRecDate').val(obj.DutyRecDate);


    $('#DutyPaidDate').val(obj.DutyPaidDate);
    $('#DECLRecDate').val(obj.DECLRecDate);
    $('#HighSeasRecDate').val(obj.HighSeasRecDate);
    $('#DeliveryExpectedDate').val(obj.DeliveryExpectedDate);
    $('#ContainerLastFreeDate').val(obj.ContainerLastFreeDate);
    $('#BPTLFDDate').val(obj.BPTLFDDate);
    $('#HiddenCFSType').val(obj.CFSType);
    $('#CFSType').val(obj.CFSName);
    $('#AdvanceRecDate').val(obj.AdvanceRecDate);
    $('#Advance').val(obj.Advance);
    $('#PaymentNo').val(obj.PaymentNo);

    $('#PartyRefNo').val(obj.PartyRefNo);
    $('#RefPartyName').val(obj.RefPartyName);

    $('#TotalNetWeight').val(obj.TotalNetWeight != null ? obj.TotalNetWeight.toFixed(3) : '0.00');
    $('#TotalGrossWeight').val(obj.TotalGrossWeight != null ? obj.TotalGrossWeight.toFixed(3) : '0.000');
    $('#TotalInvoiceValue').val(obj.TotalInvoiceValue != null ? obj.TotalInvoiceValue.toFixed(2) : '0.00');
    $('#AssessableValue').val(obj.AssessableValue != null ? obj.AssessableValue.toFixed(2) : '0.00');
    $('#CIFValue').val(obj.CIFValue != null ? obj.CIFValue.toFixed(2) : '0.00');
    $('#DutyAmount').val(obj.DutyAmount != null ? obj.DutyAmount.toFixed(2) : '0.00');

    if (obj.CreatedByName != null && obj.CreatedByName.length > 0)
        $('#CrBy').removeClass('d-none');

    if (obj.CreatedAt != null && obj.CreatedAt.length > 0)
        $('#CrDt').removeClass('d-none');

    if (obj.LastUpdatedByName != null && obj.LastUpdatedByName.length > 0)
        $('#MoBy').removeClass('d-none');

    if (obj.LastUpdatedAt != null && obj.LastUpdatedAt.length > 0)
        $('#MoDt').removeClass('d-none');

    $('#CreatedBy').text(HandleNullTextValue(obj.CreatedByName));
    $('#CreatedAt').text(HandleNullTextValue(obj.CreatedAt));

    $('#ModifiedBy').text(HandleNullTextValue(obj.LastUpdatedByName));
    $('#ModifiedAt').text(HandleNullTextValue(obj.LastUpdatedAt));

    $('#ClientRemarks').val(obj.ClientRemarks);
    $('#Remarks').val(obj.Remarks);
    $('#MarksNo').val(obj.MarksNo);

    $('#NewChargesCurrency').val(obj.ChargesCurrency);
    $('#NewChargesCurrencyExchangeRate').val(obj.ChargesCurrencyExchangeRate != null ? obj.ChargesCurrencyExchangeRate.toFixed(2) : '0.00');


    $('#HiddenPortLoading').val(obj.PortLoadingCode);
    $('#PortLoading').val(obj.PortLoading);

    $('#HiddenOrigin').val(obj.OriginCode);
    $('#Origin').val(obj.Origin);

    $('#HiddenCountryOrigin').val(obj.CountryOriginCode);
    $('#CountryOrigin').val(obj.CountryOrigin);

    $('#HiddenConsignment').val(obj.ConsignmentCode);
    $('#Consignment').val(obj.Consignment);

    $('#HiddenCountryConsignment').val(obj.CountryConsignmentCode);
    $('#CountryConsignment').val(obj.CountryConsignment);

    $('#HiddenPortShipment').val(obj.PortShipmentCode);
    $('#PortShipment').val(obj.PortShipment);

    $('#HiddenPortDischarge').val(obj.PortDischargeCode);
    $('#PortDischarge').val(obj.PortDischarge);

    $('#HiddenDeliveryPlace').val(obj.DeliveryPlaceCode);
    $('#DeliveryPlace').val(obj.DeliveryPlace);

    $('#VslName').val(obj.VslName);
    $('#VoyageNo').val(obj.VoyageNo);
    $('#FederVsl').val(obj.FederVsl);
    $('#FederVoyageNo').val(obj.FederVoyageNo);

    $('#BillofLading').val(obj.BillofLading);
    $('#BLDate').val(obj.BLDate);

    $('#HiddenSoldTo').val(obj.SoldTo);
    $('#SoldTo').val(obj.SoldToName);
    $('#ValuationMethod').val(obj.ValuationMethod);

    $('#HiddenShipper').val(obj.Shipper);
    ShSelecBranc = obj.ShipperBranchUid;

    $('#Shipper').val(obj.ShipperName).trigger('blur');
    $('#HiddenIndentor').val(obj.Indentor);
    $('#Indentor').val(obj.IndentorName);

    if (obj.ShippingLine != null) {
        $('#HiddenShippingLine').val(obj.ShippingLine);
        $('#ShippingLine').val(obj.ShippingLineName).trigger('blur');

        if (obj.DetentionSlab != null)
            Detslab = obj.DetentionSlab;
    }

    $('#BoxTypeNo').val(obj.BoxTypeNo);
    $('#BoxType').val(obj.BoxType);
    $('#ContainerTypeNo').val(obj.ContainerTypeNo);
    $('#ContainerType').val(obj.ContainerType);
    $('#BalesTypeNo').val(obj.BalesNo);
    $('#BalesType').val(obj.BalesType);
    $('#ModeOfTransport').val(obj.ModeOfTransport);
    $('#CustomPortCode').val(obj.CustomPortCode);
    $('#CustomPortName').val(obj.CustomPortName);
    $('#ContainerLoadType').val(obj.ContainerLoadType);

    $('#PaymentTerms').val(obj.PaymentTerms);
    $('#PortIGMNo').val(obj.PortIGMNo);
    $('#PortIGMDate').val(obj.PortIGMDate);
    $('#LocalIGMNo').val(obj.LocalIGMNo);
    $('#LocalIGMDate').val(obj.LocalIGMDate);
    $('#SMTPNo').val(obj.SMTPNo);
    $('#SMTPDate').val(obj.SMTPDate);
    $('#HBLNo').val(obj.HBLNo);
    $('#HBLDate').val(obj.HBLDate);

    $('#MBLNo').val(obj.MBLNo);
    $('#MBLDate').val(obj.MBLDate);
    $('#BEType').val(obj.BEType);

    if (obj.BEType == 'W')
        $('#WareHouseDetails,#BondN,#BondD').removeClass('d-none');
    else if (obj.BEType == 'X')
        $('#WareHouseJD,#WareHouseDetails,#BondN,#BondD').removeClass('d-none');


    $('#HiddenWareHouseCode').val(obj.WareHouseCode);
    $('#WareHouseCode').val(obj.WareHouseCode);
    $('#BondNo').val(obj.BondNo);
    $('#BondDate').val(obj.BondDate);

    $('#ImporterType').val(obj.ClientType);
    $('#PaymentMethodCode').val(obj.PaymentMethodCode);
    $('#FileWeight').val(obj.FileWeight);

    $('#KachchaBE').prop('checked', obj.KachchaBE);
    $('#KachchaDetails').val(obj.KachchaDetails);
    $('#GreenChReq').prop('checked', obj.GreenChReq);
    $('#GreenChDetails').val(obj.GreenChDetails);
    $('#Section48Requested').prop('checked', obj.Section48Requested);
    $('#Section48Details').val(obj.Section48Details);
    $('#WhetherPriorBE').prop('checked', obj.WhetherPriorBE);
    $('#FirstChReq').prop('checked', obj.FirstChReq);
    $('#FirstChDetails').val(obj.FirstChDetails);


    $('#AmendmentCode').val(obj.AmendmentCode);
    $('#RequestLetterNumber').val(obj.RequestLetterNumber);
    $('#RequestDate').val(obj.RequestDate);
    $('#AmendmentReason').val(obj.AmendmentReason);



}

//FUNCTION FOR FILL CONTAINER TABLE DATA IN CONTAINER TABLE FOR EDIT
function FillContainerDetailsData(obj) {

    let ContainerFirstChild = $('#TblContainerDetails').find('tbody tr:first-child');
    let Cont = '';

    $.each(obj, function (ind, ele) {
        if (ind == 0) {
            Cont = ContainerFirstChild;
            fn();
        }
        else {
            ContainerFirstChild.find('.ContainerArrivalDate,.ContainerExamineDate,.OutChargeDate,.GatePassDate,.ContainerDeliveryDate,.ContainerDestuffingDate,.ContainerDeliverToParty,.ContainerEmptyDate,.ReUseDate,.ContainerGroundRentLFDDate,.ScanOkDate').datepicker("destroy").removeAttr('id');

            Cont = ContainerFirstChild.clone();
            fn();

            $('#TblContainerDetails tbody').append(Cont);

            $('.datepickerAll').datepicker({
                changeMonth: true,
                changeYear: true,
                dateFormat: 'dd/mm/yy'
            });
        }

        function fn() {
            Cont.find('.ContainerNo').val(ele.ContainerNo);
            Cont.find('.SealNo').val(ele.SealNo);
            Cont.find('.OurSealNo').val(ele.OurSealNo);

            Cont.find('.ContType').val(ele.ContType);
            Cont.find('.HiddenContCFSType').val(ele.ContCFSType);
            Cont.find('.ContCFSType').val(ele.ContCFSTypeName);


            Cont.find('.ContainerWeight').val(HandleNullTextValueFixed(ele.ContainerWeight, 3));
            Cont.find('.ContainerArrivalDate').val(ele.ContainerArrivalDate);

            Cont.find('.ContainerExamineDate').val(ele.ContainerExamineDate);
            Cont.find('.OutChargeDate').val(ele.OutChargeDate);
            Cont.find('.GatePassDate').val(ele.GatePassDate);

            Cont.find('.ContainerDeliveryDate').val(ele.ContainerDeliveryDate);
            Cont.find('.ContainerDestuffingDate').val(ele.ContainerDestuffingDate);
            Cont.find('.ContainerDeliverToParty').val(ele.ContainerDeliverToParty);

            Cont.find('.ContainerEmptyDate').val(ele.ContainerEmptyDate);
            Cont.find('.HiddenEmptyYard').val(ele.EmptyYard);
            Cont.find('.EmptyYard').val(ele.EmptyYardName);

            Cont.find('.ReUseDate').val(ele.ReUseDate);
            Cont.find('.ReUseBy').val(ele.ReUseBy);
            Cont.find('.ContainerGroundRentLFDDate').val(ele.ContainerGroundRentLFDDate);

            Cont.find('.GRAmount').val(HandleNullTextValueFixed(ele.GRAmount, 2));
            Cont.find('.LRNo').val(ele.LRNo);
            Cont.find('.TruckNo').val(ele.TruckNo);

            Cont.find('.Loaded').val(ele.Loaded);
            Cont.find('.HiddenPrivateYard').val(ele.PrivateYard);
            Cont.find('.PrivateYard').val(ele.PrivateYardName);

            Cont.find('.GrossWeight').val(HandleNullTextValueFixed(ele.GrossWeight, 3));
            Cont.find('.TareWeight').val(HandleNullTextValueFixed(ele.TareWeight, 3));
            Cont.find('.NetWeight').val(HandleNullTextValueFixed(ele.NetWeight, 3));

            Cont.find('.HiddenTransporter').val(ele.Transporter);
            Cont.find('.Transporter').val(ele.TransporterName);
            Cont.find('.Destination').val(ele.Destination);

            Cont.find('.ExchangeRate').val(HandleNullTextValueFixed(ele.ExchangeRate, 2));
            Cont.find('.DemmAmount').val(HandleNullTextValueFixed(ele.DemmAmount, 2));
            Cont.find('.DetentionAmount').val(HandleNullTextValueFixed(ele.DetentionAmount, 2));


            if (ele.ForScan != null)
                Cont.find('.ForScan').prop('checked', ele.ForScan);
            if (ele.ScanPending != null)
                Cont.find('.ScanPending').prop('checked', ele.ScanPending);
            if (ele.NotScan != null)
                Cont.find('.NotScan').prop('checked', ele.NotScan);
            if (ele.Examine100 != null)
                Cont.find('.Examine100').prop('checked', ele.Examine100);
            if (ele.MScan != null)
                Cont.find('.MScan').prop('checked', ele.MScan);
            if (ele.RScan != null)
                Cont.find('.RScan').prop('checked', ele.RScan);
            if (ele.ScanImage != null)
                Cont.find('.ScanImage').prop('checked', ele.ScanImage);

            Cont.find('.ScanOkDate').val(ele.ScanOkDate);
            Cont.find('.ContainerRemarks').val(ele.ContainerRemarks);
        }
    });

    GenerateSerialNumberTable('TblContainerDetails', 'rn');
}

//FUNCTION FOR FILL INVOICE TABLE DATA IN INVOICE TABLE FOR EDIT
function FillInvoiceDetailsData(obj) {
    let InvoiceFirstChild = $('#TblInvoiceDetails').find('tbody tr:first-child');
    let InvT = '';
    let InvHtml = '';
    $.each(obj, function (ind, ele) {
        if (InvHtml == '')
            InvHtml = '<option value="0">---Select---</option>';
        InvHtml += '<option value="' + (ind + 1) + '">' + ele.InvoiceNo + '</option>';
        if (ind == 0) {
            InvT = InvoiceFirstChild;
            fn();
        }
        else {
            InvoiceFirstChild.find('.InvoiceDate,.TblSVBDate,.PODate,.ContractDate,.LCDate').datepicker("destroy").removeAttr("id");
            InvT = InvoiceFirstChild.clone();
            fn();
            $('#TblInvoiceDetails tbody').append(InvT);

            $('.datepickerAll').datepicker({
                changeMonth: true,
                changeYear: true,
                dateFormat: 'dd/mm/yy'
            });
        }
        function fn() {
            InvT.find('.rn').text(ind + 1);
            InvT.find('.Relation').val(ele.Relation);
            InvT.find('.InvoiceNo').val(ele.InvoiceNo);
            InvT.find('.InvoiceDate').val(ele.InvoiceDate);
            InvT.find('.NatureOfTransaction').val(ele.NatureOfTransaction);
            InvT.find('.InvoiceTerms').val(ele.InvoiceTerms);

            InvT.find('.HiddenInvoiceCurrency').val(ele.InvoiceCurrencyUid);
            InvT.find('.InvoiceCurrency').val(ele.InvoiceCurrency);
            InvT.find('.InvoiceCurrencyExchangeRate').val(HandleNullTextValueFixed(ele.InvoiceCurrencyExchangeRate, 2));

            InvT.find('.NetWeightMetric').val(HandleNullTextValueFixed(ele.NetWeightMetric, 3));
            InvT.find('.GrossWeightKg').val(HandleNullTextValueFixed(ele.GrossWeightKg, 3));
            InvT.find('.InvoiceValue').val(HandleNullTextValueFixed(ele.InvoiceValue, 2));

            InvT.find('.FreightPer').val(HandleNullTextValueFixed(ele.FreightPer, 4));
            InvT.find('.ActualFreight').val(HandleNullTextValueFixed(ele.ActualFreight, 2));
            InvT.find('.HiddenFreightCurrency').val(ele.FreightCurrencyUid);
            InvT.find('.FreightCurrency').val(ele.FreightCurrency);
            InvT.find('.FreightExchangeRate').val(HandleNullTextValueFixed(ele.FreightExchangeRate, 2));
            InvT.find('.FreightINR').val(HandleNullTextValueFixed(ele.FreightINR, 2));

            InvT.find('.InsurancePer').val(HandleNullTextValueFixed(ele.InsurancePer, 4));
            InvT.find('.ActualInsurance').val(HandleNullTextValueFixed(ele.ActualInsurance, 2));
            InvT.find('.HiddenInsuranceCurrency').val(ele.InsuranceCurrencyUid);
            InvT.find('.InsuranceCurrency').val(ele.InsuranceCurrency);
            InvT.find('.InsuranceExchangeRate').val(HandleNullTextValueFixed(ele.InsuranceExchangeRate, 2));
            InvT.find('.InsuranceINR').val(HandleNullTextValueFixed(ele.InsuranceINR, 2));

            InvT.find('.MiscCharges').val(HandleNullTextValueFixed(ele.MiscCharges, 2));
            InvT.find('.MiscChargesINR').val(HandleNullTextValueFixed(ele.MiscChargesINR, 2));

            InvT.find('.LoadingPer').val(HandleNullTextValueFixed(ele.LoadingPer, 4));
            InvT.find('.ActualLoading').val(HandleNullTextValueFixed(ele.ActualLoading, 2));
            InvT.find('.HiddenLoadingCurrency').val(ele.LoadingCurrencyUid);
            InvT.find('.LoadingCurrency').val(ele.LoadingCurrency);
            InvT.find('.LoadingExchangeRate').val(HandleNullTextValueFixed(ele.LoadingExchangeRate, 2));
            InvT.find('.LoadingINR').val(HandleNullTextValueFixed(ele.LoadingINR, 2));

            InvT.find('.HSSFlag').val(ele.HighSeaSaleFlag == true ? 'true' : '');
            InvT.find('.HiddenTblHSSeller').val(ele.HSSeller);
            InvT.find('.TblHSSeller').val(ele.AccHead);
            InvT.find('.TblHSSeller').val(ele.AccHead);
            InvT.find('.HiddenTblHSSAddress').val(ele.HSSellerBranchUid);
            InvT.find('.TblHSSAddress').val(ele.AccHead);
            InvT.find('.TblHSSellerIECCode').val(ele.AccHead);
            InvT.find('.TblHSSLoadRate').val(HandleNullTextValueFixed(ele.HSSLoadRate, 2));
            InvT.find('.TblHSSLoadAmount').val(HandleNullTextValueFixed(ele.HSSLoadAmount, 2));

            InvT.find('.TblSVBNo').val(ele.SVBNo);
            InvT.find('.TblSVBDate').val(ele.SVBDate);
            InvT.find('.TblSVBLoadCh').val(ele.SVBLoadCh == true ? 'true' : '');
            InvT.find('.TblSVBFlag').val(ele.SVBFlag);
            InvT.find('.TblSVBAssessableValue').val(HandleNullTextValueFixed(ele.SVBAssessableValue, 2));
            InvT.find('.TblSVBAssLoadFinal').val(ele.SVBAssLoadFinal);
            InvT.find('.TblSVBDuty').val(HandleNullTextValueFixed(ele.SVBDuty, 2));
            InvT.find('.TblSVBDutyLoadFinal').val(ele.SVBDutyLoadFinal);
            InvT.find('.TblSVBCustomHouse').val(ele.SVBCustomHouse);

            InvT.find('.PONumber').val(ele.PONumber);
            InvT.find('.PODate').val(ele.PODate);
            InvT.find('.ContractNumber').val(ele.ContractNumber);
            InvT.find('.ContractDate').val(ele.ContractDate);
            InvT.find('.LCNumber').val(ele.LCNumber);
            InvT.find('.LCDate').val(ele.LCDate);

            InvT.find('.AuthorizedEconomicOperatorCode').val(ele.AuthorizedEconomicOperatorCode);
            InvT.find('.AuthorizedEconomicOperatorCountry').val(ele.AuthorizedEconomicOperatorCountry);
            InvT.find('.AuthorizedEconomicOperatorCountryName').val(ele.AuthorizedEconomicOperatorCountryName);
            InvT.find('.AuthorizedEconomicOperatorRole').val(ele.AuthorizedEconomicOperatorRole);

        }
    });
    $('#NewItemInvoiceNo').html(InvHtml);
    $('.TblItemInvoiceNo').html(InvHtml);
    if (InvHtml != '')
        $('#NewJobInvoice').html(InvHtml);
    else
        $('#NewJobInvoice').html('<option value="0">---Select---</option>');

}

//FUNCTION FOR FILL ITEM TABLE DATA IN ITEM TABLE FOR EDIT
function FillItemDetailsData(obj) {

    let ItemFirstChild = $('#TblItemDetails').find('tbody tr:first-child');
    let It = '';
    let ItHtml = ''

    $.each(obj, function (ind, ele) {
        if (ItHtml == '')
            ItHtml = '<option value="0">---Select---</option>';
        ItHtml += '<option value="' + (ind + 1) + '">' + (ind + 1) + '-' + ele.ItemName + '</option>';

        if (ind == 0) {
            It = ItemFirstChild;
            fn();
        }
        else {
            It = ItemFirstChild.clone();
            fn();
            $('#TblItemDetails tbody').append(It);
        }

        function fn() {
            It.find('.rn').text(ind + 1);
            It.find('.TblItemInvoiceNo').val(ele.InvoiceSrNo);
            It.find('.TblReImport').val(ele.ReImport);
            It.find('.HiddenTblItemName').val(ele.ItemId);
            It.find('.TblItemName').val(ele.ItemName);
            It.find('.TblItemDescription').val(ele.ItemDescription1 + ele.ItemDescription2);
            It.find('.TblItemGenericDescription').val(ele.ItemGenericDescription);
            It.find('.HiddenTblItemEndUse').val(ele.EndUse);
            It.find('.TblItemEndUse').val(ele.EndUse);
            It.find('.TblItemEndUseDesc').val(ele.EndUseDesc);
            It.find('.HiddenTblItemCountryOrigin').val(ele.CountryOrigin);
            It.find('.TblItemCountryOrigin').val(ele.CountryOriginName);
            It.find('.TblItemAmount').val(HandleNullTextValueFixed(ele.ItemAmount, 2));
            It.find('.TblItemQuantity').val(HandleNullTextValueFixed(ele.Quantity, 6));
            It.find('.TblItemUnitPrice').val(HandleNullTextValueFixed(ele.ItemUnitPrice, 6));
            It.find('.HiddenTblUnitQuantityCode').val(ele.UnitQuantityCode);
            It.find('.TblUnitQuantityCode').val(ele.UnitQuantityCode);
            It.find('.TblItemFreight').val(HandleNullTextValueFixed(ele.ItemFreight, 2));
            It.find('.TblItemInsurance').val(HandleNullTextValueFixed(ele.ItemInsurance, 2));
            It.find('.TblItemMiscCharge').val(HandleNullTextValueFixed(ele.ItemMiscCharge, 2));
            It.find('.TblItemLoading').val(HandleNullTextValueFixed(ele.ItemLoading, 2));
            It.find('.TblHSSLoadAmount').val(HandleNullTextValueFixed(ele.ItemHSSAmount, 2));
            It.find('.TblItemCIFValue').val(HandleNullTextValueFixed(ele.ItemCIFValue, 2));
            It.find('.TblItemDutyAmount').val(HandleNullTextValueFixed(ele.ItemDutyAmount, 2));
            It.find('.TblItemDutyGone').val(HandleNullTextValueFixed(ele.ItemDutyGone, 2));

            //DUTY DETAILS          
            It.find('.HiddenTblLicCheck').val(ele.LicenseCheck);
            It.find('.TblItemMode').val(ele.ItemMode);
            It.find('.TblItemCategorySchemeCode').val(ele.ItemCategorySchemeCode);
            It.find('.TblRITCCode').val(ele.RITCCode);
            It.find('.TblItemCTH').val(ele.CTH);
            It.find('.TblItemCTEH').val(ele.CETH);
            It.find('.TblDEPBNotification').val(ele.DEPBNotification);
            It.find('.TblDEPBNotificationSrNo').val(ele.DEPBNotificationSrNo);
            It.find('.TblExempted').val(ele.DEPBExempted);
            It.find('.TblSQCQuantity').val(HandleNullTextValueFixed(ele.SQCQuantity, 6));
            It.find('.HiddenTblSQCQuantityCode').val(ele.SQCUnit);
            It.find('.TblSQCQuantityCode').val(ele.SQCUnit);

            It.find('.TblItemBCDNotification').val(ele.BCDNotification);
            It.find('.TblItemBCDNotificationSrNo').val(ele.BCDNotificationSrNo);
            It.find('.TblItemBCDRate').val(HandleNullTextValueFixed(ele.BCDRate, 2));
            It.find('.TblItemBCDAmount').val(HandleNullTextValueFixed(ele.BCDAmount, 2));

            It.find('.TblItemCVDNotification').val(ele.CVDNotification);
            It.find('.TblItemCVDNotificationSrNo').val(ele.CVDNotificationSrNo);
            It.find('.TblItemCVDRate').val(HandleNullTextValueFixed(ele.CVDRate, 2));
            It.find('.TblItemCVDAmount').val(HandleNullTextValueFixed(ele.CVDAmount, 2));

            It.find('.TblAdditionalNotification1').val(ele.AdditionalNotification1);
            It.find('.TblAdditionalNotification1SrNo').val(ele.AdditionalNotification1SrNo);
            It.find('.TblAdditionalNotification1Rate').val(HandleNullTextValueFixed(ele.AdditionalNotification1Rate, 2));
            It.find('.TblAdditionalNotification1Amount').val(HandleNullTextValueFixed(ele.AdditionalNotification1Amount, 2));

            It.find('.TblAdditionalNotification2').val(ele.AdditionalNotification2);
            It.find('.TblAdditionalNotification2SrNo').val(ele.AdditionalNotification2SrNo);
            It.find('.TblAdditionalNotification2Rate').val(HandleNullTextValueFixed(ele.AdditionalNotification2Rate, 2));
            It.find('.TblAdditionalNotification2Amount').val(HandleNullTextValueFixed(ele.AdditionalNotification2Amount, 2));

            It.find('.TblOtherNotification').val(ele.OtherNotification);
            It.find('.TblOtherNotificationSrNo').val(ele.OtherNotificationSrNo);
            It.find('.TblOtherNotificationRate').val(HandleNullTextValueFixed(ele.OtherNotificationRate, 2));
            It.find('.TblOtherNotificationAmount').val(HandleNullTextValueFixed(ele.OtherNotificationAmount, 2));

            It.find('.TblSocialWelfareNotification').val(ele.SocialWelfareNotification);
            It.find('.TblSocialWelfareNotificationSrNo').val(ele.SocialWelfareNotificationSrNo);
            It.find('.TblSocialWelfareRate').val(HandleNullTextValueFixed(ele.SocialWelfareNotificationRate, 2));
            It.find('.TblSocialWelfareAmount').val(HandleNullTextValueFixed(ele.SocialWelfareNotificationAmount, 2));

            It.find('.TblNCDNotification').val(ele.NCDNotification);
            It.find('.TblNCDNotificationSrNo').val(ele.NCDNotificationSrNo);
            It.find('.TblNCDNotificationRate').val(HandleNullTextValueFixed(ele.NCDNotificationRate, 2));
            It.find('.TblNCDNotificationAmount').val(HandleNullTextValueFixed(ele.NCDNotificationAmount, 2));

            It.find('.TblAntiDumpingDutyNotification').val(ele.AntiDumpingDutyNotification);
            It.find('.TblAntiDumpingDutyNotificationSrNo').val(ele.AntiDumpingDutyNotificationSrNo);
            It.find('.TblAntiDumpingDutyNotificationRate').val(HandleNullTextValueFixed(ele.AntiDumpingDutyNotificationRate, 2));
            It.find('.TblAntiDumpingDutyNotificationAmount').val(HandleNullTextValueFixed(ele.AntiDumpingDutyNotificationAmount, 2));

            It.find('.TblHealthNotification').val(ele.HealthNotification);
            It.find('.TblHealthNotificationSrNo').val(ele.HealthNotificationSrNo);
            It.find('.TblHealthNotificationRate').val(HandleNullTextValueFixed(ele.HealthNotificationRate, 2));
            It.find('.TblHealthNotificationAmount').val(HandleNullTextValueFixed(ele.HealthNotificationAmount, 2));

            It.find('.TblAdditionalCVDNotification').val(ele.AdditionalCVDNotification);
            It.find('.TblAdditionalCVDNotificationSrNo').val(ele.AdditionalCVDNotificationSrNo);
            It.find('.TblAdditionalCVDNotificationRate').val(HandleNullTextValueFixed(ele.AdditionalCVDNotificationRate, 2));
            It.find('.TblAdditionalCVDNotificationAmount').val(HandleNullTextValueFixed(ele.AdditionalCVDNotificationAmount, 2));

            It.find('.TblAggregateDutyNotification').val(ele.AggregateDutyNotification);
            It.find('.TblAggregateDutyNotificationSrNo').val(ele.AggregateDutyNotificationSrNo);
            It.find('.TblAggregateDutyNotificationRate').val(HandleNullTextValueFixed(ele.AggregateDutyNotificationRate, 2));
            It.find('.TblAggregateDutyNotificationAmount').val(HandleNullTextValueFixed(ele.AggregateDutyNotificationAmount, 2));

            It.find('.TblSafeguardDutyNotification').val(ele.SafeguardDutyNotification);
            It.find('.TblSafeguardDutyNotificationSrNo').val(ele.SafeguardDutyNotificationSrNo);
            It.find('.TblSafeguardDutyNotificationRate').val(HandleNullTextValueFixed(ele.SafeguardDutyNotificationRate, 2));
            It.find('.TblSafeguardDutyNotificationAmount').val(HandleNullTextValueFixed(ele.SafeguardDutyNotificationAmount, 2));

            It.find('.TblIGSTNotification').val(ele.IGSTNotification);
            It.find('.TblIGSTNotificationSrNo').val(ele.IGSTNotificationSrNo);
            It.find('.TblIGSTNotificationRate').val(HandleNullTextValueFixed(ele.IGSTNotificationRate, 2));
            It.find('.TblIGSTNotificationAmount').val(HandleNullTextValueFixed(ele.IGSTNotificationAmount, 2));

            It.find('.TblIGSTExemNotification').val(ele.IGSTExemNotification);
            It.find('.TblIGSTExemNotificationSrNo').val(ele.IGSTExemNotificationSrNo);
            It.find('.TblIGSTExemNotificationRate').val(HandleNullTextValueFixed(ele.IGSTExemNotificationRate, 2));
            It.find('.TblIGSTExemNotificationAmount').val(HandleNullTextValueFixed(ele.IGSTExemNotificationAmount, 2));

            It.find('.TblIGSTComCessNotification').val(ele.IGSTComCessNotification);
            It.find('.TblIGSTComCessNotificationSrNo').val(ele.IGSTComCessNotificationSrNo);
            It.find('.TblIGSTComCessNotificationRate').val(HandleNullTextValueFixed(ele.IGSTComCessNotificationRate, 2));
            It.find('.TblIGSTComCessNotificationAmount').val(HandleNullTextValueFixed(ele.IGSTComCessNotificationAmount, 2));

            It.find('.TblIGSTComCessExemNotification').val(ele.IGSTComCessExemNotification);
            It.find('.TblIGSTComCessExemNotificationSrNo').val(ele.IGSTComCessExemNotificationSrNo);
            It.find('.TblIGSTComCessExemNotificationRate').val(HandleNullTextValueFixed(ele.IGSTComCessExemNotificationRate, 2));
            It.find('.TblIGSTComCessExemNotificationAmount').val(HandleNullTextValueFixed(ele.IGSTComCessExemNotificationAmount, 2));

            //MANUFACTURER/PRODUCER DETAILS

            It.find('.HiddenTblItemManufacturerProducerGrowerName').val(ele.ManufacturerProducerGrower);
            It.find('.TblItemManufacturerProducerGrowerName').val(ele.ManufacturerProducerGrowerName);
            It.find('.TblItemManufacturerProducerCodeType').val(ele.ItemManufacturerProducerCodeType);
            It.find('.TblItemManufacturerProducerGrowerCode').val(ele.ItemManufacturerProducerGrowerCode);
            It.find('.TblItemManufacturerProducerGrowerAddress1').val(ele.ItemManufacturerProducerGrowerAddress1);
            It.find('.TblItemManufacturerProducerGrowerAddress2').val(ele.ItemManufacturerProducerGrowerAddress2);
            It.find('.TblItemManufacturerProducerGrowerCity').val(ele.ItemManufacturerProducerGrowerCity);
            It.find('.TblItemManufacturerProducerGrowerCountrySubDivision').val(ele.ItemManufacturerProducerGrowerCountrySubDivision);
            It.find('.TblItemManufacturerProducerGrowerPin').val(ele.ItemManufacturerProducerGrowerPin);
            It.find('.HiddenTblItemManufacturerCountry').val(ele.ItemManufacturerCountry);
            It.find('.TblItemManufacturerCountryName').val(ele.ItemManufacturerCountryName);
            It.find('.HiddenTblSourceCountryName').val(ele.SourceCountry);
            It.find('.TblSourceCountryName').val(ele.SourceCountryName);
            It.find('.HiddenTblTransitCountry').val(ele.TransitCountry);
            It.find('.TblTransitCountryName').val(ele.TransitCountryName);

            //OTHER DETAILS

            It.find('.TblItemBrandName').val(ele.BrandName);
            It.find('.TblItemModel').val(ele.Model);
            It.find('.TblPreferentialStandard').val(ele.PreferentialStandard);
            It.find('.TblRSPApplicability').val(ele.RSPApplicability);
            It.find('.TblCTHSerialNumber').val(ele.CTHSerialNumber);
            It.find('.TblSupplierSerialNumber').val(ele.SupplierSerialNumber);
            It.find('.TblQuantityAsPerAntiDumpingNotification').val(HandleNullTextValueFixed(ele.QuantityAsPerAntiDumpingNotification, 6));
            It.find('.TblTarrifValueNotification').val(ele.TarrifValueNotification);
            It.find('.TblTarrifValueItemSrNo').val(ele.TarrifValueItemSrNo);
            It.find('.TblQuantityAsPerTarrifValueNotification').val(HandleNullTextValueFixed(ele.QuantityAsPerTarrifValueNotification, 6));
            It.find('.TblSAPTANotification').val(ele.SAPTANotification);
            It.find('.TblSAPTANotificationSrNo').val(ele.SAPTANotificationSrNo);
            It.find('.TblQtyAsPerCTH').val(HandleNullTextValueFixed(ele.QtyAsPerCTH, 6));
            It.find('.TblQuantityAsPerCTH').val(HandleNullTextValueFixed(ele.QuantityAsPerCTH, 6));
            It.find('.TblPolicyParaNo').val(ele.PolicyParaNo);
            It.find('.TblPolicyYear').val(ele.PolicyYear);
            It.find('.TblPreviousBENo').val(ele.PreviousBENo);
            It.find('.TblPreviousBEDate').val(ele.PreviousBEDate);
            It.find('.TblPreviousUnitPrice').val(HandleNullTextValueFixed(ele.PreviousUnitPrice, 6));
            It.find('.HiddenTblPreviousCurrencyCode').val(ele.PreviousCurrency);
            It.find('.TblPreviousCurrency').val(ele.PreviousCurrencyCode);
            It.find('.HiddenTblPreviousCustomSite').val(ele.PreviousCustomSite);
            It.find('.TblPreviousCustomSiteName').val(ele.PreviousCustomSiteName);
            It.find('.TblCustomNotnExemptingCentralExciseFlag').val(ele.CustomNotnExemptingCentralExciseFlag);
            It.find('.TblAccessoryStatus').val(ele.AccessoryStatus);
            It.find('.TblItemAccessoriesOfItem').val(ele.AccessoriesOfItem);
        }
    });


    $('#NewItemLicense,#NewItemDestuff').html(ItHtml);
    $('.TblLicenseItemSr,.TblDestuffItemSr').html(ItHtml);
    if (ItHtml = '')
        $('#NewJobItem').html(ItHtml);
    else
        $('#NewJobItem').html('<option value="0">---Select---</option>');
}

//FUNCTION FOR FILL LICENSE TABLE DATA IN LICENSE TABLE FOR EDIT
function FillLicenseDetailsData(obj) {
    let LicenseFirstChild = $('#TblLicenceDetails').find('tbody tr:first-child');
    let Lit = '';

    $.each(obj, function (ind, ele) {
        if (ind == 0) {
            Lit = LicenseFirstChild;
            fn();
        }
        else {
            LicenseFirstChild.find('.TblLicenseRegisDate').datepicker("destroy").removeAttr("id");
            Lit = LicenseFirstChild.clone();
            fn();
            $('#TblLicenceDetails tbody').append(Lit);
            $('.datepickerAll').datepicker({
                changeMonth: true,
                changeYear: true,
                dateFormat: 'dd/mm/yy'
            });
        }
        function fn() {
            Lit.find('.rn').text(ind + 1);
            Lit.find('.TblLicenseItemSr').val(ele.ItemSerialNo);
            Lit.find('.TblLicenseType').val(ele.LicenseCode);
            Lit.find('.TblLicenseRegisNumber').val(ele.LicenseRegisNumber);
            Lit.find('.TblLicenseRegisDate').val(ele.LicenseRegisDate);
            Lit.find('.TblLicenseDebitQty').val(HandleNullTextValueFixed(ele.DebitQuantity, 6));
            Lit.find('.HiddenTblLicenseDebitQtyUnit').val(ele.LicenseDebitQtyUnit);
            Lit.find('.TblLicenseDebitQtyUnit').val(ele.LicenseDebitQtyUnit);
            Lit.find('.TblLicenseItemCIFValue').val(HandleNullTextValueFixed(ele.LicenseItemCIFValue, 2));
            Lit.find('.TblLicenseDebitBCDAmount').val(HandleNullTextValueFixed(ele.DebitBCDValue, 2));
            Lit.find('.TblLicenseDebitSWAmount').val(HandleNullTextValueFixed(ele.DebitSWValue, 2));
            Lit.find('.TblLicenseDebitIGSTAmount').val(HandleNullTextValueFixed(ele.DebitIGSTValue, 2));
            Lit.find('.TblLicenseDebitAmount').val(HandleNullTextValueFixed(ele.DebitValue, 2));
            Lit.find('.TblLicensePortCode').val(ele.LicensePortCode);
            Lit.find('.TblLicensePortName').val(ele.LicensePortName);
        }
    });
}

//FUNCTION FOR FILL DESTUFF TABLE DATA IN DESTUFF TABLE FOR EDIT
function FillDestuffDetailsData(obj) {

    let DestuffFirstChild = $('#TblDestuffDetails').find('tbody tr:first-child');
    let Det = '';

    $.each(obj, function (ind, ele) {
        if (ind == 0) {
            Det = DestuffFirstChild;
            fn();
        }
        else {
            DestuffFirstChild.find('.TblDeDeliveryDate').datepicker("destroy").removeAttr("id");
            Det = DestuffFirstChild.clone();
            fn();
            $('#TblDestuffDetails tbody').append(Det);
            $('.datepickerAll').datepicker({
                changeMonth: true,
                changeYear: true,
                dateFormat: 'dd/mm/yy'
            });
        }
        function fn() {
            Det.find('.TblDeDeliveryDate').val(ele.DeDeliveryDate);
            Det.find('.TblDestuffItemSr').val(ele.ItemSrNo);
            Det.find('.TblDeLRNo').val(ele.DeLRNo);
            Det.find('.TblDeTruckNo').val(ele.DeTruckNo);
            Det.find('.TblDeGrossWeight').val(HandleNullTextValueFixed(ele.DeGrossWeight, 3));
            Det.find('.TblDeTareWeight').val(HandleNullTextValueFixed(ele.DeTareWeight, 3));
            Det.find('.TblDeNetWeight').val(HandleNullTextValueFixed(ele.DeNetWeight, 3));
            Det.find('.TblDeBales').val(ele.DeBales);
            Det.find('.TblDeLoose').val(ele.DeLoose);
        }
    });
}

//FUNCTION FOR FILL JOB SUPPORT DOC TABLE DATA IN JOB SUPPORT DOC TABLE FOR EDIT
function FillJobSupportDocDetailsData(obj) {

    let JobSupportFirstChild = $('#TblJobSupportDocs').find('tbody tr:first-child');
    let JobSupportT = '';

    $.each(obj, function (ind, ele) {
        if (ind == 0) {
            JobSupportT = JobSupportFirstChild;
            fn();
        }
        else {
            JobSupportT = JobSupportFirstChild.clone();
            fn();
            $('#TblJobSupportDocs').append(JobSupportT);
        }
        function fn() {
            JobSupportT.find('.TblUniqueItemSrNo').val(ele.UniqueSerialNo);
            JobSupportT.find('.TblFileName').val(ele.FileName);
            JobSupportT.find('.TblInvoiceSrNo').val(ele.InvoiceSrNo);
            JobSupportT.find('.TblItemSrNo').val(ele.ItemSrno);
            JobSupportT.find('.TblDocLevel').val(ele.DocumentLevel);
            JobSupportT.find('.TblIceGate').val(ele.ICEGATEUserId);
            JobSupportT.find('.TblImgRefNo').val(ele.ImageReferenceNo);
            /*    JobSupportT.find('.TblDocRefNo').val(ele.DocumentReferenceNo);*/
            JobSupportT.find('.HiddenTblDocType').val(ele.DocumentTypeCode);
            JobSupportT.find('.TblDocType').val(ele.DocumentTypeCodeDescriptions);
            JobSupportT.find('.TblFileType').val(ele.FileType);
            JobSupportT.find('.TblDocUploadDate').val(ele.UploadDateTime);
            JobSupportT.find('.TblPlaceOfIssue').val(ele.PlaceOfIssue);
            JobSupportT.find('.TblDocIssueDate').val(ele.DocumentIssueDate);
            JobSupportT.find('.TblDocExpiryDate').val(ele.DocumentExpiryDate);
            JobSupportT.find('.HiddenTblDocIssuingParty').val(ele.DocumentIssuingParty);
            JobSupportT.find('.TblDocIssuingParty').val(ele.DocumentIssuingPartyName);
            JobSupportT.find('.TblDocIssuingPartyCode').val(ele.DocumentIssuingPartyCode);
            JobSupportT.find('.HiddenTblDocBeneficiaryParty').val(ele.DocumentBeneficiaryParty);
            JobSupportT.find('.TblDocBeneficiaryParty').val(ele.DocumentBeneficiaryPartyName);
            JobSupportT.find('.TblDocBeneficiaryPartyCode').val(ele.DocumentBeneficiaryPartyCode);
        }
    });
    GenerateSerialNumberTable('TblJobSupportDocs', 'rn');
}

//FUNCTION FOR FILL BOND TABLE DATA IN BOND TABLE FOR EDIT
function FillBondDetailsData(obj) {
    let BondFirstChild = $('#TblBondDetails').find('tbody tr:first-child');
    let BondT = '';

    $.each(obj, function (ind, ele) {
        if (ind == 0) {
            BondT = BondFirstChild;
            fn();
        }
        else {
            BondT = BondFirstChild.clone();
            fn();
            $('#TblBondDetails tbody').append(BondT);
        }
        function fn() {
            BondT.find('.TblBondNo').val(ele.BondNumber);
            BondT.find('.TblBondCode').val(ele.BondCode);
            BondT.find('.TblBondPort').val(ele.BondPort);
            BondT.find('.TblBondPortName').val(ele.BondPortName);
        }
    });
    GenerateSerialNumberTable('TblBondDetails', 'rn');
}

//FUNCTION FOR FILL CERTIFICATE TABLE DATA IN CERTIFICATE TABLE FOR EDIT
function FillCertificateDetailsData(obj) {
    let CertificateFirstChild = $('#TblCertificateDetails').find('tbody tr:first-child');
    let CertificateT = '';

    $.each(obj, function (ind, ele) {
        if (ind == 0) {
            CertificateT = CertificateFirstChild;
            fn();
        }
        else {
            CertificateT = CertificateFirstChild.clone();
            fn();
            $('#TblCertificateDetails').append(CertificateT);
        }

        function fn() {
            CertificateT.find('.TblCertificateNo').val(ele.CertificateNumber);
            CertificateT.find('.TblCertificateDate').val(ele.CertificateDate);
            CertificateT.find('.TblCertificateCode').val(ele.CertificateType);
        }
    });
    GenerateSerialNumberTable('TblCertificateDetails', 'rn');
}

//FUNCTION FOR FILL ITEM MODE
function FillItemMode(DrpID) {
    try {
        AjaxSubmission(null, "/_Layout/FillItemMode", $('input[name=__RequestVerificationToken]').val()).done(function (data) {
            let obj = data;
            if (obj.status == true) {
                if (obj.responsecode == '100')
                    BindDropdown(obj.data.Table, DrpID, 'ItemModeUid', 'ItemModeName', '----select----');
                else if (obj.responsecode == '604')
                    BindDropdown(null, DrpID, 'ItemModeUid', 'ItemModeName', '----select----');
                else
                    Toast(RetrieveMessage(obj.responsecode), "Message", "error");
            }
            else
                window.location.href = '/ClientLogin/ClientLogin';

        }).fail(function (result) {
            console.log(result.Message);
        });
    }
    catch (e) {
        console.log(e.message);
    }
}

//NEWRITCCODE BLUR EVENT
$('#NewRITCCode').blur(function () {
    $('#HiddenNewItemCTH').val($('#HiddenNewRITCCode').val());
    $('#NewItemCTH').val($('#NewRITCCode').val());
    FillSQC($('#NewRITCCode').val());
    GetDutyRate($('#NewItemCTH').val());
});

//FILL SQC DETAILS
function FillSQC(RITC) {
    try {
        $('#HiddenNewSQCUnitCode,#NewSQCUnitCode').val('');
        const dataString = {};
        dataString.RITC = RITC;
        AjaxSubmission(JSON.stringify(dataString), "/_Layout/GetSQCUnit", $('input[name=__RequestVerificationToken]').val()).done(function (data) {
            let obj = data;
            if (obj.status == true) {
                if (obj.responsecode == '100') {
                    $('#HiddenNewSQCUnitCode,#NewSQCUnitCode').val(obj.data.Table[0].RITCUnit);
                }
            }
            else
                window.location.href = '/ClientLogin/ClientLogin';
        }).fail(function (result) {
            console.log(result.Message);
        });
    }
    catch (e) {
        console.log(e.message);
    }
}

//FUNCTION FOR GET BCD RATE 
function GetDutyRate(CTH) {
    try {
        $('#NewItemBCDRate').val('0.00');
        const dataString = {};
        dataString.CTH = CTH;
        AjaxSubmission(JSON.stringify(dataString), "/_Layout/GetDutyRate", $('input[name=__RequestVerificationToken]').val()).done(function (data) {
            let obj = data;

            if (obj.status == true) {
                if (obj.responsecode == '100') {
                    $('#NewItemBCDRate').val(HandleNullTextValueFixed(obj.data.Table[0].RTA, 2));
                    $('#HiddenNewIGSTNotification').val(obj.data.Table1[0].NOTN);
                    $('#NewIGSTNotification').val(obj.data.Table1[0].NOTN);
                    $('#NewIGSTNotificationSrNo').val(obj.data.Table1[0].SLNO);
                    $('#NewIGSTNotificationRate').val(HandleNullTextValueFixed(obj.data.Table1[0].RTA, 2));
                    DutyCalculation();
                }
            }
            else
                window.location.href = '/ClientLogin/ClientLogin';
        }).fail(function (result) {
            console.log(result.Message);
        });
    }
    catch (e) {
        console.log(e.message);
    }
}

//JOBTYPE CHANGE EVENT
$('#JobType').change(function () {
    if ($('#JobType').val() == 'A') 
        $('#AmdJob,#AmendmentDetails-tab').removeClass('d-none');
    else 
        $('#AmdJob,#AmendmentDetails-tab').addClass('d-none');

    $('#SubJobNo,#HiddenAmendmentCode,#AmendmentCode,#RequestLetterNumber,#RequestDate,#AmendmentReason').val('');   
    GetJobNo($('#JobType').val());

});

//FUNCTION FOR ACTIVE AMENDMENT TAB
function ActiveAmendmentTab() {
    $("#AmendmentDetails-tab").addClass('active');
    $("#AmendmentDetails").addClass('active show');

    $("#ShipmentDetails,#ContainerDetails,#InvoiceDetails,#EDIDetails,#ItemDetails,#DestuffDetails,#LicenseDetails,#CFSChargeDetails,#ESanchitDetails,#BondDetails,#CertificateDetails").removeClass('active show');

    $("#ShipmentDetails-tab,#ContainerDetails-tab,#InvoiceDetails-tab,#EDIDetails-tab,#ItemDetails-tab,#DestuffDetails-tab,#LicenseDetails-tab,#CFSChargeDetails-tab,#ESanchitDetails-tab,#BondDetails-tab,#CertificateDetails-tab").removeClass('active');
}

//FUNCTION FOR GET OLD JOB DATA
function GetOldJobData(JobUid) {
    try {
        if ($('#' + JobUid).val() != null && $('#' + JobUid).val() != undefined && $('#' + JobUid).val().trim().length > 0) {
            const dataString = {};
            dataString.JobUid = $('#' + JobUid).val();
            AjaxSubmission(JSON.stringify(dataString), "/ImportJobEntry/CheckJobUidExist", $('input[name=__RequestVerificationToken]').val()).done(function (data) {
                let obj = data;
                if (obj.status == true) {
                    if (obj.responsecode == '100') {
                        $.confirm({
                            title: '',
                            content: 'Fetch All Job Data.',
                            type: 'green',
                            boxWidth: '300px',
                            useBootstrap: false,
                            typeAnimated: true,
                            columnClass: 'small',
                            containerFluid: true,
                            draggable: true,
                            buttons: {
                                tryAgain: {
                                    text: 'Confirm',
                                    btnClass: 'btn-green',
                                    action: function () {
                                        const dataString = {};
                                        dataString.JobId = $('#' + JobUid).val();
                                        formid = $('#' + JobUid).val();
                                        AjaxSubmission(JSON.stringify(dataString), "/ImportJobEntry/FormEdit", $('[name="__RequestVerificationToken"]').val()).done(function (data) {
                                            let obj = data;
                                            if (obj.status == true) {
                                                if (obj.responsecode == '100') {

                                                    $('#AddNewJobESanchit').removeClass('d-none');

                                                    $("#CreatedByModifiedBy").css('display', 'block');
                                                    $("#CreatedByModifiedBy").css('width', '100%');

                                                    FillLetters(obj.data.Table8[0].JobNo);  //FILL LETTER DETAILS
                                                    FillBillDetails(obj.data.Table8[0].JobUid);  //FILL BILL DETAILS
                                                    FillMainDetailsData(obj.data.Table8[0], false);  //FILL MAIN DETAILS
                                                    FillContainerDetailsData(obj.data.Table);  //FILL CONTAINER DETAILS
                                                    FillInvoiceDetailsData(obj.data.Table1);  //FILL INVOICE DETAILS  
                                                    FillItemDetailsData(obj.data.Table2);  //FILL ITEM DETAILS DATA
                                                    FillLicenseDetailsData(obj.data.Table3);  //FILL LICENSE DETAILS DATA
                                                    FillDestuffDetailsData(obj.data.Table4);  //FILL DESTUFF DETAILS DATA
                                                    FillBondDetailsData(obj.data.Table6);  //FILL BOND DETAILS DATA
                                                    FillCertificateDetailsData(obj.data.Table7);  //FILL CERTIFICATE DETAILS DATA

                                                }
                                                else
                                                    Toast(RetrieveMessage(obj.responsecode), "Message", "error");
                                            }
                                            else
                                                window.location.href = '/ClientLogin/ClientLogin';

                                            HideLoader();
                                        }).fail(function (data) {
                                            console.log(data.Message);
                                            HideLoader();
                                        });
                                    }
                                },
                                cancel: function () {
                                    $('#ImporterName').focus();
                                }
                            }
                        });
                    }
                    else
                        Toast(RetrieveMessage(obj.responsecode), 'Message', 'error');
                }
                else
                    window.location.href = '/ClientLogin/ClientLogin';
            }).fail(function (result) {
                console.log(result.Message);
            });
        }

    }
    catch (e) {
        console.log(e.message);
    }
}

//OLDJOBNO BUTTON CLICK EVENT
$('#OldJobNo').on('input', function () {
    $('#HiddenOldJobNo').val('');
});

//WAREHOUSEJOBNO BUTTON CLICK EVENT
$('#WareHouseJobNo').on('input', function () {
    $('#HiddenWareHouseJobNo').val('');
});

//BILLOFENTRY DROPDOWN CHANGE EVENT
$('#BillOfEntry').change(function () {
    let val = $('#BillOfEntry').val();
    $('#WhetherPriorBE').prop('checked', val == 'P' ? true : false);
});

//BETYPE DROPDOWN CHANGE EVENT
$('#BEType').change(function () {
    let val = $('#BEType').val();

    $('#WareHouseJD,#WareHouseDetails,#BondN,#BondD').addClass('d-none');
    $('#HiddenWareHouseJobNo,#WareHouseJobNo,#HiddenWareHouseCode,#WareHouseCode,#BondNo,#BondDate').val('');

    if (val == 'W')
        $('#WareHouseDetails,#BondN,#BondD').removeClass('d-none');
    else if (val == 'X')
        $('#WareHouseJD,#WareHouseDetails,#BondN,#BondD').removeClass('d-none');
});

//FUNCTION FOR GET BILL OF ENTRY PDF FILE
function GetBillOfEntryFile(JobUid) {
    try {
        $.confirm({
            title: '',
            content: 'Bill Of Entry.',
            type:'green',
            boxWidth: '460px',
            useBootstrap: false,
            typeAnimated: true,
            columnClass: 'small',
            containerFluid: true,
            draggable: true,
            backgroundDismissAnimation: 'glow',
            escapeKey: 'cancel',
            buttons: {        
                NormalBoe: {
                    text: 'Normal BOE',
                    btnClass: 'btn-blue Cmbtn text-capitalize',
                    keys: ['enter', 'shift'],
                    action: function () {
                        const dataString = {};
                        dataString.JobUid = JobUid;
                        dataString.Type = 'FirstCopy';
                        AjaxSubmission(JSON.stringify(dataString), "/ImportJobEntry/GetBEFile", $('[name="__RequestVerificationToken"]').val()).done(function (data) {
                            let obj = data;
                            if (obj.status == true) {
                                if (obj.responsecode == '100')
                                    window.open(obj.data);
                                else
                                    Toast(RetrieveMessage(obj.responsecode), "Message", "error");
                            }
                            else
                                window.location.href = '/ClientLogin/ClientLogin';
                        }).fail(function (data) {
                            console.log(data.Message);
                        });
                    }
                },
                FirstCopy: {
                    text: 'First Copy',
                    btnClass: 'btn-blue Cmbtn text-capitalize',
                    keys: ['enter'],
                    action: function () {
                        const dataString = {};
                        dataString.JobUid = JobUid;
                        dataString.Type = 'FirstCopy';
                        AjaxSubmission(JSON.stringify(dataString), "/ImportJobEntry/GetBillOfEntryFile", $('[name="__RequestVerificationToken"]').val()).done(function (data) {
                            let obj = data;
                            if (obj.status == true) {
                                if (obj.responsecode == '100')
                                    window.open(obj.data);
                                else
                                    Toast(RetrieveMessage(obj.responsecode), "Message", "error");
                            }
                            else
                                window.location.href = '/ClientLogin/ClientLogin';
                        }).fail(function (data) {
                            console.log(data.Message);
                        });
                    }

                },
                FinalCopy: {
                    text: 'Final OCC ',
                    btnClass: 'btn-blue Cmbtn text-capitalize',
                    keys: ['enter'],
                    action: function () {
                        const dataString = {};
                        dataString.JobUid = JobUid;
                        dataString.Type = 'FinalCopy';
                        AjaxSubmission(JSON.stringify(dataString), "/ImportJobEntry/GetBillOfEntryFile", $('[name="__RequestVerificationToken"]').val()).done(function (data) {
                            let obj = data;
                            if (obj.status == true) {
                                console.log(obj);
                                if (obj.responsecode == '100')
                                    window.open(obj.data);
                                else
                                    Toast(RetrieveMessage(obj.responsecode), "Message", "error");
                            }
                            else
                                window.location.href = '/ClientLogin/ClientLogin';
                        }).fail(function (data) {
                            console.log(data.Message);
                        });
                    }
                },                
                cancel: {
                    text: 'Close',
                    btnClass: 'btn-red Cmbtn text-capitalize',
                    keys: ['enter'],
                    action: function () {
                    }
                }
            }
        });
    }
    catch (e) {
        console.log(e.message);
    }
}

//FUNCTION FOR JOB ATTACHMENT
function JobAttachment(JobUid, JobNo) {
    AjaxSubmission(null, "/ImportJobEntry/CheckEditFilePermission", $('[name="__RequestVerificationToken"]').val()).done(function (data) {
        let obj = data;
        if (obj.status == true) {           
            if (obj.responsecode == '100') {
                console.log(DocumentUploadModal)
                DocumentUploadModal.style.display = 'block';
                formid = JobUid;
                DocUploadResetdata();
                $('#UploadTitle').html("Upload Document :- " + JobNo);
                CommonFormList('JobDocUpload JDU INNER JOIN document_type_master DTM ON DTM.doc_type_uid =JDU.DocTypeUid', ' JDU.DocUploadUId, DTM.doc_type, JDU.FilePath,JDU.JobNo', 'FilePath');

            }
            else {
                Toast(RetrieveMessage(obj.responsecode), "Message", "error");
               
            }              
        }
        else
            window.location.href = '/ClientLogin/ClientLogin';
    }).fail(function (data) {
        console.log(data.Message);
    });

   
}

//#endregion

//#region /****************************CONTAINER DETAILS TAB ALL FUNCTION START****************************/

////MBLONMARKSNO BUTTON CLICK EVENT
//let val1 = true
//let val2 = true
//$('#MblonMarksNo').click(function () {
//    if ($('#HBLNo').val() != $('#HBLNo').val()) {
//        if (val1 && $('#HBLNo').val() == "") {
//            $('#MarksNo').val() == $('#MBLNo').val() ? true : $('#MarksNo').val($('#MBLNo').val());
//        }
//        else if (val1 && $('#HBLNo').val() != "") {
//            $('#MarksNo').val() == $('#MBLNo').val() ? true : $('#MarksNo').val($('#HBLNo').val() + $('#MBLNo').val());
//        }

//    }
//    else {
//        $('#MarksNo').val() == $('#MBLNo').val() ? true : $('#MarksNo').val($('#MBLNo').val());
//    }
//    val1 = false
//})

////HBLONMARKSNO BUTTON CLICK EVENT
//$('#HblonMarksNo').click(function () {
//    if ($('#HBLNo').val() != $('#MBLNo').val()) {
//        if (val2 && $('#MBLNo').val() == "")
//            $('#MarksNo').val() == $('#HBLNo').val() ? true : $('#MarksNo').val($('#HBLNo').val());
//        else if (val2 && $('#MBLNo').val() != "")
//            $('#MarksNo').val() == $('#HBLNo').val() ? true : $('#MarksNo').val($('#MBLNo').val() + $('#HBLNo').val());
//    }
//    else
//        $('#MarksNo').val() == $('#HBLNo').val() ? true : $('#MarksNo').val($('#HBLNo').val());
//    val2 = false
//});

////MBLNO BUTTON CLICKED EVENT
//$('#MBLNo').click(function () {
//    val1 = true
//});
////HBLNO BUTTON CLICKED EVENT
//$('#HBLNo').click(function () {
//    val2 = true
//});

//FUNCTION FOR CLONE CONTAINER ROW
function CloneContainerRow() {
    let contNo = $('#ContainerTypeNo').val().trim();
    let contType = $('#ContainerType').val().trim();
    let tblContLength = $('#TblContainerDetails tbody tr').length;
    let tbody = $('#TblContainerDetails').find('tbody');
    let firstTr = $(tbody).find('tr:first');

    if (contNo != null && contNo != undefined && contNo.length > 0 && contType != null && contType != undefined && contType.length > 0) {
        if (contNo > tblContLength) {
            let rowClone = contNo - tblContLength;
            for (let i = 0; i < rowClone; i++) {
                firstTr.find('.ContainerArrivalDate,.ContainerExamineDate,.ContainerDeliveryDate,.ContainerDestuffingDate,.ContainerDeliverToParty,.ContainerEmptyDate,.ContainerGroundRentLFDDate').datepicker('destroy').removeAttr('id');
                let newRow = $(firstTr).clone();

                newRow.find('.ContainerNo,.SealNo,.HiddenContType,.ContType,.HiddenContCFSType,.ContCFSType,.ContainerArrivalDate,.ContainerExamineDate,.ContainerDeliveryDate,.ContainerDestuffingDate,.ContainerDeliverToParty,.ContainerEmptyDate,.ContainerGroundRentLFDDate,.HiddenPrivateYard,.PrivateYard,.HiddenTransporter,.Transporter,.Destination,.ContainerRemarks').val('');

                newRow.find('.Loaded').val('Loaded');

                newRow.find('.ContainerWeight,.GrossWeight,.TareWeight,.NetWeight').val('0.000');
                newRow.find('.GRAmount,.ExchangeRate,.DetentionAmount').val('0.00');

                $('#TblContainerDetails').append(newRow);

                $('.datepickerAll').datepicker({
                    changeMonth: true,
                    changeYear: true,
                    dateFormat: 'dd/mm/yy'
                });


            }
        }
        else if (contNo < tblContLength)
            $('#TblContainerDetails tbody').find(`tr:gt(${contNo - 1})`).remove();
        $('#TblContainerDetails tbody tr').find('.ContType').val($('#ContainerType').val());
    }
    else {
        $('#TblContainerDetails tbody').find(`tr:gt(0)`).remove();

        $('#TblContainerDetails tbody').find('.ContainerNo,.SealNo,.HiddenContType,.ContType,.HiddenContCFSType,.ContCFSType,.ContainerArrivalDate,.ContainerExamineDate,.ContainerDeliveryDate,.ContainerDestuffingDate,.ContainerDeliverToParty,.ContainerEmptyDate,.ContainerGroundRentLFDDate,.HiddenPrivateYard,.PrivateYard,.HiddenTransporter,.Transporter,.Destination,.ContainerRemarks').val('');

        $('#TblContainerDetails tbody').find('.Loaded').val('Loaded');

        $('#TblContainerDetails tbody').find('.ContainerWeight,.GrossWeight,.TareWeight,.NetWeight').val('0.000');
        $('#TblContainerDetails tbody').find('.GRAmount,.ExchangeRate,.DetentionAmount').val('0.00');
    }
}

//MBL ON MARKS NUMBER BUTTON CLICK EVENT
let val1 = val2 = val3 = false;

$('#MblonMarksNo').click(function () {
    if ($('#MarksNo').val() == "AS PER B/L" || $('#MarksNo').val() == '')
        $('#MarksNo').val($('#MBLNo').val());
    else if (!val1)
        $('#MarksNo').val($('#MarksNo').val() + ' ' + $('#MBLNo').val());
    if ($('#MarksNo').val() == '')
        $('#MarksNo').val('AS PER B/L');
    val1 = true;
})

//HBL ON MARKS NUMBER BUTTON CLICK EVENT
$('#HblonMarksNo').click(function () {
    if ($('#MarksNo').val() == "AS PER B/L" || $('#MarksNo').val() == '')
        $('#MarksNo').val($('#HBLNo').val());
    else if (!val2)
        $('#MarksNo').val($('#MarksNo').val() + ' ' + $('#HBLNo').val());
    if ($('#MarksNo').val() == '')
        $('#MarksNo').val('AS PER B/L');
    val2 = true;
});

//CONTAINER ON MARKS NUMBER BUTTON CLICK EVENT
$('#ContonMarksNo').click(function () {
    let marks = '';
    if ($('#MarksNo').val() == "AS PER B/L" || $('#MarksNo').val() == '') {
        $('#TblContainerDetails tbody tr').each(function (ind, ele) {

            if ($(ele).find('.ContainerNo').val().trim().length > 0)
                marks += $(ele).find('.ContainerNo').val() + ',';
        });

        $('#MarksNo').val(marks.slice(0, marks.length - 1));
        val3 = true;
    }
    if (!val3) {
        $('#TblContainerDetails tbody tr').each(function (ind, ele) {
            if ($(ele).find('.ContainerNo').val().trim().length > 0)
                marks += $(ele).find('.ContainerNo').val() + ',';
        });
        $('#MarksNo').val($('#MarksNo').val() + marks.slice(1, marks.length));
    }
    if ($('#MarksNo').val() == '')
        $('#MarksNo').val('AS PER B/L');
    val3 = true;
});

//CONTAINER BUTTON INPUT EVENT
function ChangeMarksNoVal() {
    val1 = val2 = val3 = false;   
    $('#MarksNo').val('AS PER B/L');
};

//HBLNO BUTTON INPUT EVENT
$('#HBLNo').on('input', function () {
    val1 = val2 = val3 = false;
    $('#MarksNo').val('AS PER B/L');
});

//FUNCTION FOR VALIDATE DUPLICATE CONATINER NUMBER
function ValidateDuplicateConatinerNumber() {
    let arr = [];
    let duplicates = [];

    $("#TblContainerDetails tbody tr").each(function () {
        if ($(this).find('.ContainerNo').val().trim().length > 0)
            arr.push($(this).find('.ContainerNo').val().trim());
    });

    arr.forEach(function (value, index, array) {
        if (array.indexOf(value, index + 1) !== -1 && duplicates.indexOf(value) === -1) {
            duplicates.push(value);
        }
    });

    if (duplicates.length > 0) {
        Toast('Duplicate Container Number.', 'Message', 'error');
    }
}

//FUNCTION FOR ADD MARKS NUMBER
function AddMarksNumber() {
    //let MarksNo = "";

    //$("#TblContainerDetails tbody tr").each(function () {
    //    MarksNo = MarksNo + ", " + $(this).find('.ContainerNo').val().trim();
    //});

    //$("#MarksNo").val(MarksNo.substring(1, MarksNo.length));
}


//FUNCTION FOR VALIDATE CONTAINER DETAILS DATA
function ValidateContainerDetailsData() {
    let Vflag = 0;
    //let CLType = $('#ContainerLoadType').val();
    //if (CLType == 'L')
    //    Vflag = 0;
    //else {
    //    $('#TblContainerDetails tbody tr').each(function (ind, ele) {
    //        if ($(ele).find('.ContainerNo').val().trim().length <= 0) {
    //            Toast('Please Add Container Number in Row-' + (ind + 1) + '', 'Message', 'error');
    //            Vflag = 1;
    //            return false;
    //        }
    //    });
    //}

    let contNo = $('#ContainerTypeNo').val().trim();
    let contType = $('#ContainerType').val().trim();

    if (contNo != null && contNo != undefined && contNo.length > 0 && contType != null && contType != undefined && contType.length > 0) {
        $('#TblContainerDetails tbody tr').each(function (ind, ele) {
            if ($(ele).find('.ContainerNo').val().trim().length <= 0) {
                Toast('Please Add Container Number in Row-' + (ind + 1) + '', 'Message', 'error');
                Vflag = 1;
                return false;
            }
        });
    }

    return Vflag;
}

//#endregion

//#region /****************************INVOICE DETAILS TAB ALL FUNCTION START****************************/

//FUNCTION FOR ACTIVE INVOICE TAB
function ActiveInvoiceDetailsTab() {
    $('#InvoiceDetails-tab').addClass('active');
    $('#InvoiceDetails').addClass('active show');
$('#ShipmentDetails,#ContainerDetails,#EDIDetails,#ItemDetails,#DestuffDetails,#LicenseDetails,#CFSChargeDetails,#ESanchitDetails,#BondDetails,#CertificateDetails').removeClass('active show');

    $('ShipmentDetails-tab,#ContainerDetails-tab,#EDIDetails-tab,#ItemDetails-tab,#DestuffDetails-tab,#LicenseDetails-tab,#CFSChargeDetails-tab,#ESanchitDetails-tab,#BondDetails-tab,#CertificateDetails-tab').removeClass('active');

}

//HIGH SEA SELLER ON INPUT EVENT
$('#HSSeller').on('input', function () {
    $('#HiddenHSSeller,#HSSellerIECCode').val('');
});

//HIGH SEA SELLER BLUR EVENT
$('#HSSeller').blur(function () {
    $('#HSSellerAddress').html('');
    if ($('#HiddenHSSeller').val().trim().length > 0) {
        FillHSSellerAddress($('#HiddenHSSeller').val(), 'HSSellerAddress');
        GetIECCode($('#HiddenHSSeller').val(), 'HSSellerIECCode');
    }
});

//FUNCTIONF OR FILL HIGH SEA SELLER ADDRESS
function FillHSSellerAddress(LId, DrpId) {
    try {
        const dataString = {};
        dataString.LedgerId = LId;
        AjaxSubmission(JSON.stringify(dataString), '/Master/_Layout/GetLedgerAddressWithBranch', $('input[name=__RequestVerificationToken]').val()).done(function (result) {
            let obj = result;
            if (obj.status == true) {
                if (obj.responsecode == '100') {
                    BindDropdownNew(obj.data.Table, DrpId, 'BranchUid', 'BranchAddress', '--Select--');
                    if (HSSelecBranc == '' || HSSelecBranc == undefined || HSSelecBranc == null)
                        $('#HSSellerAddress').val(obj.data.Table[0].BranchUid);
                    else {
                        $('#HSSellerAddress').val(HSSelecBranc);
                        HSSelecBranc = '';
                    }
                }
                else
                    BindDropdownNew(null, DrpId, 'BranchUid', 'BranchAddress', '--Select--');
            }
            else
                window.location.href = '/ClientLogin/ClientLogin';
        }).fail(function (result) {
            console.log(result.Message);
        });
    }
    catch (e) {
        console.log(e.message);
    }
}

//NEWINVOICETERMS SELECT CHANGE EVENT
$('#NewInvoiceTerms').change(function () {
    let Vl = $('#NewInvoiceTerms option:selected').text();
    if (Vl == 'CIF') {
        $('#NewFreightPerInvoice,#NewInsurancePerInvoice').val('0.0000').attr('disabled', 'disabled');
        $('#NewActualFreightInvoice,#NewFreightExchangeRateInvoice,#NewFreightINRInvoice,#NewActualInsuranceInvoice,#NewInsuranceExchangeRateInvoice,#NewInsuranceINRInvoice').val('0.00').attr('disabled', 'disabled');
        $('#HiddenNewFreightCurrencyInvoice,#NewFreightCurrencyInvoice,#HiddenNewInsuranceCurrencyInvoice,#NewInsuranceCurrencyInvoice').val('').attr('disabled', 'disabled');

    }
    else if (Vl == 'CI') {
        $('#NewInsurancePerInvoice').val('0.0000').attr('disabled', 'disabled');
        $('#NewActualInsuranceInvoice,#NewInsuranceExchangeRateInvoice,#NewInsuranceINRInvoice').val('0.00').attr('disabled', 'disabled');
        $('#HiddenNewInsuranceCurrencyInvoice,#NewInsuranceCurrencyInvoice').val('').attr('disabled', 'disabled');

        $('#NewFreightPerInvoice').val('0.0000').removeAttr('disabled');
        $('#NewActualFreightInvoice,#NewFreightExchangeRateInvoice,#NewFreightINRInvoice').val('0.00').removeAttr('disabled');
        $('#HiddenNewFreightCurrencyInvoice,#NewFreightCurrencyInvoice').val('').removeAttr('disabled');

    }
    else if (Vl == 'CF') {
        $('#NewFreightPerInvoice').val('0.0000').attr('disabled', 'disabled');
        $('#HiddenNewFreightCurrencyInvoice,#NewFreightCurrencyInvoice').val('').attr('disabled', 'disabled');
        $('#NewActualFreightInvoice,#NewFreightExchangeRateInvoice,#NewFreightINRInvoice').val('0.00').attr('disabled', 'disabled');

        $('#NewInsurancePerInvoice').val('0.0000').removeAttr('disabled');
        $('#NewActualInsuranceInvoice,#NewInsuranceExchangeRateInvoice,#NewInsuranceINRInvoice').val('0.00').removeAttr('disabled');
        $('#HiddenNewInsuranceCurrencyInvoice,#NewInsuranceCurrencyInvoice').val('').removeAttr('disabled', 'disabled');

    }
    else if (Vl == 'FOB') {
        $('#NewFreightPerInvoice,#NewActualFreightInvoice,#NewFreightExchangeRateInvoice,#NewFreightINRInvoice,#HiddenNewFreightCurrencyInvoice,#NewFreightCurrencyInvoice,#NewInsurancePerInvoice,#NewActualInsuranceInvoice,#HiddenNewInsuranceCurrencyInvoice,#NewInsuranceCurrencyInvoice,#NewInsuranceExchangeRateInvoice,#NewInsuranceINRInvoice').removeAttr('disabled');
    }
});

//FUNCTION FOR CALCULATE TOTAL INVOICE VALUE
function CalculateTotalInvoiceValue() {
    let TotalInvoiceValue = 0;
    $('#TotalInvoiceValue').val(parseFloat(0).toFixed(2));
    $('#TblInvoiceDetails tbody tr').each(function () {
        TotalInvoiceValue += parseFloat($(this).find('.InvoiceValue').val().trim());
    });
    if (isNaN(TotalInvoiceValue))
        $('#TotalInvoiceValue').val('0.00');
    else
        $('#TotalInvoiceValue').val(TotalInvoiceValue.toFixed(2));
}

//FUNCTION FOR CALCULATE TOTAL NET WEIGHT
function CalculateTotalNetWeight() {
    let TotalNetWeight = 0;
    $("#TblInvoiceDetails tbody tr").each(function () {
        TotalNetWeight += parseFloat($(this).find('.NetWeightMetric').val().trim());
    });
    if (isNaN(TotalNetWeight))
        $("#TotalNetWeight").val("0.000");
    else
        $("#TotalNetWeight").val(TotalNetWeight.toFixed(3));
}

//FUNCTION FORM CALCULATE TOTAL GROSS WEIGHT
function CalculateTotalGrossWeight() {
    let TotalGrossWeight = 0;
    $("#TblInvoiceDetails tbody tr").each(function () {
        TotalGrossWeight += parseFloat($(this).find('.GrossWeightKg').val().trim());
    });
    if (isNaN(TotalGrossWeight))
        $("#TotalGrossWeight").val("0.000");
    else
        $("#TotalGrossWeight").val(TotalGrossWeight.toFixed(3));

}

//FUNCTION FOR CALCULATE NEW LOADING WITH LOAD PERCENTAGE
function NewLoadingCalculate(fx) {
    let InvValue = 0, Excrate = 0, TLoading = 0, Loper = 0, LoErate = 0, ActLo = 0;

    InvValue = HandleNullNumericValue($('#NewInvoiceValue').val());
    Excrate = HandleNullNumericValue($('#NewInvoiceCurrencyExchangeRate').val());
    Loper = HandleNullNumericValue($('#NewLoadingPerInvoice').val());

    if (Loper > 0 && InvValue > 0 && Excrate > 0) {
        TLoading = (InvValue * Excrate * Loper) / 100;
        $('#NewLoadingINRInvoice').val(TLoading.toFixed(fx));
        $('#NewActualLoadingInvoice,#NewLoadingExchangeRateInvoice').val('0.00');
        $('#HiddenNewLoadingCurrencyInvoice,#NewLoadingCurrencyInvoice').val('');
    }
    else if (Loper == 0) {
        ActLo = HandleNullNumericValue($('#NewActualLoadingInvoice').val());
        LoErate = HandleNullNumericValue($('#NewLoadingExchangeRateInvoice').val());
        if (ActLo > 0 && LoErate > 0) {
            TLoading = ActLo * LoErate;
            $('#NewLoadingINRInvoice').val(TLoading.toFixed(fx));
        }
        else
            $('#NewLoadingINRInvoice').val('0.00');
    }
    else
        $('#NewLoadingINRInvoice').val('0.00');
}

//FUNCTION FOR CALCULATE NEW FREIGHT WITH FREIGHT PERCENTAGE
function NewFreightCalculate(fx) {
    let InvValue = 0, Excrate = 0, Tfreight = 0, Fper = 0, FrtErate = 0, ActFr = 0;

    InvValue = HandleNullNumericValue($('#NewInvoiceValue').val());
    Excrate = HandleNullNumericValue($('#NewInvoiceCurrencyExchangeRate').val());
    Fper = HandleNullNumericValue($('#NewFreightPerInvoice').val());

    if (Fper > 0 && InvValue > 0 && Excrate > 0) {
        Tfreight = (InvValue * Excrate * Fper) / 100;
        $('#NewFreightINRInvoice').val(Tfreight.toFixed(fx));
        $('#NewActualFreightInvoice,#NewFreightExchangeRateInvoice').val('0.00');
        $('#HiddenNewFreightCurrencyInvoice,#NewFreightCurrencyInvoice').val('');
    }
    else if (Fper == 0) {
        ActFr = HandleNullNumericValue($('#NewActualFreightInvoice').val());
        FrtErate = HandleNullNumericValue($('#NewFreightExchangeRateInvoice').val());
        if (ActFr > 0 && FrtErate > 0) {
            Tfreight = ActFr * FrtErate;
            $('#NewFreightINRInvoice').val(Tfreight.toFixed(fx));
        }
        else
            $('#NewFreightINRInvoice').val('0.00');
    }
    else
        $('#NewFreightINRInvoice').val('0.00');
}

//FUNCTION FOR CALCULATE NEW INSURANCE WITH INSURANCE PERCENTAGE
function NewInsuranceCalculate(fx) {
    let InvValue = 0, Excrate = 0, TInsurance = 0, Iper = 0, ActIn = 0, InsErate = 0;

    InvValue = HandleNullNumericValue($('#NewInvoiceValue').val());
    Excrate = HandleNullNumericValue($('#NewInvoiceCurrencyExchangeRate').val());
    Iper = HandleNullNumericValue($('#NewInsurancePerInvoice').val());

    if (InvValue > 0 && Excrate > 0 && Iper > 0) {
        TInsurance = (InvValue * Excrate * Iper) / 100;
        $('#NewInsuranceINRInvoice').val(TInsurance.toFixed(fx));
        $('#NewActualInsuranceInvoice,#NewInsuranceExchangeRateInvoice').val('0.00');
        $('#HiddenNewInsuranceCurrencyInvoice,#NewInsuranceCurrencyInvoice').val('');
    }
    else if (Iper == 0) {
        ActIn = HandleNullNumericValue($('#NewActualInsuranceInvoice').val());
        InsErate = HandleNullNumericValue($('#NewInsuranceExchangeRateInvoice').val());
        if (ActIn > 0 && InsErate > 0) {
            TInsurance = ActIn * InsErate;
            $('#NewInsuranceINRInvoice').val(TInsurance.toFixed(fx));
        }
        else
            $('#NewInsuranceINRInvoice').val('0.00');
    }
    else
        $('#NewInsuranceINRInvoice').val('0.00');
}

//FUNCTION FOR CALCULATE NEW MISCELLANEOUS CHARGE
function NewMiscellaneousChargeCalculate(fx) {
    let InvValue = 0, Excrate = 0, MiscInr = 0, Misc = 0;

    InvValue = HandleNullNumericValue($('#NewInvoiceValue').val());
    Excrate = HandleNullNumericValue($('#NewInvoiceCurrencyExchangeRate').val());
    Misc = HandleNullNumericValue($('#NewMiscChargesInvoice').val());
    MiscInr = HandleNullNumericValue($('#NewMiscChargesINRInvoice').val());

    if (InvValue > 0 && Excrate > 0 && Misc > 0) {
        MiscInr = Misc * Excrate;
        if (MiscInr > 0)
            $('#NewMiscChargesINRInvoice').val(MiscInr.toFixed(fx));
        else
            $('#NewMiscChargesINRInvoice').val('0.00');
    }
}

//NEWADDINVOICE BUTTON CLICK EVENT
$('#NewAddInvoice').click(function () {

    if ($('#NewInvoiceNo').val().trim().length <= 0) {
        $('#NewInvoiceNo').focus();
        Toast('Please Add Invioce Number', 'Message', 'error');
        return;
    }
    else if ($('#NewInvoiceDate').val().trim().length < 10) {
        $('#NewInvoiceDate').focus();
        Toast('Please Add Invioce Date', 'Message', 'error');
        return;
    }
    else if ($('#NewInvoiceTerms').val() == '0') {
        $('#NewInvoiceTerms').focus();
        Toast('Please Select Invoice Terms.', 'Message', 'error');
        return;
    }
    else if ($('#NewInvoiceCurrency').val().trim().length <= 0) {
        $('#NewInvoiceCurrency').focus();
        Toast('Please Add Invioce Currency', 'Message', 'error');
        return;
    }
    else if ($('#NewInvoiceCurrencyExchangeRate').val().trim() <= 0) {
        $('#NewInvoiceCurrencyExchangeRate').focus();
        Toast('Please Add Invioce Currency Exchange Rate', 'Message', 'error');
        return;
    }
    else if ($('#NewInvoiceValue').val().trim() <= 0) {
        $('#NewInvoiceValue').focus();
        Toast('Please Add Invioce Value', 'Message', 'error');
        return;
    }
    else
        NewAddInvoiceRow();

});

//FUNCTION FOR NEW ADD INVOICE 
function NewAddInvoiceRow() {
    let flag = 0;
    let TblLen = $('#TblInvoiceDetails tbody tr').length;
    let tbody = $('#TblInvoiceDetails').find('tbody');
    let FirstTr = $(tbody).find('tr:first');
    let Invt = '';

    $('#TblInvoiceDetails tbody tr').each(function (ind, ele) {
        if ($(ele).find('.InvoiceNo').val().trim() == $('#NewInvoiceNo').val().trim()) {
            flag = 1;
            return;
        }
    });

    function AddInvoiceData() {
        Invt.find('.Relation').val($('#NewRelationInvoice').val());

        Invt.find('.InvoiceNo').val($('#NewInvoiceNo').val().trim());
        Invt.find('.InvoiceDate').val($('#NewInvoiceDate').val());

        Invt.find('.NatureOfTransaction').val($('#NewNatureOfTransactionInvoice').val());
        Invt.find('.InvoiceTerms').val($('#NewInvoiceTerms').val());

        Invt.find('.HiddenInvoiceCurrency').val($('#HiddenNewInvoiceCurrency').val());
        Invt.find('.InvoiceCurrency').val($('#NewInvoiceCurrency').val());
        Invt.find('.InvoiceCurrencyExchangeRate').val($('#NewInvoiceCurrencyExchangeRate').val());

        Invt.find('.NetWeightMetric').val($('#NewNetWeightMetricInvoice').val());
        Invt.find('.GrossWeightKg').val($('#NewGrossWeightKgInvoice').val());

        Invt.find('.InvoiceValue').val($('#NewInvoiceValue').val());

        Invt.find('.FreightPer').val($('#NewFreightPerInvoice').val());
        Invt.find('.ActualFreight').val($('#NewActualFreightInvoice').val());
        Invt.find('.HiddenFreightCurrency').val($('#HiddenNewFreightCurrencyInvoice').val());
        Invt.find('.FreightCurrency').val($('#NewFreightCurrencyInvoice').val());
        Invt.find('.FreightExchangeRate').val($('#NewFreightExchangeRateInvoice').val());
        Invt.find('.FreightINR').val($('#NewFreightINRInvoice').val());

        Invt.find('.InsurancePer').val($('#NewInsurancePerInvoice').val());
        Invt.find('.ActualInsurance').val($('#NewActualInsuranceInvoice').val());
        Invt.find('.HiddenInsuranceCurrency').val($('#HiddenNewInsuranceCurrencyInvoice').val());
        Invt.find('.InsuranceCurrency').val($('#NewInsuranceCurrencyInvoice').val());
        Invt.find('.InsuranceExchangeRate').val($('#NewInsuranceExchangeRateInvoice').val());
        Invt.find('.InsuranceINR').val($('#NewInsuranceINRInvoice').val());

        Invt.find('.MiscCharges').val($('#NewMiscChargesInvoice').val());
        Invt.find('.MiscChargesINR').val($('#NewMiscChargesINRInvoice').val());

        Invt.find('.LoadingPer').val($('#NewLoadingPerInvoice').val());
        Invt.find('.ActualLoading').val($('#NewActualLoadingInvoice').val());
        Invt.find('.HiddenLoadingCurrency').val($('#HiddenNewLoadingCurrencyInvoice').val());
        Invt.find('.LoadingCurrency').val($('#NewLoadingCurrencyInvoice').val());
        Invt.find('.LoadingExchangeRate').val($('#NewLoadingExchangeRateInvoice').val());
        Invt.find('.LoadingINR').val($('#NewLoadingINRInvoice').val());

        if ($('#HighSeaSaleFlag').is(':checked') == true) {
            Invt.find('.HSSFlag').val('true');
            Invt.find('.HiddenTblHSSeller').val($('#HiddenHSSeller').val());
            Invt.find('.TblHSSeller').val($('#HSSeller').val());
            Invt.find('.HiddenTblHSSAddress').val($('#HSSellerAddress').val());

            if ($('#HSSellerAddress').val() != '00') {
                Invt.find('.TblHSSAddress').val($('#HSSellerAddress option:selected').text());
            }

            Invt.find('.TblHSSellerIECCode').val($('#HSSellerIECCode').val());
            Invt.find('.TblHSSLoadRate').val($('#HSSLoadRate').val());
            Invt.find('.TblHSSLoadAmount').val($('#HSSLoadAmount').val());
        }

        if ($('#NewSVBLoadCh').is(':checked') == true) {
            Invt.find('.TblSVBLoadCh').val('true');
            Invt.find('.TblSVBNo').val($('#NewSVBNo').val());
            Invt.find('.TblSVBDate ').val($('#NewSVBDate').val());
            Invt.find('.TblSVBFlag').val($('#NewSVBLoadType').val());
            Invt.find('.TblSVBAssessableValue').val($('#NewSVBAssessableValue').val());
            Invt.find('.TblSVBAssLoadFinal').val($('#NewSVBAssLoadFinal').val());
            Invt.find('.TblSVBDuty').val($('#NewSVBDuty').val());
            Invt.find('.TblSVBDutyLoadFinal').val($('#NewSVBDutyLoadFinal').val());
            Invt.find('.TblSVBCustomHouse').val($('#NewSVBCustomHouse').val());
        }

        Invt.find('.PONumber').val($('#NewPONumber').val().trim());
        Invt.find('.PODate').val($('#NewPODate').val());
        Invt.find('.ContractNumber').val($('#NewContractNumber').val().trim());
        Invt.find('.ContractDate').val($('#NewContractDate').val());
        Invt.find('.LCNumber').val($('#NewLCNumber').val().trim());
        Invt.find('.LCDate').val($('#NewLCDate').val());

        Invt.find('.AuthorizedEconomicOperatorCode').val($('#NewAuthorizedEconomicOperatorCode').val());
        Invt.find('.AuthorizedEconomicOperatorCountry').val($('#HiddenNewAuthorizedEconomicCountry').val());
        Invt.find('.AuthorizedEconomicOperatorCountryName').val($('#NewAuthorizedEconomicCountry').val());
        Invt.find('.AuthorizedEconomicOperatorRole').val($('#NewAuthorizedEconomicOperatorRole').val());
    }

    if (flag == 0) {
        if ($('#TblInvoiceDetails tbody tr').find('.InvoiceNo').val().trim().length <= 0 || $('#TblInvoiceDetails tbody tr').find('.InvoiceDate').val().trim().length < 10 || $('#TblInvoiceDetails tbody tr').find('.InvoiceCurrency').val().trim().length < 0 || $('#TblInvoiceDetails tbody tr').find('.InvoiceCurrencyExchangeRate').val().trim().length < 0 || $('#TblInvoiceDetails tbody tr').find('.InvoiceValue').val().trim().length < 0) {
            Invt = FirstTr;
            AddInvoiceData();

        }
        else {
            FirstTr.find('.InvoiceDate,.TblSVBDate,.PODate,.ContractDate,.LCDate').datepicker("destroy").removeAttr("id").val('');

            Invt = $(FirstTr).clone();
            Invt.find('.Relation').val('N');
            Invt.find('.InvoiceNo,.HiddenInvoiceCurrency,.InvoiceCurrency,.HiddenFreightCurrency,.FreightCurrency,.HiddenInsuranceCurrency,.InsuranceCurrency,.HiddenLoadingCurrency,.LoadingCurrency,.HSSFlag,.HiddenTblHSSeller,.TblHSSeller,.HiddenTblHSSAddress,.TblHSSAddress,.TblHSSellerIECCode,.TblSVBNo,.TblSVBLoadCh,.TblSVBFlag,.TblSVBAssLoadFinal,.TblSVBDutyLoadFinal,.TblSVBCustomHouse,.PONumber,.ContractNumber,.LCNumber,.AuthorizedEconomicOperatorCode,.AuthorizedEconomicOperatorCountry,.AuthorizedEconomicOperatorCountryName,.AuthorizedEconomicOperatorRole').val('');
            Invt.find('.NatureOfTransaction').val('S');
            Invt.find('.InvoiceTerms').val('0');
            Invt.find('.InvoiceCurrencyExchangeRate,.InvoiceValue,.ActualFreight,.FreightExchangeRate,.FreightINR,.ActualInsurance,.InsuranceExchangeRate,.InsuranceINR,.MiscCharges,.MiscChargesINR,.ActualLoading,.LoadingExchangeRate,.LoadingINR,.TblHSSLoadRate,.TblHSSLoadAmount,.TblSVBAssessableValue,.TblSVBDuty').val('0.00');
            Invt.find('.NetWeightMetric,.GrossWeightKg').val('0.000');
            Invt.find('.FreightPer,.InsurancePer,.LoadingPer').val('0.0000');

            AddInvoiceData();

            $('#TblInvoiceDetails').append(Invt);
            $('.datepickerAll').datepicker({
                changeMonth: true,
                changeYear: true,
                dateFormat: 'dd/mm/yy'
            });
            GenerateSerialNumberTable('TblInvoiceDetails', 'rn');

        }
        ResetNewInvoice(true);
        CalculateTotalNetWeight();
        CalculateTotalGrossWeight();
        CalculateTotalInvoiceValue();
        NewGenerateInvoiceNoList();
        Toast('Invoice Add Successfully.', 'Message', 'success');
    }
    else
        Toast('Duplicate Invoice Number.', 'Message', 'error');
}

//FUNCTION FOR EDIT INVOICE ROW ENTRY
function EditInvoiceRowEntry(e) {
    let Rn = $(e).parent().parent().find('.rn').text().trim();
    let InvNo = $(e).parent().parent().find('.InvoiceNo').val().trim();

    if (InvNo.length == 0)
        Toast('Invoice Number Blank!', 'Message', 'error');
    else {

        ResetNewInvoice();

        $('#NewAddInvoice').addClass('d-none');
        $('#NewUpdateInvoice').removeClass('d-none');

        $('#NewRownNumInvoice').val(Rn);

        $('#NewRelationInvoice').val($(e).parent().parent().find('.Relation').val());

        $('#NewInvoiceNo').val($(e).parent().parent().find('.InvoiceNo').val());
        $('#NewInvoiceDate').val($(e).parent().parent().find('.InvoiceDate').val());

        $('#NewNatureOfTransactionInvoice').val($(e).parent().parent().find('.NatureOfTransaction').val());
        $('#NewInvoiceTerms').val($(e).parent().parent().find('.InvoiceTerms').val()).trigger('change');

        $('#HiddenNewInvoiceCurrency').val($(e).parent().parent().find('.HiddenInvoiceCurrency').val());
        $('#NewInvoiceCurrency').val($(e).parent().parent().find('.InvoiceCurrency').val());
        $('#NewInvoiceCurrencyExchangeRate').val($(e).parent().parent().find('.InvoiceCurrencyExchangeRate').val());

        $('#NewNetWeightMetricInvoice').val($(e).parent().parent().find('.NetWeightMetric').val());
        $('#NewGrossWeightKgInvoice').val($(e).parent().parent().find('.GrossWeightKg').val());

        $('#NewInvoiceValue').val($(e).parent().parent().find('.InvoiceValue').val());

        $('#NewFreightPerInvoice').val($(e).parent().parent().find('.FreightPer').val());
        $('#NewActualFreightInvoice').val($(e).parent().parent().find('.ActualFreight').val());
        $('#HiddenNewFreightCurrencyInvoice').val($(e).parent().parent().find('.HiddenFreightCurrency').val());
        $('#NewFreightCurrencyInvoice').val($(e).parent().parent().find('.FreightCurrency').val());
        $('#NewFreightExchangeRateInvoice').val($(e).parent().parent().find('.FreightExchangeRate').val());
        $('#NewFreightINRInvoice').val($(e).parent().parent().find('.FreightINR').val());

        $('#NewInsurancePerInvoice').val($(e).parent().parent().find('.InsurancePer').val());
        $('#NewActualInsuranceInvoice').val($(e).parent().parent().find('.ActualInsurance').val());
        $('#HiddenNewInsuranceCurrencyInvoice').val($(e).parent().parent().find('.HiddenInsuranceCurrency').val());
        $('#NewInsuranceCurrencyInvoice').val($(e).parent().parent().find('.InsuranceCurrency').val());
        $('#NewInsuranceExchangeRateInvoice').val($(e).parent().parent().find('.InsuranceExchangeRate').val());
        $('#NewInsuranceINRInvoice').val($(e).parent().parent().find('.InsuranceINR').val());

        $('#NewMiscChargesInvoice').val($(e).parent().parent().find('.MiscCharges').val());
        $('#NewMiscChargesINRInvoice').val($(e).parent().parent().find('.MiscChargesINR').val());

        $('#NewLoadingPerInvoice').val($(e).parent().parent().find('.LoadingPer').val());
        $('#NewActualLoadingInvoice').val($(e).parent().parent().find('.ActualLoading').val());
        $('#HiddenNewLoadingCurrencyInvoice').val($(e).parent().parent().find('.HiddenLoadingCurrency').val());
        $('#NewLoadingCurrencyInvoice').val($(e).parent().parent().find('.LoadingCurrency').val());
        $('#NewLoadingExchangeRateInvoice').val($(e).parent().parent().find('.LoadingExchangeRate').val());
        $('#NewLoadingINRInvoice').val($(e).parent().parent().find('.LoadingINR').val());

        $('#NewPONumber').val($(e).parent().parent().find('.PONumber').val());
        $('#NewPODate').val($(e).parent().parent().find('.PODate').val());
        $('#NewContractNumber').val($(e).parent().parent().find('.ContractNumber').val());
        $('#NewContractDate').val($(e).parent().parent().find('.ContractDate').val());
        $('#NewLCNumber').val($(e).parent().parent().find('.LCNumber').val());
        $('#NewLCDate').val($(e).parent().parent().find('.LCDate').val());

        $('#NewAuthorizedEconomicOperatorCode').val($(e).parent().parent().find('.AuthorizedEconomicOperatorCode').val());
        $('#HiddenNewAuthorizedEconomicCountry').val($(e).parent().parent().find('.AuthorizedEconomicOperatorCountry').val());
        $('#NewAuthorizedEconomicCountry').val($(e).parent().parent().find('.AuthorizedEconomicOperatorCountryName').val());
        $('#NewAuthorizedEconomicOperatorRole').val($(e).parent().parent().find('.AuthorizedEconomicOperatorRole').val());

        if ($(e).parent().parent().find('.HSSFlag').val() == 'true') {
            $('#HighSeaSaleFlag').prop('checked', true);
            $('#HssDiv').removeClass('d-none');

            HSSelecBranc = $(e).parent().parent().find('.HiddenTblHSSAddress').val();
            $('#HiddenHSSeller').val($(e).parent().parent().find('.HiddenTblHSSeller').val());
            $('#HSSeller').val($(e).parent().parent().find('.TblHSSeller').val()).trigger('blur');
            $('#HSSLoadRate').val($(e).parent().parent().find('.TblHSSLoadRate').val());
            $('#HSSLoadAmount').val($(e).parent().parent().find('.TblHSSLoadAmount').val());
        }

        if ($(e).parent().parent().find('.TblSVBLoadCh').val() == 'true') {
            $('#NewSVBLoadCh').prop('checked', true);
            $('#SvbDiv').removeClass('d-none');

            $('#NewSVBNo').val($(e).parent().parent().find('.TblSVBNo').val());
            $('#NewSVBDate').val($(e).parent().parent().find('.TblSVBDate').val());
            $('#NewSVBCustomHouse').val($(e).parent().parent().find('.TblSVBCustomHouse').val());
            $('#NewSVBLoadType').val($(e).parent().parent().find('.TblSVBFlag').val());
            $('#NewSVBAssLoadFinal').val($(e).parent().parent().find('.TblSVBAssLoadFinal').val());
            $('#NewSVBAssessableValue').val($(e).parent().parent().find('.TblSVBAssessableValue').val());
            $('#NewSVBDutyLoadFinal').val($(e).parent().parent().find('.TblSVBDutyLoadFinal').val());
            $('#NewSVBDuty').val($(e).parent().parent().find('.TblSVBDuty').val());

        }

    }
}

//NEWUPDATEINVOICE BUTTON CLICK EVENT
$('#NewUpdateInvoice').click(function () {
    if ($('#NewInvoiceNo').val().trim().length <= 0) {
        $('#NewInvoiceNo').focus();
        Toast('Please Add Invioce Number', 'Message', 'error');
        return;
    }
    else if ($('#NewInvoiceDate').val().trim().length < 10) {
        $('#NewInvoiceDate').focus();
        Toast('Please Add Invioce Date', 'Message', 'error');
        return;
    }
    else if ($('#NewInvoiceTerms').val() == '0') {
        $('#NewInvoiceTerms').focus();
        Toast('Please Select Invoice Terms.', 'Message', 'error');
        return;
    }
    else if ($('#NewInvoiceCurrency').val().trim().length <= 0) {
        $('#NewInvoiceCurrency').focus();
        Toast('Please Add Invioce Currency', 'Message', 'error');
        return;
    }
    else if ($('#NewInvoiceCurrencyExchangeRate').val().trim() <= 0) {
        $('#NewInvoiceCurrencyExchangeRate').focus();
        Toast('Please Add Invioce Currency Exchange Rate', 'Message', 'error');
        return;
    }
    else if ($('#NewInvoiceValue').val().trim() <= 0) {
        $('#NewInvoiceValue').focus();
        Toast('Please Add Invioce Value', 'Message', 'error');
        return;
    }
    else
        UpdateNewInvoiceRow($('#NewRownNumInvoice').val());
});

//FUNCTION FOR NEW UPDATE INVOICE 
function UpdateNewInvoiceRow(Rn) {
    let flag = 0;
    $('#TblInvoiceDetails tbody tr').each(function (ind, ele) {
        if ($(ele).find('.InvoiceNo').val().trim() == $('#NewInvoiceNo').val().trim() && $(ele).find('.rn').text().trim() != Rn) {
            flag = 1;
            return;
        }
    });

    if (flag == 1)
        Toast('Duplicate Invoice.', 'Message', 'error');
    else {
        $('#TblInvoiceDetails tbody tr').each(function (ind, ele) {
            if ($(ele).find('.rn').text().trim() == Rn) {

                $(ele).find('.Relation').val($('#NewRelationInvoice').val());

                $(ele).find('.InvoiceNo').val($('#NewInvoiceNo').val().trim());
                $(ele).find('.InvoiceDate').val($('#NewInvoiceDate').val());

                $(ele).find('.NatureOfTransaction').val($('#NewNatureOfTransactionInvoice').val());
                $(ele).find('.InvoiceTerms').val($('#NewInvoiceTerms').val());

                $(ele).find('.HiddenInvoiceCurrency').val($('#HiddenNewInvoiceCurrency').val());
                $(ele).find('.InvoiceCurrency').val($('#NewInvoiceCurrency').val());
                $(ele).find('.InvoiceCurrencyExchangeRate').val($('#NewInvoiceCurrencyExchangeRate').val());

                $(ele).find('.NetWeightMetric').val($('#NewNetWeightMetricInvoice').val());
                $(ele).find('.GrossWeightKg').val($('#NewGrossWeightKgInvoice').val());

                $(ele).find('.InvoiceValue').val($('#NewInvoiceValue').val());

                $(ele).find('.FreightPer').val($('#NewFreightPerInvoice').val());
                $(ele).find('.ActualFreight').val($('#NewActualFreightInvoice').val());
                $(ele).find('.HiddenFreightCurrency').val($('#HiddenNewFreightCurrencyInvoice').val());
                $(ele).find('.FreightCurrency').val($('#NewFreightCurrencyInvoice').val());
                $(ele).find('.FreightExchangeRate').val($('#NewFreightExchangeRateInvoice').val());
                $(ele).find('.FreightINR').val($('#NewFreightINRInvoice').val());

                $(ele).find('.InsurancePer').val($('#NewInsurancePerInvoice').val());
                $(ele).find('.ActualInsurance').val($('#NewActualInsuranceInvoice').val());
                $(ele).find('.HiddenInsuranceCurrency').val($('#HiddenNewInsuranceCurrencyInvoice').val());
                $(ele).find('.InsuranceCurrency').val($('#NewInsuranceCurrencyInvoice').val());
                $(ele).find('.InsuranceExchangeRate').val($('#NewInsuranceExchangeRateInvoice').val());
                $(ele).find('.InsuranceINR').val($('#NewInsuranceINRInvoice').val());

                $(ele).find('.MiscCharges').val($('#NewMiscChargesInvoice').val());
                $(ele).find('.MiscChargesINR').val($('#NewMiscChargesINRInvoice').val());

                $(ele).find('.LoadingPer').val($('#NewLoadingPerInvoice').val());
                $(ele).find('.ActualLoading').val($('#NewActualLoadingInvoice').val());
                $(ele).find('.HiddenLoadingCurrency').val($('#HiddenNewLoadingCurrencyInvoice').val());
                $(ele).find('.LoadingCurrency').val($('#NewLoadingCurrencyInvoice').val());
                $(ele).find('.LoadingExchangeRate').val($('#NewLoadingExchangeRateInvoice').val());
                $(ele).find('.LoadingINR').val($('#NewLoadingINRInvoice').val());

                $(ele).find('.PONumber').val($('#NewPONumber').val().trim());
                $(ele).find('.PODate').val($('#NewPODate').val());
                $(ele).find('.ContractNumber').val($('#NewContractNumber').val().trim());
                $(ele).find('.ContractDate').val($('#NewContractDate').val());
                $(ele).find('.LCNumber').val($('#NewLCNumber').val().trim());
                $(ele).find('.LCDate').val($('#NewLCDate').val());

                $(ele).find('.AuthorizedEconomicOperatorCode').val($('#NewAuthorizedEconomicOperatorCode').val());
                $(ele).find('.AuthorizedEconomicOperatorCountry').val($('#HiddenNewAuthorizedEconomicCountry').val());
                $(ele).find('.AuthorizedEconomicOperatorCountryName').val($('#NewAuthorizedEconomicCountry').val());
                $(ele).find('.AuthorizedEconomicOperatorRole').val($('#NewAuthorizedEconomicOperatorRole').val());

                if ($('#HighSeaSaleFlag').is(':checked') == true) {
                    $(ele).find('.HSSFlag').val('true');
                    $(ele).find('.HiddenTblHSSeller').val($('#HiddenHSSeller').val());
                    $(ele).find('.TblHSSeller').val($('#HSSeller').val());
                    $(ele).find('.HiddenTblHSSAddress').val($('#HSSellerAddress').val());

                    if ($('#HSSellerAddress').val() != '00') {
                        $(ele).find('.TblHSSAddress').val($('#HSSellerAddress option:selected').text());
                    }

                    $(ele).find('.TblHSSellerIECCode').val($('#HSSellerIECCode').val());
                    $(ele).find('.TblHSSLoadRate').val($('#HSSLoadRate').val());
                    $(ele).find('.TblHSSLoadAmount').val($('#HSSLoadAmount').val());
                }

                if ($('#NewSVBLoadCh').is(':checked') == true) {
                    $(ele).find('.TblSVBLoadCh').val('true');
                    $(ele).find('.TblSVBNo').val($('#NewSVBNo').val());
                    $(ele).find('.TblSVBDate ').val($('#NewSVBDate').val());
                    $(ele).find('.TblSVBFlag').val($('#NewSVBLoadType').val());
                    $(ele).find('.TblSVBAssessableValue').val($('#NewSVBAssessableValue').val());
                    $(ele).find('.TblSVBAssLoadFinal').val($('#NewSVBAssLoadFinal').val());
                    $(ele).find('.TblSVBDuty').val($('#NewSVBDuty').val());
                    $(ele).find('.TblSVBDutyLoadFinal').val($('#NewSVBDutyLoadFinal').val());
                    $(ele).find('.TblSVBCustomHouse').val($('#NewSVBCustomHouse').val());
                }

                ResetNewInvoice();
                CalculateTotalNetWeight();
                CalculateTotalGrossWeight();
                CalculateTotalInvoiceValue();
                Toast('Update Invoice Successfully.', 'Message', 'success');
                NewGenerateInvoiceNoList();
            }
        });
    }
}

// FUNCTION FOR DELETE INVOICE ROW  
function DeleteInvoiceRowEntry(e) {
    let flag = 0;
    let RowCount = $("#TblInvoiceDetails tbody tr").length;
    let InvNo = $(e).parent().parent().find('.InvoiceNo').val().trim();
    let InvRowNo = $(e).parent().parent().find('.rn').text();;
    let DelItSr = [];

    $('#TblItemDetails tbody tr').each(function (ind, ele) {
        if ($(ele).find('.TblItemInvoiceNo').val().trim().length > 0) {
            if ($(ele).find('.TblItemInvoiceNo option:selected').text() == InvNo) {
                flag = 1;
                DelItSr.push((ind + 1));
            }
        }
    });

    if (InvNo.length == 0)
        Toast('Invoice Number Blank!', 'Message', 'error');
    else if ($('#NewAddInvoice').hasClass('d-none')) {
        Toast('Please Update Invoice.', 'Message', 'error');
    }
    else {
        $.confirm({
            title: '',
            content: 'Are You Sure Want To Delete?',
            type: 'red',
            boxWidth: '300px',
            useBootstrap: false,
            typeAnimated: true,
            columnClass: 'small',
            containerFluid: true,
            draggable: true,
            buttons: {
                tryAgain: {
                    text: 'Confirm',
                    btnClass: 'btn-red',
                    action: function () {
                        if (flag == 1) {
                            $.confirm({
                                title: '',
                                content: 'This Invoice Number Use In Item Details.Are You Sure Want To Delete ?',
                                type: 'red',
                                boxWidth: '300px',
                                useBootstrap: false,
                                typeAnimated: true,
                                columnClass: 'small',
                                containerFluid: true,
                                draggable: true,
                                buttons: {
                                    tryAgain: {
                                        text: 'Confirm',
                                        btnClass: 'btn-red',
                                        action: function () {
                                            DeleteESanchitRowItemWise(DelItSr);  //DELETE ITEM FROM ESANCHIT
                                            DeleteDestuffRowItemWise(DelItSr); // DELETE ITEM FROM DESTUFF
                                            DeleteLicenseRowItemWise(DelItSr); // DELETE ITEM FROM LICENSE
                                            DeleteItemRowInvoiceWise(InvNo); // DELETE INVOICE FROM ITEM
                                            ResetDeleteInvoiceRowEntry(e, RowCount); //DELETE INVOICE ROW ENTRY

                                            NewGenerateItemNameList();
                                            CalculateTotalNetWeight();
                                            CalculateTotalGrossWeight();
                                            CalculateTotalInvoiceValue();
                                            GenerateSerialNumberTable('TblInvoiceDetails', 'rn');
                                            NewGenerateInvoiceNoList('Delete', InvRowNo);

                                        }
                                    },
                                    cancel: function () {
                                    }
                                }
                            });
                        }
                        else {
                            ResetDeleteInvoiceRowEntry(e, RowCount); //DELETE INVOICE ROW ENTRY
                            CalculateTotalNetWeight();
                            CalculateTotalGrossWeight();
                            CalculateTotalInvoiceValue();
                            GenerateSerialNumberTable('TblInvoiceDetails', 'rn');
                            NewGenerateInvoiceNoList();

                        }
                    }
                },
                close: function () {
                }
            }
        });
    }

}

//FUNCTION FOR RESET OR DELETE IN INVOICE ROW 
function ResetDeleteInvoiceRowEntry(e, RowCount) {
    if (RowCount > 1)
        $(e).parent().parent().remove();
    else {
        $(e).parent().parent().find('.Relation').val('N');
        $(e).parent().parent().find('.NatureOfTransaction').val('S');
        $(e).parent().parent().find('.InvoiceTerms').val('0');
        $(e).parent().parent().find('.InvoiceNo,.InvoiceDate,.HiddenInvoiceCurrency,.InvoiceCurrency,.HiddenFreightCurrency,.FreightCurrency,.HiddenInsuranceCurrency,.InsuranceCurrency,.HiddenLoadingCurrency,.LoadingCurrency,.HSSFlag,.HiddenTblHSSeller,.TblHSSeller,.HiddenTblHSSAddress,.TblHSSAddress,.TblHSSellerIECCode,.TblSVBNo,.TblSVBDate,.TblSVBLoadCh,.TblSVBFlag,.TblSVBAssLoadFinal,.TblSVBDutyLoadFinal,.TblSVBCustomHouse,.PONumber,.PODate,.ContractNumber,.ContractDate,.LCNumber,.LCDate,.AuthorizedEconomicOperatorCode,.AuthorizedEconomicOperatorCountry,.AuthorizedEconomicOperatorCountryName,.AuthorizedEconomicOperatorRole').val('');

        $(e).parent().parent().find('.InvoiceCurrencyExchangeRate,.InvoiceValue,.ActualFreight,.FreightExchangeRate,.FreightINR,.ActualInsurance,.InsuranceExchangeRate,.InsuranceINR,.MiscCharges,.MiscChargesINR,.ActualLoading,.LoadingExchangeRate,.LoadingINR,.TblHSSLoadRate,.TblHSSLoadAmount,.TblSVBAssessableValue,.TblSVBDuty').val('0.00');

        $(e).parent().parent().find('.NetWeightMetric,.GrossWeightKg').val('0.000');
        $(e).parent().parent().find('.FreightPer,.InsurancePer,.LoadingPer').val('0.0000');

    }
}

//FUNCTION FOR NEW INVOICE NUMBER LIST IN ITEM DETAILS
function NewGenerateInvoiceNoList(Type, InvRowNo) {
    let InvAr = [];
    let InvHtml = '';
    $('#TblInvoiceDetails tbody tr').each(function (ind, ele) {
        if ($(this).find('.InvoiceNo').val().trim().length > 0)
            InvAr.push($(this).find('.InvoiceNo').val().trim());
    });

    for (i = 0; i < InvAr.length; i++) {
        if (InvHtml == '')
            InvHtml = '<option value="0">---Select---</option>';
        InvHtml += '<option value="' + (i + 1) + '">' + InvAr[i] + '</option>';
    }

    $('#NewItemInvoiceNo').html(InvHtml);
    $('#NewJobInvoice,#NewJobItem').html('<option value="0">---Select---</option>');

    if (InvHtml != '')
        $('#NewJobInvoice').html(InvHtml);

    let ItmInvAr = [];
    $('#TblItemDetails tbody tr').each(function () {
        ItmInvAr.push($(this).find('.TblItemInvoiceNo').val());
    });
    $('.TblItemInvoiceNo').html(InvHtml);

    if (Type == 'Delete') {

        $('#TblItemDetails tbody tr').each(function (ind, ele) {
            if (ItmInvAr[ind] == null)
                ItmInvAr[ind] = 0;
            else if (ItmInvAr[ind] >= InvRowNo)
                ItmInvAr[ind] = ItmInvAr[ind] - 1;
            $(ele).find('.TblItemInvoiceNo').val(ItmInvAr[ind]);
        });
    }
    else {
        $('#TblItemDetails tbody tr').each(function (ind, ele) {
            if (ItmInvAr[ind] == null || ItmInvAr[ind] > InvAr.length)
                ItmInvAr[ind] = 0;
            $(ele).find('.TblItemInvoiceNo').val(ItmInvAr[ind]);
        });
    }
}

//FUNCTION FOR VALIDATE INVOICE DETAILS DATA
function ValidateInvoiceDetailsData() {
    let Vflag = 0;
    $('#TblInvoiceDetails tbody tr').each(function (ind, ele) {
        if ($('#TblInvoiceDetails tbody tr').length == 1) {
            if ($(ele).find('.InvoiceNo').val().trim().length > 0) {
                if ($(ele).find('.InvoiceDate').val().trim().length < 10) {
                    Toast('Please Enter Invoice Date Against Invoice:-' + $(ele).find('.InvoiceNo').val() + '', 'Message', 'error');
                    Vflag = 1;
                    return false;
                }
                if ($(ele).find('.InvoiceTerms').val() == "0") {
                    Toast('Please Enter Invoice Terms Against Invoice:-' + $(ele).find('.InvoiceNo').val() + '', 'Message', 'error');
                    Vflag = 1;
                    return false;
                }
                if ($(ele).find('.InvoiceCurrencyExchangeRate').val().trim().length <= 0) {
                    Toast('Please Enter Invoice Currency Exchange Rate Against Invoice:-' + $(ele).find('.InvoiceNo').val() + '', 'Message', 'error');
                    Vflag = 1;
                    return false;
                }
                if (HandleNullNumericValue($(ele).find('.InvoiceCurrencyExchangeRate').val()) <= 0) {
                    Toast('Please Enter Valid Currency Exchange Rate Against Invoice:-' + $(ele).find('.InvoiceNo').val() + '', 'Message', 'error');
                    Vflag = 1;
                    return false;
                }
                if ($(ele).find('.InvoiceValue').val().trim().length <= 0) {
                    Toast('Please Enter Invoice Value Against Invoice:-' + $(ele).find('.InvoiceNo').val() + '', 'Message', 'error');
                    Vflag = 1;
                    return false;
                }
                if (HandleNullNumericValue($(ele).find('.InvoiceValue').val()) <= 0) {
                    Toast('Please Enter Valid Invoice Value Rate Against Invoice:-' + $(ele).find('.InvoiceNo').val() + '', 'Message', 'error');
                    Vflag = 1;
                    return false;
                }

            }
        }
        else {
            if ($(ele).find('.InvoiceNo').val().trim().length <= 0) {
                Toast('Please Add Invoice Number Against Row Number:-' + (ind + 1) + '', 'Message', 'error');
                Vflag = 1;
                return false;
            }
            else {
                if ($(ele).find('.InvoiceDate').val().trim().length < 10) {
                    Toast('Please Enter Invoice Date Against Invoice:-' + $(ele).find('.InvoiceNo').val() + '', 'Message', 'error');
                    Vflag = 1;
                    return false;
                }
                if ($(ele).find('.InvoiceTerms').val() == "0") {
                    Toast('Please Enter Invoice Terms Against Invoice:-' + $(ele).find('.InvoiceNo').val() + '', 'Message', 'error');
                    Vflag = 1;
                    return false;
                }
                if ($(ele).find('.InvoiceCurrencyExchangeRate').val().trim().length <= 0) {
                    Toast('Please Enter Invoice Currency Exchange Rate Against Invoice:-' + $(ele).find('.InvoiceNo').val() + '', 'Message', 'error');
                    Vflag = 1;
                    return false;
                }
                if (HandleNullNumericValue($(ele).find('.InvoiceCurrencyExchangeRate').val()) <= 0) {
                    Toast('Please Enter Valid Currency Exchange Rate Against Invoice:-' + $(ele).find('.InvoiceNo').val() + '', 'Message', 'error');
                    Vflag = 1;
                    return false;
                }
                if ($(ele).find('.InvoiceValue').val().trim().length <= 0) {
                    Toast('Please Enter Invoice Value Against Invoice:-' + $(ele).find('.InvoiceNo').val() + '', 'Message', 'error');
                    Vflag = 1;
                    return false;
                }
                if (HandleNullNumericValue($(ele).find('.InvoiceValue').val()) <= 0) {
                    Toast('Please Enter Valid Invoice Value Rate Against Invoice:-' + $(ele).find('.InvoiceNo').val() + '', 'Message', 'error');
                    Vflag = 1;
                    return false;
                }
            }
        }
    });
    return Vflag;
}

//NEWRESETRESETINVOICE BUTTON CLICK EVENT
$('#NewResetInvoice').click(function () {
    ResetNewInvoice(true);
});

//FUNCTION FOR NEW RESET INVOICE
function ResetNewInvoice(flag) {

    const disabledInvoiceid = ['NewFreightPerInvoice', 'NewActualFreightInvoice', 'NewFreightExchangeRateInvoice', 'NewFreightINRInvoice', 'HiddenNewFreightCurrencyInvoice', 'NewFreightCurrencyInvoice', 'NewActualInsuranceInvoice', 'HiddenNewInsuranceCurrencyInvoice', 'NewInsuranceCurrencyInvoice', 'NewInsuranceExchangeRateInvoice', 'NewInsurancePerInvoice', 'NewInsuranceINRInvoice'];

    disabledInvoiceid.forEach((ele) => {
        $('#' + ele).attr('disabled', 'disabled');
    });

    const blankInvoiceId = ['NewRownNumInvoice', 'NewInvoiceNo', 'NewInvoiceDate', 'HiddenNewInvoiceCurrency', 'NewInvoiceCurrency', 'HiddenNewFreightCurrencyInvoice', 'NewFreightCurrencyInvoice', 'HiddenNewInsuranceCurrencyInvoice', 'NewInsuranceCurrencyInvoice', 'HiddenNewLoadingCurrencyInvoice', 'NewLoadingCurrencyInvoice', 'NewPONumber', 'NewPODate', 'NewContractNumber', 'NewContractDate', 'NewLCNumber', 'NewLCDate', 'NewAuthorizedEconomicOperatorCode', 'HiddenNewAuthorizedEconomicCountry', 'NewAuthorizedEconomicCountry', 'NewAuthorizedEconomicOperatorRole', 'HiddenHSSeller', 'HSSeller', 'HSSellerIECCode', 'NewSVBNo', 'NewSVBDate', 'HiddenNewSVBCustomHouse', 'NewSVBCustomHouse'];

    blankInvoiceId.forEach((ele) => {
        $('#' + ele).val('');
    });

    const zeroInvoiceId = ['NewInvoiceCurrencyExchangeRate', 'NewInvoiceValue', 'NewActualFreightInvoice', 'NewFreightExchangeRateInvoice', 'NewFreightINRInvoice', 'NewActualInsuranceInvoice', 'NewInsuranceExchangeRateInvoice', 'NewInsuranceINRInvoice', 'NewMiscChargesInvoice', 'NewMiscChargesINRInvoice', 'NewLoadingExchangeRateInvoice', 'NewLoadingINRInvoice', 'HSSLoadRate', 'HSSLoadAmount', 'NewSVBAssessableValue', 'NewSVBDuty'];

    zeroInvoiceId.forEach((ele) => {
        $('#' + ele).val('0.00');
    });

    $('#NewRelationInvoice').val('N');
    $('#NewNatureOfTransactionInvoice').val('S');
    $('#NewInvoiceTerms').val(0);
    $('#NewNetWeightMetricInvoice,#NewGrossWeightKgInvoice').val('0.000');
    $('#NewFreightPerInvoice,#NewInsurancePerInvoice,#NewLoadingPerInvoice').val('0.0000');

    $('#HighSeaSaleFlag').prop('checked', false);
    $('#HssDiv').addClass("d-none");
    $('#HSSellerAddress').html('');

    $('#NewSVBLoadCh').prop('checked', false);
    $('#SvbDiv').addClass('d-none');
    $('#NewSVBLoadType').val('A');
    $('#NewSVBAssLoadFinal,#NewSVBDutyLoadFinal').val('F');

    $('#NewSVBDuty').attr('disabled', true);

    $("#NewAddInvoice").removeClass('d-none');
    $("#NewUpdateInvoice").addClass('d-none');

    if (flag)
        $("#NewInvoiceNo").focus();
}


//#endregion

//#region /****************************ITEM DETAILS TAB ALL FUNCTION START****************************/

//NEWITEMMASTERTARIFF DROPDOWN CHANGE EVENT
$('#NewItemMasterTariff').change(function () {
    if ($('#NewItemMasterTariff').val() == 'Master')
        $('#NewItemName').attr('onkeypress', "AutoCompleteAjax('NewItemName', '/Master/_Layout/GetItemNameAutoComplete', 'HiddenNewItemName')");
    else {
        if ($('#NewItemName').hasClass('ui-autocomplete-input'))
            $('#NewItemName').autocomplete('destroy');
        $('#NewItemName').removeAttr('onkeypress').removeClass('ui-autocomplete-input');
    }
});

//NEWITEMNAME BLUR EVENT
$('#NewItemName').blur(function () {
    if ($('#NewItemMasterTariff').val() == 'Master') {
        if ($('#HiddenNewItemName').val() != '')
            GetItemDescriptionForImport('HiddenNewItemName', 'NewItemDescription', 'NewItemGenericDescription', 'NewItemEndUse', 'NewItemEndUseDesc', 'NewRITCCode', 'NewItemCTH', 'NewItemCTEH');
    }
});

//FUNCTION FOR GET ITEM DESCRIPTION FROM MASTER
function GetItemDescriptionForImport(ItemUid, ItemDesc, GenDesc, EndUsItm, EndUsDesc, RITC, CTH, CETH) {
    try {
        const dataString = {};
        dataString.ItemUid = $('#' + ItemUid).val();
        if (ItemUid.length > 0) {
            AjaxSubmissionAutocomplete(JSON.stringify(dataString), '/Master/_Layout/GetItemDescription', $('input[name=__RequestVerificationToken]').val()).done(function (result) {
                let obj = result;
                if (obj.status == true) {
                    if (obj.responsecode == '100') {
                        $('#' + ItemDesc).val(obj.data.Table[0].ItemDesc);
                        $('#' + GenDesc).val(obj.data.Table[0].ItemDesc);
                        $('#' + EndUsItm).val(obj.data.Table[0].EndUseOfItem);
                        $('#' + EndUsDesc).val(obj.data.Table[0].EndUseDesc);
                        $('#Hidden' + RITC).val(obj.data.Table[0].ritc_code);
                        $('#' + RITC).val(obj.data.Table[0].ritc_code);
                        $('#Hidden' + CTH).val(obj.data.Table[0].cth);
                        $('#' + CTH).val(obj.data.Table[0].cth);
                        $('#Hidden' + CETH).val(obj.data.Table[0].ceth);
                        $('#' + CETH).val(obj.data.Table[0].ceth);
                    }
                }
                else
                    window.location.href = '/ClientLogin/ClientLogin';
            }).fail(function (result) {
                console.log(result.Message);
            });
        }
    }
    catch (e) {
        console.log(e.message);
    }
}

//FUNCTION FOR GET END USE DESCRIPTION
function GetEndUseDescriptionForImport(EndUseCode, EndUseDesc) {
    try {
        const dataString = {};
        dataString.EndUseCode = $('#' + EndUseCode).val();
        if (EndUseCode.length > 0) {
            AjaxSubmissionAutocomplete(JSON.stringify(dataString), '/Master/_Layout/GetEndUseDescription', $('input[name=__RequestVerificationToken]').val()).done(function (result) {
                let obj = result;
                if (obj.status == true) {
                    if (obj.responsecode == '100') {
                        $('#' + EndUseDesc).val(obj.data.Table[0].EndUseDesc);
                    }
                }
                else
                    window.location.href = '/ClientLogin/ClientLogin';
            }).fail(function (result) {
                console.log(result.Message);
            });
        }
    }
    catch (e) {
        console.log(e.message);
    }
}


let hidItemMenu = '';
//NEWITEMMANUFACTURERPRODUCERGROWERNAME ON INPUT EVENT
$('#NewItemManufacturerProducerGrowerName').on('input', function () {
    $('#HiddenNewItemManufacturerProducerGrowerName').val('');
    hidItemMenu = '';
});

//NEWITEMMANUFACTURERPRODUCERGROWERNAME ON BLUR EVENT
$('#NewItemManufacturerProducerGrowerName').blur(function () {

    if (hidItemMenu != $('#HiddenNewItemManufacturerProducerGrowerName').val().trim()) {
        $('#NewItemManufacturerProducerGrowerAddress').html('');
        if ($('#HiddenNewItemManufacturerProducerGrowerName').val().trim().length > 0) {
            hidItemMenu = $('#HiddenNewItemManufacturerProducerGrowerName').val().trim();
            FillManufacturerBranchAddress();
        }

            
    }
    else if ($('#HiddenNewItemManufacturerProducerGrowerName').val() == '')
        $('#NewItemManufacturerProducerGrowerAddress').html('');
    
});

//FUNCTION FOR FILL MANUFACTURER BRANCH ADDRESS
function FillManufacturerBranchAddress() {
    try {
        const dataString = {};
        let LId = parseInt($("#HiddenNewItemManufacturerProducerGrowerName").val().trim());
        dataString.LedgerId = LId;
        AjaxSubmission(JSON.stringify(dataString), '/Master/_Layout/GetLedgerAddressWithBranch', $('input[name=__RequestVerificationToken]').val()).done(function (result) {
            let obj = result;
            if (obj.status == true) {
                if (obj.responsecode == '100')
                    BindDropdownNew(obj.data.Table, 'NewItemManufacturerProducerGrowerAddress', 'BranchUid', 'BranchAddress', '--Select--');
                else
                    BindDropdownNew(null, 'NewItemManufacturerProducerGrowerAddress', 'BranchUid', 'BranchAddress', '--Select--');

            } else
                window.location.href = '/ClientLogin/ClientLogin';
        }).fail(function (result) {
            console.log(result.Message);
        });
    }
    catch (e) {
        console.log(e.message);
    }
}

//NEWITEMMANUFACTURERPRODUCERGROWERADDRESS CHANGE EVENT
$('#NewItemManufacturerProducerGrowerAddress').change(function () {
    try {
        const dataString = {};
        let BranchUid = parseInt($("#NewItemManufacturerProducerGrowerAddress").val().trim());
        dataString.BranchUid = BranchUid;
        dataString.LedgerUid = $('#HiddenNewItemManufacturerProducerGrowerName').val();
        AjaxSubmission(JSON.stringify(dataString), '/Master/_Layout/GetLedgerFullBranchDetails', $('input[name=__RequestVerificationToken]').val()).done(function (result) {
            let obj = result;
            if (obj.status == true) {
                if (obj.responsecode == '100') {
                    $('#NewItemManufacturerProducerGrowerAddress1').val(obj.data.Table[0].Address1);
                    $('#NewItemManufacturerProducerGrowerAddress2').val(obj.data.Table[0].Address2);
                    $('#NewItemManufacturerProducerGrowerCity').val(obj.data.Table[0].BranchCity);
                    $('#NewItemManufacturerProducerGrowerPin').val(obj.data.Table[0].BranchPincode);
                    $('#HiddenNewItemManufacturerCountry').val(obj.data.Table[0].Country);
                    $('#NewItemManufacturerCountryName').val(obj.data.Table[0].CountryName);
                }
                else {
                    $('#NewItemManufacturerProducerGrowerAddress1,#NewItemManufacturerProducerGrowerAddress2,#NewItemManufacturerProducerGrowerCity').val('');
                    $('#NewItemManufacturerProducerGrowerPin,#HiddenNewItemManufacturerCountry,#NewItemManufacturerCountryName').val('');
                }


            } else
                window.location.href = '/ClientLogin/ClientLogin';
        }).fail(function (result) {
            console.log(result.Message);
        });
    }
    catch (e) {
        console.log(e.message);
    }
});

//FUNCTION FOR ACTIVE ITEM MAIN TAB
function ActiveItemMainTab() {

    $("#ItemMainDetails-tab").addClass('active');
    $("#ItemMainDetails").addClass('active show');

    $('#ItemDutyDetails,#ItemManufacturerDetails,#ItemOtherDetails').removeClass('active show');

    $('#ItemDutyDetails-tab,#ItemManufacturerDetails-tab,#ItemOtherDetails-tab').removeClass('active');

}

//FUNCTION FOR ACTIVE ITEM DUTY TAB
function ActiveItemDutyTab() {

    $('#ItemDutyDetails-tab').addClass('active');
    $('#ItemDutyDetails').addClass('active show');

    $('#ItemMainDetails,#ItemManufacturerDetails,#ItemOtherDetails').removeClass('active show');

    $('#ItemMainDetails-tab,#ItemManufacturerDetails-tab,#ItemOtherDetails-tab').removeClass('active');

}

//FUNCTION FOR ACTIVE ITEM OTHER TAB
function ActiveItemOtherTab() {

    $('#ItemOtherDetails-tab').addClass('active');
    $('#ItemOtherDetails').addClass('active show');

    $('#ItemMainDetails,#ItemDutyDetails,#ItemManufacturerDetails').removeClass('active show');

    $('#ItemMainDetails-tab,#ItemDutyDetails-tab,#ItemManufacturerDetails-tab').removeClass('active');

}

//NEWITEMINVOICENO DROPDOWN CHANGE EVENT
$('#NewItemInvoiceNo').change(function () {
    let InvText = '';
    if ($('#NewItemInvoiceNo').val() == "0") {
        $('#InvDe').text('');
    }
    else {
        $("#TblInvoiceDetails tbody tr").each(function (ind, ele) {
            if ($('#NewItemInvoiceNo option:selected').text() == $(this).find('.InvoiceNo').val().trim()) {
                InvText += 'Invoice: ' + '<span >' + $(this).find('.InvoiceNo').val() + '</span>';
                InvText += '  | InvoiceDate: ' + '<span >' + $(this).find('.InvoiceDate').val() + '</span>';
                InvText += '  | Currency: ' + '<span >' + $(this).find('.InvoiceCurrency').val() + '</span>';
                InvText += '  | Exchange Rate: ' + '<span >' + $(this).find('.InvoiceCurrencyExchangeRate').val() + '</span>';
                InvText += '  | Net Weight: ' + '<span >' + $(this).find('.NetWeightMetric').val() + ' MT</span>';
                InvText += '  | Gross Weight: ' + '<span >' + $(this).find('.GrossWeightKg').val() + ' KG</span>';
                InvText += '  | Invoice Value: ' + '<span >' + $(this).find('.InvoiceValue').val() + '</span>';
                InvText += '  | Freight: ' + '<span>' + $(this).find('.FreightINR').val() + '</span>';
                InvText += '  | Insurance: ' + '<span>' + $(this).find('.InsuranceINR').val() + '</span>';
                $('#InvDe').html(InvText);

                $('#InvDe').find('span').css('color', 'red');
                DutyCalculation();
            }
        });
    }
});

//FUNCTION FOR FILL CURRENT ITEM DETAILS
function FillCurrentItemDetails() {
    let ItemDeText = '';
    if ($('#NewItemName').val().trim().length > 0) {
        ItemDeText += 'Item Name: ' + '<span>' + $('#NewItemName').val().trim() + '</span>';
        ItemDeText += '  | Amount: ' + '<span > ' + $('#NewItemAmount').val().trim() + '</span > ';
        ItemDeText += '  | Quantity: ' + '<span>' + $('#NewItemQuantity').val().trim() + '</span>';
        ItemDeText += '  | Unit Price: ' + '<span>' + $('#NewItemUnitPrice').val().trim() + '</span>';
        ItemDeText += '  | Unit : ' + '<span>' + $('#NewUnitQuantityCode').val().trim() + '</span>';
        ItemDeText += '  | CIF Value: ' + '<span>' + $('#NewItemCIFValue').val().trim() + '</span>';
    }
    $('.ItemDe').html(ItemDeText);
    $('.ItemDe').find('span').css('color', 'red');

}

//NEWADDITEM BUTTON CLICK EVENT
$('#NewAddItem').click(function () {
    if ($('#NewItemInvoiceNo').val() == null) {
        Toast('Please Add Invoice Details.', 'Message', 'error');
        ActiveInvoiceDetailsTab();
        $('#NewInvoiceNo').focus();
        return;
    }
    else if ($('#NewItemInvoiceNo').val() == '0') {
        Toast('Please Select Invoice Number', 'Message', 'error');
        ActiveItemMainTab();
        $('#NewItemInvoiceNo').focus();
        return;
    }
    else if ($('#NewItemName').val().trim().length <= 0) {
        Toast('Please Add Item.', 'Message', 'error');
        ActiveItemMainTab();
        $('#NewItemName').focus();
        return;
    }
    else if ($('#NewItemDescription').val().trim().length <= 0) {
        Toast('Please Add Item Descriptions.', 'Message', 'error');
        ActiveItemMainTab();
        $('#NewItemDescription').focus();
        return;
    }
    else if ($('#NewItemEndUse').val().trim().length <= 0) {
        Toast('Please Add End Use.', 'Message', 'error');
        ActiveItemMainTab();
        $('#NewItemEndUse').focus();
        return;
    }
    else if ($('#NewItemEndUseDesc').val().trim().length <= 0) {
        Toast('Please Add End Use Descriptions.', 'Message', 'error');
        ActiveItemMainTab();
        $('#NewItemEndUseDesc').focus();
        return;
    }
    else if ($('#NewItemBrandName').val().trim().length <= 0) {
        Toast('Please Add Item Brand', 'Message', 'error');
        ActiveItemOtherTab();
        $('#NewItemBrandName').focus();
        return;
    }
    else if ($('#NewItemModel').val().trim().length <= 0) {
        Toast('Please Add Item Model.', 'Message', 'error');
        ActiveItemOtherTab();
        $('#NewItemModel').focus();
        return;
    }
    else if ($('#NewItemAmount').val().trim() <= 0) {
        Toast('Please Enter Item Amount.', 'Message', 'error');
        ActiveItemMainTab();
        $('#NewItemAmount').focus();
        return;
    }
    else if ($('#NewItemQuantity').val().trim() <= 0) {
        Toast('Please Add Item Quantity.', 'Message', 'error');
        ActiveItemMainTab();
        $('#NewItemQuantity').focus();
        return;
    }
    else if ($('#NewUnitQuantityCode').val().trim().length <= 0) {
        Toast('Please Add Item Unit.', 'Message', 'error');
        ActiveItemMainTab();
        $('#NewUnitQuantityCode').focus();
        return;
    }
    else if ($('#NewItemMode').val() == '0' || $('#NewItemMode').val() == null || $('#NewItemMode').val() == undefined || $('#NewItemMode').val() == '') {
        Toast('Please Add Item Mode.', 'Message', 'error');
        ActiveItemDutyTab();
        $('#NewItemMode').focus();
        return;
    }
    else if ($('#NewItemCategorySchemeCode').val() == '0' || $('#NewItemCategorySchemeCode').val() == null || $('#NewItemCategorySchemeCode').val() == undefined || $('#NewItemCategorySchemeCode').val() == '') {
        Toast('Please Add Scheme.', 'Message', 'error');
        ActiveItemDutyTab();
        $('#NewItemCategorySchemeCode').focus();
        return;
    }
    else if ($('#NewRITCCode').val().trim().length <= 0) {
        Toast('Please Add Item RITC Code.', 'Message', 'error');
        ActiveItemDutyTab();
        $('#NewRITCCode').focus();
        return;
    }
    else if ($('#NewItemCTH').val().trim().length <= 0) {
        Toast('Please Add Item CTH Code.', 'Message', 'error');
        ActiveItemDutyTab();
        $('#NewItemCTH').focus();
        return;
    }
    else if ($('#NewItemCTEH').val().trim().length <= 0) {
        Toast('Please Add Item CTEH Code', 'Message', 'error');
        ActiveItemDutyTab();
        $('#NewItemCTEH').focus();
        return;
    }
    else if ($('#NewSQCUnitCode').val().trim().length == 0) {
        Toast('Please Add Item CTEH Code', 'Message', 'error');
        ActiveItemDutyTab();
        $('#NewSQCUnitCode').focus();
        return;
    }
    else
        NewAddItemRow();
});

//FUNCTION FOR NEW ADD ITEM
function NewAddItemRow() {
    DutyCalculation();
    let flag = 0;
    let TblLen = $("#TblItemDetails tbody tr").length;
    let tbody = $("#TblItemDetails").find("tbody");
    let FirstTr = $(tbody).find("tr:first");
    let Itemt = '';

    if (TblLen == 1 && $('#TblItemDetails tbody tr').find('.TblItemName').val().trim().length == 0) {
        Itemt = FirstTr;
        AddItemData();
    }
    else {
        Itemt = $(FirstTr).clone();
        AddItemData();
        $("#TblItemDetails").append(Itemt);
    }
    GenerateSerialNumberTable('TblItemDetails', 'rn');
    ResetNewItem(true);
    NewGenerateItemNameList();
    Toast('Item Add Successfully.', 'Message', 'success');
    CalcAssCifDuty();

    function AddItemData() {

        //MAIN DETAILS

        Itemt.find('.TblItemInvoiceNo').val($('#NewItemInvoiceNo').val());
        Itemt.find('.TblReImport').val($('#NewReImport').val());
        Itemt.find('.HiddenTblItemName').val($('#HiddenNewItemName').val());
        Itemt.find('.TblItemName').val($('#NewItemName').val());
        Itemt.find('.TblItemDescription').val($('#NewItemDescription').val());
        Itemt.find('.TblItemGenericDescription').val($('#NewItemGenericDescription').val());
        Itemt.find('.HiddenTblItemEndUse').val($('#HiddenNewItemEndUse').val());
        Itemt.find('.TblItemEndUse').val($('#NewItemEndUse').val());
        Itemt.find('.TblItemEndUseDesc').val($('#NewItemEndUseDesc').val());
        Itemt.find('.HiddenTblItemCountryOrigin').val($('#HiddenNewItemCountryOrigin').val());
        Itemt.find('.TblItemCountryOrigin').val($('#NewItemCountryOrigin').val());
        Itemt.find('.TblItemAmount').val($('#NewItemAmount').val());
        Itemt.find('.TblItemQuantity').val($('#NewItemQuantity').val());
        Itemt.find('.TblItemUnitPrice').val($('#NewItemUnitPrice').val());
        Itemt.find('.HiddenTblUnitQuantityCode').val($('#HiddenNewUnitQuantityCode').val());
        Itemt.find('.TblUnitQuantityCode').val($('#NewUnitQuantityCode').val());
        Itemt.find('.TblItemFreight').val($('#NewItemFreight').val());
        Itemt.find('.TblItemInsurance').val($('#NewItemInsurance').val());
        Itemt.find('.TblItemMiscCharge').val($('#NewItemMiscCharge').val());
        Itemt.find('.TblItemLoading').val($('#NewItemLoading').val());
        Itemt.find('.TblHSSLoadAmount').val($('#NewHSSLoadAmount').val());
        Itemt.find('.TblItemCIFValue').val($('#NewItemCIFValue').val());
        Itemt.find('.TblItemDutyAmount').val($('#NewItemDutyAmount').val());
        Itemt.find('.TblItemDutyGone').val($('#NewItemDutyGone').val());

        //DUTY DETAILS

        Itemt.find('.HiddenTblLicCheck').val($('#HiddenLicCheck').val());
        Itemt.find('.TblItemMode').val($('#NewItemMode').val());
        Itemt.find('.TblItemCategorySchemeCode').val($('#NewItemCategorySchemeCode').val());
        Itemt.find('.TblRITCCode').val($('#NewRITCCode').val());
        Itemt.find('.TblItemCTH').val($('#NewItemCTH').val());
        Itemt.find('.TblItemCTEH').val($('#NewItemCTEH').val());
        Itemt.find('.TblDEPBNotification').val($('#NewDEPBNotification').val());
        Itemt.find('.TblDEPBNotificationSrNo').val($('#NewDEPBNotificationSrNo').val());
        Itemt.find('.TblExempted').val($('#NewExempted').val());
        Itemt.find('.TblSQCQuantity').val($('#NewSQCQuantity').val());
        Itemt.find('.HiddenTblSQCQuantityCode').val($('#HiddenNewSQCUnitCode').val());
        Itemt.find('.TblSQCQuantityCode').val($('#NewSQCUnitCode').val());

        Itemt.find('.TblItemBCDNotification').val($('#NewItemBCDNotification').val());
        Itemt.find('.TblItemBCDNotificationSrNo').val($('#NewItemBCDNotificationSrNo').val());
        Itemt.find('.TblItemBCDRate').val($('#NewItemBCDRate').val());
        Itemt.find('.TblItemBCDAmount').val($('#NewItemBCDAmount').val());

        Itemt.find('.TblItemCVDNotification').val($('#NewItemCVDNotification').val());
        Itemt.find('.TblItemCVDNotificationSrNo').val($('#NewItemCVDNotificationSrNo').val());
        Itemt.find('.TblItemCVDRate').val($('#NewItemCVDRate').val());
        Itemt.find('.TblItemCVDAmount').val($('#NewItemCVDAmount').val());

        Itemt.find('.TblAdditionalNotification1').val($('#NewAdditionalNotification1').val());
        Itemt.find('.TblAdditionalNotification1SrNo').val($('#NewAdditionalNotification1SrNo').val());
        Itemt.find('.TblAdditionalNotification1Rate').val($('#NewAdditionalNotification1Rate').val());
        Itemt.find('.TblAdditionalNotification1Amount').val($('#NewAdditionalNotification1Amount').val());

        Itemt.find('.TblAdditionalNotification2').val($('#NewAdditionalNotification2').val());
        Itemt.find('.TblAdditionalNotification2SrNo').val($('#NewAdditionalNotification2SrNo').val());
        Itemt.find('.TblAdditionalNotification2Rate').val($('#NewAdditionalNotification2Rate').val());
        Itemt.find('.TblAdditionalNotification2Amount').val($('#NewAdditionalNotification2Amount').val());

        Itemt.find('.TblOtherNotification').val($('#NewOtherNotification').val());
        Itemt.find('.TblOtherNotificationSrNo').val($('#NewOtherNotificationSrNo').val());
        Itemt.find('.TblOtherNotificationRate').val($('#NewOtherNotificationRate').val());
        Itemt.find('.TblOtherNotificationAmount').val($('#NewOtherNotificationAmount').val());

        Itemt.find('.TblSocialWelfareNotification').val($('#NewSocialWelfareNotification').val());
        Itemt.find('.TblSocialWelfareNotificationSrNo').val($('#NewSocialWelfareNotificationSrNo').val());
        Itemt.find('.TblSocialWelfareRate').val($('#NewSocialWelfareRate').val());
        Itemt.find('.TblSocialWelfareAmount').val($('#NewSocialWelfareAmount').val());

        Itemt.find('.TblNCDNotification').val($('#NewNCDNotification').val());
        Itemt.find('.TblNCDNotificationSrNo').val($('#NewNCDNotificationSrNo').val());
        Itemt.find('.TblNCDNotificationRate').val($('#NewNCDNotificationRate').val());
        Itemt.find('.TblNCDNotificationAmount').val($('#NewNCDNotificationAmount').val());

        Itemt.find('.TblAntiDumpingDutyNotification').val($('#NewAntiDumpingDutyNotification').val());
        Itemt.find('.TblAntiDumpingDutyNotificationSrNo').val($('#NewAntiDumpingDutyNotificationSrNo').val());
        Itemt.find('.TblAntiDumpingDutyNotificationRate').val($('#NewAntiDumpingDutyNotificationRate').val());
        Itemt.find('.TblAntiDumpingDutyNotificationAmount').val($('#NewAntiDumpingDutyNotificationAmount').val());

        Itemt.find('.TblHealthNotification').val($('#NewHealthNotification').val());
        Itemt.find('.TblHealthNotificationSrNo').val($('#NewHealthNotificationSrNo').val());
        Itemt.find('.TblHealthNotificationRate').val($('#NewHealthNotificationRate').val());
        Itemt.find('.TblHealthNotificationAmount').val($('#NewHealthNotificationAmount').val());

        Itemt.find('.TblAdditionalCVDNotification').val($('#NewAdditionalCVDNotification').val());
        Itemt.find('.TblAdditionalCVDNotificationSrNo').val($('#NewAdditionalCVDNotificationSrNo').val());
        Itemt.find('.TblAdditionalCVDNotificationRate').val($('#NewAdditionalCVDNotificationRate').val());
        Itemt.find('.TblAdditionalCVDNotificationAmount').val($('#NewAdditionalCVDNotificationAmount').val());

        Itemt.find('.TblAggregateDutyNotification').val($('#NewAggregateDutyNotification').val());
        Itemt.find('.TblAggregateDutyNotificationSrNo').val($('#HiddenNewAggregateDutyNotificationSrNo').val());
        Itemt.find('.TblAggregateDutyNotificationRate').val($('#NewAggregateDutyNotificationRate').val());
        Itemt.find('.TblAggregateDutyNotificationAmount').val($('#NewAggregateDutyNotificationAmount').val());

        Itemt.find('.TblSafeguardDutyNotification').val($('#NewSafeguardDutyNotification').val());
        Itemt.find('.TblSafeguardDutyNotificationSrNo').val($('#NewSafeguardDutyNotificationSrNo').val());
        Itemt.find('.TblSafeguardDutyNotificationRate').val($('#NewSafeguardDutyNotificationRate').val());
        Itemt.find('.TblSafeguardDutyNotificationAmount').val($('#NewSafeguardDutyNotificationAmount').val());

        Itemt.find('.TblIGSTNotification').val($('#NewIGSTNotification').val());
        Itemt.find('.TblIGSTNotificationSrNo').val($('#NewIGSTNotificationSrNo').val());
        Itemt.find('.TblIGSTNotificationRate').val($('#NewIGSTNotificationRate').val());
        Itemt.find('.TblIGSTNotificationAmount').val($('#NewIGSTNotificationAmount').val());

        Itemt.find('.TblIGSTExemNotification').val($('#NewIGSTExemNotification').val());
        Itemt.find('.TblIGSTExemNotificationSrNo').val($('#NewIGSTExemNotificationSrNo').val());
        Itemt.find('.TblIGSTExemNotificationRate').val($('#NewIGSTExemNotificationRate').val());
        Itemt.find('.TblIGSTExemNotificationAmount').val($('#NewIGSTExemNotificationAmount').val());

        Itemt.find('.TblIGSTComCessNotification').val($('#NewIGSTComCessNotification').val());
        Itemt.find('.TblIGSTComCessNotificationSrNo').val($('#NewIGSTComCessNotificationSrNo').val());
        Itemt.find('.TblIGSTComCessNotificationRate').val($('#NewIGSTComCessNotificationRate').val());
        Itemt.find('.TblIGSTComCessNotificationAmount').val($('#NewIGSTComCessNotificationAmount').val());

        Itemt.find('.TblIGSTComCessExemNotification').val($('#NewIGSTComCessExemNotification').val());
        Itemt.find('.TblIGSTComCessExemNotificationSrNo').val($('#NewIGSTComCessExemNotificationSrNo').val());
        Itemt.find('.TblIGSTComCessExemNotificationRate').val($('#NewIGSTComCessExemNotificationRate').val());
        Itemt.find('.TblIGSTComCessExemNotificationAmount').val($('#NewIGSTComCessExemNotificationAmount').val());

        //MANUFACTURER/PRODUCER DETAILS

        Itemt.find('.HiddenTblItemManufacturerProducerGrowerName').val($('#HiddenNewItemManufacturerProducerGrowerName').val());
        Itemt.find('.TblItemManufacturerProducerGrowerName').val($('#NewItemManufacturerProducerGrowerName').val());
        Itemt.find('.TblItemManufacturerProducerCodeType').val($('#NewItemManufacturerProducerCodeType').val());
        Itemt.find('.TblItemManufacturerProducerGrowerCode').val($('#NewItemManufacturerProducerGrowerCode').val());
        Itemt.find('.TblItemManufacturerProducerGrowerAddress1').val($('#NewItemManufacturerProducerGrowerAddress1').val());
        Itemt.find('.TblItemManufacturerProducerGrowerAddress2').val($('#NewItemManufacturerProducerGrowerAddress2').val());
        Itemt.find('.TblItemManufacturerProducerGrowerCity').val($('#NewItemManufacturerProducerGrowerCity').val());
        Itemt.find('.TblItemManufacturerProducerGrowerCountrySubDivision').val($('#NewItemManufacturerProducerGrowerCountrySubDivision').val());
        Itemt.find('.TblItemManufacturerProducerGrowerPin').val($('#NewItemManufacturerProducerGrowerPin').val());
        Itemt.find('.HiddenTblItemManufacturerCountry').val($('#HiddenNewItemManufacturerCountry').val());
        Itemt.find('.TblItemManufacturerCountryName').val($('#NewItemManufacturerCountryName').val());
        Itemt.find('.HiddenTblSourceCountryName').val($('#HiddenNewSourceCountry').val());
        Itemt.find('.TblSourceCountryName').val($('#NewSourceCountryName').val());
        Itemt.find('.HiddenTblTransitCountry').val($('#HiddenNewTransitCountry').val());
        Itemt.find('.TblTransitCountryName').val($('#NewTransitCountryName').val());

        //OTHER DETAILS

        Itemt.find('.TblItemBrandName').val($('#NewItemBrandName').val());
        Itemt.find('.TblItemModel').val($('#NewItemModel').val());
        Itemt.find('.TblPreferentialStandard').val($('#NewPreferentialStandard').val());
        Itemt.find('.TblRSPApplicability').val($('#NewRSPApplicability').val());
        Itemt.find('.TblCTHSerialNumber').val($('#NewCTHSerialNumber').val());
        Itemt.find('.TblSupplierSerialNumber').val($('#NewSupplierSerialNumber').val());
        Itemt.find('.TblQuantityAsPerAntiDumpingNotification').val($('#NewQuantityAsPerAntiDumpingNotification').val());
        Itemt.find('.TblTarrifValueNotification').val($('#NewTarrifValueNotification').val());
        Itemt.find('.TblTarrifValueItemSrNo').val($('#NewTarrifValueItemSrNo').val());
        Itemt.find('.TblQuantityAsPerTarrifValueNotification').val($('#NewQuantityAsPerTarrifValueNotification').val());
        Itemt.find('.TblSAPTANotification').val($('#NewSAPTANotification').val());
        Itemt.find('.TblSAPTANotificationSrNo').val($('#NewSAPTANotificationSrNo').val());
        Itemt.find('.TblQtyAsPerCTH').val($('#NewQtyAsPerCTH').val());
        Itemt.find('.TblQuantityAsPerCTH').val($('#NewQuantityAsPerCTH').val());
        Itemt.find('.TblPolicyParaNo').val($('#NewPolicyParaNo').val());
        Itemt.find('.TblPolicyYear').val($('#NewPolicyYear').val());
        Itemt.find('.TblPreviousBENo').val($('#NewPreviousBENo').val());
        Itemt.find('.TblPreviousBEDate').val($('#NewPreviousBEDate').val());
        Itemt.find('.TblPreviousUnitPrice').val($('#NewPreviousUnitPrice').val());
        Itemt.find('.HiddenTblPreviousCurrencyCode').val($('#HiddenNewPreviousCurrencyCode').val());
        Itemt.find('.TblPreviousCurrency').val($('#NewPreviousCurrency').val());
        Itemt.find('.HiddenTblPreviousCustomSite').val($('#HiddenNewPreviousCustomSite').val());
        Itemt.find('.TblPreviousCustomSiteName').val($('#NewPreviousCustomSiteName').val());
        Itemt.find('.TblCustomNotnExemptingCentralExciseFlag').val($('#NewCustomNotnExemptingCentralExciseFlag').val());
        Itemt.find('.TblAccessoryStatus').val($('#NewAccessoryStatus').val());
        Itemt.find('.TblItemAccessoriesOfItem').val($('#NewItemAccessoriesOfItem').val());


    }

}

//FUNCTION FOR EDIT ITEM ROW ENTRY
function EditItemRowEntry(e) {
    let Rn = $(e).parent().parent().find('.rn').text().trim();
    let InvNo = $(e).parent().parent().find('.TblItemInvoiceNo').val();

    if (InvNo == null || InvNo == undefined || InvNo == '0' || InvNo.length == 0)
        Toast('Invalid Invoice Number.', 'Message', 'error');
    else {
        ResetNewItem();

        $('#NewAddItem').addClass('d-none');
        $('#NewUpdateItem').removeClass('d-none');


        //MAIN DETAILS

        $('#NewRowNumItem').val(Rn);
        $('#NewItemInvoiceNo').val($(e).parent().parent().find('.TblItemInvoiceNo').val());
        $('#NewReImport').val($(e).parent().parent().find('.TblReImport').val());
        $('#HiddenNewItemName').val($(e).parent().parent().find('.HiddenTblItemName').val());
        $('#NewItemName').val($(e).parent().parent().find('.TblItemName').val());
        $('#NewItemDescription').val($(e).parent().parent().find('.TblItemDescription').val());
        $('#NewItemGenericDescription').val($(e).parent().parent().find('.TblItemGenericDescription').val());
        $('#HiddenNewItemEndUse').val($(e).parent().parent().find('.HiddenTblItemEndUse').val());
        $('#NewItemEndUse').val($(e).parent().parent().find('.TblItemEndUse').val());
        $('#NewItemEndUseDesc').val($(e).parent().parent().find('.TblItemEndUseDesc').val());
        $('#HiddenNewItemCountryOrigin').val($(e).parent().parent().find('.HiddenTblItemCountryOrigin').val());

        $('#NewItemCountryOrigin').val($(e).parent().parent().find('.TblItemCountryOrigin').val());
        $('#NewItemAmount').val($(e).parent().parent().find('.TblItemAmount').val());
        $('#NewItemQuantity').val($(e).parent().parent().find('.TblItemQuantity').val());
        $('#NewItemUnitPrice').val($(e).parent().parent().find('.TblItemUnitPrice').val());
        $('#HiddenNewUnitQuantityCode').val($(e).parent().parent().find('.HiddenTblUnitQuantityCode').val());
        $('#NewUnitQuantityCode').val($(e).parent().parent().find('.TblUnitQuantityCode').val());
        $('#NewItemFreight').val($(e).parent().parent().find('.TblItemFreight').val());
        $('#NewItemInsurance').val($(e).parent().parent().find('.TblItemInsurance').val());
        $('#NewItemMiscCharge').val($(e).parent().parent().find('.TblItemMiscCharge').val());
        $('#NewItemLoading').val($(e).parent().parent().find('.TblItemLoading').val());

        $('#NewHSSLoadAmount').val($(e).parent().parent().find('.TblHSSLoadAmount').val());
        $('#NewItemCIFValue').val($(e).parent().parent().find('.TblItemCIFValue').val());
        $('#NewItemDutyAmount').val($(e).parent().parent().find('.TblItemDutyAmount').val());
        $('#NewItemDutyGone').val($(e).parent().parent().find('.TblItemDutyGone').val());

        //DUTY DETAILS

        $('#HiddenLicCheck').val($(e).parent().parent().find('.HiddenTblLicCheck').val());
        $('#NewItemMode').val($(e).parent().parent().find('.TblItemMode').val());
        $('#NewItemCategorySchemeCode').val($(e).parent().parent().find('.TblItemCategorySchemeCode').val());
        $('#HiddenNewRITCCode').val($(e).parent().parent().find('.TblRITCCode').val());
        $('#NewRITCCode').val($(e).parent().parent().find('.TblRITCCode').val());
        $('#HiddenNewItemCTH').val($(e).parent().parent().find('.TblItemCTH').val());
        $('#NewItemCTH').val($(e).parent().parent().find('.TblItemCTH').val());
        $('#HiddenNewItemCTEH').val($(e).parent().parent().find('.TblItemCTEH').val());
        $('#NewItemCTEH').val($(e).parent().parent().find('.TblItemCTEH').val());
        $('#NewDEPBNotification').val($(e).parent().parent().find('.TblDEPBNotification').val());
        $('#NewDEPBNotificationSrNo').val($(e).parent().parent().find('.TblDEPBNotificationSrNo').val());
        $('#NewExempted').val($(e).parent().parent().find('.TblExempted').val());
        $('#NewSQCQuantity').val($(e).parent().parent().find('.TblSQCQuantity').val());
        $('#HiddenNewSQCUnitCode').val($(e).parent().parent().find('.HiddenTblSQCQuantityCode').val());
        $('#NewSQCUnitCode').val($(e).parent().parent().find('.TblSQCQuantityCode').val());

        $('#HiddenNewItemBCDNotification').val($(e).parent().parent().find('.TblItemBCDNotification').val());
        $('#NewItemBCDNotification').val($(e).parent().parent().find('.TblItemBCDNotification').val());
        $('#NewItemBCDNotificationSrNo').val($(e).parent().parent().find('.TblItemBCDNotificationSrNo').val());
        $('#NewItemBCDRate').val($(e).parent().parent().find('.TblItemBCDRate').val());
        $('#NewItemBCDAmount').val($(e).parent().parent().find('.TblItemBCDAmount').val());

        $('#HiddenNewItemCVDNotification').val($(e).parent().parent().find('.TblItemCVDNotification').val());
        $('#NewItemCVDNotification').val($(e).parent().parent().find('.TblItemCVDNotification').val());
        $('#NewItemCVDNotificationSrNo').val($(e).parent().parent().find('.TblItemCVDNotificationSrNo').val());
        $('#NewItemCVDRate').val($(e).parent().parent().find('.TblItemCVDRate').val());
        $('#NewItemCVDAmount').val($(e).parent().parent().find('.TblItemCVDAmount').val());

        $('#HiddenNewAdditionalNotification1').val($(e).parent().parent().find('.TblAdditionalNotification1').val());
        $('#NewAdditionalNotification1').val($(e).parent().parent().find('.TblAdditionalNotification1').val());
        $('#NewAdditionalNotification1SrNo').val($(e).parent().parent().find('.TblAdditionalNotification1SrNo').val());
        $('#NewAdditionalNotification1Rate').val($(e).parent().parent().find('.TblAdditionalNotification1Rate').val());
        $('#NewAdditionalNotification1Amount').val($(e).parent().parent().find('.TblAdditionalNotification1Amount').val());

        $('#HiddenNewAdditionalNotification2').val($(e).parent().parent().find('.TblAdditionalNotification2').val());
        $('#NewAdditionalNotification2').val($(e).parent().parent().find('.TblAdditionalNotification2').val());
        $('#NewAdditionalNotification2SrNo').val($(e).parent().parent().find('.TblAdditionalNotification2SrNo').val());
        $('#NewAdditionalNotification2Rate').val($(e).parent().parent().find('.TblAdditionalNotification2Rate').val());
        $('#NewAdditionalNotification2Amount').val($(e).parent().parent().find('.TblAdditionalNotification2Amount').val());

        $('#HiddenNewOtherNotification').val($(e).parent().parent().find('.TblOtherNotification').val());
        $('#NewOtherNotification').val($(e).parent().parent().find('.TblOtherNotification').val());
        $('#NewOtherNotificationSrNo').val($(e).parent().parent().find('.TblOtherNotificationSrNo').val());
        $('#NewOtherNotificationRate').val($(e).parent().parent().find('.TblOtherNotificationRate').val());
        $('#NewOtherNotificationAmount').val($(e).parent().parent().find('.TblOtherNotificationAmount').val());

        $('#NewSocialWelfareNotification').val($(e).parent().parent().find('.TblSocialWelfareNotification').val());
        $('#NewSocialWelfareNotificationSrNo').val($(e).parent().parent().find('.TblSocialWelfareNotificationSrNo').val());
        $('#NewSocialWelfareRate').val($(e).parent().parent().find('.TblSocialWelfareRate').val());
        $('#NewSocialWelfareAmount').val($(e).parent().parent().find('.TblSocialWelfareAmount').val());

        $('#NewNCDNotification').val($(e).parent().parent().find('.TblNCDNotification').val());
        $('#NewNCDNotificationSrNo').val($(e).parent().parent().find('.TblNCDNotificationSrNo').val());
        $('#NewNCDNotificationRate').val($(e).parent().parent().find('.TblNCDNotificationRate').val());
        $('#NewNCDNotificationAmount').val($(e).parent().parent().find('.TblNCDNotificationAmount').val());

        $('#NewAntiDumpingDutyNotification').val($(e).parent().parent().find('.TblAntiDumpingDutyNotification').val());
        $('#NewAntiDumpingDutyNotificationSrNo').val($(e).parent().parent().find('.TblAntiDumpingDutyNotificationSrNo').val());
        $('#NewAntiDumpingDutyNotificationRate').val($(e).parent().parent().find('.TblAntiDumpingDutyNotificationRate').val());
        $('#NewAntiDumpingDutyNotificationAmount').val($(e).parent().parent().find('.TblAntiDumpingDutyNotificationAmount').val());

        $('#NewHealthNotification').val($(e).parent().parent().find('.TblHealthNotification').val());
        $('#NewHealthNotificationSrNo').val($(e).parent().parent().find('.TblHealthNotificationSrNo').val());
        $('#NewHealthNotificationRate').val($(e).parent().parent().find('.TblHealthNotificationRate').val());
        $('#NewHealthNotificationAmount').val($(e).parent().parent().find('.TblHealthNotificationAmount').val());

        $('#NewAdditionalCVDNotification').val($(e).parent().parent().find('.TblAdditionalCVDNotification').val());
        $('#NewAdditionalCVDNotificationSrNo').val($(e).parent().parent().find('.TblAdditionalCVDNotificationSrNo').val());
        $('#NewAdditionalCVDNotificationRate').val($(e).parent().parent().find('.TblAdditionalCVDNotificationRate').val());
        $('#NewAdditionalCVDNotificationAmount').val($(e).parent().parent().find('.TblAdditionalCVDNotificationAmount').val());

        $('#NewAggregateDutyNotification').val($(e).parent().parent().find('.TblAggregateDutyNotification').val());
        $('#NewAggregateDutyNotificationSrNo').val($(e).parent().parent().find('.TblAggregateDutyNotificationSrNo').val());
        $('#NewAggregateDutyNotificationRate').val($(e).parent().parent().find('.TblAggregateDutyNotificationRate').val());
        $('#NewAggregateDutyNotificationAmount').val($(e).parent().parent().find('.TblAggregateDutyNotificationAmount').val());

        $('#NewSafeguardDutyNotification').val($(e).parent().parent().find('.TblSafeguardDutyNotification').val());
        $('#NewSafeguardDutyNotificationSrNo').val($(e).parent().parent().find('.TblSafeguardDutyNotificationSrNo').val());
        $('#NewSafeguardDutyNotificationRate').val($(e).parent().parent().find('.TblSafeguardDutyNotificationRate').val());
        $('#NewSafeguardDutyNotificationAmount').val($(e).parent().parent().find('.TblSafeguardDutyNotificationAmount').val());

        $('#HiddenNewIGSTNotification').val($(e).parent().parent().find('.TblIGSTNotification').val());
        $('#NewIGSTNotification').val($(e).parent().parent().find('.TblIGSTNotification').val());
        $('#NewIGSTNotificationSrNo').val($(e).parent().parent().find('.TblIGSTNotificationSrNo').val());
        $('#NewIGSTNotificationRate').val($(e).parent().parent().find('.TblIGSTNotificationRate').val());
        $('#NewIGSTNotificationAmount').val($(e).parent().parent().find('.TblIGSTNotificationAmount').val());

        $('#HiddenNewIGSTExemNotification').val($(e).parent().parent().find('.TblIGSTExemNotification').val());
        $('#NewIGSTExemNotification').val($(e).parent().parent().find('.TblIGSTExemNotification').val());
        $('#NewIGSTExemNotificationSrNo').val($(e).parent().parent().find('.TblIGSTExemNotificationSrNo').val());
        $('#NewIGSTExemNotificationRate').val($(e).parent().parent().find('.TblIGSTExemNotificationRate').val());
        $('#NewIGSTExemNotificationAmount').val($(e).parent().parent().find('.TblIGSTExemNotificationAmount').val());

        $('#HiddenNewIGSTComCessNotification').val($(e).parent().parent().find('.TblIGSTComCessNotification').val());
        $('#NewIGSTComCessNotification').val($(e).parent().parent().find('.TblIGSTComCessNotification').val());
        $('#NewIGSTComCessNotificationSrNo').val($(e).parent().parent().find('.TblIGSTComCessNotificationSrNo').val());
        $('#NewIGSTComCessNotificationRate').val($(e).parent().parent().find('.TblIGSTComCessNotificationRate').val());
        $('#NewIGSTComCessNotificationAmount').val($(e).parent().parent().find('.TblIGSTComCessNotificationAmount').val());

        $('#HiddenNewIGSTComCessExemNotification').val($(e).parent().parent().find('.TblIGSTComCessExemNotification').val());
        $('#NewIGSTComCessExemNotification').val($(e).parent().parent().find('.TblIGSTComCessExemNotification').val());
        $('#NewIGSTComCessExemNotificationSrNo').val($(e).parent().parent().find('.TblIGSTComCessExemNotificationSrNo').val());
        $('#NewIGSTComCessExemNotificationRate').val($(e).parent().parent().find('.TblIGSTComCessExemNotificationRate').val());
        $('#NewIGSTComCessExemNotificationAmount').val($(e).parent().parent().find('.TblIGSTComCessExemNotificationAmount').val());

        //MANUFACTURER / PRODUCER DETAILS

        $('#HiddenNewItemManufacturerProducerGrowerName').val($(e).parent().parent().find('.HiddenTblItemManufacturerProducerGrowerName').val());
        $('#NewItemManufacturerProducerGrowerName').val($(e).parent().parent().find('.TblItemManufacturerProducerGrowerName').val()).trigger('blur');
        $('#NewItemManufacturerProducerCodeType').val($(e).parent().parent().find('.TblItemManufacturerProducerCodeType').val());
        $('#NewItemManufacturerProducerGrowerCode').val($(e).parent().parent().find('.TblItemManufacturerProducerGrowerCode').val());
        $('#NewItemManufacturerProducerGrowerAddress1').val($(e).parent().parent().find('.TblItemManufacturerProducerGrowerAddress1').val());
        $('#NewItemManufacturerProducerGrowerAddress2').val($(e).parent().parent().find('.TblItemManufacturerProducerGrowerAddress2').val());
        $('#NewItemManufacturerProducerGrowerCity').val($(e).parent().parent().find('.TblItemManufacturerProducerGrowerCity').val());
        $('#NewItemManufacturerProducerGrowerCountrySubDivision').val($(e).parent().parent().find('.TblItemManufacturerProducerGrowerCountrySubDivision').val());
        $('#NewItemManufacturerProducerGrowerPin').val($(e).parent().parent().find('.TblItemManufacturerProducerGrowerPin').val());
        $('#HiddenNewItemManufacturerCountry').val($(e).parent().parent().find('.HiddenTblItemManufacturerCountry').val());
        $('#NewItemManufacturerCountryName').val($(e).parent().parent().find('.TblItemManufacturerCountryName').val());
        $('#HiddenNewSourceCountry').val($(e).parent().parent().find('.HiddenTblSourceCountryName').val());
        $('#NewSourceCountryName').val($(e).parent().parent().find('.TblSourceCountryName').val());
        $('#HiddenNewTransitCountry').val($(e).parent().parent().find('.HiddenTblTransitCountry').val());
        $('#NewTransitCountryName').val($(e).parent().parent().find('.TblTransitCountryName').val());

        //OTHER DETAILS

        $('#NewItemBrandName').val($(e).parent().parent().find('.TblItemBrandName').val());
        $('#NewItemModel').val($(e).parent().parent().find('.TblItemModel').val());
        $('#NewPreferentialStandard').val($(e).parent().parent().find('.TblPreferentialStandard').val());
        $('#NewRSPApplicability').val($(e).parent().parent().find('.TblRSPApplicability').val());
        $('#NewCTHSerialNumber').val($(e).parent().parent().find('.TblCTHSerialNumber').val());
        $('#NewSupplierSerialNumber').val($(e).parent().parent().find('.TblSupplierSerialNumber').val());
        $('#NewQuantityAsPerAntiDumpingNotification').val($(e).parent().parent().find('.TblQuantityAsPerAntiDumpingNotification').val());
        $('#NewTarrifValueNotification').val($(e).parent().parent().find('.TblTarrifValueNotification').val());
        $('#NewTarrifValueItemSrNo').val($(e).parent().parent().find('.TblTarrifValueItemSrNo').val());
        $('#NewQuantityAsPerTarrifValueNotification').val($(e).parent().parent().find('.TblQuantityAsPerTarrifValueNotification').val());
        $('#NewSAPTANotification').val($(e).parent().parent().find('.TblSAPTANotification').val());
        $('#NewSAPTANotificationSrNo').val($(e).parent().parent().find('.TblSAPTANotificationSrNo').val());
        $('#NewQtyAsPerCTH').val($(e).parent().parent().find('.TblQtyAsPerCTH').val());
        $('#NewQuantityAsPerCTH').val($(e).parent().parent().find('.TblQuantityAsPerCTH').val());
        $('#NewPolicyParaNo').val($(e).parent().parent().find('.TblPolicyParaNo').val());
        $('#NewPolicyYear').val($(e).parent().parent().find('.TblPolicyYear').val());
        $('#NewPreviousBENo').val($(e).parent().parent().find('.TblPreviousBENo').val());
        $('#NewPreviousBEDate').val($(e).parent().parent().find('.TblPreviousBEDate').val());
        $('#NewPreviousUnitPrice').val($(e).parent().parent().find('.TblPreviousUnitPrice').val());
        $('#HiddenNewPreviousCurrencyCode').val($(e).parent().parent().find('.HiddenTblPreviousCurrencyCode').val());
        $('#NewPreviousCurrency').val($(e).parent().parent().find('.TblPreviousCurrency').val());
        $('#HiddenNewPreviousCustomSite').val($(e).parent().parent().find('.HiddenTblPreviousCustomSite').val());
        $('#NewPreviousCustomSiteName').val($(e).parent().parent().find('.TblPreviousCustomSiteName').val());
        $('#NewCustomNotnExemptingCentralExciseFlag').val($(e).parent().parent().find('.TblCustomNotnExemptingCentralExciseFlag').val());
        $('#NewAccessoryStatus').val($(e).parent().parent().find('.TblAccessoryStatus').val());
        $('#NewItemAccessoriesOfItem').val($(e).parent().parent().find('.TblItemAccessoriesOfItem').val());

    }
}

//NEWUPDATEITEM BUTTON CLICK EVENT
$('#NewUpdateItem').click(function () {
    if ($('#NewItemInvoiceNo').val() == null) {
        Toast('Please Add Invoice Details.', 'Message', 'error');
        ActiveInvoiceDetailsTab();
        $('#NewInvoiceNo').focus();
        return;
    }
    else if ($('#NewItemInvoiceNo').val() == '0') {
        Toast('Please Select Invoice Number', 'Message', 'error');
        ActiveItemMainTab();
        $('#NewItemInvoiceNo').focus();
        return;
    }
    else if ($('#NewItemName').val().trim().length <= 0) {
        Toast('Please Add Item.', 'Message', 'error');
        ActiveItemMainTab();
        $('#NewItemName').focus();
        return;
    }
    else if ($('#NewItemDescription').val().trim().length <= 0) {
        Toast('Please Add Item Descriptions.', 'Message', 'error');
        ActiveItemMainTab();
        $('#NewItemDescription').focus();
        return;
    }
    else if ($('#NewItemEndUse').val().trim().length <= 0) {
        Toast('Please Add End Use.', 'Message', 'error');
        ActiveItemMainTab();
        $('#NewItemEndUse').focus();
        return;
    }
    else if ($('#NewItemEndUseDesc').val().trim().length <= 0) {
        Toast('Please Add End Use Descriptions.', 'Message', 'error');
        ActiveItemMainTab();
        $('#NewItemEndUseDesc').focus();
        return;
    }
    else if ($('#NewItemBrandName').val().trim().length <= 0) {
        Toast('Please Add Item Brand', 'Message', 'error');
        ActiveItemOtherTab();
        $('#NewItemBrandName').focus();
        return;
    }
    else if ($('#NewItemModel').val().trim().length <= 0) {
        Toast('Please Add Item Model.', 'Message', 'error');
        ActiveItemOtherTab();
        $('#NewItemModel').focus();
        return;
    }
    else if ($('#NewItemAmount').val().trim() <= 0) {
        Toast('Please Enter Item Amount.', 'Message', 'error');
        ActiveItemMainTab();
        $('#NewItemAmount').focus();
        return;
    }
    else if ($('#NewItemQuantity').val().trim() <= 0) {
        Toast('Please Add Item Quantity.', 'Message', 'error');
        ActiveItemMainTab();
        $('#NewItemQuantity').focus();
        return;
    }
    else if ($('#NewUnitQuantityCode').val().trim().length <= 0) {
        Toast('Please Add Item Unit.', 'Message', 'error');
        ActiveItemMainTab();
        $('#NewUnitQuantityCode').focus();
        return;
    }
    else if ($('#NewItemMode').val() == '0' || $('#NewItemMode').val() == null || $('#NewItemMode').val() == undefined || $('#NewItemMode').val() == '') {
        Toast('Please Add Item Mode.', 'Message', 'error');
        ActiveItemDutyTab();
        $('#NewItemMode').focus();
        return;
    }
    else if ($('#NewItemCategorySchemeCode').val() == '0' || $('#NewItemCategorySchemeCode').val() == null || $('#NewItemCategorySchemeCode').val() == undefined || $('#NewItemCategorySchemeCode').val() == '') {
        Toast('Please Add Scheme.', 'Message', 'error');
        ActiveItemDutyTab();
        $('#NewItemCategorySchemeCode').focus();
        return;
    }
    else if ($('#NewRITCCode').val().trim().length <= 0) {
        Toast('Please Add Item RITC Code.', 'Message', 'error');
        ActiveItemDutyTab();
        $('#NewRITCCode').focus();
        return;
    }
    else if ($('#NewItemCTH').val().trim().length <= 0) {
        Toast('Please Add Item CTH Code.', 'Message', 'error');
        ActiveItemDutyTab();
        $('#NewItemCTH').focus();
        return;
    }
    else if ($('#NewItemCTEH').val().trim().length <= 0) {
        Toast('Please Add Item CTEH Code', 'Message', 'error');
        ActiveItemDutyTab();
        $('#NewItemCTEH').focus();
        return;
    }
    else if ($('#NewSQCUnitCode').val().trim().length == 0) {
        Toast('Please Add Item CTEH Code', 'Message', 'error');
        ActiveItemDutyTab();
        $('#NewSQCUnitCode').focus();
        return;
    }
    else
        NewUpdateItemRow($('#NewRowNumItem').val());
});

//FUNCTION FOR UPDATE NEW ITEM ROW ENTRY
function NewUpdateItemRow(Rn) {
    DutyCalculation();

    $('#TblItemDetails tbody tr').each(function (ind, ele) {
        if ($(ele).find('.rn').text().trim() == Rn) {

            //MAIN DETAILS

            $(ele).find('.TblItemInvoiceNo').val($('#NewItemInvoiceNo').val());
            $(ele).find('.TblReImport').val($('#NewReImport').val());
            $(ele).find('.HiddenTblItemName').val($('#HiddenNewItemName').val());
            $(ele).find('.TblItemName').val($('#NewItemName').val());
            $(ele).find('.TblItemDescription').val($('#NewItemDescription').val());
            $(ele).find('.TblItemGenericDescription').val($('#NewItemGenericDescription').val());
            $(ele).find('.HiddenTblItemEndUse').val($('#HiddenNewItemEndUse').val());
            $(ele).find('.TblItemEndUse').val($('#NewItemEndUse').val());
            $(ele).find('.TblItemEndUseDesc').val($('#NewItemEndUseDesc').val());
            $(ele).find('.HiddenTblItemCountryOrigin').val($('#HiddenNewItemCountryOrigin').val());
            $(ele).find('.TblItemCountryOrigin').val($('#NewItemCountryOrigin').val());
            $(ele).find('.TblItemAmount').val($('#NewItemAmount').val());
            $(ele).find('.TblItemQuantity').val($('#NewItemQuantity').val());
            $(ele).find('.TblItemUnitPrice').val($('#NewItemUnitPrice').val());
            $(ele).find('.HiddenTblUnitQuantityCode').val($('#HiddenNewUnitQuantityCode').val());
            $(ele).find('.TblUnitQuantityCode').val($('#NewUnitQuantityCode').val());
            $(ele).find('.TblItemFreight').val($('#NewItemFreight').val());
            $(ele).find('.TblItemInsurance').val($('#NewItemInsurance').val());
            $(ele).find('.TblItemMiscCharge').val($('#NewItemMiscCharge').val());
            $(ele).find('.TblItemLoading').val($('#NewItemLoading').val());
            $(ele).find('.TblHSSLoadAmount').val($('#NewHSSLoadAmount').val());
            $(ele).find('.TblItemCIFValue').val($('#NewItemCIFValue').val());
            $(ele).find('.TblItemDutyAmount').val($('#NewItemDutyAmount').val());
            $(ele).find('.TblItemDutyGone').val($('#NewItemDutyGone').val());

            //DUTY DETAILS

            $(ele).find('.HiddenTblLicCheck').val($('#HiddenLicCheck').val());
            $(ele).find('.TblItemMode').val($('#NewItemMode').val());
            $(ele).find('.TblItemCategorySchemeCode').val($('#NewItemCategorySchemeCode').val());
            $(ele).find('.TblRITCCode').val($('#NewRITCCode').val());
            $(ele).find('.TblItemCTH').val($('#NewItemCTH').val());
            $(ele).find('.TblItemCTEH').val($('#NewItemCTEH').val());
            $(ele).find('.TblDEPBNotification').val($('#NewDEPBNotification').val());
            $(ele).find('.TblDEPBNotificationSrNo').val($('#NewDEPBNotificationSrNo').val());
            $(ele).find('.TblExempted').val($('#NewExempted').val());
            $(ele).find('.TblSQCQuantity').val($('#NewSQCQuantity').val());
            $(ele).find('.HiddenTblSQCQuantityCode').val($('#HiddenNewSQCUnitCode').val());
            $(ele).find('.TblSQCQuantityCode').val($('#NewSQCUnitCode').val());

            $(ele).find('.TblItemBCDNotification').val($('#NewItemBCDNotification').val());
            $(ele).find('.TblItemBCDNotificationSrNo').val($('#NewItemBCDNotificationSrNo').val());
            $(ele).find('.TblItemBCDRate').val($('#NewItemBCDRate').val());
            $(ele).find('.TblItemBCDAmount').val($('#NewItemBCDAmount').val());

            $(ele).find('.TblItemCVDNotification').val($('#NewItemCVDNotification').val());
            $(ele).find('.TblItemCVDNotificationSrNo').val($('#NewItemCVDNotificationSrNo').val());
            $(ele).find('.TblItemCVDRate').val($('#NewItemCVDRate').val());
            $(ele).find('.TblItemCVDAmount').val($('#NewItemCVDAmount').val());

            $(ele).find('.TblAdditionalNotification1').val($('#NewAdditionalNotification1').val());
            $(ele).find('.TblAdditionalNotification1SrNo').val($('#NewAdditionalNotification1SrNo').val());
            $(ele).find('.TblAdditionalNotification1Rate').val($('#NewAdditionalNotification1Rate').val());
            $(ele).find('.TblAdditionalNotification1Amount').val($('#NewAdditionalNotification1Amount').val());

            $(ele).find('.TblAdditionalNotification2').val($('#NewAdditionalNotification2').val());
            $(ele).find('.TblAdditionalNotification2SrNo').val($('#NewAdditionalNotification2SrNo').val());
            $(ele).find('.TblAdditionalNotification2Rate').val($('#NewAdditionalNotification2Rate').val());
            $(ele).find('.TblAdditionalNotification2Amount').val($('#NewAdditionalNotification2Amount').val());

            $(ele).find('.TblOtherNotification').val($('#NewOtherNotification').val());
            $(ele).find('.TblOtherNotificationSrNo').val($('#NewOtherNotificationSrNo').val());
            $(ele).find('.TblOtherNotificationRate').val($('#NewOtherNotificationRate').val());
            $(ele).find('.TblOtherNotificationAmount').val($('#NewOtherNotificationAmount').val());

            $(ele).find('.TblSocialWelfareNotification').val($('#NewSocialWelfareNotification').val());
            $(ele).find('.TblSocialWelfareNotificationSrNo').val($('#NewSocialWelfareNotificationSrNo').val());
            $(ele).find('.TblSocialWelfareRate').val($('#NewSocialWelfareRate').val());
            $(ele).find('.TblSocialWelfareAmount').val($('#NewSocialWelfareAmount').val());

            $(ele).find('.TblNCDNotification').val($('#NewNCDNotification').val());
            $(ele).find('.TblNCDNotificationSrNo').val($('#NewNCDNotificationSrNo').val());
            $(ele).find('.TblNCDNotificationRate').val($('#NewNCDNotificationRate').val());
            $(ele).find('.TblNCDNotificationAmount').val($('#NewNCDNotificationAmount').val());

            $(ele).find('.TblAntiDumpingDutyNotification').val($('#NewAntiDumpingDutyNotification').val());
            $(ele).find('.TblAntiDumpingDutyNotificationSrNo').val($('#NewAntiDumpingDutyNotificationSrNo').val());
            $(ele).find('.TblAntiDumpingDutyNotificationRate').val($('#NewAntiDumpingDutyNotificationRate').val());
            $(ele).find('.TblAntiDumpingDutyNotificationAmount').val($('#NewAntiDumpingDutyNotificationAmount').val());

            $(ele).find('.TblHealthNotification').val($('#NewHealthNotification').val());
            $(ele).find('.TblHealthNotificationSrNo').val($('#NewHealthNotificationSrNo').val());
            $(ele).find('.TblHealthNotificationRate').val($('#NewHealthNotificationRate').val());
            $(ele).find('.TblHealthNotificationAmount').val($('#NewHealthNotificationAmount').val());

            $(ele).find('.TblAdditionalCVDNotification').val($('#NewAdditionalCVDNotification').val());
            $(ele).find('.TblAdditionalCVDNotificationSrNo').val($('#NewAdditionalCVDNotificationSrNo').val());
            $(ele).find('.TblAdditionalCVDNotificationRate').val($('#NewAdditionalCVDNotificationRate').val());
            $(ele).find('.TblAdditionalCVDNotificationAmount').val($('#NewAdditionalCVDNotificationAmount').val());

            $(ele).find('.TblAggregateDutyNotification').val($('#NewAggregateDutyNotification').val());
            $(ele).find('.TblAggregateDutyNotificationSrNo').val($('#NewAggregateDutyNotificationSrNo').val());
            $(ele).find('.TblAggregateDutyNotificationRate').val($('#NewAggregateDutyNotificationRate').val());
            $(ele).find('.TblAggregateDutyNotificationAmount').val($('#NewAggregateDutyNotificationAmount').val());

            $(ele).find('.TblSafeguardDutyNotification').val($('#NewSafeguardDutyNotification').val());
            $(ele).find('.TblSafeguardDutyNotificationSrNo').val($('#NewSafeguardDutyNotificationSrNo').val());
            $(ele).find('.TblSafeguardDutyNotificationRate').val($('#NewSafeguardDutyNotificationRate').val());
            $(ele).find('.TblSafeguardDutyNotificationAmount').val($('#NewSafeguardDutyNotificationAmount').val());

            $(ele).find('.TblIGSTNotification').val($('#NewIGSTNotification').val());
            $(ele).find('.TblIGSTNotificationSrNo').val($('#NewIGSTNotificationSrNo').val());
            $(ele).find('.TblIGSTNotificationRate').val($('#NewIGSTNotificationRate').val());
            $(ele).find('.TblIGSTNotificationAmount').val($('#NewIGSTNotificationAmount').val());

            $(ele).find('.TblIGSTExemNotification').val($('#NewIGSTExemNotification').val());
            $(ele).find('.TblIGSTExemNotificationSrNo').val($('#NewIGSTExemNotificationSrNo').val());
            $(ele).find('.TblIGSTExemNotificationRate').val($('#NewIGSTExemNotificationRate').val());
            $(ele).find('.TblIGSTExemNotificationAmount').val($('#NewIGSTExemNotificationAmount').val());

            $(ele).find('.TblIGSTComCessNotification').val($('#NewIGSTComCessNotification').val());
            $(ele).find('.TblIGSTComCessNotificationSrNo').val($('#NewIGSTComCessNotificationSrNo').val());
            $(ele).find('.TblIGSTComCessNotificationRate').val($('#NewIGSTComCessNotificationRate').val());
            $(ele).find('.TblIGSTComCessNotificationAmount').val($('#NewIGSTComCessNotificationAmount').val());

            $(ele).find('.TblIGSTComCessExemNotification').val($('#NewIGSTComCessExemNotification').val());
            $(ele).find('.TblIGSTComCessExemNotificationSrNo').val($('#NewIGSTComCessExemNotificationSrNo').val());
            $(ele).find('.TblIGSTComCessExemNotificationRate').val($('#NewIGSTComCessExemNotificationRate').val());
            $(ele).find('.TblIGSTComCessExemNotificationAmount').val($('#NewIGSTComCessExemNotificationAmount').val());

            //MANUFACTURER/PRODUCER DETAILS

            $(ele).find('.HiddenTblItemManufacturerProducerGrowerName').val($('#HiddenNewItemManufacturerProducerGrowerName').val());
            $(ele).find('.TblItemManufacturerProducerGrowerName').val($('#NewItemManufacturerProducerGrowerName').val());
            $(ele).find('.TblItemManufacturerProducerCodeType').val($('#NewItemManufacturerProducerCodeType').val());
            $(ele).find('.TblItemManufacturerProducerGrowerCode').val($('#NewItemManufacturerProducerGrowerCode').val());
            $(ele).find('.TblItemManufacturerProducerGrowerAddress1').val($('#NewItemManufacturerProducerGrowerAddress1').val());
            $(ele).find('.TblItemManufacturerProducerGrowerAddress2').val($('#NewItemManufacturerProducerGrowerAddress2').val());
            $(ele).find('.TblItemManufacturerProducerGrowerCity').val($('#NewItemManufacturerProducerGrowerCity').val());
            $(ele).find('.TblItemManufacturerProducerGrowerCountrySubDivision').val($('#NewItemManufacturerProducerGrowerCountrySubDivision').val());
            $(ele).find('.TblItemManufacturerProducerGrowerPin').val($('#NewItemManufacturerProducerGrowerPin').val());
            $(ele).find('.HiddenTblItemManufacturerCountry').val($('#HiddenNewItemManufacturerCountry').val());
            $(ele).find('.TblItemManufacturerCountryName').val($('#NewItemManufacturerCountryName').val());
            $(ele).find('.HiddenTblSourceCountryName').val($('#HiddenNewSourceCountry').val());
            $(ele).find('.TblSourceCountryName').val($('#NewSourceCountryName').val());
            $(ele).find('.HiddenTblTransitCountry').val($('#HiddenNewTransitCountry').val());
            $(ele).find('.TblTransitCountryName').val($('#NewTransitCountryName').val());

            //OTHER DETAILS

            $(ele).find('.TblItemBrandName').val($('#NewItemBrandName').val());
            $(ele).find('.TblItemModel').val($('#NewItemModel').val());
            $(ele).find('.TblPreferentialStandard').val($('#NewPreferentialStandard').val());
            $(ele).find('.TblRSPApplicability').val($('#NewRSPApplicability').val());
            $(ele).find('.TblCTHSerialNumber').val($('#NewCTHSerialNumber').val());
            $(ele).find('.TblSupplierSerialNumber').val($('#NewSupplierSerialNumber').val());
            $(ele).find('.TblQuantityAsPerAntiDumpingNotification').val($('#NewQuantityAsPerAntiDumpingNotification').val());
            $(ele).find('.TblTarrifValueNotification').val($('#NewTarrifValueNotification').val());
            $(ele).find('.TblTarrifValueItemSrNo').val($('#NewTarrifValueItemSrNo').val());
            $(ele).find('.TblQuantityAsPerTarrifValueNotification').val($('#NewQuantityAsPerTarrifValueNotification').val());
            $(ele).find('.TblSAPTANotification').val($('#NewSAPTANotification').val());
            $(ele).find('.TblSAPTANotificationSrNo').val($('#NewSAPTANotificationSrNo').val());
            $(ele).find('.TblQtyAsPerCTH').val($('#NewQtyAsPerCTH').val());
            $(ele).find('.TblQuantityAsPerCTH').val($('#NewQuantityAsPerCTH').val());
            $(ele).find('.TblPolicyParaNo').val($('#NewPolicyParaNo').val());
            $(ele).find('.TblPolicyYear').val($('#NewPolicyYear').val());
            $(ele).find('.TblPreviousBENo').val($('#NewPreviousBENo').val());
            $(ele).find('.TblPreviousBEDate').val($('#NewPreviousBEDate').val());
            $(ele).find('.TblPreviousUnitPrice').val($('#NewPreviousUnitPrice').val());
            $(ele).find('.HiddenTblPreviousCurrencyCode').val($('#HiddenNewPreviousCurrencyCode').val());
            $(ele).find('.TblPreviousCurrency').val($('#NewPreviousCurrency').val());
            $(ele).find('.HiddenTblPreviousCustomSite').val($('#HiddenNewPreviousCustomSite').val());
            $(ele).find('.TblPreviousCustomSiteName').val($('#NewPreviousCustomSiteName').val());
            $(ele).find('.TblCustomNotnExemptingCentralExciseFlag').val($('#NewCustomNotnExemptingCentralExciseFlag').val());
            $(ele).find('.TblAccessoryStatus').val($('#NewAccessoryStatus').val());
            $(ele).find('.TblItemAccessoriesOfItem').val($('NewItemAccessoriesOfItem').val());

            ResetNewItem();
            GenerateSerialNumberTable('TblItemDetails', 'rn');
            NewGenerateItemNameList();
            Toast('Update Item Successfully.', 'Message', 'success');
            CalcAssCifDuty();
        }
    });
}

//FUNCTION FOR DELETE ITEM ROW ENTRY
function DeleteItemRowEntry(e) {
    let RowCount = $("#TblItemDetails tbody tr").length;
    let ItN = $(e).parent().parent().find('.TblItemName').val().trim();
    let ItRn = $(e).parent().parent().find('.rn').text();
    let ItLi = [];
    let ItDe = [];
    let ItEs = [];

    $("#TblLicenceDetails tbody tr").each(function (ind, ele) {
        if ($(ele).find('.TblLicenseItemSr').val().trim().length > 0) {
            ItLi.push($(ele).find('.TblLicenseItemSr').val());
        }
    });

    $("#TblDestuffDetails tbody tr").each(function (ind, ele) {
        if ($(ele).find('.TblDestuffItemSr').val().trim().length > 0) {
            ItDe.push($(ele).find('.TblDestuffItemSr').val());
        }
    });

    $('#TblJobSupportDocs tbody tr').each(function (inde, ele) {
        if ($(ele).find('.TblItemSrNo').val() == ItRn)
            ItEs.push($(ele).find('.TblItemSrNo').val());
    });

    if (ItN.length == 0)
        Toast('Item Name Blank.', 'Message', 'error');
    else if ($('#NewAddItem').hasClass('d-none')) {
        Toast('Please Update Item.', 'Message', 'error');
    }
    else {
        $.confirm({
            title: '',
            content: 'Are You Sure Want To Delete ?',
            type: 'red',
            boxWidth: '300px',
            useBootstrap: false,
            typeAnimated: true,
            columnClass: 'small',
            containerFluid: true,
            draggable: true,
            buttons: {
                tryAgain: {
                    text: 'Confirm',
                    btnClass: 'btn-red',
                    action: function () {
                        if (ItLi.includes(ItRn) == true || ItDe.includes(ItRn) == true || ItEs.includes(ItRn) == true) {
                            $.confirm({
                                title: '',
                                content: 'This Item  Use In Destuff Details/License/ESanchit Details.Are You Sure Want To Delete ?',
                                type: 'red',
                                boxWidth: '300px',
                                useBootstrap: false,
                                typeAnimated: true,
                                columnClass: 'small',
                                containerFluid: true,
                                draggable: true,
                                buttons: {
                                    tryAgain: {
                                        text: 'Confirm',
                                        btnClass: 'btn-red',
                                        action: function () {
                                            let RowNumItem = [];
                                            RowNumItem.push(ItRn);
                                            DeleteESanchitRowItemWise(RowNumItem);  //DELETE ITEM FROM ESANCHIT
                                            DeleteDestuffRowItemWise(RowNumItem); //DELETE ITEM FROM DESTUFF
                                            DeleteLicenseRowItemWise(RowNumItem);  //DELETE ITEM FROM LICENSE
                                            ResetDeleteItemRowEntry(e, RowCount);  // DELETE ITEM ROW ENTRY
                                            GenerateSerialNumberTable('TblItemDetails', 'rn');
                                            CalcAssCifDuty();
                                            NewGenerateItemNameList('Delete', ItRn); // GENERATE ITEM NAME LIST
                                        }
                                    },
                                    cancel: function () {
                                    }
                                }
                            });
                        }
                        else {
                            ResetDeleteItemRowEntry(e, RowCount);   // DELETE ITEM ROW ENTRY
                            GenerateSerialNumberTable('TblItemDetails', 'rn');
                            CalcAssCifDuty();
                            NewGenerateItemNameList();  // GENERATE ITEM NAME LIST
                        }
                    }
                },
                close: function () {
                }
            }
        });
    }
}

//FUNCTION FOR RESET OR DELETE IN ITEM ROW ENTRY
function ResetDeleteItemRowEntry(e, RowCount) {

    if (RowCount > 1)
        $(e).parent().parent().remove();
    else {
        $(e).parent().parent().find('.HiddenTblItemName,.TblItemName,.TblItemDescription,.TblItemGenericDescription,.HiddenTblItemEndUse,.TblItemEndUse,.TblItemEndUseDesc,.HiddenTblItemCountryOrigin,.TblItemCountryOrigin,.HiddenTblUnitQuantityCode,.TblUnitQuantityCode,.TblRITCCode,.TblItemCTH,.TblItemCTEH,.TblDEPBNotification,.TblDEPBNotificationSrNo,.TblItemBCDNotification,.TblItemBCDNotificationSrNo,.TblItemCVDNotification,.TblItemCVDNotificationSrNo,.TblAdditionalNotification1,.TblAdditionalNotification1SrNo,.TblAdditionalNotification2,.TblAdditionalNotification2SrNo,.TblOtherNotification,.TblOtherNotificationSrNo,.TblSocialWelfareNotification,.TblSocialWelfareNotificationSrNo,.TblNCDNotification,.TblNCDNotificationSrNo,.TblAntiDumpingDutyNotification,.TblAntiDumpingDutyNotificationSrNo,.TblHealthNotification,.TblHealthNotificationSrNo,.TblAdditionalCVDNotification,.TblAdditionalCVDNotificationSrNo,.TblAggregateDutyNotification,.TblAggregateDutyNotificationSrNo,.TblSafeguardDutyNotification,.TblSafeguardDutyNotificationSrNo,.TblIGSTNotification,.TblIGSTNotificationSrNo,.TblDEPBNotification,.TblDEPBNotificationSrNo,.TblIGSTExemNotification,.TblIGSTExemNotificationSrNo,.TblIGSTComCessNotification,.TblIGSTComCessNotificationSrNo,.TblIGSTComCessExemNotification,.TblIGSTComCessExemNotificationSrNo,.HiddenTblItemManufacturerProducerGrowerName,.TblItemManufacturerProducerGrowerName,.TblItemManufacturerProducerCodeType,.TblItemManufacturerProducerGrowerCode,.TblItemManufacturerProducerGrowerAddress1,.TblItemManufacturerProducerGrowerAddress2,.TblItemManufacturerProducerGrowerCity,.TblItemManufacturerProducerGrowerCountrySubDivision,.TblItemManufacturerProducerGrowerPin,.HiddenTblItemManufacturerCountry,.TblItemManufacturerCountryName,.HiddenTblSourceCountryName,.TblSourceCountryName,.HiddenTblTransitCountry,.TblTransitCountryName,.TblCTHSerialNumber,.TblSupplierSerialNumber,.TblTarrifValueNotification,.TblTarrifValueItemSrNo,.TblSAPTANotification,.TblSAPTANotificationSrNo,.TblPolicyParaNo,.TblPolicyYear,.TblPreviousBENo,.TblPreviousBEDate,.HiddenTblPreviousCurrencyCode,.TblPreviousCurrency,.HiddenTblPreviousCustomSite,.TblPreviousCustomSiteName,.TblCustomNotnExemptingCentralExciseFlag,.TblItemAccessoriesOfItem,.HiddenTblSQCQuantityCode,.TblSQCQuantityCode').val('');


        $(e).parent().parent().find('.TblItemAmount,.TblItemFreight,.TblItemInsurance,.TblItemMiscCharge,.TblItemLoading,.TblHSSLoadAmount,.TblItemCIFValue,.TblItemDutyAmount,.TblItemDutyGone,.TblItemBCDRate,.TblItemBCDAmount,.TblItemCVDRate,.TblItemCVDAmount,.TblAdditionalNotification1Rate,.TblAdditionalNotification1Amount,.TblAdditionalNotification2Rate,.TblAdditionalNotification2Amount,.TblOtherNotificationRate,.TblOtherNotificationAmount,.TblSocialWelfareAmount,.TblNCDNotificationRate,.TblNCDNotificationAmount,.TblAntiDumpingDutyNotificationRate,.TblAntiDumpingDutyNotificationAmount,.TblHealthNotificationRate,.TblHealthNotificationAmount,.TblAdditionalCVDNotificationRate,.TblAdditionalCVDNotificationAmount,.TblAggregateDutyNotificationRate,.TblAggregateDutyNotificationAmount,.TblSafeguardDutyNotificationRate,.TblSafeguardDutyNotificationAmount,.TblIGSTNotificationRate,.TblIGSTNotificationAmount,.TblIGSTExemNotificationRate,.TblIGSTExemNotificationAmount,.TblIGSTComCessNotificationRate,.TblIGSTComCessNotificationAmount,.TblIGSTComCessExemNotificationRate,.TblIGSTComCessExemNotificationAmount,.TblQuantityAsPerAntiDumpingNotification,.TblQuantityAsPerTarrifValueNotification,.TblQtyAsPerCTH,.TblQuantityAsPerCTH,.TblPreviousUnitPrice').val('0.00');

        $(e).parent().parent().find('.TblRSPApplicability').val('N');
        $(e).parent().parent().find('.TblReImport').val('N');
        $(e).parent().parent().find('.TblItemBrandName').val('NA');
        $(e).parent().parent().find('.TblItemModel').val('NA');
        $(e).parent().parent().find('.TblItemQuantity,.TblItemUnitPrice,.TblSQCQuantity').val('0.000000');
        $(e).parent().parent().find('.HiddenTblLicCheck').val('false');
        $(e).parent().parent().find('.TblItemMode').val('0');
        $(e).parent().parent().find('.TblExempted').val('No');
        $(e).parent().parent().find('.TblItemCategorySchemeCode').val('0');
        $(e).parent().parent().find('.TblSocialWelfareRate').val('10.00');
        $(e).parent().parent().find('.TblAccessoryStatus').val('0');
        $(e).parent().parent().find('.TblPreferentialStandard').val('P');
        $(e).parent().parent().find('.TblItemInvoiceNo').val(0);

    }
}

//FUNCTION FOR VIEW ADD ESANCHIT ROW ENTRY
function ESanchitItemRowEntry(e) {

    let ItN = $(e).parent().parent().find('.TblItemName').val().trim();
    if (ItN.length == 0)
        Toast('Item Name Blank.', 'Message', 'error');
    else if ($('#NewAddItem').hasClass('d-none')) {
        Toast('Please Update Item.', 'Message', 'error');
    }
    else {

        $('#RowNumInvoice').val($(e).parent().parent().find('.TblItemInvoiceNo').val());
        $('#RownNumItem').val($(e).parent().parent().find('.rn').text());

        $('#TblItemESanchit tbody tr').find('.TblNewItemPlaceOfIssue').val($('#CountryOrigin').val());

        $('#TblItemESanchit tbody tr').find('.HiddenTblNewItemDocumentIssuingParty').val($('#HiddenShipper').val());
        $('#TblItemESanchit tbody tr').find('.TblNewItemDocumentIssuingPartyName').val($('#Shipper').val());

        $('#TblItemESanchit tbody tr').find('.HiddenTblNewItemDocumentBeneficiaryParty').val($('#HiddenImporterName').val());
        $('#TblItemESanchit tbody tr').find('.TblNewItemDocumentBeneficiaryPartyName').val($('#ImporterName').val());
        ItemESanchitModal.style.display = 'block';
        GetAllDataFromESanchit($(e).parent().parent().find('.rn').text());
    }
}


//FUNCTION FOR ITEM CLONE ROW
function CloneItemRow(e) {
    let Rn = $(e).parent().parent().find('.rn').text().trim();
    let InvNo = $(e).parent().parent().find('.TblItemInvoiceNo').val();

    if (InvNo == null || InvNo == undefined || InvNo == '0' || InvNo.length == 0)
        Toast('Invalid Invoice Number.', 'Message', 'error');
    else {

        if ($('#NewAddItem').hasClass('d-none')) {
            Toast('Please Update Item.', 'Message', 'error');
            return;
        }
        ResetNewItem();


        //MAIN DETAILS
       
        $('#NewItemInvoiceNo').val($(e).parent().parent().find('.TblItemInvoiceNo').val());
        $('#NewReImport').val($(e).parent().parent().find('.TblReImport').val());
        $('#HiddenNewItemName').val($(e).parent().parent().find('.HiddenTblItemName').val());
        $('#NewItemName').val($(e).parent().parent().find('.TblItemName').val());
        $('#NewItemDescription').val($(e).parent().parent().find('.TblItemDescription').val());
        $('#NewItemGenericDescription').val($(e).parent().parent().find('.TblItemGenericDescription').val());
        $('#HiddenNewItemEndUse').val($(e).parent().parent().find('.HiddenTblItemEndUse').val());
        $('#NewItemEndUse').val($(e).parent().parent().find('.TblItemEndUse').val());
        $('#NewItemEndUseDesc').val($(e).parent().parent().find('.TblItemEndUseDesc').val());
        $('#HiddenNewItemCountryOrigin').val($(e).parent().parent().find('.HiddenTblItemCountryOrigin').val());

        $('#NewItemCountryOrigin').val($(e).parent().parent().find('.TblItemCountryOrigin').val());
        $('#NewItemAmount').val($(e).parent().parent().find('.TblItemAmount').val());
        $('#NewItemQuantity').val($(e).parent().parent().find('.TblItemQuantity').val());
        $('#NewItemUnitPrice').val($(e).parent().parent().find('.TblItemUnitPrice').val());
        $('#HiddenNewUnitQuantityCode').val($(e).parent().parent().find('.HiddenTblUnitQuantityCode').val());
        $('#NewUnitQuantityCode').val($(e).parent().parent().find('.TblUnitQuantityCode').val());
        $('#NewItemFreight').val($(e).parent().parent().find('.TblItemFreight').val());
        $('#NewItemInsurance').val($(e).parent().parent().find('.TblItemInsurance').val());
        $('#NewItemMiscCharge').val($(e).parent().parent().find('.TblItemMiscCharge').val());
        $('#NewItemLoading').val($(e).parent().parent().find('.TblItemLoading').val());

        $('#NewHSSLoadAmount').val($(e).parent().parent().find('.TblHSSLoadAmount').val());
        $('#NewItemCIFValue').val($(e).parent().parent().find('.TblItemCIFValue').val());
        $('#NewItemDutyAmount').val($(e).parent().parent().find('.TblItemDutyAmount').val());
        $('#NewItemDutyGone').val($(e).parent().parent().find('.TblItemDutyGone').val());

        //DUTY DETAILS

        $('#HiddenLicCheck').val($(e).parent().parent().find('.HiddenTblLicCheck').val());
        $('#NewItemMode').val($(e).parent().parent().find('.TblItemMode').val());
        $('#NewItemCategorySchemeCode').val($(e).parent().parent().find('.TblItemCategorySchemeCode').val());
        $('#HiddenNewRITCCode').val($(e).parent().parent().find('.TblRITCCode').val());
        $('#NewRITCCode').val($(e).parent().parent().find('.TblRITCCode').val());
        $('#HiddenNewItemCTH').val($(e).parent().parent().find('.TblItemCTH').val());
        $('#NewItemCTH').val($(e).parent().parent().find('.TblItemCTH').val());
        $('#HiddenNewItemCTEH').val($(e).parent().parent().find('.TblItemCTEH').val());
        $('#NewItemCTEH').val($(e).parent().parent().find('.TblItemCTEH').val());
        $('#NewDEPBNotification').val($(e).parent().parent().find('.TblDEPBNotification').val());
        $('#NewDEPBNotificationSrNo').val($(e).parent().parent().find('.TblDEPBNotificationSrNo').val());
        $('#NewExempted').val($(e).parent().parent().find('.TblExempted').val());
        $('#NewSQCQuantity').val($(e).parent().parent().find('.TblSQCQuantity').val());
        $('#HiddenNewSQCUnitCode').val($(e).parent().parent().find('.HiddenTblSQCQuantityCode').val());
        $('#NewSQCUnitCode').val($(e).parent().parent().find('.TblSQCQuantityCode').val());

        $('#HiddenNewItemBCDNotification').val($(e).parent().parent().find('.TblItemBCDNotification').val());
        $('#NewItemBCDNotification').val($(e).parent().parent().find('.TblItemBCDNotification').val());
        $('#NewItemBCDNotificationSrNo').val($(e).parent().parent().find('.TblItemBCDNotificationSrNo').val());
        $('#NewItemBCDRate').val($(e).parent().parent().find('.TblItemBCDRate').val());
        $('#NewItemBCDAmount').val($(e).parent().parent().find('.TblItemBCDAmount').val());

        $('#HiddenNewItemCVDNotification').val($(e).parent().parent().find('.TblItemCVDNotification').val());
        $('#NewItemCVDNotification').val($(e).parent().parent().find('.TblItemCVDNotification').val());
        $('#NewItemCVDNotificationSrNo').val($(e).parent().parent().find('.TblItemCVDNotificationSrNo').val());
        $('#NewItemCVDRate').val($(e).parent().parent().find('.TblItemCVDRate').val());
        $('#NewItemCVDAmount').val($(e).parent().parent().find('.TblItemCVDAmount').val());

        $('#HiddenNewAdditionalNotification1').val($(e).parent().parent().find('.TblAdditionalNotification1').val());
        $('#NewAdditionalNotification1').val($(e).parent().parent().find('.TblAdditionalNotification1').val());
        $('#NewAdditionalNotification1SrNo').val($(e).parent().parent().find('.TblAdditionalNotification1SrNo').val());
        $('#NewAdditionalNotification1Rate').val($(e).parent().parent().find('.TblAdditionalNotification1Rate').val());
        $('#NewAdditionalNotification1Amount').val($(e).parent().parent().find('.TblAdditionalNotification1Amount').val());

        $('#HiddenNewAdditionalNotification2').val($(e).parent().parent().find('.TblAdditionalNotification2').val());
        $('#NewAdditionalNotification2').val($(e).parent().parent().find('.TblAdditionalNotification2').val());
        $('#NewAdditionalNotification2SrNo').val($(e).parent().parent().find('.TblAdditionalNotification2SrNo').val());
        $('#NewAdditionalNotification2Rate').val($(e).parent().parent().find('.TblAdditionalNotification2Rate').val());
        $('#NewAdditionalNotification2Amount').val($(e).parent().parent().find('.TblAdditionalNotification2Amount').val());

        $('#HiddenNewOtherNotification').val($(e).parent().parent().find('.TblOtherNotification').val());
        $('#NewOtherNotification').val($(e).parent().parent().find('.TblOtherNotification').val());
        $('#NewOtherNotificationSrNo').val($(e).parent().parent().find('.TblOtherNotificationSrNo').val());
        $('#NewOtherNotificationRate').val($(e).parent().parent().find('.TblOtherNotificationRate').val());
        $('#NewOtherNotificationAmount').val($(e).parent().parent().find('.TblOtherNotificationAmount').val());

        $('#NewSocialWelfareNotification').val($(e).parent().parent().find('.TblSocialWelfareNotification').val());
        $('#NewSocialWelfareNotificationSrNo').val($(e).parent().parent().find('.TblSocialWelfareNotificationSrNo').val());
        $('#NewSocialWelfareRate').val($(e).parent().parent().find('.TblSocialWelfareRate').val());
        $('#NewSocialWelfareAmount').val($(e).parent().parent().find('.TblSocialWelfareAmount').val());

        $('#NewNCDNotification').val($(e).parent().parent().find('.TblNCDNotification').val());
        $('#NewNCDNotificationSrNo').val($(e).parent().parent().find('.TblNCDNotificationSrNo').val());
        $('#NewNCDNotificationRate').val($(e).parent().parent().find('.TblNCDNotificationRate').val());
        $('#NewNCDNotificationAmount').val($(e).parent().parent().find('.TblNCDNotificationAmount').val());

        $('#NewAntiDumpingDutyNotification').val($(e).parent().parent().find('.TblAntiDumpingDutyNotification').val());
        $('#NewAntiDumpingDutyNotificationSrNo').val($(e).parent().parent().find('.TblAntiDumpingDutyNotificationSrNo').val());
        $('#NewAntiDumpingDutyNotificationRate').val($(e).parent().parent().find('.TblAntiDumpingDutyNotificationRate').val());
        $('#NewAntiDumpingDutyNotificationAmount').val($(e).parent().parent().find('.TblAntiDumpingDutyNotificationAmount').val());

        $('#NewHealthNotification').val($(e).parent().parent().find('.TblHealthNotification').val());
        $('#NewHealthNotificationSrNo').val($(e).parent().parent().find('.TblHealthNotificationSrNo').val());
        $('#NewHealthNotificationRate').val($(e).parent().parent().find('.TblHealthNotificationRate').val());
        $('#NewHealthNotificationAmount').val($(e).parent().parent().find('.TblHealthNotificationAmount').val());

        $('#NewAdditionalCVDNotification').val($(e).parent().parent().find('.TblAdditionalCVDNotification').val());
        $('#NewAdditionalCVDNotificationSrNo').val($(e).parent().parent().find('.TblAdditionalCVDNotificationSrNo').val());
        $('#NewAdditionalCVDNotificationRate').val($(e).parent().parent().find('.TblAdditionalCVDNotificationRate').val());
        $('#NewAdditionalCVDNotificationAmount').val($(e).parent().parent().find('.TblAdditionalCVDNotificationAmount').val());

        $('#NewAggregateDutyNotification').val($(e).parent().parent().find('.TblAggregateDutyNotification').val());
        $('#NewAggregateDutyNotificationSrNo').val($(e).parent().parent().find('.TblAggregateDutyNotificationSrNo').val());
        $('#NewAggregateDutyNotificationRate').val($(e).parent().parent().find('.TblAggregateDutyNotificationRate').val());
        $('#NewAggregateDutyNotificationAmount').val($(e).parent().parent().find('.TblAggregateDutyNotificationAmount').val());

        $('#NewSafeguardDutyNotification').val($(e).parent().parent().find('.TblSafeguardDutyNotification').val());
        $('#NewSafeguardDutyNotificationSrNo').val($(e).parent().parent().find('.TblSafeguardDutyNotificationSrNo').val());
        $('#NewSafeguardDutyNotificationRate').val($(e).parent().parent().find('.TblSafeguardDutyNotificationRate').val());
        $('#NewSafeguardDutyNotificationAmount').val($(e).parent().parent().find('.TblSafeguardDutyNotificationAmount').val());

        $('#HiddenNewIGSTNotification').val($(e).parent().parent().find('.TblIGSTNotification').val());
        $('#NewIGSTNotification').val($(e).parent().parent().find('.TblIGSTNotification').val());
        $('#NewIGSTNotificationSrNo').val($(e).parent().parent().find('.TblIGSTNotificationSrNo').val());
        $('#NewIGSTNotificationRate').val($(e).parent().parent().find('.TblIGSTNotificationRate').val());
        $('#NewIGSTNotificationAmount').val($(e).parent().parent().find('.TblIGSTNotificationAmount').val());

        $('#HiddenNewIGSTExemNotification').val($(e).parent().parent().find('.TblIGSTExemNotification').val());
        $('#NewIGSTExemNotification').val($(e).parent().parent().find('.TblIGSTExemNotification').val());
        $('#NewIGSTExemNotificationSrNo').val($(e).parent().parent().find('.TblIGSTExemNotificationSrNo').val());
        $('#NewIGSTExemNotificationRate').val($(e).parent().parent().find('.TblIGSTExemNotificationRate').val());
        $('#NewIGSTExemNotificationAmount').val($(e).parent().parent().find('.TblIGSTExemNotificationAmount').val());

        $('#HiddenNewIGSTComCessNotification').val($(e).parent().parent().find('.TblIGSTComCessNotification').val());
        $('#NewIGSTComCessNotification').val($(e).parent().parent().find('.TblIGSTComCessNotification').val());
        $('#NewIGSTComCessNotificationSrNo').val($(e).parent().parent().find('.TblIGSTComCessNotificationSrNo').val());
        $('#NewIGSTComCessNotificationRate').val($(e).parent().parent().find('.TblIGSTComCessNotificationRate').val());
        $('#NewIGSTComCessNotificationAmount').val($(e).parent().parent().find('.TblIGSTComCessNotificationAmount').val());

        $('#HiddenNewIGSTComCessExemNotification').val($(e).parent().parent().find('.TblIGSTComCessExemNotification').val());
        $('#NewIGSTComCessExemNotification').val($(e).parent().parent().find('.TblIGSTComCessExemNotification').val());
        $('#NewIGSTComCessExemNotificationSrNo').val($(e).parent().parent().find('.TblIGSTComCessExemNotificationSrNo').val());
        $('#NewIGSTComCessExemNotificationRate').val($(e).parent().parent().find('.TblIGSTComCessExemNotificationRate').val());
        $('#NewIGSTComCessExemNotificationAmount').val($(e).parent().parent().find('.TblIGSTComCessExemNotificationAmount').val());

        //MANUFACTURER / PRODUCER DETAILS

        $('#HiddenNewItemManufacturerProducerGrowerName').val($(e).parent().parent().find('.HiddenTblItemManufacturerProducerGrowerName').val());
        $('#NewItemManufacturerProducerGrowerName').val($(e).parent().parent().find('.TblItemManufacturerProducerGrowerName').val()).trigger('blur');
        $('#NewItemManufacturerProducerCodeType').val($(e).parent().parent().find('.TblItemManufacturerProducerCodeType').val());
        $('#NewItemManufacturerProducerGrowerCode').val($(e).parent().parent().find('.TblItemManufacturerProducerGrowerCode').val());
        $('#NewItemManufacturerProducerGrowerAddress1').val($(e).parent().parent().find('.TblItemManufacturerProducerGrowerAddress1').val());
        $('#NewItemManufacturerProducerGrowerAddress2').val($(e).parent().parent().find('.TblItemManufacturerProducerGrowerAddress2').val());
        $('#NewItemManufacturerProducerGrowerCity').val($(e).parent().parent().find('.TblItemManufacturerProducerGrowerCity').val());
        $('#NewItemManufacturerProducerGrowerCountrySubDivision').val($(e).parent().parent().find('.TblItemManufacturerProducerGrowerCountrySubDivision').val());
        $('#NewItemManufacturerProducerGrowerPin').val($(e).parent().parent().find('.TblItemManufacturerProducerGrowerPin').val());
        $('#HiddenNewItemManufacturerCountry').val($(e).parent().parent().find('.HiddenTblItemManufacturerCountry').val());
        $('#NewItemManufacturerCountryName').val($(e).parent().parent().find('.TblItemManufacturerCountryName').val());
        $('#HiddenNewSourceCountry').val($(e).parent().parent().find('.HiddenTblSourceCountryName').val());
        $('#NewSourceCountryName').val($(e).parent().parent().find('.TblSourceCountryName').val());
        $('#HiddenNewTransitCountry').val($(e).parent().parent().find('.HiddenTblTransitCountry').val());
        $('#NewTransitCountryName').val($(e).parent().parent().find('.TblTransitCountryName').val());

        //OTHER DETAILS

        $('#NewItemBrandName').val($(e).parent().parent().find('.TblItemBrandName').val());
        $('#NewItemModel').val($(e).parent().parent().find('.TblItemModel').val());
        $('#NewPreferentialStandard').val($(e).parent().parent().find('.TblPreferentialStandard').val());
        $('#NewRSPApplicability').val($(e).parent().parent().find('.TblRSPApplicability').val());
        $('#NewCTHSerialNumber').val($(e).parent().parent().find('.TblCTHSerialNumber').val());
        $('#NewSupplierSerialNumber').val($(e).parent().parent().find('.TblSupplierSerialNumber').val());
        $('#NewQuantityAsPerAntiDumpingNotification').val($(e).parent().parent().find('.TblQuantityAsPerAntiDumpingNotification').val());
        $('#NewTarrifValueNotification').val($(e).parent().parent().find('.TblTarrifValueNotification').val());
        $('#NewTarrifValueItemSrNo').val($(e).parent().parent().find('.TblTarrifValueItemSrNo').val());
        $('#NewQuantityAsPerTarrifValueNotification').val($(e).parent().parent().find('.TblQuantityAsPerTarrifValueNotification').val());
        $('#NewSAPTANotification').val($(e).parent().parent().find('.TblSAPTANotification').val());
        $('#NewSAPTANotificationSrNo').val($(e).parent().parent().find('.TblSAPTANotificationSrNo').val());
        $('#NewQtyAsPerCTH').val($(e).parent().parent().find('.TblQtyAsPerCTH').val());
        $('#NewQuantityAsPerCTH').val($(e).parent().parent().find('.TblQuantityAsPerCTH').val());
        $('#NewPolicyParaNo').val($(e).parent().parent().find('.TblPolicyParaNo').val());
        $('#NewPolicyYear').val($(e).parent().parent().find('.TblPolicyYear').val());
        $('#NewPreviousBENo').val($(e).parent().parent().find('.TblPreviousBENo').val());
        $('#NewPreviousBEDate').val($(e).parent().parent().find('.TblPreviousBEDate').val());
        $('#NewPreviousUnitPrice').val($(e).parent().parent().find('.TblPreviousUnitPrice').val());
        $('#HiddenNewPreviousCurrencyCode').val($(e).parent().parent().find('.HiddenTblPreviousCurrencyCode').val());
        $('#NewPreviousCurrency').val($(e).parent().parent().find('.TblPreviousCurrency').val());
        $('#HiddenNewPreviousCustomSite').val($(e).parent().parent().find('.HiddenTblPreviousCustomSite').val());
        $('#NewPreviousCustomSiteName').val($(e).parent().parent().find('.TblPreviousCustomSiteName').val());
        $('#NewCustomNotnExemptingCentralExciseFlag').val($(e).parent().parent().find('.TblCustomNotnExemptingCentralExciseFlag').val());
        $('#NewAccessoryStatus').val($(e).parent().parent().find('.TblAccessoryStatus').val());
        $('#NewItemAccessoriesOfItem').val($(e).parent().parent().find('.TblItemAccessoriesOfItem').val());

    }
}

//NEWRESETRESETITEM BUTTON CLICK EVENT
$('#NewResetItem').click(function () {
    ResetNewItem(true);
});

//FUNCTION FOR NEW RESET ITEM
function ResetNewItem(flag) {
    const blankItemId = ['HiddenNewItemName', 'NewItemName', 'NewItemDescription', 'NewItemGenericDescription', 'HiddenNewItemEndUse', 'NewItemEndUse', 'NewItemEndUseDesc', 'HiddenNewItemCountryOrigin', 'NewItemCountryOrigin', 'HiddenNewUnitQuantityCode', 'NewUnitQuantityCode', 'HiddenNewRITCCode', 'NewRITCCode', 'HiddenNewItemCTH', 'NewItemCTH', 'HiddenNewItemCTEH', 'NewItemCTEH', 'HiddenNewItemBCDNotification', 'NewItemBCDNotification', 'NewItemBCDNotificationSrNo', 'NewItemCVDNotification', 'NewItemCVDNotificationSrNo', 'NewAdditionalNotification1', 'NewAdditionalNotification1SrNo', 'NewOtherNotification', 'NewOtherNotificationSrNo', 'NewSocialWelfareNotification', 'NewSocialWelfareNotificationSrNo', 'NewNCDNotification', 'NewNCDNotificationSrNo', 'NewAntiDumpingDutyNotification', 'NewAntiDumpingDutyNotificationSrNo', 'NewCTHSerialNumber', 'NewSupplierSerialNumber', 'NewTarrifValueNotification', 'NewTarrifValueItemSrNo', 'NewSAPTANotification', 'NewSAPTANotificationSrNo', 'NewHealthNotification', 'NewHealthNotificationSrNo', 'NewAdditionalCVDNotification', 'NewAdditionalCVDNotificationSrNo', 'NewAggregateDutyNotification', 'NewAggregateDutyNotificationSrNo', 'NewSafeguardDutyNotification', 'NewSafeguardDutyNotificationSrNo', 'HiddenNewIGSTNotification', 'NewIGSTNotification', 'HiddenNewIGSTNotificationSrNo', 'NewIGSTNotificationSrNo', 'HiddenNewIGSTExemNotification', 'NewIGSTExemNotification', 'HiddenNewIGSTComCessNotification', 'NewIGSTComCessNotification', 'HiddenNewIGSTComCessExemNotification', 'NewIGSTComCessExemNotification', 'NewPolicyParaNo', 'NewPolicyYear', 'NewPreviousBENo', 'NewPreviousCurrencyCode', 'NewPreviousCurrency', 'HiddenNewPreviousCustomSite', 'NewPreviousCustomSiteName', 'NewItemAccessoriesOfItem', 'NewPreviousBEDate', 'HiddenNewDEPBNotification', 'NewDEPBNotification', 'HiddenNewDEPBNotificationSrNo', 'NewDEPBNotificationSrNo', 'HiddenNewSQCUnitCode', 'NewSQCUnitCode'];

    blankItemId.forEach((ele) => {
        $('#' + ele).val('');
    });

    const zeroItemId = ['NewItemAmount', 'NewItemFreight', 'NewItemInsurance', 'NewItemMiscCharge', 'NewItemLoading', 'NewHSSLoadAmount', 'NewItemCIFValue', 'NewItemBCDRate', 'NewItemBCDAmount', 'NewItemCVDRate', , 'NewItemCVDAmount', 'NewAdditionalNotification1Rate', 'NewAdditionalNotification1Amount', 'NewAdditionalNotification2', 'NewAdditionalNotification2SrNo', 'NewAdditionalNotification2Rate', 'NewAdditionalNotification2Amount', 'NewOtherNotificationRate', 'NewOtherNotificationAmount', 'NewSocialWelfareAmount', 'NewNCDNotificationRate', 'NewNCDNotificationAmount', 'NewAntiDumpingDutyNotificationRate', 'NewAntiDumpingDutyNotificationAmount', 'NewQuantityAsPerAntiDumpingNotification', 'NewHealthNotificationRate', 'NewHealthNotificationAmount', 'NewAdditionalCVDNotificationRate', 'NewAdditionalCVDNotificationAmount', 'NewAggregateDutyNotificationRate', 'NewAggregateDutyNotificationAmount', 'NewSafeguardDutyNotificationRate', 'NewSafeguardDutyNotificationAmount', 'NewIGSTNotificationRate', 'NewIGSTNotificationAmount', 'NewIGSTExemNotificationRate', 'NewIGSTExemNotificationAmount', 'NewIGSTComCessNotificationRate', 'NewIGSTComCessNotificationAmount', 'NewIGSTComCessExemNotificationRate', 'NewIGSTComCessExemNotificationAmount', 'NewQtyAsPerCTH', 'NewQuantityAsPerCTH', 'NewQuantityAsPerTarrifValueNotification', 'NewPreviousUnitPrice', 'NewItemDutyAmount'];

    zeroItemId.forEach((ele) => {
        $('#' + ele).val('0.00');
    });

    $('.ItemDe').html('');
    $('#NewRowNumItem').val('');
    $('#NewItemInvoiceNo').val(0);
    $('#NewItemMasterTariff').val('TARIFF');
    if ($('#NewItemName').hasClass('ui-autocomplete-input'))
        $('#NewItemName').autocomplete('destroy');
    $('#NewItemName').removeAttr('onkeypress').removeClass('ui-autocomplete-input');
    $('#NewRSPApplicability').val('N');
    $('#NewReImport').val('N');
    $('#NewItemBrandName').val('NA');
    $('#NewItemModel').val('NA');
    $('#NewItemQuantity,#NewItemUnitPrice,#NewSQCQuantity').val('0.000000');
    $('#HiddenLicCheck').val('false');
    $('#NewItemMode').val('0');
    $('#NewItemCategorySchemeCode').val('0');
    $('#NewExempted').val('No');
    $('#NewSocialWelfareRate').val('10.00');
    $('#NewAccessoryStatus').val('0');
    $('#NewPreferentialStandard').val('P');

    $('#NewAddItem').removeClass('d-none');
    $('#NewUpdateItem').addClass('d-none');


    ActiveItemMainTab();
    if (flag)
        $('#NewItemInvoiceNo').focus();
}

//FUNCTION FOR RESET ITEM MANUFACTURER DETAILS
function ResetNewItemManufactureDetails() {
    $('#HiddenNewItemManufacturerProducerGrowerName,#NewItemManufacturerProducerGrowerName,#NewItemManufacturerProducerCodeType').val('');
    $('#NewItemManufacturerProducerGrowerCode,#NewItemManufacturerProducerGrowerAddress1,#NewItemManufacturerProducerGrowerAddress2').val('');
    $('#NewItemManufacturerProducerGrowerCity,#NewItemManufacturerProducerGrowerCountrySubDivision,#NewItemManufacturerProducerGrowerPin').val('');
    $('#HiddenNewItemManufacturerCountry,#NewItemManufacturerCountryName,#HiddenNewSourceCountry,#NewSourceCountryName').val('');
    $('#HiddenNewTransitCountry,#NewTransitCountryName').val('');
    $('#NewItemManufacturerProducerGrowerAddress').html('');
}

//NEWITEMMODE CHANGE EVENT
$('#NewItemMode').change(function () {
    let ItemModeVal = $('#NewItemMode').val();
    if (ItemModeVal != null && ItemModeVal != undefined && ItemModeVal != '') {
        if (ItemModeVal != 0) {
            const dataString = {};
            dataString.Uid = ItemModeVal;
            AjaxSubmission(JSON.stringify(dataString), "/_Layout/GetItemModeLicense", $('input[name=__RequestVerificationToken]').val()).done(function (data) {
                let obj = data;
                if (obj.status == true) {
                    if (obj.responsecode == '100')
                        $('#HiddenLicCheck').val(obj.data.Table[0].License);
                    else if (obj.responsecode == '604')
                        $('#HiddenLicCheck').val(obj.data.Table[0].License);
                }
                else
                    window.location.href = '/ClientLogin/ClientLogin';

            }).fail(function (result) {
                console.log(result.Message);
            });
        }
    }
});

//FUNCTION FOR FILL ITEM DETAILS IN LICENSE AND DESTUFF TAB
function NewGenerateItemNameList(Type, ItRn) {
    let ItemAr = [];
    let ItemHtml = '';
    $('#TblItemDetails tbody tr').each(function (ind, ele) {
        if ($(this).find('.TblItemName').val().trim().length > 0)
            ItemAr.push($(this).find('.TblItemName').val().trim());
    });

    for (i = 0; i < ItemAr.length; i++) {
        if (ItemHtml == '')
            ItemHtml = '<option value="0">---Select---</option>';
        ItemHtml += '<option value="' + (i + 1) + '">' + (i + 1) + '-' + ItemAr[i] + '</option>';
    }
    $('#NewItemLicense,#NewItemDestuff').html(ItemHtml);

    let ItemLicenceAr = [];
    $('#TblLicenceDetails tbody tr').each(function () {
        ItemLicenceAr.push($(this).find('.TblLicenseItemSr').val());
    });

    let ItemDestuffAr = [];
    $('#TblDestuffDetails tbody tr').each(function () {
        ItemDestuffAr.push($(this).find('.TblDestuffItemSr').val());
    });

    $('#NewJobItem').html('<option value="0">---Select---</option>');

    $(".TblLicenseItemSr,.TblDestuffItemSr").html(ItemHtml);

    if (Type == 'Delete') {
        $('#TblLicenceDetails tbody tr').each(function (ind, ele) {
            if (ItemLicenceAr[ind] == null)
                ItemLicenceAr[ind] = 0;
            else if (ItemLicenceAr[ind] > ItRn) {
                ItemLicenceAr[ind] = ItemLicenceAr[ind] - 1;
            }
            $(ele).find('.TblLicenseItemSr').val(ItemLicenceAr[ind]);
        });

        $('#TblDestuffDetails tbody tr').each(function (ind, ele) {
            if (ItemDestuffAr[ind] == null)
                ItemDestuffAr[ind] = 0;
            else if (ItemDestuffAr[ind] > ItRn) {
                ItemDestuffAr[ind] = ItemDestuffAr[ind] - 1;
            }
            $(ele).find('.TblDestuffItemSr').val(ItemDestuffAr[ind]);
        });


    }
    else {
        $('#TblLicenceDetails tbody tr').each(function (ind, ele) {
            if (ItemLicenceAr[ind] == null || ItemLicenceAr[ind] > ItemAr.length)
                ItemLicenceAr[ind] = 0;
            $(ele).find('.TblLicenseItemSr').val(ItemLicenceAr[ind]);
        });

        $('#TblDestuffDetails tbody tr').each(function (ind, ele) {
            if (ItemDestuffAr[ind] == null || ItemDestuffAr[ind] > ItemAr.length)
                ItemDestuffAr[ind] = 0;
            $(ele).find('.TblDestuffItemSr').val(ItemDestuffAr[ind]);
        });
    }
}

//FUNCTION FOR VALIDATE ITEM DETAILS DATA
function ValidateItemDetailsData() {
    let Vflag = 0;
    $('#TblItemDetails tbody tr').each(function (ind, ele) {
        if ($('#TblItemDetails tbody tr').length == 1) {
            if ($(ele).find('.TblItemName').val().trim().length > 0) {
                if (HandleNullNumericValue($(ele).find('.TblItemAmount').val()) <= 0) {
                    Toast('Please Enter Item Amount', 'Message', 'error');
                    Vflag = 1;
                    return;
                }
                if (HandleNullNumericValue($(ele).find('.TblItemQuantity').val()) <= 0) {
                    Toast('Please Enter Item Quantity', 'Message', 'error');
                    Vflag = 1;
                    return;
                }
            }
        }
        else {
            if (HandleNullNumericValue($(ele).find('.TblItemAmount').val()) <= 0) {
                Toast('Please Enter Item Amount', 'Message', 'error');
                Vflag = 1;
                return;
            }
            if (HandleNullNumericValue($(ele).find('.TblItemQuantity').val()) <= 0) {
                Toast('Please Enter Item Quantity', 'Message', 'error');
                Vflag = 1;
                return;
            }
        }
    });
    return Vflag;
}

//FUNCTION FOR DELETE ITEM ROW WHERE INVOICE NUMBER USE
function DeleteItemRowInvoiceWise(InvNo) {
    $("#TblItemDetails tbody tr").each(function (ItInd, ItEle) {
        if ($(ItEle).find('.TblItemInvoiceNo option:selected').text() == InvNo) {
            let ItRowCount = $('#TblItemDetails tbody tr').length;
            if (ItRowCount > 1)
                $(ItEle).remove();
            else {

                $(ItEle).find('.HiddenTblItemName,.TblItemName,.TblItemDescription,.TblItemGenericDescription,.HiddenTblItemEndUse,.TblItemEndUse,.TblItemEndUseDesc,.HiddenTblItemCountryOrigin,.TblItemCountryOrigin,.HiddenTblUnitQuantityCode,.TblUnitQuantityCode,.TblRITCCode,.TblItemCTH,.TblItemCTEH,.TblItemBCDNotification,.TblItemBCDNotificationSrNo,.TblItemCVDNotification,.TblItemCVDNotificationSrNo,.TblAdditionalNotification1,.TblAdditionalNotification1SrNo,.TblAdditionalNotification2,.TblAdditionalNotification2SrNo,.TblOtherNotification,.TblOtherNotificationSrNo,.TblSocialWelfareNotification,.TblSocialWelfareNotificationSrNo,.TblNCDNotification,.TblNCDNotificationSrNo,.TblAntiDumpingDutyNotification,.TblAntiDumpingDutyNotificationSrNo,.TblHealthNotification,.TblHealthNotificationSrNo,.TblAdditionalCVDNotification,.TblAdditionalCVDNotificationSrNo,.TblAggregateDutyNotification,.TblAggregateDutyNotificationSrNo,.TblSafeguardDutyNotification,.TblSafeguardDutyNotificationSrNo,.TblIGSTNotification,.TblIGSTNotificationSrNo,.TblIGSTExemNotification,.TblIGSTExemNotificationSrNo,.TblIGSTComCessNotification,.TblIGSTComCessNotificationSrNo,.TblIGSTComCessExemNotification,.TblIGSTComCessExemNotificationSrNo,.HiddenTblItemManufacturerProducerGrowerName,.TblItemManufacturerProducerGrowerName,.TblItemManufacturerProducerCodeType,.TblItemManufacturerProducerGrowerCode,.TblItemManufacturerProducerGrowerAddress1,.TblItemManufacturerProducerGrowerAddress2,.TblItemManufacturerProducerGrowerCity,.TblItemManufacturerProducerGrowerCountrySubDivision,.TblItemManufacturerProducerGrowerPin,.HiddenTblItemManufacturerCountry,.TblItemManufacturerCountryName,.HiddenTblSourceCountryName,.TblSourceCountryName,.HiddenTblTransitCountry,.TblTransitCountryName,.TblCTHSerialNumber,.TblSupplierSerialNumber,.TblTarrifValueNotification,.TblTarrifValueItemSrNo,.TblSAPTANotification,.TblSAPTANotificationSrNo,.TblPolicyParaNo,.TblPolicyYear,.TblPreviousBENo,.TblPreviousBEDate,.HiddenTblPreviousCurrencyCode,.TblPreviousCurrency,.HiddenTblPreviousCustomSite,.TblPreviousCustomSiteName,.TblCustomNotnExemptingCentralExciseFlag,.TblItemAccessoriesOfItem').val('');

                $(ItEle).find('.TblItemAmount,.TblItemFreight,.TblItemInsurance,.TblItemMiscCharge,.TblItemLoading,.TblHSSLoadAmount,.TblItemCIFValue,.TblItemDutyAmount,.TblItemDutyGone,.TblItemBCDRate,.TblItemBCDAmount,.TblItemCVDRate,.TblItemCVDAmount,.TblAdditionalNotification1Rate,.TblAdditionalNotification1Amount,.TblAdditionalNotification2Rate,.TblAdditionalNotification2Amount,.TblOtherNotificationRate,.TblOtherNotificationAmount,.TblSocialWelfareRate,.TblSocialWelfareAmount,.TblNCDNotificationRate,.TblNCDNotificationAmount,.TblAntiDumpingDutyNotificationRate,.TblAntiDumpingDutyNotificationAmount,.TblHealthNotificationRate,.TblHealthNotificationAmount,.TblAdditionalCVDNotificationRate,.TblAdditionalCVDNotificationAmount,.TblAggregateDutyNotificationRate,.TblAggregateDutyNotificationAmount,.TblSafeguardDutyNotificationRate,.TblSafeguardDutyNotificationAmount,.TblIGSTNotificationRate,.TblIGSTNotificationAmount,.TblIGSTExemNotificationRate,.TblIGSTExemNotificationAmount,.TblIGSTComCessNotificationRate,.TblIGSTComCessNotificationAmount,.TblIGSTComCessExemNotificationRate,.TblIGSTComCessExemNotificationAmount,.TblQuantityAsPerAntiDumpingNotification,.TblQuantityAsPerTarrifValueNotification,.TblQtyAsPerCTH,.TblQuantityAsPerCTH').val('0.00');


                $(ItEle).find('.TblRSPApplicability').val('N');
                $(ItEle).find('.TblReImport').val('N');
                $(ItEle).find('.TblItemBrandName').val('NA');
                $(ItEle).find('.TblItemModel').val('NA');
                $(ItEle).find('.TblItemQuantity,.TblItemUnitPrice,.TblPreviousUnitPrice').val('0.000000');
                $(ItEle).find('.TblItemCategorySchemeCode').val('0');
                $(ItEle).find('.TblSocialWelfareRate').val('10.00');
                $(ItEle).find('.TblAccessoryStatus').val('0');
                $(ItEle).find('.TblPreferentialStandard').val('P');
            }
        }
    });

    GenerateSerialNumberTable('TblItemDetails', 'rn');
}

//FUNCTION FOR FILL ESANCHIT DETAILS 
function FillESanchitDetails(e) {
    if ($(e).parent().parent().find('.TblNewItemFileNameType').val() == 'AUTO') {
        if ($(e).parent().parent().find('.HiddenTblNewItemFileName').val().trim().length > 0) {
            $(e).parent().parent().find('.TblNewItemIceGate').val(0);
            $(e).parent().parent().find('.TblItemNewImageReferenceNo,.HiddenTblNewItemDocumentTypeCode,.TblNewItemDocumentTypeCode,.TblNewItemUploadDateTime,.TblNewItemDocumentIssueDate,.TblNewItemDocumentExpiryDate,.TblNewItemDocumentIssuingPartyCode,.TblNewItemDocumentBeneficiaryPartyCode ').val('');

            try {
                const dataString = {};
                dataString.ESanchitDocumentUid = parseInt($(e).parent().parent().find('.HiddenTblNewItemFileName').val().trim());

                AjaxSubmission(JSON.stringify(dataString), '/Master/_Layout/GetESanchitDetails', $('input[name=__RequestVerificationToken]').val()).done(function (result) {
                    let obj = result.data.Table[0];
                    if (result.status == true) {
                        if (result.responsecode == '100') {
                            $(e).parent().parent().find('.TblNewItemIceGate').val(obj.ICEGATEUserId);
                            $(e).parent().parent().find('.TblItemNewImageReferenceNo').val(obj.ImageReferenceNo);
                            /* $(e).parent().parent().find('.TblItemNewDocumentReferenceNo').val(obj.DocumentReferenceNo);*/
                            $(e).parent().parent().find('.HiddenTblNewItemDocumentTypeCode').val(obj.DocumentTypeCode);
                            $(e).parent().parent().find('.TblNewItemDocumentTypeCode').val(obj.DocumentTypeCodeDescriptions);
                            $(e).parent().parent().find('.TblNewItemFileType').val(obj.FileType);
                            $(e).parent().parent().find('.TblNewItemUploadDateTime').val(obj.UploadDateTime);
                            /*$(e).parent().parent().find('.TblNewItemPlaceOfIssue').val(obj.PlaceOfIssue);*/
                            $(e).parent().parent().find('.TblNewItemDocumentIssueDate').val(obj.DocumentIssueDate);
                            $(e).parent().parent().find('.TblNewItemDocumentExpiryDate').val(obj.DocumentExpiryDate);
                            //$(e).parent().parent().find(".HiddenTblNewItemDocumentIssuingParty").val(obj.DocumentIssuingParty);
                            //$(e).parent().parent().find('.TblNewItemDocumentIssuingPartyName').val(obj.IName);
                            $(e).parent().parent().find('.TblNewItemDocumentIssuingPartyCode').val(obj.DocumentIssuingPartyCode);
                            //$(e).parent().parent().find('.HiddenTblNewItemDocumentBeneficiaryParty').val(obj.DocumentBeneficiaryParty);
                            //$(e).parent().parent().find('.TblNewItemDocumentBeneficiaryPartyName ').val(obj.BName);
                            $(e).parent().parent().find('.TblNewItemDocumentBeneficiaryPartyCode ').val(obj.DocumentBeneficiaryPartyCode);
                        }
                    } else
                        window.location.href = '/ClientLogin/ClientLogin';
                }).fail(function (result) {
                    console.log(result.Message);
                });

            }
            catch (e) {
                console.log(e.message);
            }

        }
    }
}

//ADDITEMESANCHITROW BUTTON CLICK EVENT
$('#AddItemESanchitRow').click(function () {
    let flag = 0;

    if (flag == 0) {
        let tbody = $('#TblItemESanchit').find('tbody');
        let firstTr = $(tbody).find('tr:first');

        firstTr.find('.TblNewItemUploadDateTime ').datetimepicker('destroy').removeAttr('id');
        firstTr.find('.TblNewItemDocumentIssueDate,.TblNewItemDocumentExpiryDate').datepicker('destroy').removeAttr('id');

        let newRow = $(firstTr).clone();
        /* newRow.find('.TblNewItemPlaceOfIssue,.HiddenTblNewItemDocumentIssuingParty,.TblNewItemDocumentIssuingPartyName,.HiddenTblNewItemDocumentBeneficiaryParty,.TblNewItemDocumentBeneficiaryPartyName').val('');*/
        newRow.find('.HiddenTblNewItemFileName,.TblNewItemFileName,.TblItemNewImageReferenceNo,.TblNewItemDocumentTypeCode,.TblNewItemUploadDateTime,.TblNewItemDocumentIssueDate,.TblNewItemDocumentExpiryDate,.TblNewItemDocumentIssuingPartyCode,.TblNewItemDocumentBeneficiaryPartyCode').val('');

        newRow.find('.TblNewItemESanchitLevel ').val('JOB');
        newRow.find('.TblNewItemIceGate').val(0);
        $('#TblItemESanchit').append(newRow);

        $(".dateTimepickerAll").datetimepicker({
            format: "d/m/Y H:i",
        });

        $(".datepickerAll").datepicker({
            toolbarPlacement: "bottom",
            showButtonPanel: true,
            changeMonth: true,
            changeYear: true,
            dateFormat: 'dd/mm/yy',
        });
    }
    else {
        Toast('Please Fill All Details.', 'Message', 'error');
    }

    GenerateSerialNumberTable('TblItemESanchit', 'rn')

});

// FUNCTION FOR DELETE ITEM ESANCHIT ROW 
function DeleteRemoveItemESanchitRowEntry(e) {

    let ImgRefNo = $(e).parent().parent().find('.TblItemNewImageReferenceNo ').val();
    if (ImgRefNo == null || ImgRefNo == undefined || ImgRefNo == '' || ImgRefNo.length == 0)
        Toast('Invalid Document.', 'Message', 'error');
    else {
        $.confirm({
            title: '',
            content: 'Are You Sure Want To Delete ?',
            type: 'red',
            boxWidth: '300px',
            useBootstrap: false,
            typeAnimated: true,
            columnClass: 'small',
            containerFluid: true,
            draggable: true,
            buttons: {
                tryAgain: {
                    text: 'Confirm',
                    btnClass: 'btn-red',
                    action: function () {
                        let uniqueItemSr = $('#RownNumItem').val() + ($(e).parent().parent().find('.rn').text().trim() - 1);

                        let rowCount = $('#TblItemESanchit tbody tr').length;

                        //DELETE FROM TABLE ITEM ESANCHIT
                        if (rowCount > 1)
                            $(e).parent().parent().remove();
                        else {
                            $(e).parent().parent().find('.HiddenTblNewItemFileName,.TblNewItemFileName,.TblItemNewImageReferenceNo,.TblNewItemDocumentTypeCode,.TblNewItemUploadDateTime,.TblNewItemPlaceOfIssue,.TblNewItemDocumentIssueDate,.TblNewItemDocumentExpiryDate,.HiddenTblNewItemDocumentIssuingParty,.TblNewItemDocumentIssuingPartyName,.TblNewItemDocumentIssuingPartyCode,.TblNewItemDocumentBeneficiaryPartyName,.TblNewItemDocumentBeneficiaryPartyCode').val('');
                            $(e).parent().parent().find('.TblNewItemESanchitLevel ').val('JOB');
                            $(e).parent().parent().find('.TblNewItemIceGate').val(0);

                        }

                        //DELETE FROM TABLE SUPPORT DOCS
                        $('#TblJobSupportDocs tbody tr').each(function () {

                            if ($(this).find('.TblUniqueItemSrNo').val()[0] == $('#RownNumItem').val()) {

                                if ($('#TblJobSupportDocs tbody tr').length > 1)
                                    $(this).remove();
                                else {
                                    $(this).find('.TblUniqueItemSrNo,.TblFileName,.TblInvoiceSrNo,.TblItemSrNo,.TblImgRefNo,.HiddenTblDocType,.TblDocType,.TblDocUploadDate,.TblPlaceOfIssue,.TblDocIssueDate,.TblDocExpiryDate,.HiddenTblDocIssueParty,.TblDocIssuingParty,.TblDocIssuingPartyCode,.HiddenTblDocBeneficiaryParty,.TblDocBeneficiaryParty,.TblDocBeneficiaryPartyCode').val('');
                                    $(this).find('.TblDocLevel').val('JOB');
                                    $(this).find('.TblIceGate').val(0);
                                }
                            }

                        });

                        GenerateSerialNumberTable('TblItemESanchit', 'rn');
                        GenerateSerialNumberTable('TblJobSupportDocs', 'rn');
                    }
                },
                close: function () {
                }
            }
        });
    }
}

//FUNCTION FOR DELETE ESANCHIT ROW ITEM WISE
function DeleteESanchitRowItemWise(SrNoAr) {
    SrNoAr.forEach(function (val) {
        $('#TblJobSupportDocs tbody tr').each(function (ind, ele) {
            let EsRowCount = $('#TblJobSupportDocs tbody tr').length;
            let EsItSr = $(ele).find('.TblItemSrNo').val();
            if (EsRowCount == 1) {
                if (EsItSr != null && EsItSr != undefined && EsItSr != 0 && EsItSr != '') {
                    if (EsItSr == val) {
                        $(ele).find('.TblFileName,.TblInvoiceSrNo,.TblItemSrNo,.TblImgRefNo,.HiddenTblDocType,.TblDocType,.TblDocUploadDate,.TblPlaceOfIssue,.TblDocIssueDate,.TblDocExpiryDate,.HiddenTblDocIssueParty,.TblDocIssuingParty,.TblDocIssuingPartyCode,.HiddenTblDocBeneficiaryParty,.TblDocBeneficiaryParty,.TblDocBeneficiaryPartyCode').val('');
                        $(ele).find('.TblDocLevel').val('JOB');
                        $(ele).find('.TblIceGate').val(0);
                    }
                }
            }
            else {
                if (EsItSr != null && EsItSr != undefined && EsItSr != 0 && EsItSr != '') {
                    if (EsItSr == val) {
                        $(ele).remove();
                    }
                }
            }
        });
    });
    GenerateSerialNumberTable('TblJobSupportDocs', 'rn')
}

//FUNCTION FOR CLOSE ITEM ESANCHIT MODAL
function CloseItemESanchitModal() {
    SaveIndividualItemESanchit($('#RowNumInvoice').val(), $('#RownNumItem').val());
    ItemESanchitModal.style.display = 'none';
}

//FUNCTION FOR SAVE INDIVIDUAL ITEM ESANCHIT IN TBLJOBSUPPORTDOCS
function SaveIndividualItemESanchit(invoiceSr, itemSr) {

    let uniqueItemSr = '';
    let TblLen = $("#TblJobSupportDocs tbody tr").length;
    let tbody = $("#TblJobSupportDocs").find("tbody");
    let firstTr = $(tbody).find("tr:first");
    let eSanchitt = '';
    let allRecord = new Array();

    $('#TblJobSupportDocs tbody tr').each(function () {
        allRecord.push($(this).find('.TblUniqueItemSrNo').val());
    });

    console.log(allRecord);

    $('#TblItemESanchit tbody tr').each(function (indItem, eleItem) {
        if ($(eleItem).find('.TblNewItemFileName ').val().trim().length > 0 &&
            $(eleItem).find('.TblNewItemIceGate').val().length > 0 &&
            $(eleItem).find('.TblItemNewImageReferenceNo').val().trim().length > 0 &&
            $(eleItem).find('.HiddenTblNewItemDocumentTypeCode').val().trim().length > 0 &&
            $(eleItem).find('.TblNewItemDocumentTypeCode').val().trim().length > 0) {

            uniqueItemSr = itemSr + indItem;

            let invSr = $(eleItem).find('.TblNewItemESanchitLevel').val() == 'JOB' ? 0 : invoiceSr;
            let itSr = $(eleItem).find('.TblNewItemESanchitLevel').val() == 'JOB' || $(eleItem).find('.TblNewItemESanchitLevel').val() == 'INVOICE' ? 0 : itemSr;

            let flag = 0;
            allRecord.forEach(function (value, index) {
                if (value == uniqueItemSr) {
                    eSanchitt = $(`#TblJobSupportDocs tbody tr:eq(${index})`);
                    flag = 1;
                    return;
                }
            });

            if (flag == 1) {
                addESanchitData();
            } else {
                if (TblLen == 1 && $('#TblJobSupportDocs tbody tr').find('.TblImgRefNo').val().trim().length == 0) {
                    eSanchitt = $(`#TblJobSupportDocs tbody tr:eq(0)`);
                    addESanchitData();
                }
                else {
                    eSanchitt = $(firstTr).clone();
                    addESanchitData();
                    $("#TblJobSupportDocs").append(eSanchitt);
                }
            }
            function addESanchitData() {
                eSanchitt.find('.TblUniqueItemSrNo').val(uniqueItemSr);
                eSanchitt.find('.TblFileName').val($(eleItem).find('.TblNewItemFileName').val().trim());
                eSanchitt.find('.TblDocLevel').val($(eleItem).find('.TblNewItemESanchitLevel').val());
                eSanchitt.find('.TblInvoiceSrNo').val(invSr);
                eSanchitt.find('.TblItemSrNo').val(itSr);
                eSanchitt.find('.TblIceGate').val($(eleItem).find('.TblNewItemIceGate').val());
                eSanchitt.find('.TblImgRefNo').val($(eleItem).find('.TblItemNewImageReferenceNo').val());
                /* eSanchitt.find('.TblDocRefNo').val($(eleItem).find('.TblItemNewDocumentReferenceNo').val());*/
                eSanchitt.find('.HiddenTblDocType').val($(eleItem).find('.HiddenTblNewItemDocumentTypeCode').val());
                eSanchitt.find('.TblDocType').val($(eleItem).find('.TblNewItemDocumentTypeCode').val());
                eSanchitt.find('.TblFileType').val($(eleItem).find('.TblNewItemFileType').val());
                eSanchitt.find('.TblDocUploadDate').val($(eleItem).find('.TblNewItemUploadDateTime').val());
                eSanchitt.find('.TblPlaceOfIssue').val($(eleItem).find('.TblNewItemPlaceOfIssue').val());
                eSanchitt.find('.TblDocIssueDate').val($(eleItem).find('.TblNewItemDocumentIssueDate').val());
                eSanchitt.find('.TblDocExpiryDate').val($(eleItem).find('.TblNewItemDocumentExpiryDate').val());
                eSanchitt.find('.HiddenTblDocIssuingParty').val($(eleItem).find('.HiddenTblNewItemDocumentIssuingParty').val());
                eSanchitt.find('.TblDocIssuingParty').val($(eleItem).find('.TblNewItemDocumentIssuingPartyName').val());
                eSanchitt.find('.TblDocIssuingPartyCode').val($(eleItem).find('.TblNewItemDocumentIssuingPartyCode').val());
                eSanchitt.find('.HiddenTblDocBeneficiaryParty').val($(eleItem).find('.HiddenTblNewItemDocumentBeneficiaryParty').val());
                eSanchitt.find('.TblDocBeneficiaryParty').val($(eleItem).find('.TblNewItemDocumentBeneficiaryPartyName').val());
                eSanchitt.find('.TblDocBeneficiaryPartyCode').val($(eleItem).find('.TblNewItemDocumentBeneficiaryPartyCode').val());
            }
        }
    });

    $("#TblItemESanchit tbody").find("tr:gt(0)").remove();

    $('#TblItemESanchit tbody tr').find('.HiddenTblNewItemFileName,.TblNewItemFileName,.TblItemNewImageReferenceNo,.TblNewItemDocumentTypeCode,.TblNewItemUploadDateTime,.TblNewItemPlaceOfIssue,.TblNewItemDocumentIssueDate,.TblNewItemDocumentExpiryDate,.HiddenTblNewItemDocumentIssuingParty,.TblNewItemDocumentIssuingPartyName,.TblNewItemDocumentIssuingPartyCode,.TblNewItemDocumentBeneficiaryPartyName,.TblNewItemDocumentBeneficiaryPartyCode').val('');
    $('#TblItemESanchit tbody tr').find('.TblNewItemESanchitLevel ').val('JOB');
    $('#TblItemESanchit tbody tr').find('.TblNewItemIceGate').val(0);

    $('#RowNumInvoice,#RownNumItem').val('');

    GenerateSerialNumberTable('TblItemESanchit', 'rn');
    GenerateSerialNumberTable('TblJobSupportDocs', 'rn');
}

//FUNCTION FOR GET ALL DATA FROM ESANCHIT
function GetAllDataFromESanchit(rowVal) {
    let tbody = $("#TblItemESanchit").find("tbody");
    let firstTr = $(tbody).find("tr:first");
    let itemESanchit = '';

    $('#TblJobSupportDocs tbody tr').each(function (ind, ele) {

        if ($(this).find('.TblUniqueItemSrNo').val()[0] == rowVal) {
            if ($("#TblItemESanchit tbody tr").length == 1 && $('#TblItemESanchit tbody tr').find('.TblItemNewImageReferenceNo').val().trim().length == 0) {
                itemESanchit = firstTr;
                getData();

            } else {
                firstTr.find('.TblNewItemUploadDateTime ').datetimepicker('destroy').removeAttr('id');
                firstTr.find('.TblNewItemDocumentIssueDate,.TblNewItemDocumentExpiryDate').datepicker('destroy').removeAttr('id');

                itemESanchit = $(firstTr).clone();
                getData();
                $('#TblItemESanchit').append(itemESanchit);

                $(".dateTimepickerAll").datetimepicker({
                    format: "d/m/Y H:i",
                });

                $(".datepickerAll").datepicker({
                    toolbarPlacement: "bottom",
                    showButtonPanel: true,
                    changeMonth: true,
                    changeYear: true,
                    dateFormat: 'dd/mm/yy',
                });
            }
        }

        function getData() {
            itemESanchit.find('.TblNewItemFileName').val($(ele).find('.TblFileName').val().trim());
            itemESanchit.find('.TblNewItemESanchitLevel').val($(ele).find('.TblDocLevel').val());
            itemESanchit.find('.TblNewItemIceGate').val($(ele).find('.TblIceGate').val());
            itemESanchit.find('.TblItemNewImageReferenceNo').val($(ele).find('.TblImgRefNo').val());
            /*itemESanchit.find('.TblItemNewDocumentReferenceNo').val($(ele).find('.TblDocRefNo').val());*/
            itemESanchit.find('.HiddenTblNewItemDocumentTypeCode').val($(ele).find('.HiddenTblDocType').val());
            itemESanchit.find('.TblNewItemDocumentTypeCode').val($(ele).find('.TblDocType').val());
            itemESanchit.find('.TblNewItemFileType').val($(ele).find('.TblFileType').val());
            itemESanchit.find('.TblNewItemUploadDateTime').val($(ele).find('.TblDocUploadDate').val());
            itemESanchit.find('.TblNewItemPlaceOfIssue').val($(ele).find('.TblPlaceOfIssue').val());
            itemESanchit.find('.TblNewItemDocumentIssueDate').val($(ele).find('.TblDocIssueDate').val());
            itemESanchit.find('.TblNewItemDocumentExpiryDate').val($(ele).find('.TblDocExpiryDate').val());
            itemESanchit.find('.HiddenTblNewItemDocumentIssuingParty').val($(ele).find('.HiddenTblDocIssuingParty').val());
            itemESanchit.find('.TblNewItemDocumentIssuingPartyName').val($(ele).find('.TblDocIssuingParty').val());
            itemESanchit.find('.TblNewItemDocumentIssuingPartyCode').val($(ele).find('.TblDocIssuingPartyCode').val());
            itemESanchit.find('.HiddenTblNewItemDocumentBeneficiaryParty').val($(ele).find('.HiddenTblDocBeneficiaryParty').val());
            itemESanchit.find('.TblNewItemDocumentBeneficiaryPartyName').val($(ele).find('.TblDocBeneficiaryParty').val());
            itemESanchit.find('.TblNewItemDocumentBeneficiaryPartyCode').val($(ele).find('.TblDocBeneficiaryPartyCode').val());
        }

        GenerateSerialNumberTable('TblItemESanchit', 'rn');
    });
}

//FUNCTION FOR ADD AUTOCOMPLETE FUNCTION IN ITEM ESANCHIT
function AddFunction(e) {
    if ($(e).parent().parent().find('.TblNewItemFileNameType').val() == 'AUTO')
        $(e).parent().parent().find('.TblNewItemFileName').attr('onkeypress', AutoCompleteAjaxWithClass('TblNewItemFileName', '/Master/_Layout/GetFileNameAutoComplete', 'HiddenTblNewItemFileName'));
    else {
        if ($(e).parent().parent().find('.TblNewItemFileName').hasClass('ui-autocomplete-input'))
            $(e).parent().parent().find('.TblNewItemFileName').autocomplete('destroy');

        $(e).parent().parent().find('.TblNewItemFileName').removeAttr('onkeypress').removeClass('ui-autocomplete-input');

    }
}

//FUNCTION FOR GET DOCUMENT LEVEL
function GetDocumentLevel(e) {
    let DocumentCode = $(e).parent().parent().find('.HiddenTblNewItemDocumentTypeCode').val();

    if (DocumentCode.length > 0) {
        try {
            const dataString = {};
            dataString.DocumentCode = DocumentCode;
            AjaxSubmission(JSON.stringify(dataString), '/Master/_Layout/GetDocumentLevel', $('input[name=__RequestVerificationToken]').val()).done(function (result) {
                let obj = result;
                if (obj.status == true) {
                    if (obj.responsecode == '100')
                        $(e).parent().parent().find('.TblNewItemESanchitLevel').val(obj.data.Table[0].DocumentLevel);
                    else
                        $(e).parent().parent().find('.TblNewItemESanchitLevel').val('JOB');
                }
                else
                    window.location.href = '/ClientLogin/ClientLogin';
            }).fail(function (result) {
                console.log(result.message);
            });
        }
        catch (e) {
            console.log(e.message);
        }
    }
}

//#endregion 

//#region /****************************LICENSE DETAILS TAB ALL FUNCTION START****************************/

//NEWADDLICENSE BUTTON CLICK EVENT
$('#NewAddLicense').click(function () {
    if ($('#NewItemLicense').val() == null) {
        Toast('Please Add Item Details.', 'Message', 'error');
        return;
    }
    else if ($('#NewItemLicense').val() == '0') {
        Toast('Please Select Item.', 'Message', 'error');
        $('#NewItemLicense').focus();
        return;
    }
    else if ($('#NewLicenseCode').val() == null) {
        Toast('Please Select License Details.', 'Message', 'error');
        $('#NewLicenseCode').focus();
        return;
    }
    else if ($('#NewLicenseCode').val() == '0') {
        Toast('Please Select License Details.', 'Message', 'error');
        return;
    }
    else if ($('#NewLicenseRegisNumber').val().trim().length < 10) {
        Toast('Please Enter Valid License Number.', 'Message', 'error');
        $('#NewLicenseRegisNumber').focus();
        return;
    }
    else if ($('#NewLicenseRegisDate').val().trim().length < 10) {
        Toast('Please Enter Valid License Date.', 'Message', 'error');
        $('#NewLicenseRegisDate').focus();
        return;
    }
    else if ($('#NewDebitQuantity').val().trim() < 0) {
        Toast('Please Enter Valid Debit Quantity.', 'Message', 'error');
        $('#NewDebitQuantity').focus();
        return;
    }
    else if ($('#NewLicenseDebitQtyUnit').val().trim().length <= 0) {
        Toast('Please Enter Valid Unit.', 'Message', 'error');
        $('#NewLicenseDebitQtyUnit').focus();
        return;
    }
    else if ($('#NewLicenseItemCIFValue').val().trim() <= 0) {
        Toast('Please Enter License Item CIFValue.', 'Message', 'error');
        $('#NewLicenseItemCIFValue').focus();
        return;
    }
    else if ($('#NewLicensePortCode').val().trim().length <= 0) {
        Toast('Please Enter License Port Code.', 'Message', 'error');
        $('#NewLicensePortCode').focus();
        return;
    }
    else if ($('#TblItemDetails tbody tr').eq($('#NewItemLicense').val() - 1).find('.HiddenTblLicCheck').val() != 'true') {
        Toast('License can not add.', 'message', 'error');
        return;
    }
    else
        NewAddLicenseRow();
});

//FUNCTION FOR NEW ADD LICENSE ROW 
function NewAddLicenseRow() {
    let TblLen = $("#TblLicenceDetails tbody tr").length;
    let tbody = $("#TblLicenceDetails").find("tbody");
    let FirstTr = $(tbody).find("tr:first");
    let Licet = '';

    if (TblLen == 1 && $('#TblLicenceDetails tbody tr').find('.TblLicenseRegisNumber').val().trim().length == 0) {
        Licet = FirstTr;
        AddLicenseData();
    }
    else {
        FirstTr.find('.TblLicenseRegisDate').datepicker("destroy").removeAttr("id");
        Licet = $(FirstTr).clone();
        AddLicenseData();
        $('#TblLicenceDetails').append(Licet);
        $(".datepickerAll").datepicker({
            changeMonth: true,
            changeYear: true,
            dateFormat: 'dd/mm/yy'
        });
    }
    GenerateSerialNumberTable('TblLicenceDetails', 'rn');
    ResetNewLicense(true);
    Toast('License Add Successfully.', 'Message', 'success');

    function AddLicenseData() {
        Licet.find('.TblLicenseItemSr').val($('#NewItemLicense').val());
        Licet.find('.TblLicenseType').val($('#NewLicenseCode').val());
        Licet.find('.TblLicenseRegisNumber').val($('#NewLicenseRegisNumber').val());
        Licet.find('.TblLicenseRegisDate').val($('#NewLicenseRegisDate').val());
        Licet.find('.TblLicenseDebitQty').val($('#NewDebitQuantity').val());
        Licet.find('.HiddenTblLicenseDebitQtyUnit').val($('#HiddenNewLicenseDebitQtyUnit').val());
        Licet.find('.TblLicenseDebitQtyUnit').val($('#NewLicenseDebitQtyUnit').val());
        Licet.find('.TblLicenseItemCIFValue').val($('#NewLicenseItemCIFValue').val());
        Licet.find('.TblLicenseDebitBCDAmount').val($('#NewDebitBCDValue').val());
        Licet.find('.TblLicenseDebitSWAmount').val($('#NewDebitSWValue').val());
        Licet.find('.TblLicenseDebitIGSTAmount').val($('#NewDebitIGSTValue').val());
        Licet.find('.TblLicenseDebitAmount').val($('#NewDebitValue').val());
        Licet.find('.HiddenTblLicensePortCode').val($('#HiddenNewLicensePortCode').val());
        Licet.find('.TblLicensePortCode').val($('#NewLicensePortCode').val());
        Licet.find('.TblLicensePortName').val($('#NewLicensePortName').val());
    }
}

//FUNCTION FOR EDIT LICENSE ROW 
function EditLicenseRowEntry(e) {
    let Rn = $(e).parent().parent().find('.rn').text().trim();
    let ItmNo = $(e).parent().parent().find('.TblLicenseItemSr').val();

    if (ItmNo == null || ItmNo == undefined || ItmNo == '0' && $('#TblLicenseItemSr').html() == '')
        Toast('Invalid Item.', 'Message', 'error');
    else {
        ResetNewLicense();
        $('#NewAddLicense').addClass('d-none');
        $('#NewUpdateLicense').removeClass('d-none');

        $('#NewRowNumLicense').val(Rn);
        $('#NewItemLicense').val($(e).parent().parent().find('.TblLicenseItemSr').val());
        $('#NewLicenseCode').val($(e).parent().parent().find('.TblLicenseType').val());
        $('#NewLicenseRegisNumber').val($(e).parent().parent().find('.TblLicenseRegisNumber').val());
        $('#NewLicenseRegisDate').val($(e).parent().parent().find('.TblLicenseRegisDate').val());
        $('#NewDebitQuantity').val($(e).parent().parent().find('.TblLicenseDebitQty').val());
        $('#HiddenNewLicenseDebitQtyUnit').val($(e).parent().parent().find('.HiddenTblLicenseDebitQtyUnit').val());
        $('#NewLicenseDebitQtyUnit').val($(e).parent().parent().find('.TblLicenseDebitQtyUnit').val());
        $('#NewLicenseItemCIFValue').val($(e).parent().parent().find('.TblLicenseItemCIFValue').val());
        $('#NewDebitBCDValue').val($(e).parent().parent().find('.TblLicenseDebitBCDAmount').val());
        $('#NewDebitSWValue').val($(e).parent().parent().find('.TblLicenseDebitSWAmount').val());
        $('#NewDebitIGSTValue').val($(e).parent().parent().find('.TblLicenseDebitIGSTAmount').val());
        $('#NewDebitValue').val($(e).parent().parent().find('.TblLicenseDebitAmount').val());
        $('#HiddenNewLicensePortCode').val($(e).parent().parent().find('.HiddenTblLicensePortCode').val());
        $('#NewLicensePortCode').val($(e).parent().parent().find('.TblLicensePortCode').val());
        $('#NewLicensePortName').val($(e).parent().parent().find('.TblLicensePortName').val());
    }
}

//NEWUPDATELICENSE BUTTON CLICK EVENT
$('#NewUpdateLicense').click(function () {
    if ($('#NewItemLicense').val() == null) {
        Toast('Please Add Item Details.', 'Message', 'error');
        return;
    }
    else if ($('#NewItemLicense').val() == '0') {
        Toast('Please Select Item.', 'Message', 'error');
        return;
    }
    else if ($('#NewLicenseCode').val() == null) {
        Toast('Please Select License Details.', 'Message', 'error');
        return;
    }
    else if ($('#NewLicenseCode').val() == '0') {
        Toast('Please Select License Details.', 'Message', 'error');
        return;
    }
    else if ($('#NewLicenseRegisNumber').val().trim().length < 10) {
        Toast('Please Enter Valid License Number.', 'Message', 'error');
        $('#NewLicenseRegisNumber').focus();
        return;
    }
    else if ($('#NewLicenseRegisDate').val().trim().length < 10) {
        Toast('Please Enter Valid License Date.', 'Message', 'error');
        $('#NewLicenseRegisDate').focus();
        return;
    }
    else if ($('#NewDebitQuantity').val().trim() < 0) {
        Toast('Please Enter Valid Debit Quantity.', 'Message', 'error');
        $('#NewDebitQuantity').focus();
        return;
    }
    else if ($('#NewLicenseDebitQtyUnit').val().trim().length <= 0) {
        Toast('Please Enter Valid Unit.', 'Message', 'error');
        $('#NewLicenseDebitQtyUnit').focus();
        return;
    }
    else if ($('#NewLicenseItemCIFValue').val().trim() <= 0) {
        Toast('Please Enter License Item CIFValue.', 'Message', 'error');
        $('#NewLicenseItemCIFValue').focus();
        return;
    }
    else if ($('#NewLicensePortCode').val().trim().length <= 0) {
        Toast('Please Enter License Port Code.', 'Message', 'error');
        $('#NewLicensePortCode').focus();
        return;
    }
    else if ($('#TblItemDetails tbody tr').eq($('#NewItemLicense').val() - 1).find('.HiddenTblLicCheck').val() != 'true') {
        Toast('License can not add.', 'message', 'error');
        return;
    }
    else
        NewUpdateLicenseRow($('#NewRowNumLicense').val());
})

//FUNCTION FOR NEW UPDATE LICENSE ROW
function NewUpdateLicenseRow(Rn) {
    $('#TblLicenceDetails tbody tr').each(function (ind, ele) {
        if ($(ele).find('.rn').text().trim() == Rn) {

            $(ele).find('.TblLicenseItemSr').val($('#NewItemLicense').val());
            $(ele).find('.TblLicenseType').val($('#NewLicenseCode').val());
            $(ele).find('.TblLicenseRegisNumber').val($('#NewLicenseRegisNumber').val());
            $(ele).find('.TblLicenseRegisDate').val($('#NewLicenseRegisDate').val());
            $(ele).find('.TblLicenseDebitQty').val($('#NewDebitQuantity').val());
            $(ele).find('.HiddenTblLicenseDebitQtyUnit').val($('#HiddenNewLicenseDebitQtyUnit').val());
            $(ele).find('.TblLicenseDebitQtyUnit').val($('#NewLicenseDebitQtyUnit').val());
            $(ele).find('.TblLicenseItemCIFValue').val($('#NewLicenseItemCIFValue').val());
            $(ele).find('.TblLicenseDebitBCDAmount').val($('#NewDebitBCDValue').val());
            $(ele).find('.TblLicenseDebitSWAmount').val($('#NewDebitSWValue').val());
            $(ele).find('.TblLicenseDebitIGSTAmount').val($('#NewDebitIGSTValue').val());
            $(ele).find('.TblLicenseDebitAmount').val($('#NewDebitValue').val());
            $(ele).find('.HiddenTblLicensePortCode').val($('#HiddenNewLicensePortCode').val());
            $(ele).find('.TblLicensePortCode').val($('#NewLicensePortCode').val());
            $(ele).find('.TblLicensePortName').val($('#NewLicensePortName').val());

            ResetNewLicense();
            GenerateSerialNumberTable('TblLicenceDetails', 'rn');
            Toast('Update License Successfully.', 'Message', 'success');
        }
    });
}

//FUNCTION FOR DELETE LICENSE ROW
function DeleteLicenseRowEntry(e) {
    let RowCount = $("#TblLicenceDetails tbody tr").length;
    let ItN = $(e).parent().parent().find('.TblLicenseItemSr').val();
    if (ItN == 0 || ItN == null || ItN == undefined || ItN == '' && $('#TblLicenseItemSr').html() == '')
        Toast('Item Name Blank.', 'Message', 'error');
    else if ($('#NewAddLicense').hasClass('d-none')) {
        Toast('Please Updtae License', 'Message', 'error');
    }
    else {
        $.confirm({
            title: '',
            content: 'Are You Sure Want To Delete ?',
            type: 'red',
            boxWidth: '300px',
            useBootstrap: false,
            typeAnimated: true,
            columnClass: 'small',
            containerFluid: true,
            draggable: true,
            buttons: {
                tryAgain: {
                    text: 'Confirm',
                    btnClass: 'btn-red',
                    action: function () {
                        ResetDeleteLicenseRowEntry(e, RowCount);
                        GenerateSerialNumberTable('TblLicenceDetails', 'rn');
                    }
                },
                close: function () {
                }
            }
        });
    }
}

//FUNCTION FOR RESET OR DELETE IN LICENSE ROW 
function ResetDeleteLicenseRowEntry(e, RowCount) {
    if (RowCount > 1)
        $(e).parent().parent().remove();
    else {
        $(e).parent().parent().find('.TblLicenseItemSr').val(0);
        $(e).parent().parent().find('.TblLicenseRegisNumber,.TblLicenseRegisDate,.HiddenTblLicenseDebitQtyUnit,.TblLicenseDebitQtyUnit,.HiddenTblLicensePortCode,.TblLicensePortCode,.TblLicensePortName', '.TblLicenseType').val('');
        $(e).parent().parent().find('.TblLicenseDebitQty,.TblLicenseItemCIFValue,.TblLicenseDebitBCDAmount,.TblLicenseDebitSWAmount,.TblLicenseDebitIGSTAmount,.TblLicenseDebitAmount').val('0.00');
    }
}

//FUNCTION FOR DELETE LICENSE ROW ITEM WISE
function DeleteLicenseRowItemWise(SrNoAr) {
    SrNoAr.forEach(function (val) {
        $('#TblLicenceDetails tbody tr').each(function (ind, ele) {
            let DeRowCount = $('#TblLicenceDetails tbody tr').length;
            let LiItSr = $(ele).find('.TblLicenseItemSr').val();
            if (DeRowCount == 1) {
                if (LiItSr != null && LiItSr != undefined && LiItSr != 0 && LiItSr != '') {
                    if (LiItSr == val) {
                        $(ele).find('.TblLicenseItemSr').val(0);
                        $(ele).find('.TblLicenseRegisNumber,.TblLicenseRegisDate,.HiddenTblLicenseDebitQtyUnit,.TblLicenseDebitQtyUnit,.HiddenTblLicensePortCode,.TblLicensePortCode,.TblLicensePortName,.TblLicenseType').val('');
                        $(ele).find('.TblLicenseDebitQty,.TblLicenseItemCIFValue,.TblLicenseDebitBCDAmount,.TblLicenseDebitSWAmount,.TblLicenseDebitIGSTAmount,.TblLicenseDebitAmount').val('0.00');
                    }
                }
            }
            else {
                if (LiItSr != null && LiItSr != undefined && LiItSr != 0 && LiItSr != '') {
                    if (LiItSr == val) {
                        $(ele).remove();
                    }
                }
            }
        });
    });
    GenerateSerialNumberTable('TblLicenceDetails', 'rn');
}

//NEWITEMLICENSE DROPDOWN CHANGE EVENT
$('#NewItemLicense').change(function () {
    if ($('#NewItemLicense').val() > 0)
        NewFillLicenseCalcCIFValue();
});

//FUNCTION FOR FILL CIF VALUE IN LICENSE ITEM WISE 
function NewFillLicenseCalcCIFValue() {
    let trnum = $('#NewItemLicense').val();
    let tr = $('#TblItemDetails tbody tr').eq(trnum - 1);
    $('#NewDebitQuantity').val('0.000000');
    $('#NewLicenseDebitQtyUnit').val('');
    $('#NewLicenseItemCIFValue').val('0.00');
    if ($(tr).find('.HiddenTblLicCheck').val() == 'true') {
        $('#NewDebitQuantity').val($(tr).find('.TblItemQuantity').val());
        $('#NewLicenseDebitQtyUnit').val($(tr).find('.TblUnitQuantityCode').val());
        $('#NewLicenseItemCIFValue').val($(tr).find('.TblItemCIFValue').val());
        $('#NewLicenseCode').val($(tr).find('.TblItemCategorySchemeCode').val());
    }
}

//FUNCTION FOR LICENSE CALCULATION
function LicenseCalculation() {
    let trnum = $('#NewItemLicense').val();
    if (trnum != undefined && trnum != null && trnum != '' && trnum != 0) {
        let LiCheck = $('#TblItemDetails tbody tr').eq(trnum - 1).find('.HiddenTblLicCheck').val();
        if (LiCheck == 'true') {
            let tr = $('#TblItemDetails tbody tr').eq(trnum - 1);
            let ItemAmount = $(tr).find('.TblItemAmount').val();
            let Cifvalue = $(tr).find('.TblItemCIFValue').val();
            let UnitPrice = $(tr).find('.TblItemUnitPrice').val();
            let OldQuantity = parseFloat($(tr).find('.TblItemQuantity').val());
            let NewQuantity = parseFloat($('#NewDebitQuantity').val());
            let Scheme = $(tr).find('.TblItemCategorySchemeCode').val();
            let Basic = $(tr).find('.TblItemBCDAmount').val();
            let BasicPer = $(tr).find('.TblItemBCDRate').val();
            let Sw = $(tr).find('.TblSocialWelfareAmount').val();
            let SwPer = $(tr).find('.TblSocialWelfareRate').val();
            let IgExemNotn = $(tr).find('.TblIGSTExemNotification').val();
            let Ig = $(tr).find('.TblIGSTNotificationAmount').val();
            let IgPer = $(tr).find('.TblIGSTNotificationRate').val();
            let NewCif = 0, NewBasic = 0, NewSw = 0, NewDebit = 0, NewIg = 0;
            $('#NewLicenseItemCIFValue').val('0.00');
            $('#NewLicenseCode').val($(tr).find('.TblItemCategorySchemeCode').val());
            if (NewQuantity > OldQuantity) {
                Toast('Invalid Quantity.', 'Message', 'error');
                return;
            }
            else {
                NewCif = (Cifvalue / ItemAmount) * NewQuantity * UnitPrice;
                $('#NewLicenseItemCIFValue').val(NewCif.toFixed(2));
            }

            const dataString = {};
            dataString.SchemeCode = Scheme;
            AjaxSubmission(JSON.stringify(dataString), "/Master/_Layout/GetSchemeFeautures", $('input[name=__RequestVerificationToken]').val()).done(function (result) {
                let obj = result;
                if (obj.status == true) {
                    if (obj.responsecode == '100') {
                        if (obj.data.Table[0].BasicLess == true)
                            NewBasic = NewCif * BasicPer / 100;
                        if (obj.data.Table[0].SWLess == true)
                            NewSw = NewBasic * SwPer / 100;
                        if (IgExemNotn.length > 0)
                            NewIg = (NewCif + NewBasic + NewSw) * IgPer / 100;
                        NewDebit = NewBasic + NewSw + NewIg;

                        $('#NewDebitBCDValue').val(NewBasic.toFixed(2));
                        $('#NewDebitSWValue').val(NewSw.toFixed(2));
                        $('#NewDebitIGSTValue').val(NewIg.toFixed(2));

                        $('#NewDebitValue').val(NewDebit.toFixed(2));
                    }
                }
                else
                    window.location.href = '/ClientLogin/ClientLogin';

            }).fail(function (result) {
                console.log(result.Message);
            });
        }
        else
            Toast('License can not add.', 'message', 'error');
    }
}

//NEWRESETLICENSE BUTTON CLICK EVENT
$('#NewResetLicense').click(function () {
    ResetNewLicense(true);
});

//FUNCTION FOR NEW RESET LICENSE
function ResetNewLicense(flag) {
    const blankItemId = ['NewLicenseRegisNumber', 'NewLicenseRegisDate', 'HiddenNewLicenseDebitQtyUnit', 'NewLicenseDebitQtyUnit', 'HiddenNewLicensePortCode', 'NewLicensePortCode', 'NewLicensePortName', 'NewLicenseCode'];

    blankItemId.forEach((ele) => {
        $('#' + ele).val('');
    });

    const zeroItemId = ['NewDebitQuantity', 'NewLicenseItemCIFValue', 'NewDebitBCDValue', 'NewDebitSWValue', 'NewDebitIGSTValue', 'NewDebitValue'];

    zeroItemId.forEach((ele) => {
        $('#' + ele).val('0.00');
    });

    $('#NewItemLicense').val(0);
    $('#NewAddLicense').removeClass('d-none');
    $('#NewUpdateLicense').addClass('d-none');

    if (flag)
        $('#NewItemLicense').focus();
}

//FUNCTION FOR VALIDATE LICENSE DATA WITH ITEM DETAILS DATA
function ValidateLicenseDataItemDetailsData() {
    let Vflag = 0;
    $("#TblItemDetails tbody tr").each(function (ItInd, ItEle) {
        let ItSer = 0, ItQty = 0, ItName = '';
        let LiSer = 0, LiQty = 0;
        ItSer = ItInd + 1;
        ItQty = HandleNullNumericValue($(ItEle).find('.TblItemQuantity').val());
        ItName = $(ItEle).find('.TblItemName').val();
        $("#TblLicenceDetails tbody tr").each(function (LiInd, LiEle) {
            LiSer = $(LiEle).find('.TblLicenseItemSr').val();

            if (LiSer != null && LiSer != undefined && LiSer != '' && LiSer != 0) {
                if (ItSer == LiSer)
                    LiQty += parseFloat(HandleNullNumericValue($(LiEle).find('.TblLicenseDebitQty').val()));
            }
        });
        if (LiQty > ItQty) {
            Toast('License Debit Quantity Not Greator Than Item Quantity Against Item :-' + ItName + '', 'Message', 'error');
            Vflag = 1;
            return;
        }
    });

    return Vflag;
}

//FUNCTION FOR VALIDATE LICENSE DETAILS DATA
function ValidateLicenseDetailsData() {
    let Vflag = 0;
    $("#TblLicenceDetails tbody tr").each(function (ind, ele) {
        if ($("#TblLicenceDetails tbody tr").length == 1) {
            let LiItSr = $(ele).find('.TblLicenseItemSr').val();
            if (LiItSr != null && LiItSr != undefined && LiItSr != '' && LiItSr != 0) {

                if ($(ele).find('.TblLicenseRegisNumber').val().trim().length < 10) {
                    Toast('Please Enter License Number In License Details Row Number' + (ind + 1) + '', 'Message', 'error');
                    Vflag = 1;
                    return;
                }
                if ($(ele).find('.TblLicenseRegisDate').val().trim().length < 10) {
                    Toast('Please Enter License Date In License Details Row Number' + (ind + 1) + '', 'Message', 'error');
                    Vflag = 1;
                    return;
                }
                if ($(ele).find('.TblLicensePortCode').val().trim().length <= 0) {
                    Toast('Please Enter License Port Code In License Details Row Number' + (ind + 1) + '', 'Message', 'error');
                    Vflag = 1;
                    return;
                }
            }
        }
        else {

            if ($(ele).find('.TblLicenseRegisNumber').val().trim().length < 10) {
                Toast('Please Enter License Number In License Details Row Number' + (ind + 1) + '', 'Message', 'error');
                Vflag = 1;
                return;
            }
            if ($(ele).find('.TblLicenseRegisDate').val().trim().length < 10) {
                Toast('Please Enter License Date In License Details Row Number' + (ind + 1) + '', 'Message', 'error');
                Vflag = 1;
                return;
            }
            if ($(ele).find('.TblLicensePortCode').val().trim().length <= 0) {
                Toast('Please Enter License Port Code In License Details Row Number' + (ind + 1) + '', 'Message', 'error');
                Vflag = 1;
                return;
            }
        }
    });

    return Vflag;
}

//#endregion

//#region /****************************DESTUFF DETAILS TAB ALL FUNCTION START****************************/

//NEWADDDESTUFF BUTTON CLICK EVENT
$('#NewAddDestuff').click(function () {
    if ($('#NewItemDestuff').val() == null) {
        Toast('Please Add Item Details.', 'Message', 'error');
        return;
    }
    else if ($('#NewItemDestuff').val() == '0') {
        Toast('Please Select Item.', 'Message', 'error');
        return;
    }
    else if ($('#NewDeLRNo').val().trim().length < 0) {
        Toast('Please Enter Lorry Receipt Number.', 'Message', 'error');
        return;
    }
    else
        NewAddDestuffRow();
});

//FUNCTION FOR NEW ADD DESTUFF
function NewAddDestuffRow() {
    let TblLen = $("#TblDestuffDetails tbody tr").length;
    let tbody = $("#TblDestuffDetails").find("tbody");
    let FirstTr = $(tbody).find("tr:first");
    let Destut = '';

    if (TblLen == 1 && $('#TblDestuffDetails tbody tr').find('.TblDeLRNo').val().trim().length == 0) {
        Destut = FirstTr;
        AddDestuffData();
    }
    else {
        FirstTr.find('.TblDeDeliveryDate').datepicker("destroy").removeAttr("id");
        Destut = $(FirstTr).clone();
        AddDestuffData();
        $('#TblDestuffDetails').append(Destut);
        $(".datepickerAll").datepicker({
            changeMonth: true,
            changeYear: true,
            dateFormat: 'dd/mm/yy'
        });
    }
    GenerateSerialNumberTable('TblDestuffDetails', 'rn');
    ResetNewDestuff(true);
    Toast('Destuff Add Successfully.', 'Message', 'success');

    function AddDestuffData() {
        Destut.find('.TblDeDeliveryDate').val($('#NewDeDeliveryDate').val());
        Destut.find('.TblDestuffItemSr').val($('#NewItemDestuff').val());
        Destut.find('.TblDeLRNo').val($('#NewDeLRNo').val());
        Destut.find('.TblDeTruckNo').val($('#NewDeTruckNo').val());
        Destut.find('.TblDeGrossWeight').val($('#NewDeGrossWeight').val());
        Destut.find('.TblDeTareWeight').val($('#NewDeTareWeight').val());
        Destut.find('.TblDeNetWeight').val($('#NewDeNetWeight').val());
        Destut.find('.TblDeBales').val($('#NewDeBales').val());
        Destut.find('.TblDeLoose').val($('#NewDeLoose').val());
    }
}

//FUNCTION FOR EDIT DESTUFF ROW 
function EditDestuffRowEntry(e) {
    let Rn = $(e).parent().parent().find('.rn').text().trim();
    let ItmNo = $(e).parent().parent().find('.TblDestuffItemSr').val();

    if (ItmNo == null || ItmNo == undefined || ItmNo == '0')
        Toast('Invalid Item.', 'Message', 'errro');
    else {
        ResetNewDestuff();
        $('#NewAddDestuff').addClass('d-none');
        $('#NewUpdateDestuff').removeClass('d-none');

        $('#NewRowNumDestuff').val(Rn);
        $('#NewDeDeliveryDate').val($(e).parent().parent().find('.TblDeDeliveryDate').val());
        $('#NewItemDestuff').val($(e).parent().parent().find('.TblDestuffItemSr').val());
        $('#NewDeLRNo').val($(e).parent().parent().find('.TblDeLRNo').val());
        $('#NewDeTruckNo').val($(e).parent().parent().find('.TblDeTruckNo').val());
        $('#NewDeGrossWeight').val($(e).parent().parent().find('.TblDeGrossWeight').val());
        $('#NewDeTareWeight').val($(e).parent().parent().find('.TblDeTareWeight').val());
        $('#NewDeNetWeight').val($(e).parent().parent().find('.TblDeNetWeight').val());
        $('#NewDeBales').val($(e).parent().parent().find('.TblDeBales').val());
        $('#NewDeLoose').val($(e).parent().parent().find('.TblDeLoose').val());
    }
}

//NEWUPDATEDESTUFF BUTTON CLICK EVENT
$('#NewUpdateDestuff').click(function () {
    if ($('#NewItemDestuff').val() == null) {
        Toast('Please Add Item Details.', 'Message', 'error');
        return;
    }
    else if ($('#NewItemDestuff').val() == '0') {
        Toast('Please Select Item.', 'Message', 'error');
        return;
    }
    else if ($('#NewDeLRNo').val().trim().length < 0) {
        Toast('Please Enter Lorry Receipt Number.', 'Message', 'error');
        return;
    }
    else
        NewUpdateDestuffRow($('#NewRowNumDestuff').val());
});

//FUNCTION FOR UPDATE NEW DESTUFF 
function NewUpdateDestuffRow(Rn) {
    $('#TblDestuffDetails tbody tr').each(function (ind, ele) {
        if ($(ele).find('.rn').text().trim() == Rn) {
            $(ele).find('.TblDeDeliveryDate').val($('#NewDeDeliveryDate').val());
            $(ele).find('.TblDestuffItemSr').val($('#NewItemDestuff').val());
            $(ele).find('.TblDeLRNo').val($('#NewDeLRNo').val());
            $(ele).find('.TblDeTruckNo').val($('#NewDeTruckNo').val());
            $(ele).find('.TblDeGrossWeight').val($('#NewDeGrossWeight').val());
            $(ele).find('.TblDeTareWeight').val($('#NewDeTareWeight').val());
            $(ele).find('.TblDeNetWeight').val($('#NewDeNetWeight').val());
            $(ele).find('.TblDeBales').val($('#NewDeBales').val());
            $(ele).find('.TblDeLoose').val($('#NewDeLoose').val());

            ResetNewDestuff();
            GenerateSerialNumberTable('TblDestuffDetails', 'rn');
            Toast('Update Destuff Successfully.', 'Message', 'success');
        }
    });
}

//FUNCTION FOR DELETE DESTUFF ROW 
function DeleteDestuffRowEntry(e) {
    let RowCount = $("#TblDestuffDetails tbody tr").length;
    let ItN = $(e).parent().parent().find('.TblDestuffItemSr').val();

    if (ItN == 0 || ItN == null || ItN == undefined || ItN == '')
        Toast('Item Name Blank.', 'Message', 'error');
    else if ($('#NewAddDestuff').hasClass('d-none')) {
        Toast('Please Update Destuff.', 'Message', 'error');
    }
    else {
        $.confirm({
            title: '',
            content: 'Are You Sure Want To Delete ?',
            type: 'red',
            boxWidth: '300px',
            useBootstrap: false,
            typeAnimated: true,
            columnClass: 'small',
            containerFluid: true,
            draggable: true,
            buttons: {
                tryAgain: {
                    text: 'Confirm',
                    btnClass: 'btn-red',
                    action: function () {
                        ResetDeleteDestuffRowEntry(e, RowCount);
                        GenerateSerialNumberTable('TblDestuffDetails', 'rn');
                    }
                },
                close: function () {
                }
            }
        });
    }
}

//FUNCTION FOR RESET OR DELETE IN DESTUFF ROW
function ResetDeleteDestuffRowEntry(e, RowCount) {
    if (RowCount > 1)
        $(e).parent().parent().remove();
    else {
        $(e).parent().parent().find('.TblDeDeliveryDate,.TblDeLRNo,.TblDeTruckNo,.TblDeBales,.TblDeLoose').val('');
        $(e).parent().parent().find('.TblDeGrossWeight,.TblDeTareWeight,.TblDeNetWeight').val('0.000');
    }
}

//FUNCTION FOR DELETE DESTUFF ROW ITEM WISE
function DeleteDestuffRowItemWise(SrNoAr) {
    SrNoAr.forEach(function (val) {
        $('#TblDestuffDetails tbody tr').each(function (ind, ele) {
            let DeRowCount = $('#TblDestuffDetails tbody tr').length;
            let DeItSr = $(ele).find('.TblDestuffItemSr').val();
            if (DeRowCount == 1) {
                if (DeItSr != null && DeItSr != undefined && DeItSr != 0 && DeItSr != '') {
                    if (DeItSr == val) {
                        $(ele).find('.TblDeDeliveryDate,.TblDeLRNo,.TblDeTruckNo,.TblDeBales,.TblDeLoose').val('');
                        $(ele).find('.TblDeGrossWeight,.TblDeTareWeight,.TblDeNetWeight').val('0.000');
                        $(ele).find('.TblDestuffItemSr').html('');
                    }
                }
            }
            else {
                if (DeItSr != null && DeItSr != undefined && DeItSr != 0 && DeItSr != '') {
                    if (DeItSr == val) {
                        $(ele).remove();
                    }
                }
            }
        });
    });
    GenerateSerialNumberTable('TblDestuffDetails', 'rn');
}

//NEWRESETLICENSE BUTTON CLICK EVENT
$('#NewResetDestuff').click(function () {
    ResetNewDestuff(true);
});

//FUNCTION FOR NEW RESET DESTUFF
function ResetNewDestuff(flag) {
    const blankItemId = ['NewDeDeliveryDate', 'NewRowNumDestuff', 'NewDeLRNo', 'NewDeTruckNo', 'NewDeBales', 'NewDeLoose'];

    blankItemId.forEach((ele) => {
        $('#' + ele).val('');
    });

    const zeroItemId = ['NewDeGrossWeight', 'NewDeTareWeight', 'NewDeNetWeight'];

    zeroItemId.forEach((ele) => {
        $('#' + ele).val('0.00');
    });

    $('#NewItemDestuff').val(0);

    $('#NewAddDestuff').removeClass('d-none');
    $('#NewUpdateDestuff').addClass('d-none');

    if (flag)
        $('#NewItemDestuff').focus();
}

//FUNCTION FOR VALIDATE DESTUFF DETAILS DATA
function ValidateDestuffDetailsData() {
    let Vflag = 0;
    $("#TblDestuffDetails tbody tr").each(function (ind, ele) {
        if ($("#TblDestuffDetails tbody tr").length == 1) {
            let DeItSr = $(ele).find('.TblDestuffItemSr').val();
            if (DeItSr != null && DeItSr != undefined && DeItSr != '' && DeItSr != 0) {
                if ($(ele).find('.TblDeLRNo').val().trim().length < 5) {
                    Toast('Please Enter Lorry Receipt Number In Destuff Details Row Number' + (ind + 1) + '', 'Message', 'error');
                    Vflag = 1;
                    return;
                }
                if ($(ele).find('.TblDeDeliveryDate').val().trim().length < 10) {
                    Toast('Please Enter Delivery Date In Destuff Details Row Number' + (ind + 1) + '', 'Message', 'error');
                    Vflag = 1;
                    return;
                }
            }
        }
        else {
            if ($(ele).find('.TblDeLRNo').val().trim().length < 5) {
                Toast('Please Enter Lorry Receipt Number In Destuff Details Row Number' + (ind + 1) + '', 'Message', 'error');
                Vflag = 1;
                return;
            }
            if ($(ele).find('.TblDeDeliveryDate').val().trim().length < 10) {
                Toast('Please Enter Delivery Date In Destuff Details Row Number' + (ind + 1) + '', 'Message', 'error');
                Vflag = 1;
                return;
            }
        }
    });

    return Vflag;
}

//#endregion

//#region /****************************BOND DETAILS TAB ALL FUNCTION START****************************/

//NEWADDBOND BUTTON CLICK EVENT
$('#NewAddBond').click(function () {
    let BondNumber = $('#BondNumber').val().trim();
    let BondCode = $('#BondCode').val();
    let BondPort = $('#BondPort').val().trim();

    if (BondNumber.length == 0) {
        Toast('Bond Number Required.', 'Message', 'error');
        $('#BondNumber').focus();
        return;
    }
    else if (BondNumber.length > 10) {
        Toast('Only 10 Character Allow In Bond Number.', 'Message', 'error');
        $('#BondNumber').focus();
        return;
    }
    else if (BondCode == "0" || BondCode == undefined || BondCode == '') {
        Toast('Bond Code Required.', 'Message', 'error');
        $('#BondCode').focus();
        return;
    }
    else if (BondPort.length == 0) {
        Toast('Bond Port Required.', 'Message', 'error');
        $('#BondPort').focus();
        return;
    } else
        NewAddBondRow();
});

//FUNCTION FOR NEW ADD BOND ROW
function NewAddBondRow() {
    let flag = 0;
    let tbody = $('#TblBondDetails').find("tbody");
    let FirstTr = $(tbody).find('tr:first');
    let Bondt = '';

    $("#TblBondDetails tbody tr").each(function (ind, ele) {
        if ($(ele).find('.TblBondNo').val().trim() == $('#BondNumber').val().trim()) {
            flag = 1;
            return;
        }
    });

    function AddBondRowData() {
        Bondt.find('.TblBondNo').val($('#BondNumber').val());
        Bondt.find('.TblBondCode').val($('#BondCode').val());
        Bondt.find('.TblBondPort').val($('#BondPort').val());
        Bondt.find('.TblBondPortName').val($('#BondPortName').val());
    }

    if (flag == 0) {
        if ($('#TblBondDetails tbody tr').find('.TblBondNo').val().length <= 0 || $('#TblBondDetails tbody tr').find('.TblBondCode').val().length <= 0 || $('#TblBondDetails tbody tr').find('.TblBondPort').val().length <= 0 || $('#TblBondDetails tbody tr').find('.TblBondPortName').val().length <= 0) {
            Bondt = FirstTr;
            AddBondRowData();
        }
        else {
            Bondt = $(FirstTr).clone();
            Bondt.find('.TblBondNo,.TblBondCode,.TblBondPort,.TblBondPortName').val('');
            AddBondRowData();
            $("#TblBondDetails").append(Bondt);
        }
        GenerateSerialNumberTable('TblBondDetails', 'rn')
        ResetNewBond();
        Toast('Bond Add Successfully.', 'Message', 'success');
    }
    else
        Toast('Duplicate Bond Number.', 'Message', 'error');

}

//FUNCTION FOR EDIT BOND ROW 
function EditBondRowEntry(e) {
    let Rn = $(e).parent().parent().find('.rn').text().trim();
    let BondNo = $(e).parent().parent().find('.TblBondNo').val().trim();

    if (BondNo.length == 0)
        Toast('Bond Number Blank!.', 'Message', 'error');
    else {
        ResetNewBond();
        $('#NewAddBond').addClass('d-none');
        $('#NewUpdateBond').removeClass('d-none');

        $('#NewRownNumBond').val(Rn);

        $('#BondNumber').val($(e).parent().parent().find('.TblBondNo').val());
        $('#BondCode').val($(e).parent().parent().find('.TblBondCode').val());
        $('#BondPort').val($(e).parent().parent().find('.TblBondPort').val());
        $('#BondPortName').val($(e).parent().parent().find('.TblBondPortName').val());
    }
}

//NEWUPDATEBOND BUTTON CLICK EVENT
$('#NewUpdateBond').click(function () {
    let BondNumber = $('#BondNumber').val().trim();
    let BondCode = $('#BondCode').val();
    let BondPort = $('#BondPort').val().trim();

    if (BondNumber.length == 0) {
        Toast('Bond Number Required.', 'Message', 'error');
        $('#BondNumber').focus();
        return;
    }
    else if (BondNumber.length > 10) {
        Toast('Only 10 Character Allow In Bond Number.', 'Message', 'error');
        $('#BondNumber').focus();
        return;
    }
    else if (BondCode == "0" || BondCode == undefined || BondCode == '') {
        Toast('Bond Code Required.', 'Message', 'error');
        $('#BondCode').focus();
        return;
    }
    else if (BondPort.length == 0) {
        Toast('Bond Port Required.', 'Message', 'error');
        $('#BondPort').focus();
        return;
    } else
        UpdateNewBondRow($('#NewRownNumBond').val());
});

//FUNCTION FOR NEW UPDATE BOND 
function UpdateNewBondRow(Rn) {
    let flag = 0;
    $("#TblBondDetails tbody tr").each(function (ind, ele) {
        if ($(ele).find('.TblBondNo').val().trim() == $('#BondNumber').val().trim() && $(ele).find('.rn').text().trim() != Rn) {
            flag = 1;
            return;
        }
    });
    if (flag == 1)
        Toast('Duplicate Bond Number.', 'Message', 'error');
    else {
        $('#TblBondDetails tbody tr').each(function (ind, ele) {
            if ($(ele).find('.rn').text().trim() == Rn) {
                $(ele).find('.TblBondNo').val($('#BondNumber').val());
                $(ele).find('.TblBondCode').val($('#BondCode').val().trim());
                $(ele).find('.TblBondPort').val($('#BondPort').val());
                $(ele).find('.TblBondPortName').val($('#BondPortName').val());

                $('#NewAddBond').removeClass('d-none');
                $('#NewUpdateBond').addClass('d-none');
                ResetNewBond();
                Toast('Update Bond Successfully.', 'Message', 'success');
            }
        });
    }
}

// FUNCTION FOR DELETE BOND ROW ENTRY 
function DeleteBondRowEntry(e) {
    let BondNo = $(e).parent().parent().find('.TblBondNo').val().trim();

    if (BondNo.length == 0)
        Toast('Bond Number Blank!. ', 'Message', 'error');
    else if ($('#NewAddBond').hasClass('d-none')) {
        Toast('Please Update Bond', 'Message', 'error');
    }
    else {
        $.confirm({
            title: '',
            content: 'Are You Sure Want To Delete ?',
            type: 'red',
            boxWidth: '300px',
            useBootstrap: false,
            typeAnimated: true,
            columnClass: 'small',
            containerFluid: true,
            draggable: true,
            buttons: {
                tryAgain: {
                    text: 'Confirm',
                    btnClass: 'btn-red',
                    action: function () {
                        let RowCount = $('#TblBondDetails tbody tr').length;
                        if (RowCount > 1)
                            $(e).parent().parent().remove();
                        else
                            $(e).parent().parent().find('.TblBondNo,.TblBondCode,.TblBondPort,.TblBondPortName').val('');
                        GenerateSerialNumberTable('TblBondDetails', 'rn')
                    }
                },
                close: function () {
                }
            }
        });
    }
}

//NEWRESETBOND BUTTON CLICK EVENT
$('#NewResetBond').click(function () {
    ResetNewBond(true);
})

//FUNCTION FOR RESET NEW BOND 
function ResetNewBond(flag) {
    const blankBondId = ['BondNumber', 'HiddenBondPort', 'BondPort', 'HiddenBondPort', 'BondPort', 'BondPortName'];
    $('#BondCode').val(0);
    blankBondId.forEach((ele) => {
        $('#' + ele).val('');
    });
    $('#NewAddBond').removeClass('d-none');
    $('#NewUpdateBond').addClass('d-none');
    if (flag)
        $('#BondNumber').focus();
}

//FUNCTION FOR VALIDATE BOND DETAILS DATA
function ValidateBondDetailsData() {
    let Vflag = 0;
    $("#TblBondDetails tbody tr").each(function (ind, ele) {
        if ($("#TblBondDetails tbody tr").length == 1) {
            let BondNo = $(ele).find('.TblBondNo').val();
            if (BondNo != '') {
                if ($(ele).find('.TblBondCode').val().trim().length <= 0) {
                    Toast('Please Enter Bond Code In Bond Details Row Number' + (ind + 1) + '', 'Message', 'error');
                    Vflag = 1;
                    return;
                }
                if ($(ele).find('.TblBondPort').val().trim().length <= 0) {
                    Toast('Please Enter Bond Port In Bond Details Row Number' + (ind + 1) + '', 'Message', 'error');
                    Vflag = 1;
                    return;
                }
            }
        }
        else {
            if ($(ele).find('.TblBondCode').val().trim().length <= 0) {
                Toast('Please Enter Bond Code In Bond Details Row Number' + (ind + 1) + '', 'Message', 'error');
                Vflag = 1;
                return;
            }
            if ($(ele).find('.TblBondPort').val().trim().length <= 0) {
                Toast('Please Enter Bond Port In Bond Details Row Number' + (ind + 1) + '', 'Message', 'error');
                Vflag = 1;
                return;
            }
        }
    });

    return Vflag;
}


//#endregion

//#region /****************************CERTIFICATE DETAILS TAB ALL FUNCTION START****************************/

//NEWADDCERTIFICATE BUTTON CLICK EVENT
$('#NewAddCertificate').click(function () {
    let CertificateNumber = $('#CertificateNumber').val().trim();
    let CertificateDate = $('#CertificateDate').val();
    let CertificateType = $('#CertificateType').val().trim();

    if (CertificateNumber.length == 0) {
        Toast('Certificate Number Required.', 'Message', 'error');
        $('#CertificateNumber').focus();
        return;
    }
    else if (CertificateNumber.length > 30) {
        Toast('Only 30 Character Allow In Certificate Number.', 'Message', 'error');
        $('#CertificateNumber').focus();
        return;
    }
    else if (CertificateType == "0" || CertificateType == undefined || CertificateType == '') {
        Toast('Certificate Code Required.', 'Message', 'error');
        $('#CertificateType').focus();
        return;
    }
    else if (CertificateDate.length > 0 && CertificateDate.length < 10) {
        Toast('Invalid Certificate Date', 'Message', 'error');
        $('#CertificateDate').focus();
        return;
    } else
        NewAddCertificateRow();
});

//FUNCTION FOR NEW ADD CERTIFICATE 
function NewAddCertificateRow() {
    let flag = 0;
    let tbody = $('#TblCertificateDetails').find("tbody");
    let FirstTr = $(tbody).find('tr:first');
    let Certificatet = '';

    $("#TblCertificateDetails tbody tr").each(function (ind, ele) {
        if ($(ele).find('.TblCertificateNo').val().trim() == $('#CertificateNumber').val().trim()) {
            flag = 1;
            return;
        }
    });

    function AddCertificateRowData() {
        Certificatet.find('.TblCertificateNo').val($('#CertificateNumber').val());
        Certificatet.find('.TblCertificateDate').val($('#CertificateDate').val());
        Certificatet.find('.TblCertificateCode').val($('#CertificateType').val());

    }
    if (flag == 0) {
        if ($('#TblCertificateDetails tbody tr').find('.TblCertificateNo').val().trim().length <= 0) {
            Certificatet = FirstTr;
            AddCertificateRowData();
        }
        else {
            Certificatet = $(FirstTr).clone();
            Certificatet.find('.TblCertificateNo,.TblCertificateDate,.TblCertificateCode').val('');
            AddCertificateRowData();
            $("#TblCertificateDetails").append(Certificatet);
        }
        GenerateSerialNumberTable('TblCertificateDetails', 'rn')
        ResetNewCertificate();
        Toast('Certificate Add Successfully.', 'Message', 'success');
    }
    else
        Toast('Duplicate Certificate Number.', 'Message', 'error');
}

//FUNCTION FOR EDIT CERTIFICATE ROW ENTRY
function EditCertificateRowEntry(e) {
    let Rn = $(e).parent().parent().find('.rn').text().trim();
    let CertificateNo = $(e).parent().parent().find('.TblCertificateNo').val().trim();

    if (CertificateNo.length == 0)
        Toast('Certificate Number Blank!.', 'Message', 'error');
    else {
        ResetNewCertificate();
        $('#NewAddCertificate').addClass('d-none');
        $('#NewUpdateCertificate').removeClass('d-none');

        $('#NewRownNumCertificate').val(Rn);

        $('#CertificateNumber').val($(e).parent().parent().find('.TblCertificateNo').val());
        $('#CertificateDate').val($(e).parent().parent().find('.TblCertificateDate').val());
        $('#CertificateType').val($(e).parent().parent().find('.TblCertificateCode').val());

    }
}

//NEWUPDATECERTIFICATE BUTTON CLICK EVENT
$('#NewUpdateCertificate').click(function () {
    let CertificateNumber = $('#CertificateNumber').val().trim();
    let CertificateDate = $('#CertificateDate').val();
    let CertificateType = $('#CertificateType').val().trim();

    if (CertificateNumber.length == 0) {
        Toast('Certificate Number Required.', 'Message', 'error');
        $('#CertificateNumber').focus();
        return;
    }
    else if (CertificateNumber.length > 30) {
        Toast('Only 30 Character Allow In Certificate Number.', 'Message', 'error');
        $('#CertificateNumber').focus();
        return;
    }
    else if (CertificateType == "0" || CertificateType == undefined || CertificateType == '') {
        Toast('Certificate Code Required.', 'Message', 'error');
        $('#CertificateType').focus();
        return;
    }
    else if (CertificateDate.length > 0 && CertificateDate.length < 10) {
        Toast('Invalid Certificate Date', 'Message', 'error');
        $('#CertificateDate').focus();
        return;
    } else
        UpdateNewCertificateRow($('#NewRownNumCertificate').val());
});

//FUNCTION FOR NEW UPDATE BOND 
function UpdateNewCertificateRow(Rn) {
    let flag = 0;
    $("#TblCertificateDetails tbody tr").each(function (ind, ele) {
        if ($(ele).find('.TblCertificateNo').val().trim() == $('#CertificateNumber').val().trim() && $(ele).find('.rn').text().trim() != Rn) {
            flag = 1;
            return;
        }
    });
    if (flag == 1)
        Toast('Duplicate Certificate Number.', 'Message', 'error');
    else {
        $('#TblCertificateDetails tbody tr').each(function (ind, ele) {
            if ($(ele).find('.rn').text().trim() == Rn) {
                $(ele).find('.TblCertificateNo').val($('#CertificateNumber').val());
                $(ele).find('.TblCertificateDate').val($('#CertificateDate').val().trim());
                $(ele).find('.TblCertificateCode').val($('#CertificateType').val());
                ResetNewCertificate();
                Toast('Update Certificate Successfully.', 'Message', 'success');
            }
        });
    }
}

// FUNCTION FOR DELETE CERTIFICATE ROW ENTRY 
function DeleteCertificateRowEntry(e) {
    let CertificateNo = $(e).parent().parent().find('.TblCertificateNo').val().trim();

    if (CertificateNo.length == 0)
        Toast('Certificate Number Blank!. ', 'Message', 'error');
    else if ($('#NewAddCertificate').hasClass('d-none')) {
        Toast('Please Update Certificate.', 'Message', 'error');
    }
    else {
        $.confirm({
            title: '',
            content: 'Are You Sure Want To Delete ?',
            type: 'red',
            boxWidth: '300px',
            useBootstrap: false,
            typeAnimated: true,
            columnClass: 'small',
            containerFluid: true,
            draggable: true,
            buttons: {
                tryAgain: {
                    text: 'Confirm',
                    btnClass: 'btn-red',
                    action: function () {
                        let RowCount = $('#TblCertificateDetails tbody tr').length;
                        if (RowCount > 1)
                            $(e).parent().parent().remove();
                        else
                            $(e).parent().parent().find('.TblCertificateNo,.TblCertificateDate,.TblCertificateCode').val('');
                        GenerateSerialNumberTable('TblCertificateDetails', 'rn')
                    }
                },
                close: function () {
                }
            }
        });
    }
}

//NEWRESETCERTIFICATE BUTTON CLICK EVENT
$('#NewResetCertificate').click(function () {
    ResetNewCertificate(true);
})
//FUNCTION FOR RESET NEW CERTIFICATE 
function ResetNewCertificate(flag) {
    const blankCertificateId = ['CertificateNumber', 'CertificateDate'];

    blankCertificateId.forEach((ele) => {
        $('#' + ele).val('');
    });
    $('#CertificateType').val(0);
    $('#NewAddCertificate').removeClass('d-none');
    $('#NewUpdateCertificate').addClass('d-none');

    if (flag)
        $('#CertificateNumber').focus();
}

//FUNCTION FOR VALIDATE DESTUFF DETAILS DATA
function ValidateCertificateDetailsData() {
    let Vflag = 0;
    $("#TblCertificateDetails tbody tr").each(function (ind, ele) {
        if ($("#TblCertificateDetails tbody tr").length == 1) {
            let CerNo = $(ele).find('.TblCertificateNo').val();
            if (CerNo != '') {
                if ($(ele).find('.TblCertificateCode').val().trim().length <= 0) {
                    Toast('Please Enter Bond Code In Bond Details Row Number' + (ind + 1) + '', 'Message', 'error');
                    Vflag = 1;
                    return;
                }
            }
        }
        else {
            if ($(ele).find('.TblCertificateCode').val().trim().length <= 0) {
                Toast('Please Enter Bond Code In Bond Details Row Number' + (ind + 1) + '', 'Message', 'error');
                Vflag = 1;
                return;
            }
        }
    });

    return Vflag;
}

//#endregion 

//#region /****************************ESANCHIT DETAILS TAB ALL FUNCTION START****************************/


//#endregion

//#region /*******************NEW CODE BY PRINCE START*************************************/

var Ercount = 0;
let JobAssignIRNModal = document.getElementById('JobAssignIRN');
let FlatFileModal = document.getElementById('FlatFileModal');
let ItemESanchitModal = document.getElementById('ItemESanchitModal');


//FUNCTION FOR CLOSE FLAT FILE MODAL
function CloseFlatFileModal() {
    $('#FlatFileModalICEGATEUserId').val(0);
    $('#FlatFileJobUid').val('');
    FlatFileModal.style.display = 'none';
}

//CLOSE MODAL POPUP
$(document).keydown(function (event) {
    if (event.keyCode == 27) {
        FlatFileModal.style.display = "none";     
    }
});


//FLATFILEMODALSEARCH BUTTON CLICK EVENT
$('#FlatFileModalSearch').click(function () {
    let Id = $('#FlatFileModalICEGATEUserId').val();
    if (Id != null && Id != undefined) {
        if (Id == 0)
            Toast('Please Select Icegate Userid.', 'Message', 'error');
        else {
            const dataString = {};
            dataString.JobUid = $('#FlatFileJobUid').val();
            dataString.IceGateUserId = Id;
            AjaxSubmission(JSON.stringify(dataString), '/ImportJobEntry/GenerateFlatFile', $('[name="__RequestVerificationToken"]').val()).done(function (result) {
                let obj = result;
                if (obj.status == true) {
                    if (obj.responsecode == '100') {
                        CloseFlatFileModal();
                        Toast('BE File Saved Successfully.', 'Message', 'success');
                        setTimeout(() => {
                            DownLoadFlatFile(obj.data.Table[0].SubJobNo);
                        }, 1000);
                    }
                    else
                        Toast(RetrieveMessage(obj.responsecode), 'Message', 'error');
                } else
                    window.location.href = '/ClientLogin/ClientLogin';
            }).fail(function (data) {
                console.log(data.Message);
            });
        }
    }
});

//FUNCTION FOR CONVERT BASE64 TO BYTES
function Base64ToBytes(base64) {
    let s = window.atob(base64);
    let bytes = new Uint8Array(s.length);
    for (let i = 0; i < s.length; i++)
        bytes[i] = s.charCodeAt(i);
    return bytes;
};

//FUNCTION FOR GO TO LEDGER
function GoToLedger(e) {
    SetCookie('LedgerId', $("#" + e).val(), 's', 50);
}

//FUNCTION FOR GO TO LEDGER FOR CLASS
function GoToLedgerForClass(e, ClsName) {
    SetCookie('LedgerId', $(e).parent().parent().find('.' + ClsName).val(), 's', 50);
}

//FUNCTION FOR GO TO ITEM FOR CLASS
function GoToItemForClass(e, ClsName) {
    SetCookie('ItemId', $(e).parent().parent().find('.' + ClsName).val(), 's', 50);
}

//FUNCTION FOR GO TO CUSTOM PORT
function GoToCustomPort(e) {
    try {
        const datastring = {};
        datastring.CustomPortCode = $("#" + e).val();
        AjaxSubmission(JSON.stringify(datastring), "/Master/ImportJobEntry/GetCustomPortUid", $('input[name=__RequestVerificationToken]').val()).done(function (result) {
            let obj = result;
            if (obj.status == true) {
                if (obj.responsecode == '100')
                    SetCookie('CustomPortId', obj.data.Table[0].PortUid, 's', 50);
                else
                    SetCookie('CustomPortId', '', 's', 50);
                window.open('/Master/CustomPort/CustomPort', '_blank');
            }
            else
                window.location.href = '/ClientLogin/ClientLogin';
        }).fail(function (result) {
            console.log(result.Message);
        });
    }
    catch (e) {
        console.log(e.message);
    }
}

//FUNCTION FOR LOAD TINY MCE
function LoadTinyMCE() {
    tinymce.init({
        selector: ".tinymce",
        branding: false,
        theme: "modern",
        skin: "lightgray",
        width: "100%",
        height: 250,
        statubar: true,
        plugins: [
            "advlist autolink link image lists charmap print preview hr anchor pagebreak",
            "searchreplace wordcount visualblocks visualchars code fullscreen insertdatetime media nonbreaking",
            "save table contextmenu directionality emoticons template paste textcolor"
        ],
        toolbar: "insertfile undo redo | styleselect | bold italic | alignleft aligncenter alignright alignjustify | bullist numlist outdent indent | link | fontsizeselect | fontselect | image | print preview media fullpage | forecolor backcolor emoticons ",
        style_formats: [
            {
                title: "Headers", items: [
                    { title: "Header 1", format: "h1" },
                    { title: "Header 2", format: "h2" },
                    { title: "Header 3", format: "h3" },
                    { title: "Header 4", format: "h4" },
                    { title: "Header 5", format: "h5" },
                    { title: "Header 6", format: "h6" }
                ]
            },
            {
                title: "Inline", items: [
                    { title: "Bold", icon: "bold", format: "bold" },
                    { title: "Italic", icon: "italic", format: "italic" },
                    { title: "Underline", icon: "underline", format: "underline" },
                    { title: "Strikethrough", icon: "strikethrough", format: "strikethrough" },
                    { title: "Superscript", icon: "superscript", format: "superscript" },
                    { title: "Subscript", icon: "subscript", format: "subscript" },
                    { title: "Code", icon: "code", format: "code" }
                ]
            },
            {
                title: "Blocks", items: [
                    { title: "Paragraph", format: "p" },
                    { title: "Blockquote", format: "blockquote" },
                    { title: "Div", format: "div" },
                    { title: "Pre", format: "pre" }
                ]
            },
            {
                title: "Alignment", items: [
                    { title: "Left", icon: "alignleft", format: "alignleft" },
                    { title: "Center", icon: "aligncenter", format: "aligncenter" },
                    { title: "Right", icon: "alignright", format: "alignright" },
                    { title: "Justify", icon: "alignjustify", format: "alignjustify" }
                ]
            }
        ],
    });
}

//FUNCTION FOR CHANGE TEMPLATE DETAILS
function TemplateChange() {
    tinymce.get("EmailBody").setContent('');
    $('#Subject').val('');
    if ($('#AllTemplate').val() != null && $('#AllTemplate') != undefined) {
        if ($('#AllTemplate').val() != 0)
            FillTemplateDataInTincyMce($('#JobUid').val(), TemplateFor, $('#AllTemplate').val(), 'Email', 'Shipping Line Charges');
    }
}

//#endregion /****************NEW CODE BY PRINCE END*************************************/


//DOCUMENT UPLOAD ON CLICK FUNCTION FOR GET LIST OF DOCUMENT UPLOAD
$("#UploadDocument").click(function () {
    DocUploadResetdata();
    CommonFormList('JobDocUpload JDU INNER JOIN document_type_master DTM ON DTM.doc_type_uid =JDU.DocTypeUid', ' JDU.DocUploadUId, DTM.doc_type, JDU.FilePath,JDU.JobNo', 'FilePath');
});

//FUNCTION FOR AUTO FILL MBL NO 
$("#BillofLading").on('blur', function () {
    $("#MBLNo").val($("#BillofLading").val());
});
//FUNCTION FOR AUTO FILL MBL DATE
$("#BLDate").on('blur', function () {
    $("#MBLDate").val($("#BLDate").val());
});




