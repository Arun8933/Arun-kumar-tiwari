﻿var Firstcolumn = "";
$(document).on("click", ".pagination .page", function () {
    FormList(($(this).attr('page')));
});
//PAGE SIZE CLICKED
$("#ddlPageSize").change(function () {
    FormList(1);
});

//SEARCH BUTTON CLICKED
$("#FormSearch").click(function () {
    FormList(1);
});

$(document).ready(function () {
    Firstcolumn = "invoice_type";
    FillPageSizeList('ddlPageSize', FormList);

    $("#SearchStatus").select2({
        width: '100%'
    });
    $("#InvoiceTypeStatus").select2({
        width: '100%'
    });
    $("#InvoiceIdSearch").focus();
})

//FUNCTION FOR EXPORT DATA IN EXCEL
function FormExcel() {
    ShowLoader();
    let date = new Date();
    let NewDate = ("00" + date.getDate()).slice(-2) + "_" + ("00" + (date.getMonth() + 1)).slice(-2) + "_" + date.getFullYear() + "_" + ("00" + date.getHours()).slice(-2) + "_" + ("00" + date.getMinutes()).slice(-2) + "_" + ("00" + date.getSeconds()).slice(-2);
    let fileName = "InvoiceType_" + NewDate + ".xlsx";

    $('#FormSearch').trigger('click');
    AjaxSubmission(null, '/Master/InvoiceType/FormExcel', $('input[name=__RequestVerificationToken]').val()).done(function (result) {
        let obj = result;
        if (obj.status == true) {
            if (obj.responsecode == '100') {

                let bytes = Base64ToBytes(obj.data.FileData[0].Base64Data);
                let blob = new Blob([bytes], { type: "application/octetstream" });
                let isIE = false || !!document.documentMode;
                if (isIE) {
                    window.navigator.msSaveBlob(blob, fileName);
                } else {
                    let url = window.URL || window.webkitURL;
                    link = url.createObjectURL(blob);
                    let a = $("<a />");
                    a.attr("download", fileName);
                    a.attr("href", link);
                    $("body").append(a);
                    a[0].click();
                    $("body").remove(a);
                }
            }
            else if (obj.responsecode == '302')
                Toast("No Records found.", 'Message', 'success');
            else
                Toast(RetrieveMessage(obj.responsecode), 'Message', 'error');

        } else
            window.location.href = '/ClientLogin/ClientLogin';
        HideLoader();

    }).fail(function (result) {
        console.log(result.Message);
        HideLoader();
    });
}


// BIND INVOICE TYPE TABLE

function BindFormTable(result, serial_no) {

    $("#tbl_InvoiceType tbody tr").remove();

    if (result.length == 0) {
        tr = $('<tr/>');
        tr.append("<td class='text-center' colspan='9'>NO RESULTS FOUND</td>");
        $("#tbl_InvoiceType tbody").append(tr);
    }
    else {
        for (i = 0; i < result.length; i++) {
            if (result[i].is_active == "Inactive")
                tr = $(' <tr style="background-color:#fdd2d2;"/>');
            else
                tr = $('<tr/>');

            tr.append("<td class='text-center'><button type='button' onclick='FormEdit(\"" + result[i].invoicetype_id + "\");' class='common-btn common-btn-sm'><i class='fa-solid fa-pen-to-square'></i></button ><button type='button' onclick='FormDelete(\"" + result[i].invoicetype_id + "\");' class='common-btn common-btn-sm ms-1'> <i class='fa-regular fa-trash-can'></i></button ></td > ");
            tr.append("<td class='text-left'>" + serial_no + "</td>");
            tr.append("<td class='text-left'>" + result[i].invoicetype_id + "</td>");

            tr.append("<td class='text-center'><a href='javascript:void(0)' class='text-decoration-none' style='color: black !important;' onclick='FormEdit(\"" + result[i].invoicetype_id + "\");'>" + result[i].invoice_type + "</a></td>");
            tr.append("<td class='text-center'>" + HandleNullTextValue(result[i].invoice_desc) + "</td>");
            tr.append("<td class='text-center'>" + result[i].is_active + "</td>");




            serial_no++;

            $("#tbl_InvoiceType tbody").append(tr);

        }
    }
}


//INVOICE TYPE LIST PAGE INDEX
function FormList(pageindex) {
    try {
        const dataString = {};
        dataString.PageSize = $("#ddlPageSize").val();
        dataString.PageIndex = pageindex;
        dataString.Id = $("#InvoiceIdSearch").val().trim();
        dataString.InvoiceType = $("#InvoiceTypeSearch").val();
        dataString.Status = $("#SearchStatus").val();
        dataString.OrderBy = $("#sort-column").val().trim() + " " + $("#sort-type").val().trim();
        //ShowLoader();
        AjaxSubmission(JSON.stringify(dataString), "/Master/InvoiceType/FormList", $('input[name=__RequestVerificationToken]').val()).done(function (result) {

            let obj = result;

            if (obj.status == true) {
                if (obj.responsecode == '100') {
                    var ser = ((parseInt(obj.data.Table1[0].PageIndex) - 1) * parseInt(obj.data.Table1[0].PageSize)) + 1;
                    BindFormTable(obj.data.Table, ser);
                    if (obj.data.Table1 != undefined && obj.data.Table1.length > 0) {
                        $(".pagination").BindPaging({
                            ActiveCssClass: "current",
                            PagerCssClass: "pager",
                            PageIndex: parseInt(obj.data.Table1[0].PageIndex),
                            PageSize: parseInt(obj.data.Table1[0].PageSize),
                            RecordCount: parseInt(obj.data.Table1[0].count)
                        });
                    }

                }
                else {
                    Toast(RetrieveMessage(obj.responsecode), "Message", "error");
                }
            }
            else {
                window.location.href = '/ClientLogin/ClientLogin';
            }
            //HideLoader();
        }).fail(function (result) {
            console.log(result.Message);
            //HideLoader();
        });
    }
    catch (e) {
        console.log(e.message);
        //HideLoader();
    }
}


//FUNCTION FOR SORTING FIELD
function FormSorting(obj) {

    if (Firstcolumn != "") {
        document.getElementById(Firstcolumn).innerHTML = document.getElementById(Firstcolumn).getAttribute("data-column") + " <i style='margin-left:10px;' class='fa-solid fa-sort'></i>";
    }
    Firstcolumn = obj.id;
    var colname = $(obj).data("column");
    $("#sort-column").val(Firstcolumn);
    var sorttype = $("#sort-type").val();
    if (sorttype == "ASC") {
        $("#sort-type").val("DESC");
        $(obj).html(colname + " <i style='margin-left:10px;' class='fa-solid fa-sort-down'></i>");
    } else if (sorttype == "DESC") {
        $("#sort-type").val("ASC");
        $(obj).html(colname + " <i style='margin-left:10px;' class='fa-solid fa-sort-up'></i>");
    }
    FormList(1);
}


$("#FormAdd").click(function () {
    RemoveAllError('InvoiceType');
    ValidateAllFieldNewTest('InvoiceType');
    if (Ercount == 0) {
        FormAdd();
    }
});

//FUNCTION FOR INVOICE TYPE
function FormAdd() {
    try {
        const dataString = {};
        dataString.InvoiceType = $("#InvoicetypeName").val().trim();
        dataString.InvoiceDesc = $("#InvoiceDesc").val().trim();
        dataString.Status = $("#InvoiceTypeStatus").val();
        dataString.IsDefault = $("#IsDefault").is(":checked");
        ShowLoader();
        AjaxSubmission(JSON.stringify(dataString), "/Master/InvoiceType/FormAdd", $('input[name=__RequestVerificationToken]').val()).done(function (result) {
            let obj = result;
            if (obj.status == true) {
                if (obj.responsecode == '101') {
                    console.log(obj);
                    Toast(RetrieveMessage(obj.responsecode), "Message", "success");
                    setTimeout(FormList(1), 500);
                    $("#FormAdd").hide();
                    $("#FormUpdate").show();
                    $("#FormReset").show();
                    $("#InvoiceType-tab").html("Edit InvoiceType");
                    $("#InvoiceTypeId").val(obj.data.Table[0].invoicetype_id);
                    $("#Timestamp").val(obj.data.Table[0].timestamp);
                }
                else {
                    Toast(RetrieveMessage(obj.responsecode), "Message", "error");
                }
            }
            else {
                window.location.href = '/ClientLogin/ClientLogin';
            }
            HideLoader();
        }).fail(function (result) {
            console.log(result.Message);
            HideLoader();
        });
    }
    catch (e) {
        console.log(e.message);
        HideLoader();
    }
}


//FUNCTION FOR EDIT INVOICE TYPE
function FormEdit(InvoiceTypeId) {

    try {
        const dataString = {};

        dataString.InvoiceTypeId = parseInt(InvoiceTypeId);
        ShowLoader();
        AjaxSubmission(JSON.stringify(dataString), "/Master/InvoiceType/FormEdit", $('[name="__RequestVerificationToken"]').val()).done(function (data) {
            let obj = data;

            if (obj.status == true) {
                if (obj.responsecode == '100') {

                    TabShow();
                    $("#InvoiceTypeId").val(obj.data.Table[0].invoicetype_id);
                    $("#Timestamp").val(obj.data.Table[0].timestamp);
                    $("#InvoicetypeName").val(obj.data.Table[0].invoice_type);
                    $("#InvoiceDesc").val(obj.data.Table[0].invoice_desc);
                    if (obj.data.Table[0].is_active == true)
                        $("#InvoiceTypeStatus").val(1).trigger('change');
                    else
                        $("#InvoiceTypeStatus").val(0).trigger('change');
                    if (obj.data.Table[0].is_default == true)
                        $("#IsDefault").prop("checked", true);
                    else
                        $("#IsDefault").prop("checked", false);
                }
                else {
                    Toast(RetrieveMessage(obj.responsecode), "Message", "error");
                }
            }
            else {
                window.location.href = '/ClientLogin/ClientLogin';
            }
            HideLoader();
        }).fail(function (data) {
            console.log(data.Message);
            HideLoader();
        });

    }
    catch (e) {
        console.log(e.message);
        HideLoader();
    }
}

$("#FormUpdate").click(function () {
    RemoveAllError('InvoiceType');
    ValidateAllFieldNewTest('InvoiceType');
    if (Ercount == 0) {
        FormUpdate();
    }

});


//FUNCTION FOR INVOICE TYPE
function FormUpdate() {
    try {
        const dataString = {};
        dataString.InvoiceType = $("#InvoicetypeName").val().trim();
        dataString.InvoiceDesc = $("#InvoiceDesc").val().trim();
        dataString.Status = $("#InvoiceTypeStatus").val();
        dataString.Timestamp = $("#Timestamp").val();
        dataString.InvoiceTypeId = $("#InvoiceTypeId").val();
        dataString.IsDefault = $("#IsDefault").is(":checked");
        ShowLoader();
        AjaxSubmission(JSON.stringify(dataString), "/Master/InvoiceType/FormUpdate", $('input[name=__RequestVerificationToken]').val()).done(function (result) {
            let obj = result;
            if (obj.status == true) {
                if (obj.responsecode == '107') {
                    Toast(RetrieveMessage(obj.responsecode), "Message", "success");
                    setTimeout(FormList(1), 500);
                    $("#InvoiceTypeId").val(obj.data.Table[0].invoicetype_id);
                    $("#Timestamp").val(obj.data.Table[0].timestamp);

                }
                else {
                    Toast(RetrieveMessage(obj.responsecode), "Message", "error");
                }
            }
            else {
                window.location.href = '/ClientLogin/ClientLogin';
            }
            HideLoader();
        }).fail(function (result) {
            console.log(result.Message);
            HideLoader();
        });
    }
    catch (e) {
        console.log(e.message);
        HideLoader();
    }

}



//FUNCTION FOR DELETE INVOICE TYPE
function FormDelete(e) {
    try {
        $.confirm({
            title: '',
            content: 'Are You Sure Want To Delete ?',
            type: 'red',
            boxWidth: '300px',
            useBootstrap: false,
            columnClass: 'small',
            containerFluid: true,
            typeAnimated: true,
            buttons: {
                tryAgain: {
                    text: 'Confirm',
                    btnClass: 'btn-red',
                    action: function () {

                        const datastring = {};
                        datastring.InvoiceTypeId = parseInt(e);
                        ShowLoader();
                        AjaxSubmission(JSON.stringify(datastring), "/Master/InvoiceType/FormDelete", $('[name="__RequestVerificationToken"]').val()).done(function (data) {
                            let obj = data;
                            if (obj.status == true) {
                                if (obj.responsecode == '102') {
                                    Toast(RetrieveMessage(obj.responsecode), "Message", "success");
                                    FormList(1);
                                }
                                else {
                                    Toast(RetrieveMessage(obj.responsecode), "Message", "error");
                                }
                            }
                            else {
                                window.location.href = 'ClientLogin/ClientLogin';
                            }
                            HideLoader();
                        }).fail(function (data) {
                            console.log(data.Message);
                            HideLoader();
                        });
                    }
                },
                close: function () {

                }
            }
        });
    }
    catch (e) {
        console.log(e.message);
        HideLoader();
    }
}
//FUNCTION FOR REST INPUT TYPE FIELD
function ResetForm() {

    $("#InvoicetypeName").val("");
    $("#InvoiceDesc").val("");
    $("#IsDefault").prop("checked", false);
    $("#FormAdd").show();
    $("#FormUpdate").hide();
    $("#FormReset").hide();
    $("#InvoiceTypeId").val("");
    $("#Timestamp").val("");
    $("#InvoiceType-tab").html("Add InvoiceType");
};


//FUCNTION FOR TAB SHOW
function TabShow() {
    $('#InvoiceType_list-tab').removeClass('active');
    $('#InvoiceType-tab').addClass('active');
    $('#InvoiceType_list').removeClass('active show');
    $('#InvoiceType').addClass('active show');
    $("#FormAdd").hide();
    $("#FormUpdate").show();
    $("#FormReset").show();
    $("#InvoiceType-tab").html("Edit InvoiceType");
}

//FUNCTION FOR TAB HIDE
function TabHide() {
    $('#InvoiceType-tab').removeClass('active');
    $('#InvoiceType_list-tab').addClass('active ');
    $('#InvoiceType_list').addClass('active show');
    $('#InvoiceType').removeClass('active show');
    $("#FormAdd").show();
    $("#FormUpdate").hide();
    $("#FormReset").hide();
    $("#InvoiceType-tab").html("Add InvoiceType");
}

//MENU LIST TAB CLICKED
$("#InvoiceType_list-tab").click(function () {
    RemoveAllError('InvoiceType');
    ResetForm();
})
$(".InvoiceType_list").click(function () {
    $("#InvoiceIdSearch").focus();
})
$("#FormReset").click(function () {
    ResetForm();
});

document.addEventListener("keydown", function (zEvent) {
    if (zEvent.ctrlKey && zEvent.altKey && (zEvent.key == "j" || zEvent.key == "J")) {
        $('#InvoiceType_list-tab').removeClass('active ');
        $('#InvoiceType_list').removeClass('active show');
        $('#InvoiceType-tab').addClass('active');
        $('#InvoiceType').addClass('active show');
        $("#FormAdd").show();
        $("#FormUpdate").hide();
        $("#FormReset").hide();
        $("#InvoiceType-tab").html("Add Branch");
        $('#InvoicetypeName').focus();
        ResetForm();
    }
});
