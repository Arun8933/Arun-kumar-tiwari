﻿
var DateFrom = "";
var DateTo = "";
var Count;
// DOCUMENT ON READY FUNCTION
$(document).ready(function () {
    $(".datepickerAll").datepicker({
        changeMonth: true,
        changeYear: true,
        dateFormat: 'dd/mm/yy'
    });
    $(".datepickerAll").datepicker('setDate', 'today');
})

$("#FormSearch").click(function () {
    if ($("#SearchDateTo").val() == '') {
        Toast("Please Select Date!", 'Message', 'error');
    }
    else {
        $(".ReportDNone").show();
        FormList();
    }
});


//FUNCTION FOR FILL PROFIT LOSS STATEMENT
function FormList() {
    try {
        const dataString = {};
        dataString.Date = $("#SearchDateTo").val();
        ShowLoader();
        AjaxSubmission(JSON.stringify(dataString), "/Master/ExchangeRate/FormList", $('input[name=__RequestVerificationToken]').val()).done(function (result) {
            let obj = result;
            console.log(obj);
            if (obj.status == true) {
                if (obj.responsecode == '100') {
                    BindFormTable(obj.data.Table);
                }
                else
                    Toast(RetrieveMessage(obj.responsecode), "Message", "error");
            }
            else
                window.location.href = '/ClientLogin/ClientLogin';
            HideLoader();
        }).fail(function (result) {
            console.log(result.Message);
            HideLoader();
        });
    }
    catch (e) {
        console.log(e.message);
        HideLoader();
    }
}


//FUNCTION FOR BIND EXCHANGE RATE LIST TABLE
function BindFormTable(Result) {
    $("#tbl_ExchangeRate tbody tr").remove();
    if (Result.length == 0) {
        tr = $('<tr/>');
        tr.append("<td class='text-center' colspan='8'>NO RESULTS FOUND</td>");
        $("#tbl_ExchangeRate tbody").append(tr);
    }
    else {
        for (i = 0; i < Result.length; i++) {
            tr = $('<tr/>');
            tr.append("<td class='text-center'> <input type='text' id='CurrencyCode' name='CurrencyCode' class='CurrencyCode text-end form-control form-control-md textbox-height mybox' value='" + Result[i].CurrencyCode + "' disabled/></td>")
            tr.append("<td class='text-end ' >   <input type='text' id='ImportExchangeRate' name='ImportExchangeRate' class='ImportExchangeRate text-end form-control form-control-md textbox-height mybox' value='" + Result[i].ImportExchangeRate.toFixed(2) + "' /></td>")
            tr.append("<td class='text-end ' > <input type='text' id='ExportExchangeRate' name='ExportExchangeRate' class='ExportExchangeRate text-end form-control form-control-md textbox-height mybox' value='" + Result[i].ExportExchangeRate.toFixed(2) + "' /></td>")
            tr.append("<td class='text-center ' > <input type='text' id='SearchDate' name='SearchDate' class='SearchDate datepickerAll1 form-control form-control-md textbox-height mybox' value='" + HandleNullTextValue(Result[i].Date) + "'  placeholder='dd/mm/yyyy'/></td>")
            $("#tbl_ExchangeRate tbody").append(tr);
        }
        $(".datepickerAll1").datepicker({
            changeMonth: true,
            changeYear: true,
            dateFormat: 'dd/mm/yy'
        });
    }
}

$("#FormUpdate").click(function () {
    UpdateExchangeRate();
});


// FUNCTION FOR UPDATE USER RIGHTS
function UpdateExchangeRate() {
    try {
        debugger
        const dataString = {};
        var ExchangeRateData = new Array();
        $('#tbl_ExchangeRate tbody tr').each(function (index, ele) {
            var ExchangeRate = {};
            var ImportExchangeRate = $(ele).find('.ImportExchangeRate').val();
            var ExportExchangeRate = $(ele).find('.ExportExchangeRate').val();
            var CurrencyCode = $(ele).find('.CurrencyCode').val();
            var SearchDate = $(ele).find('.SearchDate').val();
            if ((ImportExchangeRate > 0) || (ExportExchangeRate > 0) && SearchDate.length == 10) {
                ExchangeRate.ImportExchangeRate = ImportExchangeRate
                ExchangeRate.ExportExchangeRate = ExportExchangeRate;
                ExchangeRate.SearchDate = SearchDate;
                ExchangeRate.CurrencyCode = CurrencyCode;
                ExchangeRateData.push(ExchangeRate);
            }
        });
        console.log(ExchangeRateData);
        dataString.ExchangeRateModels = ExchangeRateData;
        AjaxSubmission(JSON.stringify(dataString), "/ExchangeRate/UpdateExchangeRate", $('[name="__RequestVerificationToken"]').val()).done(function (data) {
            let obj = data;
            if (obj.status == true) {
                if (obj.responsecode == '107') {
                    Toast(RetrieveMessage(107), 'message', 'success');
                    /*   $("#tbl_ExchangeRate").empty();*/
                    $("##FormSearch").trigger;
                }
                else
                    Toast(RetrieveMessage(obj.responsecode), "Message", "error");
            }
            else
                window.location.href = '/ClientLogin/ClientLogin';
            //Hideloader();
        }).fail(function (data) {
            //Hideloader();
            console.log(data.Message);
        });
    }
    catch (e) {
        console.log(e.message);
        //Hideloader();
    }
}
