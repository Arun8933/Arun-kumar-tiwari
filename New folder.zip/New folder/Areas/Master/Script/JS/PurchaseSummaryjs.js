﻿// DOCUMENT READY FUNCTION 
$(document).ready(function () {
    FillReportNameList('ReportName', 'Purchase Summary');
    $(".datepickerAll").datepicker({
        changeMonth: true,
        changeYear: true,
        dateFormat: 'dd/mm/yy',
        toolbarPlacement: "bottom",
        showButtonPanel: true,
    });
    GetFinancialYearDate('PurchaseDateFrom', 'PurchaseDateTo');
    LoadTinyMCE();
});

//FUNCTION FOR GET FINANCIAL YEAR DATE
function GetFinancialYearDate(start, end) {
    try {
        AjaxSubmission(null, '/Master/_Layout/GetFinancialYearDate', $('[name="__RequestVerificationToken"]').val()).done(function (result) {
            let obj = result;

            if (obj.status == true) {
                if (obj.responsecode == '100') {
                    $("#" + start).val(obj.data.Table[0].finyr_start_date);
                    $("#" + end).val(obj.data.Table[0].finyr_end_date);
                }
            }
            else
                window.location.href = '/ClientLogin/ClientLogin';
            //Hideloader();

        }).fail(function (result) {
            //Hideloader();
            console.log(result.message);

        });
        //Hideloader();
    }
    catch (e) {
        //Hideloader();
        console.log(e.message);
    }
}


$("#Search").click(function () {
    $("#CheckVal").val('false');
    if ($("#ReportName").val() == "0") {
        Toast('Please Select Report Name !', 'Message', 'error');
        return;
    }
    GetPurchaseSummary();
});
function GetPurchaseSummary() {
    try {
        const dataString = {};
        dataString.ReportName = $("#ReportName").val();
        dataString.BillDateFrom = $("#PurchaseDateFrom").val();
        dataString.BillDateTo = $("#PurchaseDateTo").val();
        dataString.JobDateFrom = $("#JobDateFrom").val();
        dataString.JobDateTo = $("#JobDateTo").val();
        dataString.SubJobNo = $("#SubJobNo").val();
        dataString.JobNo = $("#JobNo").val();
        dataString.ImporterName = $("#HiddenImporterName").val();
        //dataString.BillType = $("#BillType").val();
        //   dataString.SoldTo = $("#HiddenSoldTo").val();
        //  dataString.Expense = $("#HiddenExpense").val();
        //  dataString.Shipper = $("#HiddenShipper").val();
        ///dataString.Indentor = $("#HiddenIndentor").val();
        // dataString.ShippingLine = $("#HiddenShippingLine").val();
        // dataString.CFSType = $("#HiddenCFSType").val();
        // dataString.HSSeller = $("#HiddenHSSeller").val();
        dataString.BillOption = $('input:radio[name=PurchaseOption]:checked').val();
        dataString.SendEmail = $("#CheckVal").val();
        dataString.ExcelCheck = $("#ExcelCheck").val();
        ShowLoader();
        AjaxSubmission(JSON.stringify(dataString), '/Master/PurchaseSummary/GetPurchaseSummary', $('input[name=__RequestVerificationToken]').val()).done(function (result) {
            let obj = result;
            console.log(obj);
            if (obj.status == true) {
                if (obj.responsecode == '100') {
                    if ($("#CheckVal").val() == "false" && $('#ExcelCheck').val() == '0')
                        window.open($("#MyReport").attr('href'), '_blank');
                    else if ($("#CheckVal").val() == "true") {
                        EmailModal.style.display = "block";
                        $("#EmailTo").val(obj.data.Table2[0].EmailTo);
                        $("#EmailCC").val(obj.data.Table1[0].CCEmail);
                        $("#EmailLetterName").val(obj.data.Table1[0].LetterName);

                        $("#AttachFileName").text(obj.data.Table1[0].FileName);
                        $("#AttachFileName").attr("href", obj.data.Table1[0].FilePath);
                        $("#AttachedFilePath").val(obj.data.Table1[0].AttachmentFilePath);

                        $("#RefId").val($("#LetterAssignId").val());
                        $("#SendToName").val($("#ImporterName").val());
                        $("#RefName").val('PurchaseSummaryReport');
                        $("#Subject").val($("#ReportName").val());

                        BindTemplateName('AllTemplate', 'Email');
                        FillTemplateDataInTincyMce("", "PurchaseSummary", null, 'Email');
                    }

                }
                else if (obj.responsecode == '703')
                    Toast(obj.error, "Message", "error");
                else
                    Toast(RetrieveMessage(obj.responsecode), "Message", "error");

            } else
                window.location.href = '/ClientLogin/ClientLogin';
            HideLoader();
        }).fail(function (result) {
            console.log(result.Message);
            HideLoader();
        });
    }
    catch (e) {
        console.log(e.message);
        HideLoader();
    }
}


$("#OpenEmailModel").click(function () {
    $("#CheckVal").val('true');
    if ($("#ReportName").val() == "0") {
        Toast('Please Select Report Name !', 'Message', 'error');
        return;
    }
    GetPurchaseSummary();
});


//FUNCTION FOR TINYMCE EDITIOR
function LoadTinyMCE() {
    tinymce.init({
        selector: ".tinymce",
        branding: false,
        theme: "modern",
        skin: "lightgray",
        width: "100%",
        height: 250,
        statubar: true,
        plugins: [
            "advlist autolink link image lists charmap print preview hr anchor pagebreak",
            "searchreplace wordcount visualblocks visualchars code fullscreen insertdatetime media nonbreaking",
            "save table contextmenu directionality emoticons template paste textcolor"
        ],
        toolbar: "insertfile undo redo | styleselect | bold italic | alignleft aligncenter alignright alignjustify | bullist numlist outdent indent | link | fontsizeselect | fontselect | image | print preview media fullpage | forecolor backcolor emoticons ",
        style_formats: [
            {
                title: "Headers", items: [
                    { title: "Header 1", format: "h1" },
                    { title: "Header 2", format: "h2" },
                    { title: "Header 3", format: "h3" },
                    { title: "Header 4", format: "h4" },
                    { title: "Header 5", format: "h5" },
                    { title: "Header 6", format: "h6" }
                ]
            },
            {
                title: "Inline", items: [
                    { title: "Bold", icon: "bold", format: "bold" },
                    { title: "Italic", icon: "italic", format: "italic" },
                    { title: "Underline", icon: "underline", format: "underline" },
                    { title: "Strikethrough", icon: "strikethrough", format: "strikethrough" },
                    { title: "Superscript", icon: "superscript", format: "superscript" },
                    { title: "Subscript", icon: "subscript", format: "subscript" },
                    { title: "Code", icon: "code", format: "code" }
                ]
            },
            {
                title: "Blocks", items: [
                    { title: "Paragraph", format: "p" },
                    { title: "Blockquote", format: "blockquote" },
                    { title: "Div", format: "div" },
                    { title: "Pre", format: "pre" }
                ]
            },
            {
                title: "Alignment", items: [
                    { title: "Left", icon: "alignleft", format: "alignleft" },
                    { title: "Center", icon: "aligncenter", format: "aligncenter" },
                    { title: "Right", icon: "alignright", format: "alignright" },
                    { title: "Justify", icon: "alignjustify", format: "alignjustify" }
                ]
            }
        ],
    });
}

//FUNCTION FOR CHANGE TEMPLATE DETAILS
function TemplateChange() {
    tinymce.get("EmailBody").setContent('');
    $('#Subject').val('');
    if ($('#AllTemplate').val() != null && $('#AllTemplate') != undefined) {
        if ($('#AllTemplate').val() != 0)
            FillTemplateDataInTincyMce('', 'PurchaseSummary', $('#AllTemplate').val(), 'Email');
    }
}



//FUNCTION FOR EXPORT DATA IN EXCEL
function FormExcel() {
    $('#ExcelCheck').val('1');

    $("#CheckVal").val('false');
    if ($("#ReportName").val() == "0") {
        Toast('Please Select Report Name !', 'Message', 'error');
        return;
    }
    GetPurchaseSummary();
    ShowLoader();
    let date = new Date();
    let NewDate = ("00" + date.getDate()).slice(-2) + "_" + ("00" + (date.getMonth() + 1)).slice(-2) + "_" + date.getFullYear() + "_" + ("00" + date.getHours()).slice(-2) + "_" + ("00" + date.getMinutes()).slice(-2) + "_" + ("00" + date.getSeconds()).slice(-2);
    let fileName = "PurchaseSummary_" + NewDate + ".xlsx";

    $('#FormSearch').trigger('click');
    AjaxSubmission(null, '/Master/PurchaseSummary/FormExcel', $('input[name=__RequestVerificationToken]').val()).done(function (result) {
        let obj = result;
        if (obj.status == true) {
            if (obj.responsecode == '100') {
                $('#ExcelCheck').val('0');

                let bytes = Base64ToBytes(obj.data.FileData[0].Base64Data);
                let blob = new Blob([bytes], { type: "application/octetstream" });
                let isIE = false || !!document.documentMode;
                if (isIE) {
                    window.navigator.msSaveBlob(blob, fileName);
                } else {
                    let url = window.URL || window.webkitURL;
                    link = url.createObjectURL(blob);
                    let a = $("<a />");
                    a.attr("download", fileName);
                    a.attr("href", link);
                    $("body").append(a);
                    a[0].click();
                    $("body").remove(a);
                }
            }
            else if (obj.responsecode == '302')
                Toast('No Records found.', 'Message', 'success');
            else
                Toast(RetrieveMessage(obj.responsecode), 'Message', 'error');

        } else
            window.location.href = '/ClientLogin/ClientLogin';
        HideLoader();

    }).fail(function (result) {
        console.log(result.Message);
        HideLoader();
    });
}

