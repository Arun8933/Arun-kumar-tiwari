﻿

$("#DownloadFile").click(function () {
    var name = $("#TableName").val();
    var ext = $("#FileFormat").val();
    var filename = name + "." + ext;
    if ($("#TableName").val() == "0") {
        Toast(RetrieveMessage(1049), 'Message', 'error');
        return;
    }  
    DownloadSampleFile(filename, ext);
 

});

function FileCheck(e) {
    console.log($('#ExcelFile').prop('files')[0]);
    console.log($('#ExcelFile').prop('files')[0].name);
   
    var FileSize = Math.round(parseFloat($(e).prop('files')[0].size / 1024).toFixed(2));
    FileName = $(e).prop('files')[0].name;
    FileExtension = FileName.substring(FileName.indexOf('.'), FileName.length);
    
    const FE = [".xls", ".xlsx", ".csv"];
   
    if(FE.indexOf(FileExtension) == -1){
        Toast("Only(.xls,.xlsx,.csv) are Supported.", 'Message', 'error');
        $(e).val('');
        return false;
    }
   
    if (FileSize > 1024) {
        Toast("File too Big, please select a file less than 1mb !", 'Message', 'error');
        $(e).val('');
        return false;
    }
}

$("#UploadFile").click(function () {
    try {

        if ($("#TableName").val() == "0") {
            Toast(RetrieveMessage(1049), 'Message', 'error');
            return;
        }
        if ($('#ExcelFile')[0].files.length == 0) {
            Toast(RetrieveMessage(607), 'Message', 'error');
            return;
        }

        var FileSize = Math.round(parseFloat($('#ExcelFile').prop('files')[0].size / 1024).toFixed(2));
        FileName = $('#ExcelFile').prop('files')[0].name;
        FileExtension = FileName.substring(FileName.indexOf('.'), FileName.length);
        console.log(FileSize);
        const FE = [".xls", ".xlsx", ".csv"];
        if (FE.indexOf(FileExtension) == -1) {
            Toast("Only(.xls,.xlsx,.csv) are Supported.", 'Message', 'error');
            $('ExcelFile').val('');
            return false;
        }

        if (FileSize > 2500) {
            Toast("File too Big, please select a file less than 1mb !", 'Message', 'error');
            $('ExcelFile').val('');
            return false;
        }

       
        var form = $('#myform')[0];
        var TableName = $("#TableName").val();
        var mydata = new FormData(form);
        mydata.append('TableName', TableName);

        ShowLoader();
        AjaxSubmissionformdata(mydata, "/ImportMaster/ImportExcel", $('[name="__RequestVerificationToken"]').val()).done(function (data) {
            let obj = data;
            if (obj.status == true) {
                console.log(obj);
                if (obj.responsecode == '1052') {
                    Toast(RetrieveMessage(obj.responsecode), 'Message', 'error')
                    var bytes = Base64ToBytes(obj.data[0].RawData);
                    var Ext = obj.data[0].FileExt;

                    //Convert Byte Array to BLOB.
                    var blob = new Blob([bytes], { type: "application/octetstream" });

                    //Check the Browser type and download the File.
                    var isIE = false || !!document.documentMode;
                    if (isIE) {
                        window.navigator.msSaveBlob(blob, "Tmp" + obj.data[0].FileExt);
                    } else {
                        var url = window.URL || window.webkitURL;
                        link = url.createObjectURL(blob);
                        var a = $("<a />");
                        a.attr("download", "Tmp" + obj.data[0].FileExt);
                        a.attr("href", link);
                        $("body").append(a);
                        a[0].click();
                        $("body").remove(a);
                    }
                }
                else if (obj.responsecode == "100") {
                    Toast(obj.error, 'Message', 'success', 2500);
                    $('#ExcelFile').val('');
                }
                else if (obj.responsecode == "1051")
                    Toast(obj.error + " Column Not Found.", 'Message', 'error', 2500);
                    
                else
                    Toast(RetrieveMessage(obj.responsecode), 'Message', 'error',2500);
            }
            else
                window.location.href = '/ClientLogin/ClientLogin';
            HideLoader();
        }).fail(function (data) {
            console.log(data.Message);
            HideLoader();
        });
    }
    catch(e) {
        console.log(e.message);
        HideLoader();
    }
    
});


//FUNCTION FOR CONVERT BASE64 TO BYTES
function Base64ToBytes(base64) {
    var s = window.atob(base64);
    var bytes = new Uint8Array(s.length);
    for (var i = 0; i < s.length; i++) {
        bytes[i] = s.charCodeAt(i);
    }
    return bytes;
};


//FUNCTION FOR DOWNLOAD SAMPLE FILE
function DownloadSampleFile(filename,ext) {
    try {
        const dataString = {};
        dataString.FileName = filename;
        dataString.Ext = ext;
        console.log(JSON.stringify(dataString));
        AjaxSubmission(JSON.stringify(dataString), "/ImportMaster/DownloadSampleFile", $('[name="__RequestVerificationToken"]').val()).done(function (data) {
            let obj = data;
            if (obj.status == true) {
                if (obj.responsecode == '100') {
                    console.log(obj);
                    var bytes = Base64ToBytes(obj.data[0].RawData);
                    var Ext = obj.data[0].FileExt;

                    //Convert Byte Array to BLOB.
                    var blob = new Blob([bytes], { type: "application/octetstream" });

                    //Check the Browser type and download the File.
                    var isIE = false || !!document.documentMode;
                    if (isIE) {
                        window.navigator.msSaveBlob(blob, filename + Ext);
                    } else {
                        var url = window.URL || window.webkitURL;
                        link = url.createObjectURL(blob);
                        var a = $("<a />");
                        a.attr("download", filename);
                        a.attr("href", link);
                        $("body").append(a);
                        a[0].click();
                        $("body").remove(a);
                    }
                }
            }
            else
                window.location.href = '/ClientLogin/ClientLogin';           
        }).fail(function (data) {
            console.log(data.Message);           
        });
    }
    catch (e) {
        console.log(e.message);        
    }
};