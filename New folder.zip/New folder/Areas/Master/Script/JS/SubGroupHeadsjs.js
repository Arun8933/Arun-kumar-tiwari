﻿var Firstcolumn = "";
var groupmodal = document.getElementById('GroupHeadModal');
$("#GroupId").select2({ width: '100%' });
$("#GroupIdSearch").select2({ width: '100%' });

//if (Get_Cookie("SubGroupId") != null) {
//    var a = setInterval(() => {
//        if ($("#GroupId").val() != null) {
//            if (Get_Cookie("SubGroupId") != '' && Get_Cookie("SubGroupId") != 0) {
//                FormEdit(Get_Cookie("SubGroupId"));
//            } else {
//                $('#SubGroupHead_list-tab').removeClass('active');
//                $('#SubGroupHead-tab').addClass('active');
//                $('#SubGroupHead_list').removeClass('active show');
//                $('#SubGroupHead').addClass('active show');
//                $("#FormAdd").show();
//                $("#FormUpdate").hide();
//                $("#SubGroupHead-tab").html("Add Sub Group");

//            }
//            EraseCookie('SubGroupId');
//            clearInterval(a);
//        }
//    }, 100);
//}

//FUNCTION DOCUMENT READY
$(document).ready(function () {
    ShowLoader();
    //if (Get_Cookie("SubGroupId") == null)
    //    FillPageSizeList('ddlPageSize', FormList, localStorage.getItem('PageName'));
    //else
    FillPageSizeList('ddlPageSize', FormList);


    FillGroupList('GroupIdSearch');
    FillGroupList('GroupId');
    $("#SearchSubGroupId").focus();
    HideLoader();
});
//WHEN THE USER CLICKS ANYWHERE OUTSIDE OF THE MODAL, CLOSE IT
window.onclick = function (event) {
    if (event.target == modal) {
        groupmodal.style.display = "none";
        ResetGroupForm();
    }
}
//FILL SUBGROUP HEAD TABLE FUNCTION
function FormList(pageindex) {
    try {

        const dataString = {};
        dataString.PageSize = $("#ddlPageSize").val();
        dataString.PageIndex = pageindex;
        dataString.SubGroupId = $("#SearchSubGroupId").val().trim();
        dataString.GroupId = $("#GroupIdSearch").val();
        dataString.SubGroupName = $("#SearchSubGroupName").val().trim();
        dataString.OrderBy = $("#sort-column").val().trim() + " " + $("#sort-type").val().trim();
        //Showloader();
        AjaxSubmission(JSON.stringify(dataString), "/Master/SubGroupHeads/FormList", $('input[name=__RequestVerificationToken]').val()).done(function (result) {
            let obj = result;
            if (obj.status == true) {
                if (obj.responsecode == '100') {
                    var ser = ((parseInt(obj.data.Table1[0].PageIndex) - 1) * parseInt(obj.data.Table1[0].PageSize)) + 1;
                    BindFormTable(obj.data.Table, ser);
                    if (obj.data.Table1 != undefined && obj.data.Table1.length > 0) {
                        $(".pagination").BindPaging({
                            ActiveCssClass: "current",
                            PagerCssClass: "pager",
                            PageIndex: parseInt(obj.data.Table1[0].PageIndex),
                            PageSize: parseInt(obj.data.Table1[0].PageSize),
                            RecordCount: parseInt(obj.data.Table1[0].count)
                        });
                    }

                }
                else {
                    Toast(RetrieveMessage(obj.responsecode), "Message", "error");
                }
            }
            else {
                window.location.href = '/ClientLogin/ClientLogin';
            }
            //Hideloader();
        }).fail(function (result) {
            console.log(result.Message);
            //Hideloader();
        });
    }
    catch (e) {
        console.log(e.message);
        //Hideloader();
    }
}

//BIND SUBGROUP HEAD TABLE FUNCTION
function BindFormTable(Result, SerialNo) {
    $("#TblSubgroup tbody tr").remove();

    if (Result.length == 0) {
        tr = $('<tr/>');
        tr.append("<td class='text-center' colspan='5'>NO RESULTS FOUND</td>");
        $("#TblSubgroup tbody").append(tr);
    }
    else {
        for (i = 0; i < Result.length; i++) {
            if (Result[i].is_active == "Inactive") {
                tr = $(' <tr style="background-color:#fdd2d2;"/>');
            }
            else {
                tr = $('<tr/>');
                tr.append("<td class='text-center'><button type='button' onclick='FormEdit(\"" + Result[i].SubgroupHeadUid + "\");' class= 'common-btn common-btn-sm'><i class='fa-solid fa-pen-to-square'></i></button ><button type='button' onclick='FormDelete(\"" + Result[i].SubgroupHeadUid + "\");' class= 'common-btn common-btn-sm ms-1'> <i class='fa-regular fa-trash-can'></i></button ></td > ");
                tr.append("<td class='text-left'>" + SerialNo + "</td>");
                tr.append("<td class='text-left'>" + Result[i].SubgroupHeadUid + "</td>");
                tr.append("<td class='text-center'>" + Result[i].GroupHeadName + "</td>");
                tr.append("<td class='text-center'><a href='javascript:void(0)' class='text-decoration-none ' style='color: black !important;' onclick='FormEdit(\"" + Result[i].SubgroupHeadUid + "\");'>" + Result[i].SubgroupHeadName + "</a></td>");

            }

            SerialNo++;

            $("#TblSubgroup tbody").append(tr);

        }

    }
}

//PAGINATION PREVIOUS NEXT BUTTON CLICK
$(document).on("click", ".pagination .page", function () {
    FormList(($(this).attr('page')));
});

//PAGE SIZE CHANGE 
$("#ddlPageSize").change(function () {
    FormList(1);
});

//SEARCH BUTTON CLICK
$("#FormSearch").click(function () {
    FormList(1);
});
function FormSorting(obj) {
    if (Firstcolumn != "") {
        document.getElementById(Firstcolumn).innerHTML = document.getElementById(Firstcolumn).getAttribute("data-column") + " <i class='fa-solid fa-sort'></i>";
    }
    let cn = obj.id;
    Firstcolumn = cn;
    var colname = $(obj).data("column");
    $("#sort-column").val(cn.replaceAll("_", ""));
    var sorttype = $("#sort-type").val();
    if (sorttype == "ASC") {
        $("#sort-type").val("DESC");
        $(obj).html(colname + " <i style='margin-left:10px;' class='fa-solid fa-sort-up'></i>");
    } else if (sorttype == "DESC") {
        $("#sort-type").val("ASC");
        $(obj).html(colname + " <i style='margin-left:10px;' class='fa-solid fa-sort-down'></i>");
    }
    FormList(1);
}

//SUBGROUP ADD BUTTON CLICK
$("#FormAdd").click(function () {

    RemoveAllError('SubGroupHead');
    ValidateAllFieldNewTest('SubGroupHead');

    if (Ercount == 0) {
        if ($("#GroupId").val() == "0") {
            Toast(RetrieveMessage(805), 'Message', 'error');
            return;
        }
        FormAdd();
    }
});

//ADD SUBGROUP FUNCTION
function FormAdd() {
    try {
        const datastring = {};
        datastring.SubGroupName = $("#SubGroupName").val();
        datastring.GroupId = $("#GroupId").val();
        datastring.OrderPlBs = $("#OrderNo").val();
        datastring.DetailPlBs = $("#DetailPlBs").is(":checked");
        datastring.AcceptAddress = $("#AcceptAddress").is(":checked");

        ShowLoader();
        AjaxSubmission(JSON.stringify(datastring), "/Master/SubGroupHeads/FormAdd", $('input[name=__RequestVerificationToken]').val()).done(function (result) {
            let obj = result;
            if (obj.status == true) {
                if (obj.responsecode == '101') {
                    Toast(RetrieveMessage(obj.responsecode), "Message", "success");
                    setTimeout(FormList(1), 500);
                    $("#SubGroupHead-tab").html("Edit Sub Group");
                    $("#FormAdd").hide();
                    $("#FormUpdate").show();
                    $("#FormReset").show();
                    $("#SubGroupId").val(obj.data.Table[0].SubgroupHeadUid);
                    $("#Timestamp").val(obj.data.Table[0].Timestamp);
                }
                else {
                    Toast(RetrieveMessage(obj.responsecode), "Message", "error");
                }
            }
            else {
                window.location.href = '/ClientLogin/ClientLogin';
            }
            HideLoader();
        }).fail(function (result) {
            console.log(result.Message);
            HideLoader();
        });
    }
    catch (e) {
        console.log(e.message);
        HideLoader();
    }
}

//EDIT SUBGROUP FUNCTION
function FormEdit(e) {
    try {
        const datastring = {};
        datastring.SubGroupId = e;
        ShowLoader();
        AjaxSubmission(JSON.stringify(datastring), "/Master/SubGroupHeads/FormEdit", $('[name="__RequestVerificationToken"]').val()).done(function (data) {
            let obj = data;
         
            if (obj.status == true) {
                if (obj.responsecode == '100') {
                    TabShow();
                    if (obj.data.Table[0].SystemAccount == true) {
                        $("#SubGroupName").attr("disabled", "disabled");
                    }
                    $("#SubGroupId").val(obj.data.Table[0].SubgroupHeadUid);
                    $("#Timestamp").val(obj.data.Table[0].Timestamp);
                    $("#SubGroupName").val(obj.data.Table[0].SubgroupHeadName);
                    $("#GroupId").val(obj.data.Table[0].GroupHeadUid).trigger('change');
                    $("#OrderNo").val(obj.data.Table[0].OrderPLBS);
                    $("#DetailPlBs").prop("checked", obj.data.Table[0].DetailedPLBS);
                    $("#AcceptAddress").prop("checked", obj.data.Table[0].AcceptAddress);
                } else {
                    Toast(RetrieveMessage(obj.responsecode), "Message", "error");
                }
            }
            else {
                window.location.href = '/ClientLogin/ClientLogin';
            }
            HideLoader();
        }).fail(function (data) {
            console.log(data.Message);
            HideLoader();
        });
    }
    catch (e) {
        console.log(e.message);
        HideLoader();
    }
}

//SUBGROUP UPDATE BUTTON CLICK
$("#FormUpdate").click(function () {
    RemoveAllError('SubGroupHead');
    ValidateAllFieldNewTest('SubGroupHead');
    if (Ercount == 0) {
        if ($("#GroupId").val() == "0") {
            Toast(RetrieveMessage(805), 'Message', 'error');
            return;
        }
        FormUpdate();
    }
});

//UPDATE SUBGROUP FUNCTION
function FormUpdate() {
    try {
        const datastring = {};
        datastring.SubGroupName = $("#SubGroupName").val();
        datastring.OrderPlBs = $("#OrderNo").val();
        datastring.DetailPlBs = $("#DetailPlBs").is(":checked");
        datastring.AcceptAddress = $("#AcceptAddress").is(":checked");
        datastring.GroupId = $("#GroupId").val();
        datastring.SubGroupId = $("#SubGroupId").val();
        datastring.Timestamp = $("#Timestamp").val();
        ShowLoader();
        AjaxSubmission(JSON.stringify(datastring), "/Master/SubGroupHeads/FormUpdate", $('input[name=__RequestVerificationToken]').val()).done(function (result) {
            let obj = result;
            if (obj.status == true) {
                if (obj.responsecode == '107') {
                    Toast(RetrieveMessage(obj.responsecode), "Message", "success");
                    setTimeout(FormList(1), 500);
                    $("#SubGroupId").val(obj.data.Table[0].SubgroupHeadUid);
                    $("#Timestamp").val(obj.data.Table[0].Timestamp);
                }
                else {
                    Toast(RetrieveMessage(obj.responsecode), "Message", "error");
                }
            }
            else {
                window.location.href = '/ClientLogin/ClientLogin';
            }
            HideLoader();
        }).fail(function (result) {
            console.log(result.Message);
            HideLoader();
        });
    }
    catch (e) {
        console.log(e.message);
        HideLoader();
    }
}

//DELETE SUBGROUP FUNCTION
function FormDelete(e) {
    try {
        $.confirm({
            title: '',
            content: 'Are You Sure Want To Delete ?',
            type: 'red',
            boxWidth: '300px',
            useBootstrap: false,
            columnClass: 'small',
            containerFluid: true,
            typeAnimated: true,
            buttons: {
                tryAgain: {
                    text: 'Confirm',
                    btnClass: 'btn-red',
                    action: function () {

                        const datastring = {};
                        datastring.SubGroupId = parseInt(e);
                        ShowLoader();
                        AjaxSubmission(JSON.stringify(datastring), "/Master/SubGroupHeads/FormDelete", $('[name="__RequestVerificationToken"]').val()).done(function (data) {
                            let obj = data;
                            if (obj.status == true) {
                                if (obj.responsecode == '102') {
                                    Toast(RetrieveMessage(obj.responsecode), "Message", "success");
                                    FormList(1);
                                }
                                else {
                                    Toast(RetrieveMessage(obj.responsecode), "Message", "error");
                                }
                            }
                            else {
                                window.location.href = 'ClientLogin/ClientLogin';
                            }
                            HideLoader();
                        }).fail(function (data) {
                            console.log(data.Message);
                            HideLoader();
                        });
                    }
                },
                close: function () {
                }
            }
        });
    }
    catch (e) {
        console.log(e.message);
        HideLoader();
    }
}

//FUNCTION FOR TAB SHOW
function TabShow() {
    $('#SubGroupHead_list-tab').removeClass('active');
    $('#SubGroupHead-tab').addClass('active');
    $('#SubGroupHead_list').removeClass('active show');
    $('#SubGroupHead').addClass('active show');
    $("#FormAdd").hide();
    $("#FormUpdate").show();
    $("#FormReset").show();
    $("#SubGroupHead-tab").html("Edit Sub Group");
}

//FUNCTION FOR TAB HIDE
function TabHide() {
    $('#SubGroupHead-tab').removeClass('active');
    $('#SubGroupHead_list-tab').addClass('active ');
    $('#SubGroupHead_list').addClass('active show');
    $('#SubGroupHead').removeClass('active show');
    $("#FormAdd").show();
    $("#FormUpdate").hide();
    $("#FormReset").hide();
    $("#SubGroupHead-tab").html("Add Sub Group");
}

//Branch LIST TAB CLICKED
$("#SubGroupHead_list-tab").click(function () {
    ResetForm();
    RemoveAllError('SubGroupHead');
});

function ResetForm() {
    $("#SubGroupId").val('');
    $("#Timestamp").val('');
    $("#SubGroupName").val('');
    $("#SubGroupName").removeAttr("disabled");
    $("#GroupId").val('0').trigger('change');
    $("#DetailPlBs").prop("checked", false);
    $("#AcceptAddress").prop("checked", false);
    $("#OrderNo").val('');

    $("#FormAdd").show();
    $("#FormUpdate").hide();
    $("#FormReset").hide();
    $("#SubGroupHead-tab").html("Add Sub Group");
};


//FUNCTION FOR BIND GROUP NAME
function FillGroupList(DrpId) {
    try {
        //Showloader();
        AjaxSubmission(null, "/Master/SubGroupHeads/GetGroupList", $('input[name=__RequestVerificationToken]').val()).done(function (result) {
            let obj = result;
            if (obj.status == true) {
                if (obj.responsecode == '100') {
                    BindDropdown(obj.data.Table, DrpId, 'GroupHeadUid', 'GroupHeadName', '-----Select-----');
                }
                else if (obj.responsecode == '604') {
                    BindDropdown(null, DrpId, 'GroupHeadUid', 'GroupHeadName', '-----Select-----');
                }
                else {
                    Toast(RetrieveMessage(obj.responsecode), "Message", "error");
                }
            }
            else {
                window.location.href = '/ClientLogin/ClientLogin';
            }
            //Hideloader();
        }).fail(function (result) {
            console.log(result.Message);
            //Hideloader();
        });
    }
    catch (e) {
        console.log(e.message);
        //Hideloader();
    }
}

$(".SubGroupHead_list").click(function () {
    $("#SearchSubGroupId").focus();
})

$("#FormReset").click(function () {
    ResetForm();
})

////FUNCTION FOR GO TO LEDGER
//function GoToGroupHeads(e) {
//    SetCookie('GroupId', $("#" + e).val(), 's', 50);
//}


/*------------------------------------------------------------------- Add edit update group heads--------------------------------------------------------------*/
$("#OpenGroupModal").click(function () {
    groupmodal.style.display = 'block';
    if ($("#GroupId").val() == 0) {

        $("#GroupModalFormAdd").show();
        $("#GroupModalFormUpdate").hide();
        $("#GroupModalFormReset").hide();
    }
    else {

        GroupFormEdit($("#GroupId").val());

        $("#GroupModalFormAdd").hide();
        $("#GroupModalFormUpdate").show();
        $("#GroupModalFormReset").show();
    }
});
//GROUP ADD BUTTON CLICK
$("#GroupModalFormAdd").click(function () {
    RemoveAllError('GroupHeadForm');
    ValidateAllFieldNewTest('GroupHeadForm');

    if (Ercount == 0) {
        if ($("#GroupModalGroupBehaviour").val() == "0") {
            Toast(RetrieveMessage(709), 'Message', 'error');
            return;
        }
        GroupFormAdd();
    }

});

//ADD GROUP FUNCTION
function GroupFormAdd() {
    try {
        const datastring = {};
        datastring.GroupName = $("#GroupModalGroupName").val();
        datastring.GroupBehaviour = $("#GroupModalGroupBehaviour").val();
        datastring.OrderPlBs = $("#GroupModalOrderNo").val();
        ShowLoader();
        AjaxSubmission(JSON.stringify(datastring), "/Master/GroupHeads/FormAdd", $('input[name=__RequestVerificationToken]').val()).done(function (result) {
            let obj = result;
            if (obj.status == true) {
                if (obj.responsecode == '101') {
                    Toast(RetrieveMessage(obj.responsecode), "Message", "success");

                    $("#GroupModalFormAdd").removeClass('d-none');
                    $("#GroupModalFormUpdate").addClass('d-none');

                    $("#GroupModalGroupId").val(obj.data.Table[0].GroupHeadId);
                    $("#GroupModalTimestamp").val(obj.data.Table[0].Timestamp);
                }
                else {
                    Toast(RetrieveMessage(obj.responsecode), "Message", "error");
                }
            }
            else {
                window.location.href = '/ClientLogin/ClientLogin';
            }
            HideLoader();
        }).fail(function (result) {
            console.log(result.Message);
            HideLoader();
        });
    }
    catch (e) {
        console.log(e.message);
        HideLoader();
    }
}
//EDIT GROUP FUNCTION 
function GroupFormEdit(e) {
    try {
        $("#GroupModalFormAdd").addClass('d-none');
        $("#GroupModalFormUpdate").removeClass('d-none');
        ShowLoader();
        const datastring = {};
        datastring.GroupId = e;
        AjaxSubmission(JSON.stringify(datastring), "/Master/GroupHeads/FormEdit", $('[name="__RequestVerificationToken"]').val()).done(function (data) {
            let obj = data;
            if (obj.status == true) {
                if (obj.responsecode == '100') {
                    TabShow();
                    if (obj.data.Table[0].SystemAccount == true) {
                        $("#GroupModalGroupName").attr("disabled", "disabled");
                    }
                    $("#GroupModalGroupId").val(obj.data.Table[0].GroupHeadId);
                    $("#GroupModalTimestamp").val(obj.data.Table[0].Timestamp);
                    $("#GroupModalGroupName").val(obj.data.Table[0].GroupHeadName);
                    $("#GroupModalGroupBehaviour").val(obj.data.Table[0].GroupBehaviour).trigger('change');
                    $("#GroupModalOrderNo").val(obj.data.Table[0].OrderPLBS);
                } else {
                    Toast(RetrieveMessage(obj.responsecode), "Message", "error");
                }
            }
            else {
                window.location.href = '/ClientLogin/ClientLogin';
            }
            HideLoader();
        }).fail(function (data) {
            console.log(data.Message);
            HideLoader();
        });

    }
    catch (e) {
        console.log(e.message);
        HideLoader();
    }
}
//GROUP UPDATE BUTTON CLICK
$("#GroupModalFormUpdate").click(function () {
    RemoveAllError('GroupHeadForm');

    ValidateAllFieldNewTest('GroupHeadForm');

    if (Ercount == 0) {
        if ($("#GroupModalGroupBehaviour").val() == "0") {
            Toast(RetrieveMessage(709), 'Message', 'error');
            return;
        }
        GroupFormUpdate();
    }
});

//UPDATE GROUP FUNCTION
function GroupFormUpdate() {
    try {
        const datastring = {};
        datastring.GroupName = $("#GroupModalGroupName").val();
        datastring.GroupBehaviour = $("#GroupModalGroupBehaviour").val();
        datastring.OrderPlBs = $("#GroupModalOrderNo").val();
        datastring.GroupId = $("#GroupModalGroupId").val();
        datastring.Timestamp = $("#GroupModalTimestamp").val();
        ShowLoader();
        AjaxSubmission(JSON.stringify(datastring), "/Master/GroupHeads/FormUpdate", $('input[name=__RequestVerificationToken]').val()).done(function (result) {
            let obj = result;
            if (obj.status == true) {
                if (obj.responsecode == '107') {
                    Toast(RetrieveMessage(obj.responsecode), "Message", "success");

                    $("#GroupModalGroupId").val(obj.data.Table[0].GroupHeadId);
                    $("#GroupModalTimestamp").val(obj.data.Table[0].Timestamp);
                }
                else {
                    Toast(RetrieveMessage(obj.responsecode), "Message", "error");
                }
            }
            else {
                window.location.href = '/ClientLogin/ClientLogin';
            }
            HideLoader();
        }).fail(function (result) {
            console.log(result.Message);
            HideLoader();

        });
    }
    catch (e) {
        console.log(e.Message);
        HideLoader();
    }
}

//FUNCTION FOR EXPORT DATA IN EXCEL
function FormExcel() {
    ShowLoader();
    let date = new Date();
    let NewDate = ("00" + date.getDate()).slice(-2) + "_" + ("00" + (date.getMonth() + 1)).slice(-2) + "_" + date.getFullYear() + "_" + ("00" + date.getHours()).slice(-2) + "_" + ("00" + date.getMinutes()).slice(-2) + "_" + ("00" + date.getSeconds()).slice(-2);
    let fileName = "SubGroupHeads_" + NewDate + ".xlsx";

    $('#FormSearch').trigger('click');
    AjaxSubmission(null, '/Master/SubGroupHeads/FormExcel', $('input[name=__RequestVerificationToken]').val()).done(function (result) {
        let obj = result;
        if (obj.status == true) {
            if (obj.responsecode == '100') {

                let bytes = Base64ToBytes(obj.data.FileData[0].Base64Data);
                let blob = new Blob([bytes], { type: "application/octetstream" });
                let isIE = false || !!document.documentMode;
                if (isIE) {
                    window.navigator.msSaveBlob(blob, fileName);
                } else {
                    let url = window.URL || window.webkitURL;
                    link = url.createObjectURL(blob);
                    let a = $("<a />");
                    a.attr("download", fileName);
                    a.attr("href", link);
                    $("body").append(a);
                    a[0].click();
                    $("body").remove(a);
                }
            }
            else if (obj.responsecode == '302')
                Toast("No Records found.", 'Message', 'success');
            else
                Toast(RetrieveMessage(obj.responsecode), 'Message', 'error');

        } else
            window.location.href = '/ClientLogin/ClientLogin';
        HideLoader();

    }).fail(function (result) {
        console.log(result.Message);
        HideLoader();
    });
}
//FUNCTION FOR RESET DATA
function ResetGroupForm() {
    groupmodal.style.display = 'none';
    $("#GroupModalGroupId").val('');
    $("#GroupModalGroupName").val('');
    $("#GroupModalGroupName").removeAttr("disabled");
    $("#GroupModalGroupBehaviour").val('0').trigger('change');
    $("#GroupModalOrderNo").val('');

    $("#GroupModalFormAdd").removeClass('d-none');
    $("#GroupModalFormUpdate").addClass('d-none');

    RemoveAllError('GroupHeadForm');
}
$("#GroupModalFormReset").click(function () {
    ResetGroupForm();
});
$("#GroupModalClose").click(function () {
    ResetGroupForm();
});

document.addEventListener("keydown", function (zEvent) {
    if (zEvent.ctrlKey && zEvent.altKey && (zEvent.key == "j" || zEvent.key == "J")) {
        $('#SubGroupHead_list-tab').removeClass('active ');
        $('#SubGroupHead_list').removeClass('active show');
        $('#SubGroupHead-tab').addClass('active');
        $('#SubGroupHead').addClass('active show');
        $("#FormAdd").show();
        $("#FormUpdate").hide();
        $("#FormReset").hide();
        $("#SubGroupHead-tab").html("Add Sub Group  ");
        ResetForm();
        $('#SubGroupName').focus();
    }
});
